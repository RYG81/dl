"""
Standalone ComfyUI SIGMAS injection / resampling node.

Extracted from the resample-aware sigma helper in the user's
LTX Motion Lab v0.4 workflow, but made model-agnostic and preset-free.

Modes:
- truncate_tail: keep the incoming schedule from the snapped sigma onward
- preserve_shape: resample that tail to target_steps while preserving its curve shape
- linear_to_zero: create a simple linear schedule from the snapped sigma to zero
"""

import torch
import torch.nn.functional as F


class InjectSigmasStandalone:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "sigmas": ("SIGMAS",),
                "inject_sigma": (
                    "FLOAT",
                    {
                        "default": 0.9094,
                        "min": 0.0,
                        "max": 100.0,
                        "step": 0.0001,
                        "tooltip": (
                            "Desired starting sigma. The node snaps to a value "
                            "present in the incoming SIGMAS schedule."
                        ),
                    },
                ),
                "snap_mode": (
                    ["nearest", "at_or_below", "at_or_above"],
                    {
                        "default": "nearest",
                        "tooltip": (
                            "nearest: closest value. "
                            "at_or_below: first schedule value <= requested. "
                            "at_or_above: last schedule value >= requested."
                        ),
                    },
                ),
                "schedule_mode": (
                    ["truncate_tail", "preserve_shape", "linear_to_zero"],
                    {
                        "default": "preserve_shape",
                        "tooltip": (
                            "truncate_tail keeps the remaining incoming schedule exactly. "
                            "preserve_shape resamples the remaining tail to target_steps. "
                            "linear_to_zero creates a linear schedule from the snapped sigma to 0."
                        ),
                    },
                ),
                "target_steps": (
                    "INT",
                    {
                        "default": 8,
                        "min": 1,
                        "max": 1024,
                        "step": 1,
                        "tooltip": (
                            "Number of sampling intervals produced by preserve_shape "
                            "or linear_to_zero. Ignored by truncate_tail."
                        ),
                    },
                ),
            }
        }

    RETURN_TYPES = ("SIGMAS", "INT", "FLOAT", "INT", "STRING")
    RETURN_NAMES = ("sigmas", "steps", "snapped_sigma", "start_index", "debug")
    FUNCTION = "build_sigma_schedule"
    CATEGORY = "sampling/sigmas"

    @staticmethod
    def _pick_start(candidates, target, snap_mode):
        if snap_mode == "nearest":
            return int(torch.argmin((candidates - target).abs()).item())

        if snap_mode == "at_or_below":
            valid = torch.where(candidates <= target)[0]
            if valid.numel():
                return int(valid[0].item())
            return int(candidates.numel() - 1)

        if snap_mode == "at_or_above":
            valid = torch.where(candidates >= target)[0]
            if valid.numel():
                return int(valid[-1].item())
            return 0

        raise ValueError(f"Unknown snap_mode: {snap_mode}")

    @staticmethod
    def _resample_preserve_shape(tail, target_steps):
        # tail includes starting sigma and terminal zero.
        size = int(target_steps) + 1

        if tail.numel() == size:
            out = tail.clone()
        elif tail.numel() == 1:
            out = torch.cat(
                [
                    tail,
                    torch.zeros(
                        size - 1,
                        dtype=tail.dtype,
                        device=tail.device,
                    ),
                ]
            )
        else:
            out = F.interpolate(
                tail.view(1, 1, -1),
                size=size,
                mode="linear",
                align_corners=True,
            ).view(-1)

        # Preserve exact endpoints.
        out[0] = tail[0]
        out[-1] = torch.tensor(0.0, dtype=out.dtype, device=out.device)

        # Enforce a monotonic non-increasing schedule.
        for i in range(1, out.numel()):
            if out[i] > out[i - 1]:
                out[i] = out[i - 1]

        return torch.clamp(out, min=0.0)

    @staticmethod
    def _resample_linear(start_sigma, target_steps, ref_tensor):
        return torch.linspace(
            float(start_sigma),
            0.0,
            int(target_steps) + 1,
            dtype=ref_tensor.dtype,
            device=ref_tensor.device,
        )

    def build_sigma_schedule(
        self,
        sigmas,
        inject_sigma,
        snap_mode,
        schedule_mode,
        target_steps,
    ):
        if not isinstance(sigmas, torch.Tensor):
            raise ValueError("Expected SIGMAS to be a torch.Tensor.")

        if sigmas.ndim != 1 or sigmas.numel() < 2:
            raise ValueError(
                f"Expected a 1D SIGMAS tensor with at least two entries, got shape {tuple(sigmas.shape)}."
            )

        vals = sigmas.detach().float()

        # Ignore the final terminal zero for selecting the injection point.
        candidates = vals[:-1]
        if candidates.numel() == 0:
            raise ValueError("Incoming SIGMAS schedule has no selectable start sigma.")

        target = float(inject_sigma)
        idx = self._pick_start(candidates, target, snap_mode)
        snapped = float(vals[idx].item())

        tail = sigmas[idx:]
        original_tail_steps = int(tail.numel() - 1)

        if schedule_mode == "truncate_tail":
            out = tail.clone()

        elif schedule_mode == "preserve_shape":
            out = self._resample_preserve_shape(
                tail.float(),
                int(target_steps),
            ).to(dtype=sigmas.dtype, device=sigmas.device)

        elif schedule_mode == "linear_to_zero":
            out = self._resample_linear(
                snapped,
                int(target_steps),
                sigmas,
            )

        else:
            raise ValueError(f"Unknown schedule_mode: {schedule_mode}")

        steps = int(out.numel() - 1)
        sched = ", ".join(f"{float(v):.6f}" for v in out.tolist())

        debug = (
            f"Inject Sigmas Standalone | requested={target:.6f} -> snapped={snapped:.6f} "
            f"| snap={snap_mode} | mode={schedule_mode} | start_index={idx} "
            f"| incoming_intervals={int(sigmas.numel() - 1)} | output_intervals={steps} "
            f"| original_tail_intervals={original_tail_steps} "
            f"| schedule=[{sched}]"
        )

        print("[Inject Sigmas Standalone]", debug)
        return out, steps, snapped, idx, debug


NODE_CLASS_MAPPINGS = {
    "InjectSigmasStandalone": InjectSigmasStandalone,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "InjectSigmasStandalone": "💉 Inject Sigmas (Standalone)",
}
