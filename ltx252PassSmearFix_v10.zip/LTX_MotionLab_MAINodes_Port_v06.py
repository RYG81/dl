"""LTX Motion Lab — MAINodes-inspired port v0.6

A more faithful LTX adaptation of MatlowAI's public MIT-licensed
ComfyUI-MAINodes Motion Lab concepts (motion.py), while keeping LTX-specific
temporal geometry (8x temporal compression, legal decoded lengths 8k+1).

Adapted concepts:
- latent jerk/profile oracle with presets, bridging, C1-ish hold ramps
- adaptive time smear with cost/report outputs
- LTX V2V Init-style selective regeneration mask ("background freeze")
- exact first-frame recovery
- sigma injection helper

Original project:
  https://github.com/matlowai/ComfyUI-MAINodes
License: MIT (retain attribution when redistributing this derivative).

This is an experimental LTX port, not an official MAINodes component.
"""

import json
import math
import torch
import torch.nn.functional as F

LTX_TEMPORAL_STRIDE = 8
LTX_LEGAL_OFFSET = 1


def _video_component(samples):
    if not isinstance(samples, dict) or "samples" not in samples:
        raise ValueError("Expected a ComfyUI LATENT dict with key 'samples'.")
    z = samples["samples"]
    if hasattr(z, "is_nested") and z.is_nested:
        z = z.tensors[0]
    if not isinstance(z, torch.Tensor):
        raise ValueError("LATENT samples are not a torch.Tensor.")
    if z.ndim != 5:
        raise ValueError(f"Expected LTX video latent [B,C,T,H,W], got {tuple(z.shape)}")
    return z


def _latent_to_frames(t_lat):
    return max(1, (int(t_lat) - 1) * LTX_TEMPORAL_STRIDE + 1)


def _expected_latent_t(length):
    length = int(length)
    return max(1, int(math.ceil((max(1, length) - 1) / LTX_TEMPORAL_STRIDE)) + 1)


def _frame_token(frame, t_lat):
    return min(max(0, int(frame) // LTX_TEMPORAL_STRIDE), max(0, int(t_lat) - 1))


def _legal_ceil(n):
    n = max(1, int(n))
    if n <= 1:
        return 1
    k = int(math.ceil((n - LTX_LEGAL_OFFSET) / LTX_TEMPORAL_STRIDE))
    return k * LTX_TEMPORAL_STRIDE + LTX_LEGAL_OFFSET


LTX_MAX_END_TAIL = LTX_TEMPORAL_STRIDE

def _hold_runs(holds):
    runs=[]
    for h in holds:
        h=int(h)
        if runs and runs[-1][0]==h:
            runs[-1][1]+=1
        else:
            runs.append([h,1])
    return [(r,c) for r,c in runs]

def _hold_runs_str(holds):
    return "+".join(f"[{r}]*{c}" for r,c in _hold_runs(holds))

def _expand_hold_map_to_end(holds):
    holds=[max(1,int(h)) for h in holds]
    if not holds:
        return holds, None
    n=len(holds)
    tail=0
    while tail<n and holds[n-1-tail]==1:
        tail+=1
    if tail==0 or tail==n or tail>LTX_MAX_END_TAIL:
        return holds, None
    start=n-tail-1
    rate=holds[start]
    while start>0 and holds[start-1]==rate:
        start-=1
    out=holds[:start]+[rate]*(n-start)
    region=n-start
    deficit=_legal_ceil(sum(out))-sum(out)
    q,rem=divmod(deficit,region)
    for i in range(start,n):
        out[i]+=q
    if rem:
        for i in range(n-rem,n):
            out[i]+=1
    note=(f"expand_to_end: rewrote end span through world frame {n-1}: "
          f"{_hold_runs_str(holds)} ({sum(holds)}f) -> "
          f"{_hold_runs_str(out)} ({sum(out)}f)")
    return out,note


def _profile(z, mode):
    """Per-token temporal profile.

    MAINodes' validated H3 default is |Δ³| ("jerk"). LTX exposes a couple of
    alternate diagnostics because its tokenization differs from H3.
    """
    v = z.detach().float()
    T = int(v.shape[2])
    if T < 2:
        return torch.ones(T, dtype=torch.float32)

    d1 = v[:, :, 1:] - v[:, :, :-1]
    p1 = d1.abs().mean(dim=(0, 1, 3, 4)).detach().cpu()

    d2 = d1[:, :, 1:] - d1[:, :, :-1] if T >= 3 else None
    p2 = d2.abs().mean(dim=(0, 1, 3, 4)).detach().cpu() if d2 is not None else None

    d3 = d2[:, :, 1:] - d2[:, :, :-1] if T >= 4 else None
    p3 = d3.abs().mean(dim=(0, 1, 3, 4)).detach().cpu() if d3 is not None else None

    def pad_right(p, offset):
        if p is None or p.numel() == 0:
            return torch.ones(T, dtype=torch.float32)
        out = torch.empty(T, dtype=torch.float32)
        out[:offset] = p[0]
        n = min(p.numel(), T - offset)
        out[offset:offset+n] = p[:n]
        if offset+n < T:
            out[offset+n:] = p[-1]
        return out

    a1 = pad_right(p1, 1)
    a2 = pad_right(p2, 1)
    a3 = pad_right(p3, 1)

    if mode == "value |d1|":
        return a1
    if mode == "value |d2|":
        return a2
    if mode == "hybrid d2+d3":
        def norm(x):
            q = torch.quantile(x.float(), 0.95).clamp(min=1e-8)
            return (x / q).clamp(0, 3)
        return 0.35 * norm(a2) + 0.65 * norm(a3)
    return a3  # value |d3| (default)


def _ramp_holds(tok_d, d_max):
    tok_d = tok_d.clone()
    one = torch.ones(1, dtype=tok_d.dtype)
    for _ in range(max(0, int(d_max) - 1)):
        left = torch.cat([one, tok_d[:-1]])
        right = torch.cat([tok_d[1:], one])
        tok_d = torch.maximum(tok_d, torch.maximum(left, right) - 1)
    return tok_d


def _parse_hold_map(s):
    if not isinstance(s, str) or not s.strip():
        raise ValueError("hold_map is empty")
    data = json.loads(s)
    holds = [max(1, int(v)) for v in data.get("holds", [])]
    world_len = int(data.get("world_len", len(holds)))
    if len(holds) != world_len:
        raise ValueError(f"hold_map contains {len(holds)} holds but world_len={world_len}")
    return data, holds, world_len


def _norm_heat(x):
    x = x.float()
    lo = torch.quantile(x.flatten(), 0.05)
    hi = torch.quantile(x.flatten(), 0.995)
    return ((x - lo) / (hi - lo + 1e-8)).clamp(0, 1)


class LTXMAINodesJerkOracleV02:
    PRESETS = {
        "balanced (MAINodes-like)": {"q": 0.75, "d_max": 4, "ramp": True, "bridge": 8},
        "max quality (wide plateau)": {"q": 0.70, "d_max": 4, "ramp": True, "bridge": 8},
        "economy (tight spans)": {"q": 0.85, "d_max": 3, "ramp": True, "bridge": 4},
        "LTX conservative": {"q": 0.82, "d_max": 4, "ramp": True, "bridge": 2},
    }

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "samples": ("LATENT",),
            "length": ("INT", {"default": 0, "min": 0, "max": 10000, "step": 1}),
            "q": ("FLOAT", {"default": 0.75, "min": 0.50, "max": 0.99, "step": 0.01}),
            "d_max": ("INT", {"default": 4, "min": 2, "max": 8, "step": 1}),
            "ramp": ("BOOLEAN", {"default": True}),
            "preset": (["custom"] + list(cls.PRESETS), {"default": "custom"}),
            "bridge": ("INT", {"default": 8, "min": 0, "max": 20, "step": 1}),
            "profile_mode": (["value |d3| (default)", "value |d2|", "value |d1|", "hybrid d2+d3"],
                             {"default": "value |d3| (default)"}),
            "abstain_below": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 10.0, "step": 0.05}),
            "fps": ("INT", {"default": 24, "min": 1, "max": 120}),
            "s_per_step": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 60.0, "step": 0.01}),
            "est_steps": ("INT", {"default": 18, "min": 1, "max": 100}),
            "overhead_s": ("FLOAT", {"default": 7.0, "min": 0.0, "max": 300.0, "step": 0.5}),
        }}

    RETURN_TYPES = ("STRING", "STRING", "INT", "INT", "STRING", "STRING")
    RETURN_NAMES = ("hold_map", "segments", "window_start", "window_len", "profile", "report")
    FUNCTION = "read"
    CATEGORY = "LTX/Motion Lab MAINodes Port"

    def read(self, samples, length, q, d_max, ramp, preset, bridge, profile_mode,
             abstain_below, fps, s_per_step, est_steps, overhead_s):
        if preset in self.PRESETS:
            p = self.PRESETS[preset]
            q, d_max, ramp, bridge = p["q"], p["d_max"], p["ramp"], p["bridge"]

        z = _video_component(samples)
        t_lat = int(z.shape[2])
        inferred = _latent_to_frames(t_lat)
        length = inferred if int(length) <= 0 else int(length)

        mode = profile_mode.replace(" (default)", "")
        prof = _profile(z, mode)
        thr = torch.quantile(prof.float(), float(q))

        tok_d = torch.where(
            prof >= thr,
            torch.full_like(prof, int(d_max), dtype=torch.int64),
            torch.ones_like(prof, dtype=torch.int64),
        )
        if float(abstain_below) > 0:
            tok_d = torch.where(
                prof >= float(abstain_below),
                tok_d,
                torch.ones_like(tok_d),
            )

        if int(bridge) > 0:
            hot = torch.where(tok_d == int(d_max))[0].tolist()
            for a, b in zip(hot[:-1], hot[1:]):
                if 1 < b - a <= int(bridge):
                    tok_d[a:b+1] = int(d_max)

        if bool(ramp):
            tok_d = _ramp_holds(tok_d, d_max)

        holds = [int(tok_d[_frame_token(f, t_lat)].item()) for f in range(length)]

        segs = []
        s0 = 0
        for t in range(1, t_lat + 1):
            if t == t_lat or int(tok_d[t]) != int(tok_d[s0]):
                if int(tok_d[s0]) > 1:
                    segs.append(f"{s0}:{t}:{int(tok_d[s0])}")
                s0 = t

        hot_tokens_idx = torch.where(tok_d > 1)[0].tolist()
        if hot_tokens_idx:
            w0 = max(0, hot_tokens_idx[0] * LTX_TEMPORAL_STRIDE)
            w1 = min(length, (hot_tokens_idx[-1] + 1) * LTX_TEMPORAL_STRIDE + 1)
            wlen = max(1, w1 - w0)
        else:
            w0, wlen = 0, length

        hot_frames = sum(h > 1 for h in holds)
        smear_raw = sum(holds)
        est = float(overhead_s) + float(s_per_step) * int(est_steps) * max(1.0, smear_raw / max(1, length))
        hold_map = json.dumps({
            "version": "ltx-mainodes-port-v06",
            "holds": holds,
            "world_len": length,
            "latent_t": t_lat,
            "q": float(q),
            "d_max": int(d_max),
            "ramp": bool(ramp),
            "bridge": int(bridge),
            "profile_mode": mode,
        })
        profile = " ".join(f"{float(v):.3f}" for v in prof.tolist())
        token_holds = "".join(str(min(9, int(v))) for v in tok_d.tolist())
        report = (
            f"decoded={length} latentT={t_lat} | hot_tokens={len(hot_tokens_idx)}/{t_lat} | "
            f"hot_frames={hot_frames}/{length} ({hot_frames/max(1,length):.1%}) | "
            f"q={q:.2f} d_max={d_max} ramp={ramp} bridge={bridge} | token_holds={token_holds}\n"
            f"window={w0}:{w0+wlen} | segments={','.join(segs) or 'none'} | "
            f"raw smear≈{smear_raw} frames ({smear_raw/max(1,length):.2f}x) | "
            f"fps={fps} est≈{est:.1f}s"
        )
        print("[LTX MAINodes Port v0.6]", report)
        return hold_map, ",".join(segs), int(w0), int(wlen), profile, report


class LTXMAINodesTimeSmearV02:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",),
            "dilation": ("INT", {"default": 4, "min": 1, "max": 8}),
            "expand_to_end": ("BOOLEAN", {"default": True}),
            "fps": ("INT", {"default": 24, "min": 1, "max": 120}),
            "s_per_step": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 60.0, "step": 0.01}),
            "est_steps": ("INT", {"default": 18, "min": 1, "max": 100}),
            "overhead_s": ("FLOAT", {"default": 7.0, "min": 0.0, "max": 300.0, "step": 0.5}),
        }, "optional": {
            "hold_map": ("STRING", {"default": ""}),
        }}

    RETURN_TYPES = ("IMAGE", "STRING", "INT", "STRING")
    RETURN_NAMES = ("images", "hold_map_used", "length", "report")
    FUNCTION = "smear"
    CATEGORY = "LTX/Motion Lab MAINodes Port"

    def smear(self, images, dilation, expand_to_end, fps, s_per_step, est_steps, overhead_s, hold_map=""):
        if not isinstance(images, torch.Tensor) or images.ndim != 4:
            raise ValueError(f"Expected IMAGE [T,H,W,C], got {getattr(images, 'shape', None)}")
        images_cpu = images.detach().cpu()
        n = int(images_cpu.shape[0])

        if isinstance(hold_map, str) and hold_map.strip():
            _, holds, world_len = _parse_hold_map(hold_map)
            if world_len != n:
                raise ValueError(f"hold map covers {world_len} frames, IMAGE has {n}")
        else:
            holds = [max(1, int(dilation))] * n

        note = None
        if bool(expand_to_end):
            holds, note = _expand_hold_map_to_end(holds)
            if note:
                print("[LTX MAINodes Port v0.6]", note)

        raw = sum(holds)
        target = _legal_ceil(raw)
        used = list(holds)
        if target != raw:
            used[-1] += target - raw

        idx = torch.tensor([i for i, h in enumerate(used) for _ in range(int(h))], dtype=torch.long)
        out = images_cpu.index_select(0, idx)
        starts = []
        cur = 0
        for h in used:
            starts.append(cur)
            cur += int(h)

        used_json = json.dumps({
            "version": "ltx-mainodes-port-v06",
            "holds": used,
            "world_len": n,
            "raw_target": raw,
            "target": target,
            "smeared_len": int(out.shape[0]),
            "recover_starts": starts,
        })
        est = float(overhead_s) + float(s_per_step) * int(est_steps) * max(1.0, target/max(1,n))
        report = (
            f"LTX Time Smear v0.6 | {n}->{target} | raw={raw} | "
            f"avg_hold={target/max(1,n):.2f}x | fps={fps} | est≈{est:.1f}s"
        )
        if note:
            report += "\n" + note
        print("[LTX MAINodes Port v0.6]", report)
        return out, used_json, int(target), report


class LTXMAINodesV2VInitV02:
    """LTX equivalent of MAINodes H3 V2V Init's selective regeneration mask.

    `samples` is the VAE-encoded SMEARED clip.
    `oracle_samples` is the BASELINE latent used by the jerk oracle.

    The mask is derived from a spatial union (or time-varying version) of
    baseline latent jerk. Mask value 1 = allow regeneration; 0 = freeze/preserve.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "samples": ("LATENT",),
            "freeze_threshold": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.05}),
            "freeze_grow": ("INT", {"default": 2, "min": 0, "max": 16}),
            "mask_feather": ("INT", {"default": 0, "min": 0, "max": 16}),
            "invert_mask": ("BOOLEAN", {"default": False}),
            "time_varying": ("BOOLEAN", {"default": False}),
        }, "optional": {
            "oracle_samples": ("LATENT",),
        }}

    RETURN_TYPES = ("LATENT", "MASK", "STRING")
    RETURN_NAMES = ("latents", "mask", "debug")
    FUNCTION = "build"
    CATEGORY = "LTX/Motion Lab MAINodes Port"

    def build(self, samples, freeze_threshold, freeze_grow, mask_feather, invert_mask,
              time_varying, oracle_samples=None):
        video = _video_component(samples)
        B, C, T, H, W = video.shape
        out = dict(samples)

        # threshold 0 or missing oracle = full regen/no freezing
        if oracle_samples is None or float(freeze_threshold) <= 0:
            nm = torch.ones((B, 1, T, H, W), device=video.device, dtype=video.dtype)
            out["noise_mask"] = nm
            preview = nm[0, 0]
            debug = f"LTX V2V Init v0.6 | freeze=OFF | full regen mask | latent={tuple(video.shape)}"
            print("[LTX MAINodes Port v0.6]", debug)
            return out, preview, debug

        z = _video_component(oracle_samples).detach().float()
        if z.shape[-2:] != (H, W):
            z = F.interpolate(
                z.permute(0, 2, 1, 3, 4).reshape(-1, z.shape[1], z.shape[3], z.shape[4]),
                size=(H, W), mode="bilinear", align_corners=False
            ).reshape(z.shape[0], z.shape[2], z.shape[1], H, W).permute(0, 2, 1, 3, 4)

        # spatial jerk heat over baseline latent
        if z.shape[2] >= 4:
            d1 = z[:, :, 1:] - z[:, :, :-1]
            d2 = d1[:, :, 1:] - d1[:, :, :-1]
            d3 = d2[:, :, 1:] - d2[:, :, :-1]
            j = d3.abs().mean(dim=(0, 1))  # [Tb-3,H,W]
        else:
            j = (z[:, :, 1:] - z[:, :, :-1]).abs().mean(dim=(0, 1))

        if j.numel() == 0:
            heat_static = torch.ones((H, W))
            heat_t = torch.ones((1, H, W))
        else:
            heat_t = torch.stack([_norm_heat(x.cpu()) for x in j], dim=0)
            heat_static = _norm_heat(j.max(dim=0).values.cpu())

        if bool(time_varying):
            # resample baseline jerk maps over smeared latent T
            ht = heat_t[None, None]  # [1,1,t,h,w]
            ht = F.interpolate(ht, size=(T, H, W), mode="trilinear", align_corners=False)[0, 0]
            m = (ht >= float(freeze_threshold)).float()  # [T,H,W]
        else:
            m2 = (heat_static >= float(freeze_threshold)).float()
            m = m2[None].expand(T, H, W).clone()

        # grow REGEN region, matching MAINodes' idea of giving moving subject room
        if int(freeze_grow) > 0:
            k = int(freeze_grow) * 2 + 1
            mm = m[:, None]
            mm = F.max_pool2d(mm, kernel_size=k, stride=1, padding=k//2)
            m = mm[:, 0]

        # feather mask edges into soft regeneration weights
        if int(mask_feather) > 0:
            k = int(mask_feather) * 2 + 1
            mm = m[:, None]
            mm = F.avg_pool2d(mm, kernel_size=k, stride=1, padding=k//2)
            m = mm[:, 0].clamp(0, 1)

        if bool(invert_mask):
            m = 1.0 - m

        nm = m[None, None].to(video.device, dtype=video.dtype).expand(B, 1, T, H, W).contiguous()
        out["noise_mask"] = nm
        coverage = float(m.mean().item())
        debug = (
            f"LTX V2V Init v0.6 | threshold={freeze_threshold:.2f} grow={freeze_grow} "
            f"feather={mask_feather} invert={invert_mask} time_varying={time_varying} | "
            f"regen_mask={coverage:.1%} | latent={tuple(video.shape)}"
        )
        print("[LTX MAINodes Port v0.6]", debug)
        return out, m.to(video.device), debug


class LTXMAINodesExactRecoverV02:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",),
            "hold_map": ("STRING", {"default": ""}),
        }}

    RETURN_TYPES = ("IMAGE", "INT", "STRING")
    RETURN_NAMES = ("images", "frame_count", "debug")
    FUNCTION = "recover"
    CATEGORY = "LTX/Motion Lab MAINodes Port"

    def recover(self, images, hold_map):
        data, holds, world_len = _parse_hold_map(hold_map)
        actual = int(images.shape[0])

        # Prefer the exact recovery indices emitted by Time Smear.
        # This prevents any rewritten or legality-adjusted hold map from being
        # silently reinterpreted differently during recovery.
        starts = data.get("recover_starts")
        if starts is not None:
            starts = [int(v) for v in starts]
            expected = int(data.get("smeared_len", sum(holds)))
            if len(starts) != world_len:
                raise ValueError(
                    f"hold_map_used has {len(starts)} recovery starts but world_len={world_len}."
                )
            mode = "explicit"
        else:
            starts, cur = [], 0
            for h in holds:
                starts.append(cur)
                cur += int(h)
            expected = cur
            mode = "legacy"

        if expected != actual:
            raise ValueError(
                f"Exact recovery expects {expected} smeared frames, input has {actual}. "
                f"Connect Time Smear's hold_map_used output to Exact Recover."
            )

        if not starts:
            raise ValueError("Exact recovery received no recovery indices.")

        idx = torch.tensor(starts, device=images.device, dtype=torch.long)
        out = images.index_select(0, idx)
        debug = (
            f"LTX Exact Recover v0.6 | {actual}->{out.shape[0]} | "
            f"recovery_indices={mode}"
        )
        print("[LTX MAINodes Port v0.6]", debug)
        return out, int(out.shape[0]), debug


class LTXMAINodesInjectSigmasV04:
    """Sigma-aware LTX repair injection v0.4.

    v0.3 only *truncated* the incoming schedule, which meant choosing
    a late sigma like 0.725 could collapse the schedule to just a couple of
    intervals. v0.4 adds explicit resampling so you can keep, for example,
    8 repair steps starting at 0.725.

    Modes:
    - truncate_tail: old behavior, keep the remaining tail exactly
    - preserve_shape: resample the snapped tail to `target_steps` while keeping
      the original tail's overall sigma curve shape
    - linear_to_zero: generate a simple linear sigma ramp from snapped sigma to 0
    """

    PRESETS = {
        "aggressive repair ~0.975": 0.975,
        "balanced repair ~0.909": 0.9094,
        "conservative repair ~0.725": 0.725,
        "cleanup only ~0.422": 0.4219,
    }

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "sigmas": ("SIGMAS",),
            "inject_sigma": ("FLOAT", {
                "default": 0.9094, "min": 0.0, "max": 1.5, "step": 0.0001,
                "tooltip": "Desired starting sigma. The node snaps to the nearest actual value in the incoming schedule."
            }),
            "preset": (["custom"] + list(cls.PRESETS), {"default": "balanced repair ~0.909"}),
            "snap_mode": (["nearest", "at_or_below", "at_or_above"], {
                "default": "nearest",
                "tooltip": "How to choose an actual sigma from the incoming schedule."
            }),
            "schedule_mode": (["truncate_tail", "preserve_shape", "linear_to_zero"], {
                "default": "preserve_shape",
                "tooltip": "truncate_tail keeps the remaining tail exactly. preserve_shape rescales the snapped tail to target_steps. linear_to_zero creates a simple linear ramp."
            }),
            "target_steps": ("INT", {
                "default": 8, "min": 1, "max": 128, "step": 1,
                "tooltip": "Used by preserve_shape and linear_to_zero. Number of intervals to output."
            }),
        }}

    RETURN_TYPES = ("SIGMAS", "INT", "FLOAT", "INT", "STRING")
    RETURN_NAMES = ("sigmas", "steps", "snapped_sigma", "start_index", "debug")
    FUNCTION = "build_sigma_schedule"
    CATEGORY = "LTX/Motion Lab MAINodes Port"

    def _pick_start(self, candidates, target, snap_mode):
        if snap_mode == "nearest":
            return int(torch.argmin((candidates - target).abs()).item())
        if snap_mode == "at_or_below":
            valid = torch.where(candidates <= target)[0]
            if valid.numel():
                return int(valid[0].item())
            return int(candidates.numel() - 1)
        if snap_mode == "at_or_above":
            valid = torch.where(candidates >= target)[0]
            if valid.numel():
                return int(valid[-1].item())
            return 0
        raise ValueError(f"Unknown snap_mode: {snap_mode}")

    def _resample_preserve_shape(self, tail, target_steps):
        # tail includes start sigma and terminal zero, shape [L]
        size = int(target_steps) + 1
        if tail.numel() == size:
            out = tail.clone()
        elif tail.numel() == 1:
            out = torch.cat([tail, torch.zeros(size - 1, dtype=tail.dtype, device=tail.device)])
        else:
            out = F.interpolate(
                tail.view(1, 1, -1),
                size=size,
                mode="linear",
                align_corners=True,
            ).view(-1)
        out[0] = tail[0]
        out[-1] = torch.tensor(0.0, dtype=out.dtype, device=out.device)
        # keep monotonic non-increasing schedule
        for i in range(1, out.numel()):
            if out[i] > out[i - 1]:
                out[i] = out[i - 1]
        out = torch.clamp(out, min=0.0)
        return out

    def _resample_linear(self, start_sigma, target_steps, ref_tensor):
        return torch.linspace(
            float(start_sigma),
            0.0,
            int(target_steps) + 1,
            dtype=ref_tensor.dtype,
            device=ref_tensor.device,
        )

    def build_sigma_schedule(self, sigmas, inject_sigma, preset, snap_mode, schedule_mode, target_steps):
        if preset in self.PRESETS:
            inject_sigma = float(self.PRESETS[preset])

        if not isinstance(sigmas, torch.Tensor) or sigmas.ndim != 1 or sigmas.numel() < 2:
            raise ValueError("Expected 1D SIGMAS tensor with at least two entries.")

        vals = sigmas.detach().float()
        candidates = vals[:-1]  # ignore final 0 for start selection
        target = float(inject_sigma)
        idx = self._pick_start(candidates, target, snap_mode)
        snapped = float(vals[idx].item())
        tail = sigmas[idx:]
        original_steps = int(tail.numel() - 1)

        if schedule_mode == "truncate_tail":
            out = tail.clone()
        elif schedule_mode == "preserve_shape":
            out = self._resample_preserve_shape(tail.float(), int(target_steps)).to(sigmas.dtype).to(sigmas.device)
        elif schedule_mode == "linear_to_zero":
            out = self._resample_linear(snapped, int(target_steps), sigmas)
        else:
            raise ValueError(f"Unknown schedule_mode: {schedule_mode}")

        steps = int(out.numel() - 1)
        sched = ", ".join(f"{float(v):.4f}" for v in out.tolist())
        debug = (
            f"LTX Inject Sigmas v0.6 | requested={target:.4f} -> snapped={snapped:.4f} "
            f"| snap={snap_mode} | mode={schedule_mode} | start_index={idx} "
            f"| intervals={int(sigmas.numel()-1)}->{steps} | tail_intervals={original_steps} "
            f"| schedule=[{sched}]"
        )
        print("[LTX MAINodes Port v0.6]", debug)
        return out, steps, snapped, idx, debug


class LTXMAINodesHoldMapInfoV02:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"hold_map": ("STRING", {"default": ""})}}

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("info",)
    FUNCTION = "info"
    CATEGORY = "LTX/Motion Lab MAINodes Port"

    def info(self, hold_map):
        data, holds, world_len = _parse_hold_map(hold_map)
        total = sum(holds)
        hot = sum(h > 1 for h in holds)
        strip = "".join("." if h == 1 else str(min(9, h)) for h in holds)
        if len(strip) > 240:
            strip = strip[:120] + " ... " + strip[-120:]
        return (
            f"world frames: {world_len}\n"
            f"smeared frames: {data.get('target', total)}\n"
            f"hot frames: {hot}/{world_len} ({hot/max(1,world_len):.1%})\n"
            f"max hold: {max(holds) if holds else 1}\n"
            f"map: {strip}",
        )


NODE_CLASS_MAPPINGS = {
    "LTXMAINodesJerkOracleV02": LTXMAINodesJerkOracleV02,
    "LTXMAINodesTimeSmearV02": LTXMAINodesTimeSmearV02,
    "LTXMAINodesV2VInitV02": LTXMAINodesV2VInitV02,
    "LTXMAINodesExactRecoverV02": LTXMAINodesExactRecoverV02,
    "LTXMAINodesInjectSigmasV04": LTXMAINodesInjectSigmasV04,
    "LTXMAINodesHoldMapInfoV02": LTXMAINodesHoldMapInfoV02,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "LTXMAINodesJerkOracleV02": "🧪 LTX Jerk Oracle v0.4 (MAINodes Port)",
    "LTXMAINodesTimeSmearV02": "🧪 LTX Time Smear v0.6 (MAINodes Port)",
    "LTXMAINodesV2VInitV02": "🧪 LTX V2V Init v0.6 (MAINodes Port)",
    "LTXMAINodesExactRecoverV02": "🧪 LTX Exact Recover v0.6 (MAINodes Port)",
    "LTXMAINodesInjectSigmasV04": "🧪 LTX Inject Sigmas v0.6 (Resample-aware)",
    "LTXMAINodesHoldMapInfoV02": "🧪 LTX Hold Map Info v0.4",
}
