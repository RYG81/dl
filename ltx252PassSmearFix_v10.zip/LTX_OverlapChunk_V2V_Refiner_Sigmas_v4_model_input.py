"""
LTX Overlap-Chunk V2V Refiner (SIGMAS edition v4 — MODEL input)

Adds denoise_strength on top of an explicit SIGMAS input.
Instead of generating a new schedule, the node trims the *incoming*
sigma schedule to only use the final portion of that exact schedule.

Examples:
- denoise_strength=1.0  -> use full incoming sigma schedule
- denoise_strength=0.5  -> use roughly the final half of the schedule
- denoise_strength=0.25 -> use roughly the final quarter of the schedule

This keeps the LTX-specific sigma curve while giving a familiar
"repair strength" control.
"""

import copy
import math
import torch

try:
    import comfy.utils
except Exception:
    comfy = None


LTX_TEMPORAL_STRIDE = 8


def _is_video_latent(latent):
    return isinstance(latent, dict) and "samples" in latent and getattr(latent["samples"], "ndim", 0) == 5


def _latent_shape_string(latent):
    z = latent["samples"]
    return f"{tuple(int(x) for x in z.shape)}"


def _decoded_frame_count_from_latent(latent_t):
    latent_t = int(latent_t)
    return max(1, (latent_t - 1) * LTX_TEMPORAL_STRIDE + 1)


def _slice_latent(latent, start_t, end_t):
    """Shallow-copy a LATENT dict and slice the time dimension [B,C,T,H,W]."""
    out = copy.copy(latent)
    out["samples"] = latent["samples"][:, :, start_t:end_t, :, :].clone()

    if "noise_mask" in latent and isinstance(latent["noise_mask"], torch.Tensor):
        nm = latent["noise_mask"]
        try:
            if nm.ndim == 5:
                out["noise_mask"] = nm[:, :, start_t:end_t, :, :].clone()
            elif nm.ndim == 4:
                out["noise_mask"] = nm[:, start_t:end_t, :, :].clone()
            else:
                out["noise_mask"] = nm.clone()
        except Exception:
            out["noise_mask"] = nm.clone()

    if "batch_index" in latent:
        out["batch_index"] = latent["batch_index"]

    return out


def _build_chunk_starts(total_t, chunk_size, overlap):
    total_t = int(total_t)
    chunk_size = int(chunk_size)
    overlap = int(overlap)

    if total_t <= 0:
        raise ValueError("total_t must be > 0")
    if chunk_size <= 0:
        raise ValueError("chunk_size must be > 0")
    if overlap < 0:
        raise ValueError("overlap must be >= 0")
    if chunk_size <= overlap:
        raise ValueError("chunk_size must be greater than overlap")

    if total_t <= chunk_size:
        return [0]

    stride = chunk_size - overlap
    starts = []
    pos = 0
    while True:
        starts.append(int(pos))
        end = pos + chunk_size
        if end >= total_t:
            break
        pos += stride
        if pos + chunk_size >= total_t:
            pos = max(0, total_t - chunk_size)
            if pos != starts[-1]:
                starts.append(int(pos))
            break

    dedup = []
    for s in starts:
        if not dedup or s != dedup[-1]:
            dedup.append(s)
    return dedup


def _make_blend_weights(length, left_overlap, right_overlap, is_first, is_last, device, dtype, curve="linear"):
    w = torch.ones((int(length),), device=device, dtype=dtype)

    lo = int(max(0, left_overlap))
    ro = int(max(0, right_overlap))

    def ramp01(n):
        r = torch.linspace(0.0, 1.0, n + 2, device=device, dtype=dtype)[1:-1]
        if curve == "smoothstep":
            r = r * r * (3.0 - 2.0 * r)
        return r

    if lo > 0 and not is_first:
        ramp = ramp01(lo)
        w[:lo] = torch.minimum(w[:lo], ramp)

    if ro > 0 and not is_last:
        ramp = 1.0 - ramp01(ro)
        w[-ro:] = torch.minimum(w[-ro:], ramp)

    eps = torch.tensor(1e-6, device=device, dtype=dtype)
    return torch.clamp(w, min=eps)


def _prepare_noise_for_chunk(noise, latent_chunk, start_t, end_t, chunk_seed):
    """
    Supports either a Comfy NOISE object (preferred) or a raw tensor.
    Returns a noise tensor for the chunk.
    """
    if hasattr(noise, "generate_noise"):
        noise_obj = copy.copy(noise)
        if hasattr(noise_obj, "seed"):
            try:
                noise_obj.seed = int(chunk_seed)
            except Exception:
                pass
        return noise_obj.generate_noise(latent_chunk)

    if isinstance(noise, torch.Tensor):
        if noise.ndim == 5:
            return noise[:, :, start_t:end_t, :, :].clone()
        return noise.clone()

    raise ValueError(
        "Unsupported NOISE input. Expected a Comfy NOISE object with generate_noise() or a torch.Tensor."
    )


def _extract_sample_tensor(sample_out):
    if isinstance(sample_out, torch.Tensor):
        return sample_out
    if isinstance(sample_out, dict) and "samples" in sample_out:
        return sample_out["samples"]
    if isinstance(sample_out, (tuple, list)) and len(sample_out) > 0:
        first = sample_out[0]
        if isinstance(first, torch.Tensor):
            return first
        if isinstance(first, dict) and "samples" in first:
            return first["samples"]
    raise ValueError(f"Could not extract sample tensor from sampler output of type {type(sample_out)}")


def _run_guider_sample(guider, noise_tensor, latent_tensor, sampler, sigmas, noise_mask, chunk_seed):
    disable_pbar = False
    try:
        disable_pbar = not comfy.utils.PROGRESS_BAR_ENABLED
    except Exception:
        disable_pbar = False

    attempts = [
        lambda: guider.sample(
            noise_tensor,
            latent_tensor,
            sampler,
            sigmas,
            denoise_mask=noise_mask,
            callback=None,
            disable_pbar=disable_pbar,
            seed=int(chunk_seed),
        ),
        lambda: guider.sample(
            noise_tensor,
            latent_tensor,
            sampler,
            sigmas,
            noise_mask,
            None,
            disable_pbar,
            int(chunk_seed),
        ),
        lambda: guider.sample(noise_tensor, latent_tensor, sampler, sigmas),
    ]

    last_err = None
    for fn in attempts:
        try:
            return _extract_sample_tensor(fn())
        except Exception as e:
            last_err = e
    raise last_err



def _guider_with_model(guider, model):
    """Clone a Comfy GUIDER and swap in an optional patched MODEL.

    Keeps the guider conditioning/CFG/state, but replaces its model_patcher and
    model_options so MODEL-patching nodes (FaceID/reference hooks/etc.) can be
    used with this custom refiner.
    """
    if model is None:
        return guider, False

    if not hasattr(guider, "model_patcher"):
        raise ValueError(
            "MODEL input is connected, but the supplied GUIDER has no "
            "model_patcher attribute, so its model cannot be safely replaced."
        )

    g = copy.copy(guider)
    g.model_patcher = model
    g.model_options = model.model_options

    # sample() prepares inner_model from model_patcher. Never keep a stale
    # inner_model from the incoming guider, or the patch would be bypassed.
    if hasattr(g, "inner_model"):
        try:
            delattr(g, "inner_model")
        except Exception:
            pass

    return g, True


def _trim_sigmas_by_strength(sigmas, denoise_strength):
    if not isinstance(sigmas, torch.Tensor) or sigmas.ndim != 1 or sigmas.numel() < 2:
        raise ValueError(
            f"Expected SIGMAS to be a 1D torch.Tensor with at least 2 values, got {type(sigmas)} shape={getattr(sigmas, 'shape', None)}"
        )

    strength = float(denoise_strength)
    strength = max(0.0, min(1.0, strength))

    total_values = int(sigmas.numel())
    total_intervals = total_values - 1

    if strength >= 1.0:
        return sigmas, 0, total_values, total_intervals, total_intervals

    # Keep only the final portion of the incoming schedule.
    # Minimum is 1 interval => 2 sigma values.
    kept_intervals = max(1, int(math.ceil(total_intervals * max(strength, 1e-8))))
    start_index = max(0, total_intervals - kept_intervals)
    trimmed = sigmas[start_index:].clone()
    return trimmed, start_index, int(trimmed.numel()), total_intervals, kept_intervals


class LTXOverlapChunkV2VRefinerSigmasV4:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "noise": ("NOISE",),
                "guider": ("GUIDER",),
                "sampler": ("SAMPLER",),
                "sigmas": ("SIGMAS",),
                "latent_image": ("LATENT",),
                "chunk_latent_frames": (
                    "INT",
                    {
                        "default": 8,
                        "min": 2,
                        "max": 512,
                        "step": 1,
                        "tooltip": "Chunk length in latent timesteps (T dimension of [B,C,T,H,W]).",
                    },
                ),
                "overlap_latent_frames": (
                    "INT",
                    {
                        "default": 2,
                        "min": 0,
                        "max": 256,
                        "step": 1,
                        "tooltip": "Overlap between neighboring chunks in latent timesteps.",
                    },
                ),
                "denoise_strength": (
                    "FLOAT",
                    {
                        "default": 1.0,
                        "min": 0.0,
                        "max": 1.0,
                        "step": 0.01,
                        "tooltip": "Uses only the final portion of the incoming sigma schedule. 1.0 = full schedule, 0.25 = roughly final quarter.",
                    },
                ),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xFFFFFFFFFFFFFFFF}),
                "seed_mode": (
                    ["same", "increment_per_chunk"],
                    {
                        "default": "increment_per_chunk",
                        "tooltip": "Controls the seed passed into the chunk sampler and, when possible, the NOISE object seed.",
                    },
                ),
                "blend_curve": (
                    ["linear", "smoothstep"],
                    {"default": "linear"},
                ),
            },
            "optional": {
                "model": ("MODEL", {
                    "tooltip": "Optional patched MODEL (FaceID/reference/model hooks). Replaces the model inside the incoming GUIDER while preserving its conditioning and CFG."
                }),
            },
        }

    RETURN_TYPES = ("LATENT", "STRING")
    RETURN_NAMES = ("latent", "report")
    FUNCTION = "refine"
    CATEGORY = "LTX/Video"

    def refine(
        self,
        noise,
        guider,
        sampler,
        sigmas,
        latent_image,
        chunk_latent_frames,
        overlap_latent_frames,
        denoise_strength,
        seed,
        seed_mode,
        blend_curve,
        model=None,
    ):
        if not _is_video_latent(latent_image):
            got = tuple(getattr(latent_image.get("samples", None), "shape", [])) if isinstance(latent_image, dict) else type(latent_image)
            raise ValueError(
                f"LTX Overlap-Chunk V2V Refiner (Sigmas) expects a video LATENT dict with samples [B,C,T,H,W]. Got {got}."
            )

        z = latent_image["samples"]
        batch, channels, total_t, height, width = [int(x) for x in z.shape]
        decoded_frames = _decoded_frame_count_from_latent(total_t)

        trimmed_sigmas, start_index, used_sigma_values, total_intervals, kept_intervals = _trim_sigmas_by_strength(sigmas, denoise_strength)

        sampling_guider, model_override = _guider_with_model(guider, model)

        chunk_size = int(chunk_latent_frames)
        overlap = int(overlap_latent_frames)
        if chunk_size <= overlap:
            raise ValueError("chunk_latent_frames must be greater than overlap_latent_frames")

        starts = _build_chunk_starts(total_t, chunk_size, overlap)
        if len(starts) == 0:
            raise ValueError("No chunks were generated")

        device = z.device
        dtype = z.dtype
        accum = torch.zeros_like(z)
        weight_accum = torch.zeros((1, 1, total_t, 1, 1), device=device, dtype=dtype)

        reports = []

        for idx, start_t in enumerate(starts):
            end_t = min(total_t, start_t + chunk_size)
            this_len = int(end_t - start_t)
            is_first = idx == 0
            is_last = idx == (len(starts) - 1)

            prev_end = starts[idx - 1] + chunk_size if idx > 0 else None
            next_start = starts[idx + 1] if idx + 1 < len(starts) else None
            left_overlap = (prev_end - start_t) if prev_end is not None else 0
            right_overlap = (end_t - next_start) if next_start is not None else 0
            left_overlap = max(0, min(this_len, int(left_overlap)))
            right_overlap = max(0, min(this_len, int(right_overlap)))

            latent_chunk = _slice_latent(latent_image, start_t, end_t)
            chunk_seed = int(seed) if seed_mode == "same" else int(seed) + idx
            noise_tensor = _prepare_noise_for_chunk(noise, latent_chunk, start_t, end_t, chunk_seed)
            noise_mask = latent_chunk.get("noise_mask", None)

            refined_z = _run_guider_sample(
                guider=sampling_guider,
                noise_tensor=noise_tensor,
                latent_tensor=latent_chunk["samples"],
                sampler=sampler,
                sigmas=trimmed_sigmas,
                noise_mask=noise_mask,
                chunk_seed=chunk_seed,
            )

            if getattr(refined_z, "ndim", 0) != 5:
                raise ValueError(f"Chunk sampler returned unexpected shape {tuple(refined_z.shape)}")
            if int(refined_z.shape[2]) != this_len:
                raise ValueError(
                    f"Chunk sampler changed temporal length from {this_len} to {int(refined_z.shape[2])}."
                )

            blend_device = accum.device
            blend_dtype = accum.dtype
            refined_device_before = str(refined_z.device)

            refined_z = refined_z.to(device=blend_device, dtype=blend_dtype)

            weights_1d = _make_blend_weights(
                this_len,
                left_overlap,
                right_overlap,
                is_first,
                is_last,
                device=blend_device,
                dtype=blend_dtype,
                curve=blend_curve,
            )
            weights = weights_1d.view(1, 1, this_len, 1, 1).to(device=blend_device, dtype=blend_dtype)

            contribution = (refined_z * weights).to(device=blend_device, dtype=blend_dtype)
            acc_slice = accum[:, :, start_t:end_t, :, :]
            acc_slice.copy_(acc_slice + contribution)

            wa_slice = weight_accum[:, :, start_t:end_t, :, :]
            w_for_accum = weights.to(device=weight_accum.device, dtype=weight_accum.dtype)
            wa_slice.copy_(wa_slice + w_for_accum)

            reports.append(
                f"chunk{idx}: T[{start_t}:{end_t}] len={this_len} left_overlap={left_overlap} right_overlap={right_overlap} "
                f"seed={chunk_seed} sampled_device={refined_device_before}->{refined_z.device} "
                f"accum={accum.device} weights={weights.device} weight_accum={weight_accum.device}"
            )

        eps = torch.tensor(1e-6, device=weight_accum.device, dtype=weight_accum.dtype)
        out_z = accum / torch.clamp(weight_accum, min=eps)

        out_latent = copy.copy(latent_image)
        out_latent["samples"] = out_z

        report = (
            f"LTX Overlap-Chunk V2V Refiner (Sigmas v4) | input_latent={_latent_shape_string(latent_image)} | decoded_frames≈{decoded_frames} | "
            f"sigmas_in={int(sigmas.numel())} values/{int(sigmas.numel()-1)} intervals | "
            f"denoise_strength={float(denoise_strength):.3f} | sigma_start_index={start_index} | "
            f"sigmas_used={used_sigma_values} values/{kept_intervals} intervals | "
            f"chunk_latent_frames={chunk_size} | overlap_latent_frames={overlap} | chunks={len(starts)} | "
            f"seed_mode={seed_mode} | blend_curve={blend_curve} | "
            f"model_override={'yes' if model_override else 'no'} || " + " ; ".join(reports)
        )

        print("[LTX Overlap-Chunk V2V Refiner (Sigmas v4)]", report)
        return (out_latent, report)


NODE_CLASS_MAPPINGS = {
    "LTXOverlapChunkV2VRefinerSigmasV4": LTXOverlapChunkV2VRefinerSigmasV4,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "LTXOverlapChunkV2VRefinerSigmasV4": "LTX Overlap-Chunk V2V Refiner (Sigmas v4 + MODEL)",
}
