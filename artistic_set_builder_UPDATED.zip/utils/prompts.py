"""
Pure prompt-assembly helpers (no node classes, no relative imports).

Shared by the node pack (inside ComfyUI) and the offline scripts. Everything
here is a plain function on plain data so it can be imported from anywhere.
"""

DEFAULT_QUALITY = (
    "photorealistic, professional erotic photography, beautiful natural skin "
    "texture, elegant composition, sharp focus, 8k"
)

# named quality presets — used by ASB Set Plan's dropdown; each expands to a
# full quality string. Users can still override with quality_custom.
QUALITY_PRESETS = {
    "default": DEFAULT_QUALITY,
    "editorial": (
        "editorial photography, natural skin texture, candid and effortless, "
        "sharp focus, medium format look"
    ),
    "studio": (
        "studio photography, softbox lighting, clean background, high detail, "
        "sharp focus"
    ),
    "film": (
        "35mm film photography, natural grain, soft muted tones, cinematic"
    ),
    "black & white": (
        "black and white fine art photography, high contrast, timeless film grain"
    ),
    "ultra detail": (
        "hyper detailed, ultra realistic, 8k, sharp focus, professional retouching"
    ),
    "clean minimal": (
        "clean minimal composition, natural light, soft focus, airy"
    ),
    "metart": (
        "visible skin pores and natural texture, subsurface scattering, "
        "shallow depth of field, 85mm portrait perspective, sharp eyes, soft background"
    ),
    "sensual editorial": (
        "sensual editorial photography, warm natural light, soft shadows along curves, "
        "Kodak Portra-like skin tones, visible pores, gentle film grain, "
        "magazine-quality composition, 85mm f/1.8 look"
    ),
}


def resolve_quality(quality=None, quality_custom=""):
    """Resolve a quality dropdown choice (or raw string) + custom override."""
    if quality_custom and quality_custom.strip():
        return quality_custom.strip()
    if quality and quality in QUALITY_PRESETS:
        return QUALITY_PRESETS[quality]
    if quality and quality.strip():
        return quality.strip()
    return DEFAULT_QUALITY


STYLE_PRESETS = {
    "custom": {
        "positive": "",
        "negative": "",
    },
    "natural editorial": {
        "positive": "natural editorial photography, candid and effortless, airy muted tones, soft window light",
        "negative": "harsh flash, oversaturated colors, heavy retouching",
    },
    "studio glam": {
        "positive": "studio glamour photography, dramatic softbox lighting, glowing skin, elegant high fashion styling",
        "negative": "natural daylight, harsh shadows, casual setting",
    },
    "black and white": {
        "positive": "black and white fine-art photography, high contrast, timeless film grain",
        "negative": "color, oversaturated, vivid hues",
    },
    "soft boudoir": {
        "positive": "intimate boudoir photography, moody warm tones, low-key lighting, silk and lace textures",
        "negative": "harsh lighting, clinical setting, office or kitchen background",
    },
    "golden hour outdoor": {
        "positive": "golden hour outdoor photography, warm sunlight flare, sun-kissed skin, shallow depth of field",
        "negative": "indoor setting, artificial lighting, gray overcast sky",
    },
    "night neon": {
        "positive": "night photography, neon city lights bokeh, cinematic teal and magenta grade, moody atmosphere",
        "negative": "daylight, natural window light, bright clean background",
    },
    "metart natural": {
        "positive": "fine art erotic photography, natural unretouched skin, candid confident presence, body as elegant line, intimate refined composition",
        "negative": "ugly pose, stiff mannequin posture, exaggerated grimace, heavy makeup, plastic airbrushed skin, oversaturated, harsh on-camera flash, fish-eye, text, watermark, extra limbs, deformed hands",
    },
    "sensual soft": {
        "positive": "sensual softcore editorial, warm window light, soft shadow on curves, relaxed confident gaze, natural skin sheen, intimate bedroom mood, refined erotic composition",
        "negative": "stiff pose, blank expression, plastic skin, harsh flash, cluttered background, text, watermark, extra limbs",
    }
}

# level -> negative additions that stop the model from hallucinating
# leftover/extra clothing at higher undress levels.
LEVEL_NEGATIVES = {
    "level_0": "",
    "level_1": "",
    "level_2": "extra outer garment, stray fabric not part of current outfit",
    "level_3": "extra clothing, stray fabric, fully covering underwear when exposed",
    "level_4": "any clothing, underwear, bra, panties, stray fabric, cropped feet, stiff mannequin, closed legs when pose is open, hidden hands when fingering",
}


# phase_1..phase_5 <-> level_0..level_4 (the undress levels)
LEVEL_TO_PHASE = {"level_0": "phase_1", "level_1": "phase_2", "level_2": "phase_3",
                  "level_3": "phase_4", "level_4": "phase_5"}


def phase_key_for_level(level):
    return LEVEL_TO_PHASE.get(level or "level_0", "phase_1")




def visible_body_regions(level="level_0", framing_ref="", piece_prompt="", chest_exposed=False, groin_exposed=False, midriff_exposed=False):
    """Which body regions are likely visible given clothing exposure + framing + pose.
    Used to gate piercings/tattoos so nipple bars do not appear under a closed dress.
    """
    fr = (framing_ref or "").lower()
    pose = (piece_prompt or "").lower()
    lvl = (level or "level_0").lower()

    # Always assume face/ears unless extreme crop on lower body only
    regions = {"face", "ears", "nose", "hair"}

    tight_face = any(k in fr for k in ("close_up", "extreme_close", "detail_crop")) and "full" not in fr
    lower_only = any(k in fr for k in ("tight_crop_torso",)) and "face" not in pose

    if tight_face:
        return regions  # face/ears only

    regions.update({"shoulder", "arms", "wrist", "hands", "collarbone"})

    # Midriff / navel / ribs — need open midriff or late undress
    if midriff_exposed or chest_exposed or lvl in ("level_2", "level_3", "level_4"):
        regions.update({"midriff", "navel", "ribs", "hip"})

    if chest_exposed or lvl in ("level_3", "level_4"):
        regions.update({"chest", "nipples", "sternum", "underbust"})

    if groin_exposed or lvl == "level_4":
        regions.update({"hip", "thigh", "legs", "groin"})

    # Full body / wide shows ankles and more
    if any(k in fr for k in ("full_body", "wide", "negative_space", "environmental", "medium_full")):
        regions.update({"legs", "thigh", "ankle", "feet", "back", "spine", "lower_back"})

    # Pose cues
    if any(k in pose for k in ("from behind", "back to camera", "looking over", "all fours", "prone")):
        regions.update({"back", "spine", "lower_back", "shoulder"})
    if any(k in pose for k in ("profile", "side")):
        regions.update({"shoulder", "ribs"})
    if any(k in pose for k in ("feet", "ankle", "toes")):
        regions.update({"ankle", "feet", "legs"})
    if lower_only:
        regions.discard("face")
        regions.discard("ears")
        regions.discard("nose")

    return regions


def filter_accessory_parts(parts, visible):
    """Keep only accessory part lines whose requires ⊆ visible (or requires empty)."""
    out = []
    for part in parts or []:
        req = part.get("requires") or []
        if not req:
            if part.get("prompt"):
                out.append(part["prompt"])
            continue
        # visible if ANY required region is visible (navel needs navel OR midriff)
        if any(r in visible for r in req):
            pr = (part.get("prompt") or "").strip()
            if pr:
                out.append(pr)
    return out


def resolve_catalog_parts(folder, item_id):
    """Load parts list for a piercing/tattoo catalog id."""
    try:
        from .database import load_json
        cat = load_json(folder, "catalog") or {}
        for it in cat.get("items") or []:
            if it.get("id") == item_id:
                if it.get("parts"):
                    return it["parts"]
                pr = (it.get("prompt") or "").strip()
                return [{"prompt": pr, "requires": it.get("requires") or []}] if pr else []
    except Exception:
        pass
    return []

def _piercing_tattoo_lines(data, include_piercings=False, include_tattoos=False, tattoo_style="",
                            piercing_override="", tattoo_override="",
                            visible=None, piercing_id="", tattoo_id=""):
    """Optional accessory lines, gated by which body regions are visible.

    Nipple piercings only when chest/nipples visible; navel only when midriff
    visible; face piercings when face in frame; tattoos same rules.
    """
    if visible is None:
        visible = {"face", "ears", "nose", "hair", "shoulder", "arms", "wrist", "hands", "collarbone"}
    bits = []

    # Piercings: prefer catalog parts by id when available
    if include_piercings or piercing_override or piercing_id:
        parts = []
        if piercing_id and piercing_id != "none":
            parts = resolve_catalog_parts("piercings", piercing_id)
        if not parts and piercing_override:
            # override is free text — include only if we cannot gate (show as-is when any body shown)
            if "face" in visible or "chest" in visible or "midriff" in visible:
                bits.append(piercing_override.strip())
        elif parts:
            bits.extend(filter_accessory_parts(parts, visible))
        elif include_piercings:
            pier = data.get("piercings") or {}
            line = (pier.get("prompt") or "").strip()
            # crude keyword gate on model default prompt
            if line:
                low = line.lower()
                ok = False
                if "nipple" in low and ("nipples" in visible or "chest" in visible):
                    ok = True
                if "navel" in low and ("navel" in visible or "midriff" in visible):
                    ok = True
                if any(k in low for k in ("ear", "septum", "nose")) and ("ears" in visible or "face" in visible):
                    ok = True
                if ok:
                    bits.append(line)

    if include_tattoos or tattoo_override or tattoo_id:
        parts = []
        if tattoo_id and tattoo_id != "none":
            parts = resolve_catalog_parts("tattoos", tattoo_id)
        if not parts and tattoo_override:
            if len(visible) > 4:  # not face-only
                bits.append(tattoo_override.strip())
        elif parts:
            bits.extend(filter_accessory_parts(parts, visible))
        elif include_tattoos:
            tat = data.get("tattoos") or {}
            opts = tat.get("options") or {}
            if tattoo_style and tattoo_style in opts and opts[tattoo_style]:
                line = opts[tattoo_style]
            else:
                line = (tat.get("prompt") or "").strip()
            if line:
                low = line.lower()
                ok = False
                if any(k in low for k in ("rib", "navel", "hip", "sternum", "underbust", "underboob")) and (
                    "midriff" in visible or "chest" in visible or "ribs" in visible
                ):
                    ok = True
                if any(k in low for k in ("spine", "back", "shoulder blade")) and "back" in visible:
                    ok = True
                if "ankle" in low and "ankle" in visible:
                    ok = True
                if "thigh" in low and ("thigh" in visible or "legs" in visible):
                    ok = True
                if "wrist" in low and "wrist" in visible:
                    ok = True
                if "ear" in low and "ears" in visible:
                    ok = True
                if "collarbone" in low and ("collarbone" in visible or "chest" in visible):
                    ok = True
                if ok:
                    bits.append(line)

    # de-dupe
    seen = set()
    out = []
    for b in bits:
        k = b.lower()
        if k not in seen:
            seen.add(k)
            out.append(b)
    return ", ".join(out)


def build_model_prompt(data, detail_level="standard", level=None, include_piercings=False, include_tattoos=False, tattoo_style="", piercing_override="", tattoo_override="", visible=None, piercing_id="", tattoo_id=""):
    """
    Turn a model JSON dict into a prompt string + identity token.

    detail_level:
      standard - face, hair, body type, vibe (classic behavior)
      detailed - additionally includes skin, makeup and the body-detail blocks
      minimal  - name, age, vibe only (safe for SFW output)

    level (optional): if the model defines `prompt_model_description` with
    phase-wise text (phase_1..phase_5), the description for the matching
    phase is used instead of the static assembly — so the model's own wording
    can evolve as the shoot progresses (phase_1 = fully dressed, phase_5 =
    fully undressed). Empty phase text falls back to the static build.
    """
    phase_desc = data.get("prompt_model_description") or {}
    if level and isinstance(phase_desc, dict):
        key = phase_key_for_level(level)
        ph = (phase_desc.get(key) or "").strip()
        if ph:
            # keep identity token; do not double-prefix name if phase text already starts with it
            name = (data.get("name") or "").strip()
            token = data.get("identity_token") or name
            if name and not ph.lower().startswith(name.lower()):
                ph = f"{name}, {ph}"
            extra = _piercing_tattoo_lines(data, include_piercings, include_tattoos, tattoo_style, piercing_override, tattoo_override, visible=visible, piercing_id=piercing_id, tattoo_id=tattoo_id)
            if extra:
                ph = f"{ph} {extra}".strip()
            return ph, token

    # ---- static assembly (unchanged behavior when no phase text) ----
    parts = []
    if data.get("name"):
        parts.append(str(data["name"]))
    if data.get("age"):
        parts.append(str(data["age"]))
    if data.get("body_type"):
        parts.append(data["body_type"])

    hair = data.get("hair", {})
    if isinstance(hair, dict):
        h = " ".join(filter(None, [hair.get("length"), hair.get("style"),
                                   hair.get("color"), "hair"]))
        if h.strip():
            parts.append(h.strip())

    face = data.get("face", {})
    if isinstance(face, dict):
        fparts = []
        if face.get("smile"):
            fparts.append(f"{face['smile']} smile")
        if face.get("eyes"):
            fparts.append(f"{face['eyes']} eyes")
        if face.get("freckles") and face["freckles"] not in ("none", ""):
            fparts.append(face["freckles"])
        if detail_level != "minimal" and face.get("makeup"):
            fparts.append(f"{face['makeup']} makeup")
        if fparts:
            parts.append(", ".join(fparts))

    if detail_level == "detailed":
        extra = []
        skin = data.get("skin", {})
        if isinstance(skin, dict):
            s = " ".join(filter(None, [skin.get("tone"), skin.get("texture")]))
            if s.strip():
                extra.append(f"{s} skin")
        for key in ("breasts", "pussy", "ass"):
            block = data.get(key, {})
            if isinstance(block, dict):
                for field in ("size", "shape", "type", "hair", "nipples",
                              "labia", "asshole"):
                    v = block.get(field)
                    if v and v not in ("none", ""):
                        extra.append(str(v))
        if extra:
            parts.append(", ".join(extra))

    if data.get("overall_vibe"):
        parts.append(data["overall_vibe"])

    extra = _piercing_tattoo_lines(data, include_piercings, include_tattoos, tattoo_style, piercing_override, tattoo_override, visible=visible, piercing_id=piercing_id, tattoo_id=tattoo_id)
    if extra:
        parts.append(extra)

    identity_token = data.get("identity_token") or str(data.get("name") or "")
    return ", ".join(parts), identity_token


def assemble_prompt(model_prompt, clothing_phrases, prompt_piece, lighting,
                    style, quality, level="level_0", camera_technical="",
                    negative_hints="", auto_negative=True,
                    clothing_off_neg="", scene_phrase="", expression_text=""):
    """Combine all prompt parts -> (final_prompt, negative_prompt).

    Order (anchors scene first to reduce location drift):
      1. scene / location + zone (detailed environment)
      2. model identity + anatomy phase
      3. clothing still on the body (omit when nude)
      4. pose / action
      5. lighting
      6. style + quality + camera

    clothing_off_neg: negatives for garments OFF the body (ghost clothing).
    scene_phrase: location overall + zone description, props, place cues.
    """
    style_meta = STYLE_PRESETS.get(style, STYLE_PRESETS["custom"])
    style_pos = style_meta["positive"]
    style_neg = style_meta["negative"]

    q = (quality or "").strip()
    if q and style_pos:
        style_tokens = set(style_pos.lower().replace(",", " ").split())
        q_tokens = set(q.lower().replace(",", " ").split())
        if style_tokens and len(q_tokens & style_tokens) / max(len(q_tokens), 1) > 0.45:
            q = ""
    # Nude / late undress: model anatomy then composition pose (reference-style prompts)
    # Dressed: scene → model → clothes → pose
    is_nude = (level or "").lower() in ("level_3", "level_4") and not (clothing_phrases or "").strip()
    expr = (expression_text or "").strip()
    if is_nude:
        parts = [p.strip() for p in (
            scene_phrase,
            model_prompt,
            expr,
            prompt_piece,
            lighting,
            style_pos, q, camera_technical,
        ) if p and p.strip()]
    else:
        parts = [p.strip() for p in (
            scene_phrase,
            model_prompt,
            clothing_phrases,
            expr,
            prompt_piece,
            lighting,
            style_pos, q, camera_technical,
        ) if p and p.strip()]

    neg_parts = []
    if clothing_off_neg and clothing_off_neg.strip():
        neg_parts.append(clothing_off_neg.strip())
    if auto_negative and level in LEVEL_NEGATIVES:
        neg_parts.append(LEVEL_NEGATIVES[level])
    if style_neg:
        neg_parts.append(style_neg)
    if negative_hints and negative_hints.strip():
        neg_parts.append(negative_hints.strip())
    # de-dupe while preserving order
    seen = set()
    uniq = []
    for p in neg_parts:
        for part in p.split(","):
            t = part.strip()
            if t and t.lower() not in seen:
                seen.add(t.lower())
                uniq.append(t)
    negative = ", ".join(uniq)

    return ", ".join(parts), negative
