/**
 * AI ASB Photoset Browser -- Visual Browser v4
 * ======================================
 * 4 tabs: Locations, Outfits, Subjects, Piercings
 * Features: tags, fabric/color/style filters, CRUD (edit/delete/add),
 *           active/inactive toggle, multi-select piercings.
 */
import { app } from "../../../scripts/app.js";
import { api } from "../../../scripts/api.js";
import { ComfyDialog, $el } from "../../../scripts/ui.js";

const DIALOG_ID = "ps-v2-browser-dialog";
const CSS_ID = "ps-v2-browser-css";
let catalogCache = null;
let _showInactive = false;

function loadStylesheet() {
  if (document.getElementById(CSS_ID)) return;
  const link = document.createElement("link");
  link.id = CSS_ID;
  link.rel = "stylesheet";
  link.href = new URL("./photoset_browser.css", import.meta.url).href;
  document.head.appendChild(link);
}
function widgetByName(node, name) {
  return node.widgets?.find((w) => w.name === name);
}
function setWidgetValue(node, name, value) {
  const w = widgetByName(node, name);
  if (!w) return;
  w.value = value;
  w.callback?.(value);
}
function normalize(v) {
  return String(v || "").toLowerCase();
}
async function fetchCatalog(force) {
  if (catalogCache && !force) return catalogCache;
  const resp = await api.fetchApi("/asb/catalog" + (force ? "?refresh=1" : ""));
  catalogCache = await resp.json();
  return catalogCache;
}

class PhotosetBrowserDialog extends ComfyDialog {
  constructor() {
    super();
    this.activeTab = "locations";
    this.locSub = "all";
    this.outfitStyleFilter = "all";
    this.outfitFabricFilter = "all";
    this.subjFilter = "all";
    this.pierceFilter = "all";
    this.locSort = "default";
    this.catalog = { outfits: [], locations: [], subjects: [], piercings: [], totals: {}, location_groups: [], style_families: [], all_fabrics: [], all_colors: [], warnings: [] };
    this._node = null;
    this._loading = true;
    this._search = { locations: "", outfits: "", subjects: "", piercings: "" };
    this._cardNodes = { locations: {}, outfits: {}, subjects: {}, piercings: {} };
    this._editModal = null;
    this._editingItem = null;
    this._editingKind = null;

    this._dialogKeyHandler = (e) => {
      if (e.key === "Escape") { this._closeEditModal(); if (!this._editModalVisible) this._close(); return; }
      if (e.key === "/" && document.activeElement !== this.searchInput && !this._editModalVisible) {
        e.preventDefault(); this.searchInput.focus(); this.searchInput.select();
      }
    };

    this._editModalVisible = false;

    this.element = $el("div", { id: DIALOG_ID, parent: document.body, style: { alignItems: "center", background: "rgba(0, 0, 0, 0.68)", bottom: "0", display: "none", justifyContent: "center", left: "0", position: "fixed", right: "0", top: "0", zIndex: "10000" } }, [
      $el("div.ps-panel", [
        $el("div.ps-hdr", [
          $el("div", [ $el("h2", "ASB Photoset Browser"), $el("p", [
            $el("kbd", "/"), " search  ", $el("kbd", "Esc"), " close  ", $el("kbd", "⏎"), " confirm",
            ...([$el("kbd", "E"), " edit  ", $el("kbd", "⌫"), " delete"])
          ]) ]),
          $el("button.ps-close", { textContent: "\u00d7", onclick: () => this._close() }),
        ]),
        $el("div.ps-toolbar", [
          this.searchInput = $el("input.ps-search", { type: "search", placeholder: "Search...", oninput: () => { this._saveSearch(); this._renderGrid(); }, onkeydown: (e) => this._onGlobalKey(e) }),
          $el("div.ps-toolbar-right", [
            $el("button.ps-add-btn", { textContent: "+ Add", onclick: () => this._openEditModal(null), title: "Add new item" }),
            this.countEl = $el("span.ps-count", ""),
          ]),
        ]),
        this.chipsEl = $el("div.ps-chips"),
        this.filtersEl = $el("div.ps-filters"),
        $el("div.ps-tabs", [
          this._tabBtn("locations", "\ud83d\udccd Location"),
          this._tabBtn("outfits", "\ud83d\udc57 Outfit"),
          this._tabBtn("subjects", "\ud83d\udc64 Subject"),
          this._tabBtn("piercings", "\ud83d\udc8e Piercings"),
        ]),
        this.subtabsEl = $el("div.ps-subtabs"),
        this.timelineEl = $el("div.ps-timeline"),
        $el("div.ps-body", [
          this.gridEl = $el("div.ps-grid"),
          $el("div.ps-preview", [
            this.previewImageEl = $el("div.ps-preview-img", [ $el("div.ps-preview-fb", "Hover an item") ]),
            this.previewTitleEl = $el("h3", ""),
            this.previewMetaEl = $el("p", ""),
            this.previewTagsEl = $el("div.ps-preview-tags", ""),
            this.previewDetailEl = $el("div.ps-preview-detail", ""),
            this.confirmButton = $el("button.ps-confirm", { onclick: () => this._confirm() }, [
              $el("span", "\u2714 Generate Photoset"),
              this.confirmNameEl = $el("span.ps-confirm-name", ""),
            ]),
          ]),
        ]),
      ]),
      this._editModalEl = $el("div.ps-edit-overlay", { style: { display: "none" } }, [
        $el("div.ps-edit-panel", [
          $el("div.ps-edit-hdr", [
            $el("h3", "Edit Item"),
            $el("button.ps-close", { textContent: "\u00d7", onclick: () => this._closeEditModal() }),
          ]),
          $el("div.ps-edit-body", [
            this._editNameInput = $el("input.ps-edit-input", { placeholder: "Name", type: "text" }),
            this._editDescInput = $el("textarea.ps-edit-textarea", { placeholder: "Description / prefix text", rows: 5 }),
            this._editTagsInput = $el("input.ps-edit-input", { placeholder: "Tags (comma-separated)", type: "text" }),
            this._editActiveToggle = $el("label.ps-edit-toggle", [
              $el("input", { type: "checkbox", checked: true, onchange: (e) => { this._editActiveValue = e.target.checked; } }),
              " Active (visible in browser)"
            ]),
          ]),
          $el("div.ps-edit-actions", [
            $el("button.ps-edit-delete", { textContent: "Delete", onclick: () => this._deleteCurrentItem() }),
            $el("button.ps-edit-save", { textContent: "Save", onclick: () => this._saveCurrentItem() }),
          ]),
        ]),
      ]),
    ]);
    this._editActiveValue = true;
  }

  _tabBtn(tab, label) {
    return $el("button.ps-tab", { dataset: { tab }, onclick: () => this._switchTab(tab) }, [
      document.createTextNode(label), $el("span.ps-tab-badge", ""), $el("span.ps-tab-dot"),
    ]);
  }

  static launch(node) {
    loadStylesheet();
    if (!PhotosetBrowserDialog._instance) PhotosetBrowserDialog._instance = new PhotosetBrowserDialog();
    const d = PhotosetBrowserDialog._instance;
    d._node = node;
    d._shootApi = node?.__asbShootApi || null;
    d._loadSelectionsFromNode();
    d._open();
  }

  /** Open from ASB Shoot Plan editor — selections write back into plan state. */
  static launchForShootPlan(api) {
    loadStylesheet();
    if (!PhotosetBrowserDialog._instance) PhotosetBrowserDialog._instance = new PhotosetBrowserDialog();
    const d = PhotosetBrowserDialog._instance;
    d._shootApi = api;
    const st = api?.st || {};
    // fake node widgets so load/confirm paths still work
    d._node = {
      widgets: [
        { name: "model_id", value: st.model || "" },
        { name: "location_id", value: st.location || "" },
        { name: "clothing_id", value: st.clothing || "" },
        { name: "piercing_ids", value: (st.piercing && st.piercing !== "none") ? st.piercing : "" },
        { name: "style", value: st.style || "" },
        { name: "quality", value: st.quality || "" },
      ],
      setDirtyCanvas() {},
      __asbShootApi: api,
    };
    d._loadSelectionsFromNode();
    d._open();
  }

  _loadSelectionsFromNode() {
    const n = this._node;
    this._selLoc = (widgetByName(n, "location_id")?.value || "").trim();
    this._selOut = (widgetByName(n, "clothing_id")?.value || widgetByName(n, "outfit_id")?.value || "").trim();
    this._selSub = (widgetByName(n, "model_id")?.value || widgetByName(n, "subject_id")?.value || "").trim();
    this.selectedPiercingId = (widgetByName(n, "piercing_ids")?.value || widgetByName(n, "piercing_id")?.value || "").trim();
  }

  async _open() {
    this.element.style.display = "flex";
    document.addEventListener("keydown", this._dialogKeyHandler);
    this._loading = true; this._showSkeletons();
    this.catalog = await fetchCatalog();
    this._loading = false;
    this._renderTabs(); this._renderSubtabs(); this._renderFilters(); this._renderGrid(); this._renderChips(); this._renderConfirm();
    this.searchInput.focus();
  }

  _close() {
    document.removeEventListener("keydown", this._dialogKeyHandler);
    try { localStorage.setItem("ps_v2_last_loc", this._selLoc); localStorage.setItem("ps_v2_last_out", this._selOut); localStorage.setItem("ps_v2_last_sub", this._selSub); } catch (_) {}
    this.element.style.display = "none";
  }

  _confirm() {
    if (this._node) {
      setWidgetValue(this._node, "location_id", this._selLoc);
      setWidgetValue(this._node, "clothing_id", this._selOut);
      setWidgetValue(this._node, "model_id", this._selSub);
      setWidgetValue(this._node, "piercing_ids", this.selectedPiercingId);
      this._node.setDirtyCanvas?.(true, true);
      this._node._asbRefreshSummary?.();
    }
    // Apply cast into Shoot Plan editor state
    const api = this._shootApi || this._node?.__asbShootApi;
    if (api && typeof api._asbApplyCast === "function") {
      const loc = (this.catalog.locations || []).find(x => x.id === this._selLoc);
      const ou = (this.catalog.outfits || []).find(x => x.id === this._selOut);
      const su = (this.catalog.subjects || []).find(x => x.id === this._selSub);
      // Shoot plan DATA uses model name / location id / clothing name
      // Prefer IDs that match /asb/data stems (artist_studio, beige_knit_..., amara)
      const locKey = (loc?.id || this._selLoc || "").replace(/^loc_/i, "");
      const clothKey = ou?.id || this._selOut || "";
      const modelKey = (su?.name || su?.id || this._selSub || "").toString().toLowerCase();
      api._asbApplyCast({
        model: modelKey,
        location: locKey || loc?.name || "",
        clothing: clothKey || ou?.name || "",
        piercing: (this.selectedPiercingId || "none").split(",")[0] || "none",
        tattoo: "none",
      });
    }
    this._close();
  }

  _onGlobalKey(e) {
    if (e.key === "Escape") { this._closeEditModal(); if (!this._editModalVisible) this._close(); }
    if (e.key === "Enter" && !this._editModalVisible) this._confirm();
  }

  _switchTab(tab) {
    this.activeTab = tab; this.locSub = "all"; this.pierceFilter = "all"; this.outfitStyleFilter = "all"; this.outfitFabricFilter = "all";
    this._renderTabs(); this._renderSubtabs(); this._renderTimeline(); this._renderFilters(); this._renderGrid();
    this.searchInput.value = this._search[tab] || ""; this.searchInput.focus();
  }

  _saveSearch() { this._search[this.activeTab] = this.searchInput.value; }

  _selectedPiercings() { return (this.selectedPiercingId || "").split(",").filter(s => s.trim() && s !== "none"); }

  _renderTabs() {
    this.element.querySelectorAll(".ps-tab").forEach((btn) => {
      const tab = btn.dataset.tab;
      btn.classList.toggle("active", tab === this.activeTab);
      const badge = btn.querySelector(".ps-tab-badge");
      if (badge) {
        const active = (arr, field) => (arr || []).filter(i => i[field] !== false).length;
        if (tab === "locations") badge.textContent = active(this.catalog.locations, "active");
        else if (tab === "outfits") badge.textContent = active(this.catalog.outfits, "active");
        else if (tab === "subjects") badge.textContent = active(this.catalog.subjects, "active");
        else if (tab === "piercings") badge.textContent = (this.catalog.piercings || []).length;
      }
      const hasSel = (tab === "locations" && this._selLoc) || (tab === "outfits" && this._selOut) || (tab === "subjects" && this._selSub) || (tab === "piercings" && this.selectedPiercingId);
      btn.classList.toggle("has-sel", hasSel);
    });
  }

  _renderSubtabs() {
    this.subtabsEl.innerHTML = "";
    if (this.activeTab === "locations") {
      this.subtabsEl.style.display = "flex";
      const mk = (l,s) => { const b=$el("button.ps-subtab",{textContent:l,onclick:()=>{this.locSub=s;this._renderSubtabs();this._renderGrid();}}); if(this.locSub===s)b.classList.add("active"); this.subtabsEl.appendChild(b); };
      mk("All","all"); (this.catalog.location_groups||[]).forEach(g=>mk(g,g));
    } else if (this.activeTab === "piercings") {
      this.subtabsEl.style.display = "flex";
      ["All","👂 Ear","👃 Nose","💋 Face","⚲ Nipple","💎 Navel","✦ Surface"].forEach(label=>{
        const val = label.replace(/[^\w]/g,"").toLowerCase()||"all";
        const b=$el("button.ps-subtab",{textContent:label,onclick:()=>{this.pierceFilter=val;this._renderSubtabs();this._renderGrid();}});
        if((this.pierceFilter||"all")===val)b.classList.add("active"); this.subtabsEl.appendChild(b);
      });
    } else if (this.activeTab === "outfits") {
      this.subtabsEl.style.display = "flex";
      const mk = (l,v) => { const b=$el("button.ps-subtab",{textContent:l,onclick:()=>{this.outfitStyleFilter=v;this._renderSubtabs();this._renderFilters();this._renderGrid();}}); if(this.outfitStyleFilter===v)b.classList.add("active"); this.subtabsEl.appendChild(b); };
      mk("All","all");
      (this.catalog.style_families||[]).forEach(s => mk(s.charAt(0).toUpperCase()+s.slice(1), s));
    } else { this.subtabsEl.style.display = "none"; }
  }

  _renderTimeline() {
    this.timelineEl.innerHTML = "";
    if (this.activeTab !== "outfits") { this.timelineEl.classList.remove("show"); return; }
    const outfit = (this.catalog.outfits || []).find((o) => o.id === this._selOut);
    if (!outfit || !outfit.items || !outfit.items.length) { this.timelineEl.classList.remove("show"); return; }
    this.timelineEl.classList.add("show");
    const phasePct = {1:15,2:20,3:25,4:25,5:15};
    const items = [...outfit.items].sort((a,b)=>a.removalOrder-b.removalOrder);
    this.timelineEl.appendChild($el("div.ps-timeline-title",`Clothing arc — ${items.length} items`));
    items.forEach((item)=>{
      const row=$el("div.ps-timeline-row",[$el("div.ps-timeline-label",item.name)]);
      const bar=$el("div.ps-timeline-bar");
      const e=item.removalPhaseRange?.earliest||2, l=item.removalPhaseRange?.latest||3;
      for(let ph=1;ph<=5;ph++){ const s=$el("div.ps-timeline-seg"); s.style.width=(phasePct[ph]||15)+"%"; if(ph<e)s.classList.add("worn"); else if(ph>l)s.classList.add("removed"); else s.classList.add("trans"); bar.appendChild(s); }
      row.appendChild(bar); this.timelineEl.appendChild(row);
    });
  }

  _renderFilters() {
    this.filtersEl.innerHTML = ""; this.filtersEl.classList.remove("show");
    if (this.activeTab === "subjects") {
      this.filtersEl.classList.add("show");
      [["All","all"],["Blonde","blonde"],["Brunette","brunette"],["Redhead","redhead"]].forEach(([l,v])=>{const b=$el("button.ps-filt",{textContent:l,onclick:()=>{this.subjFilter=v;this._renderFilters();this._renderGrid();}});if((this.subjFilter||"all")===v)b.classList.add("active");this.filtersEl.appendChild(b);});
      this.filtersEl.appendChild($el("span",{style:{color:"#555",fontSize:"10px",margin:"0 2px"},textContent:"|"}));
      [["Blue eyes","blue_eyes"],["Green/Hazel","green_eyes"],["Brown/Dark","brown_eyes"]].forEach(([l,v])=>{const b=$el("button.ps-filt",{textContent:l,onclick:()=>{this.subjFilter=v;this._renderFilters();this._renderGrid();}});if((this.subjFilter||"all")===v)b.classList.add("active");this.filtersEl.appendChild(b);});
      this.filtersEl.appendChild($el("span",{style:{color:"#555",fontSize:"10px",margin:"0 2px"},textContent:"|"}));
      const tgl=$el("button.ps-filt",{textContent:_showInactive?"Hide inactive":"Show all",onclick:()=>{_showInactive=!_showInactive;this._renderFilters();this._renderGrid();}});
      if(_showInactive)tgl.classList.add("active");this.filtersEl.appendChild(tgl);
    }
    if (this.activeTab === "outfits") {
      this.filtersEl.classList.add("show");
      const m=(l,v)=>{const b=$el("button.ps-filt",{textContent:l,onclick:()=>{this.outfitFabricFilter=v;this._renderFilters();this._renderGrid();}});if(this.outfitFabricFilter===v)b.classList.add("active");this.filtersEl.appendChild(b);};
      m("All fabrics","all");
      (this.catalog.all_fabrics||[]).slice(0,8).forEach(f => m(f.charAt(0).toUpperCase()+f.slice(1), f));
      this.filtersEl.appendChild($el("span",{style:{color:"#555",fontSize:"10px",margin:"0 2px"},textContent:"|"}));
      const tgl=$el("button.ps-filt",{textContent:_showInactive?"Hide inactive":"Show all",onclick:()=>{_showInactive=!_showInactive;this._renderFilters();this._renderGrid();}});
      if(_showInactive)tgl.classList.add("active");this.filtersEl.appendChild(tgl);
    }
    if (this.activeTab === "locations") {
      this.filtersEl.classList.add("show");
      [["Group","default"],["A–Z","name"],["Most views","zones"]].forEach(([l,v])=>{const b=$el("button.ps-filt",{textContent:`Sort: ${l}`,onclick:()=>{this.locSort=v;this._renderFilters();this._renderGrid();}});if(this.locSort===v)b.classList.add("active");this.filtersEl.appendChild(b);});
      this.filtersEl.appendChild($el("span",{style:{color:"#555",fontSize:"10px",margin:"0 2px"},textContent:"|"}));
      const tgl=$el("button.ps-filt",{textContent:_showInactive?"Hide inactive":"Show all",onclick:()=>{_showInactive=!_showInactive;this._renderFilters();this._renderGrid();}});
      if(_showInactive)tgl.classList.add("active");this.filtersEl.appendChild(tgl);
    }
    if (this.activeTab === "piercings") {
      this.filtersEl.classList.add("show");
      this.filtersEl.appendChild($el("button.ps-filt",{textContent:`Selected: ${this._selectedPiercings().length}`,style:{cursor:"default"}}));
      this.filtersEl.appendChild($el("button.ps-filt",{textContent:"Clear all",onclick:()=>{this.selectedPiercingId="";this._renderFilters();this._renderGrid();this._renderChips();this._renderConfirm();this._renderTabs();}}));
    }
  }

  _filteredItems() {
    const q = normalize(this._search[this.activeTab] || "");
    if (this.activeTab === "outfits") {
      let items = this.catalog.outfits || [];
      if (!_showInactive) items = items.filter(o => o.active !== false);
      if (this.outfitStyleFilter !== "all") items = items.filter(o => (o.style_family || "classic") === this.outfitStyleFilter);
      if (this.outfitFabricFilter !== "all") items = items.filter(o => (o.fabrics || []).includes(this.outfitFabricFilter));
      return items.filter((o) => !q || normalize([o.id, o.name, (o.categories||[]).join(" "), (o.tags||[]).join(" "), (o.colors||[]).join(" ")].join(" ")).includes(q));
    }
    if (this.activeTab === "locations") {
      let items = this.catalog.locations || [];
      if (!_showInactive) items = items.filter(l => l.active !== false);
      items = this.locSub === "all" ? items : items.filter((l) => l.group === this.locSub);
      if (this.locSort === "name") items = [...items].sort((a, b) => a.name.localeCompare(b.name));
      else if (this.locSort === "zones") items = [...items].sort((a, b) => (b.zone_count || 0) - (a.zone_count || 0));
      return items.filter((l) => !q || normalize([l.id, l.name, l.group, (l.tags||[]).join(" ")].join(" ")).includes(q));
    }
    if (this.activeTab === "subjects") {
      let items = this.catalog.subjects || [];
      if (!_showInactive) items = items.filter(s => s.active !== false);
      if (this.subjFilter !== "all") { items = items.filter((s) => { const h = (s.hair_color || "").toLowerCase(); const e = (s.eye_color || "").toLowerCase(); if (this.subjFilter === "blonde") return h.includes("blond") || h.includes("ash") || h.includes("platinum"); if (this.subjFilter === "brunette") return h.includes("brown") || h.includes("dark") || h.includes("black") || h.includes("ebony"); if (this.subjFilter === "redhead") return h.includes("red") || h.includes("auburn") || h.includes("ginger") || h.includes("copper"); if (this.subjFilter === "blue_eyes") return e.includes("blue") || e.includes("steel") || e.includes("icy"); if (this.subjFilter === "green_eyes") return e.includes("green") || e.includes("hazel") || e.includes("emerald"); if (this.subjFilter === "brown_eyes") return e.includes("brown") || e.includes("dark") || e.includes("ebony") || e.includes("amber"); return true; }); }
      return items.filter((s) => !q || normalize([s.id, s.name, String(s.age || ""), s.hair_color||"", s.eye_color||"", s.nationality||"", (s.tags||[]).join(" ")].join(" ")).includes(q));
    }
    if (this.activeTab === "piercings") {
      let items = this.catalog.piercings || [];
      if (this.pierceFilter !== "all") { const lo = {ear:"ear",nose:"nose",face:"face",nipple:"nipple",navel:"navel",surface:"surface"}; const t = lo[this.pierceFilter] || this.pierceFilter; items = items.filter((p) => { const l = (p.location || "").toLowerCase(); if (t === "surface") return l === "surface" || l === "other"; return l === t || l.includes(t); }); }
      return items.filter((p) => p.id !== "none" && (!q || normalize([p.id, p.name, p.location, p.material].join(" ")).includes(q)));
    }
    return [];
  }

  _isSelected(item) {
    if (this.activeTab === "piercings") return this._selectedPiercings().includes(item.id);
    if (this.activeTab === "outfits") return item.id === this._selOut;
    if (this.activeTab === "locations") return item.id === this._selLoc;
    return item.id === this._selSub;
  }
  _kind() {
    if (this.activeTab === "outfits") return "outfit";
    if (this.activeTab === "locations") return "location";
    if (this.activeTab === "piercings") return "piercing";
    return "subject";
  }
  _subtitle(item) {
    if (this.activeTab === "outfits") {
      const parts = [`${item.item_count} items`];
      if (item.style_family) parts.push(item.style_family);
      if (item.fabrics?.length) parts.push(item.fabrics.slice(0,2).join(", "));
      return parts.join(" · ");
    }
    if (this.activeTab === "locations") return `${item.group} · ${item.zone_count || 0} views`;
    if (this.activeTab === "piercings") return `${item.location} · ${item.material}`;
    return `Age ${item.age || "?"}`;
  }

  _thumbImg(item, kind) {
    const img = document.createElement("img");
    img.src = item.thumbnail || `/asb/thumb/${kind}/${item.id}`;
    img.alt = item.name; img.loading = "lazy";
    img.onerror = () => { img.style.display = "none"; img.parentElement?.classList.add("no-thumb"); };
    img.onload = () => { img.parentElement?.classList.remove("no-thumb"); };
    return img;
  }

  _showSkeletons() { this.gridEl.innerHTML = ""; for (let i = 0; i < 6; i++) this.gridEl.appendChild($el("div.ps-card", [$el("div.ps-skel.ps-skel-thumb"), $el("div.ps-skel.ps-skel-name"), $el("div.ps-skel.ps-skel-sub")])); }

  _renderGrid() {
    if (this._loading) { this._showSkeletons(); return; }
    const items = this._filteredItems();
    this.gridEl.innerHTML = "";
    this.countEl.textContent = `${items.length} items`;
    this._cardNodes[this.activeTab] = {};
    if (!items.length) { this.gridEl.appendChild($el("div.ps-empty", "No items found.")); return; }
    const kind = this._kind();
    const isP = this.activeTab === "piercings";
    const lastLoc = localStorage.getItem("ps_v2_last_loc") || "", lastOut = localStorage.getItem("ps_v2_last_out") || "", lastSub = localStorage.getItem("ps_v2_last_sub") || "";

    items.forEach((item) => {
      const sel = this._isSelected(item);
      const inactive = item.active === false;

      if (isP) {
        const card = $el("button.ps-card.ps-pierce-card", { onclick: () => this._toggleItem(item), onmouseenter: () => this._setPreview(item) }, [
          $el("div.ps-pierce-card-hdr", [ $el("span.ps-pierce-checkbox", sel ? "\u2611" : "\u2610"), $el("span.ps-card-name", item.name), $el("span.ps-pierce-badge", item.material || "") ]),
          $el("small", { style: { padding: "0 12px", color: "#aaa", fontSize: "11px", lineHeight: "1.4" } }, item.style),
          $el("small", { style: { padding: "0 12px 6px" } }, `${item.location} · ${item.material}`),
        ]);
        if (sel) card.classList.add("selected");
        this.gridEl.appendChild(card);
        this._cardNodes[this.activeTab][item.id] = card;
      } else {
        const ch = [
          $el("div.ps-card-thumb", {}, [this._thumbImg(item, kind)]),
          $el("span.ps-card-name", item.name),
          $el("small", this._subtitle(item)),
        ];

        // Tag chips on card
        const tagChips = [];
        if (kind === "outfit") {
          if (item.style_family) tagChips.push($el("span.ps-tag-chip.style", item.style_family));
          (item.fabrics || []).slice(0,2).forEach(f => tagChips.push($el("span.ps-tag-chip.fabric", f)));
          (item.colors || []).slice(0,2).forEach(c => tagChips.push($el("span.ps-tag-chip.color", c)));
        }
        if (kind === "subject") {
          const t = [];
          if (item.hair_color) t.push($el("span.ps-trait.hair", item.hair_color));
          if (item.eye_color) t.push($el("span.ps-trait.eyes", item.eye_color));
          if (item.nationality) t.push($el("span.ps-trait.nat", item.nationality));
          if (t.length) ch.push($el("div.ps-traits", t));
        }
        if (tagChips.length) ch.push($el("div.ps-tag-chips", tagChips));

        // Action buttons overlay (edit/delete)
        const actions = $el("div.ps-card-actions", [
          $el("button.ps-card-action", { textContent: "\u270E", title: "Edit", onclick: (e) => { e.stopPropagation(); this._openEditModal(item); } }),
          $el("button.ps-card-action.delete", { textContent: "\u2716", title: "Delete", onclick: (e) => { e.stopPropagation(); this._deleteItem(item); } }),
        ]);

        if (sel) ch.push($el("span.ps-card-check", "\u2713"));
        if (inactive) ch.push($el("span.ps-card-inactive-badge", "inactive"));

        const card = $el("button.ps-card", { onclick: () => this._toggleItem(item), onmouseenter: () => this._setPreview(item) }, ch);
        card.appendChild(actions);
        if (sel) card.classList.add("selected");
        if (inactive) card.classList.add("inactive");
        const isLast = (kind === "location" && item.id === lastLoc) || (kind === "outfit" && item.id === lastOut) || (kind === "subject" && item.id === lastSub);
        if (!sel && isLast) card.classList.add("last-used");
        this.gridEl.appendChild(card);
        this._cardNodes[this.activeTab][item.id] = card;
      }
    });
  }

  _toggleItem(item) {
    if (this.activeTab === "piercings") {
      let sel = this._selectedPiercings();
      sel = sel.includes(item.id) ? sel.filter(s => s !== item.id) : [...sel, item.id];
      this.selectedPiercingId = sel.join(",");
      if (this._node) { setWidgetValue(this._node, "piercing_ids", this.selectedPiercingId); this._node.setDirtyCanvas?.(true, true); }
      this._renderGrid(); this._renderFilters(); this._renderChips(); this._renderConfirm(); this._renderTabs();
      return;
    }
    let field, wname;
    if (this.activeTab === "outfits") { field = "_selOut"; wname = "clothing_id"; }
    else if (this.activeTab === "locations") { field = "_selLoc"; wname = "location_id"; }
    else { field = "_selSub"; wname = "model_id"; }
    const old = this[field];
    this[field] = (old === item.id) ? "" : item.id;
    if (this._node) { setWidgetValue(this._node, wname, this[field]); this._node.setDirtyCanvas?.(true, true); }
    this._renderGrid(); this._renderTimeline(); this._renderChips(); this._renderConfirm(); this._renderTabs();
  }

  _renderChips() {
    this.chipsEl.innerHTML = "";
    const ac = (icon, name, id, cls, cb) => { if(!id)return; const c=$el("span.ps-chip"+(cls?`.${cls}`:""), [document.createTextNode(`${icon} ${name}`),$el("em",`#${id}`),$el("button.ps-chip-x",{textContent:"\u00d7",onclick:cb})]); this.chipsEl.appendChild(c); };
    const lo=(this.catalog.locations||[]).find(x=>x.id===this._selLoc), ou=(this.catalog.outfits||[]).find(x=>x.id===this._selOut), su=(this.catalog.subjects||[]).find(x=>x.id===this._selSub);
    ac("\ud83d\udccd",lo?.name||"",this._selLoc,"",()=>{this._selLoc="";this._renderChips();this._renderConfirm();this._renderTabs();if(this.activeTab==="locations")this._renderGrid();});
    ac("\ud83d\udc57",ou?.name||"",this._selOut,"outfit",()=>{this._selOut="";this._renderChips();this._renderConfirm();this._renderTabs();if(this.activeTab==="outfits")this._renderGrid();});
    ac("\ud83d\udc64",su?.name||"",this._selSub,"subject",()=>{this._selSub="";this._renderChips();this._renderConfirm();this._renderTabs();if(this.activeTab==="subjects")this._renderGrid();});
    this._selectedPiercings().forEach(pid=>{const p=(this.catalog.piercings||[]).find(x=>x.id===pid);if(p)ac("\ud83d\udc8e",p.name,pid,"",()=>{let s=this._selectedPiercings().filter(x=>x!==pid);this.selectedPiercingId=s.join(",");if(this._node){setWidgetValue(this._node,"piercing_ids",this.selectedPiercingId);this._node.setDirtyCanvas?.(true,true);}this._renderFilters();this._renderGrid();this._renderChips();this._renderConfirm();this._renderTabs();});});
    if(this._selLoc||this._selOut||this._selSub||this.selectedPiercingId)this.chipsEl.appendChild($el("button.ps-chip-random",{textContent:"\ud83c\udfb2 Randomize all",onclick:()=>this._randomizeAll()}));
  }

  _renderConfirm() {
    const lo=(this.catalog.locations||[]).find(x=>x.id===this._selLoc), ou=(this.catalog.outfits||[]).find(x=>x.id===this._selOut), su=(this.catalog.subjects||[]).find(x=>x.id===this._selSub);
    const pc=this._selectedPiercings().length;
    this.confirmNameEl.textContent = [lo?.name||"Random location",ou?.name||"Random outfit",su?.name||"Random subject",pc?`${pc} piercing${pc>1?"s":""}`:""].filter(Boolean).join(" · ");
  }

  _setPreview(item) {
    this.previewImageEl.innerHTML="";this.previewTitleEl.textContent="";this.previewMetaEl.textContent="";this.previewTagsEl.innerHTML="";this.previewDetailEl.innerHTML="";
    if(!item){this.previewImageEl.appendChild($el("div.ps-preview-fb","Hover an item"));return;}
    this.previewTitleEl.textContent=item.name;
    if(item.thumbnail)this.previewImageEl.appendChild(this._thumbImg(item,this._kind()));else this.previewImageEl.appendChild($el("div.ps-preview-fb","No preview image"));

    if(this.activeTab==="outfits"){
      this.previewMetaEl.textContent=`${item.item_count} items · ${item.style_family || "classic"}`;
      // Tag pills in preview
      const pChips = [];
      if (item.fabrics?.length) item.fabrics.forEach(f => pChips.push($el("span.ps-preview-chip.fabric", f)));
      if (item.colors?.length) item.colors.forEach(c => pChips.push($el("span.ps-preview-chip.color", c)));
      if (item.tags?.length) item.tags.forEach(t => pChips.push($el("span.ps-preview-chip.tag", t)));
      pChips.forEach(c => this.previewTagsEl.appendChild(c));

      if(item.items&&item.items.length){
        const s=[...item.items].sort((a,b)=>a.removalOrder-b.removalOrder);
        const ic={outerwear:"\ud83e\udde5",dress:"\ud83d\udc57",top:"\ud83d\udc54",bottom:"\ud83d\udc56",underwear_top:"\ud83d\udc59",underwear_bottom:"\ud83e\ude72",footwear:"\ud83d\udc60",accessory:"\ud83d\udc8d"};
        this.previewDetailEl.innerHTML=`<div><strong>Layers</strong><div class="ps-layer-list">${s.map((i,idx)=>`<div class="ps-layer-item"><span class="ps-layer-num">${idx+1}</span> ${ic[i.category]||"\u2693"} ${i.name} <span class="ps-layer-cat">${i.category}</span></div>`).join("")}</div></div>`;
      }
    } else if(this.activeTab==="locations"){
      this.previewMetaEl.textContent=`${item.group} · ${item.zone_count||(item.zones||[]).length} views`;
      const z=item.zones||[],sf=item.surfaces||[];
      this.previewDetailEl.innerHTML=[z.length?`<div><strong>Views</strong><div class="ps-zlist">${z.map(z=>`<span class="ps-ztag z-${z.category}">${z.category}</span>`).join("")}</div></div>`:"", sf.length?`<div><strong>Surfaces</strong> ${sf.map(s=>s.name).join(" · ")}</div>`:""].join("");
    } else if(this.activeTab==="piercings"){
      this.previewMetaEl.textContent=`${item.location} · ${item.material}`;
      this.previewDetailEl.innerHTML=`<p>${item.style}</p>`;
    } else {
      this.previewMetaEl.textContent=`Age ${item.age||"?"}`;
      this.previewDetailEl.innerHTML=item.preview?`<p>${item.preview}</p>`:"";
    }
  }

  // ── CRUD: Edit modal ──
  _openEditModal(item) {
    this._editModalVisible = true;
    this._editingItem = item;
    this._editingKind = this.activeTab === "outfits" ? "outfit" : this.activeTab === "locations" ? "location" : this.activeTab === "subjects" ? "subject" : "piercing";
    this._editNameInput.value = item ? (item.name || "") : "";
    this._editDescInput.value = item ? ((item.preview || item.description_preview || item.style || "") || "") : "";
    this._editTagsInput.value = item && item.tags ? item.tags.join(", ") : "";
    const cb = this._editActiveToggle.querySelector("input");
    if (cb) { cb.checked = item ? (item.active !== false) : true; this._editActiveValue = cb.checked; }
    this._editModalEl.querySelector(".ps-edit-hdr h3").textContent = item ? "Edit Item" : "Add New Item";
    this._editModalEl.querySelector(".ps-edit-delete").style.display = item ? "" : "none";
    this._editModalEl.style.display = "flex";
  }

  _closeEditModal() {
    this._editModalVisible = false;
    this._editingItem = null;
    this._editModalEl.style.display = "none";
  }

  async _saveCurrentItem() {
    const kind = this._editingKind;
    const name = this._editNameInput.value.trim();
    if (!name) { alert("Name is required."); return; }
    const tags = this._editTagsInput.value.split(",").map(t => t.trim()).filter(Boolean);
    const body = { name, tags, active: this._editActiveValue };
    if (kind === "subject") body.preview = this._editDescInput.value.trim();
    if (kind === "location") body.description_preview = this._editDescInput.value.trim();
    if (kind === "outfit") body.preview = this._editDescInput.value.trim();

    let url, method;
    if (this._editingItem) {
      url = `/asb/item/${kind}/${this._editingItem.id}`;
      method = "PUT";
    } else {
      url = `/asb/item/${kind}`;
      method = "POST";
    }

    const resp = await api.fetchApi(url, { method, body: JSON.stringify(body), headers: { "Content-Type": "application/json" } });
    if (resp.ok) {
      this._closeEditModal();
      this.catalog = await fetchCatalog(true);
      this._renderGrid(); this._renderSubtabs(); this._renderFilters(); this._renderChips(); this._renderTabs();
    } else {
      const err = await resp.json();
      alert(`Save failed: ${err.error || "Unknown error"}`);
    }
  }

  async _deleteCurrentItem() {
    if (!this._editingItem) return;
    if (!confirm(`Delete "${this._editingItem.name}"? This only sets it as inactive — you can re-enable later.`)) return;
    const kind = this._editingKind;
    const resp = await api.fetchApi(`/asb/item/${kind}/${this._editingItem.id}`, { method: "DELETE" });
    if (resp.ok) {
      this._closeEditModal();
      this.catalog = await fetchCatalog(true);
      // Clear selection if deleted item was selected
      if (kind === "outfit" && this._selOut === this._editingItem.id) this._selOut = "";
      if (kind === "location" && this._selLoc === this._editingItem.id) this._selLoc = "";
      if (kind === "subject" && this._selSub === this._editingItem.id) this._selSub = "";
      this._renderGrid(); this._renderSubtabs(); this._renderFilters(); this._renderChips(); this._renderConfirm(); this._renderTabs();
    } else {
      alert("Delete failed.");
    }
  }

  async _deleteItem(item) {
    if (!confirm(`Delete "${item.name}"? It will be marked inactive and hidden from the browser.`)) return;
    const kind = this._kind();
    const resp = await api.fetchApi(`/asb/item/${kind}/${item.id}`, { method: "DELETE" });
    if (resp.ok) {
      this.catalog = await fetchCatalog(true);
      if (kind === "outfit" && this._selOut === item.id) this._selOut = "";
      if (kind === "location" && this._selLoc === item.id) this._selLoc = "";
      if (kind === "subject" && this._selSub === item.id) this._selSub = "";
      this._renderGrid(); this._renderSubtabs(); this._renderFilters(); this._renderChips(); this._renderConfirm(); this._renderTabs();
    } else {
      alert("Delete failed.");
    }
  }

  _randomizeAll() { this._selLoc="";this._selOut="";this._selSub="";this.selectedPiercingId="";this._renderGrid();this._renderTimeline();this._renderFilters();this._renderChips();this._renderConfirm();this._renderTabs(); }
}


// ═══════════════════════════════════════════════════════════
// Attach Browse + Template panel to ASB_PhotosetBrowser node
// (same pattern as planner_widget.js → ASB_ShootPlan)
// ═══════════════════════════════════════════════════════════
app.registerExtension({
  name: "ASB.PhotosetBrowser",
  init() { loadStylesheet(); },
  async setup() {
    try { await fetchCatalog(); console.log("[ASB Browser] catalog ready"); }
    catch (e) { console.warn("[ASB Browser] catalog pre-load failed", e); }
  },
  async beforeRegisterNodeDef(nodeType, nodeData, app) {
    if (nodeData.name !== "ASB_PhotosetBrowser") return;

    const onNodeCreated = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      const r = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;
      try {
        if (this._asbBrowserPanel) return r;
        this._asbBrowserPanel = true;

        const host = document.createElement("div");
        host.style.cssText = "display:flex;flex-direction:column;gap:8px;padding:8px 4px;min-width:280px;";

        const title = document.createElement("div");
        title.textContent = "Photoset Studio";
        title.style.cssText = "font-size:12px;font-weight:650;color:#ccc;letter-spacing:0.3px;";
        host.appendChild(title);

        const hint = document.createElement("div");
        hint.textContent = "Pick model · location · clothing · piercings";
        hint.style.cssText = "font-size:10px;color:#777;";
        host.appendChild(hint);

        const row = document.createElement("div");
        row.style.cssText = "display:flex;gap:6px;flex-wrap:wrap;";

        const browseBtn = document.createElement("button");
        browseBtn.textContent = "Browse & Select";
        browseBtn.style.cssText = "flex:1;background:#2f6fed;border:0;border-radius:6px;color:#fff;font-size:12px;font-weight:600;padding:10px 12px;cursor:pointer;";
        browseBtn.onmouseenter = () => { browseBtn.style.background = "#3d7eff"; };
        browseBtn.onmouseleave = () => { browseBtn.style.background = "#2f6fed"; };
        browseBtn.onclick = (e) => {
          e.preventDefault(); e.stopPropagation();
          PhotosetBrowserDialog.launch(this);
        };
        row.appendChild(browseBtn);

        const tmplBtn = document.createElement("button");
        tmplBtn.textContent = "Template";
        tmplBtn.style.cssText = "background:#252525;border:1px solid #444;border-radius:6px;color:#ddd;font-size:12px;padding:10px 12px;cursor:pointer;";
        tmplBtn.onclick = (e) => {
          e.preventDefault(); e.stopPropagation();
          const w = (this.widgets || []).find((x) => x.name === "template");
          const cur = w ? (w.value || "") : "";
          if (window.TemplateBuilderDialog && TemplateBuilderDialog.launch) {
            TemplateBuilderDialog.launch(this, "template", cur, (newVal) => {
              if (w) { w.value = newVal; w.callback?.(newVal); }
              this.setDirtyCanvas?.(true, true);
            });
          } else {
            // template_builder.js may load after — try dynamic open via event
            console.warn("[ASB] TemplateBuilder not loaded yet — open template_builder.js");
            alert("Template Builder script not loaded. Check web/template_builder.js");
          }
        };
        row.appendChild(tmplBtn);
        host.appendChild(row);

        const summary = document.createElement("div");
        summary.style.cssText = "font-size:10px;color:#8db8f0;line-height:1.4;min-height:28px;";
        const refreshSummary = () => {
          const g = (n) => ((this.widgets || []).find((x) => x.name === n)?.value || "").toString().trim();
          const parts = [];
          if (g("model_id")) parts.push("model: " + g("model_id"));
          if (g("location_id")) parts.push("loc: " + g("location_id"));
          if (g("clothing_id")) parts.push("outfit: " + g("clothing_id"));
          if (g("piercing_ids")) parts.push("pierce: " + g("piercing_ids").split(",").filter(Boolean).length);
          summary.textContent = parts.length ? parts.join(" · ") : "No selection — click Browse";
        };
        host.appendChild(summary);
        this._asbRefreshSummary = refreshSummary;
        refreshSummary();

        if (typeof this.addDOMWidget === "function") {
          this.addDOMWidget("asb_browser_panel", "div", host, {
            serialize: false,
            getMinHeight: () => 110,
          });
        } else {
          // Fallback: classic button widgets
          this.addWidget("button", "Browse & Select", null, () => PhotosetBrowserDialog.launch(this));
          this.addWidget("button", "Template Builder", null, () => {
            const w = (this.widgets || []).find((x) => x.name === "template");
            if (window.TemplateBuilderDialog) TemplateBuilderDialog.launch(this, "template", w?.value || "", (v) => { if (w) w.value = v; });
          });
        }
      } catch (err) {
        console.error("[ASB Browser] panel attach failed", err);
      }
      return r;
    };
  },
});

window.PhotosetBrowserDialog = PhotosetBrowserDialog;
