from .nodes.model_loader import ASB_LoadModel
from .nodes.location_loader import ASB_LoadLocation
from .nodes.zone_selector import ASB_SelectZone
from .nodes.clothing_loader import ASB_LoadClothing
from .nodes.clothing_state import ASB_AdvanceClothing, ASB_GetClothingStatus
from .nodes.prompt_piece_selector import ASB_SelectPromptPiece
from .nodes.prompt_builder import ASB_BuildPrompt
from .nodes.set_clothing_state import ASB_SetClothingState
from .nodes.randomize_set import ASB_RandomizeSet
from .nodes.manifest import ASB_Manifest
from .nodes.validate_node import ASB_ValidateData
from .nodes.set_plan import ASB_SetPlan
from .nodes.plan_prompt import ASB_PlanPrompt
from .nodes.batch_index import ASB_BatchIndex
from .nodes.prompt_designer import ASB_PromptDesigner
from .nodes.shoot_plan import ASB_ShootPlan

NODE_CLASS_MAPPINGS = {
    "ASB_LoadModel": ASB_LoadModel,
    "ASB_LoadLocation": ASB_LoadLocation,
    "ASB_SelectZone": ASB_SelectZone,
    "ASB_LoadClothing": ASB_LoadClothing,
    "ASB_AdvanceClothing": ASB_AdvanceClothing,
    "ASB_GetClothingStatus": ASB_GetClothingStatus,
    "ASB_SelectPromptPiece": ASB_SelectPromptPiece,
    "ASB_BuildPrompt": ASB_BuildPrompt,
    "ASB_SetClothingState": ASB_SetClothingState,
    "ASB_RandomizeSet": ASB_RandomizeSet,
    "ASB_Manifest": ASB_Manifest,
    "ASB_ValidateData": ASB_ValidateData,
    "ASB_SetPlan": ASB_SetPlan,
    "ASB_PlanPrompt": ASB_PlanPrompt,
    "ASB_BatchIndex": ASB_BatchIndex,
    "ASB_PromptDesigner": ASB_PromptDesigner,
    "ASB_ShootPlan": ASB_ShootPlan,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ASB_LoadModel": "ASB Load Model",
    "ASB_LoadLocation": "ASB Load Location",
    "ASB_SelectZone": "ASB Select Zone",
    "ASB_LoadClothing": "ASB Load Clothing",
    "ASB_AdvanceClothing": "ASB Advance Clothing (one item)",
    "ASB_GetClothingStatus": "ASB Get Clothing Status",
    "ASB_SelectPromptPiece": "ASB Select Prompt Piece",
    "ASB_BuildPrompt": "ASB Build Final Prompt",
    "ASB_SetClothingState": "ASB Set Item State",
    "ASB_RandomizeSet": "ASB Randomize Set (seeded)",
    "ASB_Manifest": "ASB Manifest (log & export)",
    "ASB_ValidateData": "ASB Validate Data",
    "ASB_SetPlan": "ASB Set Plan (batch generator)",
    "ASB_PlanPrompt": "ASB Plan → Prompt",
    "ASB_BatchIndex": "ASB Batch Index (counter, auto-run)",
    "ASB_PromptDesigner": "ASB Prompt Designer (YAML template)",
    "ASB_ShootPlan": "ASB Shoot Plan (director's shot list)",
}

WEB_DIRECTORY = "./web"

# ---------------------------------------------------------------------------
# Server-side plan storage API (ComfyUI routes)
#
# Plans are stored under ComfyUI/user/asb_plans/ so they persist across
# browser sessions and machines. Routes (guarded — no-op outside ComfyUI):
#   GET    /asb/plans          list saved plan files
#   POST   /asb/plans          save a plan  {name, content}
#   GET    /asb/plans/{name}   load a plan  -> {name, content}
#   DELETE /asb/plans/{name}   delete a plan
# ---------------------------------------------------------------------------
try:
    import server
    from aiohttp import web

    from .utils import plan_storage

    _ASB_SERVER = server.PromptServer.instance
except Exception:
    _ASB_SERVER = None

if _ASB_SERVER is not None and getattr(_ASB_SERVER, "routes", None) is not None:
    _ASB_ROUTES = _ASB_SERVER.routes

    @_ASB_ROUTES.get("/asb/plans")
    async def asb_list_plans(request):
        files, d = plan_storage.list_plans()
        return web.json_response({"plans": files, "dir": d})

    @_ASB_ROUTES.post("/asb/plans")
    async def asb_save_plan(request):
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"ok": False, "error": "bad json"}, status=400)
        name = plan_storage.safe_name(data.get("name") or "plan.yaml")
        content = data.get("content") or ""
        path = plan_storage.write_plan(name, content)
        return web.json_response({"ok": True, "name": name, "path": path})

    @_ASB_ROUTES.get("/asb/plans/{name}")
    async def asb_get_plan(request):
        name = request.match_info.get("name", "")
        content = plan_storage.read_plan(name)
        if content is None:
            return web.json_response({"error": "not found"}, status=404)
        return web.json_response({"name": plan_storage.safe_name(name),
                                  "content": content})

    @_ASB_ROUTES.delete("/asb/plans/{name}")
    async def asb_del_plan(request):
        name = request.match_info.get("name", "")
        ok = plan_storage.delete_plan(name)
        return web.json_response({"ok": ok})

    @_ASB_ROUTES.post("/asb/data")
    async def asb_editor_data(request):
        """
        LIVE editor data: reads data/ (pack + extras) at request time and
        returns the exact shape the editor needs. The frontend uses this so
        the in-node editor always reflects the real data folder — no
        export_planner_data.py / snapshot required.
        """
        from .utils.database import build_editor_payload
        try:
            payload = build_editor_payload()
            return web.json_response({"ok": True, "data": payload})
        except Exception as e:
            return web.json_response({"ok": False, "error": str(e)}, status=400)

    @_ASB_ROUTES.post("/asb/expand")
    async def asb_expand_plan(request):
        """
        Expand a plan with the REAL Python engine and return the outputs —
        NO graph execution, NO sampler, NO image generation. The frontend uses
        this so the in-node preview always matches what plan_json/storyboard
        will contain after a run.
        """
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"ok": False, "error": "bad json"}, status=400)
        try:
            from .nodes.shoot_plan import ASB_ShootPlan
            node = ASB_ShootPlan()
            out = node.plan(
                plan=data.get("plan", ""),
                seed=int(data.get("seed", 1) or 1),
                style=data.get("style") or "",
                quality=data.get("quality") or "",
                detail_level=data.get("detail_level") or "standard",
                auto_negative=bool(data.get("auto_negative", True)),
                negative_hints=data.get("negative_hints") or "",
                template=data.get("template") or "(none)",
                camera=data.get("camera") or "",
                framing=data.get("framing") or "",
                use_internal_counter=False,
            )
            plan_json, count, storyboard, shots_csv, report = out[0], out[1], out[2], out[3], out[4]
            return web.json_response({
                "ok": True,
                "count": count,
                "plan_json": plan_json,
                "storyboard": storyboard,
                "shots_csv": shots_csv,
                "report": report,
            })
        except Exception as e:
            return web.json_response({"ok": False, "error": str(e)}, status=400)

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS", "WEB_DIRECTORY"]
