import json

from ..utils.database import get_clothing_list, get_location_list, get_model_list
from ..utils.planner import build_plan, plan_to_csv
from ..utils.prompts import QUALITY_PRESETS, STYLE_PRESETS


class ASB_SetPlan:
    """
    Declarative set generator (v3).

    Defines a whole image set in one node and emits a frozen, deterministic
    plan: every image's final prompt, negative prompt, per-image seed,
    filename hint, tags and full metadata. Same inputs -> identical plan,
    so a set is reproducible and internally consistent.

    Modes:
      level      - one canonical clothing combo per (prompt piece x level)
      exhaustive - every item-state combination per piece (capped by --cap)
      random     - seeded random sample of `count` images
      transition - stable blocks per level + short one-item undress transitions (MetArt/girlstop rhythm)

    Feed plan_json into ASB Plan -> Prompt (with an ASB Batch Index counter)
    and queue with Batch Count = plan count to render the whole set.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": (get_model_list(),),
                "location": (get_location_list(),),
                "clothing_set": (get_clothing_list(),),
                "mode": (["level", "transition", "random", "exhaustive"], {"default": "transition"}),
                "seed": ("INT", {"default": 1, "min": 0, "max": 0x7FFFFFFF}),
                "style": (list(STYLE_PRESETS.keys()), {"default": "custom"}),
                "quality": (list(QUALITY_PRESETS.keys()), {"default": "default"}),
                "detail_level": (["standard", "detailed", "minimal"],
                                 {"default": "standard"}),
                "min_level": ("INT", {"default": 0, "min": 0, "max": 4}),
                "max_level": ("INT", {"default": 4, "min": 0, "max": 4}),
                "count": ("INT", {"default": 200, "min": 1, "max": 1000000}),
                "auto_negative": ("BOOLEAN", {"default": True}),
            },
            "optional": {
                "filename_prefix": ("STRING", {"default": ""}),
                "negative_hints": ("STRING", {"default": ""}),
                "quality_custom": ("STRING", {"default": ""}),
                "cap": ("INT", {"default": 2000, "min": 1, "max": 1000000}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "INT", "STRING")
    RETURN_NAMES = ("plan_json", "plan_csv", "count", "prompts_json")
    FUNCTION = "build"
    CATEGORY = "ArtisticSetBuilder/Generation"

    def build(self, model, location, clothing_set, mode="level", seed=1,
              style="custom", quality="default", detail_level="standard",
              min_level=0, max_level=4, count=200, auto_negative=True,
              filename_prefix="", negative_hints="", quality_custom="", cap=2000):
        entries = build_plan(
            model, location, clothing_set,
            mode=mode, seed=seed, count=count,
            min_level=min_level, max_level=max_level, cap=cap,
            detail=detail_level, style=style, quality=quality,
            quality_custom=quality_custom,
            filename_prefix=filename_prefix,
            auto_negative=auto_negative, negative_hints=negative_hints,
        )
        prompts = [e["final_prompt"] for e in entries]
        return (json.dumps(entries, ensure_ascii=False),
                plan_to_csv(entries),
                len(entries),
                json.dumps(prompts, ensure_ascii=False))
