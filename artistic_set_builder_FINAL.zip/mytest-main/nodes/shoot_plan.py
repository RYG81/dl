import json

from ..utils.database import get_camera_ids, get_framing_ids
from ..utils.prompt_templates import load_template, render_template
from ..utils.shoot_plan import expand_plan, parse_plan_text, resolve_camera, shots_to_csv




class ASB_ShootPlan:
    """
    Director's shot-list engine (v5).

    Takes a plan (JSON or YAML, id-first: zone_id / piece id / item_id) that
    declares the whole shoot, validates every reference against the data files,
    resolves cameras from the camera database, expands wardrobe transitions,
    and emits:

      plan_json / count / storyboard / shots_csv / report   (the full plan)
      index / shot_prompt / shot_negative / shot_seed /
      shot_filename_hint / shot_done                        (single-shot serve)

    The single-shot serve replaces the ASB_BatchIndex + ASB Plan→Prompt pair:
    turn on `use_internal_counter` and each execution serves the next shot
    (auto-run friendly), or wire an external `index`.

    The embedded plan editor (frontend) uses `auto_shots` as the shot count
    for its "Auto N shots" button.
    """

    def __init__(self):
        self._counter = 0

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "plan": ("STRING", {"multiline": True, "default": ""}),
                "seed": ("INT", {"default": 1, "min": 0, "max": 0x7FFFFFFF}),
            },
            "optional": {
                "style": ("STRING", {"forceInput": True, "default": ""}),
                "quality": ("STRING", {"forceInput": True, "default": ""}),
                "detail_level": (["standard", "detailed", "minimal"],
                                 {"default": "standard"}),
                "auto_negative": ("BOOLEAN", {"default": True}),
                "negative_hints": ("STRING", {"forceInput": True, "default": ""}),
                "template": (["(none)"] + _template_list(), {"default": "(none)"}),
                "camera": ([""] + get_camera_ids(), {"default": ""}),
                "framing": ([""] + get_framing_ids(), {"default": ""}),
                "auto_shots": ("INT", {"default": 5, "min": 1, "max": 1000000}),
                "gallery_mode": (["undress narrative", "MetArt gallery"],
                                 {"default": "undress narrative"}),
                "index": ("INT", {"forceInput": True, "default": -1,
                                  "min": -1, "max": 1000000}),
                "use_internal_counter": ("BOOLEAN", {"default": False}),
                "reset_counter": ("BOOLEAN", {"default": False}),
            },
        }

    RETURN_TYPES = ("STRING", "INT", "STRING", "STRING", "STRING",
                    "INT", "STRING", "STRING", "INT", "STRING", "BOOLEAN")
    RETURN_NAMES = ("plan_json", "count", "storyboard", "shots_csv", "report",
                    "index", "shot_prompt", "shot_negative", "shot_seed",
                    "shot_filename_hint", "shot_done")
    FUNCTION = "plan"
    CATEGORY = "ArtisticSetBuilder/Shoot"

    def plan(self, plan, seed=1, style="", quality="", detail_level="standard",
             auto_negative=True, negative_hints="", template="(none)",
             camera="", framing="", auto_shots=5, index=-1,
             use_internal_counter=False, reset_counter=False,
             gallery_mode="undress narrative", **kwargs):
        # `gallery_mode` is declared in INPUT_TYPES and passed by ComfyUI.
        # **kwargs swallows any other/older widget value so a frontend or
        # workflow version mismatch can NEVER crash node execution again.
        if reset_counter:
            self._counter = 0

        err_payload = (json.dumps([]), 0)
        # friendly message when the plan box is empty/whitespace — the #1 cause
        # of "empty plan_json" after running without Apply/paste
        if not plan or not str(plan).strip():
            err = ("EMPTY PLAN — the plan box is empty.\n"
                   "Click the editor's ✓ Apply to node (after building shots), or "
                   "paste a plan / ⟳ Load from plan / 📂 Load file / ☁️ Server, "
                   "then run.")
            print("[ASB] ShootPlan: EMPTY PLAN")
            return (*err_payload, err, err, err, -1, "", "", 0, "", False)
        try:
            data = parse_plan_text(plan)
        except Exception as e:
            err = f"ERROR: {e}"
            print(f"[ASB] ShootPlan: parse error -> {err}")
            return (*err_payload, err, "", err, -1, "", "", 0, "", False)

        try:
            shots, report, story = expand_plan(
                data, base_seed=seed, style=style or None,
                quality=quality or None, detail=detail_level,
                auto_negative=auto_negative, negative_hints=negative_hints,
                camera_override=camera or "",
                framing_override=framing or "",
            )
        except Exception as e:
            err = f"ERROR: {e}"
            print(f"[ASB] ShootPlan: expand error -> {err}")
            return (*err_payload, err, "", err, -1, "", "", 0, "", False)

        # optional template re-render of final prompts (structure control)
        if template and template != "(none)":
            tmpl = load_template(template)
            for s in shots:
                ctx = {
                    "model_prompt": s.get("model_prompt", ""),
                    "clothing_phrases": s.get("clothing_phrases", ""),
                    "prompt_piece": s.get("piece_prompt", s.get("piece", "")),
                    "zone_description": s.get("zone_description", ""),
                    "lighting": s.get("lighting", ""),
                    "style_positive": s.get("style", ""),
                    "style_negative": "",
                    "quality": s.get("quality", ""),
                    "camera_technical": s.get("camera", ""),
                    "level": s["level"],
                    "level_negative": "",
                    "negative_hints": negative_hints,
                    "note": s.get("note", ""),
                    "index": str(s["index"]),
                    "total": str(len(shots)),
                    "title": s.get("title", ""),
                    "seed": str(s["seed"]),
                }
                s["final_prompt"] = render_template(tmpl, ctx, positive=True)
                neg2 = render_template(tmpl, ctx, positive=False)
                if neg2:
                    s["negative_prompt"] = neg2

        # ---- single-shot serve ----
        count = len(shots)
        if use_internal_counter:
            serve_idx = self._counter
            self._counter += 1
            done = count > 0 and serve_idx >= count - 1
            serve_idx = serve_idx % max(count, 1) if count else -1
        elif index is not None and index >= 0:
            serve_idx = max(0, min(int(index), max(count - 1, 0))) if count else -1
            done = count > 0 and serve_idx >= count - 1
        else:
            serve_idx = -1
            done = False

        if 0 <= serve_idx < count:
            s = shots[serve_idx]
            shot_out = (serve_idx, s.get("final_prompt", ""),
                        s.get("negative_prompt", ""),
                        int(s.get("seed", 0)), s.get("filename_hint", ""), done)
        else:
            shot_out = (-1, "", "", 0, "", done)

        report_txt = "\n".join(report) if report else "OK"
        # visible in the ComfyUI server console — helps debugging output issues
        print(f"[ASB] ShootPlan: plan={len(plan)} chars -> {count} shots | "
              f"report={'OK' if not report else str(len(report)) + ' notes'} | "
              f"serve_index={shot_out[0]}")
        return (json.dumps(shots, ensure_ascii=False), count,
                story, shots_to_csv(shots), report_txt, *shot_out)


def _template_list():
    from ..utils.prompt_templates import list_templates
    return list_templates()
