import copy

from ..utils.levels import compute_level, item_current_state


def _is_removed_state(state_id, phrase=""):
    sid = (state_id or "").strip().lower()
    ph = (phrase or "").strip().lower()
    if sid in {"removed", "barefoot"} or sid.startswith("no "):
        return True
    if ph.startswith("no ") or "not visible on the body" in ph or "completely removed" in ph or ph == "barefoot":
        return True
    return False


def _collect_phrases(items):
    phrases = []
    for it in items:
        cur = item_current_state(it)
        for st in it.get("states", []):
            if st.get("state_id") == cur:
                ph = st.get("prompt_phrase", "") or ""
                if not _is_removed_state(cur, ph):
                    phrases.append(ph)
                break
    return ", ".join(p for p in phrases if p)

def _is_removed_state(state_id, phrase=""):
    sid = (state_id or "").strip().lower()
    ph = (phrase or "").strip().lower()
    if sid in {"removed", "barefoot"} or sid.startswith("no "):
        return True
    if ph.startswith("no ") or "not visible on the body" in ph or ph == "barefoot":
        return True
    return False

from .clothing_loader import item_labels, item_state_list


class ASB_AdvanceClothing:
    """
    Advance ONE clothing item by its display name.
    Copy the exact name from 'available_items' output, e.g. "Simple Briefs [fully_worn]"
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "clothing": ("ASB_CLOTHING",),
                "item_name": ("STRING", {"default": "Simple Briefs [fully_worn]"}),
            }
        }

    RETURN_TYPES = ("ASB_CLOTHING", "STRING", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("clothing", "changed", "phrases", "available_items", "item_states")
    FUNCTION = "advance"
    CATEGORY = "ArtisticSetBuilder"

    def advance(self, clothing, item_name):
        new_clothing = copy.deepcopy(clothing)
        items = new_clothing.get("items", [])
        target = item_name.split(" [")[0].strip().lower()

        changed = "item not found"
        for item in items:
            name = str(item.get("name", "")).lower()
            iid = str(item.get("item_id", "")).lower()
            if ((name and (name == target or target in name))
                    or (iid and (iid == target or target in iid))):
                states = item.get("states", [])
                current = item_current_state(item)
                idx = next((i for i, st in enumerate(states) if st.get("state_id") == current), -1)
                if 0 <= idx < len(states) - 1:
                    nxt = states[idx + 1]
                    item["current_state"] = nxt["state_id"]
                    changed = f"{item.get('name')} \u2192 {nxt['state_id']}"
                else:
                    changed = f"{item.get('name')} already final"
                break

        return (new_clothing, changed, _collect_phrases(items),
                item_labels(new_clothing), item_state_list(new_clothing))


class ASB_GetClothingStatus:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"clothing": ("ASB_CLOTHING",)}}

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING", "INT")
    RETURN_NAMES = ("phrases", "level", "available_items", "level_name", "removed_count")
    FUNCTION = "get"
    CATEGORY = "ArtisticSetBuilder"

    def get(self, clothing):
        items = clothing.get("items", [])
        level_id, level_name, removed = compute_level(clothing)
        return (_collect_phrases(items), level_id,
                item_labels(clothing), level_name, removed)
