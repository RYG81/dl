# Why v1 prompts felt weak

From a real v1 run (Mira / tank / shorts):

| Issue | Example | Fix in v2 |
|-------|---------|-----------|
| Thin identity | "quiet brunette with long dark wavy hair, athletic medium build" | Full age/ethnicity/face/skin/vibe paragraph |
| Vague clothes | "white cotton tank top lifted underbust" | Locked base_description + action |
| Missing layers | Fully dressed without panties | Always list all on-body layers |
| Vague anatomy | "full breasts and nipples" | Size, shape, nipple/areola color |
| Phase bleed | Nipples named while still mostly clothed OK, but silhouette phase was too short | Strict phase table |
| Structure was OK | Zone blocks + progressive undress | Keep |

Use `TEXT_TO_PROMPTS.md` (v2) as system prompt.
