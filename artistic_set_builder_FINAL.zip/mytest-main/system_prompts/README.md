# System prompts

| File | Use when | Output |
|------|----------|--------|
| `TEXT_TO_PROMPTS.md` | **No images** — want **final prompts** ready to generate | Shot list with POSITIVE / NEGATIVE |
| `TEXT_TO_DATABASE.md` | No images — want JSON for the ComfyUI node pack | model + location + outfit JSON |
| `PHOTOSET_TO_DATABASE.md` | Have ordered gallery images | model + location + outfit JSON from photos |

## Typical flows

**A. Fast images (no Comfy nodes)**  
System: `TEXT_TO_PROMPTS.md` → paste POSITIVE/NEGATIVE into any generator.

**B. Full ASB pipeline**  
System: `TEXT_TO_DATABASE.md` or `PHOTOSET_TO_DATABASE.md` → save JSON under `data/` → `python scripts/export_planner_data.py` → ComfyUI Auto/transition shots.

After JSON install, restart ComfyUI and hard-refresh the browser.
