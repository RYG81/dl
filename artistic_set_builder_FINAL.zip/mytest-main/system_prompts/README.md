# System prompts

| File | Use when | Output |
|------|----------|--------|
| `TEXT_TO_PROMPTS.md` | **No images** — want **final prompts** ready to generate | Shot list with POSITIVE / NEGATIVE |
| `TEXT_TO_DATABASE.md` | **No images** — invent a set from a short brief | model + location + outfit JSON |
| `PHOTOSET_TO_DATABASE.md` | **You have gallery images** (folder / attachments) | model + location + outfit JSON **from those photos** |
| `PROMPT_QUALITY_NOTES.md` | Reference only | Notes on weak vs strong prompts |

## Typical flows

**A. Fast prompts (no Comfy nodes)**  
System: `TEXT_TO_PROMPTS.md` → paste POSITIVE/NEGATIVE into any generator.

**B. Invent a set (text only)**  
System: `TEXT_TO_DATABASE.md` → save JSON under `data/` → export → ComfyUI.

**C. Reverse a real photoset (folder of images)**  
1. System: paste full `PHOTOSET_TO_DATABASE.md`  
2. User: attach images **in order** (or zip/folder listing + images) and say e.g.  
   `Analyze these frames in order and build ASB model + location + outfit JSON.`  
3. Model must read the pictures — not copy schema samples.  
4. Save JSON under `data/models`, `data/locations`, `data/clothing`  
5. `python scripts/export_planner_data.py` → restart ComfyUI → hard refresh  

If the model returns a generic bedroom/dress set that does not match your photos, reject it and re-prompt:  
`You did not use my images. Re-analyze attachments only; no sample JSON.`

After JSON install, restart ComfyUI and hard-refresh the browser.
