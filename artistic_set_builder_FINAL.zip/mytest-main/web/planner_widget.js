// Artistic Set Builder — embedded Plan Designer (v5.3)
//
// In-canvas shot-list editor for ASB_ShootPlan.
//
// v5.3 fixes:
//   * node height is CAPPED — the shot list scrolls inside the widget; the
//     node can never grow endlessly (getHeight is clamped, no resize loop)
//   * shot list shows as many cards as fit (up to 10), then scrolls
//   * Apply-to-node is bulletproof: finds the live plan widget, sets value +
//     textarea + dispatches input, shows ✓ feedback (run node to refresh
//     plan_json)
//   * editor starts EMPTY (node default plan is ""), so "Auto N shots" gives
//     exactly N — no surprise default shots
//   * Auto N shots follows a real undressing narrative: shot 0 = all on,
//     then one garment advances one step per shot (cycling the wardrobe DB),
//     until everything is off; extra shots keep all-off with varied
//     zone/pose. Poses are chosen compatible with the level each shot reaches.
//   * toolbar (＋ Shot / Auto N / Sample / Load / Apply) above the shot list;
//     status bar shows shots count + plan details + level histogram + feedback

import { app } from "../../scripts/app.js";

const DATA_URL = new URL("planner_data.json", import.meta.url).href;

// Load editor data: try the LIVE server route first (reads data/ at request
// time — always current, includes external folders), fall back to the shipped
// snapshot only if the route is unavailable.
async function loadEditorData() {
  try {
    const r = await fetch("/asb/data", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
      cache: "no-store",
    });
    if (r.ok) {
      const j = await r.json();
      if (j && j.ok && j.data && j.data.locations && j.data.locations.length) {
        return { data: j.data, live: true };
      }
    }
  } catch (e) { /* route unavailable — fall through to snapshot */ }
  const r2 = await fetch(DATA_URL + (DATA_URL.includes("?") ? "&" : "?") + "t=" + Date.now(), { cache: "no-store" });
  if (!r2.ok) throw new Error("no data source");
  return { data: await r2.json(), live: false };
}
const REMOVED_DEFAULT = ["removed","no panties","no bra","barefoot","no top","no skirt","no dress","no shirt"];
const SHOTS_PER_PAGE = 10;      // pagination size
const MAX_VISIBLE_SHOTS = 10;   // kept for height calc of one page
const MAX_NODE_H = 720;         // tighter cap — use shot pagination, not a tall node
const MIN_NODE_H = 240;

// Build a sample plan from WHATEVER data is present (first available
// model / location / clothing / camera / style / quality + a small undress
// narrative through the first zones' pieces). Never hardcodes any id, so the
// Sample button always produces a plan loadable with your current data.
function buildSamplePlan(DATA) {
  const D = DATA || {};
  const m = (D.models && D.models[0]) || "";
  const loc = (D.locations && D.locations[0]) || null;
  const cl = (D.clothing && D.clothing[0]) || null;
  const cam = (D.cameras && D.cameras[0] && D.cameras[0].id) || "";
  const style = (D.styles && D.styles[0]) || "custom";
  const quality = (D.qualities && D.qualities[0]) || "default";
  if (!loc || !cl || !loc.zones || !loc.zones.length) return "";
  const zones = loc.zones;
  const items = (cl.items || []).map(it => it.item_id || it.name);
  const L = [];
  L.push(`title: "Sample shoot"`);
  L.push(`model: ${m}`);
  L.push(`location: ${loc.name}`);
  L.push(`clothing_set: ${cl.name}`);
  L.push(`style: ${style}`);
  L.push(`quality: ${quality}`);
  if (cam) L.push(`camera: ${cam}`);
  L.push("seed: 1");
  L.push("shots:");
  // walk up to 6 shots across the first zones, advancing one item at a time
  const n = Math.min(zones.length, 6);
  for (let zi = 0; zi < n; zi++) {
    const z = zones[zi];
    const zid = z.zone_id || z.name;
    const pieces = z.pieces || [];
    const p0 = pieces.find(p => (p.levels || []).includes("level_0")) || pieces[0];
    if (!p0) continue;
    L.push(`  - zone: ${zid}`);
    L.push(`    piece: ${p0.id}`);
    if (zi === 0) {
      L.push("    outfit: fully_worn");
    } else if (items.length) {
      L.push(`    transition: "advance: ${items[(zi - 1) % items.length]}"`);
    }
  }
  return L.join("\n");
}

const SAMPLE_PLAN = buildSamplePlan(null); // placeholder — replaced with real data below

const CSS_ID = "asb-plan-editor-css";
if (!document.getElementById(CSS_ID)) {
  const style = document.createElement("style");
  style.id = CSS_ID;
  style.textContent = `
  .asb-pe { font: 12px/1.35 "Segoe UI", system-ui, sans-serif; color: #dfe5ee;
            display:flex; flex-direction:column; height:100%; box-sizing:border-box;
            min-width:0; overflow:hidden; }
  .asb-pe * { box-sizing:border-box; min-width:0; }
  .asb-pe .pe-head { display:flex; align-items:center; gap:6px; margin-bottom:6px; flex:none; }
  .asb-pe .pe-toggle { cursor:pointer; background:#2a3140; border:1px solid #3a4458; color:#dfe5ee;
      border-radius:5px; padding:2px 8px; font-size:11px; }
  .asb-pe .pe-toggle:hover { border-color:#6ea8fe; }
  .asb-pe .pe-status { background:#1a2029; border:1px solid #2c3342; border-radius:6px;
      padding:3px 8px; font-size:10px; color:#8b96a8; margin-bottom:6px; flex:none;
      display:flex; gap:10px; flex-wrap:wrap; align-items:center; min-height:20px; }
  .asb-pe .pe-status b { color:#dfe5ee; font-weight:600; }
  .asb-pe .pe-status .pe-count { color:#6ea8fe; font-weight:700; }
  .asb-pe .pe-status .pe-flash { color:#34d399; font-weight:600; }
  .asb-pe .pe-status .pe-flash.err { color:#f87171; }
  .asb-pe .pe-grid { display:grid; grid-template-columns:1fr 1fr 1fr; gap:3px 6px; margin-bottom:6px; flex:none; }
  .asb-pe label { display:block; font-size:9px; color:#8b96a8; text-transform:uppercase; letter-spacing:.4px; }
  .asb-pe select, .asb-pe input[type=text], .asb-pe input[type=number] { width:100%; background:#1c2230; color:#dfe5ee;
      border:1px solid #3a4458; border-radius:4px; padding:2px 4px; font-size:11px; }
  .asb-pe .pe-toolbar { display:flex; gap:5px; margin-bottom:6px; flex-wrap:wrap; align-items:center; flex:none; }
  .asb-pe .pe-shots { flex:1 1 auto; min-height:0; overflow-y:auto; border:1px solid #2c3342; border-radius:6px;
      padding:3px; background:#141922; }
  .asb-pe .pe-empty { color:#7c8798; font-size:11px; padding:14px 8px; text-align:center; }
  .asb-pe .pe-shot { border:1px solid #2c3342; border-radius:6px; padding:4px; margin-bottom:4px; background:#1a2029; }
  .asb-pe .pe-shot:last-child { margin-bottom:0; }
  .asb-pe .pe-prompt { background:#10141c; border:1px solid #232b38; border-radius:4px;
      padding:3px 5px; font-size:10px; color:#93a1b5; margin-top:3px; line-height:1.3;
      display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
  .asb-pe .pe-prompt b { color:#7c8798; font-weight:600; }
  .asb-pe .pe-shot-top { display:flex; gap:4px; align-items:center; margin-bottom:3px; }
  .asb-pe .pe-no { background:#8b5cf6; color:#fff; border-radius:4px; padding:0 6px; font-weight:700; font-size:10px; flex:none; }
  .asb-pe .pe-lvl { border-radius:10px; padding:0 7px; font-size:10px; font-weight:600; white-space:nowrap; flex:none; }
  .asb-pe .l0{background:#1e3a5f;color:#7cc4ff;} .asb-pe .l1{background:#1f3a3a;color:#5eead4;}
  .asb-pe .l2{background:#3a2f1e;color:#fbbf24;} .asb-pe .l3{background:#1f3a2b;color:#fb7185;}
  .asb-pe .l4{background:#2d1e3a;color:#c084fc;}
  .asb-pe .pe-ic { cursor:pointer; background:none; border:none; color:#8b96a8; font-size:12px; padding:0 3px; flex:none; }
  .asb-pe .pe-ic:hover { color:#6ea8fe; }
  .asb-pe .pe-row { display:grid; grid-template-columns:1fr 1.3fr 1.1fr; gap:3px; margin-bottom:3px; }
  .asb-pe .pe-row2 { display:grid; grid-template-columns:1.3fr 1fr; gap:3px; margin-bottom:3px; }
  .asb-pe .pe-custom { display:grid; grid-template-columns:1fr 1fr; gap:3px 6px; background:#10141c; border-radius:4px; padding:3px; margin-top:3px; }
  .asb-pe .pe-foot-note { color:#7c8798; font-size:10px; flex:none; margin-top:4px; }
  .asb-pe .pe-out { flex:none; margin-top:6px; }
  .asb-pe .pe-outbody { display:none; background:#0f131a; border:1px solid #2c3342; border-radius:6px;
      padding:6px; font:10.5px/1.4 ui-monospace, Menlo, Consolas, monospace; color:#aab6c6;
      max-height:150px; overflow:auto; white-space:pre; margin:4px 0 0; }
  .asb-pe .pe-server { background:#10141c; border:1px solid #2c3342; border-radius:6px; padding:4px; margin-bottom:6px; flex:none; }
  .asb-pe .pe-server-row { display:flex; gap:5px; align-items:center; margin-bottom:4px; }
  .asb-pe .pe-server-row input[type=text] { flex:1; }
  .asb-pe .pe-serverlist { max-height:110px; overflow-y:auto; }
  .asb-pe .pe-server-row .pe-sname { flex:1; font-size:11px; color:#c7d0dd; word-break:break-all; }
  .asb-pe .pe-server-row button { padding:2px 7px; font-size:11px; }
  .asb-pe button { background:#2a3140; border:1px solid #3a4458; color:#dfe5ee; border-radius:5px;
      padding:3px 9px; font-size:11px; cursor:pointer; white-space:nowrap; }
  .asb-pe button:hover { border-color:#6ea8fe; }
  .asb-pe .pe-primary { background:#6ea8fe; border-color:#6ea8fe; color:#081018; font-weight:600; }
  .asb-pe .pe-err { color:#f87171; font-size:11px; padding:6px; }
  .asb-pe .pe-note { color:#7c8798; font-size:10px; }
  `;
  document.head.appendChild(style);
}

function computeLevel(cn, outfitMap, DATA) {
  const c = DATA.clothing.find(x => x.name === cn);
  const removed = (c && c.removed_states) || REMOVED_DEFAULT;
  const vals = Object.values(outfitMap || {});
  const total = vals.length;
  let n = 0;
  for (const v of vals) if (removed.includes(v)) n++;
  // Fully stripped (every tracked item off) => level_4 nude phase
  if (total > 0 && n >= total) return "level_4";
  // Empty outfit map with bare set
  if (total === 0) return "level_4";
  let idx = 0;
  for (let i = 0; i < 5; i++) if (n >= i) idx = i;
  return "level_" + Math.min(idx, 4);
}
function removedStatesOf(api) {
  const c = api._DATA.clothing.find(x => x.name === api.st.clothing);
  return (c && c.removed_states) || REMOVED_DEFAULT;
}

function yamlQuote(v) {
  v = String(v);
  return /[:#\[\]{}&*!|>'"%@`,\n]/.test(v) || /^\s|\s$/.test(v) ? JSON.stringify(v) : v;
}

function newState() {
  return {
    title: "My Shoot", model: "", location: "", clothing: "",
    style: "custom", quality: "default", seed: 1, camera: "",
    piercing: "none", tattoo: "none",
    shots: [],
  };
}

function locZones(st, DATA) {
  const l = DATA.locations.find(x => x.name === st.location);
  return l ? l.zones : [];
}
function zonePieces(st, DATA, zoneId) {
  const z = locZones(st, DATA).find(x => (x.zone_id || x.name) === zoneId);
  return z ? z.pieces : [];
}
function clothItems(st, DATA) {
  const c = DATA.clothing.find(x => x.name === st.clothing);
  return c ? c.items : [];
}

// ---------- YAML ----------
function buildYAML(st) {
  const L = [];
  L.push(`title: ${yamlQuote(st.title)}`);
  L.push(`model: ${yamlQuote(st.model)}`);
  L.push(`location: ${yamlQuote(st.location)}`);
  L.push(`clothing_set: ${yamlQuote(st.clothing)}`);
  L.push(`style: ${yamlQuote(st.style)}`);
  L.push(`quality: ${yamlQuote(st.quality)}`);
  if (st.camera) L.push(`camera: ${yamlQuote(st.camera)}`);
  if (st.piercing && st.piercing !== "none") L.push(`piercing: ${yamlQuote(st.piercing)}`);
  if (st.tattoo && st.tattoo !== "none") L.push(`tattoo: ${yamlQuote(st.tattoo)}`);
  L.push(`seed: ${st.seed}`);
  L.push("shots:");
  // A plan uses ONE location + ONE clothing set throughout (consistent set).
  for (const s of st.shots) {
    L.push(`  - zone: ${yamlQuote(s.zone)}`);
    L.push(`    piece: ${yamlQuote(s.piece)}`);
    if (s.framing) L.push(`    framing: ${yamlQuote(s.framing)}`);
    // Prefer explicit custom outfit map (MetArt blocks / Auto v12)
    const customEntries = s.custom ? Object.entries(s.custom).filter(([, v]) => v) : [];
    if (customEntries.length) {
      L.push("    outfit:");
      for (const [k, v] of customEntries) L.push(`      ${yamlQuote(k)}: ${yamlQuote(v)}`);
    } else if (s.mode === "fully_worn") L.push("    outfit: fully_worn");
    else if (s.mode === "removed") L.push("    outfit: removed");
    else if (s.transition && s.transition !== "none") {
      L.push(`    transition: ${yamlQuote(s.transition)}`);
    }
    if (s.note) L.push(`    note: ${yamlQuote(s.note)}`);
  }
  return L.join("\n");
}

function parsePlanText(txt) {
  const obj = {};
  let cur = null;
  const shots = [];
  for (const raw of txt.split("\n")) {
    const line = raw.replace(/#.*$/, "").trimEnd();
    if (!line.trim()) continue;
    if (/^shots:/.test(line.trim())) continue;
    // a shot's opening line carries its first field ("- zone: Z_Window") —
    // start the shot AND parse the key:value on that same line (bugfix:
    // previously the zone was silently dropped, which blanked every shot)
    let openingShot = false;
    let effLine = line;
    if (/^  - /.test(line)) {
      cur = {};
      shots.push(cur);
      openingShot = true;
      effLine = line.replace(/^  - /, "    "); // treat "- key: val" as an indented field line
    }
    const ind = openingShot ? 4 : effLine.search(/\S/);
    const m = effLine.trim().match(/^([^:]+):\s*(.*)$/);
    if (!m) continue;
    const k = m[1].trim(), v = unquote(m[2]);
    if (ind >= 2 && cur) {
      if (k === "outfit" && !v) { cur.outfit = {}; continue; }
      if (k === "outfit" && v) { cur.outfit = v; continue; }
      if (cur.outfit && typeof cur.outfit === "object" && k !== "zone" && k !== "piece" && k !== "transition" && k !== "framing" && k !== "camera" && k !== "note") {
        cur.outfit[k] = v; continue;
      }
      cur[k] = v;
    } else if (ind === 0) {
      obj[k] = v;
    }
  }
  obj.shots = shots;
  return obj;
}
function unquote(v) { v = v.trim(); if (v.length >= 2 && ((v[0] === '"' && v[v.length-1] === '"') || (v[0] === "'" && v[v.length-1] === "'"))) return v.slice(1, -1); return v; }

// ---------- outfit/transition logic (mirrors engine) ----------
// outfit map for a shot: the plan uses ONE clothing set, so items are that
// set's items and the state carries forward across shots.
function outfitMapOf(api, idx) {
  const items = clothItems(api.st, api._DATA);
  if (!items.length) return {};
  const s = api.st.shots[idx];
  if (!s) { const m = {}; items.forEach(it => m[it.item_id || it.name] = it.states[0]); return m; }
  const prev = idx > 0 ? outfitMapOf(api, idx - 1) : {};
  const m = {};
  items.forEach(it => { m[it.item_id || it.name] = it.states[0]; });
  Object.assign(m, prev);
  if (s.mode === "fully_worn") items.forEach(it => m[it.item_id || it.name] = it.states[0]);
  else if (s.mode === "removed") items.forEach(it => m[it.item_id || it.name] = it.states[it.states.length - 1]);
  else if (s.mode === "custom") items.forEach(it => { const k = it.item_id || it.name; if (s.custom[k]) m[k] = s.custom[k]; });
  else if (s.transition && s.transition !== "none") applyTransition(m, s.transition, items);
  return m;
}
function applyTransition(m, t, items) {
  if (t === "reset") { items.forEach(it => m[it.item_id || it.name] = it.states[0]); return m; }
  const parts = t.split(": ");
  const kind = parts[0], arg = parts[1];
  const it = items.find(x => (x.item_id || x.name) === arg || x.name === arg);
  if (it) {
    const k = it.item_id || it.name;
    const idx = it.states.indexOf(m[k]);
    if (kind === "advance" || kind === "undress" || kind === "next") m[k] = it.states[Math.min(idx + 1, it.states.length - 1)];
    else if (kind === "remove") m[k] = it.states[it.states.length - 1];
    else if (kind === "dress") m[k] = it.states[Math.max(idx - 1, 0)];
    else if (kind === "set") { const st = t.split("->")[1].trim(); m[k] = st; }
  }
  return m;
}

// ---------- auto shots: real undressing narrative ----------
// pieces of a zone in a SPECIFIC location (per-shot location override)
function zonePiecesIn(api, locname, zoneId) {
  const l = (api._DATA.locations || []).find(x => x.name === locname);
  const z = l ? (l.zones || []).find(x => (x.zone_id || x.name) === zoneId) : null;
  return z ? (z.pieces || []) : [];
}

// pick a pose for a zone (in `locname`) at `lvl`, rotating through the
// compatible poses so the set has variety.
function pickPiece(api, locname, zone, lvl) {
  const pieces = zonePiecesIn(api, locname, zone.zone_id || zone.name);
  if (!pieces.length) return {};
  const have = parseInt(String(lvl || "level_0").split("_").pop(), 10);
  const lvlNum = Number.isFinite(have) ? have : 0;
  const compat = pieces.filter(p => {
    const levels = p.compatible_clothing_levels || p.levels || [];
    if (levels.length) return levels.includes(lvl) || levels.includes("level_" + lvlNum);
    const minL = p.min_level || p.minLevel;
    const maxL = p.max_level || p.maxLevel;
    let ok = true;
    if (minL) {
      const n = parseInt(String(minL).split("_").pop(), 10);
      if (Number.isFinite(n) && lvlNum < n) ok = false;
    }
    if (maxL) {
      const n = parseInt(String(maxL).split("_").pop(), 10);
      if (Number.isFinite(n) && lvlNum > n) ok = false;
    }
    return ok;
  });
  const pool = compat.length ? compat : pieces;
  // per-zone rotation so consecutive holds cycle poses, not zones
  api._zonePick = api._zonePick || {};
  const key = (locname || "") + "::" + (zone.zone_id || zone.name) + "::" + (lvl || "");
  const idx = (api._zonePick[key] || 0) % pool.length;
  api._zonePick[key] = idx + 1;
  return pool[idx] || pieces[0] || {};
}

// pick a framing: prefer one matched to the pose type, else cycle through the
// list so consecutive shots differ.
function pickFraming(api, framings, piece, shotIndex) {
  // Full-body = scale in frame (head-to-toe + scene), NOT "front only".
  // Angle variety is good: rear, profile, 3/4, high, low, from behind.
  // Avoid only TIGHT CROPS that lose the body/scene.
  if (!framings.length) return "full_body";
  const idOf = (f) => (f.id || f.name || "").toLowerCase();
  const cropBan = /close_up|extreme_close|detail_crop|tight_crop|intimate$/;
  // Full-figure friendly angles (scale + viewpoint)
  // Prefer true full-body scale most of the time; angles still vary.
  // wide_scene / negative_space reinforce floor + ceiling + room.
  const fullFigureAngles = [
    "full_body", "full_body", "full_body", "wide_scene", "negative_space",
    "environmental_portrait", "medium_full",
    "from_behind", "rear_three_quarter", "profile", "three_quarter",
    "low_angle", "high_angle", "elevated_three_quarter",
  ];
  const prompt = ((piece && (piece.prompt || piece.label)) || "").toLowerCase();
  const wantsClose = /close portrait|close beauty|face only|tight portrait/.test(prompt);

  if (wantsClose) {
    const c = framings.find(f => /close_up/.test(idOf(f)) && !/extreme/.test(idOf(f)));
    if (c) return c.id || c.name;
  }
  // Align angle with pose text (avoid "facing camera" + from_behind)
  if (/from behind|back to camera|looking over the shoulder|look back|looking back/.test(prompt)) {
    const hit = framings.find(f => /from_behind|rear/.test(idOf(f)));
    if (hit) return hit.id || hit.name;
  }
  if (/in profile|side view|side-on/.test(prompt)) {
    const hit = framings.find(f => idOf(f) === "profile");
    if (hit) return hit.id || hit.name;
  }
  if (/facing camera|toward camera|looking at camera/.test(prompt) && !/over the shoulder|looking back/.test(prompt)) {
    const hit = framings.find(f => idOf(f) === "full_body" || idOf(f) === "medium_full");
    if (hit) return hit.id || hit.name;
  }

  // Build pool of available full-figure framings (exclude crops)
  const pool = [];
  for (const want of fullFigureAngles) {
    const hit = framings.find(f => idOf(f) === want || idOf(f).includes(want));
    if (hit && !cropBan.test(idOf(hit))) pool.push(hit);
  }
  // Also include any other framing that is not a crop
  for (const f of framings) {
    if (cropBan.test(idOf(f))) continue;
    if (/overhead|bird_eye|worm_eye|pov|dutch|reflection|silhouette|through_foreground/.test(idOf(f))) {
      // occasional specialty angles still full-ish — allow sparsely via index
      if (shotIndex % 12 === 11) pool.push(f);
      continue;
    }
    if (!pool.some(p => idOf(p) === idOf(f))) pool.push(f);
  }
  if (!pool.length) {
    const fb = framings.find(f => /full_body/.test(idOf(f)));
    return (fb && (fb.id || fb.name)) || (framings[0].id || framings[0].name || "full_body");
  }
  // Rotate through full-figure angles for variety (rear/profile/3q/high/low…)
  const pick = pool[shotIndex % pool.length];
  return pick.id || pick.name || "full_body";
}

function makeAutoShot(api, zones, framings, items, outfitMode, transition, note) {
  const { st, _DATA } = api;
  // level after this shot's transition
  let trial = st.shots.length ? outfitMapOf(api, st.shots.length - 1) : {};
  if (outfitMode === "fully_worn") {
    trial = {}; items.forEach(it => trial[it.item_id || it.name] = it.states[0]);
  } else if (transition) {
    trial = applyTransition({ ...trial }, transition, items);
  }
  const lvl = computeLevel(st.clothing, trial, _DATA);
  const zone = zones[st.shots.length % zones.length] || zones[0];
  const zid = zone.zone_id || zone.name;
  const piece = pickPiece(api, st.location, zone, lvl);
  const framing = pickFraming(api, framings, piece, st.shots.length);
  return {
    zone: zid,
    piece: piece.id || "",
    framing,
    mode: outfitMode ? outfitMode : "inherit",
    custom: {},
    transition: transition ? transition : "none",
    note: note || "",
  };
}

// total wardrobe steps to go from fully worn to everything off
function totalUndressSteps(items) {
  let steps = 0;
  items.forEach(it => steps += Math.max(0, (it.states.length - 1)));
  return steps;
}

// read a node INT widget (auto_shots / min_level / max_level), default fallback
function nodeInt(api, name, fallback) {
  const w = (api.node.widgets || []).find(x => x.name === name);
  const v = w ? parseInt(w.value) : NaN;
  return Number.isFinite(v) ? v : fallback;
}

// read a node COMBO widget value ("all" | "current" | mode name)
function nodeChoice(api, name, fallback) {
  const w = (api.node.widgets || []).find(x => x.name === name);
  return (w && w.value) ? String(w.value) : fallback;
}

// fresh per-set item state machine
function freshSetMachine(set) {
  return ((set && set.items) || []).map(it => ({
    key: it.item_id || it.name,
    states: it.states || [],
    cur: (it.states && it.states[0]) || "",
  }));
}


// autoShots v6 — builds a TRUE gallery across the whole database:
//   location_scope  : "all" (cycle every location) | "current"
//   clothing_scope  : "all" (cycle every clothing set) | "current"
//   gallery_mode    : "MetArt gallery" (mostly artistic nude with wardrobe
//                     changes) | "undress narrative" (classic paced undress)
// Per-shot `location` / `clothing_set` overrides are emitted so ONE plan spans
// the full databases — the engine expands each shot in its own location/set.
// autoShots v7 — builds a consistent gallery within the USER-SELECTED
// location + clothing set (NEVER mixes two locations or two outfits in one
// set). It fully utilizes the selected data:
//   - cycles through ALL zones of the selected location,
//   - rotates poses per zone (compatible with each shot's level),
//   - uses EVERY item of the selected clothing set in the undress arc,
//   - MetArt gallery = dress/undress ~30% then mostly artistic nude;
//     undress narrative = slower paced undress (~60% wardrobe).
// autoShots v8 — LINEAR all→none undress across the FULL shot count.
//
// The sequence is strictly linear: shot 0 is fully dressed, and the outfit
// advances one item-state at a time, spread evenly across ALL N shots, so the
// set ends all-off. Location zones are REUSED (they cycle) but every revisit
// has a progressed outfit state, and poses rotate per zone per level — so a
// 500-shot set uses the same 5 zones ~100 times each, never repeating the
// exact same (zone, pose, outfit) triple.
//
//   gallery_mode:
//     "undress narrative" (default) — undress spread across the whole N
//     "MetArt gallery"               — dress/undress arc then mostly nude
// director's-note pool for auto-generated shots — real, evocative wording,
// NEVER progress counters (counters leaking into prompts looked like
// "hold (59/100)" — meaningless to an image model and ugly).
const AUTO_NOTES = [
  "eyes to camera, soft smile", "weight shift, hand through hair",
  "looking away, gentle profile", "arms relaxed, quiet confidence",
  "fingertip tracing collarbone", "half-lidded gaze, warm light",
  "shoulder turned, coy glance", "stretching slowly, arching back",
  "hand resting on hip, poised", "hair swept over one shoulder",
  "leaning in, intimate moment", "serene, caught in soft light",
  "breath held, anticipation", "smile just forming, playful",
  "gazing down, shy warmth", "tilting head, curious and open",
];
function autoNote(api, i) { return AUTO_NOTES[i % AUTO_NOTES.length]; }

// autoShots v9 — LINEAR all→none, with correct max_level handling and short-set
// support.
//
// Fixes:
//   * max_level now caps the ACTUAL wardrobe (the machine never advances an
//     item past what would exceed max_level) — the display and the engine
//     always agree (previously the display clamped but the machine kept
//     undressing to level_4 behind the scenes).
//   * short counts: if the shot count is too small to complete every item
//     step, the generator still advances one step per shot and warns.
//   * the sequence stays strictly linear all→none within max_level.
// autoShots v10 — CONTINUOUS undressing (the core restored).
//
// Regression fixed: v8/v9 spread the advances so thin (every Nth shot) that
// most shots were holds with identical outfits — undressing was invisible.
// Now the default "undress narrative" advances ONE item EVERY shot, cycling
// items in order, so the outfit visibly progresses shot-by-shot until all off
// (or max_level reached); the remaining shots stay at the final state with
// full zone/pose/framing variety. Zones are reused — each revisit has a
// progressed outfit.
function autoShots(api, n) {
  // MetArt sequencing (v14) — VARIETY FIRST
  //  - Tease arc: ONE shot per clothing state (state changes every shot)
  //  - Extra budget: more poses at important beats (open, first lift, panties, nude)
  //  - EVERY consecutive shot must differ in pose id and preferably framing
  //  - Zone still changes when the focus garment changes
  const { st, _DATA } = api;
  const zones = locZones(st, _DATA);
  const items = clothItems(st, _DATA);
  if (!zones.length) {
    flash(api, "⚠ pick a location first", true);
    return 0;
  }
  if (!st.clothing) {
    flash(api, "⚠ pick a clothing set (use Nude Bare Start for fully nude)", true);
    return 0;
  }
  const framings = _DATA.framing || [];
  const mode = nodeChoice(api, "gallery_mode", "undress narrative");
  const maxLevel = Math.max(0, Math.min(4, nodeInt(api, "max_level", 4)));
  const target = Math.max(1, n);

  const removedStates = (() => {
    const c = (_DATA.clothing || []).find(x => x.name === st.clothing);
    return (c && c.removed_states) || REMOVED_DEFAULT;
  })();

  const preferIntimate = (z) => {
    // Works for 1-zone shower sets and 5-zone apartments alike:
    // score by zone name + how many intimate pieces the zone actually has.
    const id = ((z.zone_id || z.name || "") + " " + (z.description || "")).toLowerCase();
    let score = 0;
    if (/bed|sofa|couch|daybed|chaise/.test(id)) score += 6;
    if (/shower|bath|tub|spa|deck|lounger/.test(id)) score += 6;
    if (/floor|rug|mat|tatami/.test(id)) score += 4;
    if (/window|mirror|vanity/.test(id)) score += 2;
    if (/door|entry|kitchen|desk|hall/.test(id)) score -= 2;
    const pcs = z.prompt_pieces || z.pieces || [];
    let intimatePcs = 0;
    for (let i = 0; i < pcs.length; i++) {
      const stg = ((pcs[i].stage || pcs[i].type || "") + " " + (pcs[i].id || "")).toLowerCase();
      if (/intimate|presenting|leg_pose|glamour|gl\d/.test(stg)) intimatePcs += 1;
    }
    score += Math.min(8, Math.floor(intimatePcs / 5));
    return score;
  };
  // Sort high-intimate first — primary undress + first nude block use best zone
  // regardless of whether location has 1, 2, or 5 zones.
  const zonesIntro = zones.slice().sort((a, b) => preferIntimate(b) - preferIntimate(a));
  const zonesNude = zonesIntro.slice(0, Math.min(2, zonesIntro.length));

  const machineKeys = items.map(it => it.item_id || it.name);
  // Nude-from-start: no garments (or only accessories treated as optional)
  if (!machineKeys.length) {
    const preferIntimate = (z) => {
      const id = ((z.zone_id || z.name || "") + "").toLowerCase();
      let score = 0;
      if (/shower|bed|sofa|bath|deck|rug|floor/.test(id)) score += 5;
      if (/window|mirror/.test(id)) score += 2;
      return score;
    };
    const zonesNude = zones.slice().sort((a, b) => preferIntimate(b) - preferIntimate(a));
    const useZones = zonesNude.slice(0, Math.min(2, zonesNude.length));
    st.shots = [];
    st.shotPage = 0;
    let lastPiece = "";
    const nsBlock = Math.ceil(target * 0.55);
    for (let j = 0; j < target; j++) {
      // solid blocks: first ~55% zone0, rest zone1 — no interleave
      const zone = useZones[j < nsBlock ? 0 : Math.min(1, useZones.length - 1)];
      const zid = zone.zone_id || zone.name;
      const lvl = "level_4";
      const avoid = lastPiece ? [lastPiece] : [];
      let piece = (typeof pickPieceAvoid === "function")
        ? pickPieceAvoid(api, st.location, zone, lvl, avoid)
        : pickPiece(api, st.location, zone, lvl);
      if (!piece || !piece.id) piece = pickPiece(api, st.location, zone, lvl) || {};
      lastPiece = piece.id || ("p" + j);
      const framing = pickFraming(api, framings, piece, j);
      st.shots.push({
        zone: zid,
        piece: piece.id || "",
        framing,
        mode: "custom",
        custom: {},
        transition: "none",
        note: "nude start — " + ((zid || "") + "").toLowerCase(),
      });
    }
    flash(api, `✓ v14 nude-start ${st.shots.length} shots · 0 garments · ${useZones.map(z => z.zone_id || z.name).join(", ")}`);
    return st.shots.length;
  }

  const stateLists = {};
  items.forEach(it => {
    const key = it.item_id || it.name;
    let states = Array.isArray(it.states) ? it.states.slice() : [];
    if (states.length && typeof states[0] === "object") {
      states = states.map(s => s.state_id || s.id || s.name).filter(Boolean);
    }
    if (!states.length) states = ["fully_worn", "removed"];
    stateLists[key] = states;
  });

  // Full clothing timeline (1 entry = 1 unique outfit map)
  const timeline = [];
  const cur = {};
  machineKeys.forEach(k => { cur[k] = stateLists[k][0]; });
  timeline.push({ map: Object.assign({}, cur), phase: "dressed", focus: null, state: "fully_worn" });

  for (const key of machineKeys) {
    const states = stateLists[key];
    for (let si = 1; si < states.length; si++) {
      if (states[si] === "in_hand") continue; // in_hand causes ghost clothing in prompts
      cur[key] = states[si];
      const rem = machineKeys.filter(k => removedStates.includes(cur[k])).length;
      if (rem > maxLevel) break;
      timeline.push({
        map: Object.assign({}, cur),
        phase: removedStates.includes(states[si]) ? "removed" : "tease",
        focus: key,
        state: states[si],
      });
    }
  }

  const nStates = timeline.length;

  // Build recipe: primary = 1 shot per timeline state (guaranteed progression)
  // Extra shots inserted as VARIETY at key beats (different pose, same clothes)
  const recipe = [];
  // MetArt-style: entire undress sequence stays in ONE zone (no jumping).
  // Second zone used only later as one solid nude block.
  const primaryZone = zonesIntro[0];
  const secondaryZone = zonesIntro.length > 1 ? zonesIntro[1] : zonesIntro[0];
  function zoneFor(focus) {
    return primaryZone;
  }

  // How many extra variety shots we can afford beyond 1-per-state
  const extraBudget = Math.max(0, target - nStates);
  // Distribute extras: open, mid-tease anchors, nude
  let extraOpen = Math.min(4, Math.floor(extraBudget * 0.15));
  let extraNude = Math.min(Math.floor(extraBudget * 0.45), Math.max(6, Math.floor(target * 0.25)));
  let extraTease = Math.max(0, extraBudget - extraOpen - extraNude);

  // Opening: 1 + extras at fully dressed
  const openZone = zonesIntro[0];
  const openCount = 1 + extraOpen;
  for (let i = 0; i < openCount && recipe.length < target; i++) {
    recipe.push({
      map: timeline[0].map,
      zone: openZone,
      note: i === 0 ? "opening — fully dressed" : "variety — dressed new pose",
      focus: null,
      state: "fully_worn",
    });
  }

  // Tease: exactly 1 shot per remaining timeline state, plus sparse variety extras
  // Spread extraTease across states (at most +1 per state so clothes still advance often)
  const teaseStates = timeline.slice(1);
  const extraPer = teaseStates.length ? Math.floor(extraTease / teaseStates.length) : 0;
  let extraRem = extraTease - extraPer * teaseStates.length;

  for (let ti = 0; ti < teaseStates.length && recipe.length < target - Math.max(2, extraNude); ti++) {
    const step = teaseStates[ti];
    const z = zoneFor(step.focus);
    const copies = 1 + extraPer + (extraRem > 0 ? 1 : 0);
    if (extraRem > 0) extraRem -= 1;
    for (let h = 0; h < copies && recipe.length < target - Math.max(2, extraNude); h++) {
      recipe.push({
        map: step.map,
        zone: z,
        note: h === 0
          ? ("undress — " + (step.focus || "?") + " → " + (step.state || ""))
          : ("variety — " + (step.focus || "") + " → " + (step.state || "") + " new pose"),
        focus: step.focus,
        state: step.state,
      });
    }
  }

  // Nude: SOLID zone blocks — first ~55% primary, rest secondary (no interleave)
  const finalMap = timeline[timeline.length - 1].map;
  const nudeTotal = Math.max(0, target - recipe.length);
  const blockA = Math.ceil(nudeTotal * 0.55);
  let nudeI = 0;
  while (recipe.length < target) {
    const z = (nudeI < blockA) ? primaryZone : secondaryZone;
    recipe.push({
      map: finalMap,
      zone: z,
      note: "nude variety — " + ((z.zone_id || z.name || "") + "").toLowerCase() + " #" + (nudeI + 1),
      focus: null,
      state: "nude",
    });
    nudeI += 1;
  }

  // Materialize — hard guarantee: consecutive shots never share the same piece id
  st.shots = [];
  let lastPieceId = "";
  let lastFraming = "";
  const usedGlobal = [];

  for (let j = 0; j < recipe.length; j++) {
    const r = recipe[j];
    const zone = r.zone;
    const zid = zone.zone_id || zone.name;
    const map = r.map;
    const lvl = computeLevel(st.clothing, map, _DATA);

    // avoid last piece + recent global pieces
    const avoid = [lastPieceId].concat(usedGlobal.slice(-80)).filter(Boolean);
    const isNude = (r.state === "nude") || /nude variety|nude start/.test(r.note || "");
    const isLateTease = /removed|at_waist|pulled_aside|cups_pulled|presenting/.test(r.note || "");
    const preferMode = isNude ? "intimate" : (isLateTease ? "glamour" : null);
    let piece = pickPieceAvoid(api, st.location, zone, lvl, avoid, preferMode);
    if (!piece || !piece.id) piece = pickPiece(api, st.location, zone, lvl) || {};
    // if still same as last, try full pool without level filter once
    if (piece && piece.id && piece.id === lastPieceId) {
      const all = zonePiecesIn(api, st.location, zid) || [];
      const alt = all.find(p => p.id !== lastPieceId);
      if (alt) piece = alt;
    }
    lastPieceId = (piece && piece.id) || ("x" + j);
    usedGlobal.push(lastPieceId);

    let framing = pickFraming(api, framings, piece, j);
    // Rotate only inside full-body/scene pool — never the full framing list
    if (framing && framing === lastFraming && framings.length > 1) {
      const preferIds = ["full_body", "medium_full", "environmental_portrait", "negative_space",
                         "from_behind", "rear", "rear_three_quarter", "profile", "three_quarter",
                         "elevated_three_quarter", "low_angle", "high_angle", "wide_scene",
                         "medium", "over_shoulder", "diagonal", "rule_of_thirds"];
      const pool = preferIds
        .map(id => framings.find(f => ((f.id || f.name || "") + "").toLowerCase() === id))
        .filter(Boolean);
      const use = pool.length ? pool : framings;
      const cur = use.findIndex(f => (f.id || f.name) === framing);
      const nxt = use[(Math.max(cur, 0) + 1) % use.length];
      framing = (nxt && (nxt.id || nxt.name)) || framing;
    }
    lastFraming = framing || "";

    st.shots.push({
      zone: zid,
      piece: (piece && piece.id) || "",
      framing,
      mode: "custom",
      custom: Object.assign({}, map),
      transition: "none",
      note: r.note || "",
    });
  }

  // Stats for flash
  let clothingChanges = 0;
  let poseChanges = 0;
  for (let i = 1; i < st.shots.length; i++) {
    const a = st.shots[i - 1], b = st.shots[i];
    const sig = (s) => Object.keys(s.custom || {}).sort().map(k => k + "=" + s.custom[k]).join(";");
    if (sig(a) !== sig(b)) clothingChanges += 1;
    if (a.piece !== b.piece) poseChanges += 1;
  }
  flash(api, `✓ v14 ${st.shots.length} shots · ${clothingChanges} clothing changes · ${poseChanges} pose changes · ${nStates} states`);
  return st.shots.length;
}


/** Prefer pieces not in avoid list. */
function pickPieceAvoid(api, locname, zone, lvl, avoid, preferMode) {
  // preferMode "intimate"|"glamour" biases ending shots toward presenting/leg/glamour
  // pieces. Safe for 1-zone and 5-zone locations — only changes ranking, not filters.
  const pieces = zonePiecesIn(api, locname, zone.zone_id || zone.name);
  if (!pieces.length) return {};
  const have = parseInt(String(lvl || "level_0").split("_").pop(), 10);
  const lvlNum = Number.isFinite(have) ? have : 0;
  const compat = pieces.filter(p => {
    const levels = p.compatible_clothing_levels || p.levels || [];
    if (levels.length) return levels.includes(lvl) || levels.includes("level_" + lvlNum);
    const minL = p.min_level || p.minLevel;
    const maxL = p.max_level || p.maxLevel;
    let ok = true;
    if (minL) {
      const n = parseInt(String(minL).split("_").pop(), 10);
      if (Number.isFinite(n) && lvlNum < n) ok = false;
    }
    if (maxL) {
      const n = parseInt(String(maxL).split("_").pop(), 10);
      if (Number.isFinite(n) && lvlNum > n) ok = false;
    }
    return ok;
  });
  let pool = (compat.length ? compat : pieces).slice();
  const fresh = pool.filter(p => (avoid || []).indexOf(p.id) < 0);
  let use = fresh.length ? fresh : pool;

  // Nude: drop pieces that still talk about clothes (panties aside, bottoms mid-thigh…)
  if (preferMode === "intimate" || lvlNum >= 4 || lvl === "level_4") {
    const clothTalk = /panties|briefs|bra |waistband|neckline|strap|towel|dress|shorts|skirt|top |shirt|button|unbutton|fly open|bottoms pushed|hem |garment|fabric of the/;
    const cleaned = use.filter(p => !clothTalk.test((p.prompt || "").toLowerCase()));
    if (cleaned.length >= 3) use = cleaned;
  }

  if (preferMode === "intimate" || preferMode === "glamour") {
    const score = (p) => {
      const stage = ((p.stage || p.type || "") + " " + (p.id || "") + " " + (p.prompt || "")).toLowerCase();
      let s = 0;
      if (/presenting|intimate|leg_pose|butterfly|m pose|w pose|ass raised|hips high|bridge|all fours|spread/.test(stage)) s += 8;
      if (/finger|fingering|squeez|breast|nipple|pussy|labia|clit|spreading the|between the legs/.test(stage)) s += 12;
      if (/glamour|contrapposto|s-curve|seductive|erotic|look back|over the shoulder/.test(stage)) s += 5;
      if (/_a0|^a0|gl\d|^ix1[1-5]|^ix2/.test((p.id || "").toLowerCase())) s += 6;
      if (/stand still|standing still|hands relaxed at the sides/.test(stage)) s -= 3;
      if (/panties|bottoms pushed|waistband|bra cup|neckline/.test(stage)) s -= 10;
      return s;
    };
    use = use.slice().sort((a, b) => score(b) - score(a));
    const top = use.filter(p => score(p) >= 4);
    if (top.length >= 3) use = top;
  }

  api._zonePick = api._zonePick || {};
  const key = (locname || "") + "::" + (zone.zone_id || zone.name) + "::" + (lvl || "") + "::" + (preferMode || "any");
  const idx = (api._zonePick[key] || 0) % use.length;
  api._zonePick[key] = idx + 1;
  return use[idx] || pool[0] || {};
}


function autoShotCount(api) {
  const w = (api.node.widgets || []).find(x => x.name === "auto_shots");
  const n = w ? parseInt(w.value) : 5;
  return Number.isFinite(n) && n > 0 ? n : 5;
}

// ---------- status bar + feedback ----------
function flash(api, msg, isErr) {
  const el = api.editor.querySelector('[data-role="flash"]');
  if (!el) return;
  el.textContent = msg;
  el.className = "pe-flash" + (isErr ? " err" : "");
  clearTimeout(api._flashT);
  api._flashT = setTimeout(() => { el.textContent = ""; }, 4000);
}

function updateStatus(api) {
  const { st, _DATA } = api;
  const el = api.editor.querySelector('[data-role="status"]');
  if (!el) return;
  const levels = {};
  st.shots.forEach((_, i) => {
    const lvl = computeLevel(st.clothing, outfitMapOf(api, i), _DATA);
    levels[lvl] = (levels[lvl] || 0) + 1;
  });
  const hist = Object.entries(levels).sort().map(([l, c]) => `${l}:${c}`).join(" ");
  const cam = (() => {
    const c = (api._DATA.cameras || []).find(x => x.id === st.camera);
    return c ? `${c.brand} ${c.model}` : "no camera";
  })();
  // live availability summary of the CURRENT location's data (intelligence)
  let avail = "";
  const allLocs = (api._DATA.locations || []).length;
  const loc = (api._DATA.locations || []).find(l => l.name === st.location);
  if (loc) {
    const zones = loc.zones || [];
    const poses = zones.reduce((a, z) => a + (z.pieces ? z.pieces.length : 0), 0);
    avail = `<span style="color:#7c8798">${zones.length} zones · ${poses} poses</span>` +
            `<span style="color:#6ea8fe">· ${allLocs} locations total</span>`;
  } else {
    avail = `<span style="color:#7c8798">${allLocs} locations · ${(api._DATA.clothing || []).length} sets · ${(api._DATA.cameras || []).length} cams</span>`;
  }
  el.innerHTML = `<span class="pe-count">${st.shots.length} shots</span>
    <span><b>${st.model || "?"}</b></span>
    <span>${st.location || "?"} · ${st.clothing || "?"}</span>
    <span>${cam}</span>
    <span>${st.style || "?"} · ${st.quality || "?"}</span>
    <span>seed ${st.seed}</span>
    ${avail}
    <span style="color:#7c8798">${hist}</span>
    <span data-role="flash" class="pe-flash" style="flex-basis:100%"></span>`;
}

// ---------- build the editor DOM ----------
function buildEditor(host, node, planWidget, DATA) {
  const st = newState();
  st.model = DATA.models[0] || "";
  st.location = DATA.locations[0] ? DATA.locations[0].name : "";
  st.clothing = DATA.clothing[0] ? DATA.clothing[0].name : "";
  st.camera = DATA.cameras[0] ? DATA.cameras[0].id : "";
  // start EMPTY — no default shots

  const editor = document.createElement("div");
  editor.className = "asb-pe";
  host.appendChild(editor);
  const api = { editor, st, host, node, planWidget, _DATA: DATA, _flashT: null };

  editor.innerHTML = `
    <div class="pe-head">
      <button class="pe-toggle" data-act="toggle">▾ Plan editor</button>
      <span style="flex:1"></span>
      <span class="pe-note" data-role="count"></span>
    </div>
    <div data-role="body" style="display:flex; flex-direction:column; flex:1; min-height:0;">
      <div class="pe-status" data-role="status"></div>
      <div class="pe-grid">
        <div><label>Title</label><input type="text" data-f="title"></div>
        <div><label>Seed</label><input type="number" data-f="seed"></div>
        <div><label>Camera (all shots)</label><select data-f="camera"></select></div>
        <div><label>Model</label><select data-f="model"></select></div>
        <div><label>Location</label><select data-f="location"></select></div>
        <div><label>Clothing set</label><select data-f="clothing"></select></div>
        <div><label>Piercing</label><select data-f="piercing"></select></div>
        <div><label>Tattoo</label><select data-f="tattoo"></select></div>
        <div><label>Style</label><select data-f="style"></select></div>
        <div><label>Quality</label><select data-f="quality"></select></div>
      </div>
      <div class="pe-toolbar">
        <button data-act="add">＋ Shot</button>
        <button data-act="undress">🧩 Auto <span data-role="auton">–</span> shots</button>
        <button data-act="sample">Sample</button>
        <button data-act="load">⟳ Load from plan</button>
        <button data-act="save">💾 Save file</button>
        <button data-act="loadfile">📂 Load file</button>
        <button data-act="server">☁️ Server</button>
        <button data-act="refresh">↻ Refresh data</button>
        <button data-act="clear">🧹 Clear</button>
        <span style="flex:1"></span>
        <button class="pe-primary" data-act="apply">✓ Apply to node</button>
      </div>
      <div class="pe-server" data-role="server" style="display:none">
        <div class="pe-server-row">
          <input type="text" data-f="serverName" placeholder="plan name (default: asb_plan_&lt;title&gt;_&lt;date&gt;.yaml)">
          <button data-act="serversave">☁️ Save to server</button>
          <button data-act="serverrefresh">⟳</button>
        </div>
        <div data-role="serverlist" class="pe-serverlist"></div>
      </div>
      <div class="pe-shots" data-role="shots"></div>
      <div class="pe-foot-note" data-role="scrollnote"></div>
      <div class="pe-out">
        <button class="pe-toggle" data-act="toggleout">▸ Output preview</button>
        <button data-act="outcopy">📋 Copy plan_json</button>
        <button data-act="outrefresh">⟳ Expand</button>
        <span class="pe-note" data-role="outcount"></span>
        <pre class="pe-outbody" data-role="outbody"></pre>
      </div>
    </div>
  `;

  const sel = (name, options, fallback) => {
    const el = editor.querySelector(`select[data-f="${name}"]`);
    el.innerHTML = options.map(o => `<option value="${o.value}" ${o.value === fallback ? "selected" : ""}>${o.label}</option>`).join("");
    el.onchange = () => {
      const wasLocation = name === "location";
      const wasClothing = name === "clothing";
      st[name] = el.value;
      // Do NOT auto-rebuild the plan on location/clothing change —
      // that wiped the user's shots. Only update selection; user runs Auto.
      if ((wasLocation || wasClothing) && st.shots && st.shots.length) {
        flash(api, "✓ " + (wasClothing ? "clothing" : "location") +
          " updated — existing plan kept. Click Auto to rebuild for the new set.", false);
      }
      renderAll(api);
    };
    return el;
  };
  sel("model", DATA.models.map(m => ({ value: m, label: m })), st.model);
  sel("location", DATA.locations.map(l => ({ value: l.name, label: l.label || l.name })), st.location);
  sel("clothing", DATA.clothing.map(c => ({ value: c.name, label: c.label || c.name })), st.clothing);
  const pierOpts = (DATA.piercings || [{id:"none",label:"None"}]).map(p => ({
    value: p.id || p.value || "none", label: p.label || p.id || "None"
  }));
  const tatOpts = (DATA.tattoos || [{id:"none",label:"None"}]).map(p => ({
    value: p.id || p.value || "none", label: p.label || p.id || "None"
  }));
  sel("piercing", pierOpts, st.piercing || "none");
  sel("tattoo", tatOpts, st.tattoo || "none");
  sel("style", DATA.styles.map(s => ({ value: s, label: s })), st.style);
  sel("quality", DATA.qualities.map(q => ({ value: q, label: q })), st.quality);
  const camEl = editor.querySelector('select[data-f="camera"]');
  const camOpts = [{ value: "", label: "— none —" }].concat(
    (DATA.cameras || []).map(c => ({ value: c.id, label: `${c.brand} ${c.model} (${c.id})` })));
  camEl.innerHTML = camOpts.map(o => `<option value="${o.value}" ${o.value === st.camera ? "selected" : ""}>${o.label}</option>`).join("");
  camEl.onchange = () => { st.camera = camEl.value; updateStatus(api); };
  editor.querySelector('input[data-f="title"]').onchange = e => { st.title = e.target.value; updateStatus(api); };
  editor.querySelector('input[data-f="seed"]').onchange = e => { st.seed = parseInt(e.target.value) || 1; updateStatus(api); };

  // header toggle (fixed heights — never grows)
  let expanded = true;
  editor.querySelector('[data-act="toggle"]').onclick = () => {
    expanded = !expanded;
    editor.querySelector('[data-role="body"]').style.display = expanded ? "flex" : "none";
    editor.querySelector('[data-act="toggle"]').textContent = expanded ? "▾ Plan editor" : "▸ Plan editor";
    node.setSize([node.size[0], expanded ? Math.min(Math.max(node.size[1], MIN_NODE_H), MAX_NODE_H) : 110]);
    if (node.graph) node.graph.setDirtyCanvas(true, true);
  };

  // defensive wiring: one missing element must never kill the rest
  const on = (sel, fn) => { const el = editor.querySelector(sel); if (el) el.onclick = fn; };
  on('[data-act="add"]', () => { addShot(api); renderAll(api); });
  on('[data-act="undress"]', () => {
    autoShots(api, autoShotCount(api)); renderAll(api);
  });
  on('[data-act="sample"]', () => {
    const sample = buildSamplePlan(api._DATA);
    if (!sample) { flash(api, "⚠ need at least one location + clothing set to build a sample", true); return; }
    const obj = parsePlanText(sample);
    applyParsed(api, obj);
    flash(api, `✓ sample plan loaded (${api.st.shots.length} shots, from your data)`);
    renderAll(api);
  });
  on('[data-act="load"]', () => loadFromPlan(api, planWidget));
  on('[data-act="save"]', () => savePlanToFile(api));
  on('[data-act="loadfile"]', () => loadPlanFromFile(api));
  on('[data-act="refresh"]', async () => {
    flash(api, "↻ reloading data…");
    try {
      const { data: fresh } = await loadEditorData();
      if (!fresh || !fresh.locations || !fresh.locations.length) throw new Error("empty data");
      api._DATA = fresh;
      // re-fill the model/location/clothing/style/quality/camera selects
      const fill = (name, opts, cur) => {
        const el = editor.querySelector(`select[data-f="${name}"]`);
        if (!el) return;
        const keep = cur || st[name];
        el.innerHTML = opts.map(o => `<option value="${o.value}" ${o.value === keep ? "selected" : ""}>${o.label}</option>`).join("");
        st[name] = keep && opts.some(o => o.value === keep) ? keep : (opts[0] ? opts[0].value : "");
      };
      fill("model", (fresh.models || []).map(m => ({ value: m, label: m })), st.model);
      fill("location", (fresh.locations || []).map(l => ({ value: l.name, label: l.label || l.name })), st.location);
      fill("clothing", (fresh.clothing || []).map(c => ({ value: c.name, label: c.label || c.name })), st.clothing);
      fill("style", (fresh.styles || []).map(s => ({ value: s, label: s })), st.style);
      fill("quality", (fresh.qualities || []).map(q => ({ value: q, label: q })), st.quality);
      const camEl = editor.querySelector('select[data-f="camera"]');
      if (camEl) {
        const cOpts = [{ value: "", label: "— none —" }].concat((fresh.cameras || []).map(c => ({ value: c.id, label: `${c.brand} ${c.model} (${c.id})` })));
        camEl.innerHTML = cOpts.map(o => `<option value="${o.value}" ${o.value === st.camera ? "selected" : ""}>${o.label}</option>`).join("");
        st.camera = st.camera && cOpts.some(o => o.value === st.camera) ? st.camera : "";
      }
      // re-map any shots that referenced now-missing ids
      remapShotsForLocation(api);
      clearStaleCustom(api);
      renderAll(api);
      flash(api, `✓ data refreshed — ${(fresh.locations || []).length} locations · ${(fresh.clothing || []).length} sets · ${(fresh.models || []).length} models · ${(fresh.cameras || []).length} cams`);
    } catch (e) {
      console.warn("[ASB] refresh data:", e);
      flash(api, "⚠ could not refresh — run scripts/export_planner_data.py, restart ComfyUI, then refresh the browser", true);
    }
  });
  on('[data-act="clear"]', () => clearAll(api));
  on('[data-act="apply"]', () => {
    applyToNode(api, planWidget);
    // open the preview so the user sees the expanded result right away
    if (!outOpen) editor.querySelector('[data-act="toggleout"]').click();
  });

  // output preview toggle
  const outBody = editor.querySelector('[data-role="outbody"]');
  let outOpen = false;
  on('[data-act="toggleout"]', () => {
    outOpen = !outOpen;
    const b = editor.querySelector('[data-role="outbody"]');
    const t = editor.querySelector('[data-act="toggleout"]');
    if (b) b.style.display = outOpen ? "" : "none";
    if (t) t.textContent = outOpen ? "▾ Output preview" : "▸ Output preview";
    renderOutputPreview(api, null);
    if (outOpen) debouncedExpand(api);
    if (node.graph) node.graph.setDirtyCanvas(true, true);
  });
  on('[data-act="outcopy"]', async () => {
    const txt = api._serverPlanJson || buildYAML(api.st);
    try { await navigator.clipboard.writeText(txt); flash(api, "✓ plan_json copied"); }
    catch (e) { flash(api, "⚠ copy failed", true); }
  });
  on('[data-act="outrefresh"]', () => expandPreviewClient(api));

  // server panel
  const serverPanel = editor.querySelector('[data-role="server"]');
  let serverOpen = false;
  on('[data-act="server"]', () => {
    serverOpen = !serverOpen;
    if (serverPanel) serverPanel.style.display = serverOpen ? "" : "none";
    if (serverOpen) {
      const nm = editor.querySelector('input[data-f="serverName"]');
      if (nm && !nm.value) nm.value = defaultServerName(api);
      refreshServerList(api);
    }
    if (node.graph) node.graph.setDirtyCanvas(true, true);
  });
  on('[data-act="serversave"]', () => savePlanToServer(api));
  on('[data-act="serverrefresh"]', () => refreshServerList(api));

  return api;
}

function resetPieces(api) { for (const s of api.st.shots) { s.piece = ""; s.custom = {}; } }

// When the user switches LOCATION, existing shots keep the OLD zone ids (and
// pieces) which makes the whole plan fail to expand -> "empty plan_json".
// Re-map every shot to the NEW location: zone rotates through the new zones,
// piece = a pose compatible with the shot's current outfit level.
function remapShotsForLocation(api) {
  const zones = locZones(api.st, api._DATA);
  if (!zones.length) { api.st.shots = []; return; }
  // Keep MetArt-style blocks: same zone for ~8 consecutive shots
  const block = 8;
  api.st.shots.forEach((s, i) => {
    const z = zones[Math.floor(i / block) % zones.length];
    s.zone = z.zone_id || z.name;
    const pieces = zonePieces(api.st, api._DATA, s.zone);
    const lvl = computeLevel(api.st.clothing, outfitMapOf(api, i), api._DATA);
    const p = pieces.find(x => (x.levels || x.compatible_clothing_levels || []).includes(lvl)) || pieces[0] || {};
    s.piece = p.id || "";
  });
}

// When the user switches CLOTHING SET, any "custom" outfit maps hold OLD item
// ids -> those shots fail to expand. Reset them to inherit (no stale ids).
function clearStaleCustom(api) {
  api.st.shots.forEach(s => {
    s.custom = {};
    s.mode = "inherit";
    s.transition = "none";
  });
}

// Clear EVERYTHING: the shot list and the node's plan field.
function clearAll(api) {
  api.st.shots = [];
  api.st.shotPage = 0;
  try { writePlanWidget(api.node, ""); } catch (e) { console.warn("[ASB] clear plan:", e); }
  try {
    const ta = api.editor.querySelector('[data-role="outbody"]');
    if (ta) ta.textContent = "";
    const cnt = api.editor.querySelector('[data-role="outcount"]');
    if (cnt) cnt.textContent = "";
  } catch (e) {}
  renderAll(api);
  flash(api, "🧹 cleared shot list + plan field");
}
// default fields for a NEW shot so nothing is left blank:
//   zone    - cycles to the next zone (after the last shot's zone)
//   piece   - the first piece in that zone compatible with the level the shot
//             will be at (inherit -> previous outfit), else the zone's first
//   framing - auto-picked from the framing DB for the piece type (else "")
//   mode    - "inherit" (keeps the wardrobe state), transition "none"
//   note    - a default director's note
function defaultShotFields(api) {
  const { st, _DATA } = api;
  const zones = locZones(st, _DATA);
  const framings = _DATA.framing || [];
  if (!zones.length) return { zone: "", piece: "", framing: "", mode: "inherit", custom: {}, transition: "none", note: "" };
  // zone: cycle to the next zone after the last shot
  let zone = zones[0];
  if (st.shots.length) {
    const lastZone = st.shots[st.shots.length - 1].zone;
    const li = zones.findIndex(z => (z.zone_id || z.name) === lastZone);
    zone = zones[(li + 1) % zones.length] || zones[0];
  }
  const zid = zone.zone_id || zone.name;
  const pieces = zonePieces(st, _DATA, zid);
  // level this shot would be at (inherit previous outfit)
  const prevIdx = st.shots.length - 1;
  const prevMap = prevIdx >= 0 ? outfitMapOf(api, prevIdx) : null;
  const lvl = prevMap ? computeLevel(st.clothing, prevMap, _DATA) : "level_0";
  let piece = pieces.find(p => (p.levels || []).includes(lvl)) || pieces[0] || {};
  // framing: prefer a preset whose default_for_piece_types matches the pose
  const ptype = (piece.label || "").split("|")[1] ? (piece.label.split("|")[1] || "").trim() : "";
  const fhit = framings.find(f => (f.default_for_piece_types || []).includes(ptype));
  return {
    zone: zid,
    piece: piece.id || "",
    framing: fhit ? fhit.id : "",
    mode: "inherit",
    custom: {},
    transition: "none",
    note: autoNote(api, st.shots.length),
  };
}

function addShot(api) {
  api.st.shots.push(defaultShotFields(api));
}

function renderAll(api) {
  updateStatus(api);
  renderShots(api);
  // keep the Auto button label in sync with the node's auto_shots input
  const an = api.editor.querySelector('[data-role="auton"]');
  if (an) an.textContent = autoShotCount(api);
  // update the client mirror immediately, then the server engine (debounced)
  renderOutputPreview(api, null);
  debouncedExpand(api);
}

// ---------- live output preview (what the node will produce) ----------
function clientStoryboard(api) {
  const { st, _DATA } = api;
  const lines = [];
  lines.push(`SHOOT: ${st.title || "untitled"}`);
  lines.push(`MODEL: ${st.model || "-"}   LOCATION: ${st.location || "-"}   WARDROBE: ${st.clothing || "-"}`);
  const cam = (_DATA.cameras || []).find(x => x.id === st.camera);
  lines.push(`CAMERA: ${cam ? cam.brand + " " + cam.model : (st.camera || "-")}   SEED: ${st.seed}`);
  lines.push("");
  const removed = removedStatesOf(api);
  st.shots.forEach((s, i) => {
    const map = outfitMapOf(api, i);
    const lvl = computeLevel(st.clothing, map, _DATA);
    const offN = Object.values(map).filter(v => removed.includes(v)).length;
    const outcome = Object.entries(map).map(([k, v]) => `${k}=${v}`).join(" ");
    lines.push(
      `${String(i).padStart(2)}  ${(s.zone || "-").padEnd(10)}  ${(s.piece || "-").padEnd(12)}  ` +
      `${lvl.padEnd(8)} ${offN} off  ${(s.framing || "-").padEnd(12)} ${outcome}`);
  });
  return lines.join("\n");
}

// Expand the plan on the SERVER with the real Python engine (no queue, no
// sampler, no image generation). Fallback: client-side mirror if the route is
// unavailable (e.g. page opened outside ComfyUI).
async function expandPreviewClient(api) {
  const yaml = currentPlanText(api);
  const body = api.editor.querySelector('[data-role="outbody"]');
  if (!yaml) {
    if (body) body.textContent = "";
    const cnt = api.editor.querySelector('[data-role="outcount"]');
    if (cnt) cnt.textContent = "";
    return;
  }
  if (body) body.textContent = "expanding with server engine…";
  try {
    const r = await fetch("/asb/expand", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        plan: yaml,
        seed: api.st.seed,
        style: api.st.style,
        quality: api.st.quality,
        detail_level: "standard",
        auto_negative: true,
        template: "(none)",
        camera: api.st.camera,
        framing: "",
      }),
    });
    const res = await r.json();
    if (res && res.ok) {
      renderOutputPreview(api, res);
      return;
    }
    if (res && res.error) console.warn("[ASB] expand error:", res.error);
  } catch (e) { /* route unavailable */ }
  renderOutputPreview(api, null); // fallback: client mirror
}

function renderOutputPreview(api, serverRes) {
  const body = api.editor.querySelector('[data-role="outbody"]');
  const cnt = api.editor.querySelector('[data-role="outcount"]');
  if (!body) return;
  if (serverRes) {
    const n = serverRes.count || 0;
    body.textContent = serverRes.storyboard || "(no shots)";
    if (cnt) cnt.textContent = ` · ${n} shots (server engine)`;
    // stash the authoritative plan_json on the api for copy
    api._serverPlanJson = serverRes.plan_json || "";
    api._serverShotsCsv = serverRes.shots_csv || "";
    return;
  }
  if (api.st.shots.length) {
    body.textContent = clientStoryboard(api);
    if (cnt) cnt.textContent = ` · ${api.st.shots.length} shots (client mirror)`;
  } else {
    body.textContent = "";
    if (cnt) cnt.textContent = "";
  }
}

function debouncedExpand(api) {
  clearTimeout(api._expandT);
  api._expandT = setTimeout(() => expandPreviewClient(api), 450);
}

function renderShots(api) {
  const { editor, st, _DATA } = api;
  const host = editor.querySelector('[data-role="shots"]');
  host.innerHTML = "";
  const items = clothItems(st, _DATA);
  const zones = locZones(st, _DATA);
  const framings = _DATA.framing || [];
  const removed = removedStatesOf(api);

  if (!st.shots.length) {
    host.innerHTML = `<div class="pe-empty">No shots yet — click "＋ Shot" to add one, or "🧩 Auto N shots" to generate an undress sequence from the location + wardrobe.</div>`;
    const note0 = editor.querySelector('[data-role="scrollnote"]');
    if (note0) note0.innerHTML = "";
    updateStatus(api);
    return;
  }

  // Pagination: 10 shots per page
  if (typeof st.shotPage !== "number" || st.shotPage < 0) st.shotPage = 0;
  const totalPages = Math.max(1, Math.ceil(st.shots.length / SHOTS_PER_PAGE));
  if (st.shotPage >= totalPages) st.shotPage = totalPages - 1;
  const pageStart = st.shotPage * SHOTS_PER_PAGE;
  const pageEnd = Math.min(st.shots.length, pageStart + SHOTS_PER_PAGE);

  for (let i = pageStart; i < pageEnd; i++) {
    const s = st.shots[i];
    const map = outfitMapOf(api, i);
    const lvl = computeLevel(st.clothing, map, _DATA);
    const z = zones.find(x => (x.zone_id || x.name) === s.zone) || zones[0];
    const pieces = zonePieces(st, _DATA, z ? (z.zone_id || z.name) : "");
    const removedN = Object.values(map).filter(v => removed.includes(v)).length;

    // the EXACT prompt words this shot will use: the piece's `prompt` field +
    // the clothing `prompt_phrase` for the current states (from your data files)
    const pObj = pieces.find(p => p.id === s.piece) || pieces[0] || {};
    const promptWords = pObj.prompt || "";
    const clothWords = items.map(it => {
      const k = it.item_id || it.name;
      const curSt = map[k];
      const ph = it.state_phrases && it.state_phrases[curSt];
      return ph || "";
    }).filter(Boolean).join(", ");
    const promptPreview = [promptWords, clothWords].filter(Boolean).join(" — ");

    const card = document.createElement("div");
    card.className = "pe-shot";
    card.innerHTML = `
      <div class="pe-shot-top">
        <span class="pe-no">${i}</span>
        <span class="pe-lvl l${lvl.split("_")[1]}">${lvl} · ${removedN} off</span>
        <span style="flex:1"></span>
        <button class="pe-ic" data-ic="up">↑</button>
        <button class="pe-ic" data-ic="down">↓</button>
        <button class="pe-ic" data-ic="del">✕</button>
      </div>
      <div class="pe-row">
        <div><label>Zone</label><select data-f="zone"></select></div>
        <div><label>Pose</label><select data-f="piece"></select></div>
        <div><label>Outfit</label><select data-f="mode">
          <option value="inherit">inherit prev</option>
          <option value="fully_worn">all on</option>
          <option value="removed">all off</option>
          <option value="custom">custom…</option>
        </select></div>
      </div>
      <div class="pe-row2">
        <div><label>Framing / angle</label><select data-f="framing">
          <option value="">— auto / default —</option>
          <option value="__custom__">custom…</option>
        </select><input type="text" data-f="framingCustom" placeholder="e.g. low angle" style="display:none;margin-top:2px"></div>
        <div><label>Transition</label><select data-f="transition">
          <option value="none">— none —</option>
          <option value="reset">reset (all on)</option>
        </select></div>
      </div>
      <div data-role="custom"></div>
    `;

    const zsel = card.querySelector('select[data-f="zone"]');
    zones.forEach(zd => {
      const v = zd.zone_id || zd.name;
      const o = document.createElement("option");
      o.value = v; o.textContent = zd.name; o.selected = v === s.zone;
      zsel.appendChild(o);
    });
    zsel.onchange = () => { s.zone = zsel.value; s.piece = ""; renderShots(api); };

    const psel = card.querySelector('select[data-f="piece"]');
    pieces.forEach(p => {
      const o = document.createElement("option");
      o.value = p.id; o.textContent = p.label; o.selected = p.id === s.piece;
      psel.appendChild(o);
    });
    psel.onchange = () => { s.piece = psel.value; };

    const msel = card.querySelector('select[data-f="mode"]');
    msel.value = s.mode;
    msel.onchange = () => { s.mode = msel.value; if (s.mode !== "inherit") s.transition = "none"; renderShots(api); };

    const fsel = card.querySelector('select[data-f="framing"]');
    framings.forEach(f => {
      const o = document.createElement("option");
      o.value = f.id; o.textContent = `${f.name} (${f.id})`; o.selected = f.id === s.framing;
      fsel.appendChild(o);
    });
    const fCustom = card.querySelector('input[data-f="framingCustom"]');
    const isCustom = s.framing && !framings.some(f => f.id === s.framing);
    fsel.value = isCustom ? "__custom__" : (s.framing || "");
    fCustom.style.display = isCustom ? "" : "none";
    fCustom.value = isCustom ? s.framing : "";
    fsel.onchange = () => {
      if (fsel.value === "__custom__") { fCustom.style.display = ""; fCustom.focus(); s.framing = fCustom.value; }
      else { fCustom.style.display = "none"; s.framing = fsel.value; }
      renderShots(api);
    };
    fCustom.onchange = () => { s.framing = fCustom.value; };

    const tsel = card.querySelector('select[data-f="transition"]');
    const transOpts = [["none", "— none —"], ["reset", "reset (all on)"]];
    items.forEach(it => {
      const id = it.item_id || it.name;
      transOpts.push([`advance: ${id}`, `advance: ${it.name}`]);
      transOpts.push([`remove: ${id}`, `remove: ${it.name}`]);
      transOpts.push([`dress: ${id}`, `dress: ${it.name}`]);
      it.states.forEach(stt => transOpts.push([`set: ${id} -> ${stt}`, `set: ${it.name} -> ${stt}`]));
    });
    transOpts.forEach(([v, label]) => {
      const o = document.createElement("option");
      o.value = v; o.textContent = label; o.selected = v === s.transition;
      tsel.appendChild(o);
    });
    tsel.onchange = () => { s.transition = tsel.value; if (s.transition !== "none") s.mode = "inherit"; renderShots(api); };

    // prompt-words preview (the fields from your data that generation uses)
    const pv = document.createElement("div");
    pv.className = "pe-prompt";
    pv.textContent = promptPreview ? "prompt: " + promptPreview : "prompt: (no data text for this piece)";
    card.appendChild(pv);


    const customBox = card.querySelector('[data-role="custom"]');
    if (s.mode === "custom") {
      customBox.className = "pe-custom";
      items.forEach(it => {
        const k = it.item_id || it.name;
        const wrap = document.createElement("div");
        wrap.innerHTML = `<label>${it.name}</label><select></select>`;
        const sel2 = wrap.querySelector("select");
        sel2.appendChild(new Option("inherit", ""));
        it.states.forEach(stt => sel2.appendChild(new Option(stt, stt)));
        sel2.value = s.custom[k] || "";
        sel2.onchange = () => { s.custom[k] = sel2.value; renderShots(api); };
        customBox.appendChild(wrap);
      });
    }

    card.querySelector('[data-ic="up"]').onclick = () => { if (i > 0) { const t = st.shots[i]; st.shots[i] = st.shots[i-1]; st.shots[i-1] = t; renderAll(api); } };
    card.querySelector('[data-ic="down"]').onclick = () => { if (i < st.shots.length - 1) { const t = st.shots[i]; st.shots[i] = st.shots[i+1]; st.shots[i+1] = t; renderAll(api); } };
    card.querySelector('[data-ic="del"]').onclick = () => { st.shots.splice(i, 1); renderAll(api); };

    host.appendChild(card);
  }

  // One page of cards — no endless scroll list
  host.style.maxHeight = `${SHOTS_PER_PAGE * 112}px`;
  host.style.overflowY = "auto";

  // Pagination controls
  const note = editor.querySelector('[data-role="scrollnote"]');
  if (note) {
    if (st.shots.length <= SHOTS_PER_PAGE) {
      note.innerHTML = `<span>${st.shots.length} shots</span>`;
    } else {
      note.innerHTML = `
        <button type="button" data-act="page-first" title="First page">«</button>
        <button type="button" data-act="page-prev" title="Previous">‹ Prev</button>
        <span style="margin:0 8px;font-weight:600">
          shots ${pageStart + 1}–${pageEnd} / ${st.shots.length}
          · page ${st.shotPage + 1} / ${totalPages}
        </span>
        <button type="button" data-act="page-next" title="Next">Next ›</button>
        <button type="button" data-act="page-last" title="Last page">»</button>
        <input type="number" data-act="page-goto" min="1" max="${totalPages}"
          value="${st.shotPage + 1}" title="Go to page"
          style="width:48px;margin-left:8px;background:#1c2230;color:#dfe5ee;border:1px solid #3a4458;border-radius:4px;padding:2px 4px">
      `;
      const go = (p) => {
        st.shotPage = Math.max(0, Math.min(totalPages - 1, p));
        renderShots(api);
      };
      note.querySelector('[data-act="page-first"]').onclick = () => go(0);
      note.querySelector('[data-act="page-prev"]').onclick = () => go(st.shotPage - 1);
      note.querySelector('[data-act="page-next"]').onclick = () => go(st.shotPage + 1);
      note.querySelector('[data-act="page-last"]').onclick = () => go(totalPages - 1);
      const gi = note.querySelector('[data-act="page-goto"]');
      gi.onchange = () => go((parseInt(gi.value, 10) || 1) - 1);
      gi.onkeydown = (e) => { if (e.key === "Enter") go((parseInt(gi.value, 10) || 1) - 1); };
    }
  }
  updateStatus(api);
}

function planSlug(st) {
  const s = String(st.title || "shoot").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
  return s || "shoot";
}

// ---------- save / load plan files (browser download + file picker) ----------
function savePlanToFile(api) {
  let yaml = "";
  if (api.st.shots.length) yaml = buildYAML(api.st);
  else if (api.planWidget && api.planWidget.value) yaml = api.planWidget.value;
  if (!yaml) { flash(api, "⚠ nothing to save — add shots first", true); return; }
  try {
    const blob = new Blob([yaml], { type: "text/yaml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `asb_plan_${planSlug(api.st)}_${new Date().toISOString().slice(0, 10)}.yaml`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    const n = api.st.shots.length ? api.st.shots.length : "(plan text)";
    flash(api, `✓ plan saved to file (${n} shots)`);
  } catch (e) {
    console.warn("[ASB] save file:", e);
    flash(api, "⚠ save failed: " + e.message, true);
  }
}

function loadPlanFromFile(api) {
  if (!api._fileInput) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".yaml,.yml,.json,.txt";
    input.style.display = "none";
    document.body.appendChild(input);
    api._fileInput = input;
    input.onchange = () => {
      const f = input.files && input.files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const obj = parsePlanText(String(reader.result || ""));
          if (!obj.shots || !obj.shots.length) throw new Error("no shots found");
          applyParsed(api, obj);
          renderAll(api);
          flash(api, `✓ loaded ${api.st.shots.length} shots from ${f.name}`);
        } catch (e2) {
          console.warn("[ASB] load file parse:", e2);
          flash(api, "⚠ could not parse " + f.name, true);
        }
        input.value = "";
      };
      reader.onerror = () => flash(api, "⚠ could not read file", true);
      reader.readAsText(f);
    };
  }
  api._fileInput.click();
}

// ---------- server-side plan storage (ComfyUI /asb/plans API) ----------
const API = {
  async list() {
    const r = await fetch("/asb/plans", { cache: "no-store" });
    return r.ok ? r.json() : { plans: [], dir: "" };
  },
  async save(name, content) {
    const r = await fetch("/asb/plans", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, content }),
    });
    return r.ok ? r.json() : null;
  },
  async get(name) {
    const r = await fetch(`/asb/plans/${encodeURIComponent(name)}`);
    return r.ok ? r.json() : null;
  },
  async del(name) {
    const r = await fetch(`/asb/plans/${encodeURIComponent(name)}`, { method: "DELETE" });
    return r.ok;
  },
};

function currentPlanText(api) {
  if (api.st.shots.length) return buildYAML(api.st);
  if (api.planWidget && api.planWidget.value) return api.planWidget.value;
  return "";
}

function defaultServerName(api) {
  const slug = planSlug(api.st);
  const d = new Date().toISOString().slice(0, 10);
  return `asb_plan_${slug}_${d}.yaml`;
}

async function refreshServerList(api) {
  const listEl = api.editor.querySelector('[data-role="serverlist"]');
  if (!listEl) return;
  listEl.innerHTML = '<span class="pe-note">loading…</span>';
  try {
    const data = await API.list();
    if (!data.plans || !data.plans.length) {
      listEl.innerHTML = `<span class="pe-note">no saved plans yet${data.dir ? " — " + data.dir : ""}</span>`;
      return;
    }
    const rows = data.plans.map(name => `
      <div class="pe-server-row">
        <span class="pe-sname">${name}</span>
        <button data-srv="load" data-name="${name}">Load</button>
        <button data-srv="del" data-name="${name}" class="pe-ic">🗑</button>
      </div>`).join("");
    listEl.innerHTML = `<div class="pe-note">${data.plans.length} saved · ${data.dir || ""}</div>` + rows;
    listEl.querySelectorAll("[data-srv]").forEach(btn => {
      btn.onclick = async () => {
        const nm = btn.getAttribute("data-name");
        if (btn.getAttribute("data-srv") === "load") {
          const got = await API.get(nm);
          if (!got) { flash(api, "⚠ could not load " + nm, true); return; }
          try {
            const obj = parsePlanText(got.content || "");
            applyParsed(api, obj);
            renderAll(api);
            flash(api, `✓ loaded ${api.st.shots.length} shots from ${nm}`);
          } catch (e) {
            flash(api, "⚠ could not parse " + nm, true);
          }
        } else {
          await API.del(nm);
          flash(api, `🗑 deleted ${nm}`);
          refreshServerList(api);
        }
      };
    });
  } catch (e) {
    listEl.innerHTML = `<span class="pe-err">⚠ server API unavailable (${e.message}) — is this served by ComfyUI?</span>`;
  }
}

async function savePlanToServer(api) {
  const yaml = currentPlanText(api);
  if (!yaml) { flash(api, "⚠ nothing to save — add shots first", true); return; }
  const nameEl = api.editor.querySelector('input[data-f="serverName"]');
  const name = (nameEl && nameEl.value.trim()) ? nameEl.value.trim() : defaultServerName(api);
  try {
    const res = await API.save(name, yaml);
    if (!res || !res.ok) { flash(api, "⚠ server save failed", true); return; }
    if (nameEl) nameEl.value = res.name;
    flash(api, `✓ saved to server: ${res.name}`);
    refreshServerList(api);
  } catch (e) {
    console.warn("[ASB] server save:", e);
    flash(api, "⚠ server save failed: " + e.message, true);
  }
}

// ---------- plan widget access (robust across ComfyUI versions) ----------
function findPlanWidget(node) {
  if (!node || !node.widgets) return null;
  let w = node.widgets.find(x => x.name === "plan");
  if (!w) w = node.widgets.find(x => x.name && x.name.toLowerCase().includes("plan"));
  return w || null;
}

// Read the CURRENT plan text from the live widget. Order matches how litegraph
// serializes widgets when building the queue payload:
//   1) serialize_value  (if set, THIS is what the server receives)
//   2) widget.value
//   3) the DOM element (textarea/input) — display only
// This is critical: after Apply, if we only set .value and litegraph reads
// serialize_value (stale/empty), the server gets an EMPTY plan — the exact
// "again empty plan" bug.
function readPlanWidget(node) {
  const w = findPlanWidget(node);
  if (!w) return "";
  try {
    if (w.serialize_value !== undefined && w.serialize_value !== null &&
        String(w.serialize_value).length) return String(w.serialize_value);
  } catch (e) { /* ignore */ }
  try {
    if (w.value !== undefined && w.value !== null && String(w.value).length) return String(w.value);
  } catch (e) { /* ignore */ }
  try {
    const dom = w.inputEl
      || (w.element && w.element.value !== undefined && w.element)
      || (w.element && w.element.querySelector && w.element.querySelector("textarea"));
    if (dom && dom.value !== undefined && String(dom.value).length) return String(dom.value);
  } catch (e) { /* ignore */ }
  return "";
}

// Write the plan text into the live widget through every layer ComfyUI uses,
// then verify by reading back. Returns true on success.
function writePlanWidget(node, yaml) {
  const w = findPlanWidget(node);
  if (!w) { console.warn("[ASB] plan widget not found"); return false; }

  // 0) ComfyUI-native setWidgetValue if present (routes everything safely)
  if (typeof node.setWidgetValue === "function") {
    try { node.setWidgetValue("plan", yaml); }
    catch (e) { console.warn("[ASB] setWidgetValue:", e); }
  }

  // 1) visible DOM element (textarea / input)
  try {
    const dom = w.inputEl
      || (w.element && w.element.value !== undefined && w.element)
      || (w.element && w.element.querySelector && w.element.querySelector("textarea"));
    if (dom && dom.value !== undefined) {
      dom.value = yaml;
      const fire = (t) => {
        try {
          if (typeof dom.dispatchEvent === "function") dom.dispatchEvent(new Event(t, { bubbles: true }));
        } catch (_) {}
      };
      fire("input");
      fire("change");
      fire("blur");
    }
  } catch (e) { console.warn("[ASB] apply dom:", e); }

  // 2) the widget value itself
  try { w.value = yaml; } catch (e) { console.warn("[ASB] apply value:", e); }

  // 3) serialize_value — litegraph serializes widgets as `serialize_value ??
  //    value` when building the queue payload; if this is stale/empty the
  //    server receives an empty plan. MUST set it.
  try { w.serialize_value = yaml; } catch (e) { console.warn("[ASB] apply serialize_value:", e); }

  // 4) mark the graph dirty so save / queue serializes the new value
  try { if (node.graph) node.graph.setDirtyCanvas(true, true); } catch (e) { console.warn("[ASB] apply dirty:", e); }

  return true;
}

// ---------- apply (bulletproof) ----------
// NOTE: never call widget.callback(...) directly — ComfyUI wraps input-widget
// callbacks and expects the full (value, canvas, node, pos, event) signature;
// calling with a bare value crashes with "Cannot destructure property 'e' of
// 'undefined'". We write the value + DOM element and dispatch real events.
function applyToNode(api, planWidget) {
  if (!api.st.shots.length) {
    // if the editor is empty but the node already has plan text, load it first
    const existing = readPlanWidget(api.node);
    if (existing) {
      try {
        const obj = parsePlanText(existing);
        if (obj.shots && obj.shots.length) { applyParsed(api, obj); renderAll(api); }
      } catch (e) { /* ignore */ }
    }
    if (!api.st.shots.length) { flash(api, "⚠ add shots first, then Apply", true); return; }
  }
  const yaml = buildYAML(api.st);
  const node = api.node;
  const ok = writePlanWidget(node, yaml);
  if (!ok) { flash(api, "⚠ plan widget not found", true); return; }

  // verify by reading back through the same path ComfyUI serializes
  const back = readPlanWidget(node);
  const landed = back === yaml;
  console.info(`[ASB] apply → plan widget ${landed ? "OK" : "MISMATCH"} (${yaml.length} chars, read-back ${back.length})`);
  if (!landed) {
    // force the widget value once more (some versions keep value in the object)
    try { const w = findPlanWidget(node); if (w) w.value = yaml; } catch (e) {}
  }

  flash(api, landed
    ? `✓ plan applied (${api.st.shots.length} shots) — run the node to refresh outputs`
    : "⚠ plan written but read-back differs — see console", !landed);
  // refresh the live preview with the authoritative server engine (no queue)
  debouncedExpand(api);
}

// ---------- load ----------
function applyParsed(api, obj) {
  const st = api.st;
  const D = api._DATA || {};
  const models = D.models || [];
  const locations = D.locations || [];
  const clothing = D.clothing || [];
  const styles = D.styles || [];
  const qualities = D.qualities || [];
  const cameras = D.cameras || [];
  if (obj.model && models.includes(obj.model)) st.model = obj.model;
  if (obj.location && locations.some(l => l.name === obj.location)) st.location = obj.location;
  if (obj.clothing_set && clothing.some(c => c.name === obj.clothing_set)) st.clothing = obj.clothing_set;
  if (obj.piercing) st.piercing = obj.piercing;
  if (obj.tattoo) st.tattoo = obj.tattoo;
  if (obj.style && styles.includes(obj.style)) st.style = obj.style;
  if (obj.quality && qualities.includes(obj.quality)) st.quality = obj.quality;
  if (obj.camera && cameras.some(c => c.id === obj.camera)) st.camera = obj.camera;
  if (obj.title) st.title = obj.title;
  if (obj.seed) st.seed = parseInt(obj.seed) || 1;
  // intelligence: report ids in the loaded plan that are NOT in current data,
  // so the user knows why some things didn't transfer
  const missing = [];
  if (obj.model && !models.includes(obj.model)) missing.push("model '" + obj.model + "'");
  if (obj.location && !locations.some(l => l.name === obj.location)) missing.push("location '" + obj.location + "'");
  if (obj.clothing_set && !clothing.some(c => c.name === obj.clothing_set)) missing.push("clothing '" + obj.clothing_set + "'");
  if (obj.camera && !cameras.some(c => c.id === obj.camera)) missing.push("camera '" + obj.camera + "'");
  if (missing.length) flash(api, "⚠ not in current data: " + missing.join(", "), true);
  st.shots = [];
  if (Array.isArray(obj.shots) && obj.shots.length) {
    obj.shots.forEach(s => {
      const sh = { zone: s.zone || "", piece: s.piece || "", framing: s.framing || "",
                   mode: "inherit", custom: {}, transition: "none", note: s.note || "" };
      if (s.outfit === "fully_worn") sh.mode = "fully_worn";
      else if (s.outfit === "removed") sh.mode = "removed";
      else if (s.outfit && typeof s.outfit === "object") { sh.mode = "custom"; sh.custom = { ...s.outfit }; }
      else if (s.transition) sh.transition = s.transition;
      api.st.shots.push(sh);
    });
    // heal blank zones left by the old parser bug so the plan still runs —
    // point them at the first zone of the selected location and warn loudly
    const zl = locZones(st, D);
    let healed = 0;
    st.shots.forEach(s => {
      if (!s.zone || !String(s.zone).trim()) {
        const z0 = zl[0];
        if (z0) { s.zone = z0.zone_id || z0.name; healed++; }
      }
    });
    if (healed) {
      const zn = zl[0] ? (zl[0].name || zl[0].zone_id) : "first zone";
      flash(api, `⚠ ${healed} shot(s) had a blank zone (old saved-plan bug) — set to "${zn}", please verify each shot`, true);
    }
  }
  ["model", "location", "clothing", "style", "quality", "camera"].forEach(f => {
    const el = api.editor.querySelector(`select[data-f="${f}"]`);
    if (el) el.value = api.st[f];
  });
  api.editor.querySelector('input[data-f="title"]').value = api.st.title;
  api.editor.querySelector('input[data-f="seed"]').value = api.st.seed;
}

function loadFromPlan(api, planWidget) {
  // fresh lookup — never trust a stale captured reference
  const src = (api.node && readPlanWidget(api.node)) || (planWidget && planWidget.value) || "";
  if (!src) { flash(api, "⚠ plan text is empty — nothing to load", true); return; }
  try {
    const obj = parsePlanText(src);
    if (!obj.shots || !obj.shots.length) { flash(api, "⚠ plan text has no shots", true); return; }
    applyParsed(api, obj);
    flash(api, `✓ loaded ${api.st.shots.length} shots from plan`);
    renderAll(api);
  } catch (err) {
    console.warn("[ASB] load from plan failed:", err);
    flash(api, "⚠ could not parse plan text", true);
  }
}

app.registerExtension({
  name: "ArtisticSetBuilder.ShootPlanEditor",

  beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name !== "ASB_ShootPlan") return;
    const onNodeCreated = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      const r = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;
      if (this.__asbPlannerInit) return r;
      this.__asbPlannerInit = true;

      if (typeof this.addDOMWidget !== "function") return r;
      const planWidget = (this.widgets || []).find(w => w.name === "plan");
      const host = document.createElement("div");
      host.style.width = "100%";
      host.style.height = "100%";
      host.style.overflow = "hidden";

      // The DOM widget MUST track the node's actual size — width follows the
      // node width, height is clamped between MIN_NODE_H and MAX_NODE_H so the
      // node can never grow endlessly, and onResize recomputes on every drag.
      const domW = this.addDOMWidget("plan_editor", "div", host, {
        serialize: false,
        hideOnZoom: true,
        getWidth: () => {
          const w = this.size ? this.size[0] : 480;
          return Math.max(260, w - 12);          // node width minus padding
        },
        getMinHeight: () => MIN_NODE_H,
        getMaxHeight: () => MAX_NODE_H,
        getHeight: () => {
          const h = this.size ? this.size[1] : 760;
          return Math.max(MIN_NODE_H, Math.min(h - 44, MAX_NODE_H));
        },
      });
      if (domW && domW.computeSize) domW.computeSize();

      // live resize: keep the widget sized to the node whenever the user drags
      // the node's sides (this is the fix for "widget not extending with node")
      this.onResize = function (size) {
        if (!domW) return;
        try {
          if (host) {
            host.style.width = "100%";
            host.style.height = "100%";
          }
          if (domW.computeSize) domW.computeSize();
          if (domW.onDraw) domW.onDraw(this.ctx);
        } catch (e) { console.warn("[ASB] onResize:", e); }
        if (this.graph) this.graph.setDirtyCanvas(true, true);
      };
      this.setSize([480, 760]);
      if (this.graph) this.graph.setDirtyCanvas(true, true);

      // remember the editor api for later re-syncs
      const self = this;
      this.__asbApiRef = { api: null };
      const loaded = (D) => {
        if (!D) return;
        const api = buildEditor(host, self, planWidget, D);
        api._DATA = D;
        self.__asbApiRef.api = api;
        const txt = readPlanWidget(self);
        if (txt && txt.trim()) {
          try { applyParsed(api, parsePlanText(txt)); } catch (e) {}
        }
        renderAll(api);
      };
      // load editor data LIVE from the server (data/ folder), snapshot as fallback
      loadEditorData()
        .then(({ data: D, live }) => {
          if (!D) {
            host.innerHTML = `<div class="asb-pe"><div class="pe-err">⚠ no data available.</div></div>`;
            return;
          }
          loaded(D);
          self.__asbLiveData = !!live;
        })
        .catch(err => {
          host.innerHTML = `<div class="asb-pe"><div class="pe-err">⚠ could not load planner data: ${err}</div></div>`;
        });

      // when a saved workflow is loaded, ComfyUI calls configure AFTER widget
      // values are set — re-sync the editor from the (now populated) plan widget
      const onConfigure = nodeType.prototype.onConfigure;
      nodeType.prototype.onConfigure = function () {
        const rr = onConfigure ? onConfigure.apply(this, arguments) : undefined;
        const api = this.__asbApiRef && this.__asbApiRef.api;
        if (api) {
          const txt = readPlanWidget(this);
          if (txt && txt.trim()) {
            try { applyParsed(api, parsePlanText(txt)); renderAll(api); } catch (e) {}
          }
        }
        return rr;
      };
      return r;
    };
  },
});
