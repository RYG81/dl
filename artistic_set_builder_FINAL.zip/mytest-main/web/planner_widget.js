// Artistic Set Builder — embedded Plan Designer (v5.3)
//
// In-canvas shot-list editor for ASB_ShootPlan.
//
// v5.3 fixes:
//   * node height is CAPPED — the shot list scrolls inside the widget; the
//     node can never grow endlessly (getHeight is clamped, no resize loop)
//   * shot list shows as many cards as fit (up to 10), then scrolls
//   * Apply-to-node is bulletproof: finds the live plan widget, sets value +
//     textarea + dispatches input, shows ✓ feedback (run node to refresh
//     plan_json)
//   * editor starts EMPTY (node default plan is ""), so "Auto N shots" gives
//     exactly N — no surprise default shots
//   * Auto N shots follows a real undressing narrative: shot 0 = all on,
//     then one garment advances one step per shot (cycling the wardrobe DB),
//     until everything is off; extra shots keep all-off with varied
//     zone/pose. Poses are chosen compatible with the level each shot reaches.
//   * toolbar (＋ Shot / Auto N / Sample / Load / Apply) above the shot list;
//     status bar shows shots count + plan details + level histogram + feedback

import { app } from "../../scripts/app.js";

const DATA_URL = new URL("planner_data.json", import.meta.url).href;

// Load editor data: try the LIVE server route first (reads data/ at request
// time — always current, includes external folders), fall back to the shipped
// snapshot only if the route is unavailable.
async function loadEditorData() {
  try {
    const r = await fetch("/asb/data", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
      cache: "no-store",
    });
    if (r.ok) {
      const j = await r.json();
      if (j && j.ok && j.data && j.data.locations && j.data.locations.length) {
        return { data: j.data, live: true };
      }
    }
  } catch (e) { /* route unavailable — fall through to snapshot */ }
  const r2 = await fetch(DATA_URL + (DATA_URL.includes("?") ? "&" : "?") + "t=" + Date.now(), { cache: "no-store" });
  if (!r2.ok) throw new Error("no data source");
  return { data: await r2.json(), live: false };
}
const REMOVED_DEFAULT = ["removed","no panties","no bra","barefoot","no top","no skirt","no dress","no shirt"];
const MAX_VISIBLE_SHOTS = 10;   // max cards before the list scrolls
const MAX_NODE_H = 1040;        // hard cap so the node never grows endlessly
const MIN_NODE_H = 240;

// Build a sample plan from WHATEVER data is present (first available
// model / location / clothing / camera / style / quality + a small undress
// narrative through the first zones' pieces). Never hardcodes any id, so the
// Sample button always produces a plan loadable with your current data.
function buildSamplePlan(DATA) {
  const D = DATA || {};
  const m = (D.models && D.models[0]) || "";
  const loc = (D.locations && D.locations[0]) || null;
  const cl = (D.clothing && D.clothing[0]) || null;
  const cam = (D.cameras && D.cameras[0] && D.cameras[0].id) || "";
  const style = (D.styles && D.styles[0]) || "custom";
  const quality = (D.qualities && D.qualities[0]) || "default";
  if (!loc || !cl || !loc.zones || !loc.zones.length) return "";
  const zones = loc.zones;
  const items = (cl.items || []).map(it => it.item_id || it.name);
  const L = [];
  L.push(`title: "Sample shoot"`);
  L.push(`model: ${m}`);
  L.push(`location: ${loc.name}`);
  L.push(`clothing_set: ${cl.name}`);
  L.push(`style: ${style}`);
  L.push(`quality: ${quality}`);
  if (cam) L.push(`camera: ${cam}`);
  L.push("seed: 1");
  L.push("shots:");
  // walk up to 6 shots across the first zones, advancing one item at a time
  const n = Math.min(zones.length, 6);
  for (let zi = 0; zi < n; zi++) {
    const z = zones[zi];
    const zid = z.zone_id || z.name;
    const pieces = z.pieces || [];
    const p0 = pieces.find(p => (p.levels || []).includes("level_0")) || pieces[0];
    if (!p0) continue;
    L.push(`  - zone: ${zid}`);
    L.push(`    piece: ${p0.id}`);
    if (zi === 0) {
      L.push("    outfit: fully_worn");
    } else if (items.length) {
      L.push(`    transition: "advance: ${items[(zi - 1) % items.length]}"`);
    }
  }
  return L.join("\n");
}

const SAMPLE_PLAN = buildSamplePlan(null); // placeholder — replaced with real data below

const CSS_ID = "asb-plan-editor-css";
if (!document.getElementById(CSS_ID)) {
  const style = document.createElement("style");
  style.id = CSS_ID;
  style.textContent = `
  .asb-pe { font: 12px/1.35 "Segoe UI", system-ui, sans-serif; color: #dfe5ee;
            display:flex; flex-direction:column; height:100%; box-sizing:border-box;
            min-width:0; overflow:hidden; }
  .asb-pe * { box-sizing:border-box; min-width:0; }
  .asb-pe .pe-head { display:flex; align-items:center; gap:6px; margin-bottom:6px; flex:none; }
  .asb-pe .pe-toggle { cursor:pointer; background:#2a3140; border:1px solid #3a4458; color:#dfe5ee;
      border-radius:5px; padding:2px 8px; font-size:11px; }
  .asb-pe .pe-toggle:hover { border-color:#6ea8fe; }
  .asb-pe .pe-status { background:#1a2029; border:1px solid #2c3342; border-radius:6px;
      padding:3px 8px; font-size:10px; color:#8b96a8; margin-bottom:6px; flex:none;
      display:flex; gap:10px; flex-wrap:wrap; align-items:center; min-height:20px; }
  .asb-pe .pe-status b { color:#dfe5ee; font-weight:600; }
  .asb-pe .pe-status .pe-count { color:#6ea8fe; font-weight:700; }
  .asb-pe .pe-status .pe-flash { color:#34d399; font-weight:600; }
  .asb-pe .pe-status .pe-flash.err { color:#f87171; }
  .asb-pe .pe-grid { display:grid; grid-template-columns:1fr 1fr 1fr; gap:3px 6px; margin-bottom:6px; flex:none; }
  .asb-pe label { display:block; font-size:9px; color:#8b96a8; text-transform:uppercase; letter-spacing:.4px; }
  .asb-pe select, .asb-pe input[type=text], .asb-pe input[type=number] { width:100%; background:#1c2230; color:#dfe5ee;
      border:1px solid #3a4458; border-radius:4px; padding:2px 4px; font-size:11px; }
  .asb-pe .pe-toolbar { display:flex; gap:5px; margin-bottom:6px; flex-wrap:wrap; align-items:center; flex:none; }
  .asb-pe .pe-shots { flex:1 1 auto; min-height:0; overflow-y:auto; border:1px solid #2c3342; border-radius:6px;
      padding:3px; background:#141922; }
  .asb-pe .pe-empty { color:#7c8798; font-size:11px; padding:14px 8px; text-align:center; }
  .asb-pe .pe-shot { border:1px solid #2c3342; border-radius:6px; padding:4px; margin-bottom:4px; background:#1a2029; }
  .asb-pe .pe-shot:last-child { margin-bottom:0; }
  .asb-pe .pe-prompt { background:#10141c; border:1px solid #232b38; border-radius:4px;
      padding:3px 5px; font-size:10px; color:#93a1b5; margin-top:3px; line-height:1.3;
      display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
  .asb-pe .pe-prompt b { color:#7c8798; font-weight:600; }
  .asb-pe .pe-shot-top { display:flex; gap:4px; align-items:center; margin-bottom:3px; }
  .asb-pe .pe-no { background:#8b5cf6; color:#fff; border-radius:4px; padding:0 6px; font-weight:700; font-size:10px; flex:none; }
  .asb-pe .pe-lvl { border-radius:10px; padding:0 7px; font-size:10px; font-weight:600; white-space:nowrap; flex:none; }
  .asb-pe .l0{background:#1e3a5f;color:#7cc4ff;} .asb-pe .l1{background:#1f3a3a;color:#5eead4;}
  .asb-pe .l2{background:#3a2f1e;color:#fbbf24;} .asb-pe .l3{background:#1f3a2b;color:#fb7185;}
  .asb-pe .l4{background:#2d1e3a;color:#c084fc;}
  .asb-pe .pe-ic { cursor:pointer; background:none; border:none; color:#8b96a8; font-size:12px; padding:0 3px; flex:none; }
  .asb-pe .pe-ic:hover { color:#6ea8fe; }
  .asb-pe .pe-row { display:grid; grid-template-columns:1fr 1.3fr 1.1fr; gap:3px; margin-bottom:3px; }
  .asb-pe .pe-row2 { display:grid; grid-template-columns:1.3fr 1fr; gap:3px; margin-bottom:3px; }
  .asb-pe .pe-custom { display:grid; grid-template-columns:1fr 1fr; gap:3px 6px; background:#10141c; border-radius:4px; padding:3px; margin-top:3px; }
  .asb-pe .pe-foot-note { color:#7c8798; font-size:10px; flex:none; margin-top:4px; }
  .asb-pe .pe-out { flex:none; margin-top:6px; }
  .asb-pe .pe-outbody { display:none; background:#0f131a; border:1px solid #2c3342; border-radius:6px;
      padding:6px; font:10.5px/1.4 ui-monospace, Menlo, Consolas, monospace; color:#aab6c6;
      max-height:150px; overflow:auto; white-space:pre; margin:4px 0 0; }
  .asb-pe .pe-server { background:#10141c; border:1px solid #2c3342; border-radius:6px; padding:4px; margin-bottom:6px; flex:none; }
  .asb-pe .pe-server-row { display:flex; gap:5px; align-items:center; margin-bottom:4px; }
  .asb-pe .pe-server-row input[type=text] { flex:1; }
  .asb-pe .pe-serverlist { max-height:110px; overflow-y:auto; }
  .asb-pe .pe-server-row .pe-sname { flex:1; font-size:11px; color:#c7d0dd; word-break:break-all; }
  .asb-pe .pe-server-row button { padding:2px 7px; font-size:11px; }
  .asb-pe button { background:#2a3140; border:1px solid #3a4458; color:#dfe5ee; border-radius:5px;
      padding:3px 9px; font-size:11px; cursor:pointer; white-space:nowrap; }
  .asb-pe button:hover { border-color:#6ea8fe; }
  .asb-pe .pe-primary { background:#6ea8fe; border-color:#6ea8fe; color:#081018; font-weight:600; }
  .asb-pe .pe-err { color:#f87171; font-size:11px; padding:6px; }
  .asb-pe .pe-note { color:#7c8798; font-size:10px; }
  `;
  document.head.appendChild(style);
}

function computeLevel(cn, outfitMap, DATA) {
  const c = DATA.clothing.find(x => x.name === cn);
  const removed = (c && c.removed_states) || REMOVED_DEFAULT;
  let n = 0;
  for (const v of Object.values(outfitMap)) if (removed.includes(v)) n++;
  let idx = 0;
  for (let i = 0; i < 5; i++) if (n >= i) idx = i;
  return "level_" + Math.min(idx, 4);
}
function removedStatesOf(api) {
  const c = api._DATA.clothing.find(x => x.name === api.st.clothing);
  return (c && c.removed_states) || REMOVED_DEFAULT;
}

function yamlQuote(v) {
  v = String(v);
  return /[:#\[\]{}&*!|>'"%@`,\n]/.test(v) || /^\s|\s$/.test(v) ? JSON.stringify(v) : v;
}

function newState() {
  return {
    title: "My Shoot", model: "", location: "", clothing: "",
    style: "custom", quality: "default", seed: 1, camera: "",
    shots: [],
  };
}

function locZones(st, DATA) {
  const l = DATA.locations.find(x => x.name === st.location);
  return l ? l.zones : [];
}
function zonePieces(st, DATA, zoneId) {
  const z = locZones(st, DATA).find(x => (x.zone_id || x.name) === zoneId);
  return z ? z.pieces : [];
}
function clothItems(st, DATA) {
  const c = DATA.clothing.find(x => x.name === st.clothing);
  return c ? c.items : [];
}

// ---------- YAML ----------
function buildYAML(st) {
  const L = [];
  L.push(`title: ${yamlQuote(st.title)}`);
  L.push(`model: ${yamlQuote(st.model)}`);
  L.push(`location: ${yamlQuote(st.location)}`);
  L.push(`clothing_set: ${yamlQuote(st.clothing)}`);
  L.push(`style: ${yamlQuote(st.style)}`);
  L.push(`quality: ${yamlQuote(st.quality)}`);
  if (st.camera) L.push(`camera: ${yamlQuote(st.camera)}`);
  L.push(`seed: ${st.seed}`);
  L.push("shots:");
  // A plan uses ONE location + ONE clothing set throughout (consistent set).
  for (const s of st.shots) {
    L.push(`  - zone: ${yamlQuote(s.zone)}`);
    L.push(`    piece: ${yamlQuote(s.piece)}`);
    if (s.framing) L.push(`    framing: ${yamlQuote(s.framing)}`);
    if (s.mode === "fully_worn") L.push("    outfit: fully_worn");
    else if (s.mode === "removed") L.push("    outfit: removed");
    else if (s.mode === "custom") {
      const entries = Object.entries(s.custom).filter(([, v]) => v);
      if (entries.length) {
        L.push("    outfit:");
        for (const [k, v] of entries) L.push(`      ${yamlQuote(k)}: ${yamlQuote(v)}`);
      }
    } else if (s.transition && s.transition !== "none") {
      L.push(`    transition: ${yamlQuote(s.transition)}`);
    }
    if (s.note) L.push(`    note: ${yamlQuote(s.note)}`);
  }
  return L.join("\n");
}

function parsePlanText(txt) {
  const obj = {};
  let cur = null;
  const shots = [];
  for (const raw of txt.split("\n")) {
    const line = raw.replace(/#.*$/, "").trimEnd();
    if (!line.trim()) continue;
    if (/^shots:/.test(line.trim())) continue;
    // a shot's opening line carries its first field ("- zone: Z_Window") —
    // start the shot AND parse the key:value on that same line (bugfix:
    // previously the zone was silently dropped, which blanked every shot)
    let openingShot = false;
    let effLine = line;
    if (/^  - /.test(line)) {
      cur = {};
      shots.push(cur);
      openingShot = true;
      effLine = line.replace(/^  - /, "    "); // treat "- key: val" as an indented field line
    }
    const ind = openingShot ? 4 : effLine.search(/\S/);
    const m = effLine.trim().match(/^([^:]+):\s*(.*)$/);
    if (!m) continue;
    const k = m[1].trim(), v = unquote(m[2]);
    if (ind >= 2 && cur) {
      if (k === "outfit" && !v) { cur.outfit = {}; continue; }
      if (k === "outfit" && v) { cur.outfit = v; continue; }
      if (cur.outfit && typeof cur.outfit === "object" && k !== "zone" && k !== "piece" && k !== "transition" && k !== "framing" && k !== "camera" && k !== "note") {
        cur.outfit[k] = v; continue;
      }
      cur[k] = v;
    } else if (ind === 0) {
      obj[k] = v;
    }
  }
  obj.shots = shots;
  return obj;
}
function unquote(v) { v = v.trim(); if (v.length >= 2 && ((v[0] === '"' && v[v.length-1] === '"') || (v[0] === "'" && v[v.length-1] === "'"))) return v.slice(1, -1); return v; }

// ---------- outfit/transition logic (mirrors engine) ----------
// outfit map for a shot: the plan uses ONE clothing set, so items are that
// set's items and the state carries forward across shots.
function outfitMapOf(api, idx) {
  const items = clothItems(api.st, api._DATA);
  if (!items.length) return {};
  const s = api.st.shots[idx];
  if (!s) { const m = {}; items.forEach(it => m[it.item_id || it.name] = it.states[0]); return m; }
  const prev = idx > 0 ? outfitMapOf(api, idx - 1) : {};
  const m = {};
  items.forEach(it => { m[it.item_id || it.name] = it.states[0]; });
  Object.assign(m, prev);
  if (s.mode === "fully_worn") items.forEach(it => m[it.item_id || it.name] = it.states[0]);
  else if (s.mode === "removed") items.forEach(it => m[it.item_id || it.name] = it.states[it.states.length - 1]);
  else if (s.mode === "custom") items.forEach(it => { const k = it.item_id || it.name; if (s.custom[k]) m[k] = s.custom[k]; });
  else if (s.transition && s.transition !== "none") applyTransition(m, s.transition, items);
  return m;
}
function applyTransition(m, t, items) {
  if (t === "reset") { items.forEach(it => m[it.item_id || it.name] = it.states[0]); return m; }
  const parts = t.split(": ");
  const kind = parts[0], arg = parts[1];
  const it = items.find(x => (x.item_id || x.name) === arg || x.name === arg);
  if (it) {
    const k = it.item_id || it.name;
    const idx = it.states.indexOf(m[k]);
    if (kind === "advance" || kind === "undress" || kind === "next") m[k] = it.states[Math.min(idx + 1, it.states.length - 1)];
    else if (kind === "remove") m[k] = it.states[it.states.length - 1];
    else if (kind === "dress") m[k] = it.states[Math.max(idx - 1, 0)];
    else if (kind === "set") { const st = t.split("->")[1].trim(); m[k] = st; }
  }
  return m;
}

// ---------- auto shots: real undressing narrative ----------
// pieces of a zone in a SPECIFIC location (per-shot location override)
function zonePiecesIn(api, locname, zoneId) {
  const l = (api._DATA.locations || []).find(x => x.name === locname);
  const z = l ? (l.zones || []).find(x => (x.zone_id || x.name) === zoneId) : null;
  return z ? (z.pieces || []) : [];
}

// pick a pose for a zone (in `locname`) at `lvl`, rotating through the
// compatible poses so the set has variety.
function pickPiece(api, locname, zone, lvl) {
  const pieces = zonePiecesIn(api, locname, zone.zone_id || zone.name);
  if (!pieces.length) return {};
  const compat = pieces.filter(p => (p.levels || []).includes(lvl));
  const pool = compat.length ? compat : pieces;
  // per-zone rotation counter keeps us cycling through the poses
  api._zonePick = api._zonePick || {};
  const key = (locname || "") + "::" + (zone.zone_id || zone.name);
  const idx = (api._zonePick[key] || 0) % pool.length;
  api._zonePick[key] = idx + 1;
  return pool[idx] || pieces[0] || {};
}

// pick a framing: prefer one matched to the pose type, else cycle through the
// list so consecutive shots differ.
function pickFraming(api, framings, piece, shotIndex) {
  const ptype = (piece.label || "").split("|")[1] ? (piece.label.split("|")[1] || "").trim() : "";
  const hit = framings.find(f => (f.default_for_piece_types || []).includes(ptype));
  if (hit) return hit.id;
  if (!framings.length) return "";
  return framings[shotIndex % framings.length].id;
}

function makeAutoShot(api, zones, framings, items, outfitMode, transition, note) {
  const { st, _DATA } = api;
  // level after this shot's transition
  let trial = st.shots.length ? outfitMapOf(api, st.shots.length - 1) : {};
  if (outfitMode === "fully_worn") {
    trial = {}; items.forEach(it => trial[it.item_id || it.name] = it.states[0]);
  } else if (transition) {
    trial = applyTransition({ ...trial }, transition, items);
  }
  const lvl = computeLevel(st.clothing, trial, _DATA);
  const zone = zones[st.shots.length % zones.length] || zones[0];
  const zid = zone.zone_id || zone.name;
  const piece = pickPiece(api, st.location, zone, lvl);
  const framing = pickFraming(api, framings, piece, st.shots.length);
  return {
    zone: zid,
    piece: piece.id || "",
    framing,
    mode: outfitMode ? outfitMode : "inherit",
    custom: {},
    transition: transition ? transition : "none",
    note: note || "",
  };
}

// total wardrobe steps to go from fully worn to everything off
function totalUndressSteps(items) {
  let steps = 0;
  items.forEach(it => steps += Math.max(0, (it.states.length - 1)));
  return steps;
}

// read a node INT widget (auto_shots / min_level / max_level), default fallback
function nodeInt(api, name, fallback) {
  const w = (api.node.widgets || []).find(x => x.name === name);
  const v = w ? parseInt(w.value) : NaN;
  return Number.isFinite(v) ? v : fallback;
}

// read a node COMBO widget value ("all" | "current" | mode name)
function nodeChoice(api, name, fallback) {
  const w = (api.node.widgets || []).find(x => x.name === name);
  return (w && w.value) ? String(w.value) : fallback;
}

// fresh per-set item state machine
function freshSetMachine(set) {
  return ((set && set.items) || []).map(it => ({
    key: it.item_id || it.name,
    states: it.states || [],
    cur: (it.states && it.states[0]) || "",
  }));
}


// autoShots v6 — builds a TRUE gallery across the whole database:
//   location_scope  : "all" (cycle every location) | "current"
//   clothing_scope  : "all" (cycle every clothing set) | "current"
//   gallery_mode    : "MetArt gallery" (mostly artistic nude with wardrobe
//                     changes) | "undress narrative" (classic paced undress)
// Per-shot `location` / `clothing_set` overrides are emitted so ONE plan spans
// the full databases — the engine expands each shot in its own location/set.
// autoShots v7 — builds a consistent gallery within the USER-SELECTED
// location + clothing set (NEVER mixes two locations or two outfits in one
// set). It fully utilizes the selected data:
//   - cycles through ALL zones of the selected location,
//   - rotates poses per zone (compatible with each shot's level),
//   - uses EVERY item of the selected clothing set in the undress arc,
//   - MetArt gallery = dress/undress ~30% then mostly artistic nude;
//     undress narrative = slower paced undress (~60% wardrobe).
// autoShots v8 — LINEAR all→none undress across the FULL shot count.
//
// The sequence is strictly linear: shot 0 is fully dressed, and the outfit
// advances one item-state at a time, spread evenly across ALL N shots, so the
// set ends all-off. Location zones are REUSED (they cycle) but every revisit
// has a progressed outfit state, and poses rotate per zone per level — so a
// 500-shot set uses the same 5 zones ~100 times each, never repeating the
// exact same (zone, pose, outfit) triple.
//
//   gallery_mode:
//     "undress narrative" (default) — undress spread across the whole N
//     "MetArt gallery"               — dress/undress arc then mostly nude
// director's-note pool for auto-generated shots — real, evocative wording,
// NEVER progress counters (counters leaking into prompts looked like
// "hold (59/100)" — meaningless to an image model and ugly).
const AUTO_NOTES = [
  "eyes to camera, soft smile", "weight shift, hand through hair",
  "looking away, gentle profile", "arms relaxed, quiet confidence",
  "fingertip tracing collarbone", "half-lidded gaze, warm light",
  "shoulder turned, coy glance", "stretching slowly, arching back",
  "hand resting on hip, poised", "hair swept over one shoulder",
  "leaning in, intimate moment", "serene, caught in soft light",
  "breath held, anticipation", "smile just forming, playful",
  "gazing down, shy warmth", "tilting head, curious and open",
];
function autoNote(api, i) { return AUTO_NOTES[i % AUTO_NOTES.length]; }

// autoShots v9 — LINEAR all→none, with correct max_level handling and short-set
// support.
//
// Fixes:
//   * max_level now caps the ACTUAL wardrobe (the machine never advances an
//     item past what would exceed max_level) — the display and the engine
//     always agree (previously the display clamped but the machine kept
//     undressing to level_4 behind the scenes).
//   * short counts: if the shot count is too small to complete every item
//     step, the generator still advances one step per shot and warns.
//   * the sequence stays strictly linear all→none within max_level.
// autoShots v10 — CONTINUOUS undressing (the core restored).
//
// Regression fixed: v8/v9 spread the advances so thin (every Nth shot) that
// most shots were holds with identical outfits — undressing was invisible.
// Now the default "undress narrative" advances ONE item EVERY shot, cycling
// items in order, so the outfit visibly progresses shot-by-shot until all off
// (or max_level reached); the remaining shots stay at the final state with
// full zone/pose/framing variety. Zones are reused — each revisit has a
// progressed outfit.
function autoShots(api, n) {
  const { st, _DATA } = api;
  const zones = locZones(st, _DATA);
  const items = clothItems(st, _DATA);
  if (!zones.length || !items.length) { flash(api, "⚠ pick a location & clothing set first", true); return 0; }
  const framings = _DATA.framing || [];
  const mode = nodeChoice(api, "gallery_mode", "undress narrative");
  const maxLevel = Math.max(0, Math.min(4, nodeInt(api, "max_level", 4)));
  const startIdx = st.shots.length;
  const target = Math.max(1, n);

  const removedStates = (() => {
    const c = (_DATA.clothing || []).find(x => x.name === st.clothing);
    return (c && c.removed_states) || REMOVED_DEFAULT;
  })();
  const machine = items.map(it => ({
    key: it.item_id || it.name,
    states: it.states || [],
    cur: (it.states && it.states[0]) || "",
  }));
  const removedCount = () => machine.filter(x => removedStates.includes(x.cur)).length;
  // can any item advance one step without exceeding maxLevel?
  const canAdvanceAny = () => {
    for (const x of machine) {
      const ix = x.states.indexOf(x.cur);
      if (ix < 0 || ix >= x.states.length - 1) continue;
      const nxt = x.states[ix + 1];
      const willBe = removedCount() + (removedStates.includes(nxt) ? 1 : 0);
      if (willBe <= maxLevel) return true;
    }
    return false;
  };
  // advance the NEXT item in rotation (one step)
  let cursor = 0;
  const advanceOne = () => {
    for (let k = 0; k < items.length; k++) {
      const x = machine[(cursor + k) % machine.length];
      const ix = x.states.indexOf(x.cur);
      if (ix >= 0 && ix < x.states.length - 1) {
        const nxt = x.states[ix + 1];
        const willBe = removedCount() + (removedStates.includes(nxt) ? 1 : 0);
        if (willBe <= maxLevel) {
          x.cur = nxt;
          cursor = (cursor + k + 1) % machine.length;
          return x;
        }
      }
    }
    return null;
  };
  // MetArt: how long the wardrobe arc lasts (40% or until all off)
  const metArc = mode === "MetArt gallery" ? Math.max(1, Math.round(target * 0.4)) : target;

  for (let j = 0; j < target; j++) {
    const i = startIdx + j;
    let action;
    let advItem = null;
    let rewearInfo = null; // {key, state, name} when re-wearing

    if (j === 0) {
      action = "open";
      machine.forEach(x => { x.cur = x.states[0] || ""; });
    } else if (mode === "MetArt gallery" && j > metArc) {
      // artistic-nude section: push every item as far as maxLevel allows
      machine.forEach(x => {
        while (true) {
          const ix = x.states.indexOf(x.cur);
          if (ix < 0 || ix >= x.states.length - 1) break;
          const nxt = x.states[ix + 1];
          const willBe = removedCount() + (removedStates.includes(nxt) ? 1 : 0);
          if (willBe > maxLevel) break;
          x.cur = nxt;
        }
      });
      action = "nude";
    } else if (canAdvanceAny()) {
      // CONTINUOUS: advance one item every shot until we can't anymore
      action = "adv";
      advItem = advanceOne();
    } else {
      // wardrobe exhausted (all off / maxLevel). For LONG sets, re-wear one
      // item occasionally so the outfit keeps evolving across the set
      // ("reuse zones with different outfit stats").
      const rewearEvery = Math.max(6, Math.round(target / 20));
      let wore = null;
      for (const x of machine) {
        const ix = x.states.indexOf(x.cur);
        if (ix > 0) { wore = x; break; }
      }
      if (mode !== "MetArt gallery" && wore && j % rewearEvery === 0) {
        const ix = wore.states.indexOf(wore.cur);
        wore.cur = wore.states[Math.max(ix - 1, 0)];
        rewearInfo = {
          key: wore.key,
          state: wore.cur,
          name: (items.find(y => (y.item_id || y.name) === wore.key) || {}).name || wore.key,
        };
        action = "rewear";
      } else {
        action = "final";
      }
    }

    const map = {}; machine.forEach(x => { map[x.key] = x.cur; });
    const lvl = computeLevel(st.clothing, map, _DATA);

    const zone = zones[i % zones.length] || zones[0];
    const zid = zone.zone_id || zone.name;
    const piece = pickPiece(api, st.location, zone, lvl);
    const framing = pickFraming(api, framings, piece, i);

    const shot = {
      zone: zid, piece: piece.id || "", framing,
      mode: "inherit", custom: {}, transition: "none", note: "",
    };
    const itName = (advItem && (items.find(x => (x.item_id || x.name) === advItem.key) || {}).name) || (advItem && advItem.key) || "";
    if (action === "open") {
      shot.mode = "fully_worn";
      const clLbl = (_DATA.clothing || []).find(c => c.name === st.clothing);
      shot.note = "opening look — " + ((clLbl && clLbl.label) || st.clothing || "set") + " fully worn";
    } else if (action === "adv" && advItem) {
      shot.transition = "advance: " + advItem.key;
      shot.note = itName ? itName + " slipping" : "undressing";
    } else if (action === "nude") {
      shot.mode = "removed";
      const ll = (_DATA.locations || []).find(l => l.name === st.location);
      shot.note = "artistic nude, " + ((ll && ll.label) || st.location).toLowerCase();
    } else if (action === "rewear" && rewearInfo) {
      shot.transition = "set: " + rewearInfo.key + " -> " + rewearInfo.state;
      shot.note = "re-wear — " + rewearInfo.name + " back on";
    } else {
      shot.note = autoNote(api, i);
    }
    st.shots.push(shot);
  }

  const finalMap = {}; machine.forEach(x => { finalMap[x.key] = x.cur; });
  const finalLvl = computeLevel(st.clothing, finalMap, _DATA);
  const finalIdx = parseInt(finalLvl.split("_")[1]) || 0;
  let note = `✓ added ${target} shot${target === 1 ? "" : "s"} (continuous undress, ${zones.length} zones × ${items.length} items)`;
  if (finalIdx < maxLevel) {
    note += ` ⚠ reached ${finalLvl} (max ${maxLevel}) — that's the most this set allows.`;
  }
  flash(api, note);
  return target;
}

function autoShotCount(api) {
  const w = (api.node.widgets || []).find(x => x.name === "auto_shots");
  const n = w ? parseInt(w.value) : 5;
  return Number.isFinite(n) && n > 0 ? n : 5;
}

// ---------- status bar + feedback ----------
function flash(api, msg, isErr) {
  const el = api.editor.querySelector('[data-role="flash"]');
  if (!el) return;
  el.textContent = msg;
  el.className = "pe-flash" + (isErr ? " err" : "");
  clearTimeout(api._flashT);
  api._flashT = setTimeout(() => { el.textContent = ""; }, 4000);
}

function updateStatus(api) {
  const { st, _DATA } = api;
  const el = api.editor.querySelector('[data-role="status"]');
  if (!el) return;
  const levels = {};
  st.shots.forEach((_, i) => {
    const lvl = computeLevel(st.clothing, outfitMapOf(api, i), _DATA);
    levels[lvl] = (levels[lvl] || 0) + 1;
  });
  const hist = Object.entries(levels).sort().map(([l, c]) => `${l}:${c}`).join(" ");
  const cam = (() => {
    const c = (api._DATA.cameras || []).find(x => x.id === st.camera);
    return c ? `${c.brand} ${c.model}` : "no camera";
  })();
  // live availability summary of the CURRENT location's data (intelligence)
  let avail = "";
  const allLocs = (api._DATA.locations || []).length;
  const loc = (api._DATA.locations || []).find(l => l.name === st.location);
  if (loc) {
    const zones = loc.zones || [];
    const poses = zones.reduce((a, z) => a + (z.pieces ? z.pieces.length : 0), 0);
    avail = `<span style="color:#7c8798">${zones.length} zones · ${poses} poses</span>` +
            `<span style="color:#6ea8fe">· ${allLocs} locations total</span>`;
  } else {
    avail = `<span style="color:#7c8798">${allLocs} locations · ${(api._DATA.clothing || []).length} sets · ${(api._DATA.cameras || []).length} cams</span>`;
  }
  el.innerHTML = `<span class="pe-count">${st.shots.length} shots</span>
    <span><b>${st.model || "?"}</b></span>
    <span>${st.location || "?"} · ${st.clothing || "?"}</span>
    <span>${cam}</span>
    <span>${st.style || "?"} · ${st.quality || "?"}</span>
    <span>seed ${st.seed}</span>
    ${avail}
    <span style="color:#7c8798">${hist}</span>
    <span data-role="flash" class="pe-flash" style="flex-basis:100%"></span>`;
}

// ---------- build the editor DOM ----------
function buildEditor(host, node, planWidget, DATA) {
  const st = newState();
  st.model = DATA.models[0] || "";
  st.location = DATA.locations[0] ? DATA.locations[0].name : "";
  st.clothing = DATA.clothing[0] ? DATA.clothing[0].name : "";
  st.camera = DATA.cameras[0] ? DATA.cameras[0].id : "";
  // start EMPTY — no default shots

  const editor = document.createElement("div");
  editor.className = "asb-pe";
  host.appendChild(editor);
  const api = { editor, st, host, node, planWidget, _DATA: DATA, _flashT: null };

  editor.innerHTML = `
    <div class="pe-head">
      <button class="pe-toggle" data-act="toggle">▾ Plan editor</button>
      <span style="flex:1"></span>
      <span class="pe-note" data-role="count"></span>
    </div>
    <div data-role="body" style="display:flex; flex-direction:column; flex:1; min-height:0;">
      <div class="pe-status" data-role="status"></div>
      <div class="pe-grid">
        <div><label>Title</label><input type="text" data-f="title"></div>
        <div><label>Seed</label><input type="number" data-f="seed"></div>
        <div><label>Camera (all shots)</label><select data-f="camera"></select></div>
        <div><label>Model</label><select data-f="model"></select></div>
        <div><label>Location</label><select data-f="location"></select></div>
        <div><label>Clothing set</label><select data-f="clothing"></select></div>
        <div><label>Style</label><select data-f="style"></select></div>
        <div><label>Quality</label><select data-f="quality"></select></div>
      </div>
      <div class="pe-toolbar">
        <button data-act="add">＋ Shot</button>
        <button data-act="undress">🧩 Auto <span data-role="auton">–</span> shots</button>
        <button data-act="sample">Sample</button>
        <button data-act="load">⟳ Load from plan</button>
        <button data-act="save">💾 Save file</button>
        <button data-act="loadfile">📂 Load file</button>
        <button data-act="server">☁️ Server</button>
        <button data-act="refresh">↻ Refresh data</button>
        <button data-act="clear">🧹 Clear</button>
        <span style="flex:1"></span>
        <button class="pe-primary" data-act="apply">✓ Apply to node</button>
      </div>
      <div class="pe-server" data-role="server" style="display:none">
        <div class="pe-server-row">
          <input type="text" data-f="serverName" placeholder="plan name (default: asb_plan_&lt;title&gt;_&lt;date&gt;.yaml)">
          <button data-act="serversave">☁️ Save to server</button>
          <button data-act="serverrefresh">⟳</button>
        </div>
        <div data-role="serverlist" class="pe-serverlist"></div>
      </div>
      <div class="pe-shots" data-role="shots"></div>
      <div class="pe-foot-note" data-role="scrollnote"></div>
      <div class="pe-out">
        <button class="pe-toggle" data-act="toggleout">▸ Output preview</button>
        <button data-act="outcopy">📋 Copy plan_json</button>
        <button data-act="outrefresh">⟳ Expand</button>
        <span class="pe-note" data-role="outcount"></span>
        <pre class="pe-outbody" data-role="outbody"></pre>
      </div>
    </div>
  `;

  const sel = (name, options, fallback) => {
    const el = editor.querySelector(`select[data-f="${name}"]`);
    el.innerHTML = options.map(o => `<option value="${o.value}" ${o.value === fallback ? "selected" : ""}>${o.label}</option>`).join("");
    el.onchange = () => {
      const wasLocation = name === "location";
      const wasClothing = name === "clothing";
      st[name] = el.value;
      if (wasLocation) remapShotsForLocation(api);
      if (wasClothing) clearStaleCustom(api);
      renderAll(api);
      if (wasLocation || wasClothing) {
        flash(api, wasLocation ? "✓ location changed — shots re-mapped to its zones" : "✓ clothing set changed — outfit states reset", false);
      }
    };
    return el;
  };
  sel("model", DATA.models.map(m => ({ value: m, label: m })), st.model);
  sel("location", DATA.locations.map(l => ({ value: l.name, label: l.label || l.name })), st.location);
  sel("clothing", DATA.clothing.map(c => ({ value: c.name, label: c.label || c.name })), st.clothing);
  sel("style", DATA.styles.map(s => ({ value: s, label: s })), st.style);
  sel("quality", DATA.qualities.map(q => ({ value: q, label: q })), st.quality);
  const camEl = editor.querySelector('select[data-f="camera"]');
  const camOpts = [{ value: "", label: "— none —" }].concat(
    (DATA.cameras || []).map(c => ({ value: c.id, label: `${c.brand} ${c.model} (${c.id})` })));
  camEl.innerHTML = camOpts.map(o => `<option value="${o.value}" ${o.value === st.camera ? "selected" : ""}>${o.label}</option>`).join("");
  camEl.onchange = () => { st.camera = camEl.value; updateStatus(api); };
  editor.querySelector('input[data-f="title"]').onchange = e => { st.title = e.target.value; updateStatus(api); };
  editor.querySelector('input[data-f="seed"]').onchange = e => { st.seed = parseInt(e.target.value) || 1; updateStatus(api); };

  // header toggle (fixed heights — never grows)
  let expanded = true;
  editor.querySelector('[data-act="toggle"]').onclick = () => {
    expanded = !expanded;
    editor.querySelector('[data-role="body"]').style.display = expanded ? "flex" : "none";
    editor.querySelector('[data-act="toggle"]').textContent = expanded ? "▾ Plan editor" : "▸ Plan editor";
    node.setSize([node.size[0], expanded ? Math.min(Math.max(node.size[1], MIN_NODE_H), MAX_NODE_H) : 110]);
    if (node.graph) node.graph.setDirtyCanvas(true, true);
  };

  // defensive wiring: one missing element must never kill the rest
  const on = (sel, fn) => { const el = editor.querySelector(sel); if (el) el.onclick = fn; };
  on('[data-act="add"]', () => { addShot(api); renderAll(api); });
  on('[data-act="undress"]', () => {
    autoShots(api, autoShotCount(api)); renderAll(api);
  });
  on('[data-act="sample"]', () => {
    const sample = buildSamplePlan(api._DATA);
    if (!sample) { flash(api, "⚠ need at least one location + clothing set to build a sample", true); return; }
    const obj = parsePlanText(sample);
    applyParsed(api, obj);
    flash(api, `✓ sample plan loaded (${api.st.shots.length} shots, from your data)`);
    renderAll(api);
  });
  on('[data-act="load"]', () => loadFromPlan(api, planWidget));
  on('[data-act="save"]', () => savePlanToFile(api));
  on('[data-act="loadfile"]', () => loadPlanFromFile(api));
  on('[data-act="refresh"]', async () => {
    flash(api, "↻ reloading data…");
    try {
      const { data: fresh } = await loadEditorData();
      if (!fresh || !fresh.locations || !fresh.locations.length) throw new Error("empty data");
      api._DATA = fresh;
      // re-fill the model/location/clothing/style/quality/camera selects
      const fill = (name, opts, cur) => {
        const el = editor.querySelector(`select[data-f="${name}"]`);
        if (!el) return;
        const keep = cur || st[name];
        el.innerHTML = opts.map(o => `<option value="${o.value}" ${o.value === keep ? "selected" : ""}>${o.label}</option>`).join("");
        st[name] = keep && opts.some(o => o.value === keep) ? keep : (opts[0] ? opts[0].value : "");
      };
      fill("model", (fresh.models || []).map(m => ({ value: m, label: m })), st.model);
      fill("location", (fresh.locations || []).map(l => ({ value: l.name, label: l.label || l.name })), st.location);
      fill("clothing", (fresh.clothing || []).map(c => ({ value: c.name, label: c.label || c.name })), st.clothing);
      fill("style", (fresh.styles || []).map(s => ({ value: s, label: s })), st.style);
      fill("quality", (fresh.qualities || []).map(q => ({ value: q, label: q })), st.quality);
      const camEl = editor.querySelector('select[data-f="camera"]');
      if (camEl) {
        const cOpts = [{ value: "", label: "— none —" }].concat((fresh.cameras || []).map(c => ({ value: c.id, label: `${c.brand} ${c.model} (${c.id})` })));
        camEl.innerHTML = cOpts.map(o => `<option value="${o.value}" ${o.value === st.camera ? "selected" : ""}>${o.label}</option>`).join("");
        st.camera = st.camera && cOpts.some(o => o.value === st.camera) ? st.camera : "";
      }
      // re-map any shots that referenced now-missing ids
      remapShotsForLocation(api);
      clearStaleCustom(api);
      renderAll(api);
      flash(api, `✓ data refreshed — ${(fresh.locations || []).length} locations · ${(fresh.clothing || []).length} sets · ${(fresh.models || []).length} models · ${(fresh.cameras || []).length} cams`);
    } catch (e) {
      console.warn("[ASB] refresh data:", e);
      flash(api, "⚠ could not refresh — run scripts/export_planner_data.py, restart ComfyUI, then refresh the browser", true);
    }
  });
  on('[data-act="clear"]', () => clearAll(api));
  on('[data-act="apply"]', () => {
    applyToNode(api, planWidget);
    // open the preview so the user sees the expanded result right away
    if (!outOpen) editor.querySelector('[data-act="toggleout"]').click();
  });

  // output preview toggle
  const outBody = editor.querySelector('[data-role="outbody"]');
  let outOpen = false;
  on('[data-act="toggleout"]', () => {
    outOpen = !outOpen;
    const b = editor.querySelector('[data-role="outbody"]');
    const t = editor.querySelector('[data-act="toggleout"]');
    if (b) b.style.display = outOpen ? "" : "none";
    if (t) t.textContent = outOpen ? "▾ Output preview" : "▸ Output preview";
    renderOutputPreview(api, null);
    if (outOpen) debouncedExpand(api);
    if (node.graph) node.graph.setDirtyCanvas(true, true);
  });
  on('[data-act="outcopy"]', async () => {
    const txt = api._serverPlanJson || buildYAML(api.st);
    try { await navigator.clipboard.writeText(txt); flash(api, "✓ plan_json copied"); }
    catch (e) { flash(api, "⚠ copy failed", true); }
  });
  on('[data-act="outrefresh"]', () => expandPreviewClient(api));

  // server panel
  const serverPanel = editor.querySelector('[data-role="server"]');
  let serverOpen = false;
  on('[data-act="server"]', () => {
    serverOpen = !serverOpen;
    if (serverPanel) serverPanel.style.display = serverOpen ? "" : "none";
    if (serverOpen) {
      const nm = editor.querySelector('input[data-f="serverName"]');
      if (nm && !nm.value) nm.value = defaultServerName(api);
      refreshServerList(api);
    }
    if (node.graph) node.graph.setDirtyCanvas(true, true);
  });
  on('[data-act="serversave"]', () => savePlanToServer(api));
  on('[data-act="serverrefresh"]', () => refreshServerList(api));

  return api;
}

function resetPieces(api) { for (const s of api.st.shots) { s.piece = ""; s.custom = {}; } }

// When the user switches LOCATION, existing shots keep the OLD zone ids (and
// pieces) which makes the whole plan fail to expand -> "empty plan_json".
// Re-map every shot to the NEW location: zone rotates through the new zones,
// piece = a pose compatible with the shot's current outfit level.
function remapShotsForLocation(api) {
  const zones = locZones(api.st, api._DATA);
  if (!zones.length) { api.st.shots = []; return; }
  api.st.shots.forEach((s, i) => {
    const z = zones[i % zones.length];
    s.zone = z.zone_id || z.name;
    const pieces = zonePieces(api.st, api._DATA, s.zone);
    const lvl = computeLevel(api.st.clothing, outfitMapOf(api, i), api._DATA);
    const p = pieces.find(x => (x.levels || []).includes(lvl)) || pieces[0] || {};
    s.piece = p.id || "";
  });
}

// When the user switches CLOTHING SET, any "custom" outfit maps hold OLD item
// ids -> those shots fail to expand. Reset them to inherit (no stale ids).
function clearStaleCustom(api) {
  api.st.shots.forEach(s => {
    s.custom = {};
    s.mode = "inherit";
    s.transition = "none";
  });
}

// Clear EVERYTHING: the shot list and the node's plan field.
function clearAll(api) {
  api.st.shots = [];
  try { writePlanWidget(api.node, ""); } catch (e) { console.warn("[ASB] clear plan:", e); }
  try {
    const ta = api.editor.querySelector('[data-role="outbody"]');
    if (ta) ta.textContent = "";
    const cnt = api.editor.querySelector('[data-role="outcount"]');
    if (cnt) cnt.textContent = "";
  } catch (e) {}
  renderAll(api);
  flash(api, "🧹 cleared shot list + plan field");
}
// default fields for a NEW shot so nothing is left blank:
//   zone    - cycles to the next zone (after the last shot's zone)
//   piece   - the first piece in that zone compatible with the level the shot
//             will be at (inherit -> previous outfit), else the zone's first
//   framing - auto-picked from the framing DB for the piece type (else "")
//   mode    - "inherit" (keeps the wardrobe state), transition "none"
//   note    - a default director's note
function defaultShotFields(api) {
  const { st, _DATA } = api;
  const zones = locZones(st, _DATA);
  const framings = _DATA.framing || [];
  if (!zones.length) return { zone: "", piece: "", framing: "", mode: "inherit", custom: {}, transition: "none", note: "" };
  // zone: cycle to the next zone after the last shot
  let zone = zones[0];
  if (st.shots.length) {
    const lastZone = st.shots[st.shots.length - 1].zone;
    const li = zones.findIndex(z => (z.zone_id || z.name) === lastZone);
    zone = zones[(li + 1) % zones.length] || zones[0];
  }
  const zid = zone.zone_id || zone.name;
  const pieces = zonePieces(st, _DATA, zid);
  // level this shot would be at (inherit previous outfit)
  const prevIdx = st.shots.length - 1;
  const prevMap = prevIdx >= 0 ? outfitMapOf(api, prevIdx) : null;
  const lvl = prevMap ? computeLevel(st.clothing, prevMap, _DATA) : "level_0";
  let piece = pieces.find(p => (p.levels || []).includes(lvl)) || pieces[0] || {};
  // framing: prefer a preset whose default_for_piece_types matches the pose
  const ptype = (piece.label || "").split("|")[1] ? (piece.label.split("|")[1] || "").trim() : "";
  const fhit = framings.find(f => (f.default_for_piece_types || []).includes(ptype));
  return {
    zone: zid,
    piece: piece.id || "",
    framing: fhit ? fhit.id : "",
    mode: "inherit",
    custom: {},
    transition: "none",
    note: autoNote(api, st.shots.length),
  };
}

function addShot(api) {
  api.st.shots.push(defaultShotFields(api));
}

function renderAll(api) {
  updateStatus(api);
  renderShots(api);
  // keep the Auto button label in sync with the node's auto_shots input
  const an = api.editor.querySelector('[data-role="auton"]');
  if (an) an.textContent = autoShotCount(api);
  // update the client mirror immediately, then the server engine (debounced)
  renderOutputPreview(api, null);
  debouncedExpand(api);
}

// ---------- live output preview (what the node will produce) ----------
function clientStoryboard(api) {
  const { st, _DATA } = api;
  const lines = [];
  lines.push(`SHOOT: ${st.title || "untitled"}`);
  lines.push(`MODEL: ${st.model || "-"}   LOCATION: ${st.location || "-"}   WARDROBE: ${st.clothing || "-"}`);
  const cam = (_DATA.cameras || []).find(x => x.id === st.camera);
  lines.push(`CAMERA: ${cam ? cam.brand + " " + cam.model : (st.camera || "-")}   SEED: ${st.seed}`);
  lines.push("");
  const removed = removedStatesOf(api);
  st.shots.forEach((s, i) => {
    const map = outfitMapOf(api, i);
    const lvl = computeLevel(st.clothing, map, _DATA);
    const offN = Object.values(map).filter(v => removed.includes(v)).length;
    const outcome = Object.entries(map).map(([k, v]) => `${k}=${v}`).join(" ");
    lines.push(
      `${String(i).padStart(2)}  ${(s.zone || "-").padEnd(10)}  ${(s.piece || "-").padEnd(12)}  ` +
      `${lvl.padEnd(8)} ${offN} off  ${(s.framing || "-").padEnd(12)} ${outcome}`);
  });
  return lines.join("\n");
}

// Expand the plan on the SERVER with the real Python engine (no queue, no
// sampler, no image generation). Fallback: client-side mirror if the route is
// unavailable (e.g. page opened outside ComfyUI).
async function expandPreviewClient(api) {
  const yaml = currentPlanText(api);
  const body = api.editor.querySelector('[data-role="outbody"]');
  if (!yaml) {
    if (body) body.textContent = "";
    const cnt = api.editor.querySelector('[data-role="outcount"]');
    if (cnt) cnt.textContent = "";
    return;
  }
  if (body) body.textContent = "expanding with server engine…";
  try {
    const r = await fetch("/asb/expand", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        plan: yaml,
        seed: api.st.seed,
        style: api.st.style,
        quality: api.st.quality,
        detail_level: "standard",
        auto_negative: true,
        template: "(none)",
        camera: api.st.camera,
        framing: "",
      }),
    });
    const res = await r.json();
    if (res && res.ok) {
      renderOutputPreview(api, res);
      return;
    }
    if (res && res.error) console.warn("[ASB] expand error:", res.error);
  } catch (e) { /* route unavailable */ }
  renderOutputPreview(api, null); // fallback: client mirror
}

function renderOutputPreview(api, serverRes) {
  const body = api.editor.querySelector('[data-role="outbody"]');
  const cnt = api.editor.querySelector('[data-role="outcount"]');
  if (!body) return;
  if (serverRes) {
    const n = serverRes.count || 0;
    body.textContent = serverRes.storyboard || "(no shots)";
    if (cnt) cnt.textContent = ` · ${n} shots (server engine)`;
    // stash the authoritative plan_json on the api for copy
    api._serverPlanJson = serverRes.plan_json || "";
    api._serverShotsCsv = serverRes.shots_csv || "";
    return;
  }
  if (api.st.shots.length) {
    body.textContent = clientStoryboard(api);
    if (cnt) cnt.textContent = ` · ${api.st.shots.length} shots (client mirror)`;
  } else {
    body.textContent = "";
    if (cnt) cnt.textContent = "";
  }
}

function debouncedExpand(api) {
  clearTimeout(api._expandT);
  api._expandT = setTimeout(() => expandPreviewClient(api), 450);
}

function renderShots(api) {
  const { editor, st, _DATA } = api;
  const host = editor.querySelector('[data-role="shots"]');
  host.innerHTML = "";
  const items = clothItems(st, _DATA);
  const zones = locZones(st, _DATA);
  const framings = _DATA.framing || [];
  const removed = removedStatesOf(api);

  if (!st.shots.length) {
    host.innerHTML = `<div class="pe-empty">No shots yet — click "＋ Shot" to add one, or "🧩 Auto N shots" to generate an undress sequence from the location + wardrobe.</div>`;
    updateStatus(api);
    return;
  }

  st.shots.forEach((s, i) => {
    const map = outfitMapOf(api, i);
    const lvl = computeLevel(st.clothing, map, _DATA);
    const z = zones.find(x => (x.zone_id || x.name) === s.zone) || zones[0];
    const pieces = zonePieces(st, _DATA, z ? (z.zone_id || z.name) : "");
    const removedN = Object.values(map).filter(v => removed.includes(v)).length;

    // the EXACT prompt words this shot will use: the piece's `prompt` field +
    // the clothing `prompt_phrase` for the current states (from your data files)
    const pObj = pieces.find(p => p.id === s.piece) || pieces[0] || {};
    const promptWords = pObj.prompt || "";
    const clothWords = items.map(it => {
      const k = it.item_id || it.name;
      const curSt = map[k];
      const ph = it.state_phrases && it.state_phrases[curSt];
      return ph || "";
    }).filter(Boolean).join(", ");
    const promptPreview = [promptWords, clothWords].filter(Boolean).join(" — ");

    const card = document.createElement("div");
    card.className = "pe-shot";
    card.innerHTML = `
      <div class="pe-shot-top">
        <span class="pe-no">${i}</span>
        <span class="pe-lvl l${lvl.split("_")[1]}">${lvl} · ${removedN} off</span>
        <span style="flex:1"></span>
        <button class="pe-ic" data-ic="up">↑</button>
        <button class="pe-ic" data-ic="down">↓</button>
        <button class="pe-ic" data-ic="del">✕</button>
      </div>
      <div class="pe-row">
        <div><label>Zone</label><select data-f="zone"></select></div>
        <div><label>Pose</label><select data-f="piece"></select></div>
        <div><label>Outfit</label><select data-f="mode">
          <option value="inherit">inherit prev</option>
          <option value="fully_worn">all on</option>
          <option value="removed">all off</option>
          <option value="custom">custom…</option>
        </select></div>
      </div>
      <div class="pe-row2">
        <div><label>Framing / angle</label><select data-f="framing">
          <option value="">— auto / default —</option>
          <option value="__custom__">custom…</option>
        </select><input type="text" data-f="framingCustom" placeholder="e.g. low angle" style="display:none;margin-top:2px"></div>
        <div><label>Transition</label><select data-f="transition">
          <option value="none">— none —</option>
          <option value="reset">reset (all on)</option>
        </select></div>
      </div>
      <div data-role="custom"></div>
    `;

    const zsel = card.querySelector('select[data-f="zone"]');
    zones.forEach(zd => {
      const v = zd.zone_id || zd.name;
      const o = document.createElement("option");
      o.value = v; o.textContent = zd.name; o.selected = v === s.zone;
      zsel.appendChild(o);
    });
    zsel.onchange = () => { s.zone = zsel.value; s.piece = ""; renderShots(api); };

    const psel = card.querySelector('select[data-f="piece"]');
    pieces.forEach(p => {
      const o = document.createElement("option");
      o.value = p.id; o.textContent = p.label; o.selected = p.id === s.piece;
      psel.appendChild(o);
    });
    psel.onchange = () => { s.piece = psel.value; };

    const msel = card.querySelector('select[data-f="mode"]');
    msel.value = s.mode;
    msel.onchange = () => { s.mode = msel.value; if (s.mode !== "inherit") s.transition = "none"; renderShots(api); };

    const fsel = card.querySelector('select[data-f="framing"]');
    framings.forEach(f => {
      const o = document.createElement("option");
      o.value = f.id; o.textContent = `${f.name} (${f.id})`; o.selected = f.id === s.framing;
      fsel.appendChild(o);
    });
    const fCustom = card.querySelector('input[data-f="framingCustom"]');
    const isCustom = s.framing && !framings.some(f => f.id === s.framing);
    fsel.value = isCustom ? "__custom__" : (s.framing || "");
    fCustom.style.display = isCustom ? "" : "none";
    fCustom.value = isCustom ? s.framing : "";
    fsel.onchange = () => {
      if (fsel.value === "__custom__") { fCustom.style.display = ""; fCustom.focus(); s.framing = fCustom.value; }
      else { fCustom.style.display = "none"; s.framing = fsel.value; }
      renderShots(api);
    };
    fCustom.onchange = () => { s.framing = fCustom.value; };

    const tsel = card.querySelector('select[data-f="transition"]');
    const transOpts = [["none", "— none —"], ["reset", "reset (all on)"]];
    items.forEach(it => {
      const id = it.item_id || it.name;
      transOpts.push([`advance: ${id}`, `advance: ${it.name}`]);
      transOpts.push([`remove: ${id}`, `remove: ${it.name}`]);
      transOpts.push([`dress: ${id}`, `dress: ${it.name}`]);
      it.states.forEach(stt => transOpts.push([`set: ${id} -> ${stt}`, `set: ${it.name} -> ${stt}`]));
    });
    transOpts.forEach(([v, label]) => {
      const o = document.createElement("option");
      o.value = v; o.textContent = label; o.selected = v === s.transition;
      tsel.appendChild(o);
    });
    tsel.onchange = () => { s.transition = tsel.value; if (s.transition !== "none") s.mode = "inherit"; renderShots(api); };

    // prompt-words preview (the fields from your data that generation uses)
    const pv = document.createElement("div");
    pv.className = "pe-prompt";
    pv.textContent = promptPreview ? "prompt: " + promptPreview : "prompt: (no data text for this piece)";
    card.appendChild(pv);


    const customBox = card.querySelector('[data-role="custom"]');
    if (s.mode === "custom") {
      customBox.className = "pe-custom";
      items.forEach(it => {
        const k = it.item_id || it.name;
        const wrap = document.createElement("div");
        wrap.innerHTML = `<label>${it.name}</label><select></select>`;
        const sel2 = wrap.querySelector("select");
        sel2.appendChild(new Option("inherit", ""));
        it.states.forEach(stt => sel2.appendChild(new Option(stt, stt)));
        sel2.value = s.custom[k] || "";
        sel2.onchange = () => { s.custom[k] = sel2.value; renderShots(api); };
        customBox.appendChild(wrap);
      });
    }

    card.querySelector('[data-ic="up"]').onclick = () => { if (i > 0) { const t = st.shots[i]; st.shots[i] = st.shots[i-1]; st.shots[i-1] = t; renderAll(api); } };
    card.querySelector('[data-ic="down"]').onclick = () => { if (i < st.shots.length - 1) { const t = st.shots[i]; st.shots[i] = st.shots[i+1]; st.shots[i+1] = t; renderAll(api); } };
    card.querySelector('[data-ic="del"]').onclick = () => { st.shots.splice(i, 1); renderAll(api); };

    host.appendChild(card);
  });

  // cap visible cards at MAX_VISIBLE_SHOTS (scroll beyond)
  host.style.maxHeight = `${MAX_VISIBLE_SHOTS * 108}px`;
  const note = editor.querySelector('[data-role="scrollnote"]');
  if (note) note.textContent = st.shots.length > MAX_VISIBLE_SHOTS
    ? `showing up to ${MAX_VISIBLE_SHOTS} of ${st.shots.length} — scroll for the rest`
    : "";
  updateStatus(api);
}

function planSlug(st) {
  const s = String(st.title || "shoot").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
  return s || "shoot";
}

// ---------- save / load plan files (browser download + file picker) ----------
function savePlanToFile(api) {
  let yaml = "";
  if (api.st.shots.length) yaml = buildYAML(api.st);
  else if (api.planWidget && api.planWidget.value) yaml = api.planWidget.value;
  if (!yaml) { flash(api, "⚠ nothing to save — add shots first", true); return; }
  try {
    const blob = new Blob([yaml], { type: "text/yaml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `asb_plan_${planSlug(api.st)}_${new Date().toISOString().slice(0, 10)}.yaml`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    const n = api.st.shots.length ? api.st.shots.length : "(plan text)";
    flash(api, `✓ plan saved to file (${n} shots)`);
  } catch (e) {
    console.warn("[ASB] save file:", e);
    flash(api, "⚠ save failed: " + e.message, true);
  }
}

function loadPlanFromFile(api) {
  if (!api._fileInput) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".yaml,.yml,.json,.txt";
    input.style.display = "none";
    document.body.appendChild(input);
    api._fileInput = input;
    input.onchange = () => {
      const f = input.files && input.files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const obj = parsePlanText(String(reader.result || ""));
          if (!obj.shots || !obj.shots.length) throw new Error("no shots found");
          applyParsed(api, obj);
          renderAll(api);
          flash(api, `✓ loaded ${api.st.shots.length} shots from ${f.name}`);
        } catch (e2) {
          console.warn("[ASB] load file parse:", e2);
          flash(api, "⚠ could not parse " + f.name, true);
        }
        input.value = "";
      };
      reader.onerror = () => flash(api, "⚠ could not read file", true);
      reader.readAsText(f);
    };
  }
  api._fileInput.click();
}

// ---------- server-side plan storage (ComfyUI /asb/plans API) ----------
const API = {
  async list() {
    const r = await fetch("/asb/plans", { cache: "no-store" });
    return r.ok ? r.json() : { plans: [], dir: "" };
  },
  async save(name, content) {
    const r = await fetch("/asb/plans", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, content }),
    });
    return r.ok ? r.json() : null;
  },
  async get(name) {
    const r = await fetch(`/asb/plans/${encodeURIComponent(name)}`);
    return r.ok ? r.json() : null;
  },
  async del(name) {
    const r = await fetch(`/asb/plans/${encodeURIComponent(name)}`, { method: "DELETE" });
    return r.ok;
  },
};

function currentPlanText(api) {
  if (api.st.shots.length) return buildYAML(api.st);
  if (api.planWidget && api.planWidget.value) return api.planWidget.value;
  return "";
}

function defaultServerName(api) {
  const slug = planSlug(api.st);
  const d = new Date().toISOString().slice(0, 10);
  return `asb_plan_${slug}_${d}.yaml`;
}

async function refreshServerList(api) {
  const listEl = api.editor.querySelector('[data-role="serverlist"]');
  if (!listEl) return;
  listEl.innerHTML = '<span class="pe-note">loading…</span>';
  try {
    const data = await API.list();
    if (!data.plans || !data.plans.length) {
      listEl.innerHTML = `<span class="pe-note">no saved plans yet${data.dir ? " — " + data.dir : ""}</span>`;
      return;
    }
    const rows = data.plans.map(name => `
      <div class="pe-server-row">
        <span class="pe-sname">${name}</span>
        <button data-srv="load" data-name="${name}">Load</button>
        <button data-srv="del" data-name="${name}" class="pe-ic">🗑</button>
      </div>`).join("");
    listEl.innerHTML = `<div class="pe-note">${data.plans.length} saved · ${data.dir || ""}</div>` + rows;
    listEl.querySelectorAll("[data-srv]").forEach(btn => {
      btn.onclick = async () => {
        const nm = btn.getAttribute("data-name");
        if (btn.getAttribute("data-srv") === "load") {
          const got = await API.get(nm);
          if (!got) { flash(api, "⚠ could not load " + nm, true); return; }
          try {
            const obj = parsePlanText(got.content || "");
            applyParsed(api, obj);
            renderAll(api);
            flash(api, `✓ loaded ${api.st.shots.length} shots from ${nm}`);
          } catch (e) {
            flash(api, "⚠ could not parse " + nm, true);
          }
        } else {
          await API.del(nm);
          flash(api, `🗑 deleted ${nm}`);
          refreshServerList(api);
        }
      };
    });
  } catch (e) {
    listEl.innerHTML = `<span class="pe-err">⚠ server API unavailable (${e.message}) — is this served by ComfyUI?</span>`;
  }
}

async function savePlanToServer(api) {
  const yaml = currentPlanText(api);
  if (!yaml) { flash(api, "⚠ nothing to save — add shots first", true); return; }
  const nameEl = api.editor.querySelector('input[data-f="serverName"]');
  const name = (nameEl && nameEl.value.trim()) ? nameEl.value.trim() : defaultServerName(api);
  try {
    const res = await API.save(name, yaml);
    if (!res || !res.ok) { flash(api, "⚠ server save failed", true); return; }
    if (nameEl) nameEl.value = res.name;
    flash(api, `✓ saved to server: ${res.name}`);
    refreshServerList(api);
  } catch (e) {
    console.warn("[ASB] server save:", e);
    flash(api, "⚠ server save failed: " + e.message, true);
  }
}

// ---------- plan widget access (robust across ComfyUI versions) ----------
function findPlanWidget(node) {
  if (!node || !node.widgets) return null;
  let w = node.widgets.find(x => x.name === "plan");
  if (!w) w = node.widgets.find(x => x.name && x.name.toLowerCase().includes("plan"));
  return w || null;
}

// Read the CURRENT plan text from the live widget. Order matches how litegraph
// serializes widgets when building the queue payload:
//   1) serialize_value  (if set, THIS is what the server receives)
//   2) widget.value
//   3) the DOM element (textarea/input) — display only
// This is critical: after Apply, if we only set .value and litegraph reads
// serialize_value (stale/empty), the server gets an EMPTY plan — the exact
// "again empty plan" bug.
function readPlanWidget(node) {
  const w = findPlanWidget(node);
  if (!w) return "";
  try {
    if (w.serialize_value !== undefined && w.serialize_value !== null &&
        String(w.serialize_value).length) return String(w.serialize_value);
  } catch (e) { /* ignore */ }
  try {
    if (w.value !== undefined && w.value !== null && String(w.value).length) return String(w.value);
  } catch (e) { /* ignore */ }
  try {
    const dom = w.inputEl
      || (w.element && w.element.value !== undefined && w.element)
      || (w.element && w.element.querySelector && w.element.querySelector("textarea"));
    if (dom && dom.value !== undefined && String(dom.value).length) return String(dom.value);
  } catch (e) { /* ignore */ }
  return "";
}

// Write the plan text into the live widget through every layer ComfyUI uses,
// then verify by reading back. Returns true on success.
function writePlanWidget(node, yaml) {
  const w = findPlanWidget(node);
  if (!w) { console.warn("[ASB] plan widget not found"); return false; }

  // 0) ComfyUI-native setWidgetValue if present (routes everything safely)
  if (typeof node.setWidgetValue === "function") {
    try { node.setWidgetValue("plan", yaml); }
    catch (e) { console.warn("[ASB] setWidgetValue:", e); }
  }

  // 1) visible DOM element (textarea / input)
  try {
    const dom = w.inputEl
      || (w.element && w.element.value !== undefined && w.element)
      || (w.element && w.element.querySelector && w.element.querySelector("textarea"));
    if (dom && dom.value !== undefined) {
      dom.value = yaml;
      const fire = (t) => {
        try {
          if (typeof dom.dispatchEvent === "function") dom.dispatchEvent(new Event(t, { bubbles: true }));
        } catch (_) {}
      };
      fire("input");
      fire("change");
      fire("blur");
    }
  } catch (e) { console.warn("[ASB] apply dom:", e); }

  // 2) the widget value itself
  try { w.value = yaml; } catch (e) { console.warn("[ASB] apply value:", e); }

  // 3) serialize_value — litegraph serializes widgets as `serialize_value ??
  //    value` when building the queue payload; if this is stale/empty the
  //    server receives an empty plan. MUST set it.
  try { w.serialize_value = yaml; } catch (e) { console.warn("[ASB] apply serialize_value:", e); }

  // 4) mark the graph dirty so save / queue serializes the new value
  try { if (node.graph) node.graph.setDirtyCanvas(true, true); } catch (e) { console.warn("[ASB] apply dirty:", e); }

  return true;
}

// ---------- apply (bulletproof) ----------
// NOTE: never call widget.callback(...) directly — ComfyUI wraps input-widget
// callbacks and expects the full (value, canvas, node, pos, event) signature;
// calling with a bare value crashes with "Cannot destructure property 'e' of
// 'undefined'". We write the value + DOM element and dispatch real events.
function applyToNode(api, planWidget) {
  if (!api.st.shots.length) {
    // if the editor is empty but the node already has plan text, load it first
    const existing = readPlanWidget(api.node);
    if (existing) {
      try {
        const obj = parsePlanText(existing);
        if (obj.shots && obj.shots.length) { applyParsed(api, obj); renderAll(api); }
      } catch (e) { /* ignore */ }
    }
    if (!api.st.shots.length) { flash(api, "⚠ add shots first, then Apply", true); return; }
  }
  const yaml = buildYAML(api.st);
  const node = api.node;
  const ok = writePlanWidget(node, yaml);
  if (!ok) { flash(api, "⚠ plan widget not found", true); return; }

  // verify by reading back through the same path ComfyUI serializes
  const back = readPlanWidget(node);
  const landed = back === yaml;
  console.info(`[ASB] apply → plan widget ${landed ? "OK" : "MISMATCH"} (${yaml.length} chars, read-back ${back.length})`);
  if (!landed) {
    // force the widget value once more (some versions keep value in the object)
    try { const w = findPlanWidget(node); if (w) w.value = yaml; } catch (e) {}
  }

  flash(api, landed
    ? `✓ plan applied (${api.st.shots.length} shots) — run the node to refresh outputs`
    : "⚠ plan written but read-back differs — see console", !landed);
  // refresh the live preview with the authoritative server engine (no queue)
  debouncedExpand(api);
}

// ---------- load ----------
function applyParsed(api, obj) {
  const st = api.st;
  const D = api._DATA || {};
  const models = D.models || [];
  const locations = D.locations || [];
  const clothing = D.clothing || [];
  const styles = D.styles || [];
  const qualities = D.qualities || [];
  const cameras = D.cameras || [];
  if (obj.model && models.includes(obj.model)) st.model = obj.model;
  if (obj.location && locations.some(l => l.name === obj.location)) st.location = obj.location;
  if (obj.clothing_set && clothing.some(c => c.name === obj.clothing_set)) st.clothing = obj.clothing_set;
  if (obj.style && styles.includes(obj.style)) st.style = obj.style;
  if (obj.quality && qualities.includes(obj.quality)) st.quality = obj.quality;
  if (obj.camera && cameras.some(c => c.id === obj.camera)) st.camera = obj.camera;
  if (obj.title) st.title = obj.title;
  if (obj.seed) st.seed = parseInt(obj.seed) || 1;
  // intelligence: report ids in the loaded plan that are NOT in current data,
  // so the user knows why some things didn't transfer
  const missing = [];
  if (obj.model && !models.includes(obj.model)) missing.push("model '" + obj.model + "'");
  if (obj.location && !locations.some(l => l.name === obj.location)) missing.push("location '" + obj.location + "'");
  if (obj.clothing_set && !clothing.some(c => c.name === obj.clothing_set)) missing.push("clothing '" + obj.clothing_set + "'");
  if (obj.camera && !cameras.some(c => c.id === obj.camera)) missing.push("camera '" + obj.camera + "'");
  if (missing.length) flash(api, "⚠ not in current data: " + missing.join(", "), true);
  st.shots = [];
  if (Array.isArray(obj.shots) && obj.shots.length) {
    obj.shots.forEach(s => {
      const sh = { zone: s.zone || "", piece: s.piece || "", framing: s.framing || "",
                   mode: "inherit", custom: {}, transition: "none", note: s.note || "" };
      if (s.outfit === "fully_worn") sh.mode = "fully_worn";
      else if (s.outfit === "removed") sh.mode = "removed";
      else if (s.outfit && typeof s.outfit === "object") { sh.mode = "custom"; sh.custom = { ...s.outfit }; }
      else if (s.transition) sh.transition = s.transition;
      api.st.shots.push(sh);
    });
    // heal blank zones left by the old parser bug so the plan still runs —
    // point them at the first zone of the selected location and warn loudly
    const zl = locZones(st, D);
    let healed = 0;
    st.shots.forEach(s => {
      if (!s.zone || !String(s.zone).trim()) {
        const z0 = zl[0];
        if (z0) { s.zone = z0.zone_id || z0.name; healed++; }
      }
    });
    if (healed) {
      const zn = zl[0] ? (zl[0].name || zl[0].zone_id) : "first zone";
      flash(api, `⚠ ${healed} shot(s) had a blank zone (old saved-plan bug) — set to "${zn}", please verify each shot`, true);
    }
  }
  ["model", "location", "clothing", "style", "quality", "camera"].forEach(f => {
    const el = api.editor.querySelector(`select[data-f="${f}"]`);
    if (el) el.value = api.st[f];
  });
  api.editor.querySelector('input[data-f="title"]').value = api.st.title;
  api.editor.querySelector('input[data-f="seed"]').value = api.st.seed;
}

function loadFromPlan(api, planWidget) {
  // fresh lookup — never trust a stale captured reference
  const src = (api.node && readPlanWidget(api.node)) || (planWidget && planWidget.value) || "";
  if (!src) { flash(api, "⚠ plan text is empty — nothing to load", true); return; }
  try {
    const obj = parsePlanText(src);
    if (!obj.shots || !obj.shots.length) { flash(api, "⚠ plan text has no shots", true); return; }
    applyParsed(api, obj);
    flash(api, `✓ loaded ${api.st.shots.length} shots from plan`);
    renderAll(api);
  } catch (err) {
    console.warn("[ASB] load from plan failed:", err);
    flash(api, "⚠ could not parse plan text", true);
  }
}

app.registerExtension({
  name: "ArtisticSetBuilder.ShootPlanEditor",

  beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name !== "ASB_ShootPlan") return;
    const onNodeCreated = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      const r = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;
      if (this.__asbPlannerInit) return r;
      this.__asbPlannerInit = true;

      if (typeof this.addDOMWidget !== "function") return r;
      const planWidget = (this.widgets || []).find(w => w.name === "plan");
      const host = document.createElement("div");
      host.style.width = "100%";
      host.style.height = "100%";
      host.style.overflow = "hidden";

      // The DOM widget MUST track the node's actual size — width follows the
      // node width, height is clamped between MIN_NODE_H and MAX_NODE_H so the
      // node can never grow endlessly, and onResize recomputes on every drag.
      const domW = this.addDOMWidget("plan_editor", "div", host, {
        serialize: false,
        hideOnZoom: true,
        getWidth: () => {
          const w = this.size ? this.size[0] : 480;
          return Math.max(260, w - 12);          // node width minus padding
        },
        getMinHeight: () => MIN_NODE_H,
        getMaxHeight: () => MAX_NODE_H,
        getHeight: () => {
          const h = this.size ? this.size[1] : 760;
          return Math.max(MIN_NODE_H, Math.min(h - 44, MAX_NODE_H));
        },
      });
      if (domW && domW.computeSize) domW.computeSize();

      // live resize: keep the widget sized to the node whenever the user drags
      // the node's sides (this is the fix for "widget not extending with node")
      this.onResize = function (size) {
        if (!domW) return;
        try {
          if (host) {
            host.style.width = "100%";
            host.style.height = "100%";
          }
          if (domW.computeSize) domW.computeSize();
          if (domW.onDraw) domW.onDraw(this.ctx);
        } catch (e) { console.warn("[ASB] onResize:", e); }
        if (this.graph) this.graph.setDirtyCanvas(true, true);
      };
      this.setSize([480, 760]);
      if (this.graph) this.graph.setDirtyCanvas(true, true);

      // remember the editor api for later re-syncs
      const self = this;
      this.__asbApiRef = { api: null };
      const loaded = (D) => {
        if (!D) return;
        const api = buildEditor(host, self, planWidget, D);
        api._DATA = D;
        self.__asbApiRef.api = api;
        const txt = readPlanWidget(self);
        if (txt && txt.trim()) {
          try { applyParsed(api, parsePlanText(txt)); } catch (e) {}
        }
        renderAll(api);
      };
      // load editor data LIVE from the server (data/ folder), snapshot as fallback
      loadEditorData()
        .then(({ data: D, live }) => {
          if (!D) {
            host.innerHTML = `<div class="asb-pe"><div class="pe-err">⚠ no data available.</div></div>`;
            return;
          }
          loaded(D);
          self.__asbLiveData = !!live;
        })
        .catch(err => {
          host.innerHTML = `<div class="asb-pe"><div class="pe-err">⚠ could not load planner data: ${err}</div></div>`;
        });

      // when a saved workflow is loaded, ComfyUI calls configure AFTER widget
      // values are set — re-sync the editor from the (now populated) plan widget
      const onConfigure = nodeType.prototype.onConfigure;
      nodeType.prototype.onConfigure = function () {
        const rr = onConfigure ? onConfigure.apply(this, arguments) : undefined;
        const api = this.__asbApiRef && this.__asbApiRef.api;
        if (api) {
          const txt = readPlanWidget(this);
          if (txt && txt.trim()) {
            try { applyParsed(api, parsePlanText(txt)); renderAll(api); } catch (e) {}
          }
        }
        return rr;
      };
      return r;
    };
  },
});
