#!/usr/bin/env python3
"""
Export pack data to web/planner_data.json for the visual Shoot Designer page
(web/planner.html). Run after editing any data file:

    python scripts/export_planner_data.py
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.database import (  # noqa: E402
    first_camera, first_clothing, first_location, first_model,
    get_clothing_list, get_location_list, get_model_list, load_cameras,
    load_framing, load_json,
)
from utils.prompts import QUALITY_PRESETS, STYLE_PRESETS  # noqa: E402

ALL_LEVELS = ["level_0", "level_1", "level_2", "level_3", "level_4"]


def build_sample_plan():
    """
    Build a small loadable plan from the FIRST available model/location/
    clothing/camera in the user's data folders — never hardcodes any id.
    Used so the pack always has an example that matches YOUR data.
    """
    m = first_model()
    ln = first_location()
    cn = first_clothing()
    cam = first_camera()
    if not m or not ln or not cn:
        return None
    loc = load_json("locations", ln)
    cl = load_json("clothing", cn)
    zones = loc.get("photo_zones", [])
    items = cl.get("items", [])
    if not zones or not items:
        return None
    lines = ['title: "Sample shoot (from your data)"',
             f"model: {m}", f"location: {ln}", f"clothing_set: {cn}",
             "style: soft boudoir", "quality: film"]
    if cam:
        lines.append(f"camera: {cam}")
    lines += ["seed: 1", "shots:"]
    for zi, z in enumerate(zones[:6]):
        zid = z.get("zone_id") or z.get("name")
        pieces = z.get("prompt_pieces", [])
        p0 = next((p for p in pieces
                   if "level_0" in p.get("compatible_clothing_levels", [])), None)             or (pieces[0] if pieces else None)
        if not p0:
            continue
        lines.append(f"  - zone: {zid}")
        lines.append(f"    piece: {p0.get('id')}")
        if zi == 0:
            lines.append("    outfit: fully_worn")
        elif items:
            it = items[(zi - 1) % len(items)]
            lines.append(f'    transition: "advance: {it.get("item_id", it.get("name"))}"')
    return "\n".join(lines)


def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    web_dir = os.path.join(root, "web")

    data = {
        "models": get_model_list(),
        "locations": [],
        "clothing": [],
        "styles": list(STYLE_PRESETS.keys()),
        "qualities": list(QUALITY_PRESETS.keys()),
        "levels": ALL_LEVELS,
        "cameras": [{"id": c.get("id"), "brand": c.get("brand"),
                     "model": c.get("model"), "lens": c.get("lens"),
                     "tech": c.get("tech")}
                    for c in load_cameras()],
        "framing": [{"id": f.get("id"), "name": f.get("name"),
                     "tech": f.get("tech"),
                     "default_for_piece_types": f.get("default_for_piece_types", [])}
                    for f in load_framing()],
    }

    for ln in get_location_list():
        loc = load_json("locations", ln)
        zones = []
        for z in loc.get("photo_zones", []):
            pieces = []
            for p in z.get("prompt_pieces", []):
                pieces.append({
                    "id": p.get("id"),
                    "type": p.get("type", ""),
                    "label": f"{p.get('id')} | {p.get('type')}",
                    "levels": p.get("compatible_clothing_levels", ALL_LEVELS),
                    "prompt": p.get("prompt", ""),   # the words used in generation
                })
            zones.append({
                "zone_id": z.get("zone_id") or z.get("name"),
                "name": z.get("name"),
                "pieces": pieces,
            })
        data["locations"].append({
            "name": ln,
            "label": loc.get("name", ln),
            "zones": zones,
        })

    for cn in get_clothing_list():
        cl = load_json("clothing", cn)
        items = []
        for it in cl.get("items", []):
            items.append({
                "item_id": it.get("item_id") or it.get("name"),
                "name": it.get("name", it.get("item_id")),
                "states": [s.get("state_id") for s in it.get("states", [])],
                "state_phrases": {s.get("state_id"): s.get("prompt_phrase", "")
                                  for s in it.get("states", [])},
            })
        data["clothing"].append({
            "name": cn,
            "label": cl.get("name", cn),
            "items": items,
            "removed_states": (cl.get("level_config") or {}).get(
                "removed_states",
                ["removed", "no panties", "no bra", "barefoot", "no top",
                 "no skirt", "no dress", "no shirt"],
            ),
        })

    os.makedirs(web_dir, exist_ok=True)
    out = os.path.join(web_dir, "planner_data.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    print(f"Wrote {out} ({os.path.getsize(out)} bytes)")

    # always ship an example plan built from the CURRENT data (no hardcoded ids)
    sample = build_sample_plan()
    ex = os.path.join(root, "examples", "sample_plan_from_data.yaml")
    if sample:
        with open(ex, "w", encoding="utf-8") as f:
            f.write(sample + "\n")
        print(f"Wrote {ex} (sample plan from your data)")
    else:
        print(f"(no sample plan — need at least one model/location/clothing)")


if __name__ == "__main__":
    main()
