"""
Data-driven clothing level engine (v2).

Replaces the hardcoded level_0..level_4 derivation with a configurable one.
A clothing set JSON may define a `level_config` block:

    "level_config": {
        "removed_states": ["removed", "no panties", "no bra", "barefoot"],
        "thresholds":     [0, 1, 2, 3, 4],          # removed-count -> level index
        "level_names":    ["fully dressed", "partially undressed",
                           "undressed", "mostly nude", "fully nude"]
    }

Defaults reproduce the classic behavior for 4-item sets and are monotonic
(removing more items never moves you to a *lower* level).
"""

DEFAULT_REMOVED_STATES = [
    "removed",
    "no panties",
    "no bra",
    "barefoot",
    "no top",
    "no skirt",
    "no dress",
    "no shirt",
]

DEFAULT_THRESHOLDS = [0, 1, 2, 3, 4]
DEFAULT_LEVEL_NAMES = ["level_0", "level_1", "level_2", "level_3", "level_4"]
MAX_LEVELS = len(DEFAULT_THRESHOLDS)


def get_level_config(clothing):
    """Return (removed_states, thresholds, level_names) for a clothing dict."""
    cfg = clothing.get("level_config") or {}
    removed = cfg.get("removed_states") or DEFAULT_REMOVED_STATES
    thresholds = cfg.get("thresholds") or DEFAULT_THRESHOLDS
    names = cfg.get("level_names") or DEFAULT_LEVEL_NAMES
    if len(thresholds) != MAX_LEVELS:
        thresholds = DEFAULT_THRESHOLDS
    while len(names) < MAX_LEVELS:
        names = names + DEFAULT_LEVEL_NAMES[len(names):]
    return removed, thresholds, names


def removed_count(clothing, removed_states=None):
    """How many items are currently in a 'removed'-family state."""
    if removed_states is None:
        removed_states, _, _ = get_level_config(clothing)
    n = 0
    for item in clothing.get("items", []):
        cur = item.get("current_state", "fully_worn")
        if cur in removed_states:
            n += 1
    return n


def compute_level(clothing):
    """
    Return (level_id, level_name, removed_count) where level_id is
    'level_0' .. 'level_4'.

    If every item is off the body, force level_4 (true nude) even when
    the set only has 2–3 garments (otherwise n=3 → level_3 forever).
    """
    removed_states, thresholds, names = get_level_config(clothing)
    n = removed_count(clothing, removed_states)
    items = clothing.get("items") or []
    total = len(items)
    if total == 0 or (total > 0 and n >= total):
        idx = min(4, MAX_LEVELS - 1)
        return f"level_{idx}", names[idx] if idx < len(names) else "level_4", n
    idx = 0
    for i, thr in enumerate(thresholds):
        if n >= thr:
            idx = i
    idx = min(idx, MAX_LEVELS - 1)
    return f"level_{idx}", names[idx], n


def max_reachable_level(clothing):
    """Highest level achievable given the number of items in the set."""
    total = len(clothing.get("items", []))
    return f"level_{min(total, MAX_LEVELS - 1)}"


def item_state_ids(item):
    """All state ids of a clothing item, in file order."""
    return [s.get("state_id") for s in item.get("states", []) if s.get("state_id")]


def item_current_state(item):
    """Current state id of an item, defaulting to its first state."""
    cur = item.get("current_state")
    if cur:
        return cur
    first = item_state_ids(item)
    return first[0] if first else "fully_worn"


# Partial undress states that reveal anatomy even though the item is still "on".
# Used to pick model phase text so we never say "only silhouette under clothing"
# while breasts are already exposed by a lifted top / pulled cups / etc.
PARTIAL_EXPOSURE_STATES = {
    # tops / bras — chest exposed
    "lifted_underbust": 1,
    "lifted_above": 2,
    "cups_pulled_down": 2,
    "straps_down": 1,
    "open": 1,
    "off_shoulders": 2,
    "unhooked": 1,
    "pulled_aside": 2,       # bra or panties aside
    "untied_hanging": 2,
    # bottoms — intimate area suggested / exposed
    "unbuttoned": 1,
    "around_thighs": 2,
    "around_knees": 2,
    "around_ankles": 2,
    "in_hand": 2,
}


def exposure_level(clothing):
    """Return level_id for model phase selection based on TRUE visual exposure.

    Critical layering rules (MetArt-style):
      - Outer bottoms around knees do NOT expose pussy if briefs/panties still on
      - Top removed does NOT bare breasts if a bra is still worn
      - Phase text must never claim nipples/pussy while those layers are on
    """
    removed_states, _, names = get_level_config(clothing)
    items = clothing.get("items") or []
    if not items:
        # Bare set (no garments) = fully nude phases
        return "level_4"

    off = set(removed_states) | {
        "removed", "in_hand", "barefoot",
        "no panties", "no bra", "no top", "no skirt", "no dress", "no shirt",
    }

    def _cat(item):
        return f"{item.get('category') or ''} {item.get('name') or ''} {item.get('item_id') or ''}".lower()

    def _is_chest_layer(item):
        c = _cat(item)
        return any(k in c for k in (
            "bra", "top", "shirt", "blouse", "sweater", "tank", "crop",
            "bodysuit", "corset", "camisole", "bikini_top", "bikini top",
            "dress", "gown", "robe", "slip", "towel", "outer", "coat",
            "jacket", "wrap", "poncho",
        ))

    def _is_inner_chest(item):
        c = _cat(item)
        return any(k in c for k in ("bra", "bikini_top", "bikini top"))

    def _is_groin_inner(item):
        """Underwear layer that actually covers genitals."""
        c = _cat(item)
        return any(k in c for k in (
            "brief", "panties", "panty", "thong", "g-string", "gstring",
            "bikini_bottom", "bikini bottom", "underwear", "knicker",
        ))

    def _is_groin_outer(item):
        c = _cat(item)
        return any(k in c for k in (
            "short", "skirt", "jean", "trouser", "pant", "legging",
            "bottom", "hose", "culotte",
        )) and not _is_groin_inner(item)

    # Per-area coverage: 0 covered, 1 soft/partial, 2 bare
    chest = 0
    groin = 0

    # Track whether an ON inner layer still covers the area
    bra_on = False
    panties_on = False
    chest_outer_off = True   # true if no outer chest item is still covering
    groin_outer_off = True

    for item in items:
        cur = (item.get("current_state") or "fully_worn").lower()
        is_off = cur in off or cur.startswith("no ")

        if _is_inner_chest(item):
            if not is_off and cur not in (
                "cups_pulled_down", "lifted_above", "open", "unhooked",
                "straps_down", "off_shoulders", "one_cup_pulled",
                "one_side_lifted", "neckline_tugged",
            ):
                bra_on = True
            elif cur in ("cups_pulled_down", "lifted_above", "open", "unhooked", "one_cup_pulled", "one_side_lifted"):
                chest = max(chest, 2)  # nipples can show
            elif not is_off:
                chest = max(chest, 1)

        if _is_groin_inner(item):
            if not is_off and cur not in ("pulled_aside", "around_thighs", "around_knees", "around_ankles"):
                panties_on = True
            elif cur == "pulled_aside":
                groin = max(groin, 2)  # exposed through aside
            elif cur in ("around_thighs", "around_knees", "around_ankles") or is_off:
                pass  # may be bare depending on outer — handled below
            elif not is_off:
                groin = max(groin, 1)

        if _is_chest_layer(item) and not _is_inner_chest(item):
            if is_off:
                pass
            elif cur in ("lifted_above", "off_shoulders", "untied_hanging", "at_waist"):
                # at_waist towel = chest bare
                if cur == "at_waist":
                    chest = max(chest, 2)
                else:
                    chest = max(chest, 1)
            elif cur in ("lifted_underbust", "open", "unbuttoned", "straps_down", "slipping", "held_closed"):
                chest = max(chest, 1)
            else:
                chest_outer_off = False  # still fully covering chest

        if _is_groin_outer(item):
            if is_off or cur in ("around_thighs", "around_knees", "around_ankles", "pulled_aside"):
                pass  # outer not covering — underwear decides
            elif cur in ("unbuttoned", "open"):
                groin = max(groin, 1)
            else:
                groin_outer_off = False

        # Single-piece / wrap covering both chest and groin when worn closed
        c = _cat(item)
        if any(k in c for k in (
            "dress", "gown", "bodysuit", "catsuit", "swimsuit", "one_piece", "slip",
            "towel", "robe", "wrap", "outer",
        )):
            if is_off or cur in ("in_hand",):
                pass
            elif cur in ("at_waist",):
                # towel at waist: chest bare, groin still covered by towel
                chest = max(chest, 2)
                groin_outer_off = False
            elif cur in ("slipping", "open", "held_closed", "lifted_above", "pulled_up"):
                chest = max(chest, 1)
                groin = max(groin, 1)
            elif cur in ("fully_worn", "worn", "closed") or not is_off:
                # fully wrapped towel / robe covers everything
                chest_outer_off = False
                groin_outer_off = False

    # Final layering lock: inner garments still on block bare claims
    if bra_on:
        chest = 0  # soft silhouette only — never "nipples fully exposed"
    elif chest_outer_off and not bra_on:
        # no bra, outer off → breasts bare
        chest = max(chest, 2)

    if panties_on:
        groin = 0  # briefs still on — never "pussy fully visible"
    elif groin_outer_off and not panties_on:
        groin = max(groin, 2)

    # Count fully removed items for nude tail
    removed = sum(
        1 for it in items
        if (it.get("current_state") or "").lower() in off
        or str(it.get("current_state") or "").startswith("no ")
    )
    n = len(items)

    # Map to level_0..4 → phase_1..5
    # level_0 phase_1: silhouette only
    # level_1 phase_2: soft curves under/through clothes
    # level_2 phase_3: breasts bare OR strong body detail, genitals NOT claimed
    # level_3 phase_4: breasts + genitals visible
    # level_4 phase_5: fully nude (everything off)
    if n > 0 and removed >= n:
        score = 4
    elif chest >= 2 and groin >= 2:
        score = 3
    elif chest >= 2:
        score = 2  # bare breasts, still covered below
    elif groin >= 2:
        score = 2  # bottomless but top still on — use phase_3 body detail, not full nude
    elif chest >= 1 or groin >= 1 or removed >= 1:
        score = 1
    else:
        score = 0

    return f"level_{max(0, min(4, score))}"


