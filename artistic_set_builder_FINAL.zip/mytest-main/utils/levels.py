"""
Data-driven clothing level engine (v2).

Replaces the hardcoded level_0..level_4 derivation with a configurable one.
A clothing set JSON may define a `level_config` block:

    "level_config": {
        "removed_states": ["removed", "no panties", "no bra", "barefoot"],
        "thresholds":     [0, 1, 2, 3, 4],          # removed-count -> level index
        "level_names":    ["fully dressed", "partially undressed",
                           "undressed", "mostly nude", "fully nude"]
    }

Defaults reproduce the classic behavior for 4-item sets and are monotonic
(removing more items never moves you to a *lower* level).
"""

DEFAULT_REMOVED_STATES = [
    "removed",
    "no panties",
    "no bra",
    "barefoot",
    "no top",
    "no skirt",
    "no dress",
    "no shirt",
]

DEFAULT_THRESHOLDS = [0, 1, 2, 3, 4]
DEFAULT_LEVEL_NAMES = ["level_0", "level_1", "level_2", "level_3", "level_4"]
MAX_LEVELS = len(DEFAULT_THRESHOLDS)


def get_level_config(clothing):
    """Return (removed_states, thresholds, level_names) for a clothing dict."""
    cfg = clothing.get("level_config") or {}
    removed = cfg.get("removed_states") or DEFAULT_REMOVED_STATES
    thresholds = cfg.get("thresholds") or DEFAULT_THRESHOLDS
    names = cfg.get("level_names") or DEFAULT_LEVEL_NAMES
    if len(thresholds) != MAX_LEVELS:
        thresholds = DEFAULT_THRESHOLDS
    while len(names) < MAX_LEVELS:
        names = names + DEFAULT_LEVEL_NAMES[len(names):]
    return removed, thresholds, names


def removed_count(clothing, removed_states=None):
    """How many items are currently in a 'removed'-family state."""
    if removed_states is None:
        removed_states, _, _ = get_level_config(clothing)
    n = 0
    for item in clothing.get("items", []):
        cur = item.get("current_state", "fully_worn")
        if cur in removed_states:
            n += 1
    return n


def compute_level(clothing):
    """
    Return (level_id, level_name, removed_count) where level_id is
    'level_0' .. 'level_4'.
    """
    removed_states, thresholds, names = get_level_config(clothing)
    n = removed_count(clothing, removed_states)
    idx = 0
    for i, t in enumerate(thresholds):
        if n >= t:
            idx = i
    idx = min(idx, MAX_LEVELS - 1)
    return f"level_{idx}", names[idx], n


def max_reachable_level(clothing):
    """Highest level achievable given the number of items in the set."""
    total = len(clothing.get("items", []))
    return f"level_{min(total, MAX_LEVELS - 1)}"


def item_state_ids(item):
    """All state ids of a clothing item, in file order."""
    return [s.get("state_id") for s in item.get("states", []) if s.get("state_id")]


def item_current_state(item):
    """Current state id of an item, defaulting to its first state."""
    cur = item.get("current_state")
    if cur:
        return cur
    first = item_state_ids(item)
    return first[0] if first else "fully_worn"


# Partial undress states that reveal anatomy even though the item is still "on".
# Used to pick model phase text so we never say "only silhouette under clothing"
# while breasts are already exposed by a lifted top / pulled cups / etc.
PARTIAL_EXPOSURE_STATES = {
    # tops / bras — chest exposed
    "lifted_underbust": 1,
    "lifted_above": 2,
    "cups_pulled_down": 2,
    "straps_down": 1,
    "open": 1,
    "off_shoulders": 2,
    "unhooked": 1,
    "pulled_aside": 2,       # bra or panties aside
    "untied_hanging": 2,
    # bottoms — intimate area suggested / exposed
    "unbuttoned": 1,
    "around_thighs": 2,
    "around_knees": 2,
    "around_ankles": 2,
    "in_hand": 2,
}


def exposure_level(clothing):
    """Return level_id for model phase selection based on visual exposure.

    Clothing phrases still use exact current_state. This only picks phase_1..5
    so a lifted top never gets "silhouette only under clothing" text.
    """
    removed_states, _, names = get_level_config(clothing)
    items = clothing.get("items") or []
    if not items:
        return "level_0"

    removed = 0
    chest = 0   # 0 covered, 1 partial, 2 exposed
    groin = 0
    for item in items:
        cur = (item.get("current_state") or "fully_worn").lower()
        cat = (item.get("category") or item.get("name") or "").lower()
        if cur in removed_states or cur == "removed":
            removed += 1
            # guess body area from name/category
            if any(k in cat for k in ("bra", "top", "shirt", "dress", "blouse", "sweater", "tank", "crop", "bodysuit", "corset", "robe")):
                chest = max(chest, 2)
            elif any(k in cat for k in ("pant", "brief", "thong", "short", "skirt", "jean", "trouser", "bottom", "bikini_bottom")):
                groin = max(groin, 2)
            else:
                chest = max(chest, 1)
                groin = max(groin, 1)
            continue

        # partial states by id
        if cur in ("lifted_above", "cups_pulled_down", "off_shoulders", "untied_hanging"):
            chest = max(chest, 2)
        elif cur in ("lifted_underbust", "straps_down", "open", "unhooked"):
            chest = max(chest, 1)
        elif cur in ("pulled_aside", "around_thighs", "around_knees", "around_ankles", "in_hand"):
            # panties/shorts partial
            if any(k in cat for k in ("bra", "top", "bikini_top")):
                chest = max(chest, 2)
            else:
                groin = max(groin, 2)
        elif cur in ("unbuttoned",):
            groin = max(groin, 1)

    n = len(items)
    # Map to level_0..4 for phase_1..5
    if removed >= n and n > 0:
        score = 4
    elif chest >= 2 and groin >= 2:
        score = 3
    elif removed >= 2 or (chest >= 2 and removed >= 1) or (groin >= 2 and removed >= 1):
        score = 3 if (chest >= 2 or groin >= 2) else 2
    elif chest >= 2 or groin >= 2:
        score = 2  # phase_3: exposed breasts or groin detail
    elif chest >= 1 or groin >= 1 or removed == 1:
        score = 1  # phase_2: suggested curves
    else:
        score = 0

    score = max(0, min(4, score))
    return f"level_{score}"

