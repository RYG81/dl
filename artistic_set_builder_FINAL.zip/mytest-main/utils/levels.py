"""
Data-driven clothing level engine (v2).

Replaces the hardcoded level_0..level_4 derivation with a configurable one.
A clothing set JSON may define a `level_config` block:

    "level_config": {
        "removed_states": ["removed", "no panties", "no bra", "barefoot"],
        "thresholds":     [0, 1, 2, 3, 4],          # removed-count -> level index
        "level_names":    ["fully dressed", "partially undressed",
                           "undressed", "mostly nude", "fully nude"]
    }

Defaults reproduce the classic behavior for 4-item sets and are monotonic
(removing more items never moves you to a *lower* level).
"""

DEFAULT_REMOVED_STATES = [
    "removed",
    "no panties",
    "no bra",
    "barefoot",
    "no top",
    "no skirt",
    "no dress",
    "no shirt",
]

DEFAULT_THRESHOLDS = [0, 1, 2, 3, 4]
DEFAULT_LEVEL_NAMES = ["level_0", "level_1", "level_2", "level_3", "level_4"]
MAX_LEVELS = len(DEFAULT_THRESHOLDS)


def get_level_config(clothing):
    """Return (removed_states, thresholds, level_names) for a clothing dict."""
    cfg = clothing.get("level_config") or {}
    removed = cfg.get("removed_states") or DEFAULT_REMOVED_STATES
    thresholds = cfg.get("thresholds") or DEFAULT_THRESHOLDS
    names = cfg.get("level_names") or DEFAULT_LEVEL_NAMES
    if len(thresholds) != MAX_LEVELS:
        thresholds = DEFAULT_THRESHOLDS
    while len(names) < MAX_LEVELS:
        names = names + DEFAULT_LEVEL_NAMES[len(names):]
    return removed, thresholds, names


def removed_count(clothing, removed_states=None):
    """How many items are currently in a 'removed'-family state."""
    if removed_states is None:
        removed_states, _, _ = get_level_config(clothing)
    n = 0
    for item in clothing.get("items", []):
        cur = item.get("current_state", "fully_worn")
        if cur in removed_states:
            n += 1
    return n


def compute_level(clothing):
    """
    Return (level_id, level_name, removed_count) where level_id is
    'level_0' .. 'level_4'.
    """
    removed_states, thresholds, names = get_level_config(clothing)
    n = removed_count(clothing, removed_states)
    idx = 0
    for i, t in enumerate(thresholds):
        if n >= t:
            idx = i
    idx = min(idx, MAX_LEVELS - 1)
    return f"level_{idx}", names[idx], n


def max_reachable_level(clothing):
    """Highest level achievable given the number of items in the set."""
    total = len(clothing.get("items", []))
    return f"level_{min(total, MAX_LEVELS - 1)}"


def item_state_ids(item):
    """All state ids of a clothing item, in file order."""
    return [s.get("state_id") for s in item.get("states", []) if s.get("state_id")]


def item_current_state(item):
    """Current state id of an item, defaulting to its first state."""
    cur = item.get("current_state")
    if cur:
        return cur
    first = item_state_ids(item)
    return first[0] if first else "fully_worn"
