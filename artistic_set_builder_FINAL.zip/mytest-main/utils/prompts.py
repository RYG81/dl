"""
Pure prompt-assembly helpers (no node classes, no relative imports).

Shared by the node pack (inside ComfyUI) and the offline scripts. Everything
here is a plain function on plain data so it can be imported from anywhere.
"""

DEFAULT_QUALITY = (
    "photorealistic, professional erotic photography, beautiful natural skin "
    "texture, elegant composition, sharp focus, 8k"
)

# named quality presets — used by ASB Set Plan's dropdown; each expands to a
# full quality string. Users can still override with quality_custom.
QUALITY_PRESETS = {
    "default": DEFAULT_QUALITY,
    "editorial": (
        "editorial photography, natural skin texture, candid and effortless, "
        "sharp focus, medium format look"
    ),
    "studio": (
        "studio photography, softbox lighting, clean background, high detail, "
        "sharp focus"
    ),
    "film": (
        "35mm film photography, natural grain, soft muted tones, cinematic"
    ),
    "black & white": (
        "black and white fine art photography, high contrast, timeless film grain"
    ),
    "ultra detail": (
        "hyper detailed, ultra realistic, 8k, sharp focus, professional retouching"
    ),
    "clean minimal": (
        "clean minimal composition, natural light, soft focus, airy"
    ),
    "metart": (
        "fine art erotic photography, soft directional window light sculpting the body, "
        "medium format tonal response, visible skin pores and natural texture, "
        "subsurface scattering on thin skin, elegant composition, shallow depth of field, "
        "85mm portrait perspective, intimate but refined, sharp eyes soft background"
    ),
    "sensual editorial": (
        "sensual editorial photography, warm natural light, soft shadows along curves, "
        "Kodak Portra-like skin tones, visible pores, gentle film grain, "
        "magazine-quality composition, 85mm f/1.8 look"
    ),
}


def resolve_quality(quality=None, quality_custom=""):
    """Resolve a quality dropdown choice (or raw string) + custom override."""
    if quality_custom and quality_custom.strip():
        return quality_custom.strip()
    if quality and quality in QUALITY_PRESETS:
        return QUALITY_PRESETS[quality]
    if quality and quality.strip():
        return quality.strip()
    return DEFAULT_QUALITY


STYLE_PRESETS = {
    "custom": {
        "positive": "",
        "negative": "",
    },
    "natural editorial": {
        "positive": "natural editorial photography, candid and effortless, airy muted tones, soft window light",
        "negative": "harsh flash, oversaturated colors, heavy retouching",
    },
    "studio glam": {
        "positive": "studio glamour photography, dramatic softbox lighting, glowing skin, elegant high fashion styling",
        "negative": "natural daylight, harsh shadows, casual setting",
    },
    "black and white": {
        "positive": "black and white fine-art photography, high contrast, timeless film grain",
        "negative": "color, oversaturated, vivid hues",
    },
    "soft boudoir": {
        "positive": "intimate boudoir photography, moody warm tones, low-key lighting, silk and lace textures",
        "negative": "harsh lighting, clinical setting, office or kitchen background",
    },
    "golden hour outdoor": {
        "positive": "golden hour outdoor photography, warm sunlight flare, sun-kissed skin, shallow depth of field",
        "negative": "indoor setting, artificial lighting, gray overcast sky",
    },
    "night neon": {
        "positive": "night photography, neon city lights bokeh, cinematic teal and magenta grade, moody atmosphere",
        "negative": "daylight, natural window light, bright clean background",
    },
    "metart natural": {
        "positive": "fine art erotic photography, natural unretouched skin, soft directional window light, candid confident presence, medium format clarity, body as elegant line, intimate refined composition, real pores and skin texture",
        "negative": "ugly pose, stiff mannequin posture, exaggerated grimace, heavy makeup, plastic airbrushed skin, oversaturated, harsh on-camera flash, fish-eye, text, watermark, extra limbs, deformed hands",
    },
    "sensual soft": {
        "positive": "sensual softcore editorial, warm window light, soft shadow on curves, relaxed confident gaze, natural skin sheen, intimate bedroom mood, refined erotic composition",
        "negative": "stiff pose, blank expression, plastic skin, harsh flash, cluttered background, text, watermark, extra limbs",
    }
}

# level -> negative additions that stop the model from hallucinating
# leftover/extra clothing at higher undress levels.
LEVEL_NEGATIVES = {
    "level_0": "",
    "level_1": "",
    "level_2": "extra outer garment, stray fabric not part of current outfit",
    "level_3": "extra clothing, stray fabric, fully covering underwear when exposed",
    "level_4": "any clothing, underwear, bra, panties, stray fabric",
}


# phase_1..phase_5 <-> level_0..level_4 (the undress levels)
LEVEL_TO_PHASE = {"level_0": "phase_1", "level_1": "phase_2", "level_2": "phase_3",
                  "level_3": "phase_4", "level_4": "phase_5"}


def phase_key_for_level(level):
    return LEVEL_TO_PHASE.get(level or "level_0", "phase_1")



def _piercing_tattoo_lines(data, include_piercings=False, include_tattoos=False, tattoo_style=""):
    """Optional accessory lines controlled by the Load Model node — never hard-required."""
    bits = []
    if include_piercings:
        pier = data.get("piercings") or {}
        line = (pier.get("prompt") or "").strip()
        if line:
            bits.append(line)
    if include_tattoos:
        tat = data.get("tattoos") or {}
        opts = tat.get("options") or {}
        if tattoo_style and tattoo_style in opts and opts[tattoo_style]:
            bits.append(opts[tattoo_style])
        else:
            line = (tat.get("prompt") or "").strip()
            if line:
                bits.append(line)
    return ", ".join(bits)


def build_model_prompt(data, detail_level="standard", level=None, include_piercings=False, include_tattoos=False, tattoo_style=""):
    """
    Turn a model JSON dict into a prompt string + identity token.

    detail_level:
      standard - face, hair, body type, vibe (classic behavior)
      detailed - additionally includes skin, makeup and the body-detail blocks
      minimal  - name, age, vibe only (safe for SFW output)

    level (optional): if the model defines `prompt_model_description` with
    phase-wise text (phase_1..phase_5), the description for the matching
    phase is used instead of the static assembly — so the model's own wording
    can evolve as the shoot progresses (phase_1 = fully dressed, phase_5 =
    fully undressed). Empty phase text falls back to the static build.
    """
    phase_desc = data.get("prompt_model_description") or {}
    if level and isinstance(phase_desc, dict):
        key = phase_key_for_level(level)
        ph = (phase_desc.get(key) or "").strip()
        if ph:
            # keep identity token; do not double-prefix name if phase text already starts with it
            name = (data.get("name") or "").strip()
            token = data.get("identity_token") or name
            if name and not ph.lower().startswith(name.lower()):
                ph = f"{name}, {ph}"
            extra = _piercing_tattoo_lines(data, include_piercings, include_tattoos, tattoo_style)
            if extra:
                ph = f"{ph} {extra}".strip()
            return ph, token

    # ---- static assembly (unchanged behavior when no phase text) ----
    parts = []
    if data.get("name"):
        parts.append(str(data["name"]))
    if data.get("age"):
        parts.append(str(data["age"]))
    if data.get("body_type"):
        parts.append(data["body_type"])

    hair = data.get("hair", {})
    if isinstance(hair, dict):
        h = " ".join(filter(None, [hair.get("length"), hair.get("style"),
                                   hair.get("color"), "hair"]))
        if h.strip():
            parts.append(h.strip())

    face = data.get("face", {})
    if isinstance(face, dict):
        fparts = []
        if face.get("smile"):
            fparts.append(f"{face['smile']} smile")
        if face.get("eyes"):
            fparts.append(f"{face['eyes']} eyes")
        if face.get("freckles") and face["freckles"] not in ("none", ""):
            fparts.append(face["freckles"])
        if detail_level != "minimal" and face.get("makeup"):
            fparts.append(f"{face['makeup']} makeup")
        if fparts:
            parts.append(", ".join(fparts))

    if detail_level == "detailed":
        extra = []
        skin = data.get("skin", {})
        if isinstance(skin, dict):
            s = " ".join(filter(None, [skin.get("tone"), skin.get("texture")]))
            if s.strip():
                extra.append(f"{s} skin")
        for key in ("breasts", "pussy", "ass"):
            block = data.get(key, {})
            if isinstance(block, dict):
                for field in ("size", "shape", "type", "hair", "nipples",
                              "labia", "asshole"):
                    v = block.get(field)
                    if v and v not in ("none", ""):
                        extra.append(str(v))
        if extra:
            parts.append(", ".join(extra))

    if data.get("overall_vibe"):
        parts.append(data["overall_vibe"])

    extra = _piercing_tattoo_lines(data, include_piercings, include_tattoos, tattoo_style)
    if extra:
        parts.append(extra)

    identity_token = data.get("identity_token") or str(data.get("name") or "")
    return ", ".join(parts), identity_token


def assemble_prompt(model_prompt, clothing_phrases, prompt_piece, lighting,
                    style, quality, level="level_0", camera_technical="",
                    negative_hints="", auto_negative=True):
    """Combine all prompt parts -> (final_prompt, negative_prompt)."""
    style_meta = STYLE_PRESETS.get(style, STYLE_PRESETS["custom"])
    style_pos = style_meta["positive"]
    style_neg = style_meta["negative"]

    parts = [p.strip() for p in (
        model_prompt, clothing_phrases, prompt_piece, lighting,
        style_pos, quality, camera_technical
    ) if p and p.strip()]

    neg_parts = []
    if auto_negative and level in LEVEL_NEGATIVES:
        neg_parts.append(LEVEL_NEGATIVES[level])
    if style_neg:
        neg_parts.append(style_neg)
    if negative_hints and negative_hints.strip():
        neg_parts.append(negative_hints.strip())
    negative = ", ".join(dict.fromkeys(p for p in neg_parts if p))

    return ", ".join(parts), negative
