"""
Plan engine for set generation (v3).

A "plan" is a deterministic, frozen list of image definitions. Each entry
contains everything needed to render one image: the final prompt, the
negative prompt, a stable per-image seed, filename hint, tags and the
full metadata trail (model, location, set, zone, piece, level, style...).

Because the plan is built once and *frozen*, a whole set stays consistent:
switching a widget afterwards does not silently change already-planned
images — you regenerate the plan deliberately.

Modes:
  level      - one canonical clothing combo per (piece x compatible level)
  exhaustive - every item-state combination per piece (capped)
  random     - seeded random sample of `count` combos
"""
import copy
import csv
import io
import itertools
import random
import re

try:
    # imported as part of the package (inside ComfyUI)
    from ..utils import manifest as mf
    from ..utils.database import load_json
    from ..utils.levels import compute_level, item_state_ids, max_reachable_level
    from ..utils.prompts import (
        DEFAULT_QUALITY, QUALITY_PRESETS, assemble_prompt,
        build_model_prompt, resolve_quality,
    )
except ImportError:
    # imported top-level from scripts/
    from utils import manifest as mf
    from utils.database import load_json
    from utils.levels import compute_level, item_state_ids, max_reachable_level
    from utils.prompts import (
        DEFAULT_QUALITY, QUALITY_PRESETS, assemble_prompt,
        build_model_prompt, resolve_quality,
    )

LEVELS = ["level_0", "level_1", "level_2", "level_3", "level_4"]
ALL_LEVELS = list(LEVELS)

# stride used to derive a distinct seed for every image in a set
SEED_STRIDE = 7919
# hard safety cap for any single plan
MAX_PLAN = 500000

PLAN_FIELDS = [
    "index", "seed", "level", "zone", "piece", "filename_hint", "tags",
    "final_prompt", "negative_prompt",
]


def image_seed(base_seed, index):
    """Deterministic per-image seed derived from the set's base seed."""
    return (int(base_seed) + int(index) * SEED_STRIDE) & 0x7FFFFFFF


def clothing_phrases(clothing):
    """Join prompt phrases for items currently *visible* on the body.

    OMIT from positive:
      - removed / in_hand / barefoot / no-* states
      - empty / held-in-hand phrases
      - underwear fully covered by an outer layer still on
        (bra under fully worn top; briefs under fully worn shorts/skirt).
    """
    skip_states = {
        "removed", "in_hand", "barefoot",
        "no panties", "no bra", "no top", "no skirt",
        "no dress", "no shirt", "no towel", "no robe", "no socks",
    }
    items = clothing.get("items") or []

    def _cat(it):
        return f"{it.get('category') or ''} {it.get('name') or ''} {it.get('item_id') or ''}".lower()

    def _is_off(it):
        cur = (it.get("current_state") or "fully_worn").lower()
        return cur in skip_states or cur.startswith("no ")

    def _is_bra(it):
        c = _cat(it)
        return any(k in c for k in ("bra", "lingerie_top", "bikini_top", "bikini top"))

    def _is_briefs(it):
        c = _cat(it)
        return any(k in c for k in (
            "brief", "panties", "panty", "thong", "lingerie_bottom",
            "bikini_bottom", "bikini bottom", "underwear", "knicker",
        ))

    def _is_outer_chest(it):
        if _is_bra(it):
            return False
        c = _cat(it)
        return any(k in c for k in (
            "top", "shirt", "blouse", "sweater", "tank", "crop", "dress",
            "gown", "bodysuit", "corset", "robe", "slip", "jumpsuit", "catsuit",
            "swimsuit", "one_piece",
        ))

    def _is_outer_bottom(it):
        if _is_briefs(it):
            return False
        c = _cat(it)
        return any(k in c for k in (
            "short", "skirt", "jean", "trouser", "pant", "legging", "bottom",
            "hose", "culotte", "dress", "gown", "jumpsuit", "bodysuit", "swimsuit",
        ))

    # Partials that open the CHEST only (dress/top still covers hips)
    chest_partials = {
        "lifted_underbust", "lifted_above", "off_shoulders", "off_one_shoulder",
        "open", "unbuttoned", "unhooked", "straps_down", "straps_stretched",
        "one_strap_off", "cups_pulled_down", "one_cup_pulled", "one_side_lifted",
        "neckline_tugged", "held_at_chest", "untied_hanging",
    }
    # Partials that open the GROIN (hem up, bottoms down…)
    groin_partials = {
        "fly_open", "waistband_tugged", "hip_side_pulled", "sliding_down",
        "pulled_aside", "around_thighs", "around_knees", "around_ankles",
        "hem_lifted_thigh", "hem_lifted_hips", "pulled_to_waist", "around_hips",
    }
    chest_covered_by_outer = False
    groin_covered_by_outer = False
    for it in items:
        if _is_off(it):
            continue
        cur = (it.get("current_state") or "fully_worn").lower()
        chest_open = cur in chest_partials
        groin_open = cur in groin_partials
        if _is_outer_chest(it) and not chest_open:
            chest_covered_by_outer = True
        if _is_outer_bottom(it) and not groin_open:
            groin_covered_by_outer = True
        c = _cat(it)
        # Dress / one-piece: shoulder slip does NOT reveal panties
        if any(k in c for k in ("dress", "gown", "jumpsuit", "bodysuit", "swimsuit", "catsuit")):
            if not chest_open:
                chest_covered_by_outer = True
            if not groin_open:
                groin_covered_by_outer = True

    phrases = []
    for it in items:
        cur = it.get("current_state") or "fully_worn"
        if cur in skip_states or (isinstance(cur, str) and cur.startswith("no ")):
            continue
        if _is_bra(it) and chest_covered_by_outer and cur in ("fully_worn", "worn_normally", "closed"):
            continue
        if _is_briefs(it) and groin_covered_by_outer and cur in ("fully_worn", "worn_normally", "closed"):
            continue
        for st in it.get("states", []):
            if st.get("state_id") == cur:
                ph = (st.get("prompt_phrase") or "").strip()
                low = ph.lower()
                if (not ph or low.startswith("no ") or low == "barefoot"
                        or "not visible on the body" in low
                        or "completely removed" in low
                        or "no longer on the body" in low
                        or "held in one hand" in low
                        or "held in hand" in low):
                    break
                if ph:
                    phrases.append(ph)
                break
    return ", ".join(phrases)



def clothing_off_negatives(clothing):
    """Negative tokens for garments that are off the body (anti ghost-clothing)."""
    off_states = {
        "removed", "in_hand", "barefoot",
        "no panties", "no bra", "no top", "no skirt",
        "no dress", "no shirt", "no towel", "no robe", "no socks",
    }
    toks = []
    any_off = False
    for it in clothing.get("items", []):
        cur = (it.get("current_state") or "fully_worn").lower()
        is_off = cur in off_states or cur.startswith("no ")
        if not is_off:
            # empty prompt_phrase for current state counts as off
            ph = ""
            for st in it.get("states", []):
                if st.get("state_id") == cur:
                    ph = (st.get("prompt_phrase") or "").strip()
                    break
            if ph:
                continue
            is_off = True
        if not is_off:
            continue
        any_off = True
        name = (it.get("name") or it.get("item_id") or "").strip()
        cat = (it.get("category") or "").lower()
        base = (it.get("base_description") or "").strip()
        if name:
            toks.append(f"wearing {name}")
            toks.append(name)
        # category bans
        if any(k in cat for k in ("top", "shirt", "blouse", "crop", "tank")):
            toks.extend(["wearing top", "shirt on", "crop top"])
        if any(k in cat for k in ("bra", "lingerie_top")):
            toks.extend(["wearing bra", "bra on"])
        if any(k in cat for k in ("short", "skirt", "pant", "bottom", "jean")):
            toks.extend(["wearing shorts", "wearing skirt", "bottoms on"])
        if any(k in cat for k in ("brief", "panties", "lingerie_bottom", "thong")):
            toks.extend(["wearing panties", "panties on", "underwear on"])
        if any(k in cat for k in ("dress", "gown")):
            toks.extend(["wearing dress", "dress on"])
        if any(k in cat for k in ("towel", "robe", "outer")):
            toks.extend(["wearing towel", "wrapped in towel", "robe on"])
        # a few distinctive words from base_description
        if base:
            for w in base.lower().replace(",", " ").split():
                if len(w) > 4 and w.isalpha() and w not in {
                    "with", "and", "from", "soft", "tight", "fitted", "ending", "still"
                }:
                    toks.append(w)
                    if len([x for x in toks if x == w]) > 0 and len(toks) > 40:
                        break
    # de-dupe
    seen = set()
    out = []
    for tkn in toks:
        k = tkn.lower()
        if k not in seen:
            seen.add(k)
            out.append(tkn)
    if any_off and not out:
        out = ["clothing", "dressed", "garment"]
    return ", ".join(out[:48])



def piece_allowed_for_level(piece, level_id):
    """Return True if piece is suitable for this undress level.

    Uses min_level / max_level / compatible_clothing_levels when present.
    Intimate poses only at high undress; intro poses only while still clothed.
    """
    try:
        have_n = int(str(level_id).split("_")[-1])
    except Exception:
        return True

    compat = piece.get("compatible_clothing_levels")
    if isinstance(compat, list) and compat:
        return level_id in compat or any(
            str(level_id) == str(c) for c in compat
        )

    need = piece.get("min_level") or piece.get("minLevel")
    mx = piece.get("max_level") or piece.get("maxLevel")
    ok = True
    if need:
        try:
            ok = ok and have_n >= int(str(need).split("_")[-1])
        except Exception:
            pass
    if mx:
        try:
            ok = ok and have_n <= int(str(mx).split("_")[-1])
        except Exception:
            pass
    return ok


def filter_pieces_for_level(pieces, level_id):
    return [p for p in pieces if piece_allowed_for_level(p, level_id)]

def canonical_clothing(clothing, level_idx, rng=None):
    """Deterministic combo for a level: remove exactly `level_idx` items."""
    c = copy.deepcopy(clothing)
    items = c.get("items", [])
    if rng is not None:
        rng.shuffle(items)  # vary *which* items get removed, per seed
    ordered = sorted(items, key=lambda it: len(item_state_ids(it)))
    for i, item in enumerate(ordered):
        ids = item_state_ids(item)
        item["current_state"] = ids[-1] if i < level_idx else ids[0]
    return c


def all_item_combos(clothing, level_id, cap):
    """Every state combination that lands exactly on `level_id`."""
    items = clothing.get("items", [])
    results = []
    for combo in itertools.product(*(item_state_ids(it) for it in items)):
        c = copy.deepcopy(clothing)
        for it, st in zip(c.get("items", []), combo):
            it["current_state"] = st
        if compute_level(c)[0] == level_id:
            results.append(c)
            if len(results) >= cap:
                break
    return results



def load_expressions():
    """Load expression/gaze lines keyed by level. Safe empty if missing."""
    try:
        from .database import load_json
        data = load_json("expressions", "expressions")
        if data and isinstance(data.get("by_level"), dict):
            return data["by_level"]
    except Exception:
        pass
    # try direct path
    try:
        import json, os
        p = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "expressions", "expressions.json")
        with open(p, encoding="utf-8") as f:
            return json.load(f).get("by_level", {})
    except Exception:
        return {}


_EXPRESSIONS = None

def expression_for_level(level, rng=None):
    global _EXPRESSIONS
    if _EXPRESSIONS is None:
        _EXPRESSIONS = load_expressions()
    lines = _EXPRESSIONS.get(level) or _EXPRESSIONS.get("level_0") or []
    if not lines:
        return ""
    if rng is not None:
        return rng.choice(lines)
    return lines[0]



def pick_camera_tech(rng=None, prefer="portrait", piece_prompt=""):
    """Short camera line. Avoid angles that fight the pose framing."""
    low = (piece_prompt or "").lower()
    # Never inject extreme angles unless the piece asks for them
    forbid = []
    if "bird" in low or "overhead" in low or "from above" in low:
        prefer_angle = "elevated"
    elif "low angle" in low or "from below" in low:
        prefer_angle = "low"
    else:
        prefer_angle = "eye"
        forbid = ["bird", "overhead", "worm", "dutch"]

    defaults_eye = [
        "shot on 85mm f/1.8, eye-level, shallow depth of field, soft bokeh",
        "shot on 50mm f/1.4, natural eye-level perspective, sharp eyes",
        "medium format 80mm look, eye-level, creamy background separation",
    ]
    defaults_elevated = [
        "shot on 50mm, slight elevated three-quarter angle, soft falloff",
    ]
    defaults_low = [
        "shot on 35mm, subtle low angle, elongated figure, soft background",
    ]
    pool = defaults_eye if prefer_angle == "eye" else (defaults_elevated if prefer_angle == "elevated" else defaults_low)

    try:
        from .database import load_cameras
        cams = load_cameras()
        if isinstance(cams, dict):
            cams = list(cams.values())
        filtered = []
        for c in cams or []:
            if not isinstance(c, dict):
                continue
            tech = (c.get("tech") or c.get("focal_look") or "").strip()
            tlow = tech.lower()
            if any(f in tlow for f in forbid):
                continue
            if tech:
                filtered.append(tech)
        if filtered:
            pool = filtered
    except Exception:
        pass
    if rng:
        return rng.choice(pool)
    return pool[0]


def pick_framing_tech(piece_prompt="", rng=None):
    """Framing line that reinforces the piece, never contradicts it."""
    low = (piece_prompt or "").lower()
    # Piece already specifies framing/angle — do not add a conflicting one
    if any(k in low for k in ("medium shot", "medium-full", "full-body", "full body",
                               "close-up", "close up", "from above", "from below",
                               "low angle", "eye-level", "eye level", "waist-up", "portrait")):
        return ""
    if any(k in low for k in ("close-up", "close up", "portrait", "face and shoulder")):
        return "close framing, face and upper body, eyes near upper third, shallow depth of field"
    if any(k in low for k in ("full-body", "full body", "head to toe")):
        return "full-body framing, head-to-toe in frame, balanced negative space"
    if "from above" in low or "bird" in low:
        return "elevated three-quarter view, soft downward angle"
    if "low angle" in low:
        return "subtle low angle, figure elongated"
    if "medium-full" in low or "medium full" in low:
        return "medium-full framing, head to mid-thigh, natural eye-level"
    if "medium" in low:
        return "medium framing, waist-up, natural eye-level"
    return "natural eye-level framing, balanced composition"


def _transition_states(clothing_a, clothing_b, n=3):
    """Produce n intermediate clothing dicts between two canonical states.

    Advances one item at a time along undress_order toward clothing_b.
    If items already match, returns [].
    """
    import copy
    a = copy.deepcopy(clothing_a)
    b_states = {}
    for it in clothing_b.get("items", []):
        key = it.get("item_id") or it.get("name")
        b_states[key] = it.get("current_state")

    # find items that differ
    diffs = []
    for it in a.get("items", []):
        key = it.get("item_id") or it.get("name")
        if b_states.get(key) and b_states[key] != it.get("current_state"):
            order = it.get("undress_order") or [s.get("state_id") for s in it.get("states", [])]
            try:
                cur_i = order.index(it.get("current_state"))
            except ValueError:
                cur_i = 0
            try:
                tgt_i = order.index(b_states[key])
            except ValueError:
                tgt_i = len(order) - 1
            diffs.append((it, order, cur_i, tgt_i))

    if not diffs:
        return []

    results = []
    # advance the first differing item step by step
    it, order, cur_i, tgt_i = diffs[0]
    step = 1 if tgt_i > cur_i else -1
    idx = cur_i
    while idx != tgt_i and len(results) < n:
        idx += step
        if idx < 0 or idx >= len(order):
            break
        mid = copy.deepcopy(a)
        for mit in mid.get("items", []):
            if (mit.get("item_id") or mit.get("name")) == (it.get("item_id") or it.get("name")):
                mit["current_state"] = order[idx]
        results.append(mid)
    return results


def _item_undress_order(item):
    """Return ordered state_ids for progressive undress of one item."""
    order = item.get("undress_order")
    if order:
        return list(order)
    return [s.get("state_id") for s in item.get("states", []) if s.get("state_id")]


def _undress_sequence(clothing):
    """Item keys in the order they should come off.

    Prefers clothing.recommended_undress_sequence, else items list order.
    """
    items = clothing.get("items") or []
    by_key = {(it.get("item_id") or it.get("name")): it for it in items}
    seq = clothing.get("recommended_undress_sequence") or []
    ordered = []
    for key in seq:
        if key in by_key:
            ordered.append(by_key[key])
    for it in items:
        if it not in ordered:
            ordered.append(it)
    return ordered


def build_tease_clothing_timeline(clothing, poses_per_state=4, transition_poses=2):
    """Build a list of clothing snapshots for a long tease undress.

    Timeline:
      1. All fully_worn — held for poses_per_state shots (caller adds those)
      2. For each item in undress order:
           for each intermediate state in undress_order[1:]:
             hold that state for transition_poses (early steps) or poses_per_state (later)
      3. Final all-removed

    Returns list of clothing dicts (deep copies with current_state set).
    Does NOT expand to shots — only clothing states to visit.
    """
    import copy
    base = copy.deepcopy(clothing)
    items_ordered = _undress_sequence(base)
    # start: everything first state
    for it in base.get("items", []):
        order = _item_undress_order(it)
        it["current_state"] = order[0] if order else "fully_worn"

    timeline = []
    # fully dressed block marker (caller may repeat)
    timeline.append(copy.deepcopy(base))

    for it in items_ordered:
        order = _item_undress_order(it)
        if len(order) <= 1:
            # only one state — jump to removed if present
            continue
        key = it.get("item_id") or it.get("name")
        # walk states after fully_worn
        for state in order[1:]:
            # advance this item only
            snap = copy.deepcopy(timeline[-1])
            for sit in snap.get("items", []):
                if (sit.get("item_id") or sit.get("name")) == key:
                    sit["current_state"] = state
            timeline.append(snap)

    return timeline


def build_plan(model, location, clothing_set, mode="level", seed=1, count=200,
               min_level=0, max_level=4, cap=2000, detail="standard",
               style="custom", quality="default", quality_custom="",
               filename_prefix="", auto_negative=True, negative_hints="",
               include_piercings=False, include_tattoos=False, tattoo_style=""):
    """
    Build a plan list of entry dicts. Deterministic for the same arguments.
    Returns [] if any data file is missing.
    """
    mdata = load_json("models", model)
    ldata = load_json("locations", location)
    cdata = load_json("clothing", clothing_set)
    if not mdata or not ldata or not cdata or not cdata.get("items"):
        return []

    # Apply accessory flags from ASB Load Model (or explicit kwargs)
    mdata = dict(mdata)
    mdata["_include_piercings"] = bool(include_piercings)
    mdata["_include_tattoos"] = bool(include_tattoos)
    mdata["_tattoo_style"] = tattoo_style or ""

    quality = resolve_quality(quality, quality_custom)

    mprompt, _ = build_model_prompt(
        mdata, detail,
        include_piercings=bool(mdata.get("_include_piercings")),
        include_tattoos=bool(mdata.get("_include_tattoos")),
        tattoo_style=mdata.get("_tattoo_style") or "",
    )
    ident = mdata.get("name") or model
    lighting = ldata.get("lighting", "soft natural light")

    max_idx = int(max_reachable_level(cdata).split("_")[1])
    hi = max(0, min(max_level, max_idx))
    lo = max(0, min(min_level, hi))

    rng = random.Random(seed)
    entries = []
    prefix = mf.safe_filename(filename_prefix or f"{ident}_{mf.safe_filename(location)}")

    def add(zone, piece, clothing, lvl):
        if len(entries) >= MAX_PLAN:
            return
        phrases = clothing_phrases(clothing)
        # Model phase follows visual exposure, not only fully-removed count.
        # Prevents "silhouette under clothing" while a top is already lifted.
        try:
            from .levels import exposure_level
            phase_lvl = exposure_level(clothing)
        except Exception:
            phase_lvl = lvl
        mprompt_shot, _ = build_model_prompt(
            mdata, detail, level=phase_lvl,
            include_piercings=bool(mdata.get("_include_piercings")),
            include_tattoos=bool(mdata.get("_include_tattoos")),
            tattoo_style=mdata.get("_tattoo_style") or "",
        )
        piece_prompt = piece.get("prompt", "")
        expr = expression_for_level(lvl, rng)
        # Avoid stacking if pose already carries gaze/expression language
        has_expr = any(k in piece_prompt.lower() for k in (
            "gaze", "smile", "eyes toward", "looking", "expression", "parted lips", "half-lidded"
        ))
        if expr and not has_expr and expr.lower() not in piece_prompt.lower():
            piece_prompt = f"{piece_prompt}, {expr}"
        cam_tech = piece.get("camera") or pick_camera_tech(rng, piece_prompt=piece_prompt)
        frame_tech = pick_framing_tech(piece_prompt, rng)
        cam_combined = ", ".join(x for x in (cam_tech, frame_tech) if x)
        off_neg = clothing_off_negatives(clothing)
        final, neg = assemble_prompt(
            mprompt_shot, phrases, piece_prompt, lighting,
            style, quality, level=lvl,
            camera_technical=cam_combined,
            auto_negative=auto_negative, negative_hints=negative_hints,
            clothing_off_neg=off_neg,
        )
        zname = zone.get("name", zone.get("zone_id", "zone"))
        plabel = f"{piece.get('id', '?')} | {piece.get('type', '?')}"
        idx = len(entries)
        entries.append({
            "index": idx,
            "seed": image_seed(seed, idx),
            "base_seed": seed,
            "model": model,
            "location": location,
            "clothing_set": clothing_set,
            "model_prompt": mprompt_shot,
            "clothing_phrases": phrases,
            "piece_prompt": piece_prompt,
            "lighting": lighting,
            "camera": piece.get("camera", ""),
            "level": lvl,
            "zone": zname,
            "piece": plabel,
            "style": style,
            "filename_hint": mf.safe_filename(
                f"{prefix}_{mf.safe_filename(zname)}_{mf.safe_filename(piece.get('id', 'p'))}_{lvl}"
            ),
            "tags": (f"model={model};location={location};set={clothing_set};"
                     f"level={lvl};zone={zname};piece={plabel}"),
            "final_prompt": final,
            "negative_prompt": neg,
        })

    if mode == "random":
        for _ in range(count):
            if len(entries) >= MAX_PLAN:
                break
            target_idx = rng.randint(lo, hi)
            lvl = LEVELS[target_idx]
            clothing = canonical_clothing(cdata, target_idx, rng)
            zones = ldata.get("photo_zones", [])
            if not zones:
                break
            zone = rng.choice(zones)
            pieces = [p for p in zone.get("prompt_pieces", [])
                      if piece_allowed_for_level(p, lvl)
                      and lvl in p.get("compatible_clothing_levels", ALL_LEVELS)]
            if not pieces:
                # fallback: any piece allowed for this level
                pieces = [p for p in zone.get("prompt_pieces", [])
                          if piece_allowed_for_level(p, lvl)]
            if not pieces:
                pieces = zone.get("prompt_pieces", [])
            if not pieces:
                break
            piece = rng.choice(pieces)
            add(zone, piece, clothing, lvl)
    elif mode == "transition":
        # Long tease undress: walk every intermediate clothing state, one item at a time.
        # Budget is spread across the full undress_order chain, not just level jumps.
        zones = [z for z in (ldata.get("photo_zones") or []) if z.get("prompt_pieces")]
        if not zones:
            zones = ldata.get("photo_zones") or [{}]

        def pieces_for(zone, lvl):
            pcs = [p for p in zone.get("prompt_pieces", []) if piece_allowed_for_level(p, lvl)]
            if not pcs:
                pcs = [p for p in zone.get("prompt_pieces", [])]
            return pcs

        # Build full clothing state timeline (one step per intermediate state)
        timeline = build_tease_clothing_timeline(cdata)
        if not timeline:
            timeline = [canonical_clothing(cdata, 0)]

        n_states = len(timeline)
        # How many shots per clothing state so we fill `count` across the tease
        # Reserve ~20% of shots for the final nude/stable hold at the end
        nude_tail = max(count // 5, 8)
        tease_budget = max(count - nude_tail, n_states)
        base_per = max(2, tease_budget // max(n_states, 1))
        # First state (fully dressed) and last intermediate get a bit more
        extra_first = max(2, base_per // 2)

        from .levels import compute_level as _cl, exposure_level as _el

        def shots_for_index(i):
            if i == 0:
                return base_per + extra_first
            # terminal removed states still on timeline: fewer if many left
            return base_per

        total_planned = 0
        for i, clothing in enumerate(timeline):
            if len(entries) >= count or len(entries) >= MAX_PLAN:
                break
            n_here = shots_for_index(i)
            # don't overrun tease budget before last states
            remaining_states = n_states - i
            remaining_shots = count - len(entries) - (nude_tail if i < n_states - 1 else 0)
            if remaining_states > 0:
                n_here = min(n_here, max(2, remaining_shots // remaining_states))
            try:
                lvl = _el(clothing)
            except Exception:
                lvl = _cl(clothing)[0]
            # clamp to requested min/max window
            try:
                lvl_i = int(str(lvl).split("_")[-1])
                lvl_i = max(lo, min(hi, lvl_i))
                lvl = LEVELS[lvl_i]
            except Exception:
                pass
            # Zone changes only every few clothing-states (not every shot, not every state)
            # Groups of consecutive states share one zone → MetArt "same place" blocks
            states_per_zone = max(3, n_states // max(len(zones), 1))
            zone = zones[(i // states_per_zone) % len(zones)]
            pcs = pieces_for(zone, lvl)
            if not pcs:
                for ztry in zones:
                    pcs = pieces_for(ztry, lvl)
                    if pcs:
                        zone = ztry
                        break
            for j in range(n_here):
                if len(entries) >= count or len(entries) >= MAX_PLAN:
                    break
                if not pcs:
                    break
                piece = rng.choice(pcs)
                add(zone, piece, clothing, lvl)
                total_planned += 1

        # Tail: nude hold in at most 2 preferred zones (bed/window/sofa first)
        final_clothing = timeline[-1]
        try:
            final_lvl = _el(final_clothing)
        except Exception:
            final_lvl = _cl(final_clothing)[0]

        def _intimate_score(z):
            n = ((z.get("zone_id") or z.get("name") or "") + "").lower()
            s = 0
            if any(k in n for k in ("bed", "sofa", "couch")): s += 5
            if any(k in n for k in ("window", "mirror")): s += 3
            if any(k in n for k in ("floor", "rug")): s += 2
            return s

        nude_zones = sorted(zones, key=_intimate_score, reverse=True)[:max(1, min(2, len(zones)))]
        nude_i = 0
        while len(entries) < count and len(entries) < MAX_PLAN:
            zone = nude_zones[(nude_i // 8) % len(nude_zones)]
            pcs = pieces_for(zone, final_lvl)
            if not pcs:
                pcs = zone.get("prompt_pieces") or []
            if not pcs:
                nude_i += 1
                if nude_i > 50:
                    break
                continue
            add(zone, rng.choice(pcs), final_clothing, final_lvl)
            nude_i += 1

    
    else:
        for zone in ldata.get("photo_zones", []):
            for piece in zone.get("prompt_pieces", []):
                for lvl_idx in range(lo, hi + 1):
                    lvl = LEVELS[lvl_idx]
                    if not piece_allowed_for_level(piece, lvl):
                        continue
                    if lvl not in piece.get("compatible_clothing_levels", ALL_LEVELS):
                        continue
                    if mode == "exhaustive":
                        for clothing in all_item_combos(cdata, lvl, cap):
                            add(zone, piece, clothing, lvl)
                    else:  # level
                        add(zone, piece, canonical_clothing(cdata, lvl_idx), lvl)
    return entries


def plan_to_csv(entries):
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=PLAN_FIELDS, lineterminator="\n")
    writer.writeheader()
    for e in entries:
        writer.writerow({f: e.get(f, "") for f in PLAN_FIELDS})
    return out.getvalue()


def to_manifest_entries(entries):
    """Convert plan entries to manifest (logging) entries."""
    return [
        mf.make_entry(
            index=e["index"],
            seed=e["seed"],
            prompt=e["final_prompt"],
            negative_prompt=e["negative_prompt"],
            filename_hint=e["filename_hint"],
            tags=e["tags"],
        )
        for e in entries
    ]


def renumber(entries, base_seed):
    """Re-index a concatenated list so index/seed are globally unique."""
    for i, e in enumerate(entries):
        e["index"] = i
        e["seed"] = image_seed(base_seed, i)
    return entries
