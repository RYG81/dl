"""
Plan engine for set generation (v3).

A "plan" is a deterministic, frozen list of image definitions. Each entry
contains everything needed to render one image: the final prompt, the
negative prompt, a stable per-image seed, filename hint, tags and the
full metadata trail (model, location, set, zone, piece, level, style...).

Because the plan is built once and *frozen*, a whole set stays consistent:
switching a widget afterwards does not silently change already-planned
images — you regenerate the plan deliberately.

Modes:
  level      - one canonical clothing combo per (piece x compatible level)
  exhaustive - every item-state combination per piece (capped)
  random     - seeded random sample of `count` combos
"""
import copy
import csv
import io
import itertools
import random

try:
    # imported as part of the package (inside ComfyUI)
    from ..utils import manifest as mf
    from ..utils.database import load_json
    from ..utils.levels import compute_level, item_state_ids, max_reachable_level
    from ..utils.prompts import (
        DEFAULT_QUALITY, QUALITY_PRESETS, assemble_prompt,
        build_model_prompt, resolve_quality,
    )
except ImportError:
    # imported top-level from scripts/
    from utils import manifest as mf
    from utils.database import load_json
    from utils.levels import compute_level, item_state_ids, max_reachable_level
    from utils.prompts import (
        DEFAULT_QUALITY, QUALITY_PRESETS, assemble_prompt,
        build_model_prompt, resolve_quality,
    )

LEVELS = ["level_0", "level_1", "level_2", "level_3", "level_4"]
ALL_LEVELS = list(LEVELS)

# stride used to derive a distinct seed for every image in a set
SEED_STRIDE = 7919
# hard safety cap for any single plan
MAX_PLAN = 500000

PLAN_FIELDS = [
    "index", "seed", "level", "zone", "piece", "filename_hint", "tags",
    "final_prompt", "negative_prompt",
]


def image_seed(base_seed, index):
    """Deterministic per-image seed derived from the set's base seed."""
    return (int(base_seed) + int(index) * SEED_STRIDE) & 0x7FFFFFFF


def clothing_phrases(clothing):
    """Join prompt phrases for items currently on the body.

    Items in a terminal removed/barefoot state are OMITTED — saying
    "completely removed" in the positive prompt causes ghost clothing.
    """
    skip_states = {
        "removed", "barefoot", "no panties", "no bra", "no top", "no skirt",
        "no dress", "no shirt", "no towel", "no robe", "no socks",
    }
    phrases = []
    for it in clothing.get("items", []):
        cur = it.get("current_state") or "fully_worn"
        if cur in skip_states or (isinstance(cur, str) and cur.startswith("no ")):
            continue
        for st in it.get("states", []):
            if st.get("state_id") == cur:
                ph = (st.get("prompt_phrase") or "").strip()
                low = ph.lower()
                if (not ph or low.startswith("no ") or low == "barefoot"
                        or "not visible on the body" in low
                        or "completely removed" in low
                        or "no longer on the body" in low):
                    break
                if ph:
                    phrases.append(ph)
                break
    return ", ".join(phrases)



def piece_allowed_for_level(piece, level_id):
    """Return True if piece.min_level is satisfied by current level_id.

    Pieces without min_level are always allowed (clothing-agnostic general poses).
    Intimate pieces tag min_level e.g. "level_3" and only show when undress is high enough.
    This keeps plans dynamic across any outfit — only the level number matters.
    """
    need = piece.get("min_level") or piece.get("minLevel")
    if not need:
        return True
    try:
        need_n = int(str(need).split("_")[-1])
        have_n = int(str(level_id).split("_")[-1])
        return have_n >= need_n
    except Exception:
        return True


def filter_pieces_for_level(pieces, level_id):
    return [p for p in pieces if piece_allowed_for_level(p, level_id)]

def canonical_clothing(clothing, level_idx, rng=None):
    """Deterministic combo for a level: remove exactly `level_idx` items."""
    c = copy.deepcopy(clothing)
    items = c.get("items", [])
    if rng is not None:
        rng.shuffle(items)  # vary *which* items get removed, per seed
    ordered = sorted(items, key=lambda it: len(item_state_ids(it)))
    for i, item in enumerate(ordered):
        ids = item_state_ids(item)
        item["current_state"] = ids[-1] if i < level_idx else ids[0]
    return c


def all_item_combos(clothing, level_id, cap):
    """Every state combination that lands exactly on `level_id`."""
    items = clothing.get("items", [])
    results = []
    for combo in itertools.product(*(item_state_ids(it) for it in items)):
        c = copy.deepcopy(clothing)
        for it, st in zip(c.get("items", []), combo):
            it["current_state"] = st
        if compute_level(c)[0] == level_id:
            results.append(c)
            if len(results) >= cap:
                break
    return results



def load_expressions():
    """Load expression/gaze lines keyed by level. Safe empty if missing."""
    try:
        from .database import load_json
        data = load_json("expressions", "expressions")
        if data and isinstance(data.get("by_level"), dict):
            return data["by_level"]
    except Exception:
        pass
    # try direct path
    try:
        import json, os
        p = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "expressions", "expressions.json")
        with open(p, encoding="utf-8") as f:
            return json.load(f).get("by_level", {})
    except Exception:
        return {}


_EXPRESSIONS = None

def expression_for_level(level, rng=None):
    global _EXPRESSIONS
    if _EXPRESSIONS is None:
        _EXPRESSIONS = load_expressions()
    lines = _EXPRESSIONS.get(level) or _EXPRESSIONS.get("level_0") or []
    if not lines:
        return ""
    if rng is not None:
        return rng.choice(lines)
    return lines[0]


def pick_camera_tech(rng=None, prefer="portrait"):
    """Return a short camera technical line from data/cameras."""
    try:
        from .database import load_cameras
        cams = load_cameras()
    except Exception:
        cams = []
    if not cams:
        # fallback editorial defaults
        defaults = [
            "shot on 85mm f/1.8, shallow depth of field, soft bokeh",
            "shot on 50mm f/1.4, natural perspective, sharp eyes",
            "medium format look, 80mm equivalent, creamy background separation",
        ]
        return (rng.choice(defaults) if rng else defaults[0])
    # cams may be list of dicts or dict
    if isinstance(cams, dict):
        cams = list(cams.values())
    if rng:
        c = rng.choice(cams)
    else:
        c = cams[0]
    if isinstance(c, dict):
        return (c.get("tech") or c.get("focal_look") or "").strip()
    return str(c)


def pick_framing_tech(piece_prompt="", rng=None):
    """Heuristic framing line from piece text + framing DB."""
    low = (piece_prompt or "").lower()
    prefer = "medium"
    if "close" in low or "portrait" in low:
        prefer = "close_up"
    elif "full-body" in low or "full body" in low:
        prefer = "full_body"
    elif "from above" in low or "from slightly above" in low:
        prefer = "elevated"
    elif "low angle" in low:
        prefer = "low_angle"
    try:
        import json, os
        folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "framing")
        # map prefer to file
        candidates = {
            "close_up": "close_up.json",
            "full_body": "full_body.json",
            "elevated": "elevated_three_quarter.json",
            "low_angle": "low_angle.json",
            "medium": "medium_shot.json",
        }
        fn = candidates.get(prefer, "medium_shot.json")
        path = os.path.join(folder, fn)
        if not os.path.exists(path):
            # any framing file
            files = [f for f in os.listdir(folder) if f.endswith(".json") and f != "framing.json"]
            if not files:
                return ""
            path = os.path.join(folder, files[0])
        d = json.load(open(path, encoding="utf-8"))
        return (d.get("tech") or "").strip()
    except Exception:
        return ""



def _transition_states(clothing_a, clothing_b, n=3):
    """Produce n intermediate clothing dicts between two canonical states.

    Advances one item at a time along undress_order toward clothing_b.
    If items already match, returns [].
    """
    import copy
    a = copy.deepcopy(clothing_a)
    b_states = {}
    for it in clothing_b.get("items", []):
        key = it.get("item_id") or it.get("name")
        b_states[key] = it.get("current_state")

    # find items that differ
    diffs = []
    for it in a.get("items", []):
        key = it.get("item_id") or it.get("name")
        if b_states.get(key) and b_states[key] != it.get("current_state"):
            order = it.get("undress_order") or [s.get("state_id") for s in it.get("states", [])]
            try:
                cur_i = order.index(it.get("current_state"))
            except ValueError:
                cur_i = 0
            try:
                tgt_i = order.index(b_states[key])
            except ValueError:
                tgt_i = len(order) - 1
            diffs.append((it, order, cur_i, tgt_i))

    if not diffs:
        return []

    results = []
    # advance the first differing item step by step
    it, order, cur_i, tgt_i = diffs[0]
    step = 1 if tgt_i > cur_i else -1
    idx = cur_i
    while idx != tgt_i and len(results) < n:
        idx += step
        if idx < 0 or idx >= len(order):
            break
        mid = copy.deepcopy(a)
        for mit in mid.get("items", []):
            if (mit.get("item_id") or mit.get("name")) == (it.get("item_id") or it.get("name")):
                mit["current_state"] = order[idx]
        results.append(mid)
    return results

def build_plan(model, location, clothing_set, mode="level", seed=1, count=200,
               min_level=0, max_level=4, cap=2000, detail="standard",
               style="custom", quality="default", quality_custom="",
               filename_prefix="", auto_negative=True, negative_hints=""):
    """
    Build a plan list of entry dicts. Deterministic for the same arguments.
    Returns [] if any data file is missing.
    """
    mdata = load_json("models", model)
    ldata = load_json("locations", location)
    cdata = load_json("clothing", clothing_set)
    if not mdata or not ldata or not cdata or not cdata.get("items"):
        return []

    quality = resolve_quality(quality, quality_custom)

    mprompt, _ = build_model_prompt(
        mdata, detail,
        include_piercings=bool(mdata.get("_include_piercings")),
        include_tattoos=bool(mdata.get("_include_tattoos")),
        tattoo_style=mdata.get("_tattoo_style") or "",
    )
    ident = mdata.get("name") or model
    lighting = ldata.get("lighting", "soft natural light")

    max_idx = int(max_reachable_level(cdata).split("_")[1])
    hi = max(0, min(max_level, max_idx))
    lo = max(0, min(min_level, hi))

    rng = random.Random(seed)
    entries = []
    prefix = mf.safe_filename(filename_prefix or f"{ident}_{mf.safe_filename(location)}")

    def add(zone, piece, clothing, lvl):
        if len(entries) >= MAX_PLAN:
            return
        phrases = clothing_phrases(clothing)
        # phase-wise model description for this shot's level (if the model has one)
        mprompt_shot, _ = build_model_prompt(
            mdata, detail, level=lvl,
            include_piercings=bool(mdata.get("_include_piercings")),
            include_tattoos=bool(mdata.get("_include_tattoos")),
            tattoo_style=mdata.get("_tattoo_style") or "",
        )
        piece_prompt = piece.get("prompt", "")
        expr = expression_for_level(lvl, rng)
        if expr and expr.lower() not in piece_prompt.lower():
            piece_prompt = f"{piece_prompt}, {expr}"
        cam_tech = piece.get("camera") or pick_camera_tech(rng)
        frame_tech = pick_framing_tech(piece_prompt, rng)
        cam_combined = ", ".join(x for x in (cam_tech, frame_tech) if x)
        final, neg = assemble_prompt(
            mprompt_shot, phrases, piece_prompt, lighting,
            style, quality, level=lvl,
            camera_technical=cam_combined,
            auto_negative=auto_negative, negative_hints=negative_hints,
        )
        zname = zone.get("name", zone.get("zone_id", "zone"))
        plabel = f"{piece.get('id', '?')} | {piece.get('type', '?')}"
        idx = len(entries)
        entries.append({
            "index": idx,
            "seed": image_seed(seed, idx),
            "base_seed": seed,
            "model": model,
            "location": location,
            "clothing_set": clothing_set,
            "model_prompt": mprompt_shot,
            "clothing_phrases": phrases,
            "piece_prompt": piece_prompt,
            "lighting": lighting,
            "camera": piece.get("camera", ""),
            "level": lvl,
            "zone": zname,
            "piece": plabel,
            "style": style,
            "filename_hint": mf.safe_filename(
                f"{prefix}_{mf.safe_filename(zname)}_{mf.safe_filename(piece.get('id', 'p'))}_{lvl}"
            ),
            "tags": (f"model={model};location={location};set={clothing_set};"
                     f"level={lvl};zone={zname};piece={plabel}"),
            "final_prompt": final,
            "negative_prompt": neg,
        })

    if mode == "random":
        for _ in range(count):
            if len(entries) >= MAX_PLAN:
                break
            target_idx = rng.randint(lo, hi)
            lvl = LEVELS[target_idx]
            clothing = canonical_clothing(cdata, target_idx, rng)
            zones = ldata.get("photo_zones", [])
            if not zones:
                break
            zone = rng.choice(zones)
            pieces = [p for p in zone.get("prompt_pieces", [])
                      if piece_allowed_for_level(p, lvl)
                      and lvl in p.get("compatible_clothing_levels", ALL_LEVELS)]
            if not pieces:
                # fallback: any piece allowed for this level
                pieces = [p for p in zone.get("prompt_pieces", [])
                          if piece_allowed_for_level(p, lvl)]
            if not pieces:
                pieces = zone.get("prompt_pieces", [])
            if not pieces:
                break
            piece = rng.choice(pieces)
            add(zone, piece, clothing, lvl)
    elif mode == "transition":
        # Stable blocks at each level + short one-item transition beats between levels.
        # Fully dynamic: uses clothing item state chains; any model/outfit works.
        zones = ldata.get("photo_zones", []) or [{}]
        stable_per_level = max(4, count // max(1, (hi - lo + 1) * 2))
        transition_shots = 3  # frames while one garment moves

        def pieces_for(zone, lvl):
            pcs = [p for p in zone.get("prompt_pieces", []) if piece_allowed_for_level(p, lvl)]
            if not pcs:
                pcs = zone.get("prompt_pieces", [])
            return pcs

        for lvl_idx in range(lo, hi + 1):
            if len(entries) >= MAX_PLAN:
                break
            lvl = LEVELS[lvl_idx]
            clothing = canonical_clothing(cdata, lvl_idx)
            # stable block
            for i in range(stable_per_level):
                if len(entries) >= MAX_PLAN or len(entries) >= count:
                    break
                zone = zones[i % len(zones)]
                pcs = pieces_for(zone, lvl)
                if not pcs:
                    continue
                piece = rng.choice(pcs)
                add(zone, piece, clothing, lvl)

            # transition toward next level (one item advances along its undress_order)
            if lvl_idx >= hi or len(entries) >= count:
                continue
            next_clothing = canonical_clothing(cdata, lvl_idx + 1)
            # build intermediate clothing states between current and next
            intermediates = _transition_states(clothing, next_clothing, transition_shots)
            zone = zones[lvl_idx % len(zones)]
            pcs = pieces_for(zone, lvl)
            for mid in intermediates:
                if len(entries) >= MAX_PLAN or len(entries) >= count:
                    break
                piece = rng.choice(pcs) if pcs else {"id": "T", "prompt": "standing, soft gaze toward camera, medium shot, soft light"}
                mid_lvl = compute_level(mid)[0] if False else lvl  # keep label as current during transition
                from .levels import compute_level as _cl
                mid_lvl = _cl(mid)[0]
                add(zone, piece, mid, mid_lvl)

        # if still under count, pad with high-level stable
        while len(entries) < count and len(entries) < MAX_PLAN:
            lvl = LEVELS[hi]
            clothing = canonical_clothing(cdata, hi)
            zone = rng.choice(zones)
            pcs = pieces_for(zone, lvl)
            if not pcs:
                break
            add(zone, rng.choice(pcs), clothing, lvl)
    else:
        for zone in ldata.get("photo_zones", []):
            for piece in zone.get("prompt_pieces", []):
                for lvl_idx in range(lo, hi + 1):
                    lvl = LEVELS[lvl_idx]
                    if not piece_allowed_for_level(piece, lvl):
                        continue
                    if lvl not in piece.get("compatible_clothing_levels", ALL_LEVELS):
                        continue
                    if mode == "exhaustive":
                        for clothing in all_item_combos(cdata, lvl, cap):
                            add(zone, piece, clothing, lvl)
                    else:  # level
                        add(zone, piece, canonical_clothing(cdata, lvl_idx), lvl)
    return entries


def plan_to_csv(entries):
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=PLAN_FIELDS, lineterminator="\n")
    writer.writeheader()
    for e in entries:
        writer.writerow({f: e.get(f, "") for f in PLAN_FIELDS})
    return out.getvalue()


def to_manifest_entries(entries):
    """Convert plan entries to manifest (logging) entries."""
    return [
        mf.make_entry(
            index=e["index"],
            seed=e["seed"],
            prompt=e["final_prompt"],
            negative_prompt=e["negative_prompt"],
            filename_hint=e["filename_hint"],
            tags=e["tags"],
        )
        for e in entries
    ]


def renumber(entries, base_seed):
    """Re-index a concatenated list so index/seed are globally unique."""
    for i, e in enumerate(entries):
        e["index"] = i
        e["seed"] = image_seed(base_seed, i)
    return entries
