import json
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

# ---------------------------------------------------------------------------
# EXTERNAL DATA FOLDERS — the pack can aggregate a much bigger database that
# lives OUTSIDE its own data/ folder. Configure via EITHER:
#   1) environment variable:  ASB_DATA_DIRS=/path/to/my/data:/another/dir
#      (path-separated; each entry is a root containing models/ locations/
#       clothing/ cameras/ framing/ subfolders, same layout as data/)
#   2) data/config.json:      { "extra_data_dirs": ["/path/to/my/data", ...] }
# Pack data always wins on name conflicts; extra dirs simply ADD everything.
# ---------------------------------------------------------------------------
_CONFIG_FILE = os.path.join(DATA_DIR, "config.json")
_EXTRA_CACHE = None


def extra_dirs():
    """Root dirs (outside data/) to also scan for models/locations/clothing/
    cameras/framing. From ASB_DATA_DIRS env (pathsep) + data/config.json."""
    global _EXTRA_CACHE
    if _EXTRA_CACHE is not None:
        return _EXTRA_CACHE
    dirs = []
    env = os.environ.get("ASB_DATA_DIRS", "")
    if env:
        dirs += [d for d in env.split(os.pathsep) if d.strip()]
    try:
        if os.path.isfile(_CONFIG_FILE):
            with open(_CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            extra = cfg.get("extra_data_dirs") or []
            if isinstance(extra, list):
                for d in extra:
                    if d and os.path.isdir(os.path.abspath(d)):
                        dirs.append(os.path.abspath(d))
    except Exception as e:
        print(f"[ASB] config.json error: {e}")
    # dedupe, keep order
    seen = set()
    _EXTRA_CACHE = []
    for d in dirs:
        a = os.path.abspath(d)
        if a not in seen and os.path.isdir(a):
            seen.add(a)
            _EXTRA_CACHE.append(a)
    return _EXTRA_CACHE


def get_data_path(*parts):
    return os.path.join(DATA_DIR, *parts)


def reset_data_cache():
    """Drop cached extra-dir list (used by tests/scripts after changing env)."""
    global _EXTRA_CACHE
    _EXTRA_CACHE = None


def _subfolder_roots(subfolder):
    """[(root_path, is_pack)] for a subfolder across pack + extra dirs."""
    roots = [(DATA_DIR, True)]
    for d in extra_dirs():
        roots.append((d, False))
    return roots


def list_json_files(subfolder):
    """All file names in a subfolder across pack + extra dirs (deduped)."""
    names = []
    seen = set()
    for root, _ in _subfolder_roots(subfolder):
        folder = os.path.join(root, subfolder)
        if os.path.isdir(folder):
            for f in sorted(os.listdir(folder)):
                if f.endswith(".json") and f[:-5] not in seen:
                    seen.add(f[:-5])
                    names.append(f[:-5])
    return names if names else ["(none)"]


def load_json(subfolder, name):
    """Load a file by name — pack data wins, then extra dirs."""
    for root, _ in _subfolder_roots(subfolder):
        path = os.path.join(root, subfolder, f"{name}.json")
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"[ASB] Error loading {path}: {e}")
                return {}
    return {}

def get_model_list():
    return list_json_files("models")

def get_location_list():
    return list_json_files("locations")

def get_clothing_list():
    return list_json_files("clothing")


def _load_flat_or_folder(subfolder, single_file, list_key):
    """
    Load a preset list that may live either in a single JSON file
    (data/<single_file>) OR as a folder of JSON files
    (data/<subfolder>/*.json, one preset per file, like models/locations/
    clothing). Both are merged; duplicates by 'id' are dropped (flat file
    wins on conflicts).

    Each source file may be:
      - a single object with an "id" key,
      - a list of such objects,
      - a dict with a list under <list_key> (e.g. {"cameras": [...]}).
    """
    out = {}
    sources = []
    # pack data first (wins on conflicts), then extras
    for root, _ in _subfolder_roots(subfolder):
        flat = os.path.join(root, single_file)
        if os.path.isfile(flat):
            sources.append(flat)
        folder = os.path.join(root, subfolder)
        if os.path.isdir(folder):
            sources.extend(
                os.path.join(folder, f)
                for f in sorted(os.listdir(folder)) if f.endswith(".json")
            )
    for path in sources:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            print(f"[ASB] Error loading {path}: {e}")
            continue
        items = []
        if isinstance(data, dict):
            if list_key in data:
                items = data[list_key] or []
            elif data.get("id"):
                items = [data]
        elif isinstance(data, list):
            items = data
        for it in items:
            if isinstance(it, dict) and it.get("id"):
                out[it["id"]] = it  # first source wins (flat file first)
    return list(out.values())


def load_cameras():
    """Camera presets from data/cameras.json AND data/cameras/*.json."""
    return _load_flat_or_folder("cameras", "cameras.json", "cameras")


def get_camera_ids():
    return [c.get("id") for c in load_cameras() if c.get("id")]


# --- "first available" helpers — dynamic defaults so nothing is hardcoded ---

def first_model():
    m = get_model_list()
    return m[0] if m and m[0] != "(none)" else ""


def first_location():
    l = get_location_list()
    return l[0] if l and l[0] != "(none)" else ""


def first_clothing():
    c = get_clothing_list()
    return c[0] if c and c[0] != "(none)" else ""


def first_camera():
    c = get_camera_ids()
    return c[0] if c else ""


def first_zone_name():
    """First zone (name) across all locations, for text-input defaults."""
    for ln in get_location_list():
        loc = load_json("locations", ln)
        for z in loc.get("photo_zones", []):
            return z.get("name") or z.get("zone_id") or "Zone"
    return "Zone"


def first_piece_label():
    """First piece label 'id | type' across all data, for text-input defaults."""
    for ln in get_location_list():
        loc = load_json("locations", ln)
        for z in loc.get("photo_zones", []):
            for p in z.get("prompt_pieces", []):
                t = p.get("type") or ""
                return f"{p.get('id')} | {t}" if t else str(p.get("id") or "piece")
    return "piece"


def load_framing():
    """Framing presets from data/framing.json AND data/framing/*.json."""
    return _load_flat_or_folder("framing", "framing.json", "framing")


def get_framing_ids():
    return [f.get("id") for f in load_framing() if f.get("id")]


ALL_LEVELS = ["level_0", "level_1", "level_2", "level_3", "level_4"]


def build_editor_payload():
    """
    Build the FULL editor data (the same shape web/planner_data.json used to
    snapshot) LIVE from the data folders — pack + extras. The frontend calls
    this through the /asb/data route so the editor ALWAYS reflects the real
    data folder, never a stale snapshot.
    """
    from .prompts import QUALITY_PRESETS, STYLE_PRESETS

    data = {
        "models": get_model_list(),
        "locations": [],
        "clothing": [],
        "styles": list(STYLE_PRESETS.keys()),
        "qualities": list(QUALITY_PRESETS.keys()),
        "levels": ALL_LEVELS,
        "cameras": [{"id": c.get("id"), "brand": c.get("brand"),
                     "model": c.get("model"), "lens": c.get("lens"),
                     "tech": c.get("tech")}
                    for c in load_cameras()],
        "framing": [{"id": f.get("id"), "name": f.get("name"),
                     "tech": f.get("tech"),
                     "default_for_piece_types": f.get("default_for_piece_types", [])}
                    for f in load_framing()],
    }
    for ln in get_location_list():
        loc = load_json("locations", ln)
        zones = []
        for z in loc.get("photo_zones", []):
            pieces = []
            for p in z.get("prompt_pieces", []):
                pieces.append({
                    "id": p.get("id"),
                    "type": p.get("type", ""),
                    "label": f"{p.get('id')} | {p.get('type')}",
                    "levels": p.get("compatible_clothing_levels", ALL_LEVELS),
                    "prompt": p.get("prompt", ""),
                })
            zones.append({
                "zone_id": z.get("zone_id") or z.get("name"),
                "name": z.get("name"),
                "pieces": pieces,
            })
        data["locations"].append({
            "name": ln,
            "label": loc.get("name", ln),
            "zones": zones,
        })
    for cn in get_clothing_list():
        cl = load_json("clothing", cn)
        items = []
        for it in cl.get("items", []):
            items.append({
                "item_id": it.get("item_id") or it.get("name"),
                "name": it.get("name", it.get("item_id")),
                "states": [s.get("state_id") for s in it.get("states", [])],
                "state_phrases": {s.get("state_id"): s.get("prompt_phrase", "")
                                  for s in it.get("states", [])},
            })
        data["clothing"].append({
            "name": cn,
            "label": cl.get("name", cn),
            "items": items,
            "removed_states": (cl.get("level_config") or {}).get(
                "removed_states",
                ["removed", "no panties", "no bra", "barefoot", "no top",
                 "no skirt", "no dress", "no shirt"],
            ),
        })
    return data
