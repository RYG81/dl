# PythonLab Classroom

**A no-code Python teaching simulator for Unity.** Instructors plan lessons in a
visual editor; students write real Python that runs inside a 3D simulation, with
console output, objectives, hints, solutions, and automatic grading.

> Target buyer: coding schools, STEM teachers, training centers, and ed-tech
> teams who want a ready-made "learn Python by controlling a simulation" product.

> **Release status:** This is a product prototype, not yet verified as sale-ready. The companion server was tested, but the Unity project, target builds, and Docker isolation have not been tested in this environment. Perform Unity/platform QA, security review, and replace the placeholder license before commercial release. Instructors can use the included lessons without programming; creating new starter and solution code requires Python knowledge or obtaining examples from someone who has it.

---

## What the instructor does (no code)

1. Open **PythonLab → Setup Wizard** in Unity and click **Build Example Scene**.
2. Open **PythonLab → Lesson Builder**.
3. For each lesson, fill in:
   - Title + description
   - Objectives
   - Starter code
   - Solution code
   - Hints
   - Auto-grading rules (dropdowns and fields, not code)
4. Press **Play**. Students get a full classroom UI automatically.

That's it. The instructor only plans *what students should do*; the pack handles
the editor, runtime UI, Python execution bridge, simulation commands, grading,
progress, hints, and solutions.

## What the student sees

- Lesson picker with progress checkmarks
- Objectives and description
- Python code editor
- Run / Stop / Hint / Solution buttons
- Live console output
- Auto-grading feedback (pass/fail per rule)
- Next-lesson flow (optionally gated by passing)

## What's in this repository

```
PythonLab-Classroom/
├── UnityPackage/com.pythonlab.classroom/   # The sellable Unity package (UPM)
│   ├── Runtime/                            # Client, sim executor, validator, student UI
│   ├── Editor/                             # Setup Wizard + Lesson Builder (no-code)
│   ├── Samples~/ExampleCourse/             # Importable example course
│   └── Documentation~/                     # In-package docs
├── Server/                                 # Companion execution server + admin UI
│   ├── app.py                              # Auth, quotas, sessions, admin API
│   ├── worker.py                           # Python worker + `sim` bridge
│   ├── admin/                              # Browser admin dashboard
│   ├── Dockerfile.server / Dockerfile.worker
│   ├── docker-compose.yml
│   └── scripts/                            # run-local, build-worker (sh + ps1)
├── docs/                                   # Product, deployment, and sales docs
└── tools/                                  # Packaging helper
```

## Quick start

### 1. Run the companion server

```bash
cd Server
bash scripts/run-local.sh          # Windows: ./scripts/run-local.ps1
```

Open `http://127.0.0.1:8000/admin`, enter the admin token, and create an API key.

### 2. Set up Unity

1. Unity **2021.3+**.
2. Add the package via Package Manager → **Add package from disk…** →
   `UnityPackage/com.pythonlab.classroom/package.json`.
3. Open **PythonLab → Setup Wizard**.
4. Enter the server URL and API key, then click **Build Example Scene**.
5. Press **Play**.

### 3. Author your course

Open **PythonLab → Lesson Builder**, load the example course, and replace the
lessons with your own. Use the grading-rule dropdowns to define what "correct"
means. Export to JSON to share or sell course packs.

## Execution modes

| Mode | Use | Isolation |
|---|---|---|
| `local` | Development / demos | Subprocess + resource limits (not a security boundary) |
| `docker` | Production | No network, read-only FS, non-root, CPU/memory/PID limits |

For strong multi-tenant isolation, run the Docker worker under **gVisor** or
**Firecracker**. See `docs/deployment.md`.

## Product status

This is a complete, working reference product. Before selling at scale:

- Run the worker in Docker/gVisor/Firecracker (not `local`).
- Put the server behind HTTPS and lock down CORS.
- Add your branding, EULA, and support channel.
- Test on your target Unity versions and build targets.

See `docs/sales-and-packaging.md` for a go-to-market checklist.
