using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PythonLab.Runtime
{
    /// <summary>
    /// No-code student interface. Builds a complete uGUI classroom panel at
    /// runtime: lesson picker, objectives, code editor, console, hints,
    /// solution reveal, run/stop controls, and auto-grading feedback.
    /// </summary>
    public class PythonLabStudentUI : MonoBehaviour
    {
        [Header("Content")]
        public PythonLabCourse course;

        [Header("References (auto-found if empty)")]
        public PythonLabClient client;
        public SimCommandExecutor executor;

        [Header("Behavior")]
        public bool buildOnStart = true;

        private Canvas _canvas;
        private Dropdown _lessonDropdown;
        private Text _titleLabel;
        private Text _infoText;
        private InputField _codeInput;
        private Text _consoleText;
        private Text _statusText;
        private Button _runButton;
        private Button _nextButton;
        private Button _solutionButton;

        private int _lessonIndex;
        private int _hintIndex;
        private readonly List<string> _consoleLines = new List<string>();
        private LessonValidator.ValidationResult _lastValidation;

        private Font _font;

        private void Start()
        {
            if (client == null) client = FindObjectOfType<PythonLabClient>();
            if (executor == null) executor = FindObjectOfType<SimCommandExecutor>();

            if (client != null)
            {
                client.OnOutput += HandleOutput;
                client.OnError += HandleError;
                client.OnRunStarted += HandleRunStarted;
                client.OnRunFinished += HandleRunFinished;
            }

            if (buildOnStart)
                BuildUI();

            LoadLesson(0);
        }

        private void OnDestroy()
        {
            if (client != null)
            {
                client.OnOutput -= HandleOutput;
                client.OnError -= HandleError;
                client.OnRunStarted -= HandleRunStarted;
                client.OnRunFinished -= HandleRunFinished;
            }
        }

        private LessonDefinition CurrentLesson =>
            course != null && course.lessons != null && _lessonIndex >= 0 && _lessonIndex < course.lessons.Length
                ? course.lessons[_lessonIndex]
                : null;

        // ------------------------------------------------------------------
        // UI construction
        // ------------------------------------------------------------------
        private void BuildUI()
        {
            _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (_font == null) _font = Resources.GetBuiltinResource<Font>("Arial.ttf");

            var canvasGo = new GameObject("PythonLabCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            _canvas = canvasGo.GetComponent<Canvas>();
            _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1600, 900);

            if (FindObjectOfType<EventSystem>() == null)
                new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

            var root = CreatePanel(canvasGo.transform, "Root", new Color(0.07f, 0.09f, 0.12f, 0.98f));
            Stretch(root);

            // Top bar
            var top = CreatePanel(root.transform, "TopBar", new Color(0.10f, 0.13f, 0.18f));
            SetAnchors(top, new Vector2(0, 1), new Vector2(1, 1), new Vector2(0, -70), new Vector2(0, 0));
            top.pivot = new Vector2(0.5f, 1);

            _titleLabel = CreateText(top.transform, "Title", "PythonLab Classroom", 22, FontStyle.Bold, TextAnchor.MiddleLeft);
            SetAnchors(_titleLabel.rectTransform, new Vector2(0, 0), new Vector2(0.35f, 1), new Vector2(16, 0), new Vector2(0, 0));

            _lessonDropdown = CreateDropdown(top.transform, "LessonDropdown");
            SetAnchors(_lessonDropdown.GetComponent<RectTransform>(), new Vector2(0.36f, 0.5f), new Vector2(0.62f, 0.5f), new Vector2(0, -18), new Vector2(0, 18));

            _runButton = CreateButton(top.transform, "Run", "Run", new Color(0.15f, 0.55f, 0.25f));
            SetAnchors(_runButton.GetComponent<RectTransform>(), new Vector2(0.64f, 0.5f), new Vector2(0.72f, 0.5f), new Vector2(0, -18), new Vector2(0, 18));
            _runButton.onClick.AddListener(RunCurrent);

            var stopButton = CreateButton(top.transform, "Stop", "Stop", new Color(0.65f, 0.2f, 0.2f));
            SetAnchors(stopButton.GetComponent<RectTransform>(), new Vector2(0.73f, 0.5f), new Vector2(0.81f, 0.5f), new Vector2(0, -18), new Vector2(0, 18));
            stopButton.onClick.AddListener(() => { if (client != null) client.StopRun(); });

            var hintButton = CreateButton(top.transform, "Hint", "Hint", new Color(0.25f, 0.35f, 0.55f));
            SetAnchors(hintButton.GetComponent<RectTransform>(), new Vector2(0.82f, 0.5f), new Vector2(0.90f, 0.5f), new Vector2(0, -18), new Vector2(0, 18));
            hintButton.onClick.AddListener(ShowHint);

            _solutionButton = CreateButton(top.transform, "Solution", "Solution", new Color(0.45f, 0.3f, 0.55f));
            SetAnchors(_solutionButton.GetComponent<RectTransform>(), new Vector2(0.91f, 0.5f), new Vector2(0.99f, 0.5f), new Vector2(0, -18), new Vector2(0, 18));
            _solutionButton.onClick.AddListener(ShowSolution);

            // Left info panel
            var left = CreatePanel(root.transform, "InfoPanel", new Color(0.09f, 0.11f, 0.15f));
            SetAnchors(left, new Vector2(0, 0), new Vector2(0.28f, 1), new Vector2(12, 12), new Vector2(-6, -82));
            var leftScroll = CreateScrollText(left.transform, "InfoScroll", out _infoText);
            Stretch(leftScroll);

            // Code editor
            var codePanel = CreatePanel(root.transform, "CodePanel", new Color(0.06f, 0.08f, 0.11f));
            SetAnchors(codePanel, new Vector2(0.28f, 0.30f), new Vector2(0.72f, 1), new Vector2(6, 12), new Vector2(-6, -82));
            _codeInput = CreateCodeInput(codePanel.transform, "CodeInput");
            Stretch(_codeInput.GetComponent<RectTransform>());

            // Console
            var consolePanel = CreatePanel(root.transform, "ConsolePanel", new Color(0.05f, 0.06f, 0.09f));
            SetAnchors(consolePanel, new Vector2(0.28f, 0), new Vector2(1, 0.30f), new Vector2(6, 12), new Vector2(-12, -6));
            var consoleScroll = CreateScrollText(consolePanel.transform, "ConsoleScroll", out _consoleText);
            Stretch(consoleScroll);

            // Right status / validation panel
            var right = CreatePanel(root.transform, "StatusPanel", new Color(0.09f, 0.11f, 0.15f));
            SetAnchors(right, new Vector2(0.72f, 0.30f), new Vector2(1, 1), new Vector2(6, 12), new Vector2(-12, -82));
            _statusText = CreateText(right.transform, "Status", "Ready.", 15, FontStyle.Normal, TextAnchor.UpperLeft);
            Stretch(_statusText.rectTransform);
            _statusText.rectTransform.offsetMin = new Vector2(10, 44);
            _statusText.rectTransform.offsetMax = new Vector2(-10, -10);

            _nextButton = CreateButton(right.transform, "Next", "Next Lesson", new Color(0.2f, 0.4f, 0.6f));
            var nextRt = _nextButton.GetComponent<RectTransform>();
            nextRt.anchorMin = new Vector2(0, 0);
            nextRt.anchorMax = new Vector2(1, 0);
            nextRt.pivot = new Vector2(0.5f, 0);
            nextRt.anchoredPosition = new Vector2(0, 8);
            nextRt.sizeDelta = new Vector2(-16, 30);
            _nextButton.onClick.AddListener(NextLesson);

            PopulateLessonDropdown();
        }

        private void PopulateLessonDropdown()
        {
            if (_lessonDropdown == null || course == null) return;
            _lessonDropdown.ClearOptions();
            var options = new List<string>();
            for (int i = 0; i < course.lessons.Length; i++)
            {
                string mark = IsLessonPassed(course.lessons[i]) ? "✓ " : "";
                options.Add($"{mark}{i + 1}. {course.lessons[i].title}");
            }
            _lessonDropdown.AddOptions(options);
            _lessonDropdown.onValueChanged.RemoveAllListeners();
            _lessonDropdown.onValueChanged.AddListener(index => LoadLesson(index));
        }

        // ------------------------------------------------------------------
        // Lesson flow
        // ------------------------------------------------------------------
        public void LoadLesson(int index)
        {
            if (course == null || course.lessons == null || course.lessons.Length == 0) return;
            _lessonIndex = Mathf.Clamp(index, 0, course.lessons.Length - 1);
            _hintIndex = 0;
            _lastValidation = null;

            var lesson = CurrentLesson;
            if (_titleLabel != null) _titleLabel.text = course.courseName;
            if (_lessonDropdown != null && _lessonDropdown.value != _lessonIndex)
                _lessonDropdown.SetValueWithoutNotify(_lessonIndex);

            if (_codeInput != null) _codeInput.text = lesson.starterCode ?? "";
            if (_consoleText != null)
            {
                _consoleLines.Clear();
                _consoleText.text = "";
            }

            RefreshInfo();
            SetStatus("Ready. Write Python, then press Run.");
            UpdateButtons();
        }

        private void RefreshInfo()
        {
            var lesson = CurrentLesson;
            if (lesson == null || _infoText == null) return;

            string text = $"<b>{lesson.title}</b>\n\n{lesson.description}\n\n<b>Objectives</b>\n";
            if (lesson.objectives != null)
                foreach (var obj in lesson.objectives)
                    text += $"• {obj}\n";

            if (_lastValidation != null)
            {
                text += "\n<b>Grading</b>\n";
                foreach (var outcome in _lastValidation.outcomes)
                {
                    string icon = outcome.passed ? "<color=#7CFC90>✓</color>" : "<color=#FF8080>✗</color>";
                    text += $"{icon} {RuleLabel(outcome.rule)}\n";
                    if (!outcome.passed)
                        text += $"   <color=#FFB0B0>{outcome.feedback}</color>\n";
                }
            }

            _infoText.text = text;
        }

        private static string RuleLabel(LessonRule rule)
        {
            switch (rule.type)
            {
                case LessonRuleType.OutputContains: return $"Output contains \"{rule.text}\"";
                case LessonRuleType.OutputRegex: return $"Output matches pattern";
                case LessonRuleType.ObjectExists: return $"Object '{rule.target}' exists";
                case LessonRuleType.ObjectMissing: return $"Object '{rule.target}' removed";
                case LessonRuleType.ObjectPositionWithin: return $"'{rule.target}' near target";
                case LessonRuleType.ObjectCountAtLeast: return $"At least {rule.count} objects";
                case LessonRuleType.CommandCountAtMost: return $"At most {rule.count} sim commands";
                case LessonRuleType.NoErrors: return "No errors";
                default: return "Run completed";
            }
        }

        private void RunCurrent()
        {
            if (client == null || CurrentLesson == null) return;

            if (course.resetWorldBeforeRun && executor != null)
                executor.ClearWorld();
            if (executor != null)
                executor.ResetCommandCount();

            _lastValidation = null;
            RefreshInfo();
            client.RunCode(_codeInput != null ? _codeInput.text : CurrentLesson.starterCode);
        }

        private void ShowHint()
        {
            var lesson = CurrentLesson;
            if (lesson == null || !course.allowHints || lesson.hints == null || lesson.hints.Length == 0) return;
            string hint = lesson.hints[Mathf.Min(_hintIndex, lesson.hints.Length - 1)];
            _hintIndex++;
            AppendConsole($"[hint] {hint}\n", new Color(0.6f, 0.8f, 1f));
        }

        private void ShowSolution()
        {
            var lesson = CurrentLesson;
            if (lesson == null || !course.allowSolutions) return;
            if (_codeInput != null) _codeInput.text = lesson.solutionCode ?? "";
            AppendConsole("[solution loaded]\n", new Color(0.8f, 0.6f, 1f));
        }

        private void NextLesson()
        {
            if (course == null) return;
            if (_lessonIndex < course.lessons.Length - 1)
                LoadLesson(_lessonIndex + 1);
        }

        private void UpdateButtons()
        {
            if (_solutionButton != null)
                _solutionButton.gameObject.SetActive(course != null && course.allowSolutions);

            if (_nextButton != null)
            {
                bool canNext = course != null && _lessonIndex < course.lessons.Length - 1;
                if (course != null && course.requirePassToAdvance)
                    canNext = canNext && IsLessonPassed(CurrentLesson);
                _nextButton.interactable = canNext;
            }
        }

        // ------------------------------------------------------------------
        // Client events
        // ------------------------------------------------------------------
        private void HandleRunStarted()
        {
            SetStatus("Running…");
            if (_runButton != null) _runButton.interactable = false;
        }

        private void HandleOutput(string text, bool isError)
        {
            AppendConsole(text, isError ? new Color(1f, 0.5f, 0.5f) : new Color(0.85f, 0.9f, 0.95f));
        }

        private void HandleError(string message)
        {
            AppendConsole("\n[error] " + message + "\n", new Color(1f, 0.4f, 0.4f));
        }

        private void HandleRunFinished(RunResult result)
        {
            if (_runButton != null) _runButton.interactable = true;

            var lesson = CurrentLesson;
            if (lesson != null && result != null)
            {
                _lastValidation = LessonValidator.Validate(lesson, result, executor);
                if (_lastValidation.allPassed)
                {
                    MarkLessonPassed(lesson);
                    SetStatus("<color=#7CFC90>Lesson passed!</color> Great work.");
                }
                else
                {
                    SetStatus("<color=#FFB0B0>Not passed yet.</color> Check the grading feedback.");
                }
                RefreshInfo();
                PopulateLessonDropdown();
            }
            else
            {
                SetStatus("Run finished.");
            }

            UpdateButtons();
        }

        // ------------------------------------------------------------------
        // Progress persistence
        // ------------------------------------------------------------------
        private string ProgressKey(LessonDefinition lesson) =>
            $"PythonLab.{course.courseName}.{lesson.id}.passed";

        private bool IsLessonPassed(LessonDefinition lesson) =>
            lesson != null && PlayerPrefs.GetInt(ProgressKey(lesson), 0) == 1;

        private void MarkLessonPassed(LessonDefinition lesson)
        {
            PlayerPrefs.SetInt(ProgressKey(lesson), 1);
            PlayerPrefs.Save();
        }

        // ------------------------------------------------------------------
        // Helpers
        // ------------------------------------------------------------------
        private void SetStatus(string richText)
        {
            if (_statusText != null) _statusText.text = richText;
        }

        private void AppendConsole(string text, Color color)
        {
            if (_consoleText == null) return;
            string hex = ColorUtility.ToHtmlStringRGB(color);
            _consoleLines.Add($"<color=#{hex}>{text}</color>");
            if (_consoleLines.Count > 500) _consoleLines.RemoveAt(0);
            _consoleText.text = string.Join("", _consoleLines);
            Canvas.ForceUpdateCanvases();
            var scroll = _consoleText.GetComponentInParent<ScrollRect>();
            if (scroll != null) scroll.verticalNormalizedPosition = 0f;
        }

        private GameObject CreatePanel(Transform parent, string name, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            go.GetComponent<Image>().color = color;
            return go;
        }

        private Text CreateText(Transform parent, string name, string content, int size, FontStyle style, TextAnchor anchor)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Text));
            go.transform.SetParent(parent, false);
            var text = go.GetComponent<Text>();
            text.font = _font;
            text.text = content;
            text.fontSize = size;
            text.fontStyle = style;
            text.alignment = anchor;
            text.color = new Color(0.9f, 0.93f, 0.97f);
            text.supportRichText = true;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            return text;
        }

        private Button CreateButton(Transform parent, string name, string label, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            go.GetComponent<Image>().color = color;
            var button = go.GetComponent<Button>();
            var text = CreateText(go.transform, "Label", label, 15, FontStyle.Bold, TextAnchor.MiddleCenter);
            Stretch(text.rectTransform);
            return button;
        }

        private InputField CreateCodeInput(Transform parent, string name)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(InputField));
            go.transform.SetParent(parent, false);
            go.GetComponent<Image>().color = new Color(0.04f, 0.05f, 0.08f);
            var input = go.GetComponent<InputField>();

            var text = CreateText(go.transform, "Text", "", 15, FontStyle.Normal, TextAnchor.UpperLeft);
            text.color = new Color(0.85f, 0.95f, 0.85f);
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            Stretch(text.rectTransform);
            text.rectTransform.offsetMin = new Vector2(10, 10);
            text.rectTransform.offsetMax = new Vector2(-10, -10);

            var placeholder = CreateText(go.transform, "Placeholder", "# Write Python here…", 15, FontStyle.Italic, TextAnchor.UpperLeft);
            placeholder.color = new Color(0.4f, 0.45f, 0.5f);
            Stretch(placeholder.rectTransform);
            placeholder.rectTransform.offsetMin = new Vector2(10, 10);
            placeholder.rectTransform.offsetMax = new Vector2(-10, -10);

            input.textComponent = text;
            input.placeholder = placeholder;
            input.lineType = InputField.LineType.MultiLineNewline;
            input.characterLimit = 0;
            return input;
        }

        private Dropdown CreateDropdown(Transform parent, string name)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Dropdown));
            go.transform.SetParent(parent, false);
            go.GetComponent<Image>().color = new Color(0.16f, 0.2f, 0.28f);
            var dropdown = go.GetComponent<Dropdown>();

            var label = CreateText(go.transform, "Label", "Lesson", 15, FontStyle.Normal, TextAnchor.MiddleLeft);
            SetAnchors(label.rectTransform, Vector2.zero, Vector2.one, new Vector2(10, 0), new Vector2(-25, 0));
            dropdown.captionText = label;

            var arrow = CreateText(go.transform, "Arrow", "▼", 14, FontStyle.Normal, TextAnchor.MiddleCenter);
            SetAnchors(arrow.rectTransform, new Vector2(1, 0.5f), new Vector2(1, 0.5f), new Vector2(-22, -10), new Vector2(-6, 10));

            var template = CreatePanel(go.transform, "Template", new Color(0.12f, 0.15f, 0.2f));
            var templateRt = template.GetComponent<RectTransform>();
            templateRt.anchorMin = new Vector2(0, 0);
            templateRt.anchorMax = new Vector2(1, 0);
            templateRt.pivot = new Vector2(0.5f, 1);
            templateRt.anchoredPosition = new Vector2(0, -2);
            templateRt.sizeDelta = new Vector2(0, 180);
            var templateScroll = template.AddComponent<ScrollRect>();
            templateScroll.horizontal = false;
            templateScroll.vertical = true;
            templateScroll.movementType = ScrollRect.MovementType.Clamped;
            template.SetActive(false);

            var viewport = CreatePanel(template.transform, "Viewport", new Color(0, 0, 0, 0));
            Stretch(viewport.GetComponent<RectTransform>());
            viewport.AddComponent<Mask>().showMaskGraphic = false;

            var content = new GameObject("Content", typeof(RectTransform));
            content.transform.SetParent(viewport.transform, false);
            var contentRt = content.GetComponent<RectTransform>();
            contentRt.anchorMin = new Vector2(0, 1);
            contentRt.anchorMax = new Vector2(1, 1);
            contentRt.pivot = new Vector2(0.5f, 1);
            contentRt.sizeDelta = new Vector2(0, 30);

            var item = new GameObject("Item", typeof(RectTransform), typeof(Toggle));
            item.transform.SetParent(content, false);
            var itemRt = item.GetComponent<RectTransform>();
            itemRt.anchorMin = new Vector2(0, 0.5f);
            itemRt.anchorMax = new Vector2(1, 0.5f);
            itemRt.sizeDelta = new Vector2(0, 30);
            var toggle = item.GetComponent<Toggle>();

            var itemBg = CreatePanel(item.transform, "ItemBackground", new Color(0.2f, 0.3f, 0.5f));
            Stretch(itemBg.GetComponent<RectTransform>());
            var itemCheck = CreateText(item.transform, "ItemCheckmark", "✓", 14, FontStyle.Normal, TextAnchor.MiddleLeft);
            SetAnchors(itemCheck.rectTransform, new Vector2(0, 0.5f), new Vector2(0, 0.5f), new Vector2(8, -10), new Vector2(24, 10));
            var itemLabel = CreateText(item.transform, "ItemLabel", "Item", 14, FontStyle.Normal, TextAnchor.MiddleLeft);
            SetAnchors(itemLabel.rectTransform, Vector2.zero, Vector2.one, new Vector2(28, 0), new Vector2(-6, 0));

            toggle.targetGraphic = itemBg.GetComponent<Image>();
            toggle.graphic = itemCheck;
            toggle.isOn = true;

            templateScroll.content = contentRt;
            templateScroll.viewport = viewport.GetComponent<RectTransform>();

            dropdown.template = templateRt;
            dropdown.itemText = itemLabel;
            dropdown.captionText = label;
            return dropdown;
        }

        private GameObject CreateScrollText(Transform parent, string name, out Text textComponent)
        {
            var scrollGo = new GameObject(name, typeof(RectTransform), typeof(ScrollRect));
            scrollGo.transform.SetParent(parent, false);
            var scroll = scrollGo.GetComponent<ScrollRect>();
            scroll.horizontal = false;
            scroll.vertical = true;
            scroll.movementType = ScrollRect.MovementType.Clamped;

            var viewport = CreatePanel(scrollGo.transform, "Viewport", new Color(0, 0, 0, 0));
            Stretch(viewport.GetComponent<RectTransform>());
            viewport.AddComponent<Mask>().showMaskGraphic = false;

            // The Text itself is the scroll content. ContentSizeFitter on the
            // Text lets the scroll area grow with the amount of content.
            var textGo = new GameObject("Text", typeof(RectTransform), typeof(Text), typeof(ContentSizeFitter));
            textGo.transform.SetParent(viewport.transform, false);
            textComponent = textGo.GetComponent<Text>();
            textComponent.font = _font;
            textComponent.fontSize = 15;
            textComponent.alignment = TextAnchor.UpperLeft;
            textComponent.color = new Color(0.9f, 0.93f, 0.97f);
            textComponent.supportRichText = true;
            textComponent.horizontalOverflow = HorizontalWrapMode.Wrap;
            textComponent.verticalOverflow = VerticalWrapMode.Overflow;

            var textRt = textComponent.rectTransform;
            textRt.anchorMin = new Vector2(0, 1);
            textRt.anchorMax = new Vector2(1, 1);
            textRt.pivot = new Vector2(0.5f, 1);
            textRt.anchoredPosition = Vector2.zero;
            textRt.sizeDelta = new Vector2(-16, 0);

            var fitter = textGo.GetComponent<ContentSizeFitter>();
            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            scroll.content = textRt;
            scroll.viewport = viewport.GetComponent<RectTransform>();
            return scrollGo;
        }

        private static void Stretch(RectTransform rt)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
        }

        private static void Stretch(GameObject go) => Stretch(go.GetComponent<RectTransform>());

        private static void SetAnchors(RectTransform rt, Vector2 min, Vector2 max, Vector2 offsetMin, Vector2 offsetMax)
        {
            rt.anchorMin = min;
            rt.anchorMax = max;
            rt.offsetMin = offsetMin;
            rt.offsetMax = offsetMax;
        }
    }
}
