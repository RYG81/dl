using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;

namespace PythonLab.Runtime
{
    /// <summary>
    /// No-code auto-grading. Evaluates the instructor's rules against the run
    /// result and the simulation state. Returns per-rule pass/fail + feedback.
    /// </summary>
    public static class LessonValidator
    {
        public class RuleOutcome
        {
            public LessonRule rule;
            public bool passed;
            public string feedback;
        }

        public class ValidationResult
        {
            public bool allPassed;
            public List<RuleOutcome> outcomes = new List<RuleOutcome>();
        }

        public static ValidationResult Validate(LessonDefinition lesson, RunResult run, SimCommandExecutor executor)
        {
            var result = new ValidationResult { allPassed = true };
            if (lesson == null || lesson.rules == null) return result;

            foreach (var rule in lesson.rules)
            {
                var outcome = Evaluate(rule, run, executor);
                result.outcomes.Add(outcome);
                if (!outcome.passed) result.allPassed = false;
            }

            return result;
        }

        private static RuleOutcome Evaluate(LessonRule rule, RunResult run, SimCommandExecutor executor)
        {
            bool passed = false;
            string feedback = "";

            switch (rule.type)
            {
                case LessonRuleType.RunCompleted:
                    passed = run != null && run.Completed;
                    feedback = "Your code needs to run to completion.";
                    break;

                case LessonRuleType.NoErrors:
                    passed = run != null && !run.HadError;
                    feedback = "Your code produced an error. Check the console.";
                    break;

                case LessonRuleType.OutputContains:
                    passed = run != null && run.Output != null && run.Output.Contains(rule.text ?? "");
                    feedback = $"Your output should contain: {rule.text}";
                    break;

                case LessonRuleType.OutputRegex:
                    try
                    {
                        passed = run != null && run.Output != null &&
                                 Regex.IsMatch(run.Output, rule.text ?? "");
                    }
                    catch (System.ArgumentException)
                    {
                        passed = false;
                    }
                    feedback = $"Your output should match the pattern: {rule.text}";
                    break;

                case LessonRuleType.ObjectExists:
                    passed = executor != null && executor.HasObject(rule.target);
                    feedback = $"You need to create an object named '{rule.target}'.";
                    break;

                case LessonRuleType.ObjectMissing:
                    passed = executor != null && !executor.HasObject(rule.target);
                    feedback = $"The object '{rule.target}' should be deleted.";
                    break;

                case LessonRuleType.ObjectPositionWithin:
                    passed = executor != null &&
                             executor.TryGetPosition(rule.target, out var pos) &&
                             Vector3.Distance(pos, rule.position) <= rule.tolerance;
                    feedback = $"Move '{rule.target}' close to {rule.position} (within {rule.tolerance}).";
                    break;

                case LessonRuleType.ObjectCountAtLeast:
                    passed = executor != null && executor.ObjectCount >= rule.count;
                    feedback = $"Create at least {rule.count} objects.";
                    break;

                case LessonRuleType.CommandCountAtMost:
                    passed = run != null && run.CommandCount <= rule.count;
                    feedback = $"Use at most {rule.count} simulation commands (try a loop!).";
                    break;

                default:
                    passed = true;
                    break;
            }

            if (!string.IsNullOrEmpty(rule.message))
                feedback = rule.message;

            return new RuleOutcome { rule = rule, passed = passed, feedback = feedback };
        }
    }
}
