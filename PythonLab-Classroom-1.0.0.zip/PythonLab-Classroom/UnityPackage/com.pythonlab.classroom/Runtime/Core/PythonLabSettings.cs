using UnityEngine;

namespace PythonLab.Runtime
{
    /// <summary>
    /// Project-wide connection settings for the PythonLab companion server.
    /// Create via: Assets > Create > PythonLab > Settings.
    /// </summary>
    [CreateAssetMenu(fileName = "PythonLabSettings", menuName = "PythonLab/Settings")]
    public class PythonLabSettings : ScriptableObject
    {
        [Tooltip("Base URL of the PythonLab companion server, e.g. http://127.0.0.1:8000")]
        public string serverUrl = "http://127.0.0.1:8000";

        [Tooltip("API key issued by the server admin. Leave empty only for local demo servers that disable auth.")]
        public string apiKey = "";

        [Tooltip("How often the client polls for new events, in seconds.")]
        [Range(0.05f, 1f)]
        public float pollIntervalSeconds = 0.1f;

        [Tooltip("HTTP request timeout in seconds.")]
        public int requestTimeoutSeconds = 15;

        [Tooltip("Create a server session automatically when the component starts.")]
        public bool createSessionOnStart = true;
    }
}
