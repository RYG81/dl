namespace PythonLab.Runtime
{
    /// <summary>
    /// Summary of one student code run, used by the no-code validator.
    /// </summary>
    public class RunResult
    {
        public bool Completed;
        public bool HadError;
        public string Output = "";
        public string Error = "";
        public int CommandCount;
    }
}
