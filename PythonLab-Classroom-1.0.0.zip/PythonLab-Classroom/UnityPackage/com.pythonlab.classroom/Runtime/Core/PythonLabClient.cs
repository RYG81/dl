using System;
using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using Newtonsoft.Json.Linq;

namespace PythonLab.Runtime
{
    /// <summary>
    /// Talks to the PythonLab companion server. Instructors do not need to touch
    /// this script; it is driven by the student UI and the Lesson Builder.
    /// </summary>
    public class PythonLabClient : MonoBehaviour
    {
        [Header("Configuration")]
        public PythonLabSettings settings;

        [Header("Simulation")]
        public SimCommandExecutor commandExecutor;

        public event Action<string, bool> OnOutput;   // text, isError
        public event Action<string> OnError;
        public event Action OnRunStarted;
        public event Action<RunResult> OnRunFinished;

        public string SessionId { get; private set; }
        public bool IsRunning { get; private set; }
        public bool IsConnected => !string.IsNullOrEmpty(SessionId);

        private int _cursor;
        private RunResult _current;
        private string _serverUrl;
        private string _apiKey;

        private IEnumerator Start()
        {
            if (settings == null)
            {
                Debug.LogError("[PythonLab] No PythonLabSettings assigned.");
                yield break;
            }

            _serverUrl = settings.serverUrl.TrimEnd('/');
            _apiKey = settings.apiKey;

            if (commandExecutor == null)
                commandExecutor = GetComponent<SimCommandExecutor>();

            if (settings.createSessionOnStart)
                yield return CreateSession();

            StartCoroutine(PollLoop());
        }

        private string Url(string path) => _serverUrl + path;

        public IEnumerator CreateSession()
        {
            yield return Request("POST", Url("/api/sessions"), "{}", (code, text) =>
            {
                if (code >= 200 && code < 300)
                {
                    var obj = JObject.Parse(text);
                    SessionId = obj["session_id"]?.Value<string>();
                    _cursor = 0;
                }
                else
                {
                    OnError?.Invoke("Create session failed: " + text);
                }
            });
        }

        public void RunCode(string code)
        {
            if (IsRunning)
            {
                OnError?.Invoke("A run is already in progress.");
                return;
            }

            if (string.IsNullOrEmpty(SessionId))
                StartCoroutine(CreateSessionAndRun(code));
            else
                StartCoroutine(RunCodeRoutine(code));
        }

        private IEnumerator CreateSessionAndRun(string code)
        {
            yield return CreateSession();
            if (!string.IsNullOrEmpty(SessionId))
                yield return RunCodeRoutine(code);
        }

        private IEnumerator RunCodeRoutine(string code)
        {
            IsRunning = true;
            _current = new RunResult();
            OnRunStarted?.Invoke();

            var body = new JObject { ["code"] = code };
            yield return Request("POST", Url($"/api/sessions/{SessionId}/run"), body.ToString(), (httpCode, text) =>
            {
                if (httpCode < 200 || httpCode >= 300)
                {
                    IsRunning = false;
                    _current.HadError = true;
                    _current.Error = text;
                    OnError?.Invoke("Run failed: " + text);
                    OnRunFinished?.Invoke(_current);
                }
            });
        }

        public void StopRun()
        {
            if (string.IsNullOrEmpty(SessionId)) return;
            StartCoroutine(Request("POST", Url($"/api/sessions/{SessionId}/stop"), "{}", (code, text) =>
            {
                if (code < 200 || code >= 300)
                    OnError?.Invoke("Stop failed: " + text);
            }));
        }

        private IEnumerator PollLoop()
        {
            while (true)
            {
                if (!string.IsNullOrEmpty(SessionId))
                    yield return PollOnce();
                yield return new WaitForSeconds(settings != null ? settings.pollIntervalSeconds : 0.1f);
            }
        }

        private IEnumerator PollOnce()
        {
            string url = Url($"/api/sessions/{SessionId}/events?after={_cursor}");
            yield return Request("GET", url, null, (code, text) =>
            {
                if (code < 200 || code >= 300) return;

                var obj = JObject.Parse(text);
                var events = obj["events"] as JArray;
                if (events == null) return;

                foreach (JObject ev in events)
                {
                    _cursor = ev["seq"]?.Value<int>() ?? _cursor;
                    HandleEvent(ev);
                }
            });
        }

        private void HandleEvent(JObject ev)
        {
            string type = ev["type"]?.Value<string>();
            switch (type)
            {
                case "started":
                    IsRunning = true;
                    OnRunStarted?.Invoke();
                    break;

                case "output":
                    string stream = ev["stream"]?.Value<string>() ?? "stdout";
                    string outText = ev["text"]?.Value<string>() ?? "";
                    if (_current != null) _current.Output += outText;
                    OnOutput?.Invoke(outText, stream == "stderr");
                    break;

                case "command":
                    StartCoroutine(ExecuteCommand(ev));
                    break;

                case "done":
                    IsRunning = false;
                    if (_current != null)
                    {
                        _current.Completed = true;
                        _current.CommandCount = commandExecutor != null ? commandExecutor.CommandCount : 0;
                    }
                    OnRunFinished?.Invoke(_current ?? new RunResult { Completed = true });
                    break;

                case "error":
                    IsRunning = false;
                    if (_current != null)
                    {
                        _current.HadError = true;
                        _current.Error = ev["message"]?.Value<string>() ?? "Python error";
                    }
                    OnError?.Invoke(_current?.Error ?? "Python error");
                    OnRunFinished?.Invoke(_current ?? new RunResult { HadError = true });
                    break;

                case "stopped":
                    IsRunning = false;
                    if (_current != null) _current.HadError = true;
                    OnRunFinished?.Invoke(_current ?? new RunResult());
                    break;
            }
        }

        private IEnumerator ExecuteCommand(JObject ev)
        {
            string commandId = ev["command_id"]?.Value<string>();
            string name = ev["name"]?.Value<string>();
            JObject args = ev["args"] as JObject ?? new JObject();

            JToken result = null;
            bool ok = true;
            string error = null;

            try
            {
                if (commandExecutor == null)
                    throw new InvalidOperationException("No SimCommandExecutor assigned.");
                result = commandExecutor.Execute(name, args);
            }
            catch (Exception ex)
            {
                ok = false;
                error = ex.Message;
            }

            var body = new JObject
            {
                ["command_id"] = commandId,
                ["ok"] = ok,
                ["result"] = result,
                ["error"] = error
            };

            yield return Request("POST", Url($"/api/sessions/{SessionId}/command_result"), body.ToString(), (code, text) =>
            {
                if (code < 200 || code >= 300)
                    OnError?.Invoke("Failed to send command result: " + text);
            });
        }

        private IEnumerator Request(string method, string url, string json, Action<long, string> callback)
        {
            var req = new UnityWebRequest(url, method);
            req.downloadHandler = new DownloadHandlerBuffer();
            req.timeout = settings != null ? settings.requestTimeoutSeconds : 15;

            if (!string.IsNullOrEmpty(_apiKey))
                req.SetRequestHeader("Authorization", "Bearer " + _apiKey);

            if (json != null)
            {
                byte[] payload = Encoding.UTF8.GetBytes(json);
                req.uploadHandler = new UploadHandlerRaw(payload);
                req.SetRequestHeader("Content-Type", "application/json");
            }

            yield return req.SendWebRequest();

#if UNITY_2020_1_OR_NEWER
            bool failed = req.result != UnityWebRequest.Result.Success;
#else
            bool failed = req.isNetworkError || req.isHttpError;
#endif
            long responseCode = req.responseCode;
            string responseText = req.downloadHandler != null ? req.downloadHandler.text : "";
            string errorText = req.error;
            req.Dispose();

            if (failed)
                callback?.Invoke(responseCode, string.IsNullOrEmpty(errorText) ? responseText : errorText + " " + responseText);
            else
                callback?.Invoke(responseCode, responseText);
        }
    }
}
