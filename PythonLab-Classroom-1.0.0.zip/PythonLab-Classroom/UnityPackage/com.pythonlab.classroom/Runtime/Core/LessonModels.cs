using System;
using UnityEngine;

namespace PythonLab.Runtime
{
    /// <summary>
    /// No-code grading rule types. Instructors configure these in the Lesson Builder.
    /// </summary>
    public enum LessonRuleType
    {
        RunCompleted,
        NoErrors,
        OutputContains,
        OutputRegex,
        ObjectExists,
        ObjectMissing,
        ObjectPositionWithin,
        ObjectCountAtLeast,
        CommandCountAtMost
    }

    [Serializable]
    public class LessonRule
    {
        public LessonRuleType type = LessonRuleType.RunCompleted;

        [Tooltip("Object id for object rules.")]
        public string target = "";

        [Tooltip("Text for OutputContains, or regex pattern for OutputRegex.")]
        public string text = "";

        [Tooltip("Expected position for ObjectPositionWithin.")]
        public Vector3 position;

        [Tooltip("Allowed distance for ObjectPositionWithin.")]
        public float tolerance = 0.5f;

        [Tooltip("Count for ObjectCountAtLeast or CommandCountAtMost.")]
        public int count = 1;

        [Tooltip("Feedback shown to the student when this rule fails.")]
        public string message = "";
    }

    [Serializable]
    public class LessonDefinition
    {
        public string id = "lesson";
        public string title = "New Lesson";

        [TextArea(3, 8)]
        public string description = "";

        public string[] objectives = Array.Empty<string>();

        [TextArea(10, 30)]
        public string starterCode = "";

        [TextArea(10, 30)]
        public string solutionCode = "";

        public string[] hints = Array.Empty<string>();
        public LessonRule[] rules = Array.Empty<LessonRule>();

        [Tooltip("Optional per-lesson timeout hint. Server-side timeout still applies.")]
        public int timeLimitSeconds = 15;
    }

    /// <summary>
    /// A course is an ordered list of lessons. Instructors edit this through the
    /// PythonLab Lesson Builder window, not by writing code.
    /// </summary>
    [CreateAssetMenu(fileName = "PythonLabCourse", menuName = "PythonLab/Course")]
    public class PythonLabCourse : ScriptableObject
    {
        public string courseName = "New Course";
        public LessonDefinition[] lessons = Array.Empty<LessonDefinition>();

        [Header("Student experience")]
        [Tooltip("Allow students to reveal hints during a lesson.")]
        public bool allowHints = true;

        [Tooltip("Allow students to load the solution code into the editor.")]
        public bool allowSolutions = false;

        [Tooltip("Clear spawned simulation objects before each run.")]
        public bool resetWorldBeforeRun = true;

        [Tooltip("Require all grading rules to pass before the Next button is enabled.")]
        public bool requirePassToAdvance = false;
    }
}
