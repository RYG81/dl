# Example Course Sample

A ready-to-teach 5-lesson Python course.

## Import

1. Open **PythonLab → Lesson Builder**.
2. Click **Import JSON**.
3. Select `ExampleCourse.json`.
4. Save the imported course asset.
5. Assign the course to the `PythonLabStudentUI` component (or rebuild the example scene).

## Lessons

1. Hello, Python! — `print()`
2. Spawn a Robot — `sim.spawn()`
3. Move to the Goal — `sim.move()`
4. Loops: Build a Fleet — `for` loops
5. Sense, Think, Act — feedback loops with `sim.get_position()`

Each lesson includes objectives, starter code, a solution, hints, and no-code
auto-grading rules.
