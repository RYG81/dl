# PythonLab Classroom (Unity Package)

No-code Python teaching simulator for Unity.

## Install

Package Manager → **Add package from disk…** → select this folder's `package.json`.

Or reference it from a project manifest:

```json
{
  "dependencies": {
    "com.pythonlab.classroom": "file:../path/to/com.pythonlab.classroom"
  }
}
```

## Use

1. Run the companion server.
2. **PythonLab → Setup Wizard** → enter server URL/API key → **Build Example Scene**.
3. Press **Play**.
4. **PythonLab → Lesson Builder** to author lessons.

See `Documentation~/index.md` and the product `docs/` folder.
