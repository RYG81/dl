using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using PythonLab.Runtime;

namespace PythonLab.Editor
{
    /// <summary>
    /// No-code lesson authoring. Instructors create courses, lessons, objectives,
    /// starter code, hints, solutions, and grading rules without writing C#.
    /// Menu: PythonLab > Lesson Builder.
    /// </summary>
    public class LessonBuilderWindow : EditorWindow
    {
        private PythonLabCourse _course;
        private int _lessonIndex;
        private Vector2 _lessonListScroll;
        private Vector2 _editorScroll;
        private Vector2 _rulesScroll;
        private string _status = "";

        [MenuItem("PythonLab/Lesson Builder", priority = 1)]
        public static void Open()
        {
            var window = GetWindow<LessonBuilderWindow>("Lesson Builder");
            window.minSize = new Vector2(900, 600);
            window.Show();
        }

        private void OnGUI()
        {
            DrawToolbar();

            if (_course == null)
            {
                EditorGUILayout.HelpBox("Select or create a course asset to begin.", MessageType.Info);
                return;
            }

            EditorGUILayout.BeginHorizontal();
            DrawLessonList();
            DrawLessonEditor();
            EditorGUILayout.EndHorizontal();

            if (!string.IsNullOrEmpty(_status))
                EditorGUILayout.HelpBox(_status, MessageType.None);

            if (GUI.changed)
                MarkDirty();
        }

        private void DrawToolbar()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);

            var newCourse = (PythonLabCourse)EditorGUILayout.ObjectField(_course, typeof(PythonLabCourse), false, GUILayout.Width(260));
            if (newCourse != _course)
            {
                _course = newCourse;
                _lessonIndex = 0;
            }

            if (GUILayout.Button("New Course", EditorStyles.toolbarButton, GUILayout.Width(90)))
                CreateCourse();

            if (GUILayout.Button("Load Example", EditorStyles.toolbarButton, GUILayout.Width(95)))
                LoadExampleCourse();

            if (GUILayout.Button("Import JSON", EditorStyles.toolbarButton, GUILayout.Width(90)))
                ImportJson();

            if (GUILayout.Button("Export JSON", EditorStyles.toolbarButton, GUILayout.Width(90)))
                ExportJson();

            GUILayout.FlexibleSpace();

            if (GUILayout.Button("Validate", EditorStyles.toolbarButton, GUILayout.Width(75)))
                ValidateCourse();

            if (GUILayout.Button("Save", EditorStyles.toolbarButton, GUILayout.Width(60)))
                SaveCourse();

            EditorGUILayout.EndHorizontal();

            if (_course != null)
            {
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Course name", GUILayout.Width(90));
                _course.courseName = EditorGUILayout.TextField(_course.courseName);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                _course.allowHints = EditorGUILayout.ToggleLeft("Allow hints", _course.allowHints, GUILayout.Width(110));
                _course.allowSolutions = EditorGUILayout.ToggleLeft("Allow solutions", _course.allowSolutions, GUILayout.Width(130));
                _course.resetWorldBeforeRun = EditorGUILayout.ToggleLeft("Reset world before run", _course.resetWorldBeforeRun, GUILayout.Width(170));
                _course.requirePassToAdvance = EditorGUILayout.ToggleLeft("Require pass to advance", _course.requirePassToAdvance, GUILayout.Width(180));
                EditorGUILayout.EndHorizontal();
            }
        }

        private void DrawLessonList()
        {
            EditorGUILayout.BeginVertical(GUILayout.Width(240));
            EditorGUILayout.LabelField("Lessons", EditorStyles.boldLabel);

            _lessonListScroll = EditorGUILayout.BeginScrollView(_lessonListScroll);
            if (_course.lessons != null)
            {
                for (int i = 0; i < _course.lessons.Length; i++)
                {
                    bool selected = i == _lessonIndex;
                    var style = selected ? new GUIStyle(GUI.skin.button) { fontStyle = FontStyle.Bold } : GUI.skin.button;
                    string label = $"{i + 1}. {(_course.lessons[i].title ?? "Untitled")}";
                    if (GUILayout.Button(label, style))
                        _lessonIndex = i;
                }
            }
            EditorGUILayout.EndScrollView();

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("+ Add")) AddLesson();
            if (GUILayout.Button("Duplicate")) DuplicateLesson();
            if (GUILayout.Button("- Remove")) RemoveLesson();
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("↑ Up")) MoveLesson(-1);
            if (GUILayout.Button("↓ Down")) MoveLesson(1);
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.EndVertical();
        }

        private void DrawLessonEditor()
        {
            EditorGUILayout.BeginVertical();
            var lesson = CurrentLesson;
            if (lesson == null)
            {
                EditorGUILayout.HelpBox("Add a lesson to start authoring.", MessageType.Info);
                EditorGUILayout.EndVertical();
                return;
            }

            _editorScroll = EditorGUILayout.BeginScrollView(_editorScroll);

            EditorGUILayout.LabelField("Lesson details", EditorStyles.boldLabel);
            lesson.id = EditorGUILayout.TextField("Id", lesson.id);
            lesson.title = EditorGUILayout.TextField("Title", lesson.title);
            EditorGUILayout.LabelField("Description");
            lesson.description = EditorGUILayout.TextArea(lesson.description ?? "", GUILayout.MinHeight(60));
            lesson.timeLimitSeconds = EditorGUILayout.IntField("Time limit hint (s)", lesson.timeLimitSeconds);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Objectives (one per line)", EditorStyles.boldLabel);
            string objectives = string.Join("\n", lesson.objectives ?? Array.Empty<string>());
            objectives = EditorGUILayout.TextArea(objectives, GUILayout.MinHeight(60));
            lesson.objectives = SplitLines(objectives);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Starter code", EditorStyles.boldLabel);
            lesson.starterCode = EditorGUILayout.TextArea(lesson.starterCode ?? "", GUILayout.MinHeight(120));

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Solution code", EditorStyles.boldLabel);
            lesson.solutionCode = EditorGUILayout.TextArea(lesson.solutionCode ?? "", GUILayout.MinHeight(120));

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Hints (one per line)", EditorStyles.boldLabel);
            string hints = string.Join("\n", lesson.hints ?? Array.Empty<string>());
            hints = EditorGUILayout.TextArea(hints, GUILayout.MinHeight(60));
            lesson.hints = SplitLines(hints);

            EditorGUILayout.Space();
            DrawRules(lesson);

            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();
        }

        private void DrawRules(LessonDefinition lesson)
        {
            EditorGUILayout.LabelField("Auto-grading rules", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Rules are checked automatically after each run. Students see pass/fail feedback. " +
                "No code is required.", MessageType.None);

            if (GUILayout.Button("+ Add Rule"))
            {
                var list = new List<LessonRule>(lesson.rules ?? Array.Empty<LessonRule>());
                list.Add(new LessonRule());
                lesson.rules = list.ToArray();
            }

            _rulesScroll = EditorGUILayout.BeginScrollView(_rulesScroll, GUILayout.MinHeight(160));
            if (lesson.rules != null)
            {
                for (int i = 0; i < lesson.rules.Length; i++)
                {
                    var rule = lesson.rules[i];
                    EditorGUILayout.BeginVertical("box");
                    EditorGUILayout.BeginHorizontal();
                    EditorGUILayout.LabelField($"Rule {i + 1}", EditorStyles.boldLabel, GUILayout.Width(60));
                    rule.type = (LessonRuleType)EditorGUILayout.EnumPopup(rule.type);
                    if (GUILayout.Button("Remove", GUILayout.Width(70)))
                    {
                        var list = new List<LessonRule>(lesson.rules);
                        list.RemoveAt(i);
                        lesson.rules = list.ToArray();
                        EditorGUILayout.EndHorizontal();
                        EditorGUILayout.EndVertical();
                        break;
                    }
                    EditorGUILayout.EndHorizontal();

                    switch (rule.type)
                    {
                        case LessonRuleType.OutputContains:
                        case LessonRuleType.OutputRegex:
                            rule.text = EditorGUILayout.TextField(rule.type == LessonRuleType.OutputRegex ? "Regex pattern" : "Text", rule.text);
                            break;
                        case LessonRuleType.ObjectExists:
                        case LessonRuleType.ObjectMissing:
                        case LessonRuleType.ObjectPositionWithin:
                            rule.target = EditorGUILayout.TextField("Object id", rule.target);
                            if (rule.type == LessonRuleType.ObjectPositionWithin)
                            {
                                rule.position = EditorGUILayout.Vector3Field("Target position", rule.position);
                                rule.tolerance = EditorGUILayout.FloatField("Tolerance", rule.tolerance);
                            }
                            break;
                        case LessonRuleType.ObjectCountAtLeast:
                        case LessonRuleType.CommandCountAtMost:
                            rule.count = EditorGUILayout.IntField("Count", rule.count);
                            break;
                    }

                    rule.message = EditorGUILayout.TextField("Failure feedback", rule.message);
                    EditorGUILayout.EndVertical();
                }
            }
            EditorGUILayout.EndScrollView();
        }

        // ------------------------------------------------------------------
        // Actions
        // ------------------------------------------------------------------
        private LessonDefinition CurrentLesson =>
            _course != null && _course.lessons != null && _lessonIndex >= 0 && _lessonIndex < _course.lessons.Length
                ? _course.lessons[_lessonIndex]
                : null;

        private void CreateCourse()
        {
            string path = EditorUtility.SaveFilePanelInProject("Create Course", "NewCourse", "asset", "Create a new PythonLab course");
            if (string.IsNullOrEmpty(path)) return;
            var course = CreateInstance<PythonLabCourse>();
            course.courseName = "New Course";
            course.lessons = new[] { NewLesson() };
            AssetDatabase.CreateAsset(course, path);
            AssetDatabase.SaveAssets();
            _course = course;
            _lessonIndex = 0;
            _status = "Created course: " + path;
        }

        private void LoadExampleCourse()
        {
            string path = EditorUtility.SaveFilePanelInProject("Save Example Course", "ExampleCourse", "asset", "Save the example course");
            if (string.IsNullOrEmpty(path)) return;
            var course = ExampleCourseFactory.Create();
            AssetDatabase.CreateAsset(course, path);
            AssetDatabase.SaveAssets();
            _course = course;
            _lessonIndex = 0;
            _status = "Example course loaded.";
        }

        private void AddLesson()
        {
            var list = new List<LessonDefinition>(_course.lessons ?? Array.Empty<LessonDefinition>());
            list.Add(NewLesson());
            _course.lessons = list.ToArray();
            _lessonIndex = _course.lessons.Length - 1;
            MarkDirty();
        }

        private void DuplicateLesson()
        {
            var lesson = CurrentLesson;
            if (lesson == null) return;
            var json = JsonUtility.ToJson(lesson);
            var copy = JsonUtility.FromJson<LessonDefinition>(json);
            copy.id = lesson.id + "-copy";
            copy.title = lesson.title + " (Copy)";
            var list = new List<LessonDefinition>(_course.lessons);
            list.Insert(_lessonIndex + 1, copy);
            _course.lessons = list.ToArray();
            _lessonIndex++;
            MarkDirty();
        }

        private void RemoveLesson()
        {
            if (CurrentLesson == null) return;
            var list = new List<LessonDefinition>(_course.lessons);
            list.RemoveAt(_lessonIndex);
            _course.lessons = list.ToArray();
            _lessonIndex = Mathf.Clamp(_lessonIndex, 0, Mathf.Max(0, _course.lessons.Length - 1));
            MarkDirty();
        }

        private void MoveLesson(int direction)
        {
            if (_course.lessons == null) return;
            int newIndex = _lessonIndex + direction;
            if (newIndex < 0 || newIndex >= _course.lessons.Length) return;
            var list = new List<LessonDefinition>(_course.lessons);
            var item = list[_lessonIndex];
            list.RemoveAt(_lessonIndex);
            list.Insert(newIndex, item);
            _course.lessons = list.ToArray();
            _lessonIndex = newIndex;
            MarkDirty();
        }

        private void SaveCourse()
        {
            if (_course == null) return;
            MarkDirty();
            AssetDatabase.SaveAssets();
            _status = "Saved.";
        }

        private void ValidateCourse()
        {
            if (_course == null) return;
            var issues = new List<string>();
            var ids = new HashSet<string>();

            if (string.IsNullOrWhiteSpace(_course.courseName))
                issues.Add("Course name is empty.");
            if (_course.lessons == null || _course.lessons.Length == 0)
                issues.Add("Course has no lessons.");
            else
            {
                foreach (var lesson in _course.lessons)
                {
                    if (string.IsNullOrWhiteSpace(lesson.id))
                        issues.Add("A lesson has an empty id.");
                    else if (!ids.Add(lesson.id))
                        issues.Add($"Duplicate lesson id: {lesson.id}");

                    if (string.IsNullOrWhiteSpace(lesson.title))
                        issues.Add($"Lesson '{lesson.id}' has no title.");
                    if (string.IsNullOrWhiteSpace(lesson.starterCode))
                        issues.Add($"Lesson '{lesson.id}' has no starter code.");
                    if (lesson.rules == null || lesson.rules.Length == 0)
                        issues.Add($"Lesson '{lesson.id}' has no grading rules.");
                }
            }

            _status = issues.Count == 0
                ? "Validation passed. Course is ready to teach."
                : "Validation issues:\n• " + string.Join("\n• ", issues);
        }

        private void ExportJson()
        {
            if (_course == null) return;
            string path = EditorUtility.SaveFilePanel("Export Course JSON", "", _course.courseName + ".json", "json");
            if (string.IsNullOrEmpty(path)) return;
            File.WriteAllText(path, JsonUtility.ToJson(_course, true));
            _status = "Exported: " + path;
        }

        private void ImportJson()
        {
            string path = EditorUtility.OpenFilePanel("Import Course JSON", "", "json");
            if (string.IsNullOrEmpty(path)) return;
            string json = File.ReadAllText(path);
            var course = CreateInstance<PythonLabCourse>();
            JsonUtility.FromJsonOverwrite(json, course);
            string assetPath = EditorUtility.SaveFilePanelInProject("Save Imported Course", course.courseName, "asset", "Save imported course");
            if (string.IsNullOrEmpty(assetPath)) return;
            AssetDatabase.CreateAsset(course, assetPath);
            AssetDatabase.SaveAssets();
            _course = course;
            _lessonIndex = 0;
            _status = "Imported: " + path;
        }

        private void MarkDirty()
        {
            if (_course != null) EditorUtility.SetDirty(_course);
        }

        private static LessonDefinition NewLesson()
        {
            return new LessonDefinition
            {
                id = "new-lesson",
                title = "New Lesson",
                description = "Describe what the student will learn.",
                objectives = new[] { "Objective 1" },
                starterCode = "# Starter code\n",
                solutionCode = "# Solution code\n",
                hints = new[] { "First hint" },
                rules = new[] { new LessonRule { type = LessonRuleType.NoErrors } },
                timeLimitSeconds = 15
            };
        }

        private static string[] SplitLines(string text)
        {
            if (string.IsNullOrEmpty(text)) return Array.Empty<string>();
            return text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None)
                       .Select(l => l.Trim())
                       .Where(l => !string.IsNullOrEmpty(l))
                       .ToArray();
        }
    }
}
