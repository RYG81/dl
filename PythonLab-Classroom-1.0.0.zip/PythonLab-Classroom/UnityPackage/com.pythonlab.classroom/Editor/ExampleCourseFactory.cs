using UnityEngine;
using PythonLab.Runtime;

namespace PythonLab.Editor
{
    /// <summary>
    /// Builds a ready-to-teach example course. Used by the Setup Wizard and the
    /// Lesson Builder's "Load Example Course" button.
    /// </summary>
    public static class ExampleCourseFactory
    {
        public static PythonLabCourse Create()
        {
            var course = ScriptableObject.CreateInstance<PythonLabCourse>();
            course.courseName = "PythonLab Starter Course";
            course.allowHints = true;
            course.allowSolutions = false;
            course.resetWorldBeforeRun = true;
            course.requirePassToAdvance = false;

            course.lessons = new[]
            {
                Lesson1(),
                Lesson2(),
                Lesson3(),
                Lesson4(),
                Lesson5()
            };

            return course;
        }

        private static LessonDefinition Lesson1()
        {
            return new LessonDefinition
            {
                id = "hello-python",
                title = "Hello, Python!",
                description = "Welcome to PythonLab. Your first program will print a message to the console. " +
                              "The print() function sends text to the output panel.",
                objectives = new[]
                {
                    "Use print() to display a message.",
                    "Run your code and see the output in the console."
                },
                starterCode = "# Write your first Python program below.\n# Use print() to say hello.\n\n",
                solutionCode = "print(\"Hello, PythonLab!\")\n",
                hints = new[]
                {
                    "Try typing: print(\"Hello\")",
                    "Text must be inside quotes, like \"Hello\"."
                },
                rules = new[]
                {
                    new LessonRule { type = LessonRuleType.NoErrors, message = "Your code should run without errors." },
                    new LessonRule { type = LessonRuleType.OutputContains, text = "Hello", message = "Print a message containing the word Hello." }
                },
                timeLimitSeconds = 10
            };
        }

        private static LessonDefinition Lesson2()
        {
            return new LessonDefinition
            {
                id = "spawn-robot",
                title = "Spawn a Robot",
                description = "The sim object lets your Python code control the 3D world. " +
                              "Use sim.spawn() to create an object. Give it an id, a shape, and a position.",
                objectives = new[]
                {
                    "Create an object named robot.",
                    "Place it near the center of the world."
                },
                starterCode = "# Create a robot cube.\n# sim.spawn(id, shape, x, y, z, color)\n\n",
                solutionCode = "sim.spawn(\"robot\", \"cube\", x=0, y=0.5, z=0, color=\"cyan\")\nprint(\"Robot created:\", sim.objects())\n",
                hints = new[]
                {
                    "The first argument is the object's id, for example \"robot\".",
                    "Try sim.spawn(\"robot\", \"cube\", x=0, y=0.5, z=0, color=\"cyan\")"
                },
                rules = new[]
                {
                    new LessonRule { type = LessonRuleType.NoErrors },
                    new LessonRule { type = LessonRuleType.ObjectExists, target = "robot", message = "Create an object with the id 'robot'." },
                    new LessonRule { type = LessonRuleType.ObjectPositionWithin, target = "robot", position = new Vector3(0, 0.5f, 0), tolerance = 1f, message = "Place the robot near the center." }
                },
                timeLimitSeconds = 10
            };
        }

        private static LessonDefinition Lesson3()
        {
            return new LessonDefinition
            {
                id = "move-to-goal",
                title = "Move to the Goal",
                description = "Use sim.move() to change an object's position. You can move by a relative amount " +
                              "with dx/dy/dz, or set an absolute position with x/y/z. Move the robot to the goal.",
                objectives = new[]
                {
                    "Spawn a robot and a goal.",
                    "Move the robot close to the goal."
                },
                starterCode = "# The goal is at x=3, y=0.5, z=2.\n" +
                              "sim.spawn(\"goal\", \"sphere\", x=3, y=0.5, z=2, color=\"orange\")\n\n" +
                              "# 1. Spawn your robot\n" +
                              "# 2. Move it to the goal\n",
                solutionCode = "sim.spawn(\"goal\", \"sphere\", x=3, y=0.5, z=2, color=\"orange\")\n" +
                               "sim.spawn(\"robot\", \"cube\", x=0, y=0.5, z=0, color=\"cyan\")\n" +
                               "sim.move(\"robot\", x=3, y=0.5, z=2)\n" +
                               "print(\"Arrived:\", sim.get_position(\"robot\"))\n",
                hints = new[]
                {
                    "First spawn the robot with sim.spawn().",
                    "Use sim.move(\"robot\", x=3, y=0.5, z=2) to jump straight to the goal."
                },
                rules = new[]
                {
                    new LessonRule { type = LessonRuleType.NoErrors },
                    new LessonRule { type = LessonRuleType.ObjectExists, target = "robot" },
                    new LessonRule { type = LessonRuleType.ObjectPositionWithin, target = "robot", position = new Vector3(3, 0.5f, 2), tolerance = 0.5f, message = "Move the robot to the goal at (3, 0.5, 2)." }
                },
                timeLimitSeconds = 10
            };
        }

        private static LessonDefinition Lesson4()
        {
            return new LessonDefinition
            {
                id = "loop-fleet",
                title = "Loops: Build a Fleet",
                description = "Loops let you repeat actions. Use a for loop to spawn several objects without " +
                              "writing the same line over and over. Create at least five drones.",
                objectives = new[]
                {
                    "Use a for loop.",
                    "Create at least 5 objects.",
                    "Keep your simulation commands efficient."
                },
                starterCode = "# Create 5 drones with a loop.\n# Tip: use range(5) and an f-string for unique ids.\n\n",
                solutionCode = "for i in range(5):\n" +
                               "    sim.spawn(f\"drone_{i}\", \"sphere\", x=i * 1.2 - 2.4, y=0.5, z=0, color=\"lime\")\n" +
                               "print(\"Fleet:\", sim.objects())\n",
                hints = new[]
                {
                    "Start with: for i in range(5):",
                    "Inside the loop, call sim.spawn() with a unique id like f\"drone_{i}\"."
                },
                rules = new[]
                {
                    new LessonRule { type = LessonRuleType.NoErrors },
                    new LessonRule { type = LessonRuleType.ObjectCountAtLeast, count = 5, message = "Create at least 5 objects." },
                    new LessonRule { type = LessonRuleType.CommandCountAtMost, count = 12, message = "Use a loop instead of many separate commands." }
                },
                timeLimitSeconds = 15
            };
        }

        private static LessonDefinition Lesson5()
        {
            return new LessonDefinition
            {
                id = "sense-think-act",
                title = "Sense, Think, Act",
                description = "Robots read sensors, decide what to do, then act. Use sim.get_position() to read " +
                              "where objects are, compute the direction to the target, and move step by step.",
                objectives = new[]
                {
                    "Read positions with sim.get_position().",
                    "Use a loop to move toward the target.",
                    "Stop when you are close enough."
                },
                starterCode = "import math\n\n" +
                              "sim.spawn(\"target\", \"sphere\", x=4, y=0.5, z=3, color=\"orange\")\n" +
                              "sim.spawn(\"robot\", \"cube\", x=-4, y=0.5, z=-3, color=\"cyan\")\n\n" +
                              "# Move the robot toward the target, one step at a time.\n",
                solutionCode = "import math\n\n" +
                               "sim.spawn(\"target\", \"sphere\", x=4, y=0.5, z=3, color=\"orange\")\n" +
                               "sim.spawn(\"robot\", \"cube\", x=-4, y=0.5, z=-3, color=\"cyan\")\n\n" +
                               "for step in range(100):\n" +
                               "    r = sim.get_position(\"robot\")\n" +
                               "    t = sim.get_position(\"target\")\n" +
                               "    dx = t[\"x\"] - r[\"x\"]\n" +
                               "    dz = t[\"z\"] - r[\"z\"]\n" +
                               "    dist = math.hypot(dx, dz)\n" +
                               "    if dist < 0.3:\n" +
                               "        print(\"Arrived!\")\n" +
                               "        break\n" +
                               "    sim.move(\"robot\", dx=dx / dist * 0.5, dz=dz / dist * 0.5)\n",
                hints = new[]
                {
                    "Read both positions each loop: r = sim.get_position(\"robot\") and t = sim.get_position(\"target\").",
                    "Compute dx = t[\"x\"] - r[\"x\"] and dz = t[\"z\"] - r[\"z\"].",
                    "Use math.hypot(dx, dz) for distance, then move a fraction of the direction."
                },
                rules = new[]
                {
                    new LessonRule { type = LessonRuleType.NoErrors },
                    new LessonRule { type = LessonRuleType.ObjectPositionWithin, target = "robot", position = new Vector3(4, 0.5f, 3), tolerance = 0.6f, message = "Guide the robot to the target at (4, 0.5, 3)." }
                ],
                timeLimitSeconds = 20
            };
        }
    }
}
