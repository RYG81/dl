using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using PythonLab.Runtime;

namespace PythonLab.Editor
{
    /// <summary>
    /// One-click setup. Creates a ready-to-teach scene with camera, light, floor,
    /// server settings, a sample course, and the full student UI — no code needed.
    /// Menu: PythonLab > Setup Wizard.
    /// </summary>
    public class PythonLabSetupWizard : EditorWindow
    {
        private const string RootFolder = "Assets/PythonLab";
        private string _serverUrl = "http://127.0.0.1:8000";
        private string _apiKey = "";
        private Vector2 _scroll;

        [MenuItem("PythonLab/Setup Wizard", priority = 0)]
        public static void Open()
        {
            var window = GetWindow<PythonLabSetupWizard>("PythonLab Setup");
            window.minSize = new Vector2(460, 420);
            window.Show();
        }

        private void OnGUI()
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);

            EditorGUILayout.LabelField("PythonLab Classroom", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "This wizard builds a complete, ready-to-teach Unity scene. " +
                "Students get a code editor, console, objectives, hints, and auto-grading. " +
                "You only author lessons in the Lesson Builder.",
                MessageType.Info);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("1. Companion server", EditorStyles.boldLabel);
            _serverUrl = EditorGUILayout.TextField("Server URL", _serverUrl);
            _apiKey = EditorGUILayout.TextField("API key (optional for local demo)", _apiKey);
            EditorGUILayout.HelpBox(
                "Run the companion server from the Server/ folder, or deploy it with Docker. " +
                "See Documentation~/server-deployment.md.", MessageType.None);

            EditorGUILayout.Space();
            if (GUILayout.Button("Create / Update Settings Asset", GUILayout.Height(30)))
                CreateSettings();

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("2. Example course + scene", EditorStyles.boldLabel);
            if (GUILayout.Button("Build Example Scene (one click)", GUILayout.Height(34)))
                BuildExampleScene();

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("3. Author your lessons", EditorStyles.boldLabel);
            if (GUILayout.Button("Open Lesson Builder", GUILayout.Height(30)))
                LessonBuilderWindow.Open();

            EditorGUILayout.Space();
            EditorGUILayout.HelpBox(
                "After building the scene, press Play. Make sure the companion server is running. " +
                "Then open the Lesson Builder to replace the example lessons with your own.",
                MessageType.None);

            EditorGUILayout.EndScrollView();
        }

        private void CreateSettings()
        {
            EnsureFolder(RootFolder);
            string path = RootFolder + "/PythonLabSettings.asset";
            var settings = AssetDatabase.LoadAssetAtPath<PythonLabSettings>(path);
            if (settings == null)
            {
                settings = CreateInstance<PythonLabSettings>();
                AssetDatabase.CreateAsset(settings, path);
            }
            settings.serverUrl = _serverUrl;
            settings.apiKey = _apiKey;
            EditorUtility.SetDirty(settings);
            AssetDatabase.SaveAssets();
            Selection.activeObject = settings;
            EditorGUIUtility.PingObject(settings);
            Debug.Log("[PythonLab] Settings saved: " + path);
        }

        private void BuildExampleScene()
        {
            EnsureFolder(RootFolder);
            EnsureFolder(RootFolder + "/Scenes");

            // Settings
            string settingsPath = RootFolder + "/PythonLabSettings.asset";
            var settings = AssetDatabase.LoadAssetAtPath<PythonLabSettings>(settingsPath);
            if (settings == null)
            {
                settings = CreateInstance<PythonLabSettings>();
                AssetDatabase.CreateAsset(settings, settingsPath);
            }
            settings.serverUrl = _serverUrl;
            settings.apiKey = _apiKey;
            EditorUtility.SetDirty(settings);

            // Course
            string coursePath = RootFolder + "/ExampleCourse.asset";
            var course = AssetDatabase.LoadAssetAtPath<PythonLabCourse>(coursePath);
            if (course == null)
            {
                course = ExampleCourseFactory.Create();
                AssetDatabase.CreateAsset(course, coursePath);
            }

            // New scene
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // Camera
            var cameraGo = new GameObject("Main Camera");
            cameraGo.tag = "MainCamera";
            var cam = cameraGo.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.06f, 0.08f, 0.11f);
            cameraGo.transform.position = new Vector3(0, 9, -11);
            cameraGo.transform.rotation = Quaternion.Euler(45, 0, 0);
            cameraGo.AddComponent<AudioListener>();

            // Light
            var lightGo = new GameObject("Directional Light");
            var light = lightGo.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.1f;
            lightGo.transform.rotation = Quaternion.Euler(50, -30, 0);

            // Floor
            var floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
            floor.name = "Floor";
            floor.transform.localScale = new Vector3(3, 1, 3);
            EnsureFolder(RootFolder + "/Materials");
            string matPath = RootFolder + "/Materials/Floor.mat";
            var floorMat = AssetDatabase.LoadAssetAtPath<Material>(matPath);
            if (floorMat == null)
            {
                var shader = Shader.Find("Universal Render Pipeline/Lit");
                if (shader == null) shader = Shader.Find("Standard");
                if (shader == null) shader = Shader.Find("Diffuse");
                if (shader != null)
                {
                    floorMat = new Material(shader);
                    AssetDatabase.CreateAsset(floorMat, matPath);
                }
            }
            if (floorMat != null)
            {
                var floorColor = new Color(0.13f, 0.16f, 0.2f);
                if (floorMat.HasProperty("_BaseColor")) floorMat.SetColor("_BaseColor", floorColor);
                if (floorMat.HasProperty("_Color")) floorMat.SetColor("_Color", floorColor);
                floor.GetComponent<Renderer>().sharedMaterial = floorMat;
                EditorUtility.SetDirty(floorMat);
            }

            // PythonLab root
            var root = new GameObject("PythonLab");
            var executor = root.AddComponent<SimCommandExecutor>();
            var client = root.AddComponent<PythonLabClient>();
            var ui = root.AddComponent<PythonLabStudentUI>();
            client.settings = settings;
            client.commandExecutor = executor;
            ui.course = course;
            ui.client = client;
            ui.executor = executor;

            // Save scene
            string scenePath = RootFolder + "/Scenes/PythonLabExample.unity";
            EditorSceneManager.SaveScene(scene, scenePath);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            Selection.activeGameObject = root;
            EditorGUIUtility.PingObject(course);
            Debug.Log("[PythonLab] Example scene created: " + scenePath + "\nPress Play with the companion server running.");
        }

        [MenuItem("PythonLab/Build Example Scene", priority = 2)]
        public static void BuildExampleSceneMenu()
        {
            BuildExampleSceneWithDefaults();
        }

        /// <summary>
        /// Public entry point used by the Example Project bootstrapper and menu.
        /// Creates settings, example course, and a ready-to-teach scene.
        /// </summary>
        public static void BuildExampleSceneWithDefaults()
        {
            var wizard = CreateInstance<PythonLabSetupWizard>();
            wizard._serverUrl = "http://127.0.0.1:8000";
            wizard._apiKey = "";
            wizard.BuildExampleScene();
            DestroyImmediate(wizard);
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = Path.GetDirectoryName(path).Replace("\\", "/");
            string folder = Path.GetFileName(path);
            if (!AssetDatabase.IsValidFolder(parent)) EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, folder);
        }
    }
}
