# PythonLab Classroom

A no-code Python teaching simulator for Unity.

## Start here

1. Run the companion server (see the product `Server/` folder).
2. In Unity, open **PythonLab → Setup Wizard**.
3. Enter the server URL + API key, then click **Build Example Scene**.
4. Press **Play**.
5. Open **PythonLab → Lesson Builder** to author your own lessons.

## Instructor workflow (no code)

- Create courses and lessons visually.
- Set objectives, starter code, solution code, and hints.
- Define auto-grading rules with dropdowns and fields.
- Export/import courses as JSON to share or sell.

## Student experience

- Lesson picker with progress
- Objectives + description
- Python editor with Run / Stop / Hint / Solution
- Live console
- Per-rule pass/fail feedback
- Optional pass-to-advance gating

## The `sim` API

```python
sim.spawn(id, shape="cube", x=0, y=0, z=0, color=None, scale=1)
sim.move(id, x=None, y=None, z=None, dx=None, dy=None, dz=None)
sim.rotate(id, yaw=None, pitch=None, roll=None)
sim.get_position(id)
sim.objects()
sim.delete(id)
sim.set_color(id, color)
print(...)
```

## Requirements

- Unity 2021.3 or newer
- Companion server (Python 3.10+ / Docker)
- Newtonsoft JSON (auto-installed as a package dependency)

See the product `docs/` folder for deployment, lesson authoring, and packaging.
