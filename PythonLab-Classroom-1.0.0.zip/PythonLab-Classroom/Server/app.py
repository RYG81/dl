"""PythonLab Classroom companion server (product edition).

Adds API-key authentication, per-key quotas, and an admin API on top of the
same execution protocol used by the Unity package.

Run locally:
    uvicorn app:app --host 0.0.0.0 --port 8000

Environment variables:
    PYTHONLAB_ADMIN_TOKEN   Admin token for /admin endpoints (default: change-me)
    PYTHONLAB_REQUIRE_AUTH  "true" to require API keys (default: true)
    PYTHONLAB_DB_PATH       SQLite database path (default: pythonlab.db)
    PYTHONLAB_RUN_TIMEOUT   Per-run wall-clock timeout seconds (default: 15)
    PYTHONLAB_MAX_SESSIONS_PER_KEY  Concurrent sessions per key (default: 5)

IMPORTANT: The execution worker is still a local subprocess in this reference
server. For a commercial deployment, run the worker inside the hardened
container described in Dockerfile.worker and README.md.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
WORKER_PATH = BASE_DIR / "worker.py"
ADMIN_INDEX = BASE_DIR / "admin" / "index.html"

ADMIN_TOKEN = os.environ.get("PYTHONLAB_ADMIN_TOKEN", "change-me")
REQUIRE_AUTH = os.environ.get("PYTHONLAB_REQUIRE_AUTH", "true").lower() != "false"
DB_PATH = os.environ.get("PYTHONLAB_DB_PATH", str(BASE_DIR / "pythonlab.db"))
RUN_TIMEOUT_SECONDS = float(os.environ.get("PYTHONLAB_RUN_TIMEOUT", "15"))
MAX_SESSIONS_PER_KEY = int(os.environ.get("PYTHONLAB_MAX_SESSIONS_PER_KEY", "5"))
RUNNER = os.environ.get("PYTHONLAB_RUNNER", "local").lower()
WORKER_IMAGE = os.environ.get("PYTHONLAB_WORKER_IMAGE", "pythonlab-worker:latest")

MAX_CODE_CHARS = 20_000
MAX_EVENTS = 2_000
MAX_OUTPUT_CHARS = 20_000
MAX_COMMANDS_PER_RUN = 200
SESSION_TTL_SECONDS = 30 * 60
MAX_TOTAL_SESSIONS = 200

app = FastAPI(title="PythonLab Classroom Server", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------
def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def db_conn():
    """Connection that commits on success, rolls back on error, and always closes."""
    conn = db()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    with db_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS api_keys (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                key_hash TEXT NOT NULL,
                created REAL NOT NULL,
                revoked INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS run_log (
                id TEXT PRIMARY KEY,
                key_id TEXT,
                session_id TEXT,
                started REAL,
                finished REAL,
                status TEXT,
                code_chars INTEGER
            )
            """
        )


init_db()


def hash_key(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------
class ApiKeyContext(BaseModel):
    key_id: str
    name: str


def require_api_key(authorization: str | None = Header(default=None)) -> ApiKeyContext:
    if not REQUIRE_AUTH:
        return ApiKeyContext(key_id="anonymous", name="anonymous")

    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing Bearer API key")

    token = authorization[len("Bearer "):].strip()
    key_hash = hash_key(token)

    with db_conn() as conn:
        row = conn.execute(
            "SELECT id, name FROM api_keys WHERE key_hash = ? AND revoked = 0",
            (key_hash,),
        ).fetchone()

    if row is None:
        raise HTTPException(status_code=401, detail="Invalid or revoked API key")

    return ApiKeyContext(key_id=row["id"], name=row["name"])


def require_admin(x_admin_token: str | None = Header(default=None)) -> None:
    if not x_admin_token or not hmac.compare_digest(x_admin_token, ADMIN_TOKEN):
        raise HTTPException(status_code=401, detail="Invalid admin token")


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
class RunRequest(BaseModel):
    code: str = Field(..., max_length=MAX_CODE_CHARS)


class CommandResult(BaseModel):
    command_id: str
    ok: bool = True
    result: Any = None
    error: str | None = None


class CreateKeyRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=120)


# ---------------------------------------------------------------------------
# Sessions / execution (same protocol as the demo kit)
# ---------------------------------------------------------------------------
class Session:
    def __init__(self, key_id: str) -> None:
        self.id = uuid.uuid4().hex
        self.key_id = key_id
        self.created = time.time()
        self.last_seen = time.time()
        self.lock = threading.RLock()
        self.events: list[dict] = []
        self.seq = 0
        self.proc: subprocess.Popen | None = None
        self.running = False
        self.run_id: str | None = None
        self.deadline = 0.0
        self.pending_command: str | None = None
        self.output_chars = 0
        self.command_count = 0
        self.tempdir = tempfile.mkdtemp(prefix="pythonlab-")
        self.container_name = f"pythonlab-{self.id}" if RUNNER == "docker" else None

    def add_event(self, type_: str, **data) -> dict:
        with self.lock:
            self.seq += 1
            event = {"seq": self.seq, "type": type_, "ts": time.time(), **data}
            self.events.append(event)
            if len(self.events) > MAX_EVENTS:
                self.events = self.events[-MAX_EVENTS:]
            return event


sessions: dict[str, Session] = {}
sessions_lock = threading.RLock()


def _limit_resources() -> None:
    try:
        import resource

        os.setsid()
        cpu = int(RUN_TIMEOUT_SECONDS) + 2
        resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu + 1))
        resource.setrlimit(resource.RLIMIT_AS, (256 * 1024 * 1024, 256 * 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_FSIZE, (1024 * 1024, 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_NOFILE, (32, 32))
    except Exception:
        pass


def _kill_proc(proc: subprocess.Popen | None, container_name: str | None = None) -> None:
    if container_name:
        try:
            subprocess.run(
                ["docker", "rm", "-f", container_name],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
                check=False,
            )
        except Exception:
            pass
    if proc is None:
        return
    try:
        if proc.poll() is None:
            proc.kill()
    except Exception:
        pass


def _read_stdout(session: Session, proc: subprocess.Popen) -> None:
    try:
        for line in iter(proc.stdout.readline, ""):
            if not line:
                break
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                session.add_event("output", stream="stdout", text=line)
                continue

            kind = msg.get("type")
            if kind == "output":
                text = str(msg.get("text", ""))
                with session.lock:
                    session.output_chars += len(text)
                    over = session.output_chars > MAX_OUTPUT_CHARS
                if over:
                    session.add_event("error", message="Output limit exceeded")
                    with session.lock:
                        session.running = False
                        session.pending_command = None
                    _kill_proc(proc, session.container_name)
                    continue
                session.add_event("output", stream=msg.get("stream", "stdout"), text=text)

            elif kind == "command":
                with session.lock:
                    session.command_count += 1
                    over = session.command_count > MAX_COMMANDS_PER_RUN
                    if not over:
                        session.pending_command = msg.get("command_id")
                if over:
                    session.add_event("error", message="Simulation command limit exceeded")
                    with session.lock:
                        session.running = False
                        session.pending_command = None
                    _kill_proc(proc, session.container_name)
                    continue
                session.add_event(
                    "command",
                    command_id=msg.get("command_id"),
                    name=msg.get("name"),
                    args=msg.get("args", {}),
                )

            elif kind == "done":
                with session.lock:
                    session.running = False
                    session.pending_command = None
                session.add_event("done", run_id=msg.get("run_id"))
                _log_run_finish(session, "done")

            elif kind == "error":
                with session.lock:
                    session.running = False
                    session.pending_command = None
                session.add_event("error", message=msg.get("message", "Python error"))
                _log_run_finish(session, "error")

            elif kind == "ready":
                continue
    finally:
        with session.lock:
            if session.proc is proc and session.running:
                session.running = False
                session.pending_command = None
                session.add_event("error", message="Python worker exited unexpectedly")
                _log_run_finish(session, "worker-exited")


def _read_stderr(session: Session, proc: subprocess.Popen) -> None:
    try:
        for line in iter(proc.stderr.readline, ""):
            if not line:
                break
            session.add_event("output", stream="stderr", text=line)
    except Exception:
        pass


def _watchdog(session: Session, proc: subprocess.Popen, run_id: str) -> None:
    while True:
        time.sleep(0.05)
        with session.lock:
            if session.run_id != run_id or not session.running:
                return
            if time.time() > session.deadline:
                session.running = False
                session.pending_command = None
                session.add_event("error", message=f"Execution timed out after {RUN_TIMEOUT_SECONDS:.0f}s")
                _kill_proc(proc, session.container_name)
                _log_run_finish(session, "timeout")
                return
        if proc.poll() is not None:
            return


def _log_run_start(session: Session, code: str) -> None:
    try:
        with db_conn() as conn:
            conn.execute(
                "INSERT INTO run_log (id, key_id, session_id, started, status, code_chars) VALUES (?, ?, ?, ?, ?, ?)",
                (session.run_id, session.key_id, session.id, time.time(), "running", len(code)),
            )
    except Exception:
        pass


def _log_run_finish(session: Session, status: str) -> None:
    try:
        with db_conn() as conn:
            conn.execute(
                "UPDATE run_log SET finished = ?, status = ? WHERE id = ?",
                (time.time(), status, session.run_id),
            )
    except Exception:
        pass


def _start_run(session: Session, code: str) -> str:
    with session.lock:
        if session.running:
            raise HTTPException(status_code=409, detail="A run is already in progress")

        run_id = uuid.uuid4().hex
        session.running = True
        session.run_id = run_id
        session.deadline = time.time() + RUN_TIMEOUT_SECONDS
        session.pending_command = None
        session.output_chars = 0
        session.command_count = 0

        proc = session.proc
        reuse = proc is not None and proc.poll() is None

        if not reuse:
            env = {
                "PYTHONIOENCODING": "utf-8",
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONUNBUFFERED": "1",
            }

            if RUNNER == "docker":
                command = [
                    "docker", "run", "--rm", "-i",
                    "--name", session.container_name,
                    "--network", "none",
                    "--read-only",
                    "--tmpfs", "/tmp:rw,noexec,nosuid,size=16m",
                    "--memory", "256m",
                    "--memory-swap", "256m",
                    "--cpus", "0.5",
                    "--pids-limit", "64",
                    "--cap-drop", "ALL",
                    "--security-opt", "no-new-privileges",
                    "--user", "65534:65534",
                    WORKER_IMAGE,
                ]
                preexec = None
                cwd = None
            else:
                command = [sys.executable, "-u", str(WORKER_PATH)]
                preexec = _limit_resources if os.name == "posix" else None
                cwd = session.tempdir

            try:
                proc = subprocess.Popen(
                    command,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,
                    cwd=cwd,
                    env=env if RUNNER != "docker" else None,
                    preexec_fn=preexec,
                )
            except Exception as exc:
                session.running = False
                raise HTTPException(status_code=500, detail=f"Failed to start Python worker: {exc}")

            session.proc = proc
            threading.Thread(target=_read_stdout, args=(session, proc), daemon=True).start()
            threading.Thread(target=_read_stderr, args=(session, proc), daemon=True).start()

        session.add_event("started", run_id=run_id)
        _log_run_start(session, code)
        threading.Thread(target=_watchdog, args=(session, proc, run_id), daemon=True).start()

        try:
            proc.stdin.write(json.dumps({"type": "run", "run_id": run_id, "code": code}) + "\n")
            proc.stdin.flush()
        except Exception as exc:
            session.running = False
            session.pending_command = None
            _kill_proc(proc, session.container_name)
            session.proc = None
            raise HTTPException(status_code=500, detail=f"Failed to send code to worker: {exc}")

        return run_id


def _get_session(session_id: str, key: ApiKeyContext) -> Session:
    with sessions_lock:
        session = sessions.get(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if REQUIRE_AUTH and session.key_id != key.key_id:
        raise HTTPException(status_code=403, detail="Session belongs to another API key")
    session.last_seen = time.time()
    return session


def _cleanup_sessions() -> None:
    while True:
        time.sleep(30)
        now = time.time()
        with sessions_lock:
            stale = [s for s in sessions.values() if now - s.last_seen > SESSION_TTL_SECONDS]
            for session in stale:
                sessions.pop(session.id, None)
                with session.lock:
                    _kill_proc(session.proc, session.container_name)
                shutil.rmtree(session.tempdir, ignore_errors=True)


threading.Thread(target=_cleanup_sessions, daemon=True).start()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
@app.get("/")
def index():
    return {
        "service": "PythonLab Classroom Server",
        "version": "1.0.0",
        "auth_required": REQUIRE_AUTH,
        "admin_ui": "/admin",
    }


@app.get("/admin")
def admin_ui():
    if ADMIN_INDEX.exists():
        return FileResponse(ADMIN_INDEX)
    return {"ok": True, "message": "Admin UI not found"}


@app.get("/api/health")
def health():
    with sessions_lock:
        count = len(sessions)
    return {
        "ok": True,
        "sessions": count,
        "auth_required": REQUIRE_AUTH,
        "run_timeout_seconds": RUN_TIMEOUT_SECONDS,
        "runner": RUNNER,
        "secure_sandbox": RUNNER == "docker",
    }


@app.post("/api/sessions")
def create_session(key: ApiKeyContext = Depends(require_api_key)):
    with sessions_lock:
        if len(sessions) >= MAX_TOTAL_SESSIONS:
            raise HTTPException(status_code=429, detail="Server session limit reached")
        owned = sum(1 for s in sessions.values() if s.key_id == key.key_id)
        if owned >= MAX_SESSIONS_PER_KEY:
            raise HTTPException(status_code=429, detail="Per-key session limit reached")
        session = Session(key.key_id)
        sessions[session.id] = session
    return {"session_id": session.id}


@app.delete("/api/sessions/{session_id}")
def delete_session(session_id: str, key: ApiKeyContext = Depends(require_api_key)):
    session = _get_session(session_id, key)
    with sessions_lock:
        sessions.pop(session_id, None)
    with session.lock:
        session.running = False
        _kill_proc(session.proc, session.container_name)
    shutil.rmtree(session.tempdir, ignore_errors=True)
    return {"ok": True}


@app.post("/api/sessions/{session_id}/run")
def run_code(session_id: str, body: RunRequest, key: ApiKeyContext = Depends(require_api_key)):
    session = _get_session(session_id, key)
    run_id = _start_run(session, body.code)
    return {"run_id": run_id}


@app.post("/api/sessions/{session_id}/stop")
def stop_run(session_id: str, key: ApiKeyContext = Depends(require_api_key)):
    session = _get_session(session_id, key)
    with session.lock:
        if session.running:
            session.running = False
            session.pending_command = None
            session.add_event("stopped")
            _kill_proc(session.proc, session.container_name)
            session.proc = None
            _log_run_finish(session, "stopped")
    return {"ok": True}


@app.get("/api/sessions/{session_id}/events")
def get_events(session_id: str, after: int = Query(0, ge=0), key: ApiKeyContext = Depends(require_api_key)):
    session = _get_session(session_id, key)
    with session.lock:
        events = [event for event in session.events if event["seq"] > after]
        next_seq = session.seq
    return {"events": events, "next": next_seq}


@app.post("/api/sessions/{session_id}/command_result")
def command_result(session_id: str, body: CommandResult, key: ApiKeyContext = Depends(require_api_key)):
    session = _get_session(session_id, key)
    with session.lock:
        if not session.running or session.pending_command != body.command_id:
            raise HTTPException(status_code=409, detail="No matching pending command")
        proc = session.proc
        session.pending_command = None

    if proc is None or proc.poll() is not None or proc.stdin is None:
        raise HTTPException(status_code=409, detail="Python worker is not running")

    payload = {
        "type": "command_result",
        "command_id": body.command_id,
        "ok": body.ok,
        "result": body.result,
        "error": body.error,
    }
    try:
        proc.stdin.write(json.dumps(payload, ensure_ascii=False) + "\n")
        proc.stdin.flush()
    except Exception as exc:
        raise HTTPException(status_code=409, detail=f"Failed to deliver command result: {exc}")

    return {"ok": True}


# ---------------------------------------------------------------------------
# Admin API
# ---------------------------------------------------------------------------
@app.post("/admin/api/keys")
def create_key(body: CreateKeyRequest, _: None = Depends(require_admin)):
    key_id = uuid.uuid4().hex
    raw_key = "plab_" + secrets.token_urlsafe(32)
    with db_conn() as conn:
        conn.execute(
            "INSERT INTO api_keys (id, name, key_hash, created, revoked) VALUES (?, ?, ?, ?, 0)",
            (key_id, body.name, hash_key(raw_key), time.time()),
        )
    return {"id": key_id, "name": body.name, "key": raw_key}


@app.get("/admin/api/keys")
def list_keys(_: None = Depends(require_admin)):
    with db_conn() as conn:
        rows = conn.execute(
            "SELECT id, name, created, revoked FROM api_keys ORDER BY created DESC"
        ).fetchall()
    return {"keys": [dict(row) for row in rows]}


@app.post("/admin/api/keys/{key_id}/revoke")
def revoke_key(key_id: str, _: None = Depends(require_admin)):
    with db_conn() as conn:
        cur = conn.execute("UPDATE api_keys SET revoked = 1 WHERE id = ?", (key_id,))
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="Key not found")
    return {"ok": True}


@app.get("/admin/api/runs")
def list_runs(limit: int = Query(50, ge=1, le=500), _: None = Depends(require_admin)):
    with db_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM run_log ORDER BY started DESC LIMIT ?", (limit,)
        ).fetchall()
    return {"runs": [dict(row) for row in rows]}


@app.get("/admin/api/stats")
def stats(_: None = Depends(require_admin)):
    with sessions_lock:
        active = len(sessions)
        running = sum(1 for s in sessions.values() if s.running)
    with db_conn() as conn:
        total_keys = conn.execute("SELECT COUNT(*) c FROM api_keys WHERE revoked = 0").fetchone()["c"]
        total_runs = conn.execute("SELECT COUNT(*) c FROM run_log").fetchone()["c"]
    return {
        "active_sessions": active,
        "running_sessions": running,
        "active_keys": total_keys,
        "total_runs": total_runs,
    }
