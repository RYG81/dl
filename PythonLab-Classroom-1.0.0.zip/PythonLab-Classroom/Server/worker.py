"""Python worker for the Unity Python VM starter kit.

This process is spawned by app.py. It speaks a tiny JSON-lines protocol:

Parent -> worker:
  {"type": "run", "run_id": "...", "code": "..."}
  {"type": "command_result", "command_id": "...", "ok": true, "result": ...}

Worker -> parent:
  {"type": "output", "stream": "stdout", "text": "..."}
  {"type": "command", "command_id": "...", "name": "spawn", "args": {...}}
  {"type": "done", "run_id": "..."}
  {"type": "error", "message": "..."}

IMPORTANT: This file is a development/demo worker. It is NOT a security sandbox.
For untrusted student code, run this worker inside an OS-level sandbox/container
with no network, read-only filesystem, CPU/memory limits, and a non-root user.
"""

from __future__ import annotations

import builtins
import json
import sys
import traceback

MAX_OUTPUT_CHARS = 20_000
MAX_COMMANDS_PER_RUN = 200
MAX_TRACEBACK_CHARS = 8_000

# Keep the real stdout for the worker protocol. Student stdout/stderr are
# replaced below so print() becomes protocol events instead of corrupting JSON.
_PROTOCOL_OUT = sys.stdout


def emit(obj: dict) -> None:
    _PROTOCOL_OUT.write(json.dumps(obj, ensure_ascii=False) + "\n")
    _PROTOCOL_OUT.flush()


class OutputStream:
    """File-like object that converts student output into protocol events."""

    def __init__(self, stream: str) -> None:
        self.stream = stream
        self.chars = 0

    def reset(self) -> None:
        self.chars = 0

    def write(self, text: str) -> int:
        if not text:
            return 0
        self.chars += len(text)
        if self.chars > MAX_OUTPUT_CHARS:
            raise RuntimeError("Output limit exceeded")
        emit({"type": "output", "stream": self.stream, "text": text})
        return len(text)

    def writelines(self, lines) -> None:
        for line in lines:
            self.write(line)

    def flush(self) -> None:
        pass

    def isatty(self) -> bool:
        return False


class SimulationError(RuntimeError):
    pass


class Sim:
    """The `sim` object exposed to student code.

    Each method sends a command to Unity (or the browser demo) and blocks until
    the client posts the command result back through the server.
    """

    def __init__(self) -> None:
        self._commands = 0

    def reset(self) -> None:
        self._commands = 0

    def _call(self, name: str, **args):
        self._commands += 1
        if self._commands > MAX_COMMANDS_PER_RUN:
            raise SimulationError("Too many simulation commands in one run")

        command_id = f"c{self._commands}"
        emit({"type": "command", "command_id": command_id, "name": name, "args": args})

        line = sys.stdin.readline()
        if not line:
            raise SimulationError("Simulation bridge closed")

        try:
            msg = json.loads(line)
        except json.JSONDecodeError as exc:
            raise SimulationError(f"Bad command result from bridge: {exc}") from exc

        if msg.get("type") != "command_result" or msg.get("command_id") != command_id:
            raise SimulationError("Unexpected command result from bridge")

        if not msg.get("ok", False):
            raise SimulationError(str(msg.get("error") or "Simulation command failed"))

        return msg.get("result")

    # ---- Public student API -------------------------------------------------
    def spawn(self, id: str, shape: str = "cube", x: float = 0, y: float = 0, z: float = 0,
              color: str | None = None, scale: float = 1):
        """Create an object in the simulation and return its id."""
        return self._call("spawn", id=id, shape=shape, position={"x": x, "y": y, "z": z},
                          color=color, scale=scale)

    def move(self, id: str, x: float | None = None, y: float | None = None, z: float | None = None,
             dx: float | None = None, dy: float | None = None, dz: float | None = None):
        """Move an object. Use x/y/z for absolute position or dx/dy/dz for relative movement."""
        return self._call("move", id=id, x=x, y=y, z=z, dx=dx, dy=dy, dz=dz)

    def rotate(self, id: str, yaw: float | None = None, pitch: float | None = None, roll: float | None = None):
        """Set object rotation in degrees."""
        return self._call("rotate", id=id, yaw=yaw, pitch=pitch, roll=roll)

    def get_position(self, id: str):
        """Return {'x': ..., 'y': ..., 'z': ...} for an object."""
        return self._call("get_position", id=id)

    def objects(self):
        """Return a list of object ids currently in the simulation."""
        return self._call("objects")

    def delete(self, id: str):
        """Delete an object from the simulation."""
        return self._call("delete", id=id)

    def set_color(self, id: str, color: str):
        """Set an object's color using a name or hex string."""
        return self._call("set_color", id=id, color=color)


def _no_input(*args, **kwargs):
    raise RuntimeError("input() is not supported in the simulator. Use sim commands and print().")


def main() -> None:
    global _PROTOCOL_OUT
    _PROTOCOL_OUT = sys.stdout

    stdout = OutputStream("stdout")
    stderr = OutputStream("stderr")
    sys.stdout = stdout
    sys.stderr = stderr

    # Development convenience only. This is NOT a secure sandbox.
    student_builtins = dict(vars(builtins))
    student_builtins["input"] = _no_input

    sim = Sim()
    namespace = {
        "__name__": "__main__",
        "__builtins__": student_builtins,
        "sim": sim,
    }

    emit({"type": "ready"})

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue

        if msg.get("type") != "run":
            continue

        run_id = msg.get("run_id")
        code = msg.get("code", "")
        stdout.reset()
        stderr.reset()
        sim.reset()

        failed = False
        try:
            compiled = compile(code, "<student>", "exec")
            exec(compiled, namespace)
        except SystemExit:
            pass
        except BaseException:
            failed = True
            tb = traceback.format_exc(limit=8)
            if len(tb) > MAX_TRACEBACK_CHARS:
                tb = tb[:MAX_TRACEBACK_CHARS] + "\n... traceback truncated ..."
            emit({"type": "error", "message": tb})

        if not failed:
            emit({"type": "done", "run_id": run_id})


if __name__ == "__main__":
    main()
