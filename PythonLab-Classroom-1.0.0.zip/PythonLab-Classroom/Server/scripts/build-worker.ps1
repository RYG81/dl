$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
docker build -f Dockerfile.worker -t pythonlab-worker:latest .
Write-Host "Built pythonlab-worker:latest"
