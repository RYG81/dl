$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

if (-not (Test-Path ".venv")) {
    python -m venv .venv
}
. .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

if (-not $env:PYTHONLAB_ADMIN_TOKEN) { $env:PYTHONLAB_ADMIN_TOKEN = "change-me" }
if (-not $env:PYTHONLAB_REQUIRE_AUTH) { $env:PYTHONLAB_REQUIRE_AUTH = "true" }
if (-not $env:PYTHONLAB_RUNNER) { $env:PYTHONLAB_RUNNER = "local" }

Write-Host "Admin UI: http://127.0.0.1:8000/admin"
Write-Host "Admin token: $env:PYTHONLAB_ADMIN_TOKEN"
uvicorn app:app --host 0.0.0.0 --port 8000
