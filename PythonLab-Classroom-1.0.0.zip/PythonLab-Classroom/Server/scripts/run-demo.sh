#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
pip install -r requirements.txt

export PYTHONLAB_ADMIN_TOKEN="${PYTHONLAB_ADMIN_TOKEN:-pythonlab-admin}"
export PYTHONLAB_REQUIRE_AUTH=false
export PYTHONLAB_RUNNER=local
export PYTHONLAB_DB_PATH="${PYTHONLAB_DB_PATH:-./pythonlab-demo.db}"

echo "Demo server: http://127.0.0.1:8000"
echo "Admin UI:    http://127.0.0.1:8000/admin"
echo "Admin token: $PYTHONLAB_ADMIN_TOKEN"
echo "NOTE: demo mode disables API-key auth and uses the local runner."
uvicorn app:app --host 0.0.0.0 --port 8000
