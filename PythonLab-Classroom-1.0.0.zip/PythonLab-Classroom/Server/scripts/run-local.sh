#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
pip install -r requirements.txt

export PYTHONLAB_ADMIN_TOKEN="${PYTHONLAB_ADMIN_TOKEN:-change-me}"
export PYTHONLAB_REQUIRE_AUTH="${PYTHONLAB_REQUIRE_AUTH:-true}"
export PYTHONLAB_RUNNER="${PYTHONLAB_RUNNER:-local}"

echo "Admin UI: http://127.0.0.1:8000/admin"
echo "Admin token: $PYTHONLAB_ADMIN_TOKEN"
uvicorn app:app --host 0.0.0.0 --port 8000
