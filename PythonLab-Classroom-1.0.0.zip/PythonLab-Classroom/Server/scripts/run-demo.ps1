$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

if (-not (Test-Path ".venv")) {
    python -m venv .venv
}
. .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

if (-not $env:PYTHONLAB_ADMIN_TOKEN) { $env:PYTHONLAB_ADMIN_TOKEN = "pythonlab-admin" }
$env:PYTHONLAB_REQUIRE_AUTH = "false"
$env:PYTHONLAB_RUNNER = "local"
if (-not $env:PYTHONLAB_DB_PATH) { $env:PYTHONLAB_DB_PATH = "./pythonlab-demo.db" }

Write-Host "Demo server: http://127.0.0.1:8000"
Write-Host "Admin UI:    http://127.0.0.1:8000/admin"
Write-Host "Admin token: $env:PYTHONLAB_ADMIN_TOKEN"
Write-Host "NOTE: demo mode disables API-key auth and uses the local runner."
uvicorn app:app --host 0.0.0.0 --port 8000
