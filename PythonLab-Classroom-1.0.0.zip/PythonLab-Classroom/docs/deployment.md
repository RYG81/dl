# Deployment Guide

## 1. Local development (fastest)

```bash
cd Server
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

export PYTHONLAB_ADMIN_TOKEN="a-long-random-admin-token"
export PYTHONLAB_REQUIRE_AUTH=true
export PYTHONLAB_RUNNER=local
uvicorn app:app --host 0.0.0.0 --port 8000
```

Open `http://127.0.0.1:8000/admin` and create an API key for your Unity client.

> `local` mode is for development only. It is not a secure sandbox.

## 2. Docker worker (recommended production baseline)

Build the hardened worker image:

```bash
cd Server
bash scripts/build-worker.sh        # Windows: ./scripts/build-worker.ps1
```

Run the server with the Docker runner:

```bash
export PYTHONLAB_RUNNER=docker
export PYTHONLAB_WORKER_IMAGE=pythonlab-worker:latest
uvicorn app:app --host 0.0.0.0 --port 8000
```

Each session launches a worker container with:

- `--network none`
- `--read-only` + a small `tmpfs /tmp`
- `--memory 256m --memory-swap 256m`
- `--cpus 0.5`
- `--pids-limit 64`
- `--cap-drop ALL`
- `--security-opt no-new-privileges`
- `--user 65534:65534`

### Stronger isolation

For untrusted students at scale, run the worker image under:

- **gVisor (`runsc`)** — user-space kernel, strong syscall isolation.
- **Firecracker microVMs** — VM-level isolation per run/session.

The protocol is unchanged; only the runner changes.

## 3. Docker Compose

```bash
cd Server
export PYTHONLAB_ADMIN_TOKEN="a-long-random-admin-token"
export PYTHONLAB_RUNNER=docker
docker compose up --build
```

> When `PYTHONLAB_RUNNER=docker`, the server container mounts
> `/var/run/docker.sock` so it can launch worker containers. Treat this as a
> privileged service; run it on a trusted host and restrict network access.

## 4. HTTPS + CORS

For WebGL builds and production:

- Terminate TLS at a reverse proxy (Caddy / Nginx / cloud load balancer).
- Set the Unity `serverUrl` to `https://your-domain`.
- Lock down CORS to your web origin instead of `*`.

Example Caddyfile:

```
learn.example.com {
    reverse_proxy 127.0.0.1:8000
}
```

## 5. Environment variables

| Variable | Default | Meaning |
|---|---|---|
| `PYTHONLAB_ADMIN_TOKEN` | `change-me` | Admin UI/API token. **Change it.** |
| `PYTHONLAB_REQUIRE_AUTH` | `true` | Require Bearer API keys |
| `PYTHONLAB_DB_PATH` | `./pythonlab.db` | SQLite database |
| `PYTHONLAB_RUN_TIMEOUT` | `15` | Per-run wall-clock timeout (s) |
| `PYTHONLAB_MAX_SESSIONS_PER_KEY` | `5` | Concurrent sessions per key |
| `PYTHONLAB_RUNNER` | `local` | `local` or `docker` |
| `PYTHONLAB_WORKER_IMAGE` | `pythonlab-worker:latest` | Worker image |

## 6. Scaling notes

- The reference server keeps sessions in memory. For multiple server instances,
  move session/event state to Redis and use sticky sessions or a shared store.
- Put a job queue in front of workers for bursty classroom traffic.
- Add per-institution quotas and billing hooks around the admin API.

> The Docker runner uses the default Docker runtime; gVisor or Firecracker integration requires additional deployment work and independent security review. Container isolation is not a guarantee of safety.
