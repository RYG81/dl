# Lesson Authoring Guide (No Code)

Open **PythonLab → Lesson Builder** in Unity.

## Course settings

- **Course name** — shown in the student UI.
- **Allow hints** — students can reveal hints.
- **Allow solutions** — students can load the solution into the editor.
- **Reset world before run** — clears spawned objects before each run.
- **Require pass to advance** — Next is disabled until all rules pass.

## Lesson fields

- **Id** — stable identifier used for progress saving.
- **Title** — shown in the lesson picker.
- **Description** — what the student will learn.
- **Objectives** — one per line; shown as a checklist.
- **Starter code** — the code the student begins with.
- **Solution code** — optional reference solution.
- **Hints** — one per line; revealed in order.
- **Time limit hint** — guidance; the server timeout still applies.

## Auto-grading rules

Add rules with the **+ Add Rule** button. Each rule has a type and fields:

| Rule | What it checks |
|---|---|
| `RunCompleted` | The run finished |
| `NoErrors` | No Python/runtime error occurred |
| `OutputContains` | Console output contains text |
| `OutputRegex` | Console output matches a regex |
| `ObjectExists` | An object with the given id exists |
| `ObjectMissing` | An object with the given id was deleted |
| `ObjectPositionWithin` | Object is within tolerance of a target position |
| `ObjectCountAtLeast` | At least N objects exist |
| `CommandCountAtMost` | At most N sim commands were used (encourages loops) |

Each rule can have custom **failure feedback** shown to the student.

## The `sim` API available to students

```python
sim.spawn(id, shape="cube", x=0, y=0, z=0, color=None, scale=1)
sim.move(id, x=None, y=None, z=None, dx=None, dy=None, dz=None)
sim.rotate(id, yaw=None, pitch=None, roll=None)
sim.get_position(id)        # -> {"x":..., "y":..., "z":...}
sim.objects()               # -> [ids]
sim.delete(id)
sim.set_color(id, color)
print(...)                  # streams to the console
```

## Example rule set

Lesson: "Move the robot to the goal."

- `NoErrors`
- `ObjectExists` → `robot`
- `ObjectPositionWithin` → `robot`, target `(3, 0.5, 2)`, tolerance `0.5`

## Import / export

- **Export JSON** — share or sell a course pack.
- **Import JSON** — load a course pack into a Unity course asset.

## Tips

- Start with `OutputContains` lessons, then move to object/position lessons.
- Use `CommandCountAtMost` to encourage loops instead of repeated commands.
- Keep starter code short; put the challenge in the objectives.
- Write failure feedback that teaches, not just "wrong".
