# Sales & Packaging Checklist

## Product positioning

**PythonLab Classroom** — "Teach Python with a live 3D simulator. No code needed
to author lessons."

Buyers:

- Coding bootcamps and schools
- STEM / robotics teachers
- Corporate training teams
- Ed-tech startups building interactive courses

Value proposition:

- Students learn by *controlling a simulation*, not just printing text.
- Instructors author lessons visually: objectives, starter code, hints,
  solutions, and auto-grading rules.
- Real CPython execution, cross-platform Unity client (desktop/mobile/WebGL).
- Ready-made example course included.

## What to ship

1. **Unity package** (`com.pythonlab.classroom`) via UPM or `.unitypackage`.
2. **Companion server** (Docker images + compose).
3. **Example course** (importable JSON + Unity course asset).
4. **Documentation** (setup, lesson authoring, deployment).
5. **License / EULA** and support channel.

## Pricing models

- **One-time asset license** (Unity Asset Store style): package + server source.
- **Per-seat / per-classroom subscription**: hosted server + admin dashboard.
- **Institution license**: unlimited seats + priority support + custom sim API.
- **Course packs**: sell additional lesson packs as JSON imports.

## Go-to-market checklist

- [ ] Replace placeholder branding, author name, and support URL.
- [ ] Add your EULA / license file.
- [ ] Record a 60–90s demo video (setup → lesson → student run → grading).
- [ ] Capture screenshots: Setup Wizard, Lesson Builder, student UI, admin UI.
- [ ] Write a store description using the docs in this folder.
- [ ] Test on Unity 2021.3, 2022.3, and Unity 6 (or your supported versions).
- [ ] Test desktop + WebGL builds.
- [ ] Run the server in Docker/gVisor for any public demo.
- [ ] Set up HTTPS, CORS, auth, and quotas.
- [ ] Add analytics/error reporting if desired.
- [ ] Prepare a refund/support policy.

## Asset Store description (draft)

> PythonLab Classroom turns Unity into an interactive Python teaching simulator.
> Instructors create lessons with a visual Lesson Builder — objectives, starter
> code, hints, solutions, and no-code auto-grading rules. Students write real
> Python that spawns and moves objects, reads positions, and solves challenges
> in a 3D world. Includes a complete example course, a student UI with progress
> tracking, and a companion execution server with an admin dashboard, API keys,
> quotas, and Docker-based sandboxing.

## Keywords

Python, education, coding, simulator, classroom, no-code, lesson builder,
auto-grading, STEM, robotics, training, interactive learning
