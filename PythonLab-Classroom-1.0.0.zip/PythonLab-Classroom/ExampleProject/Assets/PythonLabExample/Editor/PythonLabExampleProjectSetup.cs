#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using PythonLab.Editor;

/// <summary>
/// Example-project bootstrapper. On first open, offers to create the complete
/// example scene automatically. The instructor does not need to write code.
/// </summary>
[InitializeOnLoad]
public static class PythonLabExampleProjectSetup
{
    private const string DoneKey = "PythonLab.ExampleProjectSetupDone";
    private const string ScenePath = "Assets/PythonLab/Scenes/PythonLabExample.unity";

    static PythonLabExampleProjectSetup()
    {
        EditorApplication.delayCall += TryCreateExampleScene;
    }

    private static void TryCreateExampleScene()
    {
        if (EditorPrefs.GetBool(DoneKey, false))
            return;

        EditorPrefs.SetBool(DoneKey, true);

        if (File.Exists(ScenePath))
        {
            EditorSceneManager.OpenScene(ScenePath);
            return;
        }

        bool create = EditorUtility.DisplayDialog(
            "PythonLab Classroom",
            "Welcome to the PythonLab example project.\n\n" +
            "Create the ready-to-teach example scene now?\n\n" +
            "You can also do this later from PythonLab > Setup Wizard.",
            "Create Example Scene",
            "Later");

        if (!create)
            return;

        PythonLabSetupWizard.BuildExampleSceneWithDefaults();

        if (File.Exists(ScenePath))
            EditorSceneManager.OpenScene(ScenePath);
    }
}
#endif
