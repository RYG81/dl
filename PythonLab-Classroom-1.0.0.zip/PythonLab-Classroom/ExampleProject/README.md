# PythonLab Classroom — Example Unity Project

This is a ready-to-open Unity project that demonstrates the full product.

## Open it

1. Install Unity **2022.3 LTS** (or newer LTS).
2. Open this folder (`ExampleProject/`) in Unity Hub.
3. On first load, accept **Create Example Scene**.
   - If you missed the dialog: **PythonLab → Build Example Scene**.
4. Start the companion server (see below).
5. Press **Play**.

You now have:

- A 3D floor/world
- A student code editor
- Console output
- Objectives, hints, and solution reveal
- Auto-grading
- A 5-lesson example course

## Start the companion server

From the repository root:

```bash
cd Server
./scripts/run-demo.sh        # Windows: ./scripts/run-demo.ps1
```

The demo server runs at `http://127.0.0.1:8000`.

For the admin dashboard, open `http://127.0.0.1:8000/admin`.
Demo admin token: `pythonlab-admin`.

> The demo server disables API-key auth for convenience. For production, enable
> auth and use the Docker runner. See `../docs/deployment.md`.

## Author your own lessons

Open **PythonLab → Lesson Builder**. Select the example course asset, edit
lessons, objectives, starter code, hints, solutions, and grading rules. No C# or
Python coding is required to author lessons.

## Project layout

```
ExampleProject/
├── Assets/PythonLabExample/Editor/   # First-run scene bootstrapper
├── Packages/manifest.json            # References the local PythonLab package
└── ProjectSettings/ProjectVersion.txt
```

The package itself lives at `../UnityPackage/com.pythonlab.classroom`.
