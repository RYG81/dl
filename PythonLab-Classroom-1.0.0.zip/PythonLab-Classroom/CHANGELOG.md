# Changelog

## 1.0.0

Initial product release.

### Unity package
- No-code **Setup Wizard** (one-click example scene).
- No-code **Lesson Builder** (courses, lessons, objectives, starter/solution code,
  hints, and dropdown-based auto-grading rules).
- Runtime **student UI**: lesson picker, code editor, console, Run/Stop/Hint/
  Solution, per-rule grading feedback, progress persistence, pass-to-advance.
- **Sim command executor**: spawn, move, rotate, get_position, objects, delete,
  set_color.
- **Lesson validator** with 9 rule types.
- Course **JSON import/export**.
- Example course (5 lessons) + importable sample.

### Companion server
- Session/run/event protocol shared by Unity and browser clients.
- **API-key auth**, per-key quotas, cross-key isolation.
- **Admin dashboard**: create/revoke keys, stats, recent runs.
- **Local** and **Docker** execution runners.
- Hardened worker Dockerfile (no network, read-only, non-root, resource limits).
- Docker Compose + cross-platform run scripts.

### Example project
- Ready-to-open Unity project with first-run scene bootstrapper.

### Docs
- Deployment, lesson authoring, sales & packaging guides.
