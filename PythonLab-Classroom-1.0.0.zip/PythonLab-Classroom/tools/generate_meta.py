#!/usr/bin/env python3
"""Generate Unity .meta files with stable GUIDs for the package + example project.

Unity auto-generates .meta files on import, but shipping them keeps GUIDs stable
across machines — important for a sellable package and shared scenes.
"""
import os
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

TARGETS = [
    ROOT / "UnityPackage" / "com.pythonlab.classroom",
    ROOT / "ExampleProject" / "Assets",
]

FOLDER_META = """fileFormatVersion: 2
guid: {guid}
folderAsset: yes
DefaultImporter:
  externalObjects: {{}}
  userData: 
  assetBundleName: 
  assetBundleVariant: 
"""

MONO_META = """fileFormatVersion: 2
guid: {guid}
MonoImporter:
  externalObjects: {{}}
  serializedVersion: 2
  defaultReferences: []
  executionOrder: 0
  icon: {{instanceID: 0}}
  userData: 
  assetBundleName: 
  assetBundleVariant: 
"""

ASMDEF_META = """fileFormatVersion: 2
guid: {guid}
AssemblyDefinitionImporter:
  externalObjects: {{}}
  userData: 
  assetBundleName: 
  assetBundleVariant: 
"""

TEXT_META = """fileFormatVersion: 2
guid: {guid}
TextScriptImporter:
  externalObjects: {{}}
  userData: 
  assetBundleName: 
  assetBundleVariant: 
"""


def guid_for(rel: str) -> str:
    return uuid.uuid5(uuid.NAMESPACE_URL, "pythonlab://" + rel.replace(os.sep, "/")).hex


def meta_for(path: Path) -> str:
    rel = str(path.relative_to(ROOT))
    g = guid_for(rel)
    if path.is_dir():
        return FOLDER_META.format(guid=g)
    suffix = path.suffix.lower()
    if suffix == ".cs":
        return MONO_META.format(guid=g)
    if suffix == ".asmdef":
        return ASMDEF_META.format(guid=g)
    return TEXT_META.format(guid=g)


def main() -> None:
    count = 0
    for target in TARGETS:
        if not target.exists():
            continue
        # Ensure the target root itself has a meta (as a folder inside its parent).
        for dirpath, dirnames, filenames in os.walk(target):
            dirnames[:] = [d for d in dirnames if d not in (".git",)]
            d = Path(dirpath)
            meta = d.with_name(d.name + ".meta")
            if not meta.exists():
                meta.write_text(meta_for(d))
                count += 1
            for fn in filenames:
                if fn.endswith(".meta"):
                    continue
                f = d / fn
                m = Path(str(f) + ".meta")
                if not m.exists():
                    m.write_text(meta_for(f))
                    count += 1
    print(f"Generated {count} .meta files")


if __name__ == "__main__":
    main()
