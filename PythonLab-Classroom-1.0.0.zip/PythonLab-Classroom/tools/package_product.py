#!/usr/bin/env python3
"""Package PythonLab Classroom into a distributable .zip.

Produces:
  dist/PythonLab-Classroom-<version>.zip

The zip contains the UPM package, example project, server, docs, and tools.
For Unity Asset Store, you can also export a .unitypackage from inside Unity
(Assets > Export Package) — see docs/sales-and-packaging.md.
"""
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PKG = ROOT / "UnityPackage" / "com.pythonlab.classroom" / "package.json"


def version() -> str:
    try:
        return json.loads(PKG.read_text()).get("version", "1.0.0")
    except Exception:
        return "1.0.0"


def main() -> None:
    v = version()
    # Write beside the product folder so the artifact is easy to find/download.
    out = ROOT.parent / f"PythonLab-Classroom-{v}.zip"

    skip_dirs = {".git", ".venv", "__pycache__", "dist", "node_modules", ".idea"}
    skip_ext = {".pyc", ".db"}

    count = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(ROOT.rglob("*")):
            rel = path.relative_to(ROOT)
            parts = set(rel.parts)
            if parts & skip_dirs:
                continue
            if path.is_dir():
                continue
            if path.suffix in skip_ext:
                continue
            if path.name.endswith(".meta") and path.parent.name == "dist":
                continue
            z.write(path, Path("PythonLab-Classroom") / rel)
            count += 1

    print(f"Wrote {out} ({count} files, {out.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
