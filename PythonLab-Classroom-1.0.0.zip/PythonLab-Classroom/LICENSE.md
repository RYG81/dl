# License

Copyright (c) 2026 PythonLab Classroom contributors. All rights reserved.

This is a commercial product template. Replace this file with your chosen
license/EULA before selling or distributing.

Suggested options:

- **Commercial EULA** — per-seat or per-institution license, no redistribution.
- **Source-available commercial** — customers may modify for internal use.
- **MIT/Apache-2.0** — if you want a permissive open-source model instead.

Third-party components retain their own licenses:

- Newtonsoft.Json (MIT)
- FastAPI (MIT), Uvicorn (BSD-3-Clause), Pydantic (MIT)
- Unity engine and Unity packages are governed by Unity's terms.

> This file is a placeholder and is not legal advice. Have your EULA reviewed
> before commercial release.
