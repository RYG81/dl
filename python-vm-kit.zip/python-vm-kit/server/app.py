"""FastAPI bridge between Unity and a Python worker.

Development/demo server only. Do not expose this local subprocess runner to
untrusted students. See README.md for the production sandbox architecture.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
WORKER_PATH = BASE_DIR / "worker.py"
DEMO_INDEX = BASE_DIR.parent / "demo" / "index.html"

MAX_SESSIONS = 50
MAX_CODE_CHARS = 20_000
MAX_EVENTS = 2_000
MAX_OUTPUT_CHARS = 20_000
MAX_COMMANDS_PER_RUN = 200
RUN_TIMEOUT_SECONDS = 15.0
SESSION_TTL_SECONDS = 30 * 60

app = FastAPI(title="Unity Python VM Bridge", version="0.1.0")

# Demo-friendly CORS. Lock this down in production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


class RunRequest(BaseModel):
    code: str = Field(..., max_length=MAX_CODE_CHARS)


class CommandResult(BaseModel):
    command_id: str
    ok: bool = True
    result: Any = None
    error: str | None = None


class Session:
    def __init__(self) -> None:
        self.id = uuid.uuid4().hex
        self.created = time.time()
        self.last_seen = time.time()
        self.lock = threading.RLock()
        self.events: list[dict] = []
        self.seq = 0
        self.proc: subprocess.Popen | None = None
        self.running = False
        self.run_id: str | None = None
        self.deadline = 0.0
        self.pending_command: str | None = None
        self.output_chars = 0
        self.command_count = 0
        self.tempdir = tempfile.mkdtemp(prefix="unity-python-vm-")

    def add_event(self, type_: str, **data) -> dict:
        with self.lock:
            self.seq += 1
            event = {"seq": self.seq, "type": type_, "ts": time.time(), **data}
            self.events.append(event)
            if len(self.events) > MAX_EVENTS:
                self.events = self.events[-MAX_EVENTS:]
            return event


sessions: dict[str, Session] = {}
sessions_lock = threading.RLock()


def _limit_resources() -> None:
    """Best-effort Linux resource limits for the demo runner.

    This is NOT a security boundary. Use containers/gVisor/Firecracker/etc.
    for untrusted code.
    """
    try:
        import resource

        os.setsid()
        cpu = int(RUN_TIMEOUT_SECONDS) + 2
        resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu + 1))
        resource.setrlimit(resource.RLIMIT_AS, (256 * 1024 * 1024, 256 * 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_FSIZE, (1024 * 1024, 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_NOFILE, (32, 32))
    except Exception:
        pass


def _kill_proc(proc: subprocess.Popen | None) -> None:
    if proc is None:
        return
    try:
        if proc.poll() is None:
            proc.kill()
    except Exception:
        pass


def _read_stdout(session: Session, proc: subprocess.Popen) -> None:
    try:
        for line in iter(proc.stdout.readline, ""):
            if not line:
                break
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                session.add_event("output", stream="stdout", text=line)
                continue

            kind = msg.get("type")
            if kind == "output":
                text = str(msg.get("text", ""))
                with session.lock:
                    session.output_chars += len(text)
                    over = session.output_chars > MAX_OUTPUT_CHARS
                if over:
                    session.add_event("error", message="Output limit exceeded")
                    with session.lock:
                        session.running = False
                        session.pending_command = None
                    _kill_proc(proc)
                    continue
                session.add_event("output", stream=msg.get("stream", "stdout"), text=text)

            elif kind == "command":
                with session.lock:
                    session.command_count += 1
                    over = session.command_count > MAX_COMMANDS_PER_RUN
                    if not over:
                        session.pending_command = msg.get("command_id")
                if over:
                    session.add_event("error", message="Simulation command limit exceeded")
                    with session.lock:
                        session.running = False
                        session.pending_command = None
                    _kill_proc(proc)
                    continue
                session.add_event(
                    "command",
                    command_id=msg.get("command_id"),
                    name=msg.get("name"),
                    args=msg.get("args", {}),
                )

            elif kind == "done":
                with session.lock:
                    session.running = False
                    session.pending_command = None
                session.add_event("done", run_id=msg.get("run_id"))

            elif kind == "error":
                with session.lock:
                    session.running = False
                    session.pending_command = None
                session.add_event("error", message=msg.get("message", "Python error"))

            elif kind == "ready":
                continue
    finally:
        with session.lock:
            if session.proc is proc and session.running:
                session.running = False
                session.pending_command = None
                session.add_event("error", message="Python worker exited unexpectedly")


def _read_stderr(session: Session, proc: subprocess.Popen) -> None:
    try:
        for line in iter(proc.stderr.readline, ""):
            if not line:
                break
            session.add_event("output", stream="stderr", text=line)
    except Exception:
        pass


def _watchdog(session: Session, proc: subprocess.Popen, run_id: str) -> None:
    while True:
        time.sleep(0.05)
        with session.lock:
            if session.run_id != run_id or not session.running:
                return
            if time.time() > session.deadline:
                session.running = False
                session.pending_command = None
                session.add_event("error", message=f"Execution timed out after {RUN_TIMEOUT_SECONDS:.0f}s")
                _kill_proc(proc)
                return
        if proc.poll() is not None:
            return


def _start_run(session: Session, code: str) -> str:
    with session.lock:
        if session.running:
            raise HTTPException(status_code=409, detail="A run is already in progress")

        run_id = uuid.uuid4().hex
        session.running = True
        session.run_id = run_id
        session.deadline = time.time() + RUN_TIMEOUT_SECONDS
        session.pending_command = None
        session.output_chars = 0
        session.command_count = 0

        # Reuse a live worker so Python state can persist across runs in the
        # same session. If the previous worker died/timed out, start a new one.
        proc = session.proc
        reuse = proc is not None and proc.poll() is None

        if not reuse:
            env = {
                "PYTHONIOENCODING": "utf-8",
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONUNBUFFERED": "1",
            }
            preexec = _limit_resources if os.name == "posix" else None
            try:
                proc = subprocess.Popen(
                    [sys.executable, "-u", str(WORKER_PATH)],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,
                    cwd=session.tempdir,
                    env=env,
                    preexec_fn=preexec,
                )
            except Exception as exc:
                session.running = False
                raise HTTPException(status_code=500, detail=f"Failed to start Python worker: {exc}")

            session.proc = proc
            threading.Thread(target=_read_stdout, args=(session, proc), daemon=True).start()
            threading.Thread(target=_read_stderr, args=(session, proc), daemon=True).start()

        session.add_event("started", run_id=run_id)
        threading.Thread(target=_watchdog, args=(session, proc, run_id), daemon=True).start()

        try:
            proc.stdin.write(json.dumps({"type": "run", "run_id": run_id, "code": code}) + "\n")
            proc.stdin.flush()
        except Exception as exc:
            session.running = False
            session.pending_command = None
            _kill_proc(proc)
            session.proc = None
            raise HTTPException(status_code=500, detail=f"Failed to send code to worker: {exc}")

        return run_id


def _get_session(session_id: str) -> Session:
    with sessions_lock:
        session = sessions.get(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    session.last_seen = time.time()
    return session


def _cleanup_sessions() -> None:
    while True:
        time.sleep(30)
        now = time.time()
        with sessions_lock:
            stale = [s for s in sessions.values() if now - s.last_seen > SESSION_TTL_SECONDS]
            for session in stale:
                sessions.pop(session.id, None)
                with session.lock:
                    _kill_proc(session.proc)
                shutil.rmtree(session.tempdir, ignore_errors=True)


threading.Thread(target=_cleanup_sessions, daemon=True).start()


@app.get("/")
def index():
    if DEMO_INDEX.exists():
        return FileResponse(DEMO_INDEX)
    return {"ok": True, "service": "unity-python-vm-bridge"}


@app.get("/api/health")
def health():
    with sessions_lock:
        count = len(sessions)
    return {
        "ok": True,
        "sessions": count,
        "mode": "local-demo",
        "secure_sandbox": False,
        "run_timeout_seconds": RUN_TIMEOUT_SECONDS,
    }


@app.post("/api/sessions")
def create_session():
    with sessions_lock:
        if len(sessions) >= MAX_SESSIONS:
            raise HTTPException(status_code=429, detail="Too many sessions")
        session = Session()
        sessions[session.id] = session
    return {"session_id": session.id}


@app.delete("/api/sessions/{session_id}")
def delete_session(session_id: str):
    with sessions_lock:
        session = sessions.pop(session_id, None)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    with session.lock:
        session.running = False
        _kill_proc(session.proc)
    shutil.rmtree(session.tempdir, ignore_errors=True)
    return {"ok": True}


@app.post("/api/sessions/{session_id}/run")
def run_code(session_id: str, body: RunRequest):
    session = _get_session(session_id)
    run_id = _start_run(session, body.code)
    return {"run_id": run_id}


@app.post("/api/sessions/{session_id}/stop")
def stop_run(session_id: str):
    session = _get_session(session_id)
    with session.lock:
        if session.running:
            session.running = False
            session.pending_command = None
            session.add_event("stopped")
            _kill_proc(session.proc)
            session.proc = None
    return {"ok": True}


@app.get("/api/sessions/{session_id}/events")
def get_events(session_id: str, after: int = Query(0, ge=0)):
    session = _get_session(session_id)
    with session.lock:
        events = [event for event in session.events if event["seq"] > after]
        next_seq = session.seq
    return {"events": events, "next": next_seq}


@app.post("/api/sessions/{session_id}/command_result")
def command_result(session_id: str, body: CommandResult):
    session = _get_session(session_id)
    with session.lock:
        if not session.running or session.pending_command != body.command_id:
            raise HTTPException(status_code=409, detail="No matching pending command")
        proc = session.proc
        session.pending_command = None

    if proc is None or proc.poll() is not None or proc.stdin is None:
        raise HTTPException(status_code=409, detail="Python worker is not running")

    payload = {
        "type": "command_result",
        "command_id": body.command_id,
        "ok": body.ok,
        "result": body.result,
        "error": body.error,
    }
    try:
        proc.stdin.write(json.dumps(payload, ensure_ascii=False) + "\n")
        proc.stdin.flush()
    except Exception as exc:
        raise HTTPException(status_code=409, detail=f"Failed to deliver command result: {exc}")

    return {"ok": True}
