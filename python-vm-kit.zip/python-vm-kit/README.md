# Unity Python VM — Starter Kit

Run student Python code **inside a Unity simulator**, with console output **and**
control of the 3D world (spawn/move objects, read positions back). Works across
desktop, mobile, and WebGL because the Python execution lives on a server, not
inside the Unity player.

> **Status: teaching/demo kit.** The included server runs Python as a local
> subprocess with basic limits. That is fine for you, the instructor, on your own
> machine. It is **NOT a secure sandbox** for untrusted student code. See
> [Production hardening](#production-hardening) before exposing it to students.

---

## 1. Architecture

```
┌────────────────────────────┐         HTTP/JSON          ┌───────────────────────────┐
│  Unity player              │ ─────────────────────────▶ │  Bridge server (FastAPI)  │
│  (desktop / mobile / WebGL)│                            │  server/app.py            │
│                            │ ◀───────────────────────── │                           │
│  PythonVMClient.cs         │   events: output/command/  │  spawns & supervises      │
│  SimCommandExecutor.cs     │   done/error               │  Python worker            │
└────────────────────────────┘                            └─────────────┬─────────────┘
            ▲                                                           │ JSON-lines
            │ executes sim commands,                                    │ over stdio
            │ posts results back                                        ▼
            │                                             ┌───────────────────────────┐
            └────────────────────────────────────────────│  Python worker            │
                                                          │  server/worker.py         │
                                                          │  runs student code with   │
                                                          │  an injected `sim` object │
                                                          └───────────────────────────┘
```

**Why a server instead of embedding Python in Unity?**

- **Cross-platform:** one backend serves desktop, mobile, and WebGL. Embedded
  CPython/IronPython solutions are fragile or impossible on some targets (WebGL).
- **Real CPython:** full standard library; add `numpy`/`pandas` in the worker image.
- **Safety & control:** you can timeout, limit, and sandbox execution centrally.
- **Simpler Unity client:** just HTTP + JSON, no native plugins.

The tradeoff: students need a network connection to the bridge server.

### The `sim` bridge (sense → think → act)

Student code calls `sim.move(...)`, `sim.get_position(...)`, etc. Each call:

1. Worker emits a `command` event and **blocks**.
2. Unity receives the command, executes it on the main thread, and posts the result.
3. Worker unblocks and returns the result to the student's code.

This lets Python *read live simulation state*, not just fire-and-forget.

---

## 2. Repository layout

```
python-vm-kit/
├── server/
│   ├── app.py                 # FastAPI bridge: sessions, runs, events, command results
│   ├── worker.py              # Python worker: runs student code, exposes `sim`
│   ├── requirements.txt
│   └── Dockerfile.worker      # reference hardened container for production
├── unity/
│   ├── PythonVMClient.cs      # HTTP client + event pump + command dispatch
│   ├── SimCommandExecutor.cs  # turns sim commands into Unity actions
│   └── PythonVMQuickDebugUI.cs# optional IMGUI panel for quick testing
├── demo/
│   └── index.html             # browser simulator using the SAME protocol as Unity
└── examples/
    ├── lesson_01_hello.py
    ├── lesson_02_loops.py
    ├── lesson_03_sensors.py
    ├── lesson_04_functions.py
    └── lesson_05_collections.py
```

---

## 3. Quick start (instructor machine)

```bash
cd server
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

Open `http://localhost:8000/` for the **browser demo** (a 2D top-down simulator
that speaks the exact same protocol as Unity). Use it to validate the backend and
to develop lessons before wiring up Unity.

### HTTP API

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/sessions` | Create a session → `{session_id}` |
| POST | `/api/sessions/{id}/run` | Submit `{code}` → `{run_id}` |
| GET  | `/api/sessions/{id}/events?after=N` | Poll events with `seq > N` |
| POST | `/api/sessions/{id}/command_result` | Return a sim command's result |
| POST | `/api/sessions/{id}/stop` | Kill the current run |
| DELETE | `/api/sessions/{id}` | End session + cleanup |
| GET  | `/api/health` | Liveness + mode |

Event types: `started`, `output` (`stdout`/`stderr`), `command`, `done`, `error`, `stopped`.

---

## 4. Unity setup

1. **Unity 2021.3+** (uses `UnityWebRequest`). Any render pipeline.
2. Install the Newtonsoft JSON package:
   `Window → Package Manager → + → Add package by name…` →
   `com.unity.nuget.newtonsoft-json`.
3. Copy the three `.cs` files from `unity/` into `Assets/PythonVM/`.
4. Create an empty GameObject named `PythonVM` and add:
   - `PythonVMClient`
   - `SimCommandExecutor`
   - `PythonVMQuickDebugUI` (optional, for a quick on-screen console)
5. Set `PythonVMClient.serverUrl` to your bridge, e.g. `http://192.168.1.50:8000`.
   (Use `http://localhost:8000` only when Unity and the server are on the same machine.)
6. Press Play. Use the debug panel to run code, or call from your own UI:

```csharp
var vm = FindObjectOfType<PythonVMClient>();
vm.OnOutput += (text, isError) => myConsole.Append(text);
vm.OnError  += (msg) => myConsole.AppendError(msg);
vm.RunCode("sim.spawn('robot', 'cube', x=0, y=0.5, z=0, color='cyan')");
```

### Build-target notes

- **WebGL:** serve the page and the bridge over HTTPS (mixed content is blocked).
  Enable CORS on the server for your page's origin. HTTP polling works in WebGL;
  no threads are used in the client.
- **Mobile:** point `serverUrl` at a reachable server; use HTTPS in production.
- **Desktop:** HTTP is fine on a trusted LAN.

### Extending the sim API

Add a method to `Sim` in `worker.py` (it just calls `self._call("your_command", ...)`),
then handle `"your_command"` in `SimCommandExecutor.Execute` (Unity) and in
`executeCommand` (browser demo). Ideas: `sim.raycast()`, `sim.set_velocity()`,
`sim.play_animation()`, `sim.read_sensor("lidar")`, `sim.wait(seconds)`.

---

## 5. Student-facing `sim` API

| Call | Description |
|---|---|
| `sim.spawn(id, shape="cube", x=0, y=0, z=0, color=None, scale=1)` | Create an object (`cube`, `sphere`, `cylinder`, `capsule`, …) |
| `sim.move(id, x=None, y=None, z=None, dx=None, dy=None, dz=None)` | Absolute (`x/y/z`) or relative (`dx/dy/dz`) move; returns new position |
| `sim.rotate(id, yaw=None, pitch=None, roll=None)` | Set rotation (degrees) |
| `sim.get_position(id)` | Returns `{"x":…, "y":…, "z":…}` |
| `sim.objects()` | List of object ids |
| `sim.delete(id)` | Remove an object |
| `sim.set_color(id, color)` | Name (`"cyan"`) or hex (`"#22d3ee"`) |

`print()` output is streamed to the Unity console. Errors show a trimmed traceback.

---

## 6. Production hardening

The demo runner is **not** safe for untrusted code. Before students use it:

1. **Isolate execution.** Run each run/session in a disposable container
   (see `server/Dockerfile.worker`) or a microVM. For strong isolation use
   **gVisor** or **Firecracker**. Never run student code as root.
2. **No network** from the worker (`--network none`).
3. **Resource limits:** CPU time, wall-clock timeout, memory, PIDs, file size,
   open files. The demo sets some via `resource.setrlimit`; containers enforce more.
4. **Read-only filesystem** + a small `tmpfs` scratch dir.
5. **Drop capabilities**, `--security-opt no-new-privileges`, seccomp profile.
6. **Auth & quotas:** authenticate students, rate-limit runs, cap concurrent
   sessions, and scope sessions per user.
7. **Lock down CORS** to your Unity/web origin; serve over HTTPS.
8. **Audit/log** submissions for your course's integrity needs.

A common production shape: Unity → authenticated API → job queue → pool of
sandboxed workers (containers/microVMs) → results back over WebSocket or polling.
The protocol in this kit stays the same; only the runner changes.

---

## 7. How this maps to your answers

- **Multiple platforms** → server-side execution + thin HTTP Unity client.
- **Output *and* world control** → the blocking `sim` command bridge.
- **Libraries undecided** → start with the standard library; add packages to the
  worker image later without touching Unity.

## 8. Next steps

- Swap HTTP polling for WebSockets for lower latency (optional).
- Add per-student auth and a lesson/assignment loader.
- Replace the primitive spawner with your actual simulator objects/robots.
- Move the runner into containers/microVMs (Section 6).
