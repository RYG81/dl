# Lesson 5: Collections — manage a fleet
# Concepts: lists, dictionaries, iterating over objects.

colors = ["red", "green", "blue", "yellow", "purple"]
fleet = []

# Spawn a row of drones
for i, color in enumerate(colors):
    drone_id = f"drone_{i}"
    sim.spawn(drone_id, "sphere", x=i * 1.5 - 3, y=0.5, z=0, color=color)
    fleet.append(drone_id)

print("Fleet:", fleet)

# Move each drone to a new altitude based on its index
for i, drone_id in enumerate(fleet):
    sim.move(drone_id, y=0.5 + i * 0.6)

# Read back and report the whole fleet
report = {}
for drone_id in fleet:
    report[drone_id] = sim.get_position(drone_id)

for drone_id, pos in report.items():
    print(f"{drone_id}: y = {pos['y']:.1f}")

# Clean up one drone
sim.delete(fleet[0])
print("After deletion:", sim.objects())
