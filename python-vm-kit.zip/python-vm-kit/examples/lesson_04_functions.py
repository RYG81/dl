# Lesson 4: Functions — reusable behavior
# Concepts: defining functions, parameters, return values.

import math

def distance_between(a, b):
    pa = sim.get_position(a)
    pb = sim.get_position(b)
    return math.hypot(pb["x"] - pa["x"], pb["z"] - pa["z"])

def move_toward(obj, target, step=0.5):
    p = sim.get_position(obj)
    t = sim.get_position(target)
    dx = t["x"] - p["x"]
    dz = t["z"] - p["z"]
    d = math.hypot(dx, dz)
    if d < 1e-6:
        return 0.0
    sim.move(obj, dx=dx / d * step, dz=dz / d * step)
    return d

sim.spawn("rover", "cube", x=-3, y=0.5, z=0, color="cyan")
sim.spawn("beacon", "sphere", x=3, y=0.5, z=2, color="yellow")

print("Starting distance:", round(distance_between("rover", "beacon"), 2))

for i in range(30):
    remaining = move_toward("rover", "beacon", step=0.4)
    if remaining < 0.3:
        print("Reached the beacon!")
        break

print("Final distance:", round(distance_between("rover", "beacon"), 2))
