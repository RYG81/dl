# Lesson 2: Loops — drive the robot in a square
# Concepts: for loops, variables, calling sim functions repeatedly.

sim.spawn("robot", "cube", x=0, y=0.5, z=0, color="cyan")

side_length = 3

for side in range(4):
    # Drive forward along +X
    sim.move("robot", dx=side_length)
    pos = sim.get_position("robot")
    print(f"Corner {side + 1}: x={pos['x']}, z={pos['z']}")

    # Turn the corner by moving along +Z
    sim.move("robot", dz=side_length)

print("Square complete!")
sim.set_color("robot", "lime")
