# Lesson 3: Sensors and feedback — seek the target
# Concepts: while loops, reading state, computing, acting.
# This is the core pattern of robotics/automation: sense -> think -> act.

import math

sim.spawn("robot", "cube", x=-4, y=0.5, z=-3, color="cyan")
sim.spawn("target", "sphere", x=4, y=0.5, z=3, color="orange")

STEP = 0.5
ARRIVE_DISTANCE = 0.3
max_steps = 100

steps = 0
while steps < max_steps:
    # SENSE: read positions from the simulation
    robot = sim.get_position("robot")
    target = sim.get_position("target")

    # THINK: compute direction and distance
    dx = target["x"] - robot["x"]
    dz = target["z"] - robot["z"]
    distance = math.hypot(dx, dz)
    print(f"Step {steps}: distance = {distance:.2f}")

    if distance < ARRIVE_DISTANCE:
        print("Arrived at target!")
        break

    # ACT: move one step toward the target
    sim.move("robot", dx=dx / distance * STEP, dz=dz / distance * STEP)
    steps += 1
else:
    print("Gave up after too many steps.")

sim.set_color("robot", "lime")
