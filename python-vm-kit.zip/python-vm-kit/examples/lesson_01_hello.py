# Lesson 1: Hello, simulator!
# The `sim` object is provided automatically — no import needed.

print("Hello from inside Unity!")

name = "Student"
print(f"Welcome, {name}.")

# Create a few objects in the 3D world
sim.spawn("robot", "cube", x=0, y=0.5, z=0, color="cyan")
sim.spawn("goal", "sphere", x=4, y=0.5, z=0, color="orange")

print("Objects in the world:", sim.objects())
