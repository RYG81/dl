using System;
using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using Newtonsoft.Json.Linq;

/// <summary>
/// Unity client for the Unity Python VM starter kit.
/// Requires the Unity Newtonsoft JSON package: com.unity.nuget.newtonsoft-json
/// </summary>
public class PythonVMClient : MonoBehaviour
{
    [Header("Server")]
    public string serverUrl = "http://127.0.0.1:8000";
    public float pollIntervalSeconds = 0.1f;
    public bool createSessionOnStart = true;

    [Header("Simulation")]
    public SimCommandExecutor commandExecutor;

    public event Action<string, bool> OnOutput;   // text, isError
    public event Action<string> OnError;
    public event Action OnRunStarted;
    public event Action OnRunFinished;

    public string SessionId { get; private set; }
    public bool IsRunning { get; private set; }

    private int _cursor;

    private IEnumerator Start()
    {
        if (commandExecutor == null)
            commandExecutor = GetComponent<SimCommandExecutor>();

        if (createSessionOnStart)
            yield return CreateSession();

        StartCoroutine(PollLoop());
    }

    public IEnumerator CreateSession()
    {
        yield return Request("POST", serverUrl + "/api/sessions", "{}", (code, text) =>
        {
            if (code >= 200 && code < 300)
            {
                var obj = JObject.Parse(text);
                SessionId = obj["session_id"]?.Value<string>();
                _cursor = 0;
                Debug.Log("[PythonVM] session: " + SessionId);
            }
            else
            {
                OnError?.Invoke("Create session failed: " + text);
            }
        });
    }

    public void RunCode(string code)
    {
        if (IsRunning)
        {
            OnError?.Invoke("A run is already in progress.");
            return;
        }

        if (string.IsNullOrEmpty(SessionId))
            StartCoroutine(CreateSessionAndRun(code));
        else
            StartCoroutine(RunCodeRoutine(code));
    }

    private IEnumerator CreateSessionAndRun(string code)
    {
        yield return CreateSession();
        if (!string.IsNullOrEmpty(SessionId))
            yield return RunCodeRoutine(code);
    }

    private IEnumerator RunCodeRoutine(string code)
    {
        IsRunning = true;
        OnRunStarted?.Invoke();

        var body = new JObject { ["code"] = code };
        yield return Request("POST", $"{serverUrl}/api/sessions/{SessionId}/run", body.ToString(), (httpCode, text) =>
        {
            if (httpCode < 200 || httpCode >= 300)
            {
                IsRunning = false;
                OnError?.Invoke("Run failed: " + text);
                OnRunFinished?.Invoke();
            }
        });
    }

    public void StopRun()
    {
        if (string.IsNullOrEmpty(SessionId)) return;
        StartCoroutine(Request("POST", $"{serverUrl}/api/sessions/{SessionId}/stop", "{}", (code, text) =>
        {
            if (code < 200 || code >= 300)
                OnError?.Invoke("Stop failed: " + text);
        }));
    }

    private IEnumerator PollLoop()
    {
        while (true)
        {
            if (!string.IsNullOrEmpty(SessionId))
                yield return PollOnce();
            yield return new WaitForSeconds(pollIntervalSeconds);
        }
    }

    private IEnumerator PollOnce()
    {
        string url = $"{serverUrl}/api/sessions/{SessionId}/events?after={_cursor}";
        yield return Request("GET", url, null, (code, text) =>
        {
            if (code < 200 || code >= 300) return;

            var obj = JObject.Parse(text);
            var events = obj["events"] as JArray;
            if (events == null) return;

            foreach (JObject ev in events)
            {
                _cursor = ev["seq"]?.Value<int>() ?? _cursor;
                HandleEvent(ev);
            }
        });
    }

    private void HandleEvent(JObject ev)
    {
        string type = ev["type"]?.Value<string>();
        switch (type)
        {
            case "started":
                IsRunning = true;
                OnRunStarted?.Invoke();
                break;

            case "output":
                string stream = ev["stream"]?.Value<string>() ?? "stdout";
                OnOutput?.Invoke(ev["text"]?.Value<string>() ?? "", stream == "stderr");
                break;

            case "command":
                StartCoroutine(ExecuteCommand(ev));
                break;

            case "done":
                IsRunning = false;
                OnRunFinished?.Invoke();
                break;

            case "error":
                IsRunning = false;
                OnError?.Invoke(ev["message"]?.Value<string>() ?? "Python error");
                OnRunFinished?.Invoke();
                break;

            case "stopped":
                IsRunning = false;
                OnRunFinished?.Invoke();
                break;
        }
    }

    private IEnumerator ExecuteCommand(JObject ev)
    {
        string commandId = ev["command_id"]?.Value<string>();
        string name = ev["name"]?.Value<string>();
        JObject args = ev["args"] as JObject ?? new JObject();

        JToken result = null;
        bool ok = true;
        string error = null;

        try
        {
            if (commandExecutor == null)
                throw new InvalidOperationException("No SimCommandExecutor assigned to PythonVMClient.");
            result = commandExecutor.Execute(name, args);
        }
        catch (Exception ex)
        {
            ok = false;
            error = ex.Message;
        }

        var body = new JObject
        {
            ["command_id"] = commandId,
            ["ok"] = ok,
            ["result"] = result,
            ["error"] = error
        };

        yield return Request("POST", $"{serverUrl}/api/sessions/{SessionId}/command_result", body.ToString(), (code, text) =>
        {
            if (code < 200 || code >= 300)
                OnError?.Invoke("Failed to send command result: " + text);
        });
    }

    private IEnumerator Request(string method, string url, string json, Action<long, string> callback)
    {
        var req = new UnityWebRequest(url, method);
        req.downloadHandler = new DownloadHandlerBuffer();
        req.timeout = 15;

        if (json != null)
        {
            byte[] payload = Encoding.UTF8.GetBytes(json);
            req.uploadHandler = new UploadHandlerRaw(payload);
            req.SetRequestHeader("Content-Type", "application/json");
        }

        yield return req.SendWebRequest();

#if UNITY_2020_1_OR_NEWER
        bool failed = req.result != UnityWebRequest.Result.Success;
#else
        bool failed = req.isNetworkError || req.isHttpError;
#endif
        long responseCode = req.responseCode;
        string responseText = req.downloadHandler != null ? req.downloadHandler.text : "";
        string errorText = req.error;
        req.Dispose();

        if (failed)
            callback?.Invoke(responseCode, string.IsNullOrEmpty(errorText) ? responseText : errorText + " " + responseText);
        else
            callback?.Invoke(responseCode, responseText);
    }
}
