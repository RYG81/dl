using System;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json.Linq;

/// <summary>
/// Executes simulation commands sent from Python through the PythonVMClient.
/// Attach this to a GameObject that acts as the world root, or assign worldRoot.
/// </summary>
public class SimCommandExecutor : MonoBehaviour
{
    [Tooltip("Optional parent for spawned objects. If empty, this transform is used.")]
    public Transform worldRoot;

    private readonly Dictionary<string, GameObject> _objects = new Dictionary<string, GameObject>();

    public JToken Execute(string name, JObject args)
    {
        if (args == null) args = new JObject();

        switch (name)
        {
            case "spawn": return Spawn(args);
            case "move": return Move(args);
            case "rotate": return Rotate(args);
            case "get_position": return GetPosition(args);
            case "objects": return ListObjects();
            case "delete": return Delete(args);
            case "set_color": return SetColor(args);
            default: throw new NotSupportedException($"Unknown sim command '{name}'");
        }
    }

    private JToken Spawn(JObject args)
    {
        string id = RequireString(args, "id");
        string shape = OptionalString(args, "shape") ?? "cube";
        JObject pos = args["position"] as JObject ?? new JObject();
        float x = OptionalFloat(pos, "x") ?? 0f;
        float y = OptionalFloat(pos, "y") ?? 0f;
        float z = OptionalFloat(pos, "z") ?? 0f;
        float scale = OptionalFloat(args, "scale") ?? 1f;
        string color = OptionalString(args, "color");

        if (_objects.TryGetValue(id, out var existing))
        {
            Destroy(existing);
            _objects.Remove(id);
        }

        PrimitiveType type;
        switch (shape.ToLowerInvariant())
        {
            case "sphere": type = PrimitiveType.Sphere; break;
            case "cylinder": type = PrimitiveType.Cylinder; break;
            case "capsule": type = PrimitiveType.Capsule; break;
            case "plane": type = PrimitiveType.Plane; break;
            case "quad": type = PrimitiveType.Quad; break;
            default: type = PrimitiveType.Cube; break;
        }

        var go = GameObject.CreatePrimitive(type);
        go.name = id;
        go.transform.SetParent(worldRoot != null ? worldRoot : transform, false);
        go.transform.localPosition = new Vector3(x, y, z);
        go.transform.localScale = Vector3.one * Mathf.Max(0.001f, scale);
        ApplyColor(go, color);
        _objects[id] = go;
        return new JValue(id);
    }

    private JToken Move(JObject args)
    {
        var go = GetObject(RequireString(args, "id"));
        Vector3 p = go.transform.localPosition;

        float? x = OptionalFloat(args, "x");
        float? y = OptionalFloat(args, "y");
        float? z = OptionalFloat(args, "z");
        float? dx = OptionalFloat(args, "dx");
        float? dy = OptionalFloat(args, "dy");
        float? dz = OptionalFloat(args, "dz");

        if (x.HasValue) p.x = x.Value; else if (dx.HasValue) p.x += dx.Value;
        if (y.HasValue) p.y = y.Value; else if (dy.HasValue) p.y += dy.Value;
        if (z.HasValue) p.z = z.Value; else if (dz.HasValue) p.z += dz.Value;

        go.transform.localPosition = p;
        return PositionJson(p);
    }

    private JToken Rotate(JObject args)
    {
        var go = GetObject(RequireString(args, "id"));
        Vector3 e = go.transform.localEulerAngles;
        float? yaw = OptionalFloat(args, "yaw");
        float? pitch = OptionalFloat(args, "pitch");
        float? roll = OptionalFloat(args, "roll");
        if (pitch.HasValue) e.x = pitch.Value;
        if (yaw.HasValue) e.y = yaw.Value;
        if (roll.HasValue) e.z = roll.Value;
        go.transform.localEulerAngles = e;
        return new JObject { ["pitch"] = e.x, ["yaw"] = e.y, ["roll"] = e.z };
    }

    private JToken GetPosition(JObject args)
    {
        var go = GetObject(RequireString(args, "id"));
        return PositionJson(go.transform.localPosition);
    }

    private JToken ListObjects()
    {
        var arr = new JArray();
        foreach (var key in _objects.Keys) arr.Add(key);
        return arr;
    }

    private JToken Delete(JObject args)
    {
        string id = RequireString(args, "id");
        if (_objects.TryGetValue(id, out var go))
        {
            Destroy(go);
            _objects.Remove(id);
        }
        return new JValue(true);
    }

    private JToken SetColor(JObject args)
    {
        var go = GetObject(RequireString(args, "id"));
        ApplyColor(go, RequireString(args, "color"));
        return new JValue(true);
    }

    private GameObject GetObject(string id)
    {
        if (!_objects.TryGetValue(id, out var go) || go == null)
            throw new KeyNotFoundException($"object '{id}' not found");
        return go;
    }

    private static JObject PositionJson(Vector3 p)
    {
        return new JObject { ["x"] = p.x, ["y"] = p.y, ["z"] = p.z };
    }

    private static void ApplyColor(GameObject go, string color)
    {
        var renderer = go.GetComponent<Renderer>();
        if (renderer == null) return;
        renderer.material.color = ParseColor(color);
    }

    private static Color ParseColor(string color)
    {
        if (string.IsNullOrEmpty(color)) return Color.white;
        if (ColorUtility.TryParseHtmlString(color, out var parsed)) return parsed;

        switch (color.ToLowerInvariant())
        {
            case "red": return Color.red;
            case "green": return Color.green;
            case "blue": return Color.blue;
            case "yellow": return Color.yellow;
            case "cyan": return Color.cyan;
            case "magenta": return Color.magenta;
            case "orange": return new Color(1f, 0.5f, 0f);
            case "purple":
            case "violet": return new Color(0.6f, 0.2f, 0.9f);
            case "lime": return new Color(0.5f, 1f, 0f);
            case "white": return Color.white;
            case "black": return Color.black;
            case "gray":
            case "grey": return Color.gray;
            default: return Color.white;
        }
    }

    private static string RequireString(JObject args, string key)
    {
        string value = OptionalString(args, key);
        if (string.IsNullOrEmpty(value))
            throw new ArgumentException($"missing '{key}'");
        return value;
    }

    private static string OptionalString(JObject args, string key)
    {
        var token = args[key];
        if (token == null || token.Type == JTokenType.Null) return null;
        return token.Value<string>();
    }

    private static float? OptionalFloat(JObject args, string key)
    {
        var token = args[key];
        if (token == null || token.Type == JTokenType.Null) return null;
        return token.Value<float>();
    }
}
