using UnityEngine;

/// <summary>
/// Quick IMGUI debug panel for testing the Python VM without building a full UI.
/// Add this to the same GameObject as PythonVMClient, or assign client manually.
/// </summary>
public class PythonVMQuickDebugUI : MonoBehaviour
{
    public PythonVMClient client;

    private string _code =
        "print('Hello from Unity + Python!')\n" +
        "sim.spawn('robot', 'cube', x=0, y=0, z=0, color='cyan')\n" +
        "sim.spawn('goal', 'sphere', x=3, y=0, z=2, color='orange')\n" +
        "print('objects:', sim.objects())\n" +
        "print('robot:', sim.get_position('robot'))\n";

    private string _output = "";
    private Vector2 _scroll;

    private void OnEnable()
    {
        if (client == null) client = GetComponent<PythonVMClient>();
        if (client != null)
        {
            client.OnOutput += HandleOutput;
            client.OnError += HandleError;
            client.OnRunFinished += HandleRunFinished;
        }
    }

    private void OnDisable()
    {
        if (client != null)
        {
            client.OnOutput -= HandleOutput;
            client.OnError -= HandleError;
            client.OnRunFinished -= HandleRunFinished;
        }
    }

    private void HandleOutput(string text, bool isError)
    {
        _output += text;
    }

    private void HandleError(string message)
    {
        _output += "\n[error] " + message + "\n";
    }

    private void HandleRunFinished()
    {
        _output += "\n[finished]\n";
    }

    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(10, 10, 560, Screen.height - 20));
        GUILayout.Label("Python VM Debug", GUI.skin.label);
        _code = GUILayout.TextArea(_code, GUILayout.Height(180));

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Run", GUILayout.Width(90)))
        {
            if (client != null) client.RunCode(_code);
        }
        if (GUILayout.Button("Stop", GUILayout.Width(90)))
        {
            if (client != null) client.StopRun();
        }
        if (GUILayout.Button("Clear", GUILayout.Width(90)))
        {
            _output = "";
        }
        GUILayout.EndHorizontal();

        _scroll = GUILayout.BeginScrollView(_scroll, GUILayout.ExpandHeight(true));
        GUILayout.TextArea(_output, GUILayout.ExpandHeight(true));
        GUILayout.EndScrollView();
        GUILayout.EndArea();
    }
}
