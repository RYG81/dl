import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// The dev server proxies /ollama/* to your local Ollama server-side.
// That means: NO CORS setup, NO OLLAMA_ORIGINS, works on Windows/macOS/Linux as-is.
//
// IMPORTANT: the target is 127.0.0.1 (IPv4), not "localhost".
// On Windows, Node resolves "localhost" to ::1 (IPv6) first, but Ollama listens
// on IPv4 only — that causes "connect ECONNREFUSED ::1:11434".
// Point it elsewhere with:  OLLAMA_URL=http://192.168.1.5:11434 npm run dev
const OLLAMA_URL = process.env.OLLAMA_URL || 'http://127.0.0.1:11434'

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,          // 0.0.0.0
    port: 5173,
    allowedHosts: true,  // allow tunneled/preview hostnames
    proxy: {
      '/ollama': {
        target: OLLAMA_URL,
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/ollama/, ''),
        configure: (proxy) => {
          // When Ollama is down, answer with a clean JSON 502 the app understands.
          proxy.on('error', (err, req, res) => {
            if (res && !res.headersSent) {
              res.writeHead(502, { 'Content-Type': 'application/json' })
              res.end(JSON.stringify({
                error: String(err && err.message || err),
                hint: 'Is Ollama running at ' + OLLAMA_URL + '? Start it with: ollama serve',
              }))
            }
          })
        },
      },
    },
  },
  build: { outDir: 'dist' },
})
