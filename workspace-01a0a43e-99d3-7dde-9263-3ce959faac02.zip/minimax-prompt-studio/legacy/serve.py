#!/usr/bin/env python3
"""
CinePrompt Studio — local server
Serves the studio UI and proxies /ollama/* to your local Ollama,
so the browser never hits CORS issues (no OLLAMA_ORIGINS needed).

Usage:
    python3 serve.py                 # http://localhost:8321
    PORT=9000 python3 serve.py       # custom port
    OLLAMA_URL=http://192.168.1.5:11434 python3 serve.py   # remote Ollama box
"""
import json
import os
import urllib.error
import urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434").rstrip("/")
PORT = int(os.environ.get("PORT", "8321"))


class Handler(SimpleHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def send_response(self, code, message=None):
        super().send_response(code, message)
        self.send_header("Cache-Control", "no-store")

    # ---------------- static files ----------------
    def do_GET(self):
        if self.path.startswith("/ollama/"):
            return self.proxy("GET")
        if self.path == "/":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self):
        if self.path.startswith("/ollama/"):
            return self.proxy("POST")
        self.send_error(404)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    # ---------------- ollama proxy ----------------
    def proxy(self, method):
        url = OLLAMA_URL + self.path[len("/ollama"):]
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else None
        try:
            req = urllib.request.Request(
                url, data=body, method=method,
                headers={"Content-Type": "application/json"},
            )
            upstream = urllib.request.urlopen(req, timeout=1800)
        except urllib.error.HTTPError as e:  # ollama returned an error status
            payload = e.read()
            self.send_response(e.code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        except Exception as e:  # ollama unreachable
            payload = json.dumps({
                "error": f"Cannot reach Ollama at {OLLAMA_URL}: {e}",
                "hint": "Is Ollama running? Try: ollama serve  |  then: ollama pull llama3.1:8b",
            }).encode()
            self.send_response(502)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        try:
            self.send_response(200)
            self.send_header("Content-Type", upstream.headers.get("Content-Type", "application/json"))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            while True:  # stream NDJSON chunks straight through (live tokens)
                chunk = upstream.read(512)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            upstream.close()

    def log_message(self, fmt, *args):
        print("[cineprompt]", fmt % args, flush=True)


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    print(f"""
  🎬 CinePrompt Studio
  ──────────────────────────────────────────────
  UI:      http://localhost:{PORT}
  Proxy:   /ollama/*  →  {OLLAMA_URL}   (streams tokens)

  No Ollama yet?
      ollama pull llama3.1:8b
  """)
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
