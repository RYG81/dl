# 🎬 CinePrompt Studio — MiniMax H3 Video Prompt Generator

**React + Vite edition.** A local-first prompt studio for MiniMax H3 (the model that replaced Hailuo),
powered by **your local Ollama model** — with a built-in instant engine as fallback, an 18-category
example library that doubles as few-shot knowledge, and a 3D camera-path director.

```
integrated_multimodal_description: [Shot 1] ... The camera pushes in with small amplitude at slow speed ...
overall_soundscape: ...
non_diegetic_music: ...
```

## 🚀 Quick start

```bash
npm install
npm run dev          # → http://localhost:5173
```

That's it. The instant offline engine works immediately.

### Why Ollama detection now just works

The Vite dev server proxies `/ollama/*` to `http://localhost:11434` **server-side**:

- ✅ no CORS errors
- ✅ no `OLLAMA_ORIGINS` setup (Windows, macOS, Linux — zero config)
- ✅ no mixed-content issues (the browser only ever talks to its own origin)

Model detection is fully dynamic via Ollama's `/api/tags` — **nothing is hardcoded**.
Open **⚙️ Ollama settings** (or click the connection pill in the header) to see every
installed model with family / params / quantization / size, pick one with **Use**, or
point the studio at a LAN box (the endpoint is remembered between visits).

```bash
ollama pull llama3.1:8b     # or any chat model — 7B+ follows the H3 format best
```

Point at a remote Ollama: `OLLAMA_URL=http://192.168.1.5:11434 npm run dev`

## ✨ Features

- **Two engines** — streaming Ollama generation (tokens appear live) or the instant offline H3-grammar engine
- **Full H3 grammar** — three-section format, camera type+amplitude+speed, timed multi-shot `[Shot 2] At 00:05.000`,
  `(S1)` dialogue tags in 11 languages, prose negation, 768P/2K · 5–15s · 24fps · 7,000-char limit
- **18 hand-written exemplars** — one per category (13 generation + 5 reference tasks), filterable gallery,
  auto-injected as few-shot knowledge per category when generating with Ollama
- **H3 compliance audit** — 9-point score per generated prompt
- **🛰️ 3D Camera Path mode** — drag the camera around your subject, keyframe the orbit, compile
  H3 Edit / Ref2VA trajectory prompts (port of Bruxos do VFX · Camera H3's proven prompt text)
- **Enhance mode**, multiple variants, history (last 50), cost estimator, copy-ready templates
- **External system prompts** — edit `public/prompts/system-prompt.md` (MiniMax H3) or `public/prompts/ltx-system-prompt.md` (LTX-Video 2.x), hit ↻ Reload. Override with any
  local `.md` from the settings panel. Built-in fallback if the file is unreachable.

## 📝 Customizing the system prompt

The Ollama persona lives outside the code in **`public/prompts/system-prompt.md`** (role, JSON output
contract, H3 hard rules). The whole file becomes the system message — markdown structure is fine.
Status + override controls are in ⚙️ Ollama settings.

## 📁 Project structure

```
index.html                     Vite entry
vite.config.js                 dev server + /ollama proxy
public/prompts/system-prompt.md  ← external system prompt (edit me)
src/
  App.jsx                      app shell, Ollama detection, cards & history state
  components/
    Header.jsx  SettingsPanel.jsx  StudioForm.jsx  OutputPanel.jsx
    CameraDirector.jsx  HistorySection.jsx  ExampleLibrary.jsx
    TemplatesSection.jsx  TipsSection.jsx  ui.jsx
  lib/
    ollama.js       detection, streaming chat, JSON salvage, model metadata
    prompts.js      fallback system prompt + user-message builder
    examples.js     18 exemplars + few-shot picker
    offline.js      instant engine (style/palette/sound banks)
    camera.js       camera-plan compiler (H3 Edit format)
    scoring.js      H3 compliance audit
    format.js       escaping, clipboard, download helpers
legacy/                        the original single-file app + python server (still works standalone)
```

## 🏗 Production build

```bash
npm run build        # → dist/
npm run preview      # serve the built app locally
```

> Serving the *built* app from another origin? Then the browser needs direct access to Ollama:
> Windows PowerShell: `$env:OLLAMA_ORIGINS="*"; ollama serve` · macOS/Linux: `OLLAMA_ORIGINS=* ollama serve`
> (Not needed for `npm run dev`.)

## 💡 Workflow tip

Draft at **768P** (~$0.08/s), generate 2–3 variants, compare, then re-roll the winner at **2K** (~$0.13/s).
