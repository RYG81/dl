var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/components/HistorySection.jsx
var HistorySection_exports = {};
__export(HistorySection_exports, {
  default: () => HistorySection
});
module.exports = __toCommonJS(HistorySection_exports);
var import_react = require("react");

// src/lib/format.js
function esc(s) {
  return (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function highlight(d) {
  let h = esc(d);
  h = h.replace(/\[Shot \d+\]/g, (m) => '<span class="shot">' + m + "</span>");
  h = h.replace(
    /^(integrated_multimodal_description|overall_soundscape|non_diegetic_music|subject_definitions|summary|retention_analysis|detailed_description):/gm,
    '<span class="sec">$1:</span>'
  );
  return h;
}
function fullPromptText(v) {
  let s = "integrated_multimodal_description: " + v.integrated_multimodal_description + "\n\noverall_soundscape: " + (v.overall_soundscape || "").trim() + "\n\nnon_diegetic_music: " + (v.non_diegetic_music || "N/A").trim();
  return s;
}
async function copyText(t) {
  try {
    await navigator.clipboard.writeText(t);
    return true;
  } catch (e) {
    const ta = document.createElement("textarea");
    ta.value = t;
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch (e2) {
      ok = false;
    }
    ta.remove();
    return ok;
  }
}
function downloadText(filename, text) {
  const blob = new Blob([text], { type: "text/plain" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

// src/components/HistorySection.jsx
function engineLabel(v) {
  if (v.engine === "ollama") return v.model || "ollama";
  if (v.engine === "camera-director") return "camera director";
  return "instant engine";
}
function HistorySection({ history, onReuse, onDelete, onClear, toast }) {
  const [open, setOpen] = (0, import_react.useState)(-1);
  return /* @__PURE__ */ React.createElement("section", { className: "block" }, /* @__PURE__ */ React.createElement("h2", null, "\u{1F558} Generated prompts", /* @__PURE__ */ React.createElement("span", { className: "vmeta" }, history.length, " saved (max 50, newest first)"), /* @__PURE__ */ React.createElement("span", { className: "spacer", style: { flex: 1 } }), history.length > 0 && /* @__PURE__ */ React.createElement("button", { className: "btn tiny ghost", onClick: () => {
    onClear();
    toast("History cleared");
  } }, "\u{1F5D1} Clear all")), history.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty" }, /* @__PURE__ */ React.createElement("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "#8e97ab", strokeWidth: "1.4" }, /* @__PURE__ */ React.createElement("circle", { cx: "12", cy: "12", r: "9" }), /* @__PURE__ */ React.createElement("path", { d: "M12 7v5l3 3" })), /* @__PURE__ */ React.createElement("div", { style: { fontSize: 14, fontWeight: 600, color: "var(--dim)" } }, "No prompts yet"), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 6, fontSize: 12.5 } }, "Everything you generate in the Studio or Camera Director lands here automatically.")), history.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "htable" }, /* @__PURE__ */ React.createElement("div", { className: "hhead" }, /* @__PURE__ */ React.createElement("span", null, "When"), /* @__PURE__ */ React.createElement("span", null, "Prompt"), /* @__PURE__ */ React.createElement("span", null, "Engine"), /* @__PURE__ */ React.createElement("span", null, "Actions")), history.map((h, i) => {
    const v = h.v || {};
    const desc = v.integrated_multimodal_description || "";
    const mode = h.mode || (v.engine === "camera-director" ? "camera" : "studio");
    const isOpen = open === i;
    return /* @__PURE__ */ React.createElement("div", { key: h.ts + "-" + i }, /* @__PURE__ */ React.createElement(
      "div",
      {
        className: "hrow" + (isOpen ? " open" : ""),
        onClick: () => setOpen(isOpen ? -1 : i),
        title: isOpen ? "Collapse" : "Expand full prompt"
      },
      /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { style: { color: "var(--dim)", fontSize: 11.5 } }, new Date(h.ts).toLocaleString()), /* @__PURE__ */ React.createElement("span", { className: "hmode " + mode }, mode)),
      /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { className: "t" }, "\u{1F3AC} ", v.title || "Untitled"), /* @__PURE__ */ React.createElement("div", { className: "p" }, desc.replace(/\s+/g, " ").slice(0, 160), "\u2026")),
      /* @__PURE__ */ React.createElement("div", { className: "m" }, engineLabel(v), h.inp && h.inp.ratio && /* @__PURE__ */ React.createElement("div", null, h.inp.ratio, " \xB7 ", h.inp.resolution, " \xB7 ", h.inp.duration, "s")),
      /* @__PURE__ */ React.createElement("div", { className: "hacts", onClick: (e) => e.stopPropagation() }, /* @__PURE__ */ React.createElement(
        "button",
        {
          className: "btn tiny",
          title: "Copy full prompt",
          onClick: async () => {
            await copyText(fullPromptText(v));
            toast("Copied from history");
          }
        },
        "\u{1F4CB}"
      ), /* @__PURE__ */ React.createElement(
        "button",
        {
          className: "btn tiny",
          title: "Download .txt",
          onClick: () => downloadText(
            "h3-prompt-" + (v.title || "untitled").toLowerCase().replace(/\W+/g, "-").slice(0, 40) + ".txt",
            fullPromptText(v)
          )
        },
        "\u2B07"
      ), mode === "studio" && h.inp && /* @__PURE__ */ React.createElement(
        "button",
        {
          className: "btn tiny",
          title: "Load settings back into the Studio",
          onClick: () => onReuse(h)
        },
        "\u2934"
      ), /* @__PURE__ */ React.createElement("button", { className: "btn tiny ghost", title: "Delete", onClick: () => {
        onDelete(i);
        setOpen(-1);
      } }, "\u2715"))
    ), isOpen && /* @__PURE__ */ React.createElement("div", { className: "hdetail" }, h.idea && /* @__PURE__ */ React.createElement("div", { className: "hint", style: { marginBottom: 6 } }, "\u{1F4A1} idea: ", h.idea), /* @__PURE__ */ React.createElement("div", { className: "promptbox", dangerouslySetInnerHTML: {
      __html: highlight(desc) + '\n\n<span class="sec">overall_soundscape:</span> ' + esc(v.overall_soundscape || "") + '\n\n<span class="sec">non_diegetic_music:</span> ' + esc(v.non_diegetic_music || "N/A")
    } })));
  })));
}
