/* small shared UI atoms */

export function Chips({ values, value, onChange, labels }) {
  return (
    <div className="chips">
      {values.map((v) => (
        <span
          key={v}
          className={'chip' + (v === value ? ' on' : '')}
          onClick={() => onChange(v)}
        >
          {(labels && labels[v]) || v}
        </span>
      ))}
    </div>
  )
}

export function Field({ label, opt, count, children }) {
  return (
    <div className="field">
      <label>
        {label} {opt && <span className="opt">{opt}</span>}
        {count}
      </label>
      {children}
    </div>
  )
}
