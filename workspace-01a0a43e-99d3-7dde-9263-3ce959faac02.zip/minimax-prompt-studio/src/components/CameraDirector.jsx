import { useCallback, useEffect, useRef, useState } from 'react'
import { Field } from './ui.jsx'
import { buildCamPlan } from '../lib/camera.js'

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v))

function poseAt(kfs, D, t, mode) {
  if (t <= 0) return { az: kfs[0].az, el: kfs[0].el, dist: kfs[0].dist }
  if (t >= D) { const l = kfs[kfs.length - 1]; return { az: l.az, el: l.el, dist: l.dist } }
  let i = 0
  while (i < kfs.length - 2 && t > kfs[i + 1].t) i++
  const a = kfs[i], b = kfs[i + 1]
  let u = (t - a.t) / Math.max(b.t - a.t, 1e-6)
  if (mode === 'smooth') u = u * u * (3 - 2 * u)
  return { az: a.az + (b.az - a.az) * u, el: a.el + (b.el - a.el) * u, dist: a.dist + (b.dist - a.dist) * u }
}

const proj = (p, cx, cy, S) => {
  const a = (p.az * Math.PI) / 180
  const r = p.dist * S
  const lift = Math.sin((p.el * Math.PI) / 180) * 30
  return [cx + Math.sin(a) * r, cy - Math.cos(a) * r - lift]
}

const PRESETS = {
  static: [[0, 0, 0, 1], [1, 0, 0, 1]],
  orbit360: [[0, 0, 0, 1], [1, 360, 0, 1]],
  halfR: [[0, 0, 0, 1], [1, 180, 0, 1]],
  halfL: [[0, 0, 0, 1], [1, -180, 0, 1]],
  quarterR: [[0, 0, 0, 1], [1, 90, 0, 1]],
  rise: [[0, 0, 0, 1], [1, 0, 25, 1]],
  fall: [[0, 0, 0, 1], [1, 0, -25, 1]],
  closer: [[0, 0, 0, 1], [1, 0, 0, 0.6]],
  away: [[0, 0, 0, 1], [1, 0, 0, 1.7]],
  riseOrbit: [[0, 0, 0, 1], [0.5, 180, 15, 1], [1, 360, 0, 1]],
}
const PRESET_LABELS = {
  static: 'Static', orbit360: 'Orbit 360°', halfR: 'Half orbit →', halfL: '← Half orbit',
  quarterR: 'Quarter →', rise: 'Rise', fall: 'Fall', closer: 'Move closer', away: 'Move away',
  riseOrbit: 'Rising orbit',
}

export default function CameraDirector({ pushCard, pushHistory, toast }) {
  const [kfs, setKfs] = useState([{ t: 0, az: 0, el: 0, dist: 1 }, { t: 5, az: 90, el: 0, dist: 1 }])
  const [duration, setDuration] = useState(5)
  const [interp, setInterp] = useState('smooth')
  const [detail, setDetail] = useState('extended')
  const [framing, setFraming] = useState('medium shot')
  const [ratio, setRatio] = useState('16:9')
  const [subjectBox, setSubjectBox] = useState('')
  const [instruction, setInstruction] = useState('')
  const [scrubT, setScrubT] = useState(0)
  const [playing, setPlaying] = useState(false)
  const [lastPreset, setLastPreset] = useState('')

  const canvasRef = useRef(null)
  const poseRef = useRef({ az: 90, el: 0, dist: 1 })
  const dragRef = useRef(false)
  const elRangeRef = useRef(null)
  const distRangeRef = useRef(null)
  const hudRef = useRef(null)
  const playTRef = useRef(0)
  const rafRef = useRef(0)

  const S = 72, CW = 680, CH = 420, CX = CW / 2, CY = CH / 2 + 16

  const draw = useCallback(() => {
    const cv = canvasRef.current
    if (!cv) return
    const ctx = cv.getContext('2d')
    ctx.clearRect(0, 0, CW, CH)
    ctx.strokeStyle = 'rgba(255,255,255,.06)'; ctx.lineWidth = 1
    for (const r of [0.5, 1, 1.5, 2, 2.5]) { ctx.beginPath(); ctx.arc(CX, CY, r * S, 0, Math.PI * 2); ctx.stroke() }
    ctx.strokeStyle = 'rgba(255,255,255,.10)'
    ctx.beginPath(); ctx.moveTo(CX, CY - 3.2 * S); ctx.lineTo(CX, CY + 3.2 * S)
    ctx.moveTo(CX - 3.2 * S, CY); ctx.lineTo(CX + 3.2 * S, CY); ctx.stroke()
    ctx.fillStyle = 'rgba(142,151,171,.55)'; ctx.font = '10px monospace'
    ctx.fillText('0°', CX + 4, CY - 1.02 * S + 12); ctx.fillText('+90°', CX + 1.02 * S - 8, CY + 14)
    ctx.fillText('1× ring', CX + 4, CY - S - 4)
    // planned path
    ctx.strokeStyle = 'rgba(76,201,240,.55)'; ctx.lineWidth = 2; ctx.beginPath()
    for (let i = 0; i <= 140; i++) {
      const p = poseAt(kfs, duration, (duration * i) / 140, interp)
      const [x, y] = proj(p, CX, CY, S)
      i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)
    }
    ctx.stroke()
    // keyframe markers
    ctx.font = '10px monospace'
    kfs.forEach((k, i) => {
      const [x, y] = proj(k, CX, CY, S)
      ctx.fillStyle = i === 0 ? '#3ecf8e' : '#f0b429'
      ctx.beginPath(); ctx.arc(x, y, 4.5, 0, Math.PI * 2); ctx.fill()
      ctx.fillStyle = 'rgba(233,237,245,.8)'; ctx.fillText(String(i + 1), x + 6, y - 6)
    })
    // playhead / scrub marker
    const pt = playing ? playTRef.current : scrubT
    if (pt > 0) {
      const p = poseAt(kfs, duration, pt, interp)
      const [x, y] = proj(p, CX, CY, S)
      ctx.fillStyle = 'rgba(76,201,240,.9)'
      ctx.beginPath(); ctx.arc(x, y, 3.5, 0, Math.PI * 2); ctx.fill()
    }
    // subject
    ctx.fillStyle = 'rgba(240,180,41,.16)'; ctx.beginPath(); ctx.arc(CX, CY, 15, 0, Math.PI * 2); ctx.fill()
    ctx.strokeStyle = '#f0b429'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(CX, CY, 15, 0, Math.PI * 2); ctx.stroke()
    ctx.fillStyle = '#f0b429'; ctx.font = '11px sans-serif'; ctx.fillText('SUBJECT', CX - 24, CY + 30)
    // camera handle
    const pose = poseRef.current
    const [x, y] = proj(pose, CX, CY, S)
    ctx.save(); ctx.translate(x, y); ctx.rotate(Math.atan2(CY - y, CX - x) + Math.PI / 2)
    ctx.fillStyle = '#a78bfa'; ctx.beginPath(); ctx.moveTo(0, -9); ctx.lineTo(8, 6); ctx.lineTo(-8, 6); ctx.closePath(); ctx.fill()
    ctx.fillStyle = '#0a0d13'; ctx.beginPath(); ctx.arc(0, -2, 2.6, 0, Math.PI * 2); ctx.fill()
    ctx.restore()
  }, [kfs, duration, interp, scrubT, playing])

  useEffect(() => { draw() }, [draw])

  const syncPoseUI = useCallback(() => {
    const pose = poseRef.current
    if (hudRef.current && !playing)
      hudRef.current.textContent = 'az ' + Math.round(pose.az) + '° · el ' + Math.round(pose.el) + '° · dist ' + pose.dist.toFixed(2) + '×'
    if (elRangeRef.current) elRangeRef.current.value = clamp(pose.el, -30, 30)
    if (distRangeRef.current) distRangeRef.current.value = pose.dist
  }, [playing])

  // pointer interaction
  useEffect(() => {
    const cv = canvasRef.current
    if (!cv) return
    const toLocal = (e) => {
      const r = cv.getBoundingClientRect()
      return [(e.clientX - r.left) * (CW / r.width) - CX, (e.clientY - r.top) * (CH / r.height) - CY]
    }
    const applyDrag = (e) => {
      const [x, y] = toLocal(e)
      let az = (Math.atan2(x, -y) * 180) / Math.PI
      const pose = poseRef.current
      while (az - pose.az > 180) az -= 360
      while (az - pose.az < -180) az += 360
      pose.az = az
      pose.dist = clamp(Math.hypot(x, y) / S, 0.1, 4)
      syncPoseUI(); draw()
    }
    const down = (e) => { dragRef.current = true; cv.setPointerCapture(e.pointerId); cv.style.cursor = 'grabbing'; applyDrag(e) }
    const move = (e) => { if (dragRef.current) applyDrag(e) }
    const up = () => { dragRef.current = false; cv.style.cursor = 'grab' }
    const wheel = (e) => {
      e.preventDefault()
      const pose = poseRef.current
      pose.dist = clamp(pose.dist * (e.deltaY > 0 ? 1.07 : 0.935), 0.1, 4)
      syncPoseUI(); draw()
    }
    cv.addEventListener('pointerdown', down)
    cv.addEventListener('pointermove', move)
    cv.addEventListener('pointerup', up)
    cv.addEventListener('wheel', wheel, { passive: false })
    return () => {
      cv.removeEventListener('pointerdown', down); cv.removeEventListener('pointermove', move)
      cv.removeEventListener('pointerup', up); cv.removeEventListener('wheel', wheel)
    }
  }, [draw, syncPoseUI])

  // playback
  useEffect(() => {
    if (!playing) return
    let last = 0
    const tick = (ts) => {
      if (!last) last = ts
      playTRef.current += (ts - last) / 1000
      last = ts
      if (playTRef.current >= duration) playTRef.current = 0
      const p = poseAt(kfs, duration, playTRef.current, interp)
      if (hudRef.current)
        hudRef.current.textContent = '▶ ' + playTRef.current.toFixed(1) + 's · az ' + Math.round(p.az) + '° · el ' + Math.round(p.el) + '° · dist ' + p.dist.toFixed(2) + '×'
      draw()
      rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(rafRef.current)
  }, [playing, kfs, duration, interp, draw])

  /* ---------- diagnostics ---------- */
  const travel = kfs.reduce((s, k, i) => (i ? s + Math.abs(k.az - kfs[i - 1].az) : 0), 0)
  const net = kfs[kfs.length - 1].az - kfs[0].az
  const reversals = kfs.slice(1, -1).map((k, i) => ({ k, i }))
    .filter(({ k, i }) => (k.az - kfs[i].az) * (kfs[i + 2].az - k.az) < 0).map(({ k }) => k.t)
  const closes = Math.abs(Math.abs(net) - 360) < 1e-6 &&
    Math.abs(kfs[0].el - kfs[kfs.length - 1].el) < 1e-6 &&
    Math.abs(kfs[0].dist - kfs[kfs.length - 1].dist) < 1e-6
  const avg = travel / Math.max(duration, 1e-9)
  const diag = []
  diag.push('Travel ' + travel.toFixed(0) + '° · net ' + net.toFixed(0) + '° · ' + (kfs.length - 1) + ' segment' + (kfs.length > 2 ? 's' : '') + ' · avg ' + avg.toFixed(1) + '°/s over ' + duration + 's')
  if (reversals.length) diag.push('Direction reversals at ' + reversals.map((t) => t.toFixed(2) + 's').join(', ') + ' — the camera eases to zero and turns there.')
  if (travel < 0.5 && Math.abs(kfs[kfs.length - 1].el - kfs[0].el) < 0.5 && Math.abs(kfs[kfs.length - 1].dist - kfs[0].dist) < 0.01)
    diag.push('⚠ Path is static — the prompt will request a held camera.')
  if (avg > 60) diag.push('⚠ Average ' + avg.toFixed(0) + '°/s is fast; H3 often under-rotates. Add duration or reduce travel.')
  if (closes) diag.push('Loop closure: ON — exact ±360° with matching elevation & distance; final frame will be anchored to the source.')
  else if (Math.abs(net) > 180) diag.push('Loop closure: OFF — net orbit is not exactly ±360° (currently ' + net.toFixed(1) + '°) or elevation/distance differ.')
  else diag.push('Loop closure: n/a (open path).')

  /* ---------- actions ---------- */
  const nextFreeTime = () => {
    const sorted = [...kfs].sort((a, b) => a.t - b.t)
    let bestGap = 0, bestT = null
    for (let i = 0; i < sorted.length; i++) {
      const a = sorted[i].t
      const b = i < sorted.length - 1 ? sorted[i + 1].t : duration
      if (b - a > bestGap) { bestGap = b - a; bestT = (a + b) / 2 }
    }
    return bestGap > 0.2 ? +bestT.toFixed(1) : null
  }

  const addKeyframe = () => {
    let t = +scrubT.toFixed(1)
    if (t <= 0.05) {
      const free = nextFreeTime()
      if (free === null) { toast('No free gap — delete a keyframe or extend the duration'); return }
      t = free
      setScrubT(t)
      toast('Timeline was at 0 — dropped into the free gap at ' + t + 's')
    }
    if (kfs.some((k) => Math.abs(k.t - t) < 0.05)) { toast('A keyframe already sits at ' + t + 's — drag the ⏱ Timeline to a free time'); return }
    const pose = poseRef.current
    let az = pose.az
    const prev = [...kfs].reverse().find((k) => k.t < t)
    if (prev) { while (az - prev.az > 180) az -= 360; while (az - prev.az < -180) az += 360 }
    setKfs([...kfs, { t, az: +az.toFixed(1), el: Math.round(clamp(pose.el, -89, 89)), dist: +pose.dist.toFixed(2) }].sort((a, b) => a.t - b.t))
    toast('Keyframe added at ' + t + 's')
  }

  const applyPreset = (name) => {
    const P = PRESETS[name]
    if (!P) return
    setKfs(P.map((k) => ({ t: +(k[0] * duration).toFixed(2), az: k[1], el: k[2], dist: k[3] })))
    poseRef.current = { az: 0, el: 0, dist: 1 }
    setScrubT(0)
    setLastPreset(name)
    syncPoseUI()
    toast('Preset loaded — tweak & compile 🛰️')
  }

  const redistribute = () => {
    if (kfs.length < 3) { toast('Need 3+ keyframes to redistribute'); return }
    const next = kfs.map((k) => ({ ...k }))
    let cum = [0]
    for (let i = 1; i < next.length; i++) {
      const w = Math.abs(next[i].az - next[i - 1].az) + 30 * Math.abs(next[i].el - next[i - 1].el) + 45 * Math.abs(next[i].dist - next[i - 1].dist)
      cum.push(cum[i - 1] + Math.max(w, 1e-6))
    }
    const total = cum[cum.length - 1]
    for (let i = 1; i < next.length - 1; i++) next[i].t = +((duration * cum[i]) / total).toFixed(2)
    next[next.length - 1].t = duration
    setKfs(next)
    toast('Timing redistributed by travel weight')
  }

  const changeDuration = (d) => {
    setKfs((prev) => {
      const k = d / duration
      const next = prev.map((kf) => ({ ...kf, t: +(kf.t * k).toFixed(2) }))
      next[next.length - 1].t = d
      return next
    })
    setDuration(d)
    setScrubT((t) => Math.min(t, d))
  }

  const compile = () => {
    try {
      const opts = { kfs, duration, interp, detail, subjectBox, instruction, frame: ratio }
      const res = buildCamPlan(opts)
      pushCard({ id: 'cam' + Math.random().toString(36).slice(2), kind: 'camera', res, opts })
      pushHistory({
        title: 'Camera path ' + ((res.net >= 0 ? '+' : '') + res.net.toFixed(0)) + '° / ' + duration + 's',
        integrated_multimodal_description: res.sections,
        overall_soundscape: 'Silence.', non_diegetic_music: 'N/A',
        shot_plan: res.segments.map((s) => s.id + ' · ' + s.signed_orbit_degrees + '°'),
        tags: ['camera-path', interp, detail], engine: 'camera-director', model: '3d-path',
      }, { ratio, resolution: '—', duration }, 'camera')
      toast('Camera-path prompt compiled 🛰️')
      window.scrollTo({ top: 0, behavior: 'smooth' })
    } catch (err) { toast('⚠ ' + err.message) }
  }

  const editKf = (i, f, val) => {
    let v = parseFloat(val)
    if (!isFinite(v)) return
    if (f === 't') v = clamp(v, 0, duration)
    if (f === 'el') v = clamp(v, -89, 89)
    if (f === 'dist') v = clamp(v, 0.1, 4)
    setKfs((prev) => prev.map((k, j) => (j === i ? { ...k, [f]: v } : k)).sort((a, b) => a.t - b.t))
  }

  return (
    <div>
      <h2><span className="step">A</span> Choreograph the camera</h2>
      <div className="sub">
        Drag the camera around your subject, set keyframes, then compile a trajectory prompt for <b>H3 Edit / Ref2VA</b>{' '}
        workflows — a browser port of the prompt-compile logic from{' '}
        <a href="https://github.com/NyckM/3d-Camera-control-H3-Minimax" target="_blank" rel="noopener">Bruxos do VFX · Camera H3</a>.
      </div>

      <Field label="Orbit view" opt="drag = orbit · wheel = distance · scrub & play to preview">
        <div style={{ position: 'relative' }}>
          <canvas ref={canvasRef} width={CW} height={CH}
            style={{ width: '100%', border: '1px solid var(--border2)', borderRadius: 12, background: 'radial-gradient(400px 260px at 50% 45%, #101725, #0a0e15)', cursor: 'grab', touchAction: 'none' }} />
          <div ref={hudRef} style={{ position: 'absolute', top: 8, left: 10, fontFamily: 'var(--mono)', fontSize: 11.5, color: 'var(--accent2)', background: 'rgba(10,14,21,.8)', padding: '3px 9px', borderRadius: 8, pointerEvents: 'none' }}>
            az 90° · el 0° · dist 1.00×
          </div>
          {playing && <div style={{ position: 'absolute', top: 8, right: 10, fontSize: 11, color: 'var(--green)', background: 'rgba(10,14,21,.8)', padding: '3px 9px', borderRadius: 8 }}>▶ previewing</div>}
        </div>
        <div className="hint">Top-down view. Subject at centre; positive azimuth travels toward the camera’s right. Elevation raises/lowers the camera around the subject.</div>
      </Field>

      <div className="field" style={{ marginTop: 12 }}>
        <label>⏱ Timeline — drag to pick WHEN the next keyframe lands{' '}
          <span className="rangeval">{scrubT.toFixed(1)}s / {duration.toFixed(1)}s</span></label>
        <input type="range" min="0" max={duration * 10} step="0.1" value={scrubT * 10}
          style={{ width: '100%', accentColor: 'var(--accent2)' }}
          onChange={(e) => {
            setScrubT(e.target.value / 10)
            if (!playing) {
              const p = poseAt(kfs, duration, e.target.value / 10, interp)
              if (hudRef.current) hudRef.current.textContent = '@ ' + (e.target.value / 10).toFixed(1) + 's · az ' + Math.round(p.az) + '° · el ' + Math.round(p.el) + '° · dist ' + p.dist.toFixed(2) + '×'
            }
          }} />
        <div className="hint">Scrub to a time → pose the camera on the canvas → press <b>＋ Add keyframe</b>. Left at 0? The keyframe auto-drops into the largest free gap. ▶ Play previews the whole path.</div>
      </div>

      <div className="row">
        <Field label={<span>Elevation <span className="rangeval">{Math.round(poseRef.current.el)}°</span></span>}>
          <input ref={elRangeRef} type="range" min="-30" max="30" step="1" defaultValue="0"
            onChange={(e) => { poseRef.current.el = +e.target.value; syncPoseUI(); draw() }} />
        </Field>
        <Field label={<span>Distance <span className="rangeval">{poseRef.current.dist.toFixed(2)}×</span></span>}>
          <input ref={distRangeRef} type="range" min="0.1" max="4" step="0.05" defaultValue="1"
            onChange={(e) => { poseRef.current.dist = +e.target.value; syncPoseUI(); draw() }} />
        </Field>
      </div>

      <Field label="Presets">
        <div className="chips">
          {Object.keys(PRESETS).map((p) => (
            <span key={p} className={'chip' + (lastPreset === p ? ' on' : '')} onClick={() => applyPreset(p)}>
              {PRESET_LABELS[p]}
            </span>
          ))}
        </div>
      </Field>

      <Field label="Keyframes" opt={kfs.length + ' keyframes · ' + duration + 's · ' + interp}>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 8 }}>
          <button className="btn tiny" onClick={addKeyframe}>＋ Add keyframe at scrub time</button>
          <button className="btn tiny ghost" onClick={() => setPlaying(!playing)}>{playing ? '⏸ Stop' : '▶ Play'}</button>
          <button className="btn tiny ghost" onClick={redistribute}>Redistribute timing</button>
          <button className="btn tiny ghost" onClick={() => applyPreset('static')}>Reset path</button>
        </div>
        <div style={{ display: 'grid', gap: 6 }}>
          {kfs.map((k, i) => (
            <div key={i} style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
              <span className="tagpill" style={{ margin: 0, minWidth: 26, textAlign: 'center' }}>{i + 1}</span>
              {[['t', 's', 0.1], ['az', '°', 1], ['el', '°', 1], ['dist', '×', 0.05]].map(([f, u, st]) => (
                <label key={f} style={{ fontSize: 10.5, color: 'var(--faint)' }}>
                  {f}
                  <input type="number" step={st} value={k[f]} disabled={i === 0}
                    style={{ display: 'block', marginTop: 2 }}
                    onChange={(e) => editKf(i, f, e.target.value)} />
                </label>
              ))}
              <button className="btn tiny ghost" disabled={i === 0}
                onClick={() => setKfs(kfs.filter((_, j) => j !== i))}>✕</button>
            </div>
          ))}
        </div>
        <div className="hint">Times in seconds. Keyframe 1 is the anchored source (t=0, az 0, el 0, dist 1×) and stays locked. Workflow: drag the camera on the canvas → set the ⏱ Timeline → add a keyframe (or just press add — it finds a free time for you).</div>
      </Field>

      <hr className="hr" />
      <h2><span className="step">B</span> Path settings</h2>

      <div className="row">
        <Field label={<span>Duration <span className="rangeval">{duration}s</span></span>}>
          <input type="range" min="4" max="15" step="1" value={duration} onChange={(e) => changeDuration(+e.target.value)} />
        </Field>
        <Field label="Interpolation">
          <select value={interp} onChange={(e) => setInterp(e.target.value)}>
            <option value="smooth">Smooth (eased)</option>
            <option value="linear">Linear per segment</option>
          </select>
        </Field>
      </div>
      <div className="row">
        <Field label="Prompt detail">
          <select value={detail} onChange={(e) => setDetail(e.target.value)}>
            <option value="extended">Extended contracts</option>
            <option value="baseline">v15 baseline</option>
          </select>
        </Field>
        <Field label="Aspect ratio">
          <select value={ratio} onChange={(e) => setRatio(e.target.value)}>
            {['16:9', '9:16', '1:1', '4:3', '3:4', '21:9'].map((r) => <option key={r}>{r}</option>)}
          </select>
        </Field>
      </div>

      <Field label="Subject box" opt="optional — off-centre subject, normalized 0–1">
        <input type="text" value={subjectBox} onChange={(e) => setSubjectBox(e.target.value)}
          placeholder="[L=0.62, T=0.18, W=0.24, H=0.55] — empty = full image" />
      </Field>
      <Field label="Extra instruction">
        <input type="text" value={instruction} onChange={(e) => setInstruction(e.target.value)}
          placeholder="e.g. keep the car paint reflections crisp; reveal the badge in the final third" />
      </Field>

      <div className="connbox" style={{ marginBottom: 14, fontFamily: 'var(--mono)', fontSize: 11.5, lineHeight: 1.75, whiteSpace: 'pre-wrap' }}>
        {diag.join('\n')}
      </div>

      <button className="btn primary big" onClick={compile}>🛰️ Compile camera-path prompt</button>
      <div className="hint" style={{ textAlign: 'center', marginTop: 8 }}>
        Prompts are semantic direction, not geometric conditioning — H3 may still miss angle, scale or timing. Pairs
        with H3 Edit (source image) or H3 Ref2VA in ComfyUI. Credit: Bruxos do VFX.
      </div>
    </div>
  )
}
