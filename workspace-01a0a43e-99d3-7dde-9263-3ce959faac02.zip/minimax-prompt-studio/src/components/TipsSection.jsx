const TIPS = [
  [null, <><b>Bracket commands are gone.</b> Hailuo-style <code>[Push in]</code> tokens are dead — write camera motion as natural English. Brackets are reserved for shot numbers: <code>[Shot 1]</code>.</>],
  [null, <><b>Camera = type + amplitude + speed.</b> “The camera pushes in with small amplitude at slow speed toward the folded letter.” Omit amplitude for medium, speed for normal.</>],
  [null, <><b>Say static out loud.</b> Write “the camera holds a static shot” or the frame drifts.</>],
  [null, <><b>One continuous move per shot</b> tracks far better than several abrupt ones.</>],
  [null, <><b>Audio in three places:</b> diegetic sound inside the shot, ambience in <code>overall_soundscape</code>, score in <code>non_diegetic_music</code> (or <code>N/A</code>).</>],
  [null, <><b>Dialogue:</b> tag speakers (S1)/(S2) and wrap the line with its language: <code>says: "[English] …"</code>. Eleven languages are stable.</>],
  [null, <><b>Multi-shot:</b> number shots and timecode every cut — “[Shot 2] At 00:05.000, the camera cuts to…” Cut only when new information arrives; otherwise move the camera.</>],
  [null, <><b>No seed, no negative prompt</b> on the hosted API. Prose negation works: “no soft dissolves or fluid morphs”.</>],
  [null, <><b>References get jobs:</b> “Image 1 for mood and location, Image 2 for the talent…” beats vague uploads. Max 12 files (9 images, 3 videos, 3 audios).</>],
  [null, <><b>Limits:</b> 768P or 2K (no 1080p/4K), 5–15 whole seconds (default 6), 24 fps, 7,000 characters per text item. Text-to-video needs a concrete aspect ratio.</>],
  [null, <><b>Draft cheap:</b> render at 768P first (~$0.08/s), re-roll the winner at 2K (~$0.13/s).</>],
  [null, <><b>Lock identity with feature lists.</b> When a character/product/set must survive the whole clip, enumerate its defining details once: "half-up long black hair, openwork silver crown, indigo ribbon, deep-blue sash, long tassels." Named features give the model something concrete to hold onto.</>],
  [null, <><b>Describe transitions as events.</b> Physical actions beat effect names: "fast scan with whip movement, motion blur, optical smearing, brief exposure flicker — cut at peak blur, then snap back into focus."</>],
  [null, <><b>Direct audio like picture.</b> Name the exact sounds ("ice tapping crystal, faint cigar burn, room air, clothing movement"); for score, describe instrumentation AND structure over time, including where the beat lands.</>],
  [null, <><b>Negate specifically.</b> "No tearing, black frames, hard cuts, obvious VFX or compositing seams" keeps stylized scenes from sliding into a nearby genre.</>],
  [null, <><b>Storyboard against the clock.</b> Plan beats inside the duration (0-2s hook → develop → resolve) — timed blocks keep pacing from drifting into a slideshow.</>],
  [null, <><b>LTX-Video mode:</b> one flowing present-tense paragraph — main action first, literal gesture detail, one coherent light setup, camera with an end-state ("settles on…"), dialogue in quotation marks. No labels, brackets or quality-tag tails.</>],
]

export default function TipsSection() {
  return (
    <section className="block">
      <h2>💡 MiniMax H3 cheat-sheet</h2>
      <ul className="tips">
        {TIPS.map((t, i) => <li key={i}>{t[1]}</li>)}
      </ul>
    </section>
  )
}
