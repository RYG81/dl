import { useState } from 'react'
import { EXAMPLES } from '../lib/examples.js'
import { copyText } from '../lib/format.js'

export default function ExampleLibrary({ toast }) {
  const [filter, setFilter] = useState('All')
  const cats = [...new Set(EXAMPLES.map((e) => e.cat))]
  const list = EXAMPLES.filter((e) => filter === 'All' || e.cat === filter)

  return (
    <section className="block">
      <h2>
        📚 Example library — one hand-written exemplar per category
        <select value={filter} onChange={(e) => setFilter(e.target.value)}
          style={{ float: 'right', width: 'auto', minWidth: 250, fontSize: 13 }}>
          <option>All</option>
          {cats.map((c) => <option key={c}>{c}</option>)}
        </select>
      </h2>
      <div style={{ color: 'var(--dim)', fontSize: 13, margin: '-4px 0 14px' }}>
        H3-correct exemplars you can copy as-is or load into the form — and when you generate with Ollama, the
        best-matching example is automatically injected as few-shot knowledge, so even small local models reproduce
        the format perfectly. <span className="vmeta">showing {list.length} of {EXAMPLES.length}</span>
      </div>
      <div className="cards">
        {list.map((ex) => (
          <div key={ex.title} className="tpl">
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
              <span className="t" style={{ margin: 0 }}>{ex.title}</span>
              <span className={'badge' + (ex.ref ? ' gold' : '')}>{ex.cat}</span>
              <span className="vmeta" style={{ marginLeft: 'auto' }}>{ex.prompt.length} chars</span>
            </div>
            <div className="d">{ex.blurb}</div>
            <pre style={{ maxHeight: 190, overflow: 'auto' }}>{ex.prompt}</pre>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <button className="btn tiny primary" onClick={async () => { await copyText(ex.prompt); toast('Example prompt copied') }}>
                📋 Copy prompt
              </button>
              <button className="btn tiny" onClick={() => window.dispatchEvent(new CustomEvent('cps-load-example', { detail: ex }))}>
                ⤴ Load into form
              </button>
              <button className="btn tiny ghost" onClick={() => window.dispatchEvent(new CustomEvent('cps-load-idea', { detail: ex.idea }))}>
                Use idea only
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
