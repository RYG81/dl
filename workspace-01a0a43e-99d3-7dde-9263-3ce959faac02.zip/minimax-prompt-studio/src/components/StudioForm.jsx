import { useEffect, useState } from 'react'
import { Chips } from './ui.jsx'
import MatureModal from './MatureModal.jsx'
import { streamChat, extractPartial, extractLabeled, finalizeOutput, modelLabel } from '../lib/ollama.js'
import { buildUserMessage } from '../lib/prompts.js'
import { genVariantOffline, genVariantLtxOffline, SURPRISE } from '../lib/offline.js'
import { unloadModel } from '../lib/ollama.js'
import { buildUserMessageLtx } from '../lib/prompts.js'
import { EXAMPLES, pickExemplar } from '../lib/examples.js'

const CATEGORIES = [
  'Cinematic Film Scene', 'Multi-Shot Sequence', 'Dialogue Scene', 'Commercial / Brand Film',
  'Short Drama (vertical)', 'Social Media Content', 'Music Video', 'Documentary',
  'Product Showcase', 'Nature / Landscape', 'Sci-Fi / Fantasy', 'Animation', 'Fashion / Lifestyle',
  '— reference tasks —',
  'Video Editing (reference)', 'Video Continuation (reference)', 'Motion Transfer (reference)',
  'Keyframe Completion (reference)', 'Audio Reuse (reference)', 'Auto',
]
const STYLES = ['Auto', 'Cinematic', 'Live-Action', '2D Animated', '3D CG', 'Claymation', 'Watercolor',
  'Vintage Film', 'Documentary / Handheld', 'Film Noir', 'Anime', 'High Fashion', 'Neon / Cyberpunk',
  'Slow Motion', 'Timelapse']
const CAMERAS = ['Auto', 'Static shot', 'Push in', 'Pull out', 'Zoom in', 'Zoom out', 'Pan left', 'Pan right',
  'Truck left', 'Truck right', 'Tilt up', 'Tilt down', 'Pedestal up', 'Pedestal down', 'Arc shot',
  'Tracking shot', 'Shake slightly', 'Shake strongly', 'POV', 'Roll clockwise', 'Roll counterclockwise']
const RATIOS = ['16:9', '9:16', '1:1', '4:3', '3:4', '21:9']
const DLANGS = ['English', 'Chinese', 'Spanish', 'French', 'German', 'Italian', 'Japanese', 'Korean',
  'Portuguese', 'Russian', 'Arabic']
const PALETTES = ['Auto', 'Dawn Bakery', 'Teal and Orange', 'Neon Night', 'High Fashion Mono',
  'Desert Highway', 'Cold Noir', 'Vintage Film', 'Rain Window']
const PALETTE_LABELS = { 'Teal and Orange': 'Teal & Orange', 'High Fashion Mono': 'Mono' }
const MUSIC = { auto: 'Auto', none: 'None (N/A)', subtle: 'Subtle underscore', full: 'Full score', beat: 'Beat-driven' }

function deriveTitle(idea) {
  const t = ((idea || '').split(/[,.\n]/)[0] || '').trim().split(/\s+/).slice(0, 5).join(' ')
  return t ? t.charAt(0).toUpperCase() + t.slice(1) : 'Generated shot'
}

const F0 = {
  idea: '', category: 'Cinematic Film Scene', style: 'Auto', structure: 'single', camera: 'Auto',
  amp: 'medium', speed: 'normal', ratio: '16:9', resolution: '768P', duration: 6, music: 'auto',
  ambience: '', dialogue: '', dlang: 'English', palette: 'Auto', negation: '', extra: '',
  engine: 'auto', variants: '1', temperature: 0.8, enhance: false, fewshot: true, detail: true,
  target: (typeof localStorage !== 'undefined' && localStorage.getItem('cps_target')) || 'h3',
  mature: (typeof localStorage !== 'undefined' && localStorage.getItem('cps_nsfw') === 'on'),
}

export default function StudioForm({ conn, setModel, sysPrompt, ltxSysPrompt, pushCard, updateCard, pushHistory, setStatus, toast }) {
  const [f, setF] = useState(F0)
  const [busy, setBusy] = useState(false)
  const [gateOpen, setGateOpen] = useState(false)
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }))

  // load-example events from the library + history restore
  useEffect(() => {
    const onLoad = (e) => {
      const ex = e.detail
      setF((p) => ({ ...p, idea: ex.idea, ...(ex.settings || {}) }))
      toast('Example loaded — press Generate 🎬')
    }
    const onIdea = (e) => {
      setF((p) => ({ ...p, idea: e.detail }))
      toast('Idea loaded — tweak & Generate')
    }
    const onRestore = (e) => {
      const h = e.detail || {}
      const inp = h.inp || {}
      setF((p) => ({
        ...p,
        idea: h.idea || inp.idea || '',
        category: inp.category || p.category, style: inp.style || p.style,
        structure: inp.structure || p.structure, camera: inp.camera || p.camera,
        amp: inp.amp || p.amp, speed: inp.speed || p.speed,
        ratio: inp.ratio || p.ratio, resolution: inp.resolution || p.resolution,
        duration: inp.duration || p.duration, music: inp.music || p.music,
        ambience: inp.ambience || '', dialogue: inp.dialogue || '', dlang: inp.dlang || p.dlang,
        palette: inp.palette || p.palette, negation: inp.negation || '', extra: inp.extra || '',
        enhance: !!inp.enhance,
        detail: inp.detail !== false,
        target: inp.target || p.target,
        mature: !!inp.mature,
      }))
      toast('History entry restored — tweak & Generate')
    }
    window.addEventListener('cps-load-example', onLoad)
    window.addEventListener('cps-load-idea', onIdea)
    window.addEventListener('cps-restore-entry', onRestore)
    return () => {
      window.removeEventListener('cps-load-example', onLoad)
      window.removeEventListener('cps-load-idea', onIdea)
      window.removeEventListener('cps-restore-entry', onRestore)
    }
  }, [toast])

  // Ctrl+Enter generates
  useEffect(() => {
    const h = (e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') generate() }
    document.addEventListener('keydown', h)
    return () => document.removeEventListener('keydown', h)
  })

  const cost = (f.duration * (f.resolution === '2K' ? 0.13 : 0.08)).toFixed(2)
  const useOllama = f.engine === 'ollama' || (f.engine === 'auto' && conn.status === 'ok' && conn.model)
  const engineNote = conn.status === 'ok'
    ? (f.engine === 'offline'
        ? 'Using the built-in instant engine.'
        : (conn.model
            ? 'Ready with ' + conn.model + ' — fully private, no cloud.'
            : 'Ollama connected but has no models yet — run: ollama pull <model-name>, then ↻ Re-check.'))
    : (f.engine === 'ollama'
        ? '⚠ Ollama not reachable — check it’s running (see ⚙️ Settings).'
        : 'No Ollama found — the built-in instant engine will be used. Connect Ollama for richer prompts.') + (f.target === 'ltx' ? ' · ⚡ LTX mode: one flowing paragraph, no labels.' : '')

  async function generate() {
    if (busy) return
    const inp = {
      idea: f.idea.trim(), category: f.category, style: f.style, structure: f.structure,
      camera: f.camera, amp: f.amp, speed: f.speed, ratio: f.ratio, resolution: f.resolution,
      duration: f.duration, music: f.music, ambience: f.ambience.trim(), dialogue: f.dialogue.trim(),
      dlang: f.dlang, palette: f.palette, negation: f.negation.trim(), extra: f.extra.trim(),
      enhance: f.enhance, detail: f.detail, target: f.target, mature: f.mature,
    }
    if (f.engine === 'ollama' && conn.status !== 'ok') { toast('⚠ Ollama isn’t reachable — see ⚙️ Settings'); return }
    if (!inp.idea && !inp.enhance) { toast('Describe your shot first ✍️'); return }
    const nVariants = +f.variants
    setBusy(true)
    setStatus('')
    const t0 = performance.now()
    let made = 0
    for (let k = 1; k <= nVariants; k++) {
      setStatus('Generating variant ' + k + ' of ' + nVariants + '…')
      try {
        let v
        if (useOllama) {
          v = await genOllama(inp, k, nVariants)
        } else {
          const id = 'c' + Math.random().toString(36).slice(2)
          pushCard({ id, kind: 'variant', v: null, streaming: true, inp })
          await new Promise((r) => setTimeout(r, 280))
          v = inp.target === 'ltx'
            ? await genVariantLtxOffline(inp, k, nVariants)
            : await genVariantOffline(inp, k, nVariants)
          if (!v.title) v.title = deriveTitle(inp.idea)
          updateCard(id, { v, streaming: false })
        }
        pushHistory(v, inp, 'studio')
        made++
      } catch (err) {
        pushCard({ id: 'e' + Math.random().toString(36).slice(2), kind: 'error', message: err.message })
      }
    }
    const dt = ((performance.now() - t0) / 1000).toFixed(1)
    let unloadNote = ''
    if (useOllama && made > 0) {
      const ok = await unloadModel(conn.base, conn.model)
      unloadNote = ok ? ' · 🧹 model unloaded (RAM/VRAM freed)' : ''
    }
    let exNote = ''
    if (useOllama && f.fewshot && inp.target === 'h3' && EXAMPLES.length) exNote = ' · 📚 taught by example: ' + pickExemplar(inp).title
    setStatus('✅ ' + made + ' variant' + (made === 1 ? '' : 's') + ' in ' + dt + 's · ' +
      (useOllama ? conn.model : 'instant offline engine') + ' · ' + inp.ratio + ' · ' + inp.resolution + ' · ' + inp.duration + 's' + exNote + unloadNote)
    setBusy(false)
  }

  async function genOllama(inp, k, nVariants) {
    const id = 'c' + Math.random().toString(36).slice(2)
    pushCard({ id, kind: 'variant', v: null, streaming: true, inp })
    const isLtx = inp.target === 'ltx'
    let sys = isLtx ? ltxSysPrompt.text : sysPrompt.text, exUsed = null
    if (!isLtx && f.fewshot && EXAMPLES.length) {
      exUsed = pickExemplar(inp)
      sys += '\n\nEXEMPLAR — ' + exUsed.cat + ' (' + exUsed.title + '). Match its format and grammar exactly. Its detail level is a floor, not a ceiling — write as fully as the scene deserves:\n' + exUsed.prompt
    }
    const temp = Math.min(1.2, f.temperature + 0.12 * (k - 1))
    const messages = [
      { role: 'system', content: sys },
      { role: 'user', content: isLtx ? buildUserMessageLtx(inp, k, nVariants) : buildUserMessage(inp, k, nVariants) },
    ]
    let acc = ''
    const t0 = performance.now()
    for await (const piece of streamChat(conn.base, conn.model, messages, temp, { json: isLtx })) {
      acc += piece
      const p = isLtx
        ? extractPartial(acc, 'prompt')
        : (extractLabeled(acc, 'integrated_multimodal_description') || extractPartial(acc, 'integrated_multimodal_description'))
      if (p) updateCard(id, { streamText: p })
    }
    const dt = ((performance.now() - t0) / 1000).toFixed(1)
    const v = finalizeOutput(acc, isLtx ? 'ltx' : 'h3')
    v.engine = 'ollama'; v.model = conn.model; v.secs = dt
    if (isLtx) v.target = 'ltx'
    if (exUsed) v.exemplar = exUsed.title
    if (!v.title) v.title = deriveTitle(inp.idea)
    updateCard(id, { v, streaming: false })
    return v
  }

  const ideaLen = f.idea.length
  return (
    <div>
      <fieldset className="grp">
        <legend><span className="step">1</span> Scene</legend>
        <div className="frow">
          <label>Target</label>
          <Chips values={['h3', 'ltx']} value={f.target}
            onChange={(v) => { set('target', v); try { localStorage.setItem('cps_target', v) } catch (e) {} }}
            labels={{ h3: '🎬 MiniMax H3', ltx: '⚡ LTX-Video 2.x' }} />
        </div>
        <div className="fwide">
          <label style={{ display: 'flex', gap: 8, fontSize: 10.5, fontWeight: 700, color: 'var(--dim)', textTransform: 'uppercase', letterSpacing: '.7px', marginBottom: 4 }}>
            Idea / scene <span className="opt" style={{ textTransform: 'none', letterSpacing: 0 }}>what do we see?</span>
            <span className={'count' + (ideaLen > 7000 ? ' over' : '')} style={{ marginLeft: 'auto' }}>{ideaLen} / 7000</span>
          </label>
          <textarea value={f.idea} onChange={(e) => set('idea', e.target.value)}
            placeholder="e.g. A street baker opens the shutters of a tiny bakery before sunrise and places the first loaf on the counter, steam rising in the cold air…" />
          <div className="hint">
            Describe what <b>happens over time</b> — scene, characters, actions. No word limit; go deep.{' '}
            <a href="#" onClick={(e) => {
              e.preventDefault()
              set('idea', SURPRISE[Math.floor(Math.random() * SURPRISE.length)])
              toast('Idea loaded — hit Generate 🎬')
            }}>🎲 Surprise me</a>
          </div>
        </div>
        <div className="frow">
          <label>Category</label>
          <select value={f.category} onChange={(e) => set('category', e.target.value)}>
            {CATEGORIES.map((c) => c.startsWith('—')
              ? <option key={c} disabled>{c}</option>
              : <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="frow">
          <label>Visual style</label>
          <select value={f.style} onChange={(e) => set('style', e.target.value)}>
            {STYLES.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div className="frow">
          <label>Palette</label>
          <Chips values={PALETTES} value={f.palette} onChange={(v) => set('palette', v)} labels={PALETTE_LABELS} />
        </div>
        <div className="frow">
          <label>Extra notes<span className="opt">optional</span></label>
          <input type="text" value={f.extra} onChange={(e) => set('extra', e.target.value)}
            placeholder="e.g. shallow depth of field, lens flares, rain, embers" />
        </div>
      </fieldset>

      <fieldset className="grp">
        <legend><span className="step">2</span> Camera</legend>
        <div className="frow">
          <label>Structure</label>
          <Chips values={['single', 'multi2', 'multi3']} value={f.structure} onChange={(v) => set('structure', v)}
            labels={{ single: 'Single shot', multi2: '2 cuts', multi3: '3 cuts' }} />
        </div>
        <div className="frow">
          <label>Motion</label>
          <select value={f.camera} onChange={(e) => set('camera', e.target.value)}>
            {CAMERAS.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="frow">
          <label>Amp / speed</label>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <Chips values={['small', 'medium', 'large']} value={f.amp} onChange={(v) => set('amp', v)}
              labels={{ small: 'S', medium: 'M', large: 'L' }} />
            <Chips values={['slow', 'normal', 'fast']} value={f.speed} onChange={(v) => set('speed', v)}
              labels={{ slow: 'Slow', normal: 'Normal', fast: 'Fast' }} />
          </div>
        </div>
        <div className="hint">Locked-off frame? Pick <b>Static shot</b> — H3 drifts unless you say it holds a static shot. Auto = engine picks the best move.</div>
      </fieldset>

      <fieldset className="grp">
        <legend><span className="step">3</span> Format</legend>
        <div className="frow">
          <label>Output</label>
          <div className="row" style={{ gridTemplateColumns: '1fr 1fr 1.2fr' }}>
            <select value={f.ratio} onChange={(e) => set('ratio', e.target.value)}>
              {RATIOS.map((r) => <option key={r}>{r}</option>)}
            </select>
            <select value={f.resolution} onChange={(e) => set('resolution', e.target.value)}>
              <option>768P</option><option>2K</option>
            </select>
            <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <input type="range" min="5" max="15" step="1" value={f.duration}
                onChange={(e) => set('duration', +e.target.value)} />
              <span className="rangeval">{f.duration}s</span>
            </span>
          </div>
        </div>
        <div className="hint">Draft at <b>768P</b> (~$0.08/s), re-roll the winner at <b>2K</b> (~$0.13/s). Current pick: <b>${cost}</b> · 24 fps fixed.</div>
      </fieldset>

      <fieldset className="grp">
        <legend><span className="step">4</span> Sound</legend>
        <div className="frow">
          <label>Music</label>
          <Chips values={Object.keys(MUSIC)} value={f.music} onChange={(v) => set('music', v)} labels={MUSIC} />
        </div>
        <div className="frow">
          <label>Ambience<span className="opt">optional</span></label>
          <input type="text" value={f.ambience} onChange={(e) => set('ambience', e.target.value)}
            placeholder="e.g. distant traffic, rain on glass, trays clinking" />
        </div>
        <div className="frow">
          <label>Spoken line<span className="opt">optional</span></label>
          <div className="row" style={{ gridTemplateColumns: '2fr 1fr' }}>
            <input type="text" value={f.dialogue} onChange={(e) => set('dialogue', e.target.value)}
              placeholder="e.g. First batch of the morning." />
            <select value={f.dlang} onChange={(e) => set('dlang', e.target.value)}>
              {DLANGS.map((l) => <option key={l}>{l}</option>)}
            </select>
          </div>
        </div>
        <div className="frow">
          <label>Negation<span className="opt">prose only</span></label>
          <input type="text" value={f.negation} onChange={(e) => set('negation', e.target.value)}
            placeholder="e.g. no soft dissolves or fluid morphs" />
        </div>
      </fieldset>

      <fieldset className="grp">
        <legend><span className="step">5</span> Engine</legend>
        <div className="frow">
          <label>Engine</label>
          <select value={f.engine} onChange={(e) => set('engine', e.target.value)}>
            <option value="auto">Auto — Ollama if connected</option>
            <option value="ollama">Ollama (force)</option>
            <option value="offline">Instant offline engine</option>
          </select>
        </div>
        <div className="frow">
          <label>Model</label>
          <select value={conn.model} onChange={(e) => setModel(e.target.value)}>
            {conn.models.length === 0 && <option value="">{conn.status === 'checking' ? '— detecting… —' : 'Ollama not detected'}</option>}
            {[...conn.models].sort((a, b) => a.name.localeCompare(b.name)).map((m) => (
              <option key={m.name} value={m.name}>{modelLabel(m)}</option>
            ))}
          </select>
        </div>
        <div className="frow">
          <label>Variants</label>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
            <Chips values={['1', '2', '3']} value={f.variants} onChange={(v) => set('variants', v)} />
            <span style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1, minWidth: 140 }}>
              <input type="range" min="0.2" max="1.2" step="0.05" value={f.temperature}
                onChange={(e) => set('temperature', +e.target.value)} />
              <span className="rangeval">{(+f.temperature).toFixed(2)}</span>
            </span>
          </div>
        </div>
        <div className="frow" style={{ alignItems: 'start' }}>
          <label style={{ paddingTop: 3 }}>Options</label>
          <div>
            <label className="checkboxrow">
              <input type="checkbox" checked={f.detail} onChange={(e) => set('detail', e.target.checked)} />
              🎨 Rich styling detail — adds lens, lighting-design &amp; texture intelligence for faithful styling
            </label>
            <label className="checkboxrow">
              <input type="checkbox" checked={f.fewshot} onChange={(e) => set('fewshot', e.target.checked)} />
              📚 Inject example knowledge (few-shot) for your category
            </label>
            <label className="checkboxrow">
              <input type="checkbox" checked={f.enhance} onChange={(e) => set('enhance', e.target.checked)} />
              ✨ Enhance mode — I'm pasting an existing draft; convert &amp; upgrade it
            </label>
            <label className="checkboxrow">
              <input type="checkbox" checked={f.mature} onChange={(e) => {
                if (e.target.checked && localStorage.getItem('cps_nsfw_consent') !== '1') { setGateOpen(true); return }
                set('mature', e.target.checked)
                try { localStorage.setItem('cps_nsfw', e.target.checked ? 'on' : 'off') } catch (err) {}
              }} />
              🔞 Mature themes — 18+ opt-in, adult themes handled with cinematic restraint
            </label>
          </div>
        </div>
      </fieldset>

      <button className="btn primary big" disabled={busy} onClick={generate}>
        {busy ? <><span className="spin"></span> Directing…</> : '🎬 Generate H3 Prompt'}
      </button>
      <div className="hint" style={{ textAlign: 'center', marginTop: 6 }}>{engineNote}</div>

      <MatureModal
        open={gateOpen}
        onCancel={() => setGateOpen(false)}
        onConfirm={() => {
          try { localStorage.setItem('cps_nsfw_consent', '1'); localStorage.setItem('cps_nsfw', 'on') } catch (e) {}
          set('mature', true)
          setGateOpen(false)
          toast('Mature themes enabled (18+)')
        }}
      />
    </div>
  )
}
