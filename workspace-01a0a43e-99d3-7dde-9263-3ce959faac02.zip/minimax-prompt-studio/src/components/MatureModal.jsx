import { useEffect } from 'react'

export default function MatureModal({ open, onConfirm, onCancel }) {
  useEffect(() => {
    if (!open) return
    const h = (e) => { if (e.key === 'Escape') onCancel() }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [open, onCancel])

  if (!open) return null
  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onCancel() }}>
      <div className="modal" role="dialog" aria-modal="true" style={{ width: 'min(560px,100%)' }}>
        <div className="modal-head">
          <h3>🔞 Mature themes — 18+ only</h3>
        </div>
        <div className="modal-body">
          <div className="connbox">
            <b style={{ color: 'var(--text)' }}>What this does</b>
            <div style={{ marginTop: 6 }}>
              Adds adult/mature thematic guidance to your generated prompts. The prompts themselves stay cinematic —
              mature moments are written through behavior, framing and light, with artistic restraint.
            </div>
            <div style={{ marginTop: 12, borderTop: '1px dashed var(--border)', paddingTop: 10 }}>
              <b style={{ color: 'var(--text)' }}>Your responsibility</b>
              <ul style={{ margin: '6px 0 0', paddingLeft: 18, display: 'grid', gap: 4 }}>
                <li>You confirm you are 18 or older.</li>
                <li>Fictional adult characters only — never minors, never real people or likenesses, never anything illegal.</li>
                <li>The prompts you generate and render are your responsibility — comply with your local laws.</li>
                <li>Respect the policies of whatever platform you render on.</li>
              </ul>
            </div>
            <div style={{ marginTop: 12, borderTop: '1px dashed var(--border)', paddingTop: 10, color: 'var(--accent)' }}>
              ⚠ Hosted services (MiniMax / Hailuo APIs) typically refuse adult content — this option is mainly useful
              for local workflows like LTX-Video.
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 14, justifyContent: 'flex-end' }}>
            <button className="btn" onClick={onCancel}>Cancel</button>
            <button className="btn primary" onClick={onConfirm}>I'm 18+ and accept responsibility</button>
          </div>
        </div>
      </div>
    </div>
  )
}
