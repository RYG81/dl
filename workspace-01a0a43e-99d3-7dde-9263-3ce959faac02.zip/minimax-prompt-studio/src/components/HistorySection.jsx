import { useState } from 'react'
import { copyText, downloadText, fullPromptText, mainPromptText, esc, highlight } from '../lib/format.js'

function engineLabel(v) {
  if (v.engine === 'ollama') return v.model || 'ollama'
  if (v.engine === 'camera-director') return 'camera director'
  return 'instant engine'
}

export default function HistorySection({ history, onReuse, onDelete, onClear, toast }) {
  const [open, setOpen] = useState(-1)

  return (
    <section className="block">
      <h2>
        🕘 Generated prompts
        <span className="vmeta">{history.length} saved (max 50, newest first)</span>
        <span className="spacer" style={{ flex: 1 }}></span>
        {history.length > 0 && (
          <button className="btn tiny ghost" onClick={() => { onClear(); toast('History cleared') }}>
            🗑 Clear all
          </button>
        )}
      </h2>

      {history.length === 0 && (
        <div className="empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="#8e97ab" strokeWidth="1.4">
            <circle cx="12" cy="12" r="9" />
            <path d="M12 7v5l3 3" />
          </svg>
          <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--dim)' }}>No prompts yet</div>
          <div style={{ marginTop: 6, fontSize: 12.5 }}>
            Everything you generate in the Studio or Camera Director lands here automatically.
          </div>
        </div>
      )}

      {history.length > 0 && (
        <div className="htable">
          <div className="hhead">
            <span>When</span><span>Prompt</span><span>Engine</span><span>Actions</span>
          </div>
          {history.map((h, i) => {
            const v = h.v || {}
            const desc = mainPromptText(v)
            const label = v.target === 'ltx' ? 'prompt' : 'integrated_multimodal_description'
            const mode = h.mode || (v.engine === 'camera-director' ? 'camera' : 'studio')
            const isOpen = open === i
            return (
              <div key={h.ts + '-' + i}>
                <div className={'hrow' + (isOpen ? ' open' : '')} onClick={() => setOpen(isOpen ? -1 : i)}
                  title={isOpen ? 'Collapse' : 'Expand full prompt'}>
                  <div>
                    <div style={{ color: 'var(--dim)', fontSize: 11.5 }}>{new Date(h.ts).toLocaleString()}</div>
                    <span className={'hmode ' + mode}>{mode}</span>
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div className="t">🎬 {v.title || 'Untitled'}</div>
                    <div className="p">{desc.replace(/\s+/g, ' ').slice(0, 160)}…</div>
                  </div>
                  <div className="m">
                    {engineLabel(v)}
                    {h.inp && h.inp.ratio && <div>{h.inp.ratio} · {h.inp.resolution} · {h.inp.duration}s</div>}
                  </div>
                  <div className="hacts" onClick={(e) => e.stopPropagation()}>
                    <button className="btn tiny" title="Copy full prompt"
                      onClick={async () => { await copyText(fullPromptText(v)); toast('Copied from history') }}>📋</button>
                    <button className="btn tiny" title="Download .txt"
                      onClick={() => downloadText(
                        'h3-prompt-' + (v.title || 'untitled').toLowerCase().replace(/\W+/g, '-').slice(0, 40) + '.txt',
                        fullPromptText(v))}>⬇</button>
                    {mode === 'studio' && h.inp && (
                      <button className="btn tiny" title="Load settings back into the Studio"
                        onClick={() => onReuse(h)}>⤴</button>
                    )}
                    <button className="btn tiny ghost" title="Delete" onClick={() => { onDelete(i); setOpen(-1) }}>✕</button>
                  </div>
                </div>
                {isOpen && (
                  <div className="hdetail">
                    {h.idea && <div className="hint" style={{ marginBottom: 6 }}>💡 idea: {h.idea}</div>}
                    <div className="promptbox" dangerouslySetInnerHTML={{
                      __html: '<span class="sec">' + label + ':</span> ' + highlight(desc) +
                        (v.target === 'ltx'
                          ? (v.negative_prompt ? '\n\n<span class="sec">negative_prompt:</span> ' + esc(v.negative_prompt) : '')
                          : '\n\n<span class="sec">overall_soundscape:</span> ' + esc(v.overall_soundscape || '') +
                            '\n\n<span class="sec">non_diegetic_music:</span> ' + esc(v.non_diegetic_music || 'N/A')),
                    }} />
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </section>
  )
}
