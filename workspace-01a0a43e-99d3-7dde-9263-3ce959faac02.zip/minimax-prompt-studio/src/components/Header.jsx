export default function Header({ conn, onRecheck, onSettings }) {
  const dot = conn.status === 'ok' ? 'ok' : conn.status === 'checking' ? 'warn' : 'bad'
  const text =
    conn.status === 'checking'
      ? 'Checking Ollama…'
      : conn.status === 'ok'
        ? `Ollama · ${conn.base === location.origin + '/ollama' ? 'local proxy' : conn.base} · ${conn.models.length} model${conn.models.length === 1 ? '' : 's'}`
        : 'Ollama offline — instant engine active'

  return (
    <header>
      <div className="logo">
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <rect x="2" y="8" width="20" height="12" rx="2" fill="#f0b429" />
          <path d="M2.6 7.6L20.8 3.2l.8 3.4L3.4 11z" fill="#4cc9f0" />
          <circle cx="8" cy="14" r="2" fill="#0a0d13" />
          <rect x="12" y="13" width="7" height="2" rx="1" fill="#0a0d13" />
        </svg>
        <div>
          CinePrompt Studio
          <small>MiniMax H3 video prompt generator · local-first · Ollama-powered</small>
        </div>
      </div>
      <span className="badge gold">H3 three-section format</span>
      <span className="badge">scene-first · styling intelligence · native audio</span>
      <div className="spacer"></div>
      <span className="pill" title={text}>
        <span className={'dot ' + dot}></span>
        <span>{text}</span>
      </span>
      <button className="btn tiny" title="Re-check Ollama connection" onClick={onRecheck}>
        ↻ Re-check
      </button>
      <button className="btn tiny" title="Ollama settings" onClick={onSettings}>
        ⚙️ Settings
      </button>
    </header>
  )
}
