import { useState } from 'react'
import { scoreH3 } from '../lib/scoring.js'
import { esc, highlight, fullPromptText, copyText, downloadText } from '../lib/format.js'

function LtxCard({ card, toast }) {
  const { v, inp } = card
  const words = (v.prompt || '').split(/\s+/).filter(Boolean).length
  const meta = v.engine === 'ollama' ? `${v.model} · ${v.secs}s` : 'instant engine'
  return (
    <div className="variant">
      <div className="vhead">
        <span className="vtitle">⚡ {v.title}</span>
        <span className="vmeta">LTX-Video · {meta} · {esc(inp.ratio)} · {inp.duration}s</span>
      </div>
      <div className="vbody">
        <div className="promptbox" dangerouslySetInnerHTML={{
          __html: '<span class="sec">prompt:</span> ' + esc(v.prompt) +
            '\n\n<span class="sec">negative_prompt:</span> ' + esc(v.negative_prompt || ''),
        }} />
        {(v.tags || []).length > 0 && (
          <div style={{ marginTop: 8 }}>{v.tags.map((t) => <span key={t} className="tagpill">{t}</span>)}</div>
        )}
      </div>
      <div className="vfoot">
        <button className="btn tiny primary" onClick={async () => { await copyText(v.prompt); toast('LTX prompt copied') }}>📋 Copy prompt</button>
        <button className="btn tiny" onClick={async () => { await copyText(v.negative_prompt || ''); toast('Negative prompt copied') }}>Copy negative</button>
        <button className="btn tiny" onClick={async () => { await copyText(fullPromptText(v)); toast('Full block copied') }}>Copy full</button>
        <button className="btn tiny" onClick={() => downloadText(
          'ltx-prompt-' + (v.title || '').toLowerCase().replace(/\W+/g, '-').slice(0, 40) + '.txt',
          fullPromptText(v) + '\n\n— CinePrompt Studio · LTX-Video 2.x\nTitle: ' + v.title)}>⬇ .txt</button>
        <span className="score">{words} words · one flowing paragraph</span>
      </div>
    </div>
  )
}

function useTabs(initial) {
  const [tab, setTab] = useState(initial)
  return [tab, setTab]
}

function VariantCard({ card, toast }) {
  const [tab, setTab] = useTabs('prompt')
  const { v, streaming, streamText, inp } = card

  if (streaming) {
    return (
      <div className="variant">
        <div className="vhead">
          <span className="vtitle">🎬 Directing…</span>
          <span className="vmeta">{esc(inp.ratio)} · {esc(inp.resolution)} · {inp.duration}s</span>
        </div>
        <div className="vbody">
          <div className={'promptbox' + (streamText ? '' : ' shimmer')}>
            {streamText || 'Directing your shot…'}
          </div>
        </div>
      </div>
    )
  }
  if (!v) return null
  if (v.target === 'ltx') return <LtxCard card={card} toast={toast} />

  const sc = scoreH3(v, inp)
  const meta = v.engine === 'ollama' ? `${v.model} · ${v.secs}s` : 'instant engine'
  const tabs = [
    ['prompt', 'Prompt'], ['breakdown', 'Breakdown'], ['checks', `Audit ${sc.pct}%`], ['json', 'JSON'],
  ]
  return (
    <div className="variant">
      <div className="vhead">
        <span className="vtitle">🎬 {v.title}</span>
        <span className="vmeta">{meta} · {esc(inp.ratio)} · {esc(inp.resolution)} · {inp.duration}s</span>
      </div>
      <div className="tabs">
        {tabs.map(([id, label]) => (
          <button key={id} className={'tab' + (tab === id ? ' on' : '')} onClick={() => setTab(id)}>{label}</button>
        ))}
      </div>
      <div className="vbody">
        {tab === 'prompt' && !v.integrated_multimodal_description && (
          <div className="promptbox" style={{ color: 'var(--red)' }}>
            ⚠ The model returned no integrated_multimodal_description content.
            Raw output kept in the JSON tab — try a bigger model or re-generate.
          </div>
        )}
        {tab === 'prompt' && v.integrated_multimodal_description && !(v.overall_soundscape || '').trim() && !(v.non_diegetic_music || '').trim() && (
          <div className="hint" style={{ color: 'var(--accent)', marginBottom: 8 }}>
            ⚠ The model only returned the description — the soundscape/music fields came back empty. A bigger model
            usually returns all three fields; you can still copy the description as-is.
          </div>
        )}
        {tab === 'prompt' && v.integrated_multimodal_description && (
          <div className="promptbox" dangerouslySetInnerHTML={{
            __html: '<span class="sec">integrated_multimodal_description:</span> ' +
              highlight(v.integrated_multimodal_description) +
              '\n\n<span class="sec">overall_soundscape:</span> ' + esc(v.overall_soundscape) +
              '\n\n<span class="sec">non_diegetic_music:</span> ' + esc(v.non_diegetic_music || 'N/A'),
          }} />
        )}
        {tab === 'breakdown' && (
          <div className="kv">
            <b>Shot plan</b>
            <span>{(v.shot_plan || []).map((s, i) => <span key={i}>• {s}<br /></span>)}</span>
            <b>Full soundscape</b><span>{v.overall_soundscape}</span>
            <b>Score</b><span>{v.non_diegetic_music || 'N/A'}</span>
            <b>Tags</b>
            <span>{(v.tags || []).map((t) => <span key={t} className="tagpill">{t}</span>)}</span>
          </div>
        )}
        {tab === 'checks' && (
          <div className="checks">
            {sc.checks.map((c, i) => (
              <div key={i}><span className={c[0] ? 'y' : 'n'}>{c[0] ? '✔' : '✘'}</span>{c[1]}</div>
            ))}
          </div>
        )}
        {tab === 'json' && <div className="promptbox">{JSON.stringify(v, null, 2)}</div>}
      </div>
      <div className="vfoot">
        <button className="btn tiny primary" onClick={async () => { await copyText(fullPromptText(v)); toast('Full H3 prompt copied') }}>📋 Copy full prompt</button>
        <button className="btn tiny" onClick={async () => { await copyText(v.integrated_multimodal_description); toast('Visual description copied') }}>Copy visual only</button>
        <button className="btn tiny" onClick={() => downloadText(
          'h3-prompt-' + v.title.toLowerCase().replace(/\W+/g, '-').slice(0, 40) + '.txt',
          fullPromptText(v) + '\n\n— CinePrompt Studio · MiniMax H3\nTitle: ' + v.title + '\nTags: ' + (v.tags || []).join(', '))}>⬇ .txt</button>
        <span className="score">{sc.pct}% H3-compliant<span className="meter"><i style={{ width: sc.pct + '%' }}></i></span></span>
      </div>
    </div>
  )
}

function CameraCard({ card, toast }) {
  const [tab, setTab] = useTabs('p')
  const { res, opts } = card
  const netTxt = (res.net >= 0 ? '+' : '') + res.net.toFixed(0) + '°'
  return (
    <div className="variant">
      <div className="vhead">
        <span className="vtitle">🛰️ Camera path · {netTxt} over {opts.duration}s</span>
        <span className="vmeta">
          {res.segments.length} segment{res.segments.length > 1 ? 's' : ''} · {opts.interp} · {opts.detail}
          {res.closes ? ' · loop closed' : ''} · {opts.frame}
        </span>
      </div>
      <div className="tabs">
        <button className={'tab' + (tab === 'p' ? ' on' : '')} onClick={() => setTab('p')}>Prompt</button>
        <button className={'tab' + (tab === 'c' ? ' on' : '')} onClick={() => setTab('c')}>Choreography</button>
        <button className={'tab' + (tab === 'j' ? ' on' : '')} onClick={() => setTab('j')}>JSON plan</button>
      </div>
      <div className="vbody">
        {tab === 'p' && <div className="promptbox">{res.sections}</div>}
        {tab === 'c' && <div className="promptbox">{res.choreo}</div>}
        {tab === 'j' && <div className="promptbox">{JSON.stringify(res.plan, null, 2)}</div>}
      </div>
      <div className="vfoot">
        <button className="btn tiny primary" onClick={async () => { await copyText(res.sections); toast('Camera-path prompt copied') }}>📋 Copy full prompt</button>
        <button className="btn tiny" onClick={async () => { await copyText(res.choreo); toast('Choreography copied') }}>Copy choreography</button>
        <button className="btn tiny" onClick={() => downloadText('h3-camera-path.txt',
          res.sections + '\n\n— CinePrompt Studio · 3D camera path\nNet ' + netTxt + ' · ' + opts.duration + 's')}>⬇ .txt</button>
        <span className="score">{res.travel.toFixed(0)}° travelled · avg {(res.travel / opts.duration).toFixed(0)}°/s</span>
      </div>
    </div>
  )
}

export default function OutputPanel({ cards, status }) {
  const toastRef = (m) => window.dispatchEvent(new CustomEvent('cps-toast', { detail: m }))
  return (
    <section className="panel">
      <h2><span className="step">✦</span> Generated prompts</h2>
      <div className="sub">Copy straight into the MiniMax platform, Hailuo AI, fal or ComfyUI.</div>
      <div className="statusbar">{status}</div>
      <div>
        {cards.length === 0 && (
          <div className="empty">
            <svg viewBox="0 0 24 24" fill="none" stroke="#8e97ab" strokeWidth="1.4">
              <rect x="2" y="7" width="20" height="13" rx="2" />
              <path d="M3 4l18-2.5V6L3 8.5z" />
              <path d="M7 11h6M7 15h10" />
            </svg>
            <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--dim)' }}>No prompts yet</div>
            <div style={{ marginTop: 6, fontSize: 13 }}>
              Describe a shot on the left and hit <b>Generate</b>.<br />
              Works instantly offline — or with your local Ollama model for richer results.
            </div>
          </div>
        )}
        {cards.map((c) => {
          if (c.kind === 'variant') return <VariantCard key={c.id} card={c} toast={toastRef} />
          if (c.kind === 'camera') return <CameraCard key={c.id} card={c} toast={toastRef} />
          if (c.kind === 'error') return (
            <div key={c.id} className="variant">
              <div className="vbody" style={{ color: 'var(--red)' }}>
                ⚠ {c.message}
                <div className="hint" style={{ marginTop: 8 }}>
                  If this is a CORS error, run the app with <code>npm run dev</code> (the Vite proxy removes CORS entirely).
                </div>
              </div>
            </div>
          )
          return null
        })}
      </div>
    </section>
  )
}
