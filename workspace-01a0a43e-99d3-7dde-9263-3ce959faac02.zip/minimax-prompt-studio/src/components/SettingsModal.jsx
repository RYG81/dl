import { useEffect, useState } from 'react'
import { fmtBytes, fmtAgo } from '../lib/ollama.js'

export default function SettingsModal({ open, onClose, conn, setModel, detect, sysPrompt, setSysPrompt, toast }) {
  const [customBase, setCustomBase] = useState(() => localStorage.getItem('cps_ollama_base') || '')

  useEffect(() => { if (open) setCustomBase(localStorage.getItem('cps_ollama_base') || '') }, [open])

  // Esc closes
  useEffect(() => {
    if (!open) return
    const h = (e) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [open, onClose])

  if (!open) return null

  const useBase = () => {
    const v = customBase.trim().replace(/\/$/, '')
    if (v) localStorage.setItem('cps_ollama_base', v)
    else localStorage.removeItem('cps_ollama_base')
    detect(v || undefined)
  }

  const onFile = (e) => {
    const f = e.target.files[0]
    if (!f) return
    f.text().then((t) => {
      const txt = t.trim()
      if (!txt) { toast('That file is empty'); return }
      setSysPrompt({ text: txt, status: 'override', name: f.name })
      toast('System prompt overridden with ' + f.name)
    })
  }

  const reload = () => {
    window.dispatchEvent(new Event('cps-reload-sysprompt'))
    toast('Reloading system prompt…')
  }

  const statusTxt =
    sysPrompt.status === 'loading' ? 'loading…'
      : sysPrompt.status === 'ok' ? <>✓ prompts/system-prompt.md · {sysPrompt.text.length} chars</>
      : sysPrompt.status === 'override' ? <>✓ {sysPrompt.text.length} chars — override: {sysPrompt.name} (session only)</>
      : <>⚠ system-prompt.md unreachable — built-in fallback active</>

  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="modal" role="dialog" aria-modal="true">
        <div className="modal-head">
          <h3>⚙️ Ollama settings &amp; help</h3>
          <div className="spacer"></div>
          <button className="btn tiny" onClick={onClose} title="Close (Esc)">✕ Close</button>
        </div>
        <div className="modal-body">
          <div className="connbox">
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap', alignItems: 'baseline' }}>
              <b style={{ color: 'var(--text)' }}>Endpoint</b>
              <span>
                {conn.status === 'checking' && <span style={{ color: 'var(--dim)' }}>checking…</span>}
                {conn.status === 'ok' && (
                  <span style={{ color: 'var(--green)' }}>
                    ✓ connected · {conn.base === location.origin + '/ollama' ? 'local proxy (Vite)' : conn.base}
                  </span>
                )}
                {conn.status === 'bad' && <span style={{ color: 'var(--red)' }}>✗ not reachable</span>}
              </span>
            </div>
            <div style={{ margin: '4px 0 8px', fontSize: 11.5, color: 'var(--faint)' }}>
              Auto-detection order: saved/custom endpoint → same-origin <code>/ollama/*</code> (Vite dev proxy →{' '}
              <code>127.0.0.1:11434</code>, no CORS needed) → direct <code>http://localhost:11434</code> →{' '}
              <code>http://127.0.0.1:11434</code>. Whatever Ollama reports via <code>/api/tags</code> is listed — no
              model names are hardcoded.
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                type="text"
                value={customBase}
                onChange={(e) => setCustomBase(e.target.value)}
                placeholder="http://localhost:11434 or a LAN box like http://192.168.1.5:11434"
              />
              <button className="btn tiny" onClick={useBase}>Use &amp; re-check</button>
            </div>

            <div style={{ marginTop: 13, borderTop: '1px dashed var(--border)', paddingTop: 10 }}>
              <b style={{ color: 'var(--text)' }}>Detected models</b>{' '}
              <span style={{ fontSize: 11, color: 'var(--faint)' }}>
                {conn.models.length ? `· ${conn.models.length} found on ${conn.base}` : ''}
              </span>
              <div style={{ marginTop: 8, display: 'grid', gap: 6 }}>
                {conn.models.length === 0 && (
                  <div style={{ fontSize: 12, color: 'var(--faint)' }}>
                    Nothing detected yet. Start Ollama (<code>ollama serve</code>), pull any model (
                    <code>ollama pull &lt;name&gt;</code>), then hit ↻ Re-check.
                  </div>
                )}
                {[...conn.models]
                  .sort((a, b) => a.name.localeCompare(b.name))
                  .map((m) => {
                    const d = m.details || {}
                    const meta = [
                      d.family,
                      d.parameter_size ? d.parameter_size.replace(/\.0B/, 'B') : '',
                      d.quantization_level,
                      m.size ? fmtBytes(m.size) : '',
                      m.modified_at ? fmtAgo(m.modified_at) : '',
                    ].filter(Boolean).join(' · ')
                    const inUse = m.name === conn.model
                    return (
                      <div key={m.name} style={{
                        display: 'flex', gap: 8, alignItems: 'center', background: '#0a0e15',
                        border: '1px solid var(--border)', borderRadius: 8, padding: '6px 10px',
                      }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--text)', wordBreak: 'break-all' }}>
                            {m.name}
                          </div>
                          {meta && <div style={{ fontSize: 10.5, color: 'var(--faint)' }}>{meta}</div>}
                        </div>
                        <button className={'btn tiny' + (inUse ? ' primary' : '')}
                          onClick={() => { setModel(m.name); toast('Using ' + m.name) }}>
                          {inUse ? '✓ in use' : 'Use'}
                        </button>
                      </div>
                    )
                  })}
              </div>
              <div style={{ marginTop: 8, fontSize: 11.5, color: 'var(--faint)' }}>
                No models? Install Ollama from{' '}
                <a href="https://ollama.com" target="_blank" rel="noopener">ollama.com</a>, then add any chat model
                with <code>ollama pull &lt;model-name&gt;</code> — bigger models (7B and up) follow the H3 format more
                faithfully. Hit ↻ Re-check afterwards.
              </div>
            </div>

            <div style={{ marginTop: 13, borderTop: '1px dashed var(--border)', paddingTop: 10 }}>
              <b style={{ color: 'var(--text)' }}>Browser can't reach Ollama?</b>
              <div style={{ marginTop: 6 }}>
                With <code>npm run dev</code> the Vite proxy handles everything — nothing to configure. Only if you
                serve the built/static app from another origin, allow the browser to talk to Ollama once:
              </div>
              <pre>{`# Windows (PowerShell, before starting Ollama)
$env:OLLAMA_ORIGINS="*"; ollama serve

# macOS / Linux
OLLAMA_ORIGINS=* ollama serve`}</pre>
            </div>

            <div style={{ marginTop: 13, borderTop: '1px dashed var(--border)', paddingTop: 10 }}>
              <b style={{ color: 'var(--text)' }}>System prompt</b> (external file):{' '}
              <span style={{ color: 'var(--dim)' }}>{statusTxt}</span>
              <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                <label className="btn tiny" style={{ cursor: 'pointer' }}>
                  📂 Override with local .md
                  <input type="file" accept=".md,.txt" style={{ display: 'none' }} onChange={onFile} />
                </label>
                <button className="btn tiny ghost" onClick={reload}>↻ Reload from file</button>
              </div>
              <div style={{ marginTop: 6 }}>
                Edit <code>public/prompts/system-prompt.md</code> to re-tune how the LLM writes H3 prompts — no code
                changes needed.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
