import { useState } from 'react'
import { TEMPLATES } from '../lib/templates.js'
import { copyText } from '../lib/format.js'

const TAG_LABELS = {
  person: '👤 Person', product: '📦 Product', landscape: '🏔 Landscape',
  animation: '🎨 Animation', dialogue: '💬 Dialogue', multi: '🎞 Multi-shot',
  vertical: '📱 Vertical', music: '🎵 Music',
}

export default function TemplatesSection({ templates, source, toast }) {
  const [filter, setFilter] = useState('All')
  const LIB = templates && templates.length ? templates : TEMPLATES
  const tags = ['All', ...Object.keys(TAG_LABELS)]
  const list = LIB.filter((tp) => filter === 'All' || tp.tag === filter)

  return (
    <section className="block">
      <h2>
        📋 Prompt templates
        <span className="vmeta">one per video type · {list.length} shown</span>
      </h2>
      <div style={{ color: 'var(--dim)', fontSize: 12.5, margin: '-4px 0 10px' }}>
        Fill-in skeletons in the exact three-field MiniMax format. <b>⤴ Load into Studio</b> prefills the idea and
        every setting — replace the <code>{'{PLACEHOLDERS}'}</code> and hit Generate.{' '}
        <span className="vmeta">
          {source === 'loading' ? 'loading templates…' : 'loaded from ' + source + ' — edit that file to add your own (↻ Reload from settings)'}
        </span>
      </div>
      <div className="chips" style={{ marginBottom: 12 }}>
        {tags.map((tg) => (
          <span key={tg} className={'chip' + (filter === tg ? ' on' : '')} onClick={() => setFilter(tg)}>
            {tg === 'All' ? 'All' : TAG_LABELS[tg]}
          </span>
        ))}
      </div>
      <div className="cards">
        {list.map((tp) => (
          <div key={tp.t} className="tpl">
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
              <span className="t" style={{ margin: 0 }}>{tp.t}</span>
              <span className="badge">{TAG_LABELS[tp.tag] || tp.tag}</span>
              <span className="vmeta" style={{ marginLeft: 'auto' }}>
                {tp.settings.ratio} · {tp.settings.duration}s · {tp.settings.structure === 'single' ? '1 shot' : 'multi'}
              </span>
            </div>
            <div className="d">{tp.d}</div>
            <pre style={{ maxHeight: 200, overflow: 'auto' }}>{tp.b}</pre>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <button className="btn tiny primary"
                onClick={() => {
                  window.dispatchEvent(new CustomEvent('cps-load-example', { detail: { idea: tp.idea, settings: tp.settings } }))
                  toast('Template loaded — replace the {PLACEHOLDERS}, then Generate')
                }}>
                ⤴ Load into Studio
              </button>
              <button className="btn tiny" onClick={async () => { await copyText(tp.b); toast('Template copied') }}>
                📋 Copy skeleton
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
