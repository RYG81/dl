import { useCallback, useEffect, useRef, useState } from 'react'
import Header from './components/Header.jsx'
import SettingsModal from './components/SettingsModal.jsx'
import StudioForm from './components/StudioForm.jsx'
import CameraDirector from './components/CameraDirector.jsx'
import OutputPanel from './components/OutputPanel.jsx'
import HistorySection from './components/HistorySection.jsx'
import ExampleLibrary from './components/ExampleLibrary.jsx'
import TemplatesSection from './components/TemplatesSection.jsx'
import TipsSection from './components/TipsSection.jsx'
import { tryBase } from './lib/ollama.js'
import { loadTemplates } from './lib/templates.js'
import { SYS_FALLBACK, LTX_SYS_FALLBACK } from './lib/prompts.js'

export default function App() {
  const [view, setView] = useState('studio')
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [conn, setConn] = useState({ status: 'checking', base: null, models: [], model: '' })
  const [sysPrompt, setSysPrompt] = useState({ text: SYS_FALLBACK, status: 'loading' })
  const [ltxSysPrompt, setLtxSysPrompt] = useState({ text: '', status: 'loading' })
  const [cards, setCards] = useState([])
  const [status, setStatus] = useState('')
  const [history, setHistory] = useState(() => {
    try { return JSON.parse(localStorage.getItem('cps_hist') || '[]') } catch { return [] }
  })
  const [tpl, setTpl] = useState({ list: [], source: 'loading' })

  /* ---------- toast ---------- */
  const [toastMsg, setToastMsg] = useState('')
  const toastTimer = useRef(null)
  const toast = useCallback((m) => {
    setToastMsg(m)
    clearTimeout(toastTimer.current)
    toastTimer.current = setTimeout(() => setToastMsg(''), 2200)
  }, [])
  useEffect(() => {
    const h = (e) => toast(e.detail)
    window.addEventListener('cps-toast', h)
    return () => window.removeEventListener('cps-toast', h)
  }, [toast])

  /* ---------- settings modal ---------- */
  useEffect(() => {
    const h = () => setSettingsOpen(true)
    window.addEventListener('cps-open-settings', h)
    return () => window.removeEventListener('cps-open-settings', h)
  }, [])
  useEffect(() => {
    if (conn.status === 'bad' && !sessionStorage.getItem('cps_settings_shown')) {
      sessionStorage.setItem('cps_settings_shown', '1')
      setSettingsOpen(true)
    }
  }, [conn.status])

  /* ---------- ollama detection (fully dynamic, nothing hardcoded) ---------- */
  const detect = useCallback(async (custom) => {
    setConn((c) => ({ ...c, status: 'checking' }))
    const saved = (custom || localStorage.getItem('cps_ollama_base') || '').trim().replace(/\/$/, '')
    const cands = []
    if (saved) cands.push(saved)
    if (location.protocol.startsWith('http')) cands.push(location.origin + '/ollama') // Vite proxy → 127.0.0.1:11434
    cands.push('http://localhost:11434', 'http://127.0.0.1:11434')
    for (const b of cands) {
      const m = await tryBase(b)
      if (m) {
        const names = m.map((x) => x.name)
        const prev = localStorage.getItem('cps_model') || ''
        const model = prev && names.includes(prev) ? prev : [...names].sort()[0] || ''
        setConn({ status: 'ok', base: b, models: m, model })
        return
      }
    }
    setConn({ status: 'bad', base: null, models: [], model: '' })
  }, [])
  useEffect(() => { detect() }, [detect])

  const setModel = useCallback((name) => {
    try { localStorage.setItem('cps_model', name) } catch (e) {}
    setConn((c) => ({ ...c, model: name }))
  }, [])

  /* ---------- external system prompts (H3 + LTX) ---------- */
  const fetchSys = useCallback(async (file, fallback) => {
    try {
      const r = await fetch(file, { cache: 'no-store' })
      if (!r.ok) throw new Error('HTTP ' + r.status)
      const t = (await r.text()).trim()
      if (!t) throw new Error('file is empty')
      return { text: t, status: 'ok' }
    } catch (e) {
      return { text: fallback, status: 'fallback', error: e.message }
    }
  }, [])
  const loadSys = useCallback(async () => {
    setSysPrompt(await fetchSys('prompts/system-prompt.md', SYS_FALLBACK))
    setLtxSysPrompt(await fetchSys('prompts/ltx-system-prompt.md', LTX_SYS_FALLBACK))
  }, [fetchSys])
  useEffect(() => {
    loadSys()
    loadTemplates().then(setTpl)
    const h = () => { loadSys(); loadTemplates().then(setTpl) }
    window.addEventListener('cps-reload-sysprompt', h)
    return () => window.removeEventListener('cps-reload-sysprompt', h)
  }, [loadSys])

  /* ---------- output cards + history ---------- */
  const pushCard = useCallback((c) => setCards((prev) => [c, ...prev]), [])
  const updateCard = useCallback((id, patch) =>
    setCards((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c))), [])
  const pushHistory = useCallback((v, inp, mode) => {
    setHistory((prev) => {
      const next = [{ ts: Date.now(), idea: ((inp && inp.idea) || '').slice(0, 140), mode: mode || 'studio', inp: inp || null, v }, ...prev].slice(0, 50)
      try { localStorage.setItem('cps_hist', JSON.stringify(next)) } catch (e) {}
      return next
    })
  }, [])
  const deleteHistory = useCallback((i) => setHistory((prev) => {
    const next = prev.filter((_, j) => j !== i)
    try { localStorage.setItem('cps_hist', JSON.stringify(next)) } catch (e) {}
    return next
  }), [])
  const clearHistory = useCallback(() => {
    setHistory([])
    try { localStorage.removeItem('cps_hist') } catch (e) {}
  }, [])
  const reuseHistory = useCallback((h) => {
    window.dispatchEvent(new CustomEvent('cps-restore-entry', { detail: h }))
    setView('studio')
  }, [])

  /* loading an example / restoring a history entry jumps to Studio */
  useEffect(() => {
    const h = () => setView('studio')
    window.addEventListener('cps-load-example', h)
    window.addEventListener('cps-restore-entry', h)
    return () => {
      window.removeEventListener('cps-load-example', h)
      window.removeEventListener('cps-restore-entry', h)
    }
  }, [])

  const NAV = [
    ['studio', '✨ Studio'],
    ['camera', '🛰️ Camera Director'],
    ['history', '🕘 History', history.length],
    ['learn', '📚 Learn'],
  ]

  return (
    <>
      <Header conn={conn} onRecheck={() => detect()} onSettings={() => setSettingsOpen(true)} />

      <nav className="appnav">
        {NAV.map(([id, label, count]) => (
          <button key={id} className={'ntab' + (view === id ? ' on' : '')} onClick={() => setView(id)}>
            {label}
            {count > 0 && <span className="n">{count}</span>}
          </button>
        ))}
      </nav>

      {(view === 'studio' || view === 'camera') && (
        <main>
          <section className="panel" id="inputPanel">
            {view === 'studio' ? (
              <StudioForm
                conn={conn} setModel={setModel} sysPrompt={sysPrompt} ltxSysPrompt={ltxSysPrompt}
                pushCard={pushCard} updateCard={updateCard} pushHistory={pushHistory}
                setStatus={setStatus} toast={toast}
              />
            ) : (
              <CameraDirector pushCard={pushCard} pushHistory={pushHistory} toast={toast} />
            )}
          </section>

          <OutputPanel cards={cards} status={status} />
        </main>
      )}

      {view === 'history' && (
        <HistorySection history={history} onReuse={reuseHistory} onDelete={deleteHistory} onClear={clearHistory} toast={toast} />
      )}

      {view === 'learn' && (
        <>
          <ExampleLibrary toast={toast} />
          <TemplatesSection templates={tpl.list} source={tpl.source} toast={toast} />
          <TipsSection />
        </>
      )}

      <footer>
        CinePrompt Studio · runs 100% locally · pairs with{' '}
        <a href="https://ollama.com" target="_blank" rel="noopener">Ollama</a> · prompts follow MiniMax's published
        H3 prompt-writing guides · React + Vite edition
      </footer>

      <SettingsModal
        open={settingsOpen} onClose={() => setSettingsOpen(false)}
        conn={conn} setModel={setModel} detect={detect}
        sysPrompt={sysPrompt} setSysPrompt={setSysPrompt} toast={toast}
      />

      <div id="toast" className={toastMsg ? 'show' : ''}>{toastMsg}</div>
    </>
  )
}
