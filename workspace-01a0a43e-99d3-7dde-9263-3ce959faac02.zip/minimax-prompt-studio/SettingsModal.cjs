var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/components/SettingsModal.jsx
var SettingsModal_exports = {};
__export(SettingsModal_exports, {
  default: () => SettingsModal
});
module.exports = __toCommonJS(SettingsModal_exports);
var import_react = require("react");

// src/lib/ollama.js
function fmtBytes(n) {
  if (!n) return "";
  const u = ["B", "KB", "MB", "GB", "TB"];
  let i = 0, v = n;
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return v.toFixed(v >= 10 || i === 0 ? 0 : 1) + " " + u[i];
}
function fmtAgo(iso) {
  if (!iso) return "";
  const d = Date.now() - new Date(iso).getTime();
  const m = Math.floor(d / 6e4);
  if (m < 1) return "just now";
  if (m < 60) return m + " min ago";
  const h = Math.floor(m / 60);
  if (h < 24) return h + " h ago";
  return Math.floor(h / 24) + " d ago";
}

// src/components/SettingsModal.jsx
function SettingsModal({ open, onClose, conn, setModel, detect, sysPrompt, setSysPrompt, toast }) {
  const [customBase, setCustomBase] = (0, import_react.useState)(() => localStorage.getItem("cps_ollama_base") || "");
  (0, import_react.useEffect)(() => {
    if (open) setCustomBase(localStorage.getItem("cps_ollama_base") || "");
  }, [open]);
  (0, import_react.useEffect)(() => {
    if (!open) return;
    const h = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  const useBase = () => {
    const v = customBase.trim().replace(/\/$/, "");
    if (v) localStorage.setItem("cps_ollama_base", v);
    else localStorage.removeItem("cps_ollama_base");
    detect(v || void 0);
  };
  const onFile = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    f.text().then((t) => {
      const txt = t.trim();
      if (!txt) {
        toast("That file is empty");
        return;
      }
      setSysPrompt({ text: txt, status: "override", name: f.name });
      toast("System prompt overridden with " + f.name);
    });
  };
  const reload = () => {
    window.dispatchEvent(new Event("cps-reload-sysprompt"));
    toast("Reloading system prompt\u2026");
  };
  const statusTxt = sysPrompt.status === "loading" ? "loading\u2026" : sysPrompt.status === "ok" ? /* @__PURE__ */ React.createElement(React.Fragment, null, "\u2713 prompts/system-prompt.md \xB7 ", sysPrompt.text.length, " chars") : sysPrompt.status === "override" ? /* @__PURE__ */ React.createElement(React.Fragment, null, "\u2713 ", sysPrompt.text.length, " chars \u2014 override: ", sysPrompt.name, " (session only)") : /* @__PURE__ */ React.createElement(React.Fragment, null, "\u26A0 system-prompt.md unreachable \u2014 built-in fallback active");
  return /* @__PURE__ */ React.createElement("div", { className: "modal-backdrop", onMouseDown: (e) => {
    if (e.target === e.currentTarget) onClose();
  } }, /* @__PURE__ */ React.createElement("div", { className: "modal", role: "dialog", "aria-modal": "true" }, /* @__PURE__ */ React.createElement("div", { className: "modal-head" }, /* @__PURE__ */ React.createElement("h3", null, "\u2699\uFE0F Ollama settings & help"), /* @__PURE__ */ React.createElement("div", { className: "spacer" }), /* @__PURE__ */ React.createElement("button", { className: "btn tiny", onClick: onClose, title: "Close (Esc)" }, "\u2715 Close")), /* @__PURE__ */ React.createElement("div", { className: "modal-body" }, /* @__PURE__ */ React.createElement("div", { className: "connbox" }, /* @__PURE__ */ React.createElement("div", { style: { display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "baseline" } }, /* @__PURE__ */ React.createElement("b", { style: { color: "var(--text)" } }, "Endpoint"), /* @__PURE__ */ React.createElement("span", null, conn.status === "checking" && /* @__PURE__ */ React.createElement("span", { style: { color: "var(--dim)" } }, "checking\u2026"), conn.status === "ok" && /* @__PURE__ */ React.createElement("span", { style: { color: "var(--green)" } }, "\u2713 connected \xB7 ", conn.base === location.origin + "/ollama" ? "local proxy (Vite)" : conn.base), conn.status === "bad" && /* @__PURE__ */ React.createElement("span", { style: { color: "var(--red)" } }, "\u2717 not reachable"))), /* @__PURE__ */ React.createElement("div", { style: { margin: "4px 0 8px", fontSize: 11.5, color: "var(--faint)" } }, "Auto-detection order: saved/custom endpoint \u2192 same-origin ", /* @__PURE__ */ React.createElement("code", null, "/ollama/*"), " (Vite dev proxy \u2192", " ", /* @__PURE__ */ React.createElement("code", null, "127.0.0.1:11434"), ", no CORS needed) \u2192 direct ", /* @__PURE__ */ React.createElement("code", null, "http://localhost:11434"), " \u2192", " ", /* @__PURE__ */ React.createElement("code", null, "http://127.0.0.1:11434"), ". Whatever Ollama reports via ", /* @__PURE__ */ React.createElement("code", null, "/api/tags"), " is listed \u2014 no model names are hardcoded."), /* @__PURE__ */ React.createElement("div", { style: { display: "flex", gap: 8 } }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: customBase,
      onChange: (e) => setCustomBase(e.target.value),
      placeholder: "http://localhost:11434 or a LAN box like http://192.168.1.5:11434"
    }
  ), /* @__PURE__ */ React.createElement("button", { className: "btn tiny", onClick: useBase }, "Use & re-check")), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 13, borderTop: "1px dashed var(--border)", paddingTop: 10 } }, /* @__PURE__ */ React.createElement("b", { style: { color: "var(--text)" } }, "Detected models"), " ", /* @__PURE__ */ React.createElement("span", { style: { fontSize: 11, color: "var(--faint)" } }, conn.models.length ? `\xB7 ${conn.models.length} found on ${conn.base}` : ""), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 8, display: "grid", gap: 6 } }, conn.models.length === 0 && /* @__PURE__ */ React.createElement("div", { style: { fontSize: 12, color: "var(--faint)" } }, "Nothing detected yet. Start Ollama (", /* @__PURE__ */ React.createElement("code", null, "ollama serve"), "), pull any model (", /* @__PURE__ */ React.createElement("code", null, "ollama pull <name>"), "), then hit \u21BB Re-check."), [...conn.models].sort((a, b) => a.name.localeCompare(b.name)).map((m) => {
    const d = m.details || {};
    const meta = [
      d.family,
      d.parameter_size ? d.parameter_size.replace(/\.0B/, "B") : "",
      d.quantization_level,
      m.size ? fmtBytes(m.size) : "",
      m.modified_at ? fmtAgo(m.modified_at) : ""
    ].filter(Boolean).join(" \xB7 ");
    const inUse = m.name === conn.model;
    return /* @__PURE__ */ React.createElement("div", { key: m.name, style: {
      display: "flex",
      gap: 8,
      alignItems: "center",
      background: "#0a0e15",
      border: "1px solid var(--border)",
      borderRadius: 8,
      padding: "6px 10px"
    } }, /* @__PURE__ */ React.createElement("div", { style: { flex: 1, minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { style: { fontFamily: "var(--mono)", fontSize: 12, color: "var(--text)", wordBreak: "break-all" } }, m.name), meta && /* @__PURE__ */ React.createElement("div", { style: { fontSize: 10.5, color: "var(--faint)" } }, meta)), /* @__PURE__ */ React.createElement(
      "button",
      {
        className: "btn tiny" + (inUse ? " primary" : ""),
        onClick: () => {
          setModel(m.name);
          toast("Using " + m.name);
        }
      },
      inUse ? "\u2713 in use" : "Use"
    ));
  })), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 8, fontSize: 11.5, color: "var(--faint)" } }, "No models? Install Ollama from", " ", /* @__PURE__ */ React.createElement("a", { href: "https://ollama.com", target: "_blank", rel: "noopener" }, "ollama.com"), ", then add any chat model with ", /* @__PURE__ */ React.createElement("code", null, "ollama pull <model-name>"), " \u2014 bigger models (7B and up) follow the H3 format more faithfully. Hit \u21BB Re-check afterwards.")), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 13, borderTop: "1px dashed var(--border)", paddingTop: 10 } }, /* @__PURE__ */ React.createElement("b", { style: { color: "var(--text)" } }, "Browser can't reach Ollama?"), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 6 } }, "With ", /* @__PURE__ */ React.createElement("code", null, "npm run dev"), " the Vite proxy handles everything \u2014 nothing to configure. Only if you serve the built/static app from another origin, allow the browser to talk to Ollama once:"), /* @__PURE__ */ React.createElement("pre", null, `# Windows (PowerShell, before starting Ollama)
$env:OLLAMA_ORIGINS="*"; ollama serve

# macOS / Linux
OLLAMA_ORIGINS=* ollama serve`)), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 13, borderTop: "1px dashed var(--border)", paddingTop: 10 } }, /* @__PURE__ */ React.createElement("b", { style: { color: "var(--text)" } }, "System prompt"), " (external file):", " ", /* @__PURE__ */ React.createElement("span", { style: { color: "var(--dim)" } }, statusTxt), /* @__PURE__ */ React.createElement("div", { style: { display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("label", { className: "btn tiny", style: { cursor: "pointer" } }, "\u{1F4C2} Override with local .md", /* @__PURE__ */ React.createElement("input", { type: "file", accept: ".md,.txt", style: { display: "none" }, onChange: onFile })), /* @__PURE__ */ React.createElement("button", { className: "btn tiny ghost", onClick: reload }, "\u21BB Reload from file")), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 6 } }, "Edit ", /* @__PURE__ */ React.createElement("code", null, "public/prompts/system-prompt.md"), " to re-tune how the LLM writes H3 prompts \u2014 no code changes needed."))))));
}
