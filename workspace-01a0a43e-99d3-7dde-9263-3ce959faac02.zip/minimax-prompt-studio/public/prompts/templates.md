# CinePrompt Studio — Template Library

> **Loaded at runtime** by the app via fetch('prompts/templates.md'). Edit or extend freely —
> copy any block, change the fields, reload the page (or Learn tab). Malformed blocks are skipped.
>
> Format per template: a '## Title' heading, then 'key: value' metadata lines, then the three-field
> skeleton in a fenced code block. Keys: tag, description, category, ratio, resolution, duration,
> music, structure, camera, idea.

## Brand film — model performance
tag: person
description: A model performing a brand moment: beats, off-screen direction, optional voiceover line.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
idea: A {AGE} model wearing {GARMENT} for {BRAND} at {LOCATION} — she {BEAT_1}, then {BEAT_2}, and settles into {FINAL_POSE} while an off-screen director calls out one line of direction.

```
integrated_multimodal_description: Shot on {CAMERA + LENS, e.g. an ARRI Alexa Mini with a Panavision 50mm}, {RATIO} framing, 24fps. [Shot 1] {LOCATION dressed as a working set — light stands, backdrop, one crew detail}. A MODEL in {GARMENT + appearance} marks her spot, {BEAT_1 — settle/inhale}, then begins the move. An off-screen voice says "{DIRECTION}" in {TONE}; at the cue her expression shifts and she {BEAT_2 — the developing action}, fabric and hair responding to {WIND/LIGHT}. She finishes on {FINAL_POSE}, holding the last look as the camera {MOVE with end-state, e.g. trucks left, settling tight on her face}. {LIGHTING DESIGN}. {GRADE}.

overall_soundscape: {FOOTSTEP/FABRIC sounds}, the director's voice carrying, {ONE ambient detail}.

non_diegetic_music: {GENRE} at {TEMPO}, {INSTRUMENTATION}, {dynamics under the final pose}.
```

## Product hero — macro showcase
tag: product
description: Object-first commercial: turntable or arc, material detail, no people needed.
category: Product Showcase
ratio: 1:1
resolution: 2K
duration: 6
music: subtle
structure: single
camera: Arc shot
idea: {PRODUCT} on {SURFACE} against {BACKDROP} — it rotates slowly as the light traces every material detail, ending on the {HERO DETAIL}.

```
integrated_multimodal_description: Shot on {CAMERA + MACRO LENS, e.g. a RED V-Raptor with a 100mm macro}, 24fps. [Shot 1] A studio set: {BACKDROP}, {SURFACE}, {LIGHTING RIG}. {PRODUCT} rests centered. It rotates slowly while the light traces {MATERIAL DETAILS — mesh, stitching, liquid, grain}; {MICRO-MOTION, e.g. condensation, dust motes} reads in the beam. The camera {arcs/pedestals} with small amplitude at slow speed, ending settled on {HERO DETAIL}. Product stays centered and razor sharp; {RIM/KEY LIGHT behavior}. {GRADE}. No logos or text.

overall_soundscape: Near-silent studio tone, {ONE mechanical or material sound, e.g. turntable whir}.

non_diegetic_music: {Minimal style} at {tempo}, {soft low-end}, fading at the end — or N/A.
```

## Cinematic one-take
tag: person
description: Single continuous motivated move, layered beats, atmosphere-first.
category: Cinematic Film Scene
ratio: 21:9
resolution: 2K
duration: 10
music: auto
structure: single
camera: Auto
idea: {CHARACTER} in {LOCATION} at {TIME} — {PRIMARY ACTION}, with small human beats around it; the camera {ONE continuous move} and settles on {END FRAME}.

```
integrated_multimodal_description: Shot on {ARRI/Panavision combination}, 24fps, {film grain}. [Shot 1] {LOCATION with layered depth — foreground, mid-ground, background}, {TIME + WEATHER}. {CHARACTER — age, wardrobe, one distinguishing detail} {PRIMARY ACTION}, and around it: {BEAT_1}, then {BEAT_2}, before {BEAT_3 — the turn}. Their expression moves from {STATE A} to {STATE B} in micro-detail. The camera {ONE continuous move with amplitude + speed}, coming to rest on {END FRAME}. {LIGHTING DESIGN — name the sources}. {GRADE}.

overall_soundscape: {ACTION sounds tied to each beat}, over {AMBIENT BED}.

non_diegetic_music: {INSTRUMENTATION, tempo, dynamics — or exactly N/A}.
```

## Dialogue two-hander
tag: dialogue
description: Two speakers, lines in quotes with voice tone, reactions as beats.
category: Dialogue Scene
ratio: 16:9
resolution: 2K
duration: 10
music: none
structure: single
camera: Static shot
idea: {CHARACTER_A} and {CHARACTER_B} at {LOCATION} — A says "{LINE_1}", B reacts and answers "{LINE_2}" as the tension shifts.

```
integrated_multimodal_description: Shot on {CAMERA + LENS}, 24fps. [Shot 1] {LOCATION — decor, light quality, one ambient detail}. {CHARACTER_A — appearance + wardrobe} faces {CHARACTER_B — appearance + wardrobe} across {SPATIAL RELATION}. A's expression is {STATE}; {micro-beat before speaking}, then A says "{LINE_1}" in a {VOICE TONE, pace}. B {REACTION BEAT — swallow, glance, hands}, and answers "{LINE_2}" in a {VOICE TONE}. The power between them shifts: {WHAT CHANGES physically}. The camera holds a static shot at eye level, both faces framed; {LIGHTING}. {GRADE, e.g. cold noir palette}.

overall_soundscape: {ROOM TONE + one recurring ambient sound between the lines}.

non_diegetic_music: N/A
```

## Three-beat multi-shot
tag: multi
description: Wide → medium → close detail, real cuts with timecodes, new info per shot.
category: Multi-Shot Sequence
ratio: 16:9
resolution: 2K
duration: 12
music: auto
structure: multi3
camera: Auto
idea: {SCENE}: shot 1 establishes {WIDE INFO}, shot 2 finds {SUBJECT} mid-action, shot 3 lands on {CLOSE DETAIL} as {RESOLUTION}.

```
integrated_multimodal_description: Shot on {CAMERA + LENSES}, 24fps. [Shot 1] {WIDE ESTABLISHING — location, time, atmosphere, depth layers}. {WHAT MOVES in the wide}. The camera {MOVE}. [Shot 2] At {T2, inside duration}.000, the camera cuts to {MEDIUM — the subject in action}: {WARDROBE consistent with shot 1}, {BEAT developing the action}. [Shot 3] At {T3}.000, the camera cuts to {CLOSE DETAIL — the emotional or story period}. {MICRO-EXPRESSION or material detail}. {LIGHTING consistent across shots}. {GRADE}. {NEGATION, e.g. No soft dissolves or fluid morphs}.

overall_soundscape: {CONTINUOUS sound bed that bridges the cuts}, {cut-specific sounds}.

non_diegetic_music: {SCORE that carries across all three shots}.
```

## Vertical social hook
tag: vertical
description: 9:16, one-second hook, direct-to-camera line, fast energy.
category: Social Media Content
ratio: 9:16
resolution: 768P
duration: 5
music: beat
structure: single
camera: Shake slightly
idea: {CREATOR} in {BRIGHT LOCATION} slams/places {OBJECT} and tells the lens "{HOOK LINE}" — punchy, one take.

```
integrated_multimodal_description: Shot on a smartphone, {24mm-equivalent} at f/1.8, vertical 9:16, handheld energy. [Shot 1] {BRIGHT LOCATION — hard daylight, clean background, one prop}. {CREATOR — age, look, wardrobe} stands {POSITION}; eyes bright, {HOOK PHYSICAL BEAT — slam/point/lean-in}. They say "{HOOK LINE}" in a {TONE — upbeat, fast, confident}, landing the beat on the {OBJECT/ACTION}. The camera shakes slightly with handheld energy, keeping the face in the upper frame. {LOOK — crisp whites / saturated tones}.

overall_soundscape: {THE signature prop sound}, room tone, {one extra detail}.

non_diegetic_music: {Snappy percussion/groove} at a fast tempo, with an accent hit on the {HOOK MOMENT}.
```

## Music video performance
tag: music
description: Performer + wind machine + light sweeps, continuous arc move.
category: Music Video
ratio: 21:9
resolution: 2K
duration: 10
music: beat
structure: single
camera: Arc shot
idea: {ARTIST} in {STYLIZED LOCATION} performs to the beat as wind and light sculpt the frame; the camera circles in one continuous move.

```
integrated_multimodal_description: Shot on {ARRI anamorphics / cinema camera}, 24fps, {flare character}. [Shot 1] {STYLIZED LOCATION — practicals, haze, repeating geometry}. {ARTIST — wardrobe with movement-friendly detail} performs: {VOCAL GESTURE}, head tipping back on the high note, eyes snapping to the lens; a wind machine sculpts {HAIR/FABRIC}. The camera tracks with large amplitude at fast speed around them in ONE continuous arc as light sweeps rake the frame — no cuts. {HEAVY FLARES / PUSHED GRAIN}. {PALETTE}.

overall_soundscape: {SPACE reverb bed}, cloth snapping in wind, {one electrical/mechanical texture}.

non_diegetic_music: {GENRE} at {BPM}, {KICK/BASS description} locking to the light strobes.
```

## Documentary craft
tag: person
description: Hands at work, static close framing, natural sound, no score.
category: Documentary
ratio: 4:3
resolution: 2K
duration: 12
music: none
structure: single
camera: Static shot
idea: {CRAFTSPERSON} at {WORKBENCH} performs {PRECISE TASK} — total absorption, one held close shot, real sound only.

```
integrated_multimodal_description: Shot handheld on a documentary camera, {35mm} at T2.0, natural light, 24fps. [Shot 1] {WORKSHOP — tools, textures, one window source, dust in the beam}. {CRAFTSPERSON — age, hands, one wardrobe detail} {PRECISE TASK}, and around it: {BEAT_1 — preparation}, {BEAT_2 — the attempt}, then {BEAT_3 — the breath after}. Their expression: {ABSORPTION DETAIL — lips, brow, breathing}. The camera holds a static close shot on {HANDS + OBJECT}, shallow focus. Muted true-to-life colors, deep material texture.

overall_soundscape: {THE real sounds of the craft, layered}, {one distant world sound outside}.

non_diegetic_music: N/A
```

## Drone landscape reveal
tag: landscape
description: Aerial move with layered depth, natural soundscape, orchestral swell.
category: Nature / Landscape
ratio: 21:9
resolution: 2K
duration: 12
music: full
structure: single
camera: Tilt down
idea: {LANDSCAPE} at {TIME} — mist/light in layers; the drone tilts down to reveal {SUBJECT} below.

```
integrated_multimodal_description: Shot on a cinema drone, {24mm equivalent} at f/2.8, three-axis stabilized, 24fps. [Shot 1] {LANDSCAPE} at {TIME}: {FOREGROUND layer}, {MID-GROUND layer with motion — mist, water, trees}, {BACKGROUND layer in haze}. {WHAT MOVES slowly — mist banks, light, one animal}. The camera tilts down with small amplitude at slow speed, revealing {SUBJECT BELOW}. Natural light, {EARTHY/COLD grade}. No titles or text.

overall_soundscape: {WIND + WATER + one far sound}, then a single {bird/animal} call, then stillness.

non_diegetic_music: A slow orchestral swell — {LOW STRINGS / distant horn} — rising under the reveal and holding.
```

## Animation character beat
tag: animation
description: 2D/3D character moment: style notes, expressive physics, glow/light.
category: Animation
ratio: 16:9
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Tracking shot
idea: {CHARACTER} in {STYLIZED WORLD} performs {JOYFUL ACTION} — each movement triggers {LIGHT/PARTICLE reaction}.

```
integrated_multimodal_description: {ANIMATION STYLE, e.g. Hand-drawn 2D over warm watercolor backgrounds}, 24fps, expressive linework with soft glow compositing. [Shot 1] {STYLIZED WORLD — palette, light logic, background detail}. {CHARACTER — shape language, colors, one signature feature} {JOYFUL ACTION}; each movement triggers {REACTION — sparks, swing, particles}, and the character's {ears/tail/eyes} {MICRO-REACTION}. The camera tracks alongside in profile, {PARALLAX layers} passing at different depths. {LIGHT BLOOM behavior}. {PALETTE}.

overall_soundscape: {PHYSICAL sounds stylized to match the animation}, {distant world detail}.

non_diegetic_music: {PLAYFUL instrumentation} at a light tempo with {percussion pulse}, brightening with the action.
```
