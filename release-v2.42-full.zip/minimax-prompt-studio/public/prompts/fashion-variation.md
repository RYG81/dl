# Variation pools — "everything varies" for fashion templates

Templates that declare `vary:` rotate through these pools. On a multi-variant run each variant must
draw a **different option from every pool** than the other variants in the batch, so no two outputs
share a style type, an outfit silhouette, an outfit colour, a model, a movement, a presentation style, an action,
an interaction with the garment, a location or a camera language. Options are written to be directive, not decorative.

Every pool casts women only — the studio's fashion cast rule applies here too: no option may name a man, a boy or a male-presenting model, and no pool may put a male figure, hand, reflection or voice in frame.

Use the option as written, then expand it with concrete, nameable detail (fabrics, colours, timing,
textures, light). Never merge two pools into one option — variety comes from the dimensions differing.

## STYLE TYPE
1. Tradition and heritage — a handloom sari or a lehenga-choli with its own drape, jewellery from the same region, hair dressed for an occasion.
2. Office wear — a sharp tailored suit or a shirt-and-trouser pairing, structured shoulders, crisp collar, a low practical heel.
3. Swimwear — a one-piece or bikini with real construction (cup, strap, tie, high leg), pool or sea light, skin presented as hers, no cataloguing gaze.
4. Evening and cocktail — a floor-length gown or a sculpted midi in a liquid fabric, statement earrings, a heel she can actually walk in.
5. Bridal and occasion — an heirloom-weight ensemble with embroidery, veil or dupatta, heirloom jewellery, footwear built for standing.
6. Streetwear — oversized layers over a base, sneakers with real technology, a bag worn cross-body, the city as the room.
7. Athleisure and sport — technical jersey with panelling, raglan seams, performance mesh, a running shoe with a real last.
8. Resort and vacation — linen, open weaves, a sarong or an easy shirt-dress, a sandal with a woven upper, sunlight doing the work.
9. Winter outerwear — a wool coat or a padded jacket over a knit, boots with a lugged sole, breath visible in cold light.
10. Denim and casual — a considered denim build with real stitching, a knit layer, a clean sneaker or a boot, no workwear costume.
11. Lingerie and boudoir — true intimate wear with real construction (corset, teddy, bralette set), a robe only if the brief asks for one.
12. Heritage-meets-modern — one traditional garment rebuilt in a modern silhouette, or one modern garment with traditional handwork.

## OUTFIT COLOUR

> **White, ivory and cream are choices, never defaults.** Nothing here opens on a pale base: the base is always a colour, and a light element is only ever trim, piping or a secondary. One family per look (60/30/10: the base, one secondary, one accent), one metal, and the finish named. Rotate the families across a batch — twelve variants should read as twelve different wardrobes, not twelve variations of one beige.
1. Oxblood and ivory — a deep oxblood base with ivory trim and antique-gold hardware, matte wool finish.
2. Cobalt and chalk — saturated cobalt base, chalk-white secondary, brushed-silver hardware, crisp dry finish.
3. Bottle green and tan — bottle-green base, tan leather secondary, brass hardware, grained matte finish.
4. Terracotta and cream — warm terracotta base, cream secondary, tortoiseshell accent, slubby matte finish.
5. Ink navy and silver — near-black navy base, silver hardware, satin-faced finish that catches one hard light.
6. Mustard ochre and brown — ochre base, bitter-chocolate secondary, bronze hardware, textured handloom finish.
7. Plum and blush — deep plum base, dusty blush secondary, rose-gold hardware, liquid satin finish.
8. Burnished copper and black — copper base, true black secondary, gunmetal hardware, hammered matte metal finish.
9. Powder blue and white — soft powder blue base, optic-white secondary, pearl hardware, crisp poplin finish.
10. Tomato red and camel — clear tomato base, camel secondary, gold hardware, wool-crepe dry finish.
11. Slate grey and lemon — slate base, one lemon accent, black hardware, brushed flannel finish.
12. Black with one colour — full black base and one deliberate colour (crimson, jade, electric blue) in a single piece, lacquered or matte by turn.

## MODEL
1. A 20-year-old South Asian woman, long wavy dark hair, warm brown skin, freckles across the nose, athletic build.
2. A 27-year-old Black woman, close-cropped natural hair, deep brown skin, high cheekbones, tall runway build.
3. A 34-year-old East Asian woman, sharp black blunt-cut bob, porcelain-fair skin, small-boned and lean, quiet intensity.
4. A 24-year-old white woman with auburn curls and pale freckled skin, soft shoulders, freckled arms.
5. A 31-year-old South Asian woman, thick dark hair twisted into a low bun, strong jaw, broad-shouldered athletic build, sun-weathered hands.
6. A 45-year-old woman with silver-grey bob, olive skin, laugh lines, composed presence.

## OUTFIT DESIGN

> **Every option here is a complete stack** — main piece, a bottom or the garment's own lower half, an outer layer over a named inner garment only if the look has one, then footwear. Never a lone top, a lone coat or a lone corset: an unstated layer is a layer the render will invent or leave missing. A base layer appears only where the cut shows it (sheer, plunged, open-backed, cut out, slit, cropped) — a covered look names none, because underwear that is not visible in the reference becomes visible in the render.
1. Sculptural wool tailoring in oxblood: an oversized double-breasted coat with a strong shoulder worn open over a fine ivory ribbed knit, wide-leg oxblood trousers and pointed leather boots — a closed stack, never the coat alone.
2. Cobalt satin slip dress cut on the bias with a cowl neckline, no sleeves, hem skimming the ankle, a liquid finish that carries the room's light.
3. Indigo denim on denim — a boxy cropped jacket over wide-leg raw denim with visible contrast stitching and a dry, grained finish.
4. Plum organza blouse layered over a black boned bustier, skirt in matte black crepe — sheer against matte.
5. Hand-embroidered ethnic wear: a mustard-ochre raw-silk Anarkali with dense gold zari at the yoke and a rust dupatta with a heavy border.
6. Knitwear architecture in oatmeal and bitter brown: a chunky cable cardigan worn off one shoulder over a camel column skirt and oxblood leather boots.

## PRESENTATION
1. Runway confidence — chin level, shoulders back, deliberate unhurried stride, no acknowledgement of the camera.
2. Soft editorial intimacy — half-lidded gaze, small self-touch, quiet breathing, presence rather than performance.
3. Playful street energy — a bounce in the step, a laugh that breaks the pose, hands busy with pockets or a bag.
4. Cool indifference — hands in pockets, weight on one hip, gaze travelling past the lens.
5. Couture stillness — a sculptural pose held with control, minimal blink, one deliberate head turn.
6. Structured classical posing — a dancer's alignment, neck long, arms arranged with intention.

7. Heirloom formality — composed and unhurried, gaze to the lens or just past it, chin level, the ornaments doing the talking.
8. Veiled intimacy — the veil held between the lens and her face, the gaze found through the net.
9. Confident bride — she breaks into a real smile on the last beat and holds it down the lens.
10. Hands-led ceremony — the beat is carried by her own hands on the piece, the face following the hand.
11. Quiet luxury — no smile, no gesture to the camera, one slow blink, weight settled, stillness with breath.
12. Editorial directness — she meets the lens and holds it while the light changes, no acknowledgement of anyone behind the camera.
## MOVEMENT
1. A slow deliberate catwalk gait, heel landing first, hips level, one step per beat.
2. A light quick step with a spring at the push-off, weight rolling through the whole foot.
3. A heavy unhurried walk, shoulders leading, each footfall arriving with weight.
4. Barefoot on the spot — a pivot on the ball of the foot, then a step back.
5. A dancer's glide, steps small and even, torso still, the garment doing the travelling.
6. A stalking approach — long strides, low centre of gravity, eyes fixed ahead.

7. Barefoot on stone, heel landing first, the anklets sounding each step — two or three grounded steps only.
8. A glide with the pallu gathered in one hand, steps small and even, the garment doing the travelling.
9. The bridal walk proper: one grounded step per beat, weight passing foot to foot, the drape settling a half-beat behind.
10. A rise from seated to standing, the weight rolling forward through the feet, fabric releasing as she comes up.
11. The half-turn at the mark — three-quarters away and back, the feet moving only a quarter circle.
12. Stillness with life: both feet planted, weight even, breath and ornaments the only movement.
## ACTION
1. Two or three grounded steps toward the lens, then stopping a half-step short — the floor in frame, weight passing foot to foot, both feet never off it at once.
2. A three-quarter turn away with the back reading for a moment, then coming back to the lens inside the same beat — she never walks out of frame, and the next shot finds her on the same mark.
3. Seated, rising in one continuous movement, fabric releasing as she stands.
4. Adjusting the garment — closing the coat, straightening a cuff, settling a collar.
5. Spinning once with the weight rolling from heel to toe, then settling.
6. Entering a space — pushing a door, stepping through, pausing in the threshold.

7. Seated on the floor or a low seat with the skirt arranged around her, she lifts one hand to the jewellery at her throat and holds it — the seated presentation beat.
8. The veil drawn down across her face so the frame reads through the net, then lifted clear again inside the same beat.
9. The veil spread overhead as a canopy — a quarter turn under it, and it settles around her shoulders.
10. The hand insert: her own hand comes into frame onto the piece — the cuff, the hem, the waistband — and stays there while the detail reads.
11. The pleat stack set straight with both hands, gaze down, then up to the lens.
12. Rising from a chair in one continuous movement, the fabric releasing as she stands and settling behind her.
13. Two grounded steps up onto higher ground, then the drape settling after her — never a crossing, never mid-stride.
14. She stands square and still, hands at her sides, only the ornaments moving as they settle, and holds the frame for its full length.
## OUTFIT INTERACTION
1. Both hands in the coat pockets, the coat swinging open to reveal the layer beneath.
2. Running a flat palm down the fabric to smooth it, feeling the weave, then letting it fall.
3. Gathering the skirt or dupatta in one hand and letting it drop open on the beat.
4. Tugging a cuff over the knuckles, then pulling the sleeve down over the wrist.
5. Lifting a collar or one shoulder so the garment's construction reads clearly.
6. Pulling the waist tie or belt tighter, the fabric gathering in one movement.

## LOCATION
1. A stripped concrete studio with a raw shuttered wall, a scaffold plank on trestles, a paint tin and a coiled cable where they were left, one industrial lamp on, a deep falloff to black — stark, never empty.
2. A narrow old-city lane at golden hour, plaster walls, laundry lines, one warm lamp.
3. A marble stair hall with tall windows and long shafts of afternoon light.
4. A rain-wet city street at night, neon reflections on asphalt, headlights in shallow focus.
5. A dune field at sunset, hard low sun raking across ripples, wind moving sand.
6. A leafy colonial-era veranda, cane furniture, dappled light through shutters.

## SWIM AND COVER
> A swim piece is never "a swimsuit" — the cut, the rise and what covers it are the look.
1. A one-piece maillot with a high leg and a scooped back, ribbed swim knit, a fine self-tie at the shoulder.
2. A two-piece with a high-rise brief and a soft-cup top, in a matte swim crêpe, under an open linen shirt.
3. A swim short set with a drawcord waist and a cropped swim top, in a chlorine-proof knit.
4. A wrap swimsuit with a tie at the side and a low back, in a fluid jersey, with a sarong for the deck.
5. A ribbed one-shoulder swimsuit in an acid-free knit, matte, with a wide-brim hat for the shade.
6. A terry robe over a plain maillot, towelling with a shawl collar, over the piece for the walk to the water.

## PRINT AND TEXTURE
> For the boho register: the print and the handwork carry the look — name the technique, not the vibe.
1. Hand block-print in indigo on a cotton ground, the print faintly off-register where the block landed.
2. Paisley in a dense repeat, the ground warm, the outlines printed heavier at the edges.
3. Mirror work and kantha stitching on a cotton jacket, the small mirrors catching one point of light.
4. Crochet and open work over a cotton lining, the pattern reading in shadow as well as in the light.
5. Patchwork of printed cottons and a kantha grid holding them, every square slightly different.
6. Ikat, the warp blurring where the dye was bound, the motif soft-edged front and back.

## FABRIC AND FINISH
> For the nightwear register: the finish decides how cloth behaves under one window of light.
1. Washed silk with a matte finish, its sheen travelling along the folds as the light moves.
2. Brushed cotton, the nap catching the light flat and holding warmth.
3. Jersey in a fine gauge with a soft ribbed cuff, the cloth falling in narrow folds.
4. Satin with piped edges and a covered button placket, a clean highlight running along the pipe.
5. Waffle cotton with a deep weave that reads its texture in the low light, warm and dry.
6. Washed linen with a papery drape and a soft slub, the creases staying where they form.

## SILK AND LACE
> For the intimates register: the fabric and its edge do all the work; the camera stays high.
1. Ivory silk charmeuse cut on the bias, with a scalloped lace edge and a satin strap.
2. Black satin with a fine French lace panel at the shoulder and a bonded seam that stays flat.
3. A cotton poplin set with openwork embroidery at the edge, matte and crisp rather than glossy.
4. A mesh panel under a silk overlay, the edge finished with a narrow satin bind.
5. Champagne silk with a covered button placket and a self tie at the waist.
6. Washed silk in deep plum with a lace trim at the hem, the finish matte where the light falls away.

## WINTER KIT
> For the ski register: the hardware and the warmth are part of the look.
1. A quilted shell with a drawcord hood, taped seams and a two-way zip in a matte ripstop.
2. A fine-gauge merino top with a zip neck and thumbholes at the cuff, worn under the shell.
3. A padded gilet over the shell at the apres hour, baffles reading in the low sun.
4. A knitted hat and gloves in a ribbed wool, the hat pulled low and the cuff turned.
5. Goggles with a mirrored lens worn up on the hat, the strap set above the brim.
6. A gaiter over the boot top, the trouser hem sealed down on it, snow clinging to the seam.

## STREET LAYERS
> For the street register: proportions and hardware — the layer, the bag, the cap, the shoe.
1. An oversized hoodie in a heavy fleece, the hood up, the sleeve dropped to the knuckle.
2. A boxy overshirt worn open over a layered tee, the hem finishing below the knit.
3. A bomber in a matte nylon with a ribbed cuff, worn half on the shoulder for one beat.
4. Cargo trousers in a washed cotton, the pockets flat, the hem breaking once on the shoe.
5. A puffer gilet over the hoodie, the baffles giving the silhouette its shape.
6. A crossbody bag on a webbing strap and a cotton cap with a curved brim, both in the same family.


## SAREE CONSTRUCTION
> A saree is a construction decision before it is a colour: how the six yards are built and where they are held. Name the format, not "a saree".
1. A pre-stitched concept saree — the pleats set permanently into a waistband, the pallu falling from a fixed knot at the shoulder.
2. A lehenga-sari: a fitted skirt with a pleated apron knotted at the front, the pallu sweeping from the shoulder to below the knee.
3. A ruffled tiered saree — three soft tiers falling from the hip, the tiers fanning when she turns and resting against each other when she stops.
4. A mermaid saree: fitted to the knee, flaring below, with a pleated train that trails and lifts a half-beat behind her.
5. A pant saree — the drape carried over a wide-leg trouser, the pleat stack crossing the front of the waist.
6. A saree caught under a worked waist belt, the fan hanging free below it and the belt reading as its own line.
7. A saree with a knotted-front bodice: the pallu drawn across the chest and tied once at the front, the knot sitting proud of the fabric.
8. A half-saree: a pleated skirt and a fitted bodice, the drape pinned at the shoulder and falling over one arm.

## BLOUSE ARCHETYPE
> The blouse is half the look. Name the archetype and the sleeve, never just "a blouse".
1. A halter shell: a high neck with concentric rows of pearl and crystal laid edge to edge, the arms bare.
2. A bandeau with a broad worked waistband, the midriff clear above it.
3. A knot-front blouse: the cloth twisted once and tied at the centre, a small fixed knot or a soft bow.
4. A corset blouse: boned panels, a straight neckline, hooks at the back, sitting snug to the waist.
5. A high-neck blouse with a lace yoke and a covered back, the sleeve ending at the elbow.
6. A cape-sleeve blouse: the sleeve cut away at the shoulder so it falls as a short cape.
7. A long-sleeve blouse worked edge to edge in gold, the sleeve finishing in a worked cuff.
8. A jacket-blouse: a structured front with real buttons, worn closed over the drape.

## LEHENGA CONSTRUCTION
> The lehenga's build decides how it moves: the panel line, the flare, the train.
1. A kalidar lehenga — deep panels flaring from the hip, the panel lines reading as she turns.
2. A mermaid lehenga with a train, fitted to the knee and flaring from it.
3. A tiered lehenga — three tiers of soft silk, every tier's hem worked.
4. A lehenga under a sheer cape pinned at the shoulders and falling behind the skirt.
5. A jacket lehenga: a worked jacket over a plain blouse, the jacket worn open.
6. A pre-draped dupatta lehenga, the drape already pleated and pinned across the chest.
7. A fishtail lehenga whose hem skims the floor and breaks at the ankle.
8. A lehenga caught under a belt with a removable overskirt at the waist.

## ANARKALI CONSTRUCTION
> Anarkali is a flare with a bodice: say where the flare starts and how the bodice is built.
1. A floor-length panel anarkali, the panels flaring from the waist to a worked hem.
2. A jacket anarkali: a fitted inner under a sheer jacket cut to the same flare.
3. A cape-sleeve anarkali, the shoulder opening as a short cape over the arm.
4. A gown anarkali — the bodice fitted to the hip, the skirt slim, the drape held at one shoulder.
5. A layered anarkali: a plain inner under a net over-layer, the two hems offset.
6. An angrakha-style anarkali, the front panels crossing and tied once at the side.
7. A chikankari anarkali in cotton, the flare soft and the hem worked in shadow-work.
8. A bodice-fitted anarkali with a broad worked waistband and a straight fall below it.

## GHARARA AND SHARARA
> The leg line is the whole look: name where it breaks and how wide it falls.
1. A gharara: fitted to the knee, then flared sharply below it into two wide, worked legs.
2. A sharara: two wide-legged panels falling straight from the waist, the hem heavy enough to swing and stop.
3. A patiala salwar with a short kurta, the pleats stacked at the hip.
4. A dhoti pant with a draped front pleat and a fitted top above it.
5. A gharara with a dupatta pinned flat across the chest and carried on one arm.
6. A sharara under a fitted jacket kurta, the kurta's hem stopping above the flare.
7. A palazzo set with a side-slit kurta, the pant leg wide and fluid.
8. A churidar with a long anarkali over it, the gathered line reading at the ankle.

## ETHNIC SET FORMAT
> A festive look is often a set, not a drape: name the pieces and how they read together.
1. A co-ord set: a worked top and a matching bottom in the same cloth and the same border.
2. A cape set: a fitted inner under a sheer cape cut to the shoulder line.
3. A jacket set: a structured jacket over an ethnic inner, worn open so the work shows.
4. A palazzo set: a worked top with a wide fluid pant and a dupatta worn as a sash.
5. A kurta-and-pant set with the dupatta carried rather than pinned.
6. A skirt-and-top set with the dupatta worn across one shoulder.
7. A sharara set with a short worked kurta and a heavy hem.
8. A saree-gown: the drape built into a gown, the pallu falling from one shoulder.

## EDGE AND HEM
> The edge is where a garment shows its making. Name the finish on the hem, the sleeve and the pallu.
1. A scalloped edge, every scallop worked in gold with a small drop at its point.
2. A ruffled edge: two soft flounces, hand-rolled and pressed so they stand away from the cloth.
3. A pearl-drop edge — one row of pearls hung along the hem, moving a half-beat after the cloth.
4. A broad gota border, flat and beaten into the ground rather than stitched proud of it.
5. A fringe of fine threads cut level, with enough weight at the hem to swing and stop.
6. A cutwork edge: the pattern cut out of the cloth, the openings reading as shadow on skin.
7. A mirror-work border — small round mirrors set in thread, each taking the bright zone.
8. A double border: a wide worked band with a fine line of gold running above it.

## MOOD
> The register she plays — carried in the shoulders and the eyes, never announced.
1. Unhurried and unbothered, hands where they fall, a half-smile that arrives on its own.
2. Composed and purposeful, chin level, weight on the back foot, watching rather than posing.
3. Warm and easy, caught mid-thought, laughing a beat before the lens expects it.
4. Quiet and self-possessed, eyes steady, the stillness of someone comfortable in her own room.
5. Bright and sociable, chin up, ready to move, the energy of a room she has just walked into.
6. Focused and level, breath working, the calm in the middle of effort.
7. Loose and sun-warmed, one shoulder dropped, a slow blink between beats.
8. Private and unhurried, absorbed in what her hands are doing, looking up last.

## AESTHETIC AND GRADE
> The look of the finished frame — name the grade, never a filter.
1. Workwear realism: warm daylight, slight desaturation, fine grain, no lift in the blacks.
2. Quiet editorial: neutral grade, soft contrast, highlights held back, fine grain.
3. Domestic naturalism: window light, low contrast, real texture kept, nothing crushed.
4. Clean performance: crisp key, honest skin, whites clean, no gloss and no glow.
5. Low-key glamour: deep blacks, one specular per frame, colours kept true, no sparkle filter.
6. Warm festival: rich colour, controlled highlights, a touch of grain, nothing neon.
7. Documentarian: natural colour, raking light, matte grade, the room allowed to be itself.
8. Street reportage: hard sun, punchy colour, gritty grain, blacks slightly open.


## SPACE AND DRESS
> The room is a place, never a sweep. Three planes, named materials, real objects, one practical source.
1. A near doorway or counter edge soft in the foreground, a limewash wall with a picture rail, a worn wood floor, a chair with a throw, a lamp that is on, a plant by the window.
2. A carved stone pillar at the frame's side, a courtyard falling away behind with arches, a brass pot, an oil lamp, a rug at the edge of frame, a lit doorway at the back.
3. A glass partition and a meeting table edge in the near field, oak and stone beyond, blinds half down, a desk lamp on, folders and a cup where they were left, the street moving past the window.
4. A hanging curtain at the frame's side, a velvet bench, a lit niche in a dark wall, a mirror catching one edge of the light, a tall drape, a floor with a faint sheen.
5. A coat rail with a second coat on it, panelling receding, a bench, a mirror, an umbrella stand, a shaft from a high window across the floorboards.
6. A rack and a bench at the frame's edge, studio boards or a mirrored wall receding, rubber flooring, a ball, a towel over the rail, chalk on the floor, hard light from a window at the back.
7. Rough brick or board-marked plaster, a scuffed concrete floor, a crate, a stool, a bicycle leaning on the wall, a coiled cable, a high window throwing a hard shaft.
8. A low table and floor cushions in the near field, a jaali screen, a block-printed hanging, a lantern that is on, a brass tray, a potted plant, a terracotta floor.


## CAMERA
1. Low-angle dolly-in on a 35mm, ending tight on the garment detail, shallow focus.
2. Handheld follow at chest height, one step behind the subject, reacting to her turns.
3. Locked-off wide on a 50mm, letting the subject cross the frame, no movement at all.
4. Slow lateral tracking with a 85mm, the foreground dissolving past the lens.
5. Orbiting arc at shoulder height, one continuous half-circle, the background turning behind her.
6. Crane-up revealing the environment after a tight open on the fabric.

## CREW
The crew on a shoot is optional — option 6 is a shoot with nobody in frame, and any option can be
overridden by writing the field as NONE. Whichever is drawn, at most two crew beats appear in a clip,
each about a second, always a cutaway between her beats, always inside the same light.

1. A solo photographer, one body, no assistant — crouched at the shutter, the whole crew in one person.
2. A photographer with a second body slung, and a digital tech at a tethered laptop just outside the light.
3. A photographer, one assistant turning a reflector, and a stylist standing by with a garment bag.
4. A duo at work: photographer firing and an assistant holding a boomed softbox an arm's length out of frame.
5. A small team of three — photographer, first assistant on the key, and a gaffer at a stand in a doorway behind.
6. No crew in frame at all — a shoot read only in the shutter click, the light and the marks on the floor.

## BRIDAL GARMENT

> **2026 register — hand work is the money, and the blouse is the hero piece.** Two directions, both current: the LIGHT register (raw silk, tissue, organza, dupion, brocade, chanderi — a look that moves) and the HEIRLOOM register (deep red or marsala with heavy hand-embroidered blouse, skirt and veil border — zardozi, resham, dabka, marori, pearl-and-bead fringe). Do not push one at the expense of the other: what is actually over is MACHINE sparkle — all-over mirror work (the "disco ball" era), industrial sequin scatter, and "zari work" with no technique or motif named. Heavy hand work is wanted. Name the silhouette, the blouse cut, the hem and its deep worked border, the embroidery TECHNIQUE and its motif, and the fabric weight.
1. A raw-silk lehenga in oxblood with a scalloped hem and a structured corset blouse, hand gota-patti vines climbing the blouse and spilling onto the border, the skirt light enough to move.
2. A pre-draped tissue-silk saree-gown in old rose with an off-shoulder blouse, the pleats stitched so the drape falls once and holds, a fine zardozi border at the hem only.
3. A fish-cut lehenga in champagne antique-gold tissue with a contrasting emerald raw-silk blouse, no machine work anywhere, the shine coming from the metal thread rather than sewn mirrors.
4. An ivory chanderi lehenga with an organza CAPE replacing the dupatta, a sweetheart-necklined blouse with covered back, gold kasab edging on the cape's scalloped hem.
5. An heirloom re-cut: her grandmother's banarasi saree rebuilt as a modern lehenga with a plain handloom blouse and the original border kept intact at the hem — the only embroidery in the look is the heirloom's.
6. A pistachio-green organza lehenga layered over a solid silk skirt so the colour deepens toward the hem, blouse with a high neck and a covered back, tiny pearl clusters at the cuffs.
7. A mermaid-line lehenga in deep emerald silk with a slim gold-belted waist (kamar bandh silhouette), the flare starting mid-calf, blouse in the same silk with a jewelled neckline instead of a necklace.
8. An ombré lehenga from ink navy at the waist to powder blue at the hem, dual-tone blouse (solid navy, powder-blue piping), blouse cut as a modern halter with a covered armhole.
9. A rani-pink dupion lehenga with a bandhani-draped skirt and an organza cape, the bandhani dots the only pattern in the frame, blouse as a front-buttoned shirt-cut with a mandarin collar.
10. A jacket lehenga: a brocade jacket with bracelet sleeves over a plain crepe skirt and bustier, the jacket's woven pattern carrying the whole design, no embroidery added on top of it.

## ORNAMENT SET

> **One dominant piece, everything else answers it (2026 styling).** Chokers and layered necks lead: a close choker with one long haar, polki revived in its raw uncut form, temple gold back for traditional ceremonies, pastel stones for pastel looks. Balance is the craft — an oversized maang tikka or matha patti runs with MEDIUM earrings and a pared choker, never full jhumkas as well; if the choker is wide, the long haar is single, never stacked twice. Pastel lehenga takes diamond or rose gold; red and deep colour take polki or kundan; silk takes temple gold. Prefer detachable, re-wearable architecture over one welded set.
1. One oversized polki choker worn alone with a matching matha patti and medium diamond studs — no long haar, the whole look hanging on one piece.
2. A double-layer diamond choker over a single rani haar of emerald drops, matching jhumkas kept medium length, nothing else on the neck.
3. Temple gold: a broad antique-finish gold choker over a long haram, temple jhumkas and stacked antique bangles, no diamonds or coloured stones anywhere in the frame.
4. Pastel bride: a rose-gold and aquamarine choker with a slender long chain, pearl-drop earrings and a fine diamond maang tikka — the stones echo the pistachio and blush in the garment.
5. Kundan with meenakari on the reverse, choker plus one short haar, a borla maang tikka and a nose ring for a Rajasthani register, bangles stacked to the forearm.
6. Polki and pearl: an uncut polki choker, one pearl-and-gold long haar, a single oversized tikka, plain gold studs — pearls answer every layer.
7. Modern minimal: one sleek diamond choker, a thin diamond matha patti, one emerald ring set, earrings as small hoops; the look is restraint, not absence.
8. South Indian register: an antique-gold haram layered over a choker, temple jhumkas with pearl drops, an oddiyanam-style gold waist belt over the skirt, no north-Indian pieces mixed in.
9. A statement emerald-drop tikka down the parting with medium earrings and a plain gold choker, so the head piece is the argument and the neck stays quiet.
10. Polki and rose (the fine-jewellery campaign look): a broad uncut-polki choker with rose-pink stone drops laid over two strands of pearls, tiered polki-and-pearl jhumkas, a rose-stone statement ring on the ring hand, the bangles left quiet — every answer in the set is either pearl or rose.
10. Heirloom mix: her mother's polki choker with one new long rose-gold chain, a modern diamond ring, and a temple bangle — three eras in one look, matched by metal finish rather than by design.

## METAL AND STONE

> **One metal family for the whole look**, its finish named (antique, brushed, high-polish, rose), and the stones chosen against the garment's colour rather than for their own sake.
1. Antique-finish gold with uncut polki and a single emerald drop — the raw, unpolished face of the stones left visible.
2. Rose gold with aquamarine and baroque pearls — cool pastel stones against warm metal, nothing high-polish.
3. 22k temple gold, no stones at all — the work is in the relief and the antique finish.
4. High-polish white gold with diamond and a pair of emerald accents, the emerald only at the ears and the tikka.
5. Brushed two-tone gold and silver with pearls — the modern mixed-metal register, finishes kept matte so the mix reads as intentional.
6. Meenakari enamel on the reverse in a colour taken from the garment, gold on the face, no stones beyond pearls.
7. Antiqued gold with ruby and a touch of green enamel — deep colour for a winter or evening bridal look.
8. Rose gold with rose-quartz beads and a single diamond drop, the palette deliberately quiet so the fabric leads.

## VEIL

> **The veil is styled, never draped.** 2026 favours the cape, the double dupatta and the structured throw; name which edge is embroidered and how it is held, so it reads as a designed decision.
1. A scalloped organza cape in the garment's accent colour, worn INSTEAD of a dupatta, its edge hand-finished.
2. A double dupatta: a fine tissue veil over the head with a gota edge, and a lighter bandhani one thrown over the forearm.
3. A plain net veil with a pearl-scattered border, caught at one elbow so it falls in one long line.
4. A structured dupatta pleated across the chest like a sash and pinned at the shoulder — the drape itself is the styling.
5. A heavy silk veil with a woven heirloom border, worn over the head only for the closing portrait.
6. A butterfly-net veil with a kasab edge, held in both hands in front of her rather than draped on the head.
7. No veil at all — the cape or the blouse's covered back is the statement, and the head stays open with only the tikka.

## MEHENDI

> Name the pattern TRADITION, the coverage and how fine the lines are — henna reads as a stain on skin, never as a brown flat shape.
1. Fine-line arabesque to the elbow, minimal density, the gaps of skin as important as the lines.
2. Traditional bridal jaali to the elbow, full coverage, deep brick-red stain at the edges and softer at the wrist.
3. Wrist-and-forearm bands only, botanical fine line, modern and sparse.
4. Full-hand bridal with a mandala on the palm and vine-covered fingers, deep stain, traditional.
5. Marwari density: to the elbow, motif-heavy, with her partner's initial worked into a hidden corner.
6. Minimal — a single motif on the back of each hand and a thin band at the wrist, nothing further up the arm.

## GARMENT

> For the jewellery films: the garment is the quiet ground the set is read against — one fabric, one colour, one construction detail, and no embroidery competing with the ornaments.
1. A raw-silk blouse in the same family as the skirt, closed and structured, with a precise neckline the choker can sit above.
2. A high-necked tissue blouse with covered buttons, the neckline plain so the haar falls on skin.
3. A corset-cut brocade blouse with a sweetheart neckline, no embroidery, the weave doing the work.
4. A plain crepe blouse with bracelet sleeves and a deep back, cut so the kamar bandh line stays visible.
5. A handloom cotton-silk blouse, undyed, deliberately plain against a heavy heirloom border.

## DENIM AND WASH
> The denim piece is never "jeans" — the wash, the weight and the fade are the look.
1. Raw indigo, rigid and unsanforised, with the crease still in it and the colour deep enough to read as navy.
2. Mid-blue vintage wash, softly broken in at the thigh and the seat, the hem frayed a little.
3. Faded light wash, nearly pale across the front, with a clean dark seam running through it.
4. Ecru or natural canvas, unbleached and matte, with contrast stitching.
5. Washed black, grey-fading at the knee, with brushed hardware and no shine.
6. Heavy selvedge, dry and dark, with a selvedge line at the outseam and a cuff that stands on its own.

## WEAVE AND TEXTILE
> For the saree and the handloom set: the weave decides how the drape moves and how the light lands on it.
1. Banarasi silk-brocade, the ground shifting colour in the light, zari laid in the buta and the border.
2. Kanjeevaram with a temple border and a contrast pallu, the settle of the cloth heavy and deliberate.
3. Chikankari on mulmul, white-on-white thread over a cloth light enough to move on its own.
4. Bandhani on georgette, the dots pulled tight in a pattern, the cloth fluid and faintly sheer, lined as stated.
5. Patola double-ikat, the motif identical on both faces, colour saturated edge to edge.
6. Handloom linen or cotton, the slub visible, the drape crisp and folding in straight lines.

## STONE PALETTE

1. Uncut polki with one emerald drop at the centre of every piece.
2. Pearls and tiny diamonds, no colour at all — the quiet palette.
3. Emeralds with gold, one ruby accent on the tikka only.
4. Aquamarine and rose quartz against rose gold.
5. Rubies with antique gold and green enamel detail, deep and warm.
6. Moissanite-bright white stones with a single sapphire, the modern cool palette.

## METAL

> The metal is a design decision: name the finish, and keep one family across every piece in frame.
1. Antique 22k gold, brushed, no high polish anywhere.
2. Rose gold with a matte finish so the stones do the shining.
3. High-polish yellow gold, mirror-bright, with uncut stones that stay raw against it.
4. Two-tone gold and silver, both brushed, the modern mixed-metal look.
5. White gold, bright, with black rhodium detail in the recesses of the setting.
6. Meenakari-bright gold, the enamel colour pulled from the garment.

## LIGHT

> Name ONE light design and hold it — the light is furniture in these films, not a mood. State where it comes from, what it falls on first, and how deep the shadow side goes.
1. Hard low sun through a carved screen, the pattern of the jaali thrown across her and the wall.
2. One large soft window from camera-left, a dark fall behind her, the jewellery's highlight doing the sparkle.
3. A single warm practical (a lamp, a lantern) close to her face, everything past arm's reach falling to black.
4. Open shade under a colonnade, one bright edge of sun raking the hem and the juttis.
5. A shaft of light crossing the room, positioned so the skirt passes through it as she turns.
6. Bounced light off a pale stone floor, soft and shadowless, the fabric's texture carrying the frame.
7. Two sources only: a cool window and a warm practical, the mix keeping the metal honest.
8. Late golden hour with the sun at her back, the veil going translucent and her face lit by bounce.

## GLAM GARMENT

> **This decade's couture, not the heritage catalogue — and for an Indian bride that means INDIAN contemporary couture.** Sculptural, architectural, fabric-led: real boning, sculpted drapes, crystal, structured cut-outs, gazar and duchess satin, liquid lamé. In an Indian bridal request the silhouette is Indian and the construction is couture: a corseted lehenga, a pre-draped concept saree, a saree-gown, a cape lehenga. No heirloom banarasi, no mirror work, no gota-patti and no "zari work" unless the request asks for that register — the money here is in the construction, the fabric and the hand-set detail. Never a Western gown on an Indian bride.
1. A corseted lehenga in oxblood raw silk: real boning in the blouse, a sweetheart neckline, hand-set crystal at the bodice, and a skirt whose horsehair hem holds its own flare, sheer tulle sleeves.
2. A pre-draped concept saree in liquid satin lamé, midnight blue, sculpted pleats at the shoulder, a bare back closed by one jewelled clasp.
3. A saree-gown in ivory silk gazar with an architectural bow at the waist and a cathedral train — no embroidery anywhere, the cut is the design.
4. A crystal-encrusted column lehenga over a sheer corset blouse, thousands of hand-set beads, hair slicked back so the sparkle reads without competition.
5. A cape lehenga in emerald silk over a fitted jewelled bustier, the cape sweeping to the floor and pooling a metre behind her.
6. A jewelled bustier with a floor-length brocade skirt in deep emerald, a dupatta pinned at one shoulder like a sash, no other drape.
7. A metallic lamé lehenga in rose gold with a sheer organza blouse and a structured obi belt — the whole look in one metal family.
8. A high-slit column skirt in black velvet with a jewelled bustier and a tulle underlayer that catches the light as she moves.
9. A monochrome two-piece in bone white: a tailored satin bustier with a hand-beaded column skirt, worn with one diamond choker.
10. A tulle ballgown with a boned bodice and hand-appliqué petals from waist to hem — the volume built from layers of tulle, kept for requests that name no Indian element.


## LUXE JEWELS

> **High jewellery, styled the way couture is styled — and for an Indian bride that means Indian high jewellery.** In an Indian bridal request the coordinated set IS the styling: a choker with its maang tikka and studs, the bangles answering the neck. Keep **one dominant piece** with everything else answering it, and one metal family with its finish named. What stays banned is costume weight: full jhumkas under an oversized tikka, and a parure with nothing scaled back.
1. A polished polki choker in 22k gold with pearl drops, its matching maang tikka, medium studs and stacked bangles — the set read as one idea, no jhumkas.
2. A heavy emerald-and-gold choker with one wide maang tikka, bare ears, and a kamar bandh across the waist with pearl drops.
3. Three fine diamond chains layered at different lengths, a diamond maang tikka on the parting, a diamond climber on each ear.
4. A statement ruby-and-diamond necklace with a matching cocktail ring and bare ears — the neck is the argument.
5. A modern headpiece: a diamond line running the centre parting to a single pear-shaped drop, medium studs, a plain platinum choker.
6. A temple-gold short necklace with a fine diamond second layer, matching studs, and gold bangles stacked to the elbow.
7. A rose-cut polki choker worn DOWN: with a sheer-sleeve blouse and one thin diamond bangle, so the polki reads modern instead of bridal-heavy.
8. A diamond body chain draped across a bare back with a small matching choker — jewellery built for a backless cut.
9. A diamond rivière choker worn alone with long diamond line earrings — the Western-couture statement, for requests that name no Indian element.
10. Ear architecture — a diamond ear cuff climbing the helix with an emerald drop below, that side of the hair pulled back, no necklace at all.


## GLAM BEAUTY

> **Modern glamour: skin with real texture and glass-light, a sculpted contour, an eye with a point of view, a lip with colour — and hair styled to show the jewellery rather than fight it.** For an Indian bride the eye carries kajal and the parting gets dressed, because the maang tikka sits on it.
1. Wet-look sleek middle-part bun with the maang tikka on the parting, glass-skin base, smoked bronze eye with kajal through the waterline, glossy nude-brown lip, almond nails in one neutral.
2. Open glossy waves swept to one side, dewy skin, a fine graphic liner wing, deep berry lip, hair moved off the shoulder so the neck stack reads.
3. Sleek low bun with baby hairs laid flat, sharp contour, smoked kajal eye, deep rose-brown lip, nails in deep red.
4. Sculptural braided updo with a pearl strand woven through it, bare luminous skin, soft smoked lash line, rose lip.
5. Blunt shoulder-length bob with high shine and no visible makeup weight — luminous skin, brushed-up brows, one coat of plum gloss.
6. Low chignon with a clean finish and the tikka sitting on the parting, sharp contour, a graphic double-wing liner, oxblood lip.
7. Half-up centre part with loose ends, a silver foil-finished eye, glossy caramel-nude lip.
8. Voluminous side-parted waves, matte flawless skin, classic red lip, studs the only jewellery above the neck.


## MODERN SET

> **Contemporary architecture and negative space — the room is expensive because it is clean, not because it is old.** For an Indian bridal request the space is Indian-modern: stone, glass, water and jali used as architecture, never a rustic courtyard and never a set dressed as a costume.
1. A veined-marble hall with one enormous window and no furniture, light falling in a single clean shaft.
2. A palace-turned-hotel corridor: carved jali screens set into a glass wall, polished stone floor, nothing else in frame.
3. A contemporary atrium with a water court and one sculpture, light bouncing off the water in slow ripples.
4. A deep-green paper sweep, seamless floor to wall, a single plinth at the frame edge — the editorial ground.
5. An infinity terrace at night, city lights as bokeh beyond the water, one warm key on her.
6. A mirrored ballroom with one crystal chandelier, polished parquet reflecting the hem.
7. A modern colonnade in pale stone, the arches repeating to a vanishing point.
8. A brutalist concrete stairwell under one skylight — monumental scale with her small in it.


## JEWEL METAL

> One metal family for the look, its finish named, kept consistent across every piece in frame.
1. Platinum, bright and cool, diamonds at their whitest.
2. White gold, brushed, so the stones do all the shining.
3. 22k yellow gold, high polish — the modern wedding-gold register.
4. Two-tone: platinum settings on 18k yellow gold, one family across every piece.
5. Rose gold with rose-cut stones, warm and soft.
6. White gold with black-rhodium detail recessed in the settings, a cool modern edge.

## GLAM PALETTE

> **One family per look, 60/30/10 — the garment, one secondary, one accent, with the finishes named.** Say where the light falls, because in these films the light is part of the design.
1. Champagne and bone — liquid champagne base, bone secondary, crystal accent, satin finishes.
2. Midnight and silver — deep midnight base, silver hardware, diamond accent, matte against liquid.
3. Ivory and emerald — ivory base with emerald at the jewellery and the cape lining, gold hardware.
4. Blush and rose gold — blush base, rose-gold hardware, pearl accent, soft matte.
5. Bone-white monochrome — one bone tone head to toe, texture the only variation, silver jewellery.
6. Oxblood and black — oxblood base with black hardware, matte velvet finish, white diamonds as the accent.

## GLAM LIGHT

> One light design, stated once and held — with the source named and the falloff described.
1. One large soft window from camera-left, everything past arm's reach falling to black.
2. A hard shaft of late sun crossing the room diagonally, catching the crystal as she moves through it.
3. Cool blue-hour ambient with a single warm practical on her face — two sources, mixed.
4. Chandelier light with thousands of small specular highlights, the room doing the sparkle.
5. Water bounce: light reflected off a pool moving across her in slow ripples.
6. One strip light behind for a rim, the front lit only by bounce — silhouette with detail.
7. Daylight through sheer curtains, the shadow of the fabric falling across her.
8. Gallery light: one wide, even source, high and frontal, no drama, all detail.

## EMBROIDERY

> **Name the technique AND the motif — this is what the macro beats exist to prove.** Hand work: thread that reads matte, metal that reads raised, pearls that sit on top. Over: machine mirror scatter, flat sequin fields, and "heavy embroidery" with nothing named.
1. Zardozi with antique-gold dabka on deep red, the embroidery raised a millimetre off the silk, florals repeated across blouse, skirt and veil border.
2. Resham thread embroidery in two tones — pink and green on deep red — with a fine gold outline, the thread matte and the motifs reading as painted rather than metallic.
3. Scalloped borders worked in pearl and bead fringe at the blouse hem and the veil edge, the skirt's hem carrying the same work deep and heavy.
4. Gota-patti vines in antique gold climbing the blouse and spilling onto the skirt border, the appliqué edges catching light as raised metal.
5. Marori and sitara work — tiny curved sequins stitched in spirals with gold thread, the whole surface textured so the light moves across it in small steps.
6. Aari work in silk thread: fine running stitches filling paisley and vine motifs, one dense worked panel on the sleeve and the bodice.
7. Zardozi borders framing turquoise and rose-pink jewel-thread florals on marsala silk — colour inside the metal, the way an heirloom piece carries several thread tones.
8. Kiron fringe: a deep border of gold-thread fringing at the skirt hem and the blouse edge, moving with her.
9. Naqshi and dabka with small uncut stones stitched into the work, the stones sitting inside the embroidery rather than on it.
10. Fine net embroidery on the veil only: gold thread worked so densely the veil reads as a lattice of flowers over her face.

## HEIRLOOM PALETTE

> **Deep colour, antique gold, and ONE accent — the accent is what keeps an heirloom look from turning into a single flat red.**
1. Deep red with antique gold and an emerald accent at the stones — the classic, kept rich rather than bright.
2. Marsala with burnt antique gold and turquoise thread accents inside the embroidery.
3. Oxblood with chandan-gold work and a pearl accent at the fringe and the veil border.
4. Rani pink with two-tone gold and green thread, no red anywhere — the same craft, a different woman.
5. Wine with antique gold and one ruby accent at the tikka and the ring.
6. Deep red with two-tone resham (rose and olive) and no metal in the embroidery at all — thread-only, matte, and expensive for it.
7. Ivory with antique gold and a single deep-red accent at the jewellery, for the bride who refuses red.
8. Ink-wine with silver-gold mixed work and one sapphire accent — the cool heirloom register.

## STUDIO GROUND

> **One ground, no tour.** The sweep is the house look: a plain paper backdrop or one clean set whose colour is chosen against the garment, lit so it falls off into shadow behind her.
1. A deep-green paper sweep, seamless floor to wall, falling to a soft shadow behind her.
2. A bone paper sweep with a warm-grey falloff — the red reads loudest here.
3. A dusty-rose sweep, tonally close to the garment so the embroidery does the separating.
4. A charcoal seamless with one hard key — the metal and the pearls read as the only light.
5. A single palace corner: one carved jaali panel and a white pillar, everything else out of frame.
6. A polished stone floor with a plain plaster wall and one step, nothing else in frame.
7. A soft grey-green sweep with one low plinth she can sit or rest against.
8. Sheer fabric swagged behind her on the sweep, one layer, so the ground has texture without becoming a set.
9. A full wall of repeating carved medallions — dark wood ovals with hand-painted rose, ochre and ivory medallions in a grid — lit warm and falling off into shadow, the pattern reading behind her wherever she stands.

## FORM — how the film is built

> **The content pools change what is in the frame. These change the edit itself** — and the edit is
> what makes two outputs read as two different films rather than one film with a different model in
> it. A batch must not share its **RHYTHM ENVELOPE**, **SCALE LADDER**, **FRAMING DEVICE** or
> **CUT MOTIVATION** with another variant, even if it shares the woman, the room and the garment.
> These are drawn per generation like any other pool — take option #k, all four of them.

## RHYTHM ENVELOPE
> The shape of the shot lengths across the film — not how many shots, but how the time is spent.
> Measured film practice: real films are neither even nor random, their shot lengths cluster (long
> with long, short with short). An evenly-cut film reads as machine-made.
1. Flat one-second rhythm — every beat the same length, a metronome; the jewellery-campaign cut.
2. Slow burn — a long opening beat that develops, each following shot shorter, accelerating to the close.
3. Decelerating — a quick flurry at the top, the shots lengthening as the film calms into the close.
4. Bookend — a long opening and a long closing shot with the tight beats crowded in the middle.
5. Clustered — long and short grouping the way real films cut: long, short, short, long, short, medium.
6. Stutter then pop — a burst of very short cuts, then one long held shot that lands the film.
7. One held opening — the first shot runs twice as long as any other, then the film finds its pace.

## SCALE LADDER
> The sequence of frame sizes, which is a separate decision from how long each shot lasts.
1. Monotonic tighten — establish at full length, every following shot closer; the classic ladder.
2. Tighten then release — open close on a detail, pull back to the whole look, then in again for the close.
3. Detail first — open on one detail (a hand, a hem, the jewellery), reveal the whole look, return to the detail.
4. Alternate — wide, tight, wide, tight: rhythm built from size, not from duration.
5. Plateau — one distance for the whole film, the variation carried by her acts and the light.
6. Inverted — close open, wide middle, close end; intimacy first, context second, intimacy last.
7. Coverage grid — one beat shot as a 3×3 grid of three distances and three heights, then cut from the nine for the six that matter: the film is assembled from coverage rather than chosen once.

## CUT MOTIVATION
> What earns each cut. Name it and the edits stop feeling arbitrary.
1. On the act — the cut lands at the peak of her movement, where the eye is already tracking.
2. On sound — the cut lands on a hit in the audio bed, the shot changes on the beat.
3. On her gaze — the cut lands the instant she looks away from the lens, or the instant she finds it.
4. On her breath — the cut lands as she exhales and settles, the beat changing with the breath.
5. On a shutter — a shutter click makes the frame change: the shoot cuts itself.
6. On a graphic match — the outgoing shape answers the incoming one: a bangle's circle to a choker's arc, a hem's line to a wall's edge.

## FRAMING DEVICE
> How the camera finds her — the spatial idea of the film, separate from the lens itself.
1. Direct — eye-level or chest-height, unobstructed, the classic editorial address.
2. Through a layer — net, gauze, sheer veil, foliage, rain, glass between the lens and her.
3. Reflection-led — she is read in a mirror, a window, wet stone or a polished floor.
4. Backlit silhouette — the key behind her, the garment's edge doing the drawing.
5. In an architectural frame — doorway, arch, window, corridor mouth, the architecture cropping her.
6. From the ground — the lens low, the floor and the hem sharing the frame, the look tower-like.
7. From above — the lens high, the circle of the skirt and the top of her head doing the geometry.
8. Over the shoulder — the crew's view: the photographer's shoulder, the back of the camera, her within it.

## OPEN DEVICE
> How the first shot starts — the film's first decision.
1. Walk-on — she comes onto her mark with two grounded steps, already the subject of the shot.
2. Mid-act — the film starts inside an action, as if it had been running before the cut.
3. Detail first — hands, jewellery, a hem, a crumpling sleeve: the film introduces a fragment of her.
4. Light arriving — the frame starts itself empty or dim and she is revealed as the light finds her.
5. Entering frame — she crosses the edge of a frame that was already there, camera unmoved.
6. Already settled — she stands in her final mark from the first frame, stillness broken by breath.

## CLOSE DEVICE
> How the last shot ends — the film's last decision.
1. Gaze hold — she finds the lens and holds it as the shot ends, the frame still breathing.
2. Look down then up — she drops her eyes, then lifts them to the lens on the final beat.
3. Last act finished — a small completed action (the fabric settling, the hand leaving the hem) ends the shot.
4. Step out of frame — she leaves the frame edge, the place she leaves behind holding the last beat.
5. Turn back in — she turns away inside the shot and returns to face the lens on its last beat.
6. Stillness held — the shot ends on a held, living-still frame, the breath and the light the only motion.

## TRANSITION
> What happens at the cut itself.
1. Hard cut — straight from one frame size to the next, no softening.
2. Cut on movement — the outgoing and incoming frames share a movement direction, so the seam disappears.
3. Through the sheer — the cut dissolves through a veil, net, fabric or smoke crossing the lens.
4. Match cut — an outgoing shape, line or colour repeats in the incoming frame.
5. Cut on the shutter — the frame changes exactly on a shutter click or a flash.
6. Invisible cut — a fast gesture or a whip of fabric hides the cut inside the movement.

## SOUND FORMAT
> What the audience hears, decided as a form choice.
1. Score-led — the music carries the film and the diegetic sound sits under it.
2. Diegetic only — no score at all: footsteps, fabric, jewellery, breath, room tone.
3. Click-led — a shutter, a clap or a clasp sets the rhythm and the cuts follow it.
4. One accent — near-silence with a single diegetic event landing at the film's turn.
5. Ambient build — room tone that grows into a bed, everything else staying real.

## Beat flow (paired with the pools)

The pools say WHAT varies; the template's `flows:` line says HOW the beats are arranged. Every upgraded
fashion template carries four flows. A run with 3 variants therefore delivers 3 different beat
architectures × 3 different outfits × 3 different models × 3 presentations × 3 actions × 3 outfit
interactions × 3 locations × 3 camera languages — one template, 3^8 distinguishable outputs.
