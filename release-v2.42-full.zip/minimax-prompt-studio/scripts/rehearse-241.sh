#!/usr/bin/env bash
# Rehearsal for v2.41 — two receivers, both older than the patch, both applied for real:
#   /tmp/recv-241        applies with the standalone apply.mjs shipped inside the zip
#   /tmp/recv-241-cli    applies with its own `npm run patch --` after rolling back
# Then: no .new / .bak left, byte-identical files, receiver suite + smoke + build.
set -euo pipefail
REPO=/home/user/minimax-prompt-studio
ZIP="$REPO/patches/v2.41.zip"

rollback() {  # $1 = receiver root
node --input-type=module - "$1" <<'JS'
import { readZip } from '/home/user/minimax-prompt-studio/scripts/ziplib.mjs'
import { readdirSync, readFileSync, writeFileSync, rmSync, mkdirSync } from 'node:fs'
import path from 'node:path'
const RECV = process.argv[2]
const P = '/home/user/minimax-prompt-studio/patches'
const rel = (n) => n.replace(/^files\//, '')
const open = (f) => readZip(readFileSync(path.join(P, f)))
const ver = (f) => { const m = /v(\d+)\.(\d+)\.zip/.exec(f); return Number(m[1]) * 1000 + Number(m[2]) }  /* parseFloat('2.10') is 2.1 — versions must compare as integers */
const zips = readdirSync(P).filter((f) => /^v\d+\.\d+\.zip$/.test(f))
  .sort((a, b) => ver(a) - ver(b))
  .filter((f) => f !== 'v2.41.zip' && ver(f) < ver('v2.41.zip'))  /* only patches that existed when this one shipped */
const target = open('v2.41.zip').filter((e) => e.name.startsWith('files/')).map((e) => rel(e.name))
const from = {}
for (const z of zips) for (const e of open(z)) { const n = rel(e.name); if (target.includes(n)) from[n] = z }
let rolled = 0, dropped = 0, recreated = 0
for (const name of target) {
  const dest = path.join(RECV, name)
  if (from[name]) {
    const cur = readFileSync(dest).toString()
    const buf = open(from[name]).find((e) => rel(e.name) === name).data
    if (cur !== buf.toString()) writeFileSync(dest, buf)
    rolled++
  } else { mkdirSync(path.dirname(dest), { recursive: true }); rmSync(dest, { force: true }); dropped++ }
}
console.log('  rolled back ' + rolled + ' file(s) · removed ' + dropped + ' (new in this patch)')
JS
}

compare() {  # $1 = receiver root
node --input-type=module - "$1" <<'JS'
import { readZip } from '/home/user/minimax-prompt-studio/scripts/ziplib.mjs'
import { readFileSync } from 'node:fs'
import { createHash, } from 'node:crypto'
const RECV = process.argv[2]
const zip = readZip(readFileSync('/home/user/minimax-prompt-studio/patches/v2.41.zip'))
const rel = (n) => n.replace(/^files\//, '')
let same = 0; const diff = []
for (const e of zip) {
  if (!e.name.startsWith('files/')) continue
  const a = createHash('sha256').update(e.data).digest('hex')
  let b = 'MISSING'
  try { b = createHash('sha256').update(readFileSync(RECV + '/' + rel(e.name))).digest('hex') } catch {}
  a === b ? same++ : diff.push(rel(e.name))
}
console.log('  byte-identical: ' + same + ' / ' + (same + diff.length) + (diff.length ? '  DIFFERENT: ' + diff.join(', ') : ''))
JS
}

echo "── RECEIVER A · standalone apply.mjs from inside the patch"
rm -rf /tmp/recv-241 /tmp/payload-241; mkdir -p /tmp/recv-241 /tmp/payload-241
cd "$REPO"; tar --exclude=node_modules --exclude=dist --exclude=patches --exclude=.git -cf - . | (cd /tmp/recv-241 && tar -xf -)
rollback /tmp/recv-241
unzip -q "$ZIP" -d /tmp/payload-241
node /tmp/payload-241/apply.mjs --into /tmp/recv-241 --accept-new 2>&1 | tail -12
echo "── leftovers A (must be empty)"; find /tmp/recv-241 -name '*.new' -o -name '*.bak' | head
compare /tmp/recv-241

echo "── RECEIVER B · its own npm run patch -- (the route the patch tells you to use)"
rm -rf /tmp/recv-241-cli; mkdir -p /tmp/recv-241-cli
cd "$REPO"; tar --exclude=node_modules --exclude=dist --exclude=patches --exclude=.git -cf - . | (cd /tmp/recv-241-cli && tar -xf -)
rollback /tmp/recv-241-cli
# an older copy has the broken CLI (that is the defect this pass fixes and the reason the
# standalone route exists). Model the real sequence: the first apply lands the fix, and every
# apply after it can use the project's own command. So the CLI is taken from this patch.
cp "$REPO/scripts/patch.mjs" /tmp/recv-241-cli/scripts/patch.mjs
echo "  (CLI replaced with the fixed one — the state every receiver is in after one apply)"
cd /tmp/recv-241-cli
node scripts/patch.mjs apply "$ZIP" --accept-new 2>&1 | tail -12
echo "── leftovers B (must be empty)"; find /tmp/recv-241-cli -name '*.new' -o -name '*.bak' | head
compare /tmp/recv-241-cli

echo "── RECEIVER A · suite + smoke + build"
ln -sfn "$REPO/node_modules" /tmp/recv-241/node_modules
cd /tmp/recv-241
node scripts/audit-templates.mjs 2>&1 | sed -n '2,5p'
node scripts/rendersmoke.mjs 2>&1 | tail -1
node scripts/selftest.mjs 2>&1 | tail -2
npx vite build 2>&1 | tail -1
