# Outfit tours — one tour for every wear type

*Nine tours added in v2.36, six more in v2.38, plus the space law (v2.37) they all share. Nothing in `tour-grammar.md` (the bridal, jewellery, quiet-luxury and hard-sun tours) was replaced — this is a second file beside it, and the six shipped tours were only given the same space law.*

> *"We need to cover more fashion outfit tour for different types of women wear."*
> *"Don't lock to simple room add more details, depth in room."*
> *"Swimwear, Bohemian, Nightwear, Lingerie etc?"*

The tour engine was built on the room outfit tour: a locked camera, an entrance, feature beats that only fire when the idea names the element, a flow library, and cut times derived from the live clock. It only knew four registers. These passes give the other wear types their own tours, using the same machinery and the same laws.

## The fifteen tours — `public/prompts/templates/outfit-tours.md`

| Tour | What the film is about | Flows |
| --- | --- | --- |
| **👖 Denim** | the wash, the weight and the fade — and the stack breaking at the ankle | THE WASH FIRST · WALK AND STACK · DENIM ON DENIM · CLOSE FIRST |
| **🧥 Coat** | the outer layer carried, turned, opened and **taken off** | COAT ON FIRST · THE REMOVAL · COLLAR AND CUFF · CLOSE FIRST |
| **🧶 Knit** | soft, close and unhurried — the stitch and the cuff under one fall of light | SLEEVE AND STITCH · SIT AND SETTLE · TEXTURE FIRST · CLOSE FIRST |
| **👟 Athleisure** | gym to street: fabric *under load* — the stretch, the lunge, the seam | STRETCH AND HOLD · MAT TO MARK · POCKET AND HOOD · CLOSE FIRST |
| **👗 Evening** | the gown: the drag of the hem, the slow half turn, the read of a back | HEM FIRST · THE TURN · BACK AND LIGHT · CLOSE FIRST |
| **✨ Festive ethnic** | kurta, co-ord or anarkali for a **festival** — deliberately never a wedding | SIDE SLIT FIRST · HEELS AND HEM · DUPATTA AND DRAPE · CLOSE FIRST |
| **🧣 Saree** | six yards: the pleat fan, the pallu over the arm, the border through her fingers | PLEAT AND PALLU · BORDER RUN · WALK AND TUCK · CLOSE FIRST |
| **🧕 Modest** | abaya, kimono or modest co-ord: drape, sleeve, belt, hem | SLEEVE AND DRAPE · BELT AND LINE · HEM AND FLOOR · CLOSE FIRST |
| **👔 Tailoring** | the suit: line, posture and the quarter turn — fabric that never flies | BUTTON AND LAPEL · THE QUARTER TURN · DESK TO LIGHT · CLOSE FIRST |
| **🩱 Swimwear and resort** | sun, water and cloth — the strap, the tie, the cover-up on and off the shoulders | SHADE TO SUN · COVER-UP AND TIE · THE WATER LINE · CLOSE FIRST |
| **🧿 Bohemian** | layers with weight — the print, the fringe, the coin belt, the open road | LAYERS FIRST · PRINT AND FRINGE · THE ROAD · CLOSE FIRST |
| **🌙 Nightwear** | the slow morning — silk or brushed cotton under one window, steps, a knot at the waist | WINDOW FIRST · THE ROBE TIE · THE CUFF AND SEAM · CLOSE FIRST |
| **🖤 Lingerie** | the dressing-room film — silk, lace and posture, camera high, nothing revealed | SILK FIRST · THE ROBE · LACE AND EDGE · CLOSE FIRST |
| **🎿 Ski and apres-ski** | the cold and the kit — the long zip, the hood, the cuff over the glove, breath in the air | LAYERS FIRST · THE ZIP · SNOW AND SHADE · CLOSE FIRST |
| **🛹 Streetwear** | proportions and hardware — the layer, the hood, the cap, the strap, the hero sneaker | LAYERS FIRST · SNEAKER AND CUFF · THE CORNER · CLOSE FIRST |

Every tour is **12s · 9:16 · 768P** (👗 Evening, 🌙 Nightwear and 🖤 Lingerie are 2K) · **Static shot** · amp small · speed slow, with four flows and the full vary dimensions.

## What every one of them holds

### Fifteen vocabularies, not fifteen copies

Each tour owns its own words. **Every beat name in the pack is used by exactly one tour** — 119 distinct beat names — with the single house exception of **THE FACE**, which is the close in all fifteen because the law says the last beat is her face. **Every flow name is used by exactly one tour** too, apart from **CLOSE FIRST**, which every tour offers as an option. Measured per tour: each one owns **7–10 beats of its own**, and the heaviest has 10.

The old overlaps were real and are gone: ten tours used to share a beat called **THE WALK** (now THE WALL WALK · THE ARRIVAL · THE WALK IN · THE SIX-YARD WALK · THE QUIET WALK · THE CROSSING · THE DECK WALK · THE ROAD WALK · THE BOARDWALK · THE KERB WALK), seven shared **THE BACK**, six shared **THE TURN**, and three shared a flow called **LAYERS FIRST** (now SHAWL FIRST · KIT FIRST · ON THE KERB).

### The five fields every tour states

| Field | Where it lives | Example — 🧣 Saree |
| --- | --- | --- |
| **MODEL** | `{MODEL — 20-32 unless specified…}` in the idea | one age, hair and makeup, the mood she plays |
| **MOOD** | `{MOOD — …}`, its own pool (8) | poised and unhurried, one hand on the pleats |
| **LOCATION** | `{LOCATION — …}` + `{SPACE AND DRESS — …}` | a hall with depth and a lit zone she can walk toward |
| **PRESENTATION** | `{PRESENTATION — the register she plays}` | the register she plays — driven by the register line |
| **AESTHETIC** | `{AESTHETIC AND GRADE — …}`, its own pool (8) | documentarian: natural colour, raking light, matte grade |

No two tours share a mood or a grade — all thirty are distinct, and the lighting sentence that opens each tour is distinct too (15/15).

## Next level of realism

Every tour now carries a **REALISM FIRST** law, and the engine carries it as well:

> *The frame is a capture, not a render — skin keeps its texture, its fine hair and its own unevenness, fabric keeps its weave and the marks of a day, surfaces keep their wear, and the room's light behaves; micro-imperfection is welcome (a crease, a stray thread, dust in the air) and never takes a beat. No smoothing, no plastic sheen, no beauty filter, no morphing, no floating objects, no text in frame.*

Each register then names **its own material proof** — the thing that makes the frame read as real in that category:

| Tour | Its proof of realism |
| --- | --- |
| 👖 Denim | the twill's diagonal weave, the fade worn thin at the thigh, the raw edge of the rolled cuff |
| 🧥 Coat | the wool's nap, the leather creasing at the elbow, the lining showing at the vent |
| 🧶 Knit | the yarn's fuzz, the loop of the stitch, the rib stretched over a shoulder |
| 👟 Athleisure | the compression knit's matte stretch marks, sweat at the collarbone, dust on the mat |
| 👗 Evening | silk's slubs, one sequin catching while the rest stay dark, floor dust at the hem |
| ✨ Festive | thread standing proud of the cloth, zari reading as metal, the print a hair off-register |
| 🧣 Saree | zari as metal, the pleat edges soft with wear, the mulmul's translucence in the light |
| 🧕 Modest | the weight in the folds, the finished edge, the way the cloth falls on its own |
| 👔 Tailoring | the wool's nap, the press of the crease, a slight sheen where the jacket sits |
| 🩱 Swimwear | salt drying on skin, water beading on the suit, the grain of the swim knit |
| 🧿 Bohemian | dye bleeding at the selvedge, the print a hair off-register, the fringe's uneven ends |
| 🌙 Nightwear | the nap of brushed cotton, creases from the night, soft wear along the placket |
| 🖤 Lingerie | lace as thread with its own shadow, silk's sheen along a fold, brass worn at the rail's hook |
| 🎿 Ski | breath vapour in the cold, snow clinging to a seam, the zip's metal gone dull |
| 🛹 Streetwear | fleece pilling slightly at the cuff, grit at the sole edge, the paste-up's torn paper |

The law lives in four places besides the templates, so it rides in every generation: **`packs/fashion.md`** (the doctrine), **`shared/craft-detail-and-cast.md`** (inherited by all four system prompts), **`DETAIL_DENSITY`** in `src/lib/prompts.js` (pushed into both the H3 and the LTX message), and **both fallback system prompts**.


- **The lens is bolted down.** No travel, no zoom, no orbit, no hunting. Every change of frame size is *hers* — she walks, stops, turns or steps closer.
- **OPEN is always first.** Two to four grounded steps onto her mark at full length, the floor and her feet in frame, gaze off-lens then to it — never a distance travelled, and the fabric arrives a beat after each step.
- **CLOSE is always last.** She stops at mid-close, chest or chin level, eyes finding the lens, one small real smile — and the fabric going still is the final movement.
- **One act per beat, and the act is hers.** Real gesture, not a pose held without breath; hands, gaze and fabric each doing their own thing at once.
- **Feature beats are conditional.** *Each used only if the idea names that element, none invented.* A denim film does not borrow the saree's pallu.
- **The flow is a library, not a shot list.** A named flow re-orders the beats the idea earned and re-scales them; it never adds one.
- **Timing is derived.** One act per beat, the entrance taking the first two seconds, the close holding the last — seven to eight beats at twelve seconds, and a longer runtime gives the beats room rather than adding more.
- **The stack closes.** Every layer is named down to the footwear; anything sheer, plunged, open-backed or cropped says exactly what sits under it, and a lined, closed look names nothing under it.
- **The cast is 20–32** unless your idea names an age, stated once in the `{MODEL}` field.
- **The space has depth and dress.** (v2.37) The location is built in **three planes** — a **NEAR** plane just inside the frame (a doorway or counter edge, a rail, a curtain, a chair back, a plant, a crate), the **MIDDLE** where she stands and the beat happens, and a **FAR** plane that recedes with its own architecture, material and light (a window, a corridor, panelling, a courtyard, a lit opening, a shaft across the floor). The materials are named, two or three real objects give the place life, and one practical source lights it. The dress **never performs**: nothing moves on its own, nothing takes a beat, nothing blocks her mark or sits hard behind her head.

## Register-specific laws worth knowing

- **🧕 Modest** — the camera is fixed *and respectful*: no low angles, and no travel up or down the body. The drape beat arranges the styling (over the shoulder, pinned at the side, worn long) and never unwraps it.
- **✨ Festive ethnic** — no veil, no mandap, no ceremony, no religious object; a festival film, not a bridal one.
- **👗 Evening** — the gown travels, the camera does not; the drag and the slow half turn are the film's largest movements.
- **👔 Tailoring** — fabric must not fly; the movement is posture, weight and quarter turns, with daylight from two falls across a real working interior.
- **👟 Athleisure** — the film is the fabric under load: the compression holding in a lunge, the waistband staying put in a reach, the sole gripping a step.
- **🧣 Saree** — the pleat fan swings as one piece, the hem trails a beat behind her; the border is read at half length with her body still in frame (never a bare-detail macro).
- **🧿 Bohemian** — the cloth carries the movement: the skirt as one piece, the fringe and the coins doing the talking, the shawl drawn and settled rather than spun.
- **🌙 Nightwear** — the register is a person in her own room in the first light: soft steps, a knot at the waist, cloth that keeps moving for a beat after she stops. The mug enters only if the idea puts one in the room.
- **🎿 Ski** — the kit is technical and the cold is visible: the long zip drawn and closed, the hood changing the light on her face, the cuff over the glove, the breath reading in the air.
- **🛹 Streetwear** — the camera is bolted to the kerb and the city moves behind her; the film is proportions and hardware, and the sneaker is read against the pavement.

### The two restraint guards

**🖤 Lingerie** is written as a house **dressing-room film, not a boudoir scene**: a folding screen, a rail, a cheval mirror at the edge of frame and one tall window of diffused light. The block states, in capitals, that **she is dressed throughout** — the robe is worn and stays available, nothing is removed, unfastened or adjusted under the cloth, **no beat is a reveal** — and the camera is **respectful and fixed**: chest height, no low angle, no travel up or down the body, coverage chest-up or head-to-knee. There is no bed in it.

**🩱 Swimwear** is written the same way: she stays dressed as the idea draws her, the **cover-up is arranged rather than removed** and comes back on before the film ends, the camera stays at **chest height or above**, and the register inside the frame is sun, water and fabric — the light off the surface, the fabric darkening where the water touched it and drying in place.

## The pools behind the tours

`fashion-variation.md` carries a pool for every tour's own dimension, so nothing is a dead token:

| Pool | Register | Options |
| --- | --- | --- |
| **SPACE AND DRESS** | all fifteen tours | 8 — the three planes, materials and objects for the room itself |
| **DENIM AND WASH** | 👖 Denim | 6 — raw indigo, mid-blue vintage, faded light wash, ecru canvas, washed black, heavy selvedge |
| **WEAVE AND TEXTILE** | 🧣 Saree | 6 — Banarasi, Kanjeevaram, chikankari on mulmul, bandhani on georgette, patola, handloom linen |
| **SWIM AND COVER** | 🩱 Swimwear | 6 — maillot, two-piece with a wrap, swim short set, side-tie wrap suit, one-shoulder rib, terry robe |
| **PRINT AND TEXTURE** | 🧿 Bohemian | 6 — block print, paisley, mirror work and kantha, crochet, patchwork, ikat |
| **FABRIC AND FINISH** | 🌙 Nightwear | 6 — washed silk, brushed cotton, fine jersey, piped satin, waffle, washed linen |
| **SILK AND LACE** | 🖤 Lingerie | 6 — ivory charmeuse, black satin with French lace, poplin with openwork, mesh under silk, champagne with a self tie, deep plum with lace |
| **WINTER KIT** | 🎿 Ski | 6 — quilted shell, merino zip-neck, padded gilet, ribbed hat and gloves, goggles up on the hat, gaiter over the boot |
| **STREET LAYERS** | 🛹 Streetwear | 6 — oversized hoodie, boxy overshirt, matte bomber, cargo trouser, puffer gilet, crossbody and cap |

## How to use them

Ask for the tour by name in your idea ("a saree tour", "a streetwear tour on a corner"), and add a flow name if you want the order fixed ("BORDER RUN", "SNEAKER AND CUFF"). Leave both out and the engine derives the beats and the cut times as it does for every tour.

## Measured

**15 blocks** · **119 distinct beat names** · **46 flow names** (only CLOSE FIRST is shared) · **each tour owns 7–10 beats of its own** · **28 vary dimensions** (MOOD and AESTHETIC AND GRADE among them) · every block states the 20–32 band, the three-plane space law, the closed stack, the realism law and its material proof · 0 lint warns · 0 audit errors · the heaviest block is 1,293 words, inside the 1,320 ceiling that two mandatory laws set.

The six shipped tours in `tour-grammar.md` carry the same space law, with their culture guards intact. Suite **§23** pins the wear-type coverage, **§24** the space law across all twenty-one tours, **§25** the six newest registers and their restraint guards, and **§26** the fifteen vocabularies, the five required fields and the realism law.


## How to use them

Ask for the tour by name in your idea ("a saree tour", "a streetwear tour on a corner"), and add a flow name if you want the order fixed ("BORDER RUN", "SNEAKER AND CUFF"). Leave both out and the engine derives the beats and the cut times as it does for every tour.

## Measured

**15 blocks** · 105,204 B (104,028 characters) · **60 flows** (44 distinct names) · **133 feature beats** · **28 distinct vary dimensions** · every block states the 20–32 band, the three-plane space law and the closed stack · 0 lint warns · 0 audit errors · no stamped cut times anywhere in the file. The heaviest block is 1,165 words, inside the 1,275 weight ceiling.

The six shipped tours in `tour-grammar.md` carry the same space law, with their culture guards intact. Suite **§23** pins the first nine, **§24** the space law across all twenty-one tours, and **§25** these six registers — including the two restraint guards.

---

## v2.42 · The Indian construction vocabulary

Four studied references — an ivory sequin saree with sleeves swept back into a cuff (green studio ground), an ivory halter shell with a pearl-and-crystal bodice over a pre-draped skirt (gilt salon), a black-and-gold lehenga-sari with a sheer worked jacket (plaster studio, brass pots), and a turmeric-yellow ruffled tiered saree with a fully worked blouse (timber deck at golden hour) — are all **construction-led**. The look is decided by *how the six yards are built*, *which blouse archetype sits over them* and *how the edge is finished*, none of which the packs could name before this pass: `knot/bow-front blouse` appeared in **0 files**, `pre-stitched / concept saree` in 4, `ruching / pleated apron` in 1.

**Seven new pools** (`public/prompts/fashion-variation.md`, 8 options each, 56 named constructions):

| Pool | What it names |
| --- | --- |
| SAREE CONSTRUCTION | pre-stitched concept · lehenga-sari with a knotted apron · ruffled tiered · mermaid with a train · pant saree · belt-caught · knotted-front bodice · half-saree |
| BLOUSE ARCHETYPE | halter shell · bandeau with a worked waistband · knot-front · corset · high-neck lace yoke · cape sleeve · long sleeve worked edge to edge · jacket-blouse |
| LEHENGA CONSTRUCTION | kalidar · mermaid with a train · tiered · cape · jacket · pre-draped dupatta · fishtail · belt and overskirt |
| ANARKALI CONSTRUCTION | floor-length panels · jacket · cape sleeve · gown · layered net · angrakha · chikankari · bodice-fitted with a waistband |
| GHARARA AND SHARARA | gharara knee break · sharara · patiala · dhoti pant · gharara with a flat dupatta · sharara under a jacket kurta · palazzo with a side slit · churidar under an anarkali |
| ETHNIC SET FORMAT | co-ord · cape set · jacket set · palazzo set · kurta-and-pant · skirt-and-top · sharara set · saree-gown |
| EDGE AND HEM | scalloped · ruffled flounce · pearl-drop row · broad gota · fringe · cutwork · mirror-work · double border |

**Wired where the references live.** The **🧣 Saree tour** carries SAREE CONSTRUCTION, BLOUSE ARCHETYPE and EDGE AND HEM as live dimensions and gains **THE APRON KNOT** (she presses the knot or the pleated apron once, so the way the drape is held reads against the fan below it); its border beat now reads the worked edge too. The **✨ Festive ethnic tour** carries ETHNIC SET FORMAT, LEHENGA CONSTRUCTION, ANARKALI CONSTRUCTION, GHARARA AND SHARARA, BLOUSE ARCHETYPE and EDGE AND HEM, and gains **THE FLARE** (one turn on the spot, so the kalidar panels, the gharara's knee break or the sharara's two legs settle as one silhouette); its hem-lift beat reads the flare and the worked edge.

**Measured:** 15 tours · **121 distinct beat names** (only THE FACE shared) · 10 beats in each ethnic tour (band 8–10) · 0 lint warnings · 0 audit errors · heaviest block 1,126 words (ceiling 1,320) · both tours still pass the 21-check H3 contract and the 19-check LTX contract at generation. Suite **§28** (9 pins) holds the pools, the wiring, the two new beats and the beat-name ownership.
