# Artistic Set Builder for ComfyUI (v3)

Data-driven node pack for generating large, consistent artistic photography sets (100–2000+ images) from JSON content files.

**v2 added:** real dropdowns (no more copy/paste), a seeded randomizer, a manifest logger, jump-to-state clothing control, a data-driven level engine, negative prompts + style presets, camera metadata, and a full data validator.

**v3 added:** the **plan engine** — declare a whole set in one node (model × location × clothing × mode × seed × levels), get a frozen deterministic plan of every image (prompt, negative, per-image seed, filename, metadata), then render the entire set from a single queue with Batch Count — each image seeded and reproducible.

**v4 added — the shoot-direction system:** a browser plan studio (`web/planner.html`), **ASB Shoot Plan** (validates + expands shot lists, transitions from the clothing DB, storyboard call sheet), **auto-run batch** on Batch Index, and **ASB Prompt Designer** (YAML prompt structure templates).

**v5 added — pro-grade plan authoring:**
- **ID-based plans** — plans reference `zone_id` / piece id / `item_id → state` (not prompt phrases). Prompt phrases live only in the data files; the engine resolves them at generation. Names still work as a fallback everywhere. Expanded entries carry both the machine ids (`outfit` by item_id) and human mirrors (`outfit_names`).
- **Embedded Plan Designer inside the node** — the `ASB_ShootPlan` node has a built-in DOM-widget editor on the canvas (no browser tab needed): shot-list cards with zone/pose/outfit/transition dropdowns, live level badges, camera picker, a **status bar** (shots count + model/location/clothing/style/quality/seed + level histogram), **"Auto N shots"** using the node's `auto_shots` input (builds shots from the selected location + outfit DB — zones cycle, a garment advances each shot, poses chosen for the resulting level), and **Apply / Load-from-plan** that round-trips the id-based YAML.
- **Camera database split (v5.2)** — **real camera bodies** (`data/cameras.json`: Canon EOS R5, Nikon Z9, Sony Alpha 7R V, Fujifilm GFX 100S, Leica M11, Hasselblad X2D… with brand/model/lens/tech) are **top-level and common to every shot**; **framing is per-shot** (`data/framing.json`: close-up, medium, full body, low/high angle, overhead, POV, over-the-shoulder, profile, rear, silhouette, intimate, wide scene — each with `default_for_piece_types`). The engine resolves both ids → prompt text, auto-picks framing from the piece type when a shot doesn't specify one, and free text still passes through. No more ad-hoc camera strings in location data.
- **Single-shot serve in the main node** — `ASB_ShootPlan` now also outputs `index / shot_prompt / shot_negative / shot_seed / shot_filename_hint / shot_done`: with `use_internal_counter` ON it serves the next shot every execution (replacing the ASB_BatchIndex + ASB Plan→Prompt pair), or wire an external `index`.

## Features

| Feature | v1 | v2 |
|---|---|---|
| Nested dropdowns (zone / piece / item) | copy/paste text | **real combos** (JS extension) |
| Clothing control | advance one step | advance + **jump to any state** |
| Level system | hardcoded | **data-driven** per clothing set |
| Batch generation | manual | **seeded randomizer** + **offline set generator** |
| Run logging | — | **manifest node** (CSV/JSON export) |
| Negative prompts / styles | — | **style presets + auto-negatives** |
| Camera metadata | — | per-piece `camera` field |
| Data validation | — | **validate node + CLI** |
| Model prompt detail | fixed | **standard / detailed / minimal** |

## Documentation

- **`docs/DEVELOPER_GUIDE.md`** — the full, non-coder extension guide: add models / locations / clothing / cameras / framing / templates / plans step-by-step, the plan format + transitions, helper scripts, troubleshooting, and how to add a brand-new node. Every example in it is verified against the engine.
- `docs/AI_PLAN_SYSTEM_PROMPT.md` — the AI 200-shot plan system prompt.

## Installation

1. Copy `comfyui-artistic-set-builder` into `ComfyUI/custom_nodes/`
2. Restart ComfyUI
3. Find nodes under **ArtisticSetBuilder**

The `web/` folder ships the frontend extension that turns every nested choice
into a **real dropdown** populated from the connected node:

| Field | Populated from |
|---|---|
| `ASB Select Zone → zone_name` | connected location's zones |
| `ASB Select Prompt Piece → piece_name` | connected zone's prompt pieces |
| `ASB Advance Clothing → item_name` | connected clothing's items (with current state) |
| `ASB Set Item State → target` | connected clothing's every item × state |
| `ASB Randomize Set → zone_name` | connected location's zones |
| `ASB Select Prompt Piece → level` | static combo `level_0`–`level_4` (node definition) |

The dropdowns fill in from the **executed output** of the upstream node, so run
the graph once (or just the upstream loader) and they populate. The widgets
render as dropdowns immediately (even before the first run) — they just gain
their options after the upstream node executes.

> **Important — if dropdowns still don't appear:** the earlier releases shipped
> the JS in `web/js/` with the wrong `../../scripts/app.js` import (it resolved
> to `/extensions/scripts/app.js` → 404), so the extension never loaded in the
> browser. v3.1 ships it at `web/artistic_set_builder.js` with the correct
> import. After installing the new zip, **hard-refresh the browser**
> (Ctrl/Cmd+Shift+R) and check the console (F12):
> - `[ArtisticSetBuilder] dropdown extension loaded (v3.1)` → extension is live
> - `[ASB] dropdown ready: ...` → a node's field was converted to a dropdown
> - any red error → tell me the message and I'll fix it

## The editor ALWAYS sees your real `data/` folder (no stale snapshot)

The in-node editor and the standalone planner page used to read a copied
`web/planner_data.json` snapshot — which went stale whenever you added files to
`data/` without re-running the export. **Fixed:** the editor now loads data
**live from the server** through a new `POST /asb/data` endpoint that reads
`data/` (pack + external folders) at request time. Add a location/model/set
file, hit **↻ Refresh data**, and it appears instantly — no export script, no
restart. (The shipped snapshot remains only as a fallback if the route is
unreachable, e.g. opening the page outside ComfyUI.)

## Where your data lives — and how to use your BIG database

The pack reads from its own `data/` folder **plus any external folders you
configure**. If you have many locations/models/clothing sets elsewhere, point
the pack at them (three ways — any combination works):

1. **Edit `data/config.json`** → `extra_data_dirs: ["C:/Your/Database", "/home/you/asb_data"]` — each entry is a **root folder** containing `models/`, `locations/`, `clothing/`, `cameras/`, `framing/` subfolders (same layout as `data/`).
2. **Environment variable** `ASB_DATA_DIRS=/your/folder:/another` (path-separated, same layout).
3. **Just add files into this pack's `data/` subfolders** — they appear automatically.

Everything aggregates: pack data + all extra folders are merged (pack wins on name conflicts). **Diagnose anytime with:**
```
python scripts/data_report.py     # counts + where each item comes from
python scripts/validate.py        # validates pack + extras
```
Then `python scripts/export_planner_data.py` + restart ComfyUI (or use the editor's **↻ Refresh data** button). Verified: pointing at a folder with 3 more locations / 2 models / 1 set makes the dropdowns show 11 / 20 / 10 — everything is listed, nothing hardcoded.

## Included Data

| Type | Count | Examples |
|------|-------|----------|
| Models | 18 | Liora, Sienna, Nova, Mira, Elena, Ayla, Freya, Jade, Clara, Zara, Iris, Nina, Amara, Lucia, Harper, Quinn, Sofia, Yuna |
| Locations | 8 | **Cozy Modern Living** (5 zones × 36 poses = 180 prompts — the rich sample), Cozy Living, Bright Bedroom, Modern Studio, Luxury Hotel, Garden Terrace, Penthouse Lounge, Spa Bathroom |
| Cameras | 8+ | `data/cameras.json` **or** `data/cameras/*.json` (one camera per file — Canon, Nikon, Sony, Fujifilm, Leica, Hasselblad…) |
| Framing | 13+ | `data/framing.json` **or** `data/framing/*.json` (one framing per file — close-up, medium, full body, low/high angle, overhead, POV, rear, intimate…) |
| Clothing Sets | 9 | Elegant Dress, Casual Crop, Sleep, Sheer Lingerie, Office Blouse, Bikini, Evening Gown, Cozy Sweater, Towel & Spa |

**Adding your own cameras / framings:** drop JSON files into `data/cameras/` or `data/framing/` (one preset per file, like models/locations/clothing). A file may be a single object (`{"id": ..., "brand": ..., "model": ..., "tech": ...}`), a list, or `{"cameras": [...]}` / `{"framing": [...]}`. The flat `cameras.json`/`framing.json` still work and are merged (flat wins on id conflicts). Restart ComfyUI to refresh the dropdowns.

When you add a shot (＋ Shot) it now **pre-fills every field**: zone (cycles through the location's zones), pose (first piece compatible with the shot's outfit level), framing (auto-picked from the framing DB for that pose), plus mode/transition/note defaults — so a new shot is always runnable, never half-blank.

**With the 5-zone / 180-pose location** (e.g. `cozy_modern_living`), Auto N now produces a genuinely varied set: 300 shots → 155 distinct zone|pose combos across all 5 zones, 7 framings, paced undress levels, zero incompatible poses (verified). More zones × more compatible poses per level = more variety.

**Undressing core restored + re-wear cycles (v10):** a regression in v8/v9 spread the undressing so thin (one advance every Nth shot) that 85% of shots were holds with identical outfits — undressing was effectively invisible. **Fixed:** the default `undress narrative` now **advances one item EVERY shot** (cycling items in order), so the outfit visibly progresses shot-by-shot until all off — the original "all → none in sequence" you asked for. For long sets, after reaching all-off it runs occasional **re-wear cycles** (`set: item -> state` back on, then re-undress) so the outfit keeps evolving across the whole set — "reuse zones with different outfit stats" literally. Verified: a 200-shot set has **51 outfit changes** (15 continuous undress + re-wear variety), 0 errors, monotonic first pass.

**Undress logic fixed to respect `max_level` on the ACTUAL outfit (v9):** previously `max_level` only clamped the *displayed* level while the machine kept undressing to level_4 behind the scenes — so shots showed "level_2" but the outfit was actually fully off (the display lied and the engine disagreed). Now the wardrobe machine **never advances an item past what would exceed `max_level`**, so display and engine always agree. Short shot counts (e.g. 10 shots when 15 item-steps are needed) end gracefully at the last reachable level with a clear warning to use more shots.

**Auto-generated notes are now real director's notes (v8.1):** auto shots used to write progress counters into the `note` field ("hold (59/100)") which, when a template like `boudoir_sequence` injects `{note}` into the prompt, showed up as garbage in the final text. Auto N now writes evocative notes from a 16-line pool ("looking away, gentle profile", "fingertip tracing collarbone", …) plus meaningful ones ("Elegant Mini Dress slipping", "artistic nude, window zone"). No counters, ever. Verified: 60 shots → zero `N/M` or `hold (` leaks in any prompt, even with `{note}` templates.

**Auto N shots (v8) — linear all→none, no shot limit:** the **hard shot-count cap is removed** — set `auto_shots` to 100, 500, 1000+ and it generates exactly that many (node input max 1,000,000). The sequence is **strictly linear**: shot 0 fully dressed → the outfit advances one item-state at a time, spread evenly across the whole set → the final shots are all-off. Location zones are **reused** (they cycle) but every revisit has a progressed outfit state — a 500-shot set in `cozy_modern_living` uses each of its 5 zones ~100 times, never repeating the same (zone, pose, outfit) triple. Verified: 500 shots → **500/500 expand, 0 errors, 1 location + 1 set, levels climb 0→4 monotonically**, first shot all-on, last all-off. `gallery_mode` (`undress narrative` default = linear all→none; `MetArt gallery` = dress/undress arc then mostly artistic nude) still lets you choose the feel.

**Auto N shots (v6/v7) — MetArt-style galleries, ONE location + ONE outfit per set (never mixed):** each photo set stays **fully consistent** — a single location and a single clothing set, chosen by you in the node. The generator fully utilizes the data you selected:
- **all zones** of the selected location are cycled (e.g. 5 zones of `cozy_modern_living`),
- **all poses** per zone are rotated (compatible with each shot's level) — a 100-shot gallery produces **100 distinct zone|pose combos**,
- **every item** of the selected clothing set is used in the undress arc (dress → bra → briefs → heels …),
- **`gallery_mode`** (`MetArt gallery` = mostly artistic nude with a dress/undress arc; `undress narrative` = slower paced undress),
- **no per-shot location/clothing_set overrides exist** — a plan is always one location + one set (the engine ignores any stray override keys, keeping the set consistent).

Verified: 100-shot MetArt gallery in `cozy_modern_living` × `elegant_dress_set` → **100/100 expand, 0 errors, exactly 1 location + 1 set**, levels `0:3, 1:4, 2:6, 3:2, 4:85`.

To use your OTHER locations/sets, simply change the **Location** / **Clothing Set** dropdowns and generate again (each generates its own consistent set). The offline `generate_manifest.py` already produces one set per combo for whole-database coverage.

**Switching the location / clothing set no longer blanks the plan (v5.9):** if you change the Location or Clothing Set dropdown in the editor, existing shots are **intelligently re-mapped** — shots move to the new location's zones (rotating) with compatible poses, and stale per-item outfit maps from the old clothing set are cleared — so the plan stays loadable instead of coming back empty. A **🧹 Clear** button in the toolbar empties both the shot list and the node's plan field.

**Auto N shots (v5.8)** now builds a proper, **paced undress sequence**: the wardrobe advances one step every few shots so the level climbs gradually and reaches the ceiling at ~80% of the set (e.g. a 200-shot set reaches level_4 around shot 160–180, then lingers all-off with variety) — not all-off by shot 12. It **respects the node's `min_level`/`max_level`** (set max_level=2 and it never exceeds level_2), picks poses by **round-robin per zone** (no more repeating the same pose every turn; 18 distinct zone|pose combos vs 7 before), auto-chooses framing per pose, and the **count comes straight from the node's `auto_shots` input** (the button label shows the live value; type 200 → 200 shots, up to 10000).

## Nodes

| Node | What it does |
|------|--------------|
| **ASB Load Model** | dropdown + `detail_level` (standard/detailed/minimal) + `identity_token` output |
| **ASB Load Location** | dropdown → location object, lighting, `available_zones` |
| **ASB Select Zone** | dropdown (from location) → zone object, `available_pieces` |
| **ASB Load Clothing** | dropdown → clothing object, `available_items`, `item_states` |
| **ASB Advance Clothing** | move ONE item one step (dropdown) |
| **ASB Set Item State** | *(new)* jump any item straight to any state (dropdown) |
| **ASB Get Clothing Status** | phrases, `level`, `level_name`, `removed_count` |
| **ASB Randomize Set** | *(new)* seeded random zone + piece + clothing combo at a target level range |
| **ASB Select Prompt Piece** | dropdown (from zone) → piece prompt + `camera_technical` |
| **ASB Build Final Prompt** | assembles prompt + **negative prompt**; style presets; auto-negatives by level |
| **ASB Manifest** | *(new)* accumulates each run → CSV/JSON text, resettable |
| **ASB Validate Data** | *(new)* validates all data files, reports issues |

### v4 — shoot direction (the full-production path)

| Node / Tool | What it does |
|------|--------------|
| **Shoot Designer (in-node, v5.4)** | embedded editor widget on the canvas: toolbar (＋ Shot / Auto N / Sample / Load-from-plan / **Save file** / **Load file** / Apply) **above** the shot list; status bar (shots count + model/location/clothing + real camera + style/quality/seed + level histogram + action feedback); **top-level camera select (real bodies)** + **per-shot framing/angle dropdown**; **node height is capped** (max ~1040px) and the shot list shows up to 10 cards then scrolls — it can never grow endlessly. Starts **empty**; **Auto N shots** builds a proper undress narrative: shot 0 all-on, then one garment advances a step per shot (cycling the wardrobe DB) until everything is off, with poses chosen for each shot's level. **Apply-to-node never calls ComfyUI's widget callback directly** (that caused a "Cannot destructure property 'e'" crash) — it writes the plan value + input element and marks the graph dirty; the plan_json output refreshes when you **run** the node. **Plan storage — three ways:**
1. **💾 Save file / 📂 Load file** — browser download + file picker (`.yaml/.yml/.json/.txt`), keep the plan anywhere.
2. **☁️ Server panel** (new) — **Save to server / Load from server / 🗑 delete**, stored under **`ComfyUI/user/asb_plans/`** via the pack's `/asb/plans` HTTP API (GET list, POST save, GET/DELETE per plan). Plans persist across browser sessions and machines, and are easy to back up with the rest of your ComfyUI user folder.
3. **⟳ Load from plan** — read the node's current plan text back into the editor.

(Standalone page `web/planner.html` at `/extensions/comfyui-artistic-set-builder/planner.html` — Download / Import / 📂 Load file / ☁️ Save & Load from server there too.) |
| **ASB Shoot Plan** | parses the plan (JSON or YAML), validates every zone/piece/item/state against the data files, expands transitions from the clothing database, computes each shot's level + prompt, outputs `plan_json`, `count`, **`storyboard`** (call sheet), `shots_csv`, `report` |
| **ASB Prompt Designer** | YAML template engine — defines prompt output structure (sections, order, joiner) with `{placeholders}`; 8 presets in `data/templates/*.yaml`; custom YAML override input |
| **ASB Batch Index (auto-run)** | `auto_run` ON → frontend extension auto-queues each next run until `done` (press Run once, Batch Count = 1) |

**Transitions driven by the clothing database** (per shot, applied to the previous shot's outfit — `<Item>` is an item_id like `dress_01`, names also work):

| Directive | Effect |
|---|---|
| `advance: <Item>` (or `undress:`/`next:`) | move item one state forward (fully_worn → slipped_off_shoulders → …) |
| `remove: <Item>` | jump item to its last state |
| `dress: <Item>` | move item one state backward |
| `set: <Item> -> <state>` | jump to an exact state |
| `sequence: <Item>` | auto-cycle the item one step per shot |
| `reset` | all items fully worn |
| `outfit: fully_worn / removed` | all items on / all off |
| `outfit: {item_id: state, …}` | explicit per-item map |

Example plans ship in `data/plans/` (elegant undress story, spa ritual, evening gown story) — all authored by id. A full wired example: `examples/shoot_direction_workflow.json`.

### v3 — plan-based set generation (the fast path)

| Node | What it does |
|------|--------------|
| **ASB Set Plan** | one declarative node: model + location + clothing + mode + seed + levels + count → a **frozen, deterministic plan** of every image (prompt, negative, per-image seed, filename, tags, metadata) as JSON + CSV |
| **ASB Plan → Prompt** | pulls one entry from a plan by index → `final_prompt`, `negative_prompt`, `seed`, `filename_hint`, `meta_json` |
| **ASB Batch Index** | session counter 0..total-1; drives one plan entry per queued run |

## Why outputs "don't show" — and the right way to see them

**How ComfyUI works (researched):** node outputs (`plan_json`, `storyboard`, `count`) are computed **only when the graph executes** — the frontend receives them via the `executed` event; a Show Text node displays the string its input carried during that execution. There is **no supported way to refresh outputs without running**. And calling `app.queuePrompt()` queues the **entire graph** — sampler included — so a node should never auto-queue (we removed the Apply & Run button for exactly that reason; **Apply never queues anything**).

**See your plan expanded WITHOUT running anything:**
- **▸ Output preview** panel inside the node: after **✓ Apply to node** it auto-opens and shows the expanded storyboard computed by the **real Python engine** through a dedicated server route (`POST /asb/expand` — no queue, no sampler, no image). It also stashes the authoritative `plan_json`; **📋 Copy plan_json** puts it on your clipboard.

**v5.6 bugfix — plan text round-trip (zones were dropped):** the YAML parser that reads a saved plan back into the editor (`- zone: Z_Window`) treated the shot's opening line only as "start a shot" and never read the `zone:` value on it — so every shot silently lost its zone after loading a plan, and a blank `zone:` made the whole plan come back empty (`plan_json=[]`, `count=0`). Fixed in `planner_widget.js` *and* `planner.html`. Already-corrupted saved plans are **auto-healed on load** (blank zones point to the first zone of the selected location, with a clear ⚠ warning to verify each shot).
- Wire `storyboard` / `plan_json` to a **Show Text** node (the shipped `examples/shoot_direction_workflow.json` already has it wired) and it fills in when you **Run** the graph (ComfyUI's Queue button) — that's the normal ComfyUI flow, not a bug.

**Diagnosing:** the node logs to the ComfyUI server console: `[ASB] ShootPlan: plan=NN chars -> N shots | report=…`. If `plan=0` after a run:
- **`EMPTY PLAN` report** → the plan box was empty when you ran (the #1 cause). Build shots in the editor → **✓ Apply to node** → run; or paste / ⟳ Load / 📂 / ☁️ first.
- **`plan=0` with ERROR notes in report** → those shots are skipped and the rest still load (per-shot isolation — one bad line no longer blanks the whole job). Check the notes, fix the listed shots, re-run.
- Otherwise the outputs will appear in Show Text after the run.

**v5.7 — the real "empty plan" fixes:**
1. **Serialization bug:** Apply wrote `widget.value` + the textarea, but litegraph serializes widgets as `serialize_value ?? value` when building the queue payload — if `serialize_value` was stale/empty, the **server received an empty plan** even though the UI showed it. Apply now sets `serialize_value` too, and the read-back checks it first.
2. **One bad line blanked everything:** `expand_plan()` raised on the first bad shot and the whole plan came back `[]`. It's now per-shot tolerant — bad shots are skipped with `ERROR shot N:` notes in `report`, everything else loads. Empty plans produce clear guidance instead of silence.

## No hardcoded data — the pack adapts to YOUR folders

Nothing in the code assumes a specific model / location / clothing / camera exists:
- All dropdowns, defaults and samples are built **dynamically from whatever is in
  `data/`** (models/, locations/, clothing/, cameras/, framing/ — flat files and
  folders both).
- The **Sample** button in the editor builds a sample plan from the *first
  available* model/location/clothing/camera in your data (never a fixed id).
- `scripts/export_planner_data.py` also writes `examples/sample_plan_from_data.yaml`
  from your data, and the status bar shows live availability (zones · poses · sets · cams).
- If you load a plan that references ids you don't have, the editor warns
  ("⚠ not in current data: …") and the engine reports per-shot errors instead of
  failing silently.
- Script defaults (`make_plan_prompt.py`, `generate_manifest.py`) use the first
  available entries, so `python scripts/make_plan_prompt.py --count 200` just works.

## Generate a 200-shot plan with an AI (system prompt)

The pack ships a **system prompt** that turns a tiny JSON config into a full,
consistent, node-loadable shoot plan of up to 200+ prompts:

```
python scripts/make_plan_prompt.py --model liora --location cozy_living \
    --clothing elegant_dress_set --count 200 --out ai_prompt.txt
```

The generated prompt gives the AI:
- the **JSON input** to obey (model / location / outfit / style / quality / camera / count / levels / seed / title),
- a **data reference of the real ids** (zones, pieces with compatible levels, items with states, cameras, framing) filtered to your selection — so it never invents ids that would break loading,
- the **exact YAML output schema** the `ASB_ShootPlan` node accepts,
- **hard rules**: raw YAML only (no fences/commentary), exactly N shots, one model/camera/style/quality/seed throughout, an undress narrative (advance one item per shot → all off → linger with variety), piece↔level compatibility, min/max level range.

**The workflow:**
1. `make_plan_prompt.py` → paste the prompt + JSON into any LLM → it returns a YAML plan.
2. **Verify before loading:** `python scripts/verify_plan.py plan.yaml` → "LOADABLE ✓ N shots" or the exact error.
3. **Load into the node:** paste into the plan box → **⟳ Load from plan**, or **📂 Load file** / **☁️ Server**, then **✓ Apply to node** and run.

A ready-made, verified demo is in `examples/ai_generated_200_shots.yaml` (200 shots, level_0 → all-off narrative, consistent camera/seed). The full reference prompt is in `docs/AI_PLAN_SYSTEM_PROMPT.md`.

**Consistency is guaranteed by the engine:** every shot reuses the same model prompt, location lighting, camera body, style and quality; each image gets a deterministic distinct seed; prompts are built from the same data files. The AI only supplies the shot list — it can't drift the identity.

## How many images?

Real math, not marketing: with **1 model × 1 location × 1 clothing set** in
level mode, you get one image per (zone piece × compatible level) — e.g. the
Cozy Living location (18 pieces) × Elegant Dress set = **57 prompts**. Mix in
the other 6 locations or more models and the count compounds quickly:

- 1 model × 7 locations × 1 set ≈ **~400 images**
- 2 models × 7 locations × 2 sets ≈ **~1,600 images**

Run `scripts/generate_manifest.py` to see exact numbers for any combo.

## Generate a whole set in one queue (v3)

1. Add **ASB Set Plan**, pick model / location / clothing set / mode / seed /
   level range, run it once. The `count` output tells you the set size
   (e.g. Liora × Cozy Living × Elegant Dress, level mode = **57**).
2. Wire **ASB Plan → Prompt** to the plan. Connect **ASB Batch Index**'s
   `total` to the plan's `count` and its `index` to the plan prompt's `index`.
3. Wire `final_prompt` → CLIPTextEncode (positive), `negative_prompt` →
   CLIPTextEncode (negative), and `seed` → KSampler seed (each image gets a
   stable, distinct seed derived from the plan's base seed).
4. Set ComfyUI's **Batch Count** = plan count and hit Queue. ASB Batch Index
   walks 0..count-1 — every queued run renders the next image of the set.

**Why it stays consistent:** the plan is built once and frozen — the model
prompt, style, quality and negatives are baked into every entry, so switching
a widget mid-run can't silently change the set. Each image has a deterministic
seed (`base_seed + index × 7919`). Regenerate the plan deliberately when you
want a different set; the same seed + settings always rebuild the identical
plan.

Two example workflows ship in `examples/`:
`example_workflow.json` (classic manual chain) and
`batch_set_workflow.json` (v3 plan → batch queue).

## Two ways to generate a set

### A. In ComfyUI (interactive)
Wire the chain, use `ASB_RandomizeSet` for seeded random picks, `ASB_SetItemState`
to jump clothing states, and `ASB_Manifest` to log every prompt you queue.
Re-running with the same seed reproduces the same combination.

### B. Offline (bulk, no ComfyUI needed)
```bash
python scripts/generate_manifest.py --model liora --location cozy_living \
    --clothing elegant_dress_set --mode level --out out/liora_living

python scripts/generate_manifest.py --all --mode random --count 200 \
    --seed 7 --min-level 2 --max-level 4 --out out/random200
```
Writes `prompts.csv`, `manifest.json` and SD-style per-image `captions/*.txt`
(positive + negative). Modes: `level` (canonical combo per piece×level),
`exhaustive` (every item-state combination, use `--cap`), `random` (seeded sample).

Then run the set in any batch pipeline and feed each image its caption file.

## Data schema (v2 additions — all optional)

```jsonc
// data/models/liora.json
{
  "name": "Liora",
  "age": 26,
  "identity_token": "Liora",              // optional: separate from display name
  "body_type": "slender with soft curves",
  "hair":  { "length": "long", "style": "wavy", "color": "dark brown" },
  "face":  { "eyes": "expressive brown", "smile": "bright cheerful", "makeup": "natural" },
  "skin":  { "tone": "fair", "texture": "natural smooth" },
  "breasts": { "size": "modest", "shape": "natural rounded teardrop" },   // used by detail_level=detailed
  "overall_vibe": "cute, glamorous, playful and smiling"
}

// data/locations/cozy_living.json  (pieces may carry optional camera metadata)
{
  "photo_zones": [
    { "name": "Window Zone",
      "prompt_pieces": [
        { "id": "Win_01", "type": "standing_smile",
          "prompt": "standing near the window, ...",
          "camera": "85mm f/1.8, full frame, 1/125s, ISO 100",
          "compatible_clothing_levels": ["level_0","level_1","level_2","level_3","level_4"] }
      ]}
  ]
}

// data/clothing/elegant_dress_set.json  (optional level_config overrides the defaults)
{
  "level_config": {
    "removed_states": ["removed", "no panties", "no bra"],
    "thresholds":     [0, 1, 2, 3, 4],        // removed-count → level index
    "level_names":    ["fully dressed", "partially undressed", "undressed", "mostly nude", "fully nude"]
  },
  "items": [
    { "name": "Black Briefs",
      "states": [
        { "state_id": "fully_worn",   "prompt_phrase": "wearing black panties" },
        { "state_id": "removed",      "prompt_phrase": "no panties" }
      ]}
  ]
}
```

Defaults when `level_config` is absent: `removed_states = ["removed", "no panties",
"no bra", "barefoot", "no top", "no skirt", "no dress", "no shirt"]`,
`thresholds = [0, 1, 2, 3, 4]` (monotonic: removing more items never lowers the level).

## Validation

```bash
python scripts/validate.py          # human report, exit code 0 = all good
python scripts/validate.py --json   # machine-readable
```
Or run the **ASB Validate Data** node. Checks: JSON parses, required fields,
unique zone/piece/item ids, valid state ids, in-range level refs, and
`level_config` state names.

## Tests

```bash
python tests/test_v2.py   # 11 headless tests covering every node + scripts
```

## Roadmap ideas

- LoRA / checkpoint token per model (`identity_token` hook)
- Aspect-ratio & cropping hints per piece
- Multi-day "continue where you left off" via manifest snapshot restore
