# Artistic Set Builder — MetArt-Level Photosets

## Install
1. Copy folder → `ComfyUI/custom_nodes/comfyui-artistic-set-builder/`
2. `python scripts/export_planner_data.py`
3. Restart ComfyUI once

## Recommended settings
| Field | Value |
|-------|--------|
| mode | **transition** (stable blocks + one-item undress beats) |
| style | `metart natural` or `sensual soft` |
| quality | `metart` or `sensual editorial` |
| template | `metart_natural` |
| detail_level | `detailed` |
| location | Soft Window Bedroom (or any upgraded location) |

## What this build includes
- **32 locations** upgraded with body-language poses + intimate/action pieces (`min_level` gated)
- **Expression/gaze library** injected by undress level (any model)
- **Camera + framing** tech lines on every shot
- **Transition plan mode** — girlstop/MetArt rhythm without hardcoding outfits
- **19 models** with breast/nipple/pussy/pubic-hair/ass variety
- **Piercings / tattoos** toggles on ASB Load Model (off by default)
- **Web UI** mode help on ASB Set Plan

## Dynamic rules (never broken)
- Poses never name garments or “nude”
- Clothing comes only from the outfit DB state
- Model identity only from the model DB
- Intimate/action poses only when level ≥ min_level
- Removed garments omitted from the positive prompt

## Nodes to use
1. **ASB Load Model** — pick model; optional piercings/tattoos
2. **ASB Set Plan** — mode=`transition`, count=80–200
3. Feed `final_prompt` / `negative_prompt` / `seed` into your sampler batch

## After editing JSON
```bash
python scripts/export_planner_data.py
```
Then restart or hard-refresh the browser for web widgets.
