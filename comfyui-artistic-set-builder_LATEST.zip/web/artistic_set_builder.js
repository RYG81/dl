// Artistic Set Builder — dynamic dependent dropdowns (v3.1)
//
// IMPORTANT (root cause of the previous failures): this file lives at
//   web/artistic_set_builder.js
// and is served by ComfyUI at
//   /extensions/<pack_name>/artistic_set_builder.js
// so the standard `../../scripts/app.js` import resolves to /scripts/app.js.
// The earlier version was at web/js/artistic_set_builder.js where
// `../../scripts/app.js` resolved to /extensions/scripts/app.js (a 404),
// so the whole module failed to load and NOTHING became a dropdown.
//
// What this extension does:
//   * converts the copy/paste text inputs of the ASB selector nodes into real
//     combo widgets, populated from the connected upstream node's executed data
//   * works by OUTPUT NAME (not slot index) and also extracts lists directly
//     from the connected objects (location/zone/clothing dicts)
//   * before the graph has run, widgets still render as dropdowns (with their
//     current value as the only option) so the UI never looks broken

import { app } from "../../scripts/app.js";

const SPECS = {
  ASB_SelectZone: {
    input: "location",
    objectName: "location",
    listName: "available_zones",
    widget: "zone_name",
    extract: (loc) =>
      Array.isArray(loc && loc.photo_zones)
        ? loc.photo_zones.map((z) => z.name || z.zone_id).filter(Boolean)
        : null,
  },
  ASB_SelectPromptPiece: {
    input: "zone",
    objectName: "zone",
    listName: "available_pieces",
    widget: "piece_name",
    extract: (zone) =>
      Array.isArray(zone && zone.prompt_pieces)
        ? zone.prompt_pieces
            .map((p) => [p.id, p.type].filter(Boolean).join(" | "))
            .filter(Boolean)
        : null,
  },
  ASB_AdvanceClothing: {
    input: "clothing",
    objectName: "clothing",
    listName: "available_items",
    widget: "item_name",
    extract: (cl) => {
      if (!cl || !Array.isArray(cl.items)) return null;
      return cl.items
        .map((it) => {
          const name = it.name || it.item_id;
          if (!name) return null;
          const cur =
            it.current_state ||
            (it.states && it.states[0] && it.states[0].state_id) ||
            "fully_worn";
          return `${name} [${cur}]`;
        })
        .filter(Boolean);
    },
  },
  ASB_SetClothingState: {
    input: "clothing",
    objectName: "clothing",
    listName: "item_states",
    widget: "target",
    extract: (cl) => {
      if (!cl || !Array.isArray(cl.items)) return null;
      const out = [];
      for (const it of cl.items) {
        const name = it.name || it.item_id;
        if (!name) continue;
        for (const st of it.states || []) {
          if (st && st.state_id) out.push(`${name} [${st.state_id}]`);
        }
      }
      return out;
    },
  },
  ASB_RandomizeSet: {
    input: "location",
    objectName: "location",
    listName: "available_zones",
    widget: "zone_name",
    extract: (loc) =>
      Array.isArray(loc && loc.photo_zones)
        ? loc.photo_zones.map((z) => z.name || z.zone_id).filter(Boolean)
        : null,
  },
};

const REGISTRY = new Map();

function upstream(node, inputName) {
  const inp = (node.inputs || []).find((i) => i.name === inputName);
  if (!inp || inp.link == null) return null;
  const link = (app.graph.links || []).find((l) => l.id === inp.link);
  if (!link) return null;
  const src = app.graph.getNodeById(link.origin_id);
  return src ? { node: src, link, slot: link.origin_slot } : null;
}

function readOutput(node, slot, name, link) {
  if (link && link.data !== undefined) return link.data;
  const msg = node.__asbLast || {};
  if (name && msg[name] !== undefined) return msg[name];
  if (slot != null && msg[slot] !== undefined) return msg[slot];
  try {
    const v = node.getOutputData ? node.getOutputData(slot) : undefined;
    if (v !== undefined) return v;
  } catch (e) {
    /* ignore */
  }
  return undefined;
}

function parseList(str) {
  return typeof str === "string"
    ? str.split("|").map((s) => s.trim()).filter(Boolean)
    : [];
}

function getValues(entry) {
  const up = upstream(entry.node, entry.spec.input);
  if (!up) return [];
  const obj = readOutput(up.node, up.slot, entry.spec.objectName, up.link);
  if (obj !== undefined && obj !== null) {
    const vals = entry.spec.extract(obj);
    if (Array.isArray(vals) && vals.length) return vals;
  }
  const list = readOutput(up.node, up.slot, entry.spec.listName, up.link);
  const vals = parseList(list);
  if (vals.length) return vals;
  return [];
}

function makeCombo(widget) {
  if (!widget) return;
  if (widget.type !== "combo") {
    widget.type = "combo";
    widget.options = widget.options || {};
    widget.options.values = [widget.value];
  }
}

function applyValues(entry, values) {
  const w = entry.widget;
  if (!w) return;
  makeCombo(w);
  if (!values.length) return;

  const same =
    Array.isArray(w.options.values) &&
    w.options.values.length === values.length &&
    w.options.values.every((v, i) => v === values[i]);
  if (!same) w.options.values = values.slice();

  if (!values.includes(w.value)) {
    w.value = values[0];
    // NOTE: never call w.callback(w.value) with a bare value — ComfyUI's
    // widget-callback wrapper expects the full (value, canvas, node, pos,
    // event) signature and crashes with "Cannot destructure property 'e' of
    // 'undefined'". The value is set; the graph redraw below is enough.
  }
  if (w.computeSize) w.computeSize();
}

function refresh(entry) {
  applyValues(entry, getValues(entry));
}

let timer = null;
function refreshAll() {
  for (const entry of REGISTRY.values()) refresh(entry);
  if (app.graph) app.graph.setDirtyCanvas(true, true);
}
function debouncedRefreshAll() {
  if (timer) clearTimeout(timer);
  timer = setTimeout(refreshAll, 150);
}

app.registerExtension({
  name: "ArtisticSetBuilder.DynamicCombos",
  version: "3.1",

  beforeRegisterNodeDef(nodeType, nodeData) {
    // stash executed outputs on ANY node (loaders, selectors, randomizer...)
    const origOnExecuted = nodeType.prototype.onExecuted;
    if (!origOnExecuted || !origOnExecuted.__asbWrapped) {
      nodeType.prototype.onExecuted = function (message) {
        this.__asbLast = message || {};
        if (origOnExecuted) return origOnExecuted.apply(this, arguments);
      };
      nodeType.prototype.onExecuted.__asbWrapped = true;
    }

    const spec = SPECS[nodeData.name];
    if (!spec) return;

    const onNodeCreated = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      const r = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;

      const w = (this.widgets || []).find((x) => x.name === spec.widget);
      if (w) {
        makeCombo(w); // always render as a dropdown, even before data arrives
        REGISTRY.set(this.id, { node: this, widget: w, spec });
        refresh(REGISTRY.get(this.id));
        console.info(`[ASB] dropdown ready: ${nodeData.name} → ${spec.widget}`);
      }
      return r;
    };

    // keep the widget reference in sync after (de)serialization
    const onConfigure = nodeType.prototype.onConfigure;
    nodeType.prototype.onConfigure = function () {
      const r = onConfigure ? onConfigure.apply(this, arguments) : undefined;
      const entry = REGISTRY.get(this.id);
      if (entry) {
        const w = (this.widgets || []).find((x) => x.name === spec.widget);
        if (w && w !== entry.widget) entry.widget = w;
        refresh(entry);
      }
      return r;
    };
  },

  setup() {
    console.info("[ArtisticSetBuilder] dropdown extension loaded (v3.1)");

    if (app.api && app.api.addEventListener) {
      app.api.addEventListener("executed", (e) => {
        const id = e && e.detail && e.detail.node;
        const node = app.graph.getNodeById(id);
        if (node && e.detail.output) node.__asbLast = e.detail.output;
        debouncedRefreshAll();
        maybeAutoQueue(node, e.detail.output);
      });
    }

    const g = app.graph;
    if (g && !g.__asbHook) {
      g.__asbHook = true;
      const orig = g.onAfterChange;
      g.onAfterChange = function (...args) {
        if (orig) orig.apply(this, args);
        debouncedRefreshAll();
      };
    }
  },
});

// ---------------------------------------------------------------------------
// AUTO-RUN BATCH (v4)
//
// When an ASB_BatchIndex node has `auto_run` ON, each completed run queues the
// next one automatically, until the batch index reports `done`. So you press
// Run ONCE (with queue Batch Count = 1) and the whole shoot renders end to
// end. A pending-queue guard stops it from double-queueing if you queued a
// manual batch yourself.
// ---------------------------------------------------------------------------

let __asbQueueTimer = null;

function autoRunWidgetValue(node) {
  if (!node || !node.widgets) return false;
  const w = node.widgets.find((x) => x.name === "auto_run");
  return !!(w && w.value);
}

function maybeAutoQueue(node, output) {
  if (!node || node.type !== "ASB_BatchIndex") return;
  if (!output || output.done === undefined) return;
  if (output.done === true) {
    console.info("[ASB] auto-run finished after index", output.index);
    return;
  }
  if (!autoRunWidgetValue(node)) return;

  if (__asbQueueTimer) return; // one outstanding auto-queue at a time
  __asbQueueTimer = setTimeout(async () => {
    __asbQueueTimer = null;
    try {
      // don't stack on top of a manual batch
      const q = app.api && typeof app.api.getQueue === "function"
        ? await app.api.getQueue()
        : null;
      const pending = q ? (q.queue_pending || q.pending || []).length : 0;
      const running = q ? (q.queue_running || q.running || []).length : 0;
      if (pending > 0 || running > 0) return;
      if (typeof app.queuePrompt === "function") {
        console.info("[ASB] auto-queueing next run (index → next)");
        app.queuePrompt(1);
      }
    } catch (err) {
      console.warn("[ASB] auto-run guard error:", err);
    }
  }, 350);
}


// ---- ASB UI polish (v3.2) ----
// Help text under mode dropdown + visual level badges in plan preview
(function () {
  const MODE_HELP = {
    level: "One clothing state per undress level × each pose piece. Dense coverage.",
    transition: "Stable pose blocks per level + short one-item undress transitions (MetArt/girlstop rhythm). Best default.",
    random: "Seeded random sample of N shots across levels.",
    exhaustive: "Every clothing state combo (capped). Heavy — use sparingly.",
  };

  function attachModeHelp(node) {
    if (!node || node.comfyClass !== "ASB_SetPlan") return;
    const modeWidget = (node.widgets || []).find(w => w.name === "mode");
    if (!modeWidget || modeWidget._asbHelp) return;
    modeWidget._asbHelp = true;
    const orig = modeWidget.callback;
    const help = document.createElement("div");
    help.style.cssText = "font-size:11px;opacity:0.75;padding:4px 8px;max-width:320px;line-height:1.35;";
    help.textContent = MODE_HELP[modeWidget.value] || "";
    // insert after widget DOM when available
    const tryInsert = () => {
      if (modeWidget.inputEl && modeWidget.inputEl.parentElement && !modeWidget._asbHelpEl) {
        modeWidget.inputEl.parentElement.appendChild(help);
        modeWidget._asbHelpEl = help;
      }
    };
    tryInsert();
    modeWidget.callback = function () {
      help.textContent = MODE_HELP[modeWidget.value] || "";
      tryInsert();
      if (orig) return orig.apply(this, arguments);
    };
  }

  function attachModelAccessoryHints(node) {
    if (!node || node.comfyClass !== "ASB_LoadModel") return;
    const piercings = (node.widgets || []).find(w => w.name === "include_piercings");
    const tattoos = (node.widgets || []).find(w => w.name === "include_tattoos");
    if (piercings && !piercings._asbHint) {
      piercings._asbHint = true;
      const old = piercings.callback;
      piercings.callback = function () {
        if (old) old.apply(this, arguments);
      };
    }
  }

  const _app = window.app;
  if (!_app) return;
  const prev = _app.registerExtension;
  // hook graph node creation
  document.addEventListener("DOMContentLoaded", () => {});
  if (_app.graph) {
    // periodic light pass for new nodes
    setInterval(() => {
      try {
        const nodes = _app.graph._nodes || [];
        nodes.forEach(n => {
          attachModeHelp(n);
          attachModelAccessoryHints(n);
        });
      } catch (e) {}
    }, 2000);
  }
})();
