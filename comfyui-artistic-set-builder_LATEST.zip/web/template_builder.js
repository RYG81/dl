/**
 * Template Builder v2 — sidebar chips + live preview panel.
 * Button widget opens a 3-panel modal: chips | editor | preview.
 */
import { app } from "../../../scripts/app.js";
import { api } from "../../../scripts/api.js";
import { ComfyDialog, $el } from "../../../scripts/ui.js";

const DIALOG_ID = "ps-v2-tb-dialog";

// ── Placeholder definitions with sample values for preview ──
const PLACEHOLDERS = [
  {id:"style_prefix",       label:"Style Prefix",       sample:"MetArt fine art nude editorial", group:"Style & Identity"},
  {id:"critical_guard",     label:"Critical Guard",     sample:"Single continuous photograph, one unified frame, one subject only, realistic anatomy, accurate hands", group:"Style & Identity"},
  {id:"subject_identity",   label:"Subject Identity",   sample:"Anouk Vermeer, a 27-year-old Dutch woman with ash-blonde hair, pale grey-blue eyes", group:"Style & Identity"},
  {id:"subject_first_name", label:"Subject First Name", sample:"Anouk", group:"Style & Identity"},
  {id:"style_aesthetic",    label:"Style Aesthetic",    sample:"soft natural light, European villa aesthetic, organic unposed elegance", group:"Style & Identity"},
  {id:"quality_tail",       label:"Quality Tail",       sample:"natural skin texture with visible pores, realistic anatomy, accurate hands", group:"Style & Identity"},
  {id:"phase_number",       label:"Phase Number",       sample:"1", group:"Phase & Wardrobe"},
  {id:"phase_name",         label:"Phase Name",         sample:"THE INTRODUCTION", group:"Phase & Wardrobe"},
  {id:"phase_description",  label:"Phase Description",  sample:"Fully dressed, establishing presence — the quiet before anything happens", group:"Phase & Wardrobe"},
  {id:"wardrobe_summary",   label:"Wardrobe Summary",   sample:"All 4 items worn", group:"Phase & Wardrobe"},
  {id:"outfit_recall",      label:"Outfit Recall",      sample:"The Saffron Camisole & Linen Skirt lies discarded nearby", group:"Phase & Wardrobe"},
  {id:"clothing_continuity",label:"Clothing Continuity",sample:"She wears saffron silk camisole that catches the morning light, over blush silk bralette", group:"Phase & Wardrobe"},
  {id:"pose_description",   label:"Pose Description",   sample:"one arm folded loosely across her ribs while the opposite hand lifts to touch her hair", group:"Pose & Expression"},
  {id:"pose_bridge",        label:"Pose Bridge",        sample:", gathering the hem of the camisole in both hands", group:"Pose & Expression"},
  {id:"micro_text",         label:"Micro Movement",     sample:"the breeze lifting a strand of hair across her cheek", group:"Pose & Expression"},
  {id:"gaze_text",          label:"Gaze Direction",     sample:"toward the light with quiet steady contentment", group:"Pose & Expression"},
  {id:"expression_text",    label:"Expression",         sample:"features relaxed, eyes holding the light", group:"Pose & Expression"},
  {id:"mood_word",          label:"Mood Word",          sample:"quiet contentment", group:"Pose & Expression"},
  {id:"shot_description",   label:"Shot Description",   sample:"a full-figure portrait from crown to feet", group:"Camera"},
  {id:"angle_description",  label:"Angle Description",  sample:"a direct eye-level view creating immediate connection", group:"Camera"},
  {id:"framing_description",label:"Framing Description",sample:"she occupies one third of the frame with intentional negative space", group:"Camera"},
  {id:"location_name",      label:"Location Name",      sample:"Tuscany Olive Grove Terrace", group:"Location & Environment"},
  {id:"location_desc",      label:"Location Desc",      sample:"A stone terrace shaded by ancient olive trees in the Tuscan hills", group:"Location & Environment"},
  {id:"visible_surfaces",   label:"Visible Surfaces",   sample:" Visible surfaces: stone terrace, olive tree.", group:"Location & Environment"},
  {id:"visible_props",      label:"Visible Props",      sample:" Visible props: terracotta pot.", group:"Location & Environment"},
  {id:"visibility_directive",label:"Discarded Garments",sample:" Nearby: The saffron camisole lies draped over the arm of the nearby chair.", group:"Location & Environment"},
  {id:"light_description",  label:"Lighting",           sample:"morning light, clear air — soft morning directional light", group:"Location & Environment"},
  {id:"piercing_line",      label:"Piercing Detail",    sample:"A delicate gold stud at the nostril (14k gold).", group:"Optional"},
];

const GROUPS = [...new Set(PLACEHOLDERS.map(p => p.group))];

// Mock context for live preview rendering
const MOCK_CTX = {};
PLACEHOLDERS.forEach(p => { MOCK_CTX[p.id] = p.sample; });
// Override empty samples with visible content
MOCK_CTX.visible_surfaces = " Visible surfaces: stone terrace, olive tree.";
MOCK_CTX.visible_props = " Visible props: terracotta pot, ivory cashmere throw.";
MOCK_CTX.visibility_directive = " Nearby: The saffron camisole lies draped over the arm of the nearby chair. The oatmeal linen skirt lies in a soft collapsed ring on the floorboards.";
MOCK_CTX.pose_bridge = ", gathering the hem of the Saffron Silk Camisole in both hands";
MOCK_CTX.micro_text = "the breeze lifting a strand of hair across her cheek";
MOCK_CTX.outfit_recall = " The Saffron Camisole & Linen Skirt lies discarded nearby.";

// ── CSS ──
function injectCSS() {
  if (document.getElementById("ps-v2-tb-css")) return;
  const style = document.createElement("style");
  style.id = "ps-v2-tb-css";
  style.textContent = `
#${DIALOG_ID} {
  align-items:center; background:rgba(0,0,0,0.75); inset:0; display:none;
  justify-content:center; position:fixed; z-index:10050;
}
.ps-tb2-panel {
  background:#181818; border:1px solid #3c3c3c; border-radius:10px;
  color:#f0f0f0; display:flex; flex-direction:column;
  height:94vh; max-height:880px; overflow:hidden; width:min(1300px,97vw);
  box-shadow:0 20px 80px rgba(0,0,0,0.5);
}
.ps-tb2-hdr {
  align-items:center; border-bottom:1px solid #2a2a2a; display:flex;
  flex-shrink:0; justify-content:space-between; padding:14px 20px;
}
.ps-tb2-hdr h3 { font-size:17px; font-weight:650; margin:0; letter-spacing:-0.3px; }
.ps-tb2-hdr p { color:#777; font-size:11px; margin:3px 0 0; }
.ps-tb2-hdr kbd {
  background:#222; border:1px solid #3a3a3a; border-radius:3px;
  color:#888; font-family:inherit; font-size:10px; margin:0 2px; padding:1px 5px;
}
.ps-tb2-close {
  background:#252525; border:0; border-radius:6px; color:#ccc; cursor:pointer;
  font-size:18px; line-height:1; padding:6px 14px;
}
.ps-tb2-close:hover { background:#3a3a3a; color:#fff; }
.ps-tb2-body {
  display:grid; flex:1; gap:0; grid-template-columns:280px 1fr 380px;
  min-height:0; overflow:hidden;
}
/* ── LEFT: Placeholder Sidebar ── */
.ps-tb2-sidebar {
  background:#141414; border-right:1px solid #222; display:flex;
  flex-direction:column; overflow:hidden;
}
.ps-tb2-sidebar-hdr {
  border-bottom:1px solid #222; color:#888; flex-shrink:0;
  font-size:10px; font-weight:700; letter-spacing:0.5px;
  padding:10px 14px; text-transform:uppercase;
}
.ps-tb2-sidebar-list {
  flex:1; overflow-y:auto; padding:6px 10px;
}
.ps-tb2-group-label {
  color:#555; font-size:9px; font-weight:700; letter-spacing:0.5px;
  margin:10px 4px 4px; text-transform:uppercase;
}
.ps-tb2-group-label:first-child { margin-top:2px; }
.ps-tb2-chip {
  align-items:center; background:#1e1e1e; border:1px solid transparent;
  border-radius:5px; color:#bbb; cursor:pointer; display:flex;
  font-size:10.5px; gap:6px; margin:2px 0; padding:5px 8px;
  transition:all .12s; white-space:nowrap;
}
.ps-tb2-chip:hover {
  background:#1a2a40; border-color:#2f6fed; color:#fff;
  transform:translateX(2px);
}
.ps-tb2-chip code {
  background:#111; border-radius:3px; color:#7eb8ff; flex-shrink:0;
  font-family:'Consolas','Monaco',monospace; font-size:10px;
  padding:1px 5px;
}
.ps-tb2-chip .hint {
  color:#555; flex:1; font-size:9px; overflow:hidden;
  text-overflow:ellipsis; white-space:nowrap;
}
.ps-tb2-chip:hover .hint { color:#889; }
/* ── CENTER: Editor ── */
.ps-tb2-editor {
  display:flex; flex-direction:column; overflow:hidden;
}
.ps-tb2-editor-hdr {
  align-items:center; border-bottom:1px solid #222; display:flex;
  flex-shrink:0; gap:10px; padding:8px 14px;
}
.ps-tb2-editor-hdr select {
  background:#111; border:1px solid #333; border-radius:5px;
  color:#ccc; flex:1; font-size:11px; padding:5px 8px;
}
.ps-tb2-editor-hdr button {
  background:#222; border:1px solid #333; border-radius:5px;
  color:#aaa; cursor:pointer; font-size:10px; padding:5px 10px;
}
.ps-tb2-editor-hdr button:hover { background:#333; color:#ddd; }
.ps-tb2-editor-hdr button.primary { background:#2f6fed; border-color:#2f6fed; color:#fff; }
.ps-tb2-editor-hdr button.primary:hover { background:#3d7eff; }
.ps-tb2-textarea {
  background:#0d0d0d; border:0; color:#e0e0e0; flex:1;
  font-family:'Consolas','Monaco','Courier New',monospace;
  font-size:12px; line-height:1.6; min-height:0; outline:none;
  overflow-y:auto; padding:12px 16px; resize:none; tab-size:2;
}
.ps-tb2-textarea::selection { background:rgba(47,111,237,0.35); }
.ps-tb2-footer {
  align-items:center; border-top:1px solid #222; display:flex;
  flex-shrink:0; gap:10px; padding:8px 14px;
}
.ps-tb2-footer .status {
  color:#666; flex:1; font-size:10px;
}
.ps-tb2-footer .status.ok { color:#5a8a4e; }
.ps-tb2-footer .status.err { color:#c46a6a; }
.ps-tb2-footer button.primary {
  background:#2f6fed; border:0; border-radius:6px; color:#fff;
  cursor:pointer; font-size:12px; font-weight:600; padding:7px 18px;
}
.ps-tb2-footer button.primary:hover { background:#3d7eff; }
/* ── RIGHT: Live Preview ── */
.ps-tb2-preview {
  background:#121212; border-left:1px solid #222; display:flex;
  flex-direction:column; overflow:hidden;
}
.ps-tb2-preview-hdr {
  border-bottom:1px solid #222; color:#888; flex-shrink:0;
  font-size:10px; font-weight:700; letter-spacing:0.5px;
  padding:10px 14px; text-transform:uppercase;
}
.ps-tb2-preview-body {
  color:#bbb; flex:1; font-family:'Georgia','Times New Roman',serif;
  font-size:11.5px; line-height:1.7; overflow-y:auto;
  padding:14px 16px; white-space:pre-wrap; word-wrap:break-word;
}
.ps-tb2-preview-body .ph-highlight {
  background:rgba(47,111,237,0.2); border-radius:2px; padding:0 2px;
}
.ps-tb2-preview-body .ph-missing {
  background:rgba(200,100,100,0.2); color:#c46a6a;
  border-radius:2px; padding:0 2px;
}
.ps-tb2-preview-body .ph-empty {
  color:#555;
}
/* Scrollbars */
.ps-tb2-sidebar-list::-webkit-scrollbar,
.ps-tb2-textarea::-webkit-scrollbar,
.ps-tb2-preview-body::-webkit-scrollbar { width:5px; }
.ps-tb2-sidebar-list::-webkit-scrollbar-thumb,
.ps-tb2-textarea::-webkit-scrollbar-thumb,
.ps-tb2-preview-body::-webkit-scrollbar-thumb { background:#2a2a2a; border-radius:3px; }
`;
  document.head.appendChild(style);
}

// ═══════════════════════════════════════════
// DIALOG CLASS
// ═══════════════════════════════════════════
class TemplateBuilderDialog extends ComfyDialog {
  // exposed on window for Browse panel button
  constructor() {
    super();
    this._nodeRef = null;
    this._widgetName = "template";
    this._onClose = null;

    this._keyHandler = (e) => { if (e.key === "Escape") this._close(); };

    // ── Build DOM ──
    this.element = $el("div", {
      id: DIALOG_ID,
      parent: document.body,
      style: {
        alignItems: "center",
        background: "rgba(0,0,0,0.75)",
        bottom: "0",
        display: "none",
        justifyContent: "center",
        left: "0",
        position: "fixed",
        right: "0",
        top: "0",
        zIndex: "10050",
      },
    }, [
      $el("div.ps-tb2-panel", [
        // Header
        $el("div.ps-tb2-hdr", [
          $el("div", [
            $el("h3", "Template Builder"),
            $el("p", [
              "Click chips to insert. ", $el("kbd", "Tab"), " autocomplete. ",
              $el("kbd", "Esc"), " close. Right panel shows live preview."
            ]),
          ]),
          $el("button.ps-tb2-close", { textContent: "\u00d7", onclick: () => this._close() }),
        ]),
        // 3-panel body
        $el("div.ps-tb2-body", [
          // LEFT: sidebar
          $el("div.ps-tb2-sidebar", [
            $el("div.ps-tb2-sidebar-hdr", "Placeholders"),
            this._sidebarList = $el("div.ps-tb2-sidebar-list"),
          ]),
          // CENTER: editor
          $el("div.ps-tb2-editor", [
            $el("div.ps-tb2-editor-hdr", [
              this._templateSelect = $el("select", { onchange: () => {
                if (this._templateSelect.value) this._loadTemplate(this._templateSelect.value);
              }}),
              $el("button", { textContent: "Default", title:"Load default editorial template",
                onclick: () => this._loadDefault() }),
              $el("button", { textContent: "Clear", onclick: () => {
                this._textarea.value = ""; this._updateAll();
              }}),
            ]),
            this._textarea = $el("textarea.ps-tb2-textarea", {
              placeholder: "Write your prompt template here...\n\nClick placeholders on the left to insert {{tags}}.\nUse \\n for new lines between sections.",
              oninput: () => this._updateAll(),
              onkeydown: (e) => this._onKeydown(e),
            }),
            $el("div.ps-tb2-footer", [
              this._statusEl = $el("span.status", "Ready"),
              $el("button.primary", { textContent: "Save & Apply", onclick: () => this._saveAndApply() }),
            ]),
          ]),
          // RIGHT: preview
          $el("div.ps-tb2-preview", [
            $el("div.ps-tb2-preview-hdr", "Live Preview"),
            this._previewBody = $el("div.ps-tb2-preview-body", "Your rendered prompt will appear here..."),
          ]),
        ]),
      ]),
    ]);

    this._buildSidebar();
    this._initTemplateDropdown();
    injectCSS();
  }

  // ── Sidebar chips ──
  _buildSidebar() {
    GROUPS.forEach(group => {
      this._sidebarList.appendChild($el("div.ps-tb2-group-label", group));
      PLACEHOLDERS.filter(p => p.group === group).forEach(ph => {
        const chip = $el("div.ps-tb2-chip", {
          title: ph.sample || ph.label,
          onclick: () => this._insert(ph.id),
        }, [
          $el("code", `{{${ph.id}}}`),
          $el("span.hint", ph.sample || ""),
        ]);
        this._sidebarList.appendChild(chip);
      });
    });
  }

  async _initTemplateDropdown() {
    this._templateSelect.innerHTML = "";
    this._templateSelect.appendChild($el("option", { value: "", textContent: "— Load prompt template —" }));
    try {
      const resp = await api.fetchApi("/asb/templates");
      const data = await resp.json();
      (data.templates || []).forEach(t => {
        const label = t.label || t.name;
        this._templateSelect.appendChild($el("option", { value: t.name, textContent: label }));
      });
    } catch(e) {}
  }

  // ── Insert placeholder at cursor ──
  _insert(id) {
    const ta = this._textarea;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    ta.value = ta.value.substring(0, start) + `{{${id}}}` + ta.value.substring(end);
    ta.selectionStart = ta.selectionEnd = start + id.length + 4;
    ta.focus();
    this._updateAll();
  }

  // ── Tab autocomplete ──
  _onKeydown(e) {
    if (e.key === "Tab") {
      e.preventDefault();
      const ta = this._textarea;
      const pos = ta.selectionStart;
      const before = ta.value.substring(0, pos);
      const match = before.match(/\{\{(\w*)$/);
      if (match) {
        const partial = match[1].toLowerCase();
        const found = PLACEHOLDERS.filter(p => p.id.startsWith(partial));
        if (found.length === 1) {
          const start = pos - match[0].length;
          ta.value = ta.value.substring(0, start) + `{{${found[0].id}}}` + ta.value.substring(pos);
          ta.selectionStart = ta.selectionEnd = start + found[0].id.length + 4;
          this._updateAll();
        }
      }
    }
  }

  // ── Update status + preview ──
  _updateAll() {
    this._updateStatus();
    this._renderPreview();
  }

  _updateStatus() {
    const val = this._textarea.value;
    if (!val.trim()) {
      this._statusEl.textContent = "Ready — write a template or load a saved one";
      this._statusEl.className = "status";
      return;
    }
    const opens = (val.match(/\{\{/g) || []).length;
    const closes = (val.match(/\}\}/g) || []).length;
    if (opens !== closes) {
      this._statusEl.textContent = `Unmatched braces: {{ ${opens} vs }} ${closes}`;
      this._statusEl.className = "status err";
      return;
    }
    const used = [...val.matchAll(/\{\{(\w+)\}\}/g)].map(m => m[1]);
    const unknown = used.filter(u => !PLACEHOLDERS.find(p => p.id === u));
    if (unknown.length) {
      this._statusEl.textContent = `Unknown placeholders: ${unknown.join(", ")}`;
      this._statusEl.className = "status err";
      return;
    }
    this._statusEl.textContent = `${used.length} placeholders used. Template valid.`;
    this._statusEl.className = "status ok";
  }

  _renderPreview() {
    const val = this._textarea.value;
    if (!val.trim()) {
      this._previewBody.innerHTML = '<span style="color:#555">Write a template on the left to see a live preview here with mock data...</span>';
      return;
    }

    // Parse placeholders and replace with mock values
    const opens = (val.match(/\{\{/g) || []).length;
    const closes = (val.match(/\}\}/g) || []).length;
    
    let html = val
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\n/g, '<br>');
    
    // Replace {{placeholder}} with highlighted mock values
    html = html.replace(/\{\{(\w+)\}\}/g, (match, id) => {
      const ph = PLACEHOLDERS.find(p => p.id === id);
      if (!ph) {
        return `<span class="ph-missing" title="Unknown placeholder: ${id}">{{${id}}}</span>`;
      }
      const val = MOCK_CTX[id] || "";
      if (!val) {
        return `<span class="ph-empty" title="${ph.label}: (empty in this context)">{{${id}}}</span>`;
      }
      return `<span class="ph-highlight" title="${ph.label}">${val.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</span>`;
    });

    if (opens !== closes) {
      html += '<br><br><span style="color:#c46a6a">⚠ Unmatched braces — preview may be incomplete</span>';
    }

    this._previewBody.innerHTML = html;
  }

  // ── Template operations ──
  async _loadTemplate(name) {
    try {
      const resp = await api.fetchApi(`/asb/templates/${name}`);
      const data = await resp.json();
      if (data.content) this._textarea.value = data.content;
      this._updateAll();
    } catch(e) {
      this._statusEl.textContent = `Failed to load: ${name}`;
      this._statusEl.className = "status err";
    }
  }

  async _loadDefault() {
    // Load built-in editorial template
    try {
      const resp = await api.fetchApi("/asb/templates/_editorial_default");
      const data = await resp.json();
      if (data.content) this._textarea.value = data.content;
      this._updateAll();
    } catch(e) {
      // Fallback: hardcoded default
      this._textarea.value = `[REAL PHOTOGRAPH \u2014 UNRETOUCHED RAW FILE]\n\n{{style_prefix}}. {{critical_guard}}.\n\nSubject identity: {{subject_identity}}\n\nPhase {{phase_number}}: {{phase_name}}. {{phase_description}}. Wardrobe state: {{wardrobe_summary}}.{{outfit_recall}}\n\nClothing continuity: {{clothing_continuity}}\n\nPose and expression: {{subject_first_name}} is {{pose_description}}{{pose_bridge}}, while {{gaze_text}} with {{expression_text}}, conveying {{mood_word}}.\n\nCamera: photographed in {{shot_description}} from {{angle_description}}, composed as {{framing_description}}.\n\nLocation: {{location_name}}. {{location_desc}}.{{visible_surfaces}}{{visible_props}}{{visibility_directive}}\n\nLighting: {{light_description}}.\n\nQuality and continuity: {{style_aesthetic}}, {{quality_tail}}.`;
      this._updateAll();
    }
  }

  _saveAndApply() {
    const val = this._textarea.value;
    if (this._nodeRef) {
      // Prefer template_body (compact node); fall back to template
      const w = this._nodeRef.widgets?.find(w => w.name === "template_body")
        || this._nodeRef.widgets?.find(w => w.name === "template");
      if (w) { w.value = val; w.callback?.(val); }
      // When freeform applied, set preset to (none) so body wins
      const preset = this._nodeRef.widgets?.find(w => w.name === "template_preset");
      if (preset && val && val.includes("{{")) {
        const opts = preset.options?.values || preset.options || [];
        if (Array.isArray(opts) && opts.includes("(none)")) preset.value = "(none)";
        else if (opts && typeof opts === "object" && "(none)" in opts) preset.value = "(none)";
      }
      this._nodeRef.setDirtyCanvas?.(true, true);
    }
    if (this._onClose) this._onClose(val);
    this._close();
  }

  // ── Open/Close ──
  _open(node, widgetName, currentValue, onClose) {
    try {
      this._nodeRef = node;
      this._widgetName = widgetName || "template_body";
      this._onClose = onClose;
      if (!this.element.parentElement) document.body.appendChild(this.element);
      this._textarea.value = currentValue || "";
      this._updateAll();
      // force visible overlay (inline beats stylesheet display:none)
      Object.assign(this.element.style, {
        display: "flex",
        position: "fixed",
        inset: "0",
        top: "0", left: "0", right: "0", bottom: "0",
        zIndex: "10050",
        alignItems: "center",
        justifyContent: "center",
        background: "rgba(0,0,0,0.75)",
      });
      document.addEventListener("keydown", this._keyHandler);
      setTimeout(() => this._textarea?.focus?.(), 50);
    } catch (err) {
      console.error("[ASB] TemplateBuilder open failed", err);
      alert("Template Builder failed to open — check browser console");
    }
  }

  _close() {
    document.removeEventListener("keydown", this._keyHandler);
    if (this.element) this.element.style.display = "none";
  }

  static launch(node, widgetName, currentValue, onClose) {
    try {
      if (!TemplateBuilderDialog._instance) {
        TemplateBuilderDialog._instance = new TemplateBuilderDialog();
      }
      TemplateBuilderDialog._instance._open(node, widgetName, currentValue, onClose);
    } catch (err) {
      console.error("[ASB] TemplateBuilder launch failed", err);
      alert("Template Builder failed: " + (err?.message || err));
    }
  }
}

// ═══════════════════════════════════════════
// WIDGET FACTORY
// ═══════════════════════════════════════════

// ── Register extension ──
app.registerExtension({
  name: "ASB.TemplateBuilder",

  async nodeCreated(node) {
    if (node.comfyClass !== "ASB_PhotosetBrowser" && node.comfyClass !== "ASB_ShootPlan") return;

    // Hide tall freeform storage if present (do NOT convert type — breaks some Comfy builds)
    const bodyW = node.widgets?.find(w => w.name === "template_body");
    if (bodyW) {
      const hide = () => {
        try {
          bodyW.computeSize = () => [0, -4];
          if (bodyW.element) bodyW.element.style.display = "none";
          if (bodyW.inputEl) {
            bodyW.inputEl.style.display = "none";
            if (bodyW.inputEl.parentElement) bodyW.inputEl.parentElement.style.display = "none";
          }
        } catch (_) {}
      };
      setTimeout(hide, 0);
      setTimeout(hide, 150);
    }

    // Always add the button — even if storage widget is missing
    if (node.widgets?.some(w => w.name === "✎ Template Builder" || w.label === "✎ Template Builder")) return;

    const btn = node.addWidget("button", "✎ Template Builder", null, () => {
      const tb = node.widgets?.find(w => w.name === "template_body")
        || node.widgets?.find(w => w.name === "template");
      const cur = tb?.value || node.properties?.asb_template_body || "";
      if (typeof TemplateBuilderDialog === "undefined" || !TemplateBuilderDialog.launch) {
        console.error("[ASB] TemplateBuilderDialog not defined");
        alert("Template Builder script not loaded — hard-refresh browser");
        return;
      }
      TemplateBuilderDialog.launch(node, tb?.name || "template_body", cur, (newVal) => {
        if (tb) {
          tb.value = newVal;
          if (tb.callback) tb.callback(newVal);
        }
        node.properties = node.properties || {};
        node.properties.asb_template_body = newVal;
        const preset = node.widgets?.find(w => w.name === "template_preset");
        if (preset && newVal && String(newVal).includes("{{")) {
          try { preset.value = "(none)"; } catch (_) {}
        }
        node.setDirtyCanvas?.(true, true);
      });
    });
    if (btn) btn.serializeValue = () => undefined;
  },
});

window.TemplateBuilderDialog = TemplateBuilderDialog;


// Hide ASB_ShootPlan template_body tall textarea after widgets drawn
app.registerExtension({
  name: "ASB.HideTemplateBody",
  async nodeCreated(node) {
    if (node.comfyClass !== "ASB_ShootPlan") return;
    const hide = () => {
      const w = node.widgets?.find((x) => x.name === "template_body");
      if (!w) return;
      w.computeSize = () => [0, -4];
      if (w.element) w.element.style.display = "none";
      if (w.inputEl) {
        w.inputEl.style.display = "none";
        if (w.inputEl.parentElement) w.inputEl.parentElement.style.display = "none";
      }
      node.setSize?.([node.size[0], node.computeSize?.()?.[1] || node.size[1]]);
    };
    setTimeout(hide, 0);
    setTimeout(hide, 100);
  },
});
