// Artistic Set Builder — dynamic dependent dropdowns (v2.1)
//
// Converts the copy/paste text inputs of the ASB selector nodes into real
// dropdowns populated from the connected upstream node's executed output.
//
// Fixed in v2.1: values are now looked up by OUTPUT NAME (not by slot index),
// so it works no matter which slot the link actually connects to. Lists are
// also extracted directly from the upstream OBJECT (location/zone/clothing
// dicts), which is more robust than parsing the pre-formatted strings.
//
// Covered:
//   ASB_LoadLocation  -> ASB_SelectZone.zone_name        (location zones)
//   ASB_SelectZone    -> ASB_SelectPromptPiece.piece_name (zone pieces)
//   ASB_LoadClothing  -> ASB_AdvanceClothing.item_name   (item [state] labels)
//   any clothing obj  -> ASB_SetClothingState.target     (every item x state)
//   ASB_LoadLocation  -> ASB_RandomizeSet.zone_name      (location zones)
//
// The `level` input on ASB_SelectPromptPiece is now a static combo in the node
// definition itself (level_0..level_4), so no JS needed for it.
//
// Behavior: run the upstream node(s) once — the dropdowns fill in from the
// executed data. Before that they stay as normal text fields (or show the
// default), so the classic copy/paste workflow always still works.

import { app } from "../../scripts/app.js";

const SPECS = {
  ASB_SelectZone: {
    input: "location",
    objectName: "location", // upstream output holding the location dict
    listName: "available_zones", // fallback: pre-formatted list string
    widget: "zone_name",
    extract: (loc) =>
      Array.isArray(loc && loc.photo_zones)
        ? loc.photo_zones.map((z) => z.name || z.zone_id).filter(Boolean)
        : null,
  },
  ASB_SelectPromptPiece: {
    input: "zone",
    objectName: "zone",
    listName: "available_pieces",
    widget: "piece_name",
    extract: (zone) =>
      Array.isArray(zone && zone.prompt_pieces)
        ? zone.prompt_pieces
            .map((p) => [p.id, p.type].filter(Boolean).join(" | "))
            .filter(Boolean)
        : null,
  },
  ASB_AdvanceClothing: {
    input: "clothing",
    objectName: "clothing",
    listName: "available_items",
    widget: "item_name",
    extract: (cl) => {
      if (!cl || !Array.isArray(cl.items)) return null;
      return cl.items
        .map((it) => {
          const name = it.name || it.item_id;
          if (!name) return null;
          const cur =
            it.current_state ||
            (it.states && it.states[0] && it.states[0].state_id) ||
            "fully_worn";
          return `${name} [${cur}]`;
        })
        .filter(Boolean);
    },
  },
  ASB_SetClothingState: {
    input: "clothing",
    objectName: "clothing",
    listName: "item_states",
    widget: "target",
    extract: (cl) => {
      if (!cl || !Array.isArray(cl.items)) return null;
      const out = [];
      for (const it of cl.items) {
        const name = it.name || it.item_id;
        if (!name) continue;
        for (const st of it.states || []) {
          if (st && st.state_id) out.push(`${name} [${st.state_id}]`);
        }
      }
      return out;
    },
  },
  ASB_RandomizeSet: {
    input: "location",
    objectName: "location",
    listName: "available_zones",
    widget: "zone_name",
    extract: (loc) =>
      Array.isArray(loc && loc.photo_zones)
        ? loc.photo_zones.map((z) => z.name || z.zone_id).filter(Boolean)
        : null,
  },
};

const REGISTRY = new Map();

function upstream(node, inputName) {
  const inp = (node.inputs || []).find((i) => i.name === inputName);
  if (!inp || inp.link == null) return null;
  const link = (app.graph.links || []).find((l) => l.id === inp.link);
  if (!link) return null;
  const src = app.graph.getNodeById(link.origin_id);
  return src ? { node: src, link, slot: link.origin_slot } : null;
}

// Read a value out of an upstream node. Tries, in order:
//   1. the link's carried data (ComfyUI stores the passed value on the link)
//   2. the stashed executed-output map, by OUTPUT NAME
//   3. the same map, by slot index
//   4. litegraph's getOutputData(slot)
function readOutput(node, slot, name, link) {
  if (link && link.data !== undefined) return link.data;
  const msg = node.__asbLast || {};
  if (name && msg[name] !== undefined) return msg[name];
  if (slot != null && msg[slot] !== undefined) return msg[slot];
  try {
    const v = node.getOutputData ? node.getOutputData(slot) : undefined;
    if (v !== undefined) return v;
  } catch (e) {
    /* ignore */
  }
  return undefined;
}

function parseList(str) {
  return typeof str === "string"
    ? str.split("|").map((s) => s.trim()).filter(Boolean)
    : [];
}

function getValues(entry) {
  const up = upstream(entry.node, entry.spec.input);
  if (!up) return [];
  // 1) try to extract straight from the object
  const obj = readOutput(up.node, up.slot, entry.spec.objectName, up.link);
  if (obj !== undefined && obj !== null) {
    const vals = entry.spec.extract(obj);
    if (Array.isArray(vals) && vals.length) return vals;
  }
  // 2) fall back to the pre-formatted list string
  const list = readOutput(up.node, up.slot, entry.spec.listName, up.link);
  const vals = parseList(list);
  if (vals.length) return vals;
  return [];
}

function applyValues(entry, values) {
  const w = entry.widget;
  if (!w || !values.length) return;

  // mutate the existing widget into a combo (keeps widget order/serialization)
  if (w.type !== "combo") w.type = "combo";
  w.options = w.options || {};
  const same =
    Array.isArray(w.options.values) &&
    w.options.values.length === values.length &&
    w.options.values.every((v, i) => v === values[i]);
  if (!same) w.options.values = values.slice();

  // keep a sensible selection: keep current if still valid, else first option
  if (!values.includes(w.value)) {
    w.value = values[0];
    if (w.callback) w.callback(w.value);
  }
  if (w.computeSize) w.computeSize();
}

function refresh(entry) {
  applyValues(entry, getValues(entry));
}

let timer = null;
function refreshAll() {
  for (const entry of REGISTRY.values()) refresh(entry);
  if (app.graph) app.graph.setDirtyCanvas(true, true);
}
function debouncedRefreshAll() {
  if (timer) clearTimeout(timer);
  timer = setTimeout(refreshAll, 120);
}

app.registerExtension({
  name: "ArtisticSetBuilder.DynamicCombos",

  beforeRegisterNodeDef(nodeType, nodeData) {
    const spec = SPECS[nodeData.name];
    if (!spec) return;

    const onNodeCreated = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      const r = onNodeCreated
        ? onNodeCreated.apply(this, arguments)
        : undefined;
      const w = (this.widgets || []).find((x) => x.name === spec.widget);
      if (w) {
        REGISTRY.set(this.id, { node: this, widget: w, spec });
        refresh(REGISTRY.get(this.id));
      }
      return r;
    };
  },

  setup() {
    if (window.__asbDynamicCombosLoaded) return;
    window.__asbDynamicCombosLoaded = true;

    // 1) after ANY node executes, stash its outputs and refresh all combos
    if (app.api && app.api.addEventListener) {
      app.api.addEventListener("executed", (e) => {
        const id = e && e.detail && e.detail.node;
        const node = app.graph.getNodeById(id);
        if (node && e.detail.output) node.__asbLast = e.detail.output;
        debouncedRefreshAll();
      });
    }

    // 2) refresh when the graph changes (upstream dropdown switched, links
    //    rerouted, node moved, etc.)
    const g = app.graph;
    if (g && !g.__asbDynamicCombosHook) {
      g.__asbDynamicCombosHook = true;
      const orig = g.onAfterChange;
      g.onAfterChange = function (...args) {
        if (orig) orig.apply(this, args);
        debouncedRefreshAll();
      };
    }
  },
});


// ---- ASB UI polish (v3.2) ----
// Help text under mode dropdown + visual level badges in plan preview
(function () {
  const MODE_HELP = {
    level: "One clothing state per undress level × each pose piece. Dense coverage.",
    transition: "Stable pose blocks per level + short one-item undress transitions (MetArt/girlstop rhythm). Best default.",
    random: "Seeded random sample of N shots across levels.",
    exhaustive: "Every clothing state combo (capped). Heavy — use sparingly.",
  };

  function attachModeHelp(node) {
    if (!node || node.comfyClass !== "ASB_SetPlan") return;
    const modeWidget = (node.widgets || []).find(w => w.name === "mode");
    if (!modeWidget || modeWidget._asbHelp) return;
    modeWidget._asbHelp = true;
    const orig = modeWidget.callback;
    const help = document.createElement("div");
    help.style.cssText = "font-size:11px;opacity:0.75;padding:4px 8px;max-width:320px;line-height:1.35;";
    help.textContent = MODE_HELP[modeWidget.value] || "";
    // insert after widget DOM when available
    const tryInsert = () => {
      if (modeWidget.inputEl && modeWidget.inputEl.parentElement && !modeWidget._asbHelpEl) {
        modeWidget.inputEl.parentElement.appendChild(help);
        modeWidget._asbHelpEl = help;
      }
    };
    tryInsert();
    modeWidget.callback = function () {
      help.textContent = MODE_HELP[modeWidget.value] || "";
      tryInsert();
      if (orig) return orig.apply(this, arguments);
    };
  }

  function attachModelAccessoryHints(node) {
    if (!node || node.comfyClass !== "ASB_LoadModel") return;
    const piercings = (node.widgets || []).find(w => w.name === "include_piercings");
    const tattoos = (node.widgets || []).find(w => w.name === "include_tattoos");
    if (piercings && !piercings._asbHint) {
      piercings._asbHint = true;
      const old = piercings.callback;
      piercings.callback = function () {
        if (old) old.apply(this, arguments);
      };
    }
  }

  const _app = window.app;
  if (!_app) return;
  const prev = _app.registerExtension;
  // hook graph node creation
  document.addEventListener("DOMContentLoaded", () => {});
  if (_app.graph) {
    // periodic light pass for new nodes
    setInterval(() => {
      try {
        const nodes = _app.graph._nodes || [];
        nodes.forEach(n => {
          attachModeHelp(n);
          attachModelAccessoryHints(n);
        });
      } catch (e) {}
    }, 2000);
  }
})();
