"""
Headless tests for the ASB v2 node pack.

Run from the pack root:
    python -m pytest tests/test_v2.py -q
or directly:
    python tests/test_v2.py
"""
import importlib
import json
import os
import shutil
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACK = ROOT  # tests live inside the pack itself


def import_pack():
    """Import the package under a valid module name (dir has hyphens)."""
    tmp = tempfile.mkdtemp(prefix="asb_test_")
    link = os.path.join(tmp, "asb_pkg")
    os.symlink(PACK, link)
    sys.path.insert(0, tmp)
    return importlib.import_module("asb_pkg")


PKG = import_pack()
N = PKG.nodes
DB = PKG.utils.database


def test_model_loader():
    m, mp, tok = N.model_loader.ASB_LoadModel().load("liora", "standard")
    assert "Liora" in mp and "26" in mp
    assert tok == "Liora"
    _, mp_min, _ = N.model_loader.ASB_LoadModel().load("liora", "minimal")
    assert "skin" not in mp_min.lower()
    _, mp_det, _ = N.model_loader.ASB_LoadModel().load("sienna", "detailed")
    assert len(mp_det) > len(mp_min)


def test_location_and_zone():
    loc, light, zones = N.location_loader.ASB_LoadLocation().load("cozy_living")
    assert "Window Zone" in zones and "Sofa Zone" in zones
    z, zn, pieces = N.zone_selector.ASB_SelectZone().select(loc, "Sofa Zone")
    assert zn == "Sofa Zone" and "Sofa_01" in pieces


def test_clothing_state_machine():
    cl, avail, states = N.clothing_loader.ASB_LoadClothing().load("elegant_dress_set")
    assert "Elegant Mini Dress" in avail and "Elegant Mini Dress: fully_worn | " in states

    cl2, changed, phrases, _, _ = N.clothing_state.ASB_AdvanceClothing().advance(
        cl, "Black Briefs [fully_worn]")
    assert changed.startswith("Black Briefs")
    assert "pulled_aside" in changed
    assert "panties pulled aside" in phrases

    cl3, changed3, *_ = N.clothing_state.ASB_AdvanceClothing().advance(
        cl2, "Black Briefs [pulled_aside]")
    assert "around_thighs" in changed3

    ph, lvl, _, lvl_name, removed = N.clothing_state.ASB_GetClothingStatus().get(cl3)
    assert lvl == "level_0" and removed == 0  # briefs still worn (moved, not removed)
    assert "level_0" in lvl_name or lvl_name  # level_name present


def test_set_clothing_state():
    cl, *_ = N.clothing_loader.ASB_LoadClothing().load("elegant_dress_set")
    cl2, changed, states, avail = N.set_clothing_state.ASB_SetClothingState().set_state(
        cl, "Black Briefs [around_ankles]")
    assert "around_ankles" in changed
    ph, lvl, *_ = N.clothing_state.ASB_GetClothingStatus().get(cl2)
    assert lvl == "level_0"  # briefs moved, not removed -> still level_0


def test_level_engine_and_custom_config():
    from asb_pkg.utils import levels

    cl, *_ = N.clothing_loader.ASB_LoadClothing().load("elegant_dress_set")
    # remove all 4 items -> level_4
    for item in cl["items"]:
        item["current_state"] = "removed"
    assert levels.compute_level(cl)[0] == "level_4"

    # custom level_config: "pulled_aside" counts as removed
    cl["level_config"] = {
        "removed_states": ["removed", "pulled_aside"],
        "thresholds": [0, 1, 2, 3, 4],
        "level_names": ["dressed", "semi", "bare", "more", "full"],
    }
    cl["items"][0]["current_state"] = "fully_worn"
    cl["items"][1]["current_state"] = "fully_worn"
    cl["items"][2]["current_state"] = "pulled_aside"
    cl["items"][3]["current_state"] = "removed"
    lvl_id, lvl_name, removed = levels.compute_level(cl)
    assert lvl_id == "level_2" and lvl_name == "bare" and removed == 2


def test_piece_selector_camera():
    zone = {
        "prompt_pieces": [
            {"id": "A_01", "type": "pose", "prompt": "standing", "camera": "85mm f/1.8"},
            {"id": "A_02", "type": "pose", "prompt": "sitting"},
        ]
    }
    p, sel, cam = N.prompt_piece_selector.ASB_SelectPromptPiece().select(
        zone, "level_0", "A_01 | pose")
    assert p == "standing" and cam == "85mm f/1.8"
    _, _, cam2 = N.prompt_piece_selector.ASB_SelectPromptPiece().select(
        zone, "level_0", "A_02")
    assert cam2 == ""


def test_randomizer_deterministic_and_range():
    loc, *_ = N.location_loader.ASB_LoadLocation().load("cozy_living")
    cl, *_ = N.clothing_loader.ASB_LoadClothing().load("elegant_dress_set")

    r1 = N.randomize_set.ASB_RandomizeSet().randomize(loc, cl, seed=42, min_level=2, max_level=4)
    r2 = N.randomize_set.ASB_RandomizeSet().randomize(loc, cl, seed=42, min_level=2, max_level=4)
    r3 = N.randomize_set.ASB_RandomizeSet().randomize(loc, cl, seed=43, min_level=2, max_level=4)

    assert r1 == r2, "same seed must give identical results"
    zone, zname, ppiece, sel, rcl, level, seed_used, phrases, avail = r1
    assert level in ("level_2", "level_3", "level_4")
    assert seed_used == 42
    assert len(ppiece) > 0 and len(phrases) > 0

    # zone locked
    zl = N.randomize_set.ASB_RandomizeSet().randomize(
        loc, cl, seed=1, min_level=0, max_level=0, zone_name="Window Zone")
    assert zl[1] == "Window Zone"

    # 2-item set clamps max level to level_2
    cl2, *_ = N.clothing_loader.ASB_LoadClothing().load("sleep_set")
    r4 = N.randomize_set.ASB_RandomizeSet().randomize(loc, cl2, seed=7, min_level=0, max_level=4)
    assert r4[5] in ("level_0", "level_1", "level_2")


def test_manifest():
    node = N.manifest.ASB_Manifest()
    csv1, js1, last1, count1 = node.log("prompt A", "neg A", seed=11, filename_hint="a")
    csv2, js2, last2, count2 = node.log("prompt B", "", seed=22, tags="zone=x")
    assert count1 == 1 and count2 == 2
    assert "prompt A" in csv2 and "index" in csv2.splitlines()[0]
    import json as _json
    data = _json.loads(js2)
    assert data[1]["seed"] == 22 and data[1]["tags"] == "zone=x"
    assert last2.startswith("[2]")
    # reset
    _, _, _, count3 = node.log("prompt C", reset=True)
    assert count3 == 1


def test_build_prompt_v2():
    bp = N.prompt_builder.ASB_BuildPrompt()
    fp, neg = bp.build(
        model_prompt="Liora, 26",
        clothing_phrases="wearing black panties",
        prompt_piece="standing",
        lighting="soft light",
        style="black and white",
        quality="photorealistic, 8k",
        level="level_0",
        camera_technical="85mm f/1.8",
        auto_negative=True,
    )
    assert "85mm f/1.8" in fp and "black and white" in fp
    assert "color" in neg  # style negative

    fp4, neg4 = bp.build(
        model_prompt="M", clothing_phrases="no dress", prompt_piece="P",
        lighting="L", style="custom", quality="Q", level="level_4",
        auto_negative=True, negative_hints="extra person",
    )
    assert "any clothing" in neg4 and "extra person" in neg4
    assert fp4.strip() == "M, no dress, P, L, Q"


def test_validate_node_and_all():
    node = N.validate_node.ASB_ValidateData()
    report, status, errors = node.validate()
    assert errors == 0, f"data should validate clean, got:\n{report}"

    from asb_pkg.utils.validate import validate_all
    issues = validate_all()
    # all existing data must be error-free
    assert not [i for i in issues if i["level"] == "error"]


def test_generate_manifest_script():
    import subprocess
    out = os.path.join(tempfile.gettempdir(), "asb_out_test")
    shutil.rmtree(out, ignore_errors=True)
    script = os.path.join(PACK, "scripts", "generate_manifest.py")
    r = subprocess.run(
        [sys.executable, script, "--model", "liora", "--location", "cozy_living",
         "--clothing", "elegant_dress_set", "--mode", "level", "--out", out],
        capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert os.path.exists(os.path.join(out, "prompts.csv"))
    assert os.path.exists(os.path.join(out, "manifest.json"))
    captions = os.path.join(out, "captions")
    assert os.path.isdir(captions)
    n = len(os.listdir(captions))
    # 18 pieces in cozy_living x their compatible levels
    assert n >= 50, f"level mode should yield ~57 images, got {n}"
    # every caption non-empty and contains model name
    sample = open(os.path.join(captions, os.listdir(captions)[0])).read()
    assert "Liora" in sample
    # csv row count matches caption count
    import csv as _csv
    with open(os.path.join(out, "prompts.csv")) as f:
        rows = list(_csv.DictReader(f))
    assert len(rows) == n
    assert set(rows[0].keys()) == {
        "index", "timestamp", "seed", "filename_hint", "tags", "prompt", "negative_prompt"}


def test_set_plan_level():
    sp = N.set_plan.ASB_SetPlan()
    plan_json, plan_csv, count, prompts_json = sp.build(
        "liora", "cozy_living", "elegant_dress_set", mode="level", seed=1)
    plan = json.loads(plan_json)
    assert count == len(plan) == 57
    assert len(json.loads(prompts_json)) == 57
    first = plan[0]
    assert "final_prompt" in first and "negative_prompt" in first
    assert first["final_prompt"].startswith("Liora")
    assert first["index"] == 0 and first["seed"] == 1
    assert first["filename_hint"] and first["tags"]
    assert "Window Zone" in first["zone"]
    # level spread: all 5 levels present across the plan
    levels = {e["level"] for e in plan}
    assert levels == {"level_0", "level_1", "level_2", "level_3", "level_4"}
    # csv has header + 57 rows
    rows = plan_csv.strip().splitlines()
    assert len(rows) == 58 and rows[0].startswith("index")


def test_set_plan_quality_presets():
    sp = N.set_plan.ASB_SetPlan()
    # quality is now a real dropdown (list) in the node definition
    quality_input = sp.INPUT_TYPES()["required"]["quality"]
    assert isinstance(quality_input[0], list) and "default" in quality_input[0]
    assert "film" in quality_input[0]

    plan, *_ = sp.build("liora", "cozy_living", "elegant_dress_set",
                        mode="level", seed=1, quality="film")
    assert "35mm film" in json.loads(plan)[0]["final_prompt"]

    plan2, *_ = sp.build("liora", "cozy_living", "elegant_dress_set",
                         mode="level", seed=1, quality="default",
                         quality_custom="my custom quality words")
    assert "my custom quality words" in json.loads(plan2)[0]["final_prompt"]


def test_set_plan_deterministic():
    sp = N.set_plan.ASB_SetPlan()
    a, *_ = sp.build("sienna", "luxury_hotel", "evening_gown_set", mode="level", seed=7)
    b, *_ = sp.build("sienna", "luxury_hotel", "evening_gown_set", mode="level", seed=7)
    assert a == b, "same inputs must produce identical plans"
    c, *_ = sp.build("sienna", "luxury_hotel", "evening_gown_set", mode="level", seed=8)
    assert a != c, "different seed should change the plan"


def test_set_plan_random():
    sp = N.set_plan.ASB_SetPlan()
    plan_json, _, count, _ = sp.build(
        "amara", "spa_bathroom", "sheer_lingerie_set", mode="random", seed=99,
        count=25, min_level=2, max_level=4)
    plan = json.loads(plan_json)
    assert count == len(plan) == 25
    seeds = [e["seed"] for e in plan]
    assert len(set(seeds)) == 25, "every image must have a distinct seed"
    assert all(e["base_seed"] == 99 for e in plan)
    assert all(e["level"] in ("level_2", "level_3", "level_4") for e in plan)
    # reproducibility
    plan2, *_ = sp.build(
        "amara", "spa_bathroom", "sheer_lingerie_set", mode="random", seed=99,
        count=25, min_level=2, max_level=4)
    assert plan == json.loads(plan2)


def test_set_plan_exhaustive():
    sp = N.set_plan.ASB_SetPlan()
    plan_json, _, count, _ = sp.build(
        "amara", "cozy_living", "sleep_set", mode="exhaustive", seed=1, cap=500)
    plan = json.loads(plan_json)
    # sleep_set has 2 items x 2 states = 4 combos; level-1 combos only for
    # compatible pieces -> should be > 0 and <= cap
    assert count == len(plan) > 0
    assert len(plan) <= 500


def test_plan_prompt_pick():
    sp = N.set_plan.ASB_SetPlan()
    plan_json, *_ = sp.build("liora", "cozy_living", "elegant_dress_set",
                             mode="level", seed=1)
    pp = N.plan_prompt.ASB_PlanPrompt()
    fp, neg, seed, hint, meta, idx = pp.pick(plan_json, 3)
    e3 = json.loads(plan_json)[3]
    assert fp == e3["final_prompt"] and seed == e3["seed"] and hint == e3["filename_hint"]
    assert idx == 3 and "final_prompt" in json.loads(meta)
    # out of range clamps
    fp0, *_ = pp.pick(plan_json, -5)
    assert fp0 == json.loads(plan_json)[0]["final_prompt"]
    fp_last, *_ = pp.pick(plan_json, 99999)
    assert fp_last == json.loads(plan_json)[-1]["final_prompt"]
    # empty plan
    fp_e, neg_e, seed_e, hint_e, meta_e, idx_e = pp.pick("not json", 0)
    assert "(empty plan)" in fp_e


def test_camera_and_framing_databases():
    from asb_pkg.utils.shoot_plan import resolve_camera, resolve_framing

    # real camera bodies resolve to their tech string
    tech, cid = resolve_camera("canon_r5")
    assert cid == "canon_r5" and "Canon EOS R5" in tech
    tech2, cid2 = resolve_camera("Fujifilm GFX 100S")  # by brand+model
    assert cid2 == "fuji_gfx100s" and "medium format" in tech2
    # free text passes through unchanged
    t3, c3 = resolve_camera("custom 40mm lens, hip level")
    assert c3 == t3 == "custom 40mm lens, hip level"
    assert resolve_camera("") == ("", "")

    # framing: id, name, auto-by-piece-type, free text
    ftech, fid = resolve_framing("close_up")
    assert fid == "close_up" and "close-up framing" in ftech
    ftech2, fid2 = resolve_framing("", "close_portrait")  # auto by piece type
    assert fid2 == "close_up"
    ftech3, fid3 = resolve_framing("hip level, candid")
    assert fid3 == ftech3 == "hip level, candid"
    assert resolve_framing("", "unknown_type") == ("", "")

    sp = N.shoot_plan.ASB_ShootPlan()
    plan = {
        "model": "sienna", "location": "spa_bathroom",
        "clothing_set": "towel_spa_set", "camera": "fuji_gfx100s",
        "shots": [
            {"zone": "Z_Tub", "piece": "TB_01", "outfit": "fully_worn",
             "framing": "close_up"},
            {"zone": "Z_Mirror", "piece": "MR_02", "outfit": "removed"},
        ],
    }
    pjson, *_ = sp.plan(json.dumps(plan), seed=1)
    shots = json.loads(pjson)
    assert shots[0]["camera_ref"] == "fuji_gfx100s"
    assert "Fujifilm" in shots[0]["camera"]
    assert shots[0]["framing_ref"] == "close_up"
    assert "close-up framing" in shots[0]["framing"]
    assert "close-up framing" in shots[0]["final_prompt"]  # framing in the prompt
    # per-shot framing only, camera common
    assert shots[1]["camera_ref"] == "fuji_gfx100s"
    assert shots[0]["camera"] == shots[1]["camera"]

    # node-level camera override applies when the plan has no camera
    plan_nocam = dict(plan); plan_nocam.pop("camera")
    pjson2, *_ = sp.plan(json.dumps(plan_nocam), seed=1, camera="canon_r5")
    shots2 = json.loads(pjson2)
    assert "Canon EOS R5" in shots2[1]["camera"]

    # node-level framing default applies when shot has none
    pjson3, *_ = sp.plan(json.dumps(plan), seed=1, framing="medium")
    shots3 = json.loads(pjson3)
    assert shots3[1]["framing_ref"] == "medium"
    assert "medium shot" in shots3[1]["framing"]


def test_shoot_plan_internal_counter_and_serve():
    sp = N.shoot_plan.ASB_ShootPlan()
    plan = {
        "model": "sienna", "location": "spa_bathroom",
        "clothing_set": "towel_spa_set", "shots": [
            {"zone": "Z_Tub", "piece": "TB_01", "outfit": "fully_worn"},
            {"zone": "Z_Mirror", "piece": "MR_02", "outfit": "removed"},
        ],
    }
    # internal counter serves shot 0, then 1, then done
    r0 = sp.plan(json.dumps(plan), seed=1, use_internal_counter=True)
    assert r0[5] == 0 and r0[6] != "" and r0[10] is False
    r1 = sp.plan(json.dumps(plan), seed=1, use_internal_counter=True)
    assert r1[5] == 1 and r1[10] is True
    # reset counter restarts
    r2 = sp.plan(json.dumps(plan), seed=1, use_internal_counter=True, reset_counter=True)
    assert r2[5] == 0
    # external index serve
    r3 = sp.plan(json.dumps(plan), seed=1, index=1)
    assert r3[5] == 1 and r3[7] == json.loads(r3[0])[1]["negative_prompt"]
    # no serve when neither enabled
    r4 = sp.plan(json.dumps(plan), seed=1)
    assert r4[5] == -1 and r4[6] == ""
    # full output count
    assert len(r0) == 11


def test_template_no_dangling_joiner():
    from asb_pkg.utils.prompt_templates import render_template
    tmpl = {
        "joiner": ", ",
        "positive": ["cinematic composition, {camera_technical}", "subject {model_prompt}"],
        "negative": [],
    }
    out = render_template(tmpl, {"camera_technical": "", "model_prompt": "M"}, True)
    assert out == "cinematic composition, subject M"
    assert not out.endswith(", ")
    tmpl2 = {"joiner": ", ", "positive": ["{a}", "cinematic, {b}"], "negative": []}
    out2 = render_template(tmpl2, {"a": "x", "b": ""}, True)
    assert out2 == "x, cinematic"


def test_make_plan_prompt_script():
    import subprocess
    script = os.path.join(PACK, 'scripts', 'make_plan_prompt.py')
    r = subprocess.run(
        [sys.executable, script, '--model', 'liora', '--location', 'cozy_living',
         '--clothing', 'elegant_dress_set', '--count', '200'],
        capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    out = r.stdout
    assert chr(34) + 'model' + chr(34) + ': ' + chr(34) + 'liora' + chr(34) in out
    assert chr(34) + 'count' + chr(34) + ': 200' in out
    assert 'Z_Window' in out and 'Win_01' in out
    assert 'dress_01' in out and 'canon_r5' in out
    assert 'clothing_set: <clothing set file name from reference>' in out
    assert 'advance: <item_id>' in out
    assert 'RAW YAML ONLY' in out
    bad = subprocess.run([sys.executable, script, '--model', 'nope',
                          '--location', 'cozy_living', '--clothing', 'elegant_dress_set'],
                         capture_output=True, text=True)
    assert bad.returncode == 1 and 'unknown model' in bad.stderr


def test_verify_plan_script():
    import subprocess
    import tempfile
    script = os.path.join(PACK, 'scripts', 'verify_plan.py')
    good = tempfile.NamedTemporaryFile('w', suffix='.yaml', delete=False)
    good.write('model: liora\nlocation: cozy_living\nclothing_set: elegant_dress_set\nshots:\n'
               '  - zone: Z_Window\n    piece: Win_01\n    outfit: fully_worn\n')
    good.close()
    r = subprocess.run([sys.executable, script, good.name], capture_output=True, text=True)
    assert r.returncode == 0 and 'LOADABLE' in r.stdout and '1 shots' in r.stdout
    os.unlink(good.name)

    bad = tempfile.NamedTemporaryFile('w', suffix='.yaml', delete=False)
    bad.write('model: liora\nlocation: cozy_living\nclothing_set: elegant_dress_set\nshots:\n'
             '  - zone: Z_NOPE\n    piece: Win_01\n')
    bad.close()
    r2 = subprocess.run([sys.executable, script, bad.name], capture_output=True, text=True)
    assert r2.returncode == 1 and 'NOT LOADABLE' in r2.stdout and 'Z_NOPE' in r2.stdout
    os.unlink(bad.name)

    # a plan where ALL shots are bad also fails verification (0 valid shots)
    bad2 = tempfile.NamedTemporaryFile('w', suffix='.yaml', delete=False)
    bad2.write('model: liora\nlocation: cozy_living\nclothing_set: elegant_dress_set\nshots:\n'
               '  - zone: Z_NOPE\n    piece: Win_01\n  - zone: Z_Window\n    piece: NOT_A_PIECE\n')
    bad2.close()
    r3 = subprocess.run([sys.executable, script, bad2.name], capture_output=True, text=True)
    assert r3.returncode == 1 and 'NO VALID SHOTS' in r3.stdout
    os.unlink(bad2.name)


def test_ai_200_plan_loadable():
    import copy
    from asb_pkg.utils.database import load_json
    from asb_pkg.utils.levels import item_state_ids
    from asb_pkg.utils.shoot_plan import parse_plan_text, expand_plan

    ldata = load_json('locations', 'cozy_living')
    cdata = load_json('clothing', 'elegant_dress_set')
    zones = ldata['photo_zones']
    items = cdata['items']
    lines = ['title: T', 'model: liora', 'location: cozy_living',
             'clothing_set: elegant_dress_set', 'style: soft boudoir',
             'quality: film', 'camera: canon_r5', 'seed: 42', 'shots:']
    clothing = copy.deepcopy(cdata)
    for it in clothing['items']:
        ids = item_state_ids(it)
        it['current_state'] = ids[0]
    for i in range(200):
        zone = zones[i % len(zones)]
        piece = zone['prompt_pieces'][0]
        lines.append('  - zone: ' + zone['zone_id'])
        lines.append('    piece: ' + piece['id'])
        if i == 0:
            lines.append('    outfit: fully_worn')
        else:
            it = clothing['items'][i % len(items)]
            lines.append('    transition: ' + chr(34) + 'advance: ' + it['item_id'] + chr(34))
            ids = item_state_ids(it)
            idx = ids.index(it['current_state'])
            it['current_state'] = ids[min(idx + 1, len(ids) - 1)]
    plan = '\n'.join(lines)
    data = parse_plan_text(plan)
    shots, report, story = expand_plan(data, base_seed=42)
    assert len(shots) == 200
    assert all(s['zone_id'] and s['piece_id'] for s in shots)
    assert 'ERROR' not in '\n'.join(report)
    assert shots[0]['outfit']['dress_01'] == 'fully_worn'
    assert shots[-1]['outfit']['dress_01'] == 'removed'


def test_no_hardcoded_defaults():
    """The pack must never assume specific ids exist — defaults come from data."""
    from asb_pkg.utils.database import (
        first_camera, first_clothing, first_location, first_model,
        first_piece_label, first_zone_name, get_camera_ids, get_clothing_list,
        get_location_list, get_model_list,
    )
    m = first_model(); assert m and m in get_model_list()
    l = first_location(); assert l and l in get_location_list()
    c = first_clothing(); assert c and c in get_clothing_list()
    cam = first_camera(); cams = get_camera_ids(); assert not cam or cam in cams
    z = first_zone_name(); assert z and z != "Zone"
    pl = first_piece_label(); assert pl and " | " in pl
    sp = N.shoot_plan.ASB_ShootPlan()
    opt = sp.INPUT_TYPES()["optional"]
    assert opt["camera"][0][1:] == cams
    zsel = N.zone_selector.ASB_SelectZone()
    assert zsel.INPUT_TYPES()["required"]["zone_name"][1]["default"] == first_zone_name()
    ppsel = N.prompt_piece_selector.ASB_SelectPromptPiece()
    assert ppsel.INPUT_TYPES()["required"]["piece_name"][1]["default"] == first_piece_label()


def test_sample_plan_from_data():
    import subprocess
    script = os.path.join(PACK, "scripts", "export_planner_data.py")
    r = subprocess.run([sys.executable, script], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    sample = os.path.join(PACK, "examples", "sample_plan_from_data.yaml")
    assert os.path.isfile(sample)
    from asb_pkg.utils.shoot_plan import parse_plan_text, expand_plan
    shots, report, story = expand_plan(parse_plan_text(open(sample).read()))
    assert len(shots) >= 1, report
    assert "ERROR" not in "\n".join(report)


def test_make_plan_prompt_uses_data_defaults():
    import subprocess
    script = os.path.join(PACK, "scripts", "make_plan_prompt.py")
    r = subprocess.run([sys.executable, script, "--count", "50"],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    out = r.stdout
    from asb_pkg.utils.database import first_model, first_location, first_clothing
    assert '"model": "' + first_model() + '"' in out
    assert '"location": "' + first_location() + '"' in out
    assert '"outfit": "' + first_clothing() + '"' in out


def test_plan_is_single_location_single_set():
    """A plan must stay within ONE location + ONE clothing set — per-shot
    overrides are NOT supported, so a photo set is always consistent."""
    from asb_pkg.utils.shoot_plan import parse_plan_text, expand_plan
    import json as _json

    # even if a plan text contains stray per-shot location/clothing_set keys,
    # the engine ignores them and uses the plan-level location + set
    plan = {
        "model": "amara", "location": "cozy_modern_living",
        "clothing_set": "elegant_dress_set",
        "shots": [
            {"zone": "Z_Window", "piece": "W01", "outfit": "fully_worn"},
            {"zone": "Z_Sofa", "piece": "S01",
             "location": "luxury_hotel", "clothing_set": "sheer_lingerie_set",
             "transition": "advance: dress_01"},
        ],
    }
    shots, report, story = expand_plan(parse_plan_text(_json.dumps(plan)), base_seed=1)
    assert len(shots) == 2, report
    for s in shots:
        assert s["location"] == "cozy_modern_living", s["location"]
        assert s["clothing_set"] == "elegant_dress_set", s["clothing_set"]
    assert "ERROR" not in "\n".join(report)


def test_phase_model_description():
    """Model `prompt_model_description` phase text is used per level
    (phase_1..phase_5 <-> level_0..level_4); models without it are unchanged."""
    from asb_pkg.utils.prompts import build_model_prompt
    m = {"name": "X", "age": 25, "body_type": "slim",
         "prompt_model_description": {"phase_1": "dressed look",
                                      "phase_5": "nude look"}}
    p1, _ = build_model_prompt(m, "standard", level="level_0")
    assert "dressed look" in p1 and "X" in p1
    p5, _ = build_model_prompt(m, "standard", level="level_4")
    assert "nude look" in p5
    # empty phase -> static fallback
    p2, _ = build_model_prompt(m, "standard", level="level_1")
    assert "dressed look" not in p2 and "nude look" not in p2 and "X" in p2
    # no phase field -> static
    m2 = {"name": "Y", "age": 30, "body_type": "tall"}
    p0, _ = build_model_prompt(m2, "standard", level="level_3")
    assert "Y" in p0

    # end-to-end: a model with phase desc drives final prompts per level
    import copy
    from asb_pkg.utils.database import load_json
    from asb_pkg.utils.shoot_plan import parse_plan_text, expand_plan
    import json as _json
    mdata = load_json("models", "amara")
    mdata = copy.deepcopy(mdata)
    mdata["prompt_model_description"] = {
        "phase_1": "PHRASE_ONE", "phase_5": "PHRASE_FIVE"}
    tmp = tempfile.mkdtemp(prefix="asb_ph_")
    import shutil as _sh
    os.makedirs(os.path.join(tmp, "models"))
    _json.dump(mdata, open(os.path.join(tmp, "models", "amara.json"), "w"))
    _sh.copytree(os.path.join(PACK, "data", "locations"),
                 os.path.join(tmp, "locations"))
    _sh.copytree(os.path.join(PACK, "data", "clothing"),
                 os.path.join(tmp, "clothing"))
    old_dir = _sh_mod_dir()
    try:
        from asb_pkg.utils import database as dbm
        dbm.DATA_DIR = tmp
        plan = {"model": "amara", "location": "cozy_modern_living",
                "clothing_set": "elegant_dress_set", "shots": [
                    {"zone": "Z_Window", "piece": "W01", "outfit": "fully_worn"},
                    {"zone": "Z_Window", "piece": "W02",
                     "outfit": {"dress_01": "removed", "bra_01": "removed",
                                "briefs_01": "removed", "heels_01": "removed"}}]}
        shots, report, story = expand_plan(
            parse_plan_text(_json.dumps(plan)), base_seed=1)
        assert shots, report
        assert "PHRASE_ONE" in shots[0]["final_prompt"]
        assert "PHRASE_FIVE" in shots[-1]["final_prompt"]
        assert shots[0]["level"] == "level_0" and shots[-1]["level"] == "level_4"
    finally:
        dbm.DATA_DIR = old_dir
        _sh.rmtree(tmp)


def _sh_mod_dir():
    from asb_pkg.utils import database as dbm
    return dbm.DATA_DIR


def test_prompt_and_phrase_used_verbatim():
    """The final prompt must contain the piece `prompt` and state `prompt_phrase`
    text from the data files exactly — never fabricated wording."""
    from asb_pkg.utils.database import load_json
    from asb_pkg.utils.shoot_plan import parse_plan_text, expand_plan
    import json as _json

    loc = load_json("locations", "cozy_modern_living")
    cl = load_json("clothing", "elegant_dress_set")
    z0 = loc["photo_zones"][0]
    p0 = z0["prompt_pieces"][0]
    it0 = cl["items"][0]
    st0 = it0["states"][0]
    plan = _json.dumps({
        "model": "liora", "location": "cozy_modern_living",
        "clothing_set": "elegant_dress_set",
        "shots": [{"zone": z0["zone_id"], "piece": p0["id"],
                   "outfit": {it0["item_id"]: st0["state_id"]}}],
    })
    shots, report, story = expand_plan(parse_plan_text(plan), base_seed=1)
    assert shots, report
    fp = shots[0]["final_prompt"]
    assert p0["prompt"] in fp, "piece prompt not used verbatim"
    assert st0["prompt_phrase"] in fp, "state prompt_phrase not used verbatim"


def test_external_data_folders():
    """Data can live OUTSIDE the pack (data/config.json or ASB_DATA_DIRS) —
    the pack aggregates everything; pack data wins on conflicts."""
    import shutil as _sh
    from asb_pkg.utils import database as dbm

    ext = tempfile.mkdtemp(prefix="asb_ext_")
    for sub in ("models", "locations", "clothing"):
        os.makedirs(os.path.join(ext, sub))
    json.dump({"name": "ExtLoc", "lighting": "soft",
               "photo_zones": [{"zone_id": "ZE", "name": "ExtZone",
                                "prompt_pieces": [{"id": "EP1", "type": "pose",
                                                   "prompt": "pose",
                                                   "compatible_clothing_levels": ["level_0"]}]}]},
              open(os.path.join(ext, "locations", "extloc.json"), "w"))
    json.dump({"name": "ExtModel", "age": 25, "body_type": "slim"},
              open(os.path.join(ext, "models", "extmodel.json"), "w"))
    json.dump({"name": "ExtSet", "items": [
        {"item_id": "e1", "name": "E1",
         "states": [{"state_id": "fully_worn", "prompt_phrase": "wearing e1"},
                    {"state_id": "removed", "prompt_phrase": "no e1"}]}]},
              open(os.path.join(ext, "clothing", "extset.json"), "w"))

    old_env = os.environ.get("ASB_DATA_DIRS")
    os.environ["ASB_DATA_DIRS"] = ext
    dbm.reset_data_cache()
    try:
        locs = dbm.get_location_list()
        mods = dbm.get_model_list()
        cloth = dbm.get_clothing_list()
        assert "extloc" in locs and "cozy_modern_living" in locs
        assert "extmodel" in mods and "amara" in mods
        assert "extset" in cloth and "elegant_dress_set" in cloth
        assert dbm.load_json("locations", "extloc").get("name") == "ExtLoc"
        from asb_pkg.utils.shoot_plan import parse_plan_text, expand_plan
        import json as _json
        plan = {"model": "amara", "location": "extloc", "clothing_set": "elegant_dress_set",
                "shots": [{"zone": "ZE", "piece": "EP1", "outfit": "fully_worn"}]}
        shots, report, story = expand_plan(parse_plan_text(_json.dumps(plan)), base_seed=1)
        assert shots and "ERROR" not in "\n".join(report), report
    finally:
        if old_env is None:
            os.environ.pop("ASB_DATA_DIRS", None)
        else:
            os.environ["ASB_DATA_DIRS"] = old_env
        dbm.reset_data_cache()
        _sh.rmtree(ext)


def test_plan_storage():
    from asb_pkg.utils import plan_storage
    tmp = tempfile.mkdtemp(prefix="asb_plans_")
    old = plan_storage.USER_DIR_OVERRIDE
    plan_storage.USER_DIR_OVERRIDE = tmp
    try:
        # sanitize names
        assert plan_storage.safe_name("my plan: v2") == "my_plan_v2.yaml"
        assert plan_storage.safe_name("shot list") == "shot_list.yaml"
        assert plan_storage.safe_name("../evil/name") == "name.yaml"
        # write / list / read
        p1 = plan_storage.write_plan("planA.yaml", "title: A\nshots: []")
        assert os.path.isfile(p1)
        files, d = plan_storage.list_plans()
        assert "planA.yaml" in files
        assert plan_storage.read_plan("planA.yaml") == "title: A\nshots: []"
        # missing read
        assert plan_storage.read_plan("nope.yaml") is None
        # delete
        assert plan_storage.delete_plan("planA.yaml") is True
        assert plan_storage.delete_plan("planA.yaml") is False
        assert "planA.yaml" not in plan_storage.list_plans()[0]
    finally:
        plan_storage.USER_DIR_OVERRIDE = old


def test_id_based_manual_chain():
    """The manual chain also accepts ids: zone_id, piece id, item_id."""
    loc, _, zones = N.location_loader.ASB_LoadLocation().load("cozy_living")
    z, zn, pieces = N.zone_selector.ASB_SelectZone().select(loc, "Z_Sofa")
    assert zn == "Sofa Zone"
    p, sel, cam = N.prompt_piece_selector.ASB_SelectPromptPiece().select(
        z, "level_0", "Sofa_01")
    assert sel.startswith("Sofa_01")
    cl, *_ = N.clothing_loader.ASB_LoadClothing().load("elegant_dress_set")
    cl2, changed, *_ = N.clothing_state.ASB_AdvanceClothing().advance(
        cl, "dress_01 [fully_worn]")
    assert changed.startswith("Elegant Mini Dress")
    cl3, changed2, *_ = N.set_clothing_state.ASB_SetClothingState().set_state(
        cl, "bra_01 [straps_down]")
    assert "straps_down" in changed2


def test_batch_index():
    bi = N.batch_index.ASB_BatchIndex()
    seen = []
    done_last = None
    for _ in range(5):
        idx, done, total = bi.step(5, False)
        seen.append(idx)
        done_last = done
    assert seen == [0, 1, 2, 3, 4]
    assert done_last is True and total == 5
    # wraps around
    idx, *_ = bi.step(5, False)
    assert idx == 0
    # reset
    idx, *_ = bi.step(5, True)
    assert idx == 0


def test_shoot_plan_elegant_undress():
    sp = N.shoot_plan.ASB_ShootPlan()
    plan_txt = open(os.path.join(PACK, "data", "plans", "elegant_undress_story.yaml")).read()
    pjson, count, story, csv_txt, report, *_ = sp.plan(plan_txt, seed=42)
    shots = json.loads(pjson)
    assert count == len(shots) == 8
    # id-based machine contract + name mirror
    assert shots[0]["outfit"]["dress_01"] == "fully_worn"
    assert shots[0]["outfit_names"]["Elegant Mini Dress"] == "fully_worn"
    assert shots[3]["outfit"]["dress_01"] == "removed"
    assert shots[6]["outfit"]["bra_01"] == "removed"
    assert shots[7]["outfit"]["briefs_01"] == "removed"
    assert shots[0]["zone_id"] == "Z_Window" and shots[0]["piece_id"] == "Win_01"
    # id-based plan authoring works (plan file uses ids)
    assert shots[7]["zone_id"] == "Z_Floor"
    assert shots[7]["level"] == "level_3"
    # seeds are deterministic and distinct
    seeds = [s["seed"] for s in shots]
    assert len(set(seeds)) == 8
    assert "SHOOT:" in story and "OUTCOME" in story
    assert len(csv_txt.strip().splitlines()) == count + 1
    # report lists the transition notes
    assert "advanced" in report

    # reproducibility
    p2, c2, *_ = sp.plan(plan_txt, seed=42)
    assert p2 == pjson

    # the plan's own `seed:` (42) is authoritative -> first shot seed = 42
    assert shots[0]["seed"] == 42


def test_shoot_plan_errors_and_json():
    sp = N.shoot_plan.ASB_ShootPlan()
    # JSON format works too
    plan = {
        "model": "sienna", "location": "spa_bathroom",
        "clothing_set": "towel_spa_set", "shots": [
            {"zone": "Bathtub Zone", "piece": "TB_01 | sitting_tub_edge",
             "outfit": "fully_worn"},
            {"zone": "Bathtub Zone", "piece": "TB_02 | in_tub",
             "transition": "advance: Bath Towel"},
        ],
    }
    pjson, count, story, *_ = sp.plan(json.dumps(plan), seed=5)
    report = None
    assert count == 2
    shots = json.loads(pjson)
    assert shots[1]["outfit"]["towel_01"] == "slipping"
    assert shots[1]["outfit_names"]["Bath Towel"] == "slipping"

    # unknown zone -> ERROR output
    bad = {"model": "sienna", "location": "spa_bathroom",
           "clothing_set": "towel_spa_set", "shots": [
               {"zone": "Nope Zone", "piece": "TB_01"}]}
    pjson, count, story, *_ = sp.plan(json.dumps(bad))
    report = story  # story holds ERROR
    assert count == 0 and "ERROR" in report and "unknown zone" in report

    # unknown item in transition -> that shot is skipped, the rest survive
    bad2 = {"model": "sienna", "location": "spa_bathroom",
            "clothing_set": "towel_spa_set", "shots": [
                {"zone": "Bathtub Zone", "piece": "TB_01", "outfit": "fully_worn"},
                {"zone": "Bathtub Zone", "piece": "TB_02", "transition": "advance: ???"}]}
    pj2, c2, _, _, r2, *_ = sp.plan(json.dumps(bad2))
    assert c2 == 1 and "unknown item" in r2 and "ERROR shot 1" in r2

    # empty plan -> clear guidance, not silent failure
    pj3, c3, _, _, r3, *_ = sp.plan("")
    assert c3 == 0 and "EMPTY PLAN" in r3 and "Apply" in r3


def test_shoot_plan_template_rerender():
    sp = N.shoot_plan.ASB_ShootPlan()
    plan = {
        "model": "liora", "location": "cozy_living",
        "clothing_set": "elegant_dress_set", "style": "custom", "quality": "default",
        "shots": [
            {"zone": "Window Zone", "piece": "Win_01 | standing_smile",
             "outfit": "fully_worn"},
            {"zone": "Sofa Zone", "piece": "Sofa_02 | reclining",
             "transition": "advance: Elegant Mini Dress"},
        ],
    }
    pjson, count, *_ = sp.plan(json.dumps(plan), template="cinematic")
    shots = json.loads(pjson)
    assert count == 2
    assert "cinematic composition" in shots[0]["final_prompt"]


def test_prompt_designer_templates():
    pd = N.prompt_designer.ASB_PromptDesigner()
    # template dropdown lists the shipped presets
    tpl_input = pd.INPUT_TYPES()["required"]["template"]
    names = tpl_input[0]
    assert "editorial" in names and "boudoir_sequence" in names and "cinematic" in names

    fp, neg, name = pd.design(
        template="editorial",
        model_prompt="Liora, 26", clothing_phrases="wearing dress",
        prompt_piece="standing", lighting="soft light",
        quality="8k", style="black and white",
        camera_technical="85mm f/1.8", level="level_2",
        negative_hints="extra person",
    )
    assert name == "editorial"
    assert "Liora, 26" in fp and "85mm f/1.8" in fp
    assert "color" in neg and "extra clothing" in neg and "extra person" in neg

    # minimalist template drops empty sections
    fp2, neg2, _ = pd.design(
        template="minimalist",
        model_prompt="M", clothing_phrases="", prompt_piece="",
        lighting="", quality="Q", style="custom", level="level_0")
    assert "M, Q" == fp2 or fp2.startswith("M")

    # custom yaml override
    fp3, neg3, name3 = pd.design(
        template="editorial", model_prompt="A", clothing_phrases="B",
        prompt_piece="C", lighting="", quality="Q", style="custom",
        custom_yaml="positive:\n  - \"{model_prompt} only\"\nnegative: []\njoiner: \", \"")
    assert fp3 == "A only" and name3 == "custom"


def test_batch_index_auto_run():
    bi = N.batch_index.ASB_BatchIndex()
    idx, done, total = bi.step(5, False, True)
    assert (idx, done, total) == (0, False, 5)
    seq = [bi.step(5, False, True)[0] for _ in range(5)]
    assert seq == [1, 2, 3, 4, 0]
    # auto_run param accepted and node input defined
    inputs = bi.INPUT_TYPES()
    assert "auto_run" in inputs.get("optional", {})


def test_shoot_plan_with_prompt_designer_pipeline():
    """Shoot plan -> Plan->Prompt -> feeds a prompt designer flow end to end."""
    sp = N.shoot_plan.ASB_ShootPlan()
    plan = {
        "model": "nova", "location": "penthouse_lounge",
        "clothing_set": "evening_gown_set", "style": "studio glam",
        "quality": "studio", "shots": [
            {"zone": "Glass Wall Zone", "piece": "PG_01 | standing_glass",
             "outfit": "fully_worn"},
            {"zone": "Lounge Sofa Zone", "piece": "PL_02 | reclining_lounge",
             "transition": "advance: Evening Gown"},
        ],
    }
    pjson, count, _, _, report, *_ = sp.plan(json.dumps(plan), seed=1)
    shots = json.loads(pjson)
    assert count == 2 and "ERROR" not in report
    shot0 = shots[0]
    pd = N.prompt_designer.ASB_PromptDesigner()
    fp, neg, _ = pd.design(
        template="boudoir_sequence",
        model_prompt=shot0["model_prompt"],
        clothing_phrases=shot0["clothing_phrases"],
        prompt_piece=shot0["piece"],
        lighting=shot0["lighting"],
        quality=shot0["quality"],
        style="studio glam",
        camera_technical=shot0["camera"],
        level=shot0["level"],
        index=shot0["index"], total=count,
        note=shot0["note"],
    )
    assert "shot 0 of 2" in fp
    assert "extra clothing, stray fabric, visible wardrobe malfunction" in neg


if __name__ == "__main__":
    import traceback
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"PASS  {t.__name__}")
        except Exception:
            failed += 1
            print(f"FAIL  {t.__name__}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
