# Fixes for MetArt-like photoset quality

## Critical bugs fixed

1. Restored missing utils/prompts.py (was only .pyc)
2. clothing_phrases no longer injects removed garments
3. Removed corrupt data/locations/classic_white_shirt.json
4. Stripped hardcoded nude from 61 pose pieces
5. Added metart natural style + quality + template

Use style=metart natural, quality=metart, template=metart_natural
