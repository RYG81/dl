# Artistic Set Builder — V1.0-F

**Status:** Stable checkpoint — keep this zip.

**Date:** 2026-08-21

## Why this version
User-marked “currently good one” before further experiments that may break behavior.
Roll back to this archive if later changes regress quality.

## Included at freeze
- Clothing DB: enriched states, exposure hints, short in_hand props, anti double-clothing
- Locations: R-series + K001–K085 zone-linked poses (krea_ref / krea_user)
- Zone tags; pose_family on pieces
- Planner: undress beats, clothing_phrases / off negatives, in_hand counts as off
- Widget + nodes as of freeze

## Restore
1. Remove broken custom node folder
2. Unpack this zip as the node pack
3. Restart ComfyUI
