# locations_tiera

Hand-crafted **Tier-A** location JSON only.

Currently:
- andalusian_terrace
- outdoor_garden_shower

As more locations are upgraded, copies are added here **and** written to `data/locations/` (production).
Machine versions remain in `data/locations_machine/`.
