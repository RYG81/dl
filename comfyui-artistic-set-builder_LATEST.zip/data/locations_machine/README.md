# locations_machine

Structured / generated location JSON for **every** location id (38 files).

- Do not use as production unless A/B testing.
- Production path: `data/locations/`
- Tier-A hand path: `data/locations_tiera/`

Compare: same id in `locations` (or `locations_tiera`) vs `locations_machine`.
