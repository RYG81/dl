# Test plans

Load these in **ASB Shoot Plan** (plan dropdown or paste YAML).

| Plan | Model | Location | Outfit | Shots | Purpose |
|------|-------|----------|--------|-------|---------|
| `test_01_quick_smoke` | Liora | Soft Window Bedroom | Beige knit + shorts | 12 | Fast check: clothes vanish when removed |
| `test_02_full_progressive` | Liora | Soft Window Bedroom | Beige knit + shorts | ~49 | Full MetArt undress rhythm |
| `test_03_amara_lingerie` | Amara | Soft Window Bedroom | Black sheer lingerie | 12 | Dark skin + lingerie path |
| `test_04_jade_living_bikini` | Jade | Soft Window Living | Bikini set | 12 | Living room + swimwear |
| `test_05_clara_white_lace` | Clara | Soft Window Bedroom | White lace romantic | 12 | Robe → bra → nude |

## Settings
- style: `metart natural` (or as in YAML)
- quality: `metart`
- detail: `detailed`

## What to verify
1. Early shots show full outfit in positive prompt
2. Mid shots show only remaining garments
3. Final nude shots: **no** crop top / bra / panties / bikini text in positive prompt
4. Expressions and camera lines still present
