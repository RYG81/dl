# ASB Developer & Extension Guide

**A plain-English, step-by-step guide to extending the Artistic Set Builder
ComfyUI pack — written for people who do NOT write code.**

If you can edit a text file and copy/paste, you can extend this pack. This
guide tells you exactly which files to touch, what to write, and what to do
afterwards so your changes show up.

---

## 1. Big picture — what is this pack, really?

The pack is a **factory for photo-shoot prompts**. You give it:

- **Models** (who is in the photo),
- **Locations** (where the photo is shot, with "zones" = spots in the room and
  "poses" per zone),
- **Clothing sets** (what she wears, with every "state" a garment can be in),
- **Cameras** (the real camera body),
- **Framing** (how the shot is composed: close-up, low angle, etc.),
- **Style + quality** (the overall look).

The nodes then combine these into full prompts, and can generate whole sets of
100–200+ consistent images.

**The most important idea:** all of the content lives in **JSON / YAML text
files** inside the `data/` folder. **You never touch Python code to add
content.** You only touch code if you want to add *brand-new kinds of nodes*.

---

## 1.5 Use your BIG database from anywhere (external data folders)

By default the pack reads only from its own `data/` folder. If you keep a
large database elsewhere (more locations/models/sets than the pack ships),
point the pack at it — three ways, they combine:

1. **`data/config.json`** → `extra_data_dirs: ["C:/Your/Database", "/home/you/asb_data"]`.
   Each entry is a **root folder** with `models/`, `locations/`, `clothing/`,
   `cameras/`, `framing/` subfolders (exactly the same layout as `data/`).
2. **Environment variable** `ASB_DATA_DIRS=/your/folder:/another`.
3. Drop files straight into this pack's `data/` subfolders.

The pack **merges** everything — pack data plus every extra folder — with pack
data winning on name conflicts. Nothing is hardcoded; every dropdown is built
from the merged list. To see exactly what the pack sees:

```
python scripts/data_report.py     # counts + source of every item
python scripts/validate.py        # validates pack + extras
python scripts/export_planner_data.py   # refresh the editor data
```

Then restart ComfyUI (or use the editor's **↻ Refresh data** button).

## 2. The folder map (what lives where)

```
comfyui-artistic-set-builder/        ← the whole pack (copy this into ComfyUI/custom_nodes/)
├── __init__.py                      ← "registration desk": tells ComfyUI which nodes exist (advanced)
├── README.md                        ← quick start
├── data/                            ← ★ ALL YOUR CONTENT LIVES HERE
│   ├── models/          *.json      ← one file per model
│   ├── locations/       *.json      ← one file per location (rooms, with zones + poses)
│   ├── clothing/        *.json      ← one file per clothing set (items + states)
│   ├── cameras.json                ← camera list (or use data/cameras/ folder)
│   ├── cameras/         *.json      ← one camera per file (optional, same effect)
│   ├── framing.json                ← framing/angle list (or use data/framing/ folder)
│   ├── framing/         *.json      ← one framing per file (optional)
│   ├── plans/           *.yaml      ← ready-made full shoot plans
│   └── templates/       *.yaml      ← prompt "structures" (editorial, cinematic…)
├── nodes/              *.py         ← the node logic (advanced — normally untouched)
├── utils/              *.py         ← the engine (advanced — normally untouched)
├── scripts/            *.py         ← helper tools you run from a terminal
├── web/                             ← the on-screen editor inside the node
│   ├── planner_widget.js            ← the big editor UI inside the node
│   ├── artistic_set_builder.js      ← dropdown automation
│   ├── planner.html                 ← standalone plan designer page
│   └── planner_data.json            ← ★ auto-generated copy of your data for the editor
├── examples/           *.json/yaml  ← sample workflows + a sample 200-shot plan
├── tests/              *.py         ← automated checks (advanced)
└── docs/                            ← this guide + the AI system prompt
```

> ⚠️ **The #1 rule:** after you edit anything in `data/`, run
> `python scripts/export_planner_data.py` and **restart ComfyUI** (or at least
> refresh the browser). Otherwise the on-screen editor still shows old data.

---

## 3. PART A — Add content WITHOUT writing any code

All examples below are **copy-paste-able**. Just make a new file (or edit an
existing one), save it, run the export script, restart.

### 3.1 Add a NEW MODEL

1. Go to `data/models/`.
2. Create a file called e.g. `your_model_name.json` (lowercase, no spaces;
   use `_` instead of spaces).
3. Paste this template and fill it in:

```json
{
  "id": "M20",
  "name": "Your Model Name",
  "age": 25,
  "ethnicity": "European",
  "body_type": "slender with soft curves",
  "height": "average",
  "hair": { "color": "dark brown", "length": "long", "style": "wavy", "parting": "center" },
  "face": { "shape": "oval", "eyes": "expressive brown", "smile": "bright cheerful", "freckles": "light across nose and cheeks", "makeup": "natural" },
  "skin": { "tone": "fair", "texture": "natural smooth" },
  "overall_vibe": "cute, glamorous, playful and smiling"
}
```

**Field cheat-sheet:**

| Field | What it is | Required? |
|---|---|---|
| `name` | shows in prompts | yes |
| `age` | number | yes |
| `body_type` | build | yes |
| `hair` / `face` / `skin` | description blocks | yes (blocks) |
| `overall_vibe` | the mood line | yes |
| `ethnicity`, `height` | extra info | optional |
| `breasts`, `pussy`, `ass` | body-detail blocks, used when the model loader is set to **detailed** | optional |
| `identity_token` | a short stable token for LoRA-style identity | optional |
| `prompt_model_description` | **phase-wise model wording** (see below) | optional |

**Phase-wise model description (recommended for richer shoots):** add a
`prompt_model_description` block to the model file — five short descriptions,
one per undress phase. The engine automatically uses the phase matching each
shot's level, so the model's wording evolves as the shoot progresses:

```json
"prompt_model_description": {
  "phase_1": "gorgeous in a flowing dress, full glam",   // level_0 (fully dressed)
  "phase_2": "playful, dress slipping",                  // level_1
  "phase_3": "seductive, lingerie",                      // level_2
  "phase_4": "confident, mostly bare",                   // level_3
  "phase_5": "powerfully nude, radiant skin"             // level_4 (fully undressed)
}
```

Phase text is inserted verbatim (prefixed with the model name for identity).
Empty phase entries fall back to the normal assembled description, so you can
fill in only the phases you care about. Models without the block are unchanged.

> Tip: copy `data/models/liora.json` and edit it — it's a perfect reference.

4. Run the export + restart (see §2 warning).

### 3.2 Add a NEW LOCATION (a room, with zones + poses)

A location has **zones** (spots: "Window Zone", "Sofa Zone") and each zone has
**prompt pieces** (poses). This is the file that grows your shot variety.

1. Create `data/locations/your_place.json`.
2. Template:

```json
{
  "id": "Loc_10",
  "name": "Your Place",
  "overall_description": "Bright elegant room, soft neutral tones, large windows",
  "lighting": "soft natural daylight mixed with warm ambient light",
  "photo_zones": [
    {
      "zone_id": "Z_Window",
      "name": "Window Zone",
      "description": "Large window with sheer curtains",
      "prompt_pieces": [
        {
          "id": "Win_01",
          "type": "standing_smile",
          "prompt": "standing near the window, body slightly turned, bright smile, medium shot, eye-level, soft backlight",
          "compatible_clothing_levels": ["level_0", "level_1", "level_2", "level_3", "level_4"]
        },
        {
          "id": "Win_02",
          "type": "silhouette",
          "prompt": "standing in front of large window, soft silhouette against bright light",
          "compatible_clothing_levels": ["level_2", "level_3", "level_4"]
        }
      ]
    }
  ]
}
```

**Field cheat-sheet:**

| Field | What it is | Notes |
|---|---|---|
| `zone_id` | machine id of the zone | keep unique per location, e.g. `Z_` + name |
| `name` | shown in dropdowns | |
| `prompt_pieces[].id` | machine id of the pose | unique per zone, e.g. `Win_01` |
| `prompt_pieces[].type` | short pose type | used for auto-framing |
| `prompt_pieces[].prompt` | the actual pose words | this is what goes into the image prompt |
| `prompt_pieces[].compatible_clothing_levels` | which undress levels this pose works with | `level_0` = fully dressed … `level_4` = fully undressed |

**What the levels mean (default):**
- `level_0` fully dressed
- `level_1` one item removed
- `level_2` more removed
- `level_3` mostly undressed
- `level_4` fully undressed

A pose like "silhouette at window" works at high levels; a pose like
"elegant standing smile" works at all levels. If you list a level that isn't
physically sensible for a pose, the engine just warns you.

3. Export + restart.

### 3.3 Add a NEW CLOTHING SET (garments + their states)

This is the heart of the "undressing sequence". Each **item** has an ordered
list of **states** (e.g. dress: `fully_worn` → `slipped_off_shoulders` →
`partially_open` → `removed`). The engine advances items one state at a time.

1. Create `data/clothing/your_set.json`.
2. Template:

```json
{
  "name": "Your Set",
  "items": [
    {
      "item_id": "dress_01",
      "name": "Elegant Mini Dress",
      "category": "dress",
      "states": [
        { "state_id": "fully_worn",            "prompt_phrase": "wearing elegant mini dress" },
        { "state_id": "slipped_off_shoulders", "prompt_phrase": "dress slipped off shoulders" },
        { "state_id": "partially_open",        "prompt_phrase": "dress partially open" },
        { "state_id": "removed",               "prompt_phrase": "no dress" }
      ]
    },
    {
      "item_id": "briefs_01",
      "name": "Black Briefs",
      "category": "lingerie_bottom",
      "states": [
        { "state_id": "fully_worn",   "prompt_phrase": "wearing black panties" },
        { "state_id": "pulled_aside", "prompt_phrase": "panties pulled aside" },
        { "state_id": "removed",      "prompt_phrase": "no panties" }
      ]
    }
  ]
}
```

**Rules:**
- The **first state** should be `fully_worn` (all on), the **last state**
  should be `removed` (off). States in between are the "steps".
- `prompt_phrase` is what actually appears in the image prompt.
- The state id `removed` is what the engine counts toward the level — and
  `no panties`, `no bra`, `barefoot`, etc. also count (see `removed_states`
  below).

**Advanced: control how levels are computed** (optional `level_config` block):

```json
{
  "name": "Your Set",
  "level_config": {
    "removed_states": ["removed", "no panties", "no bra", "barefoot"],
    "thresholds":     [0, 1, 2, 3, 4],
    "level_names":    ["fully dressed", "partially undressed", "undressed", "mostly nude", "fully nude"]
  },
  "items": [ ... ]
}
```

3. Export + restart.

### 3.4 Add a NEW CAMERA (two ways — both work)

**Way 1 — flat file:** edit `data/cameras.json`, add an entry to the
`"cameras"` list:

```json
{
  "id": "canon_r5",
  "brand": "Canon",
  "model": "EOS R5",
  "lens": "RF 85mm f/1.8",
  "sensor": "full frame 45MP",
  "tech": "Canon EOS R5, RF 85mm f/1.8 lens, full frame sensor, 45 megapixels"
}
```

`id` is what you reference in plans; `tech` is what lands in the prompt.

**Way 2 — one file per camera (folder):** create
`data/cameras/my_camera.json` containing just the object above (with an `id`).
Both flat + folder are merged automatically.

### 3.5 Add a NEW FRAMING (angle / coverage / view)

Same two ways. Edit `data/framing.json` (`"framing"` list) or add
`data/framing/*.json`:

```json
{
  "id": "dutch_angle",
  "name": "Dutch angle",
  "tech": "dutch angle, tilted horizon, dynamic tension",
  "default_for_piece_types": []
}
```

> 💡 `default_for_piece_types` is how the editor auto-picks framing for a pose.
> List pose `type`s here (e.g. `"close_portrait"`) to auto-suggest this framing
> for those poses.

### 3.6 Add a NEW prompt template (the "structure" of the prompt)

Templates live in `data/templates/` and appear in the **ASB Prompt Designer**
dropdown. A template is just an ordered list of "sections" with placeholders:

```yaml
name: my_look
description: My custom structure
joiner: ", "
positive:
  - "{model_prompt}"
  - "{clothing_phrases}"
  - "{prompt_piece}"
  - "{lighting}"
  - "{quality}"
  - "{camera_technical}"
negative:
  - "{level_negative}"
  - "{negative_hints}"
```

**Available placeholders** (use them in the `positive:`/`negative:` lists):

| Placeholder | Fills with |
|---|---|
| `{model_prompt}` | the model's description |
| `{clothing_phrases}` | the current outfit states |
| `{prompt_piece}` | the pose prompt |
| `{zone_description}` | the zone description |
| `{lighting}` | the location lighting |
| `{style_positive}` / `{style_negative}` | style preset words |
| `{quality}` | the quality string |
| `{camera_technical}` | camera + framing tech |
| `{level_negative}` | auto "no extra clothing" negatives at high levels |
| `{negative_hints}` | your extra negative words |
| `{index}` `{total}` `{seed}` `{note}` `{title}` | per-shot values |

Empty sections are skipped automatically, so you can leave inputs unwired.

### 3.7 Add a NEW ready-made plan (a whole shoot you can load)

1. Create `data/plans/my_shoot.yaml` (or just save any plan file anywhere).
2. The format is exactly what the **ASB Shoot Plan** node accepts — see
   **Part B** below.
3. Load it via the editor: **📂 Load file** or **☁️ Server → Load**, or paste
   into the node → **⟳ Load from plan** → **✓ Apply to node**.

---

## 4. PART B — The plan format (what "ASB Shoot Plan" reads)

A plan is a plain-text **YAML** file (YAML is just "text with colons and
indentation"). Here is a complete example with every feature:

```yaml
title: "Liora — Elegant Undress Story"     # shoot name
model: liora                                # file name from data/models/
location: cozy_living                       # file name from data/locations/
clothing_set: elegant_dress_set             # file name from data/clothing/
style: soft boudoir                         # from the style dropdown
quality: film                               # from the quality dropdown
camera: canon_r5                            # id from the camera list (one for the whole shoot)
seed: 42                                    # number — same seed = same result
shots:                                      # ← the shot list starts here
  - zone: Z_Window                          #   a shot: use ids, not names
    piece: Win_01                           #   pose id
    framing: medium                         #   optional framing id (or omit for auto)
    outfit: fully_worn                      #   "fully_worn", "removed", or a map (below)
    note: "opening shot, warm"              #   optional director's note
  - zone: Z_Sofa
    piece: Sofa_02
    framing: intimate
    transition: "advance: dress_01"         #   ← wardrobe instruction (see below)
    note: "dress slipping"
  - zone: Z_Floor
    piece: Floor_03
    outfit:                                 #   explicit per-item map
      bra_01: removed
      briefs_01: fully_worn
    framing: rear
    note: "the reveal"
```

### 4.1 Use IDs, not names

In a plan you always use **machine ids** (from the data files): `Z_Window`
(not "Window Zone"), `Win_01` (not "Win_01 | standing_smile"), `dress_01`
(not "Elegant Mini Dress"). The engine turns ids into the real prompt words
for you. (Names *also* work as a fallback, but ids are the reliable way.)

### 4.2 The wardrobe instructions (transitions) — cheat-sheet

Each shot can carry ONE outfit instruction, applied to the previous shot's
outfit:

| Instruction | Meaning | Example |
|---|---|---|
| `outfit: fully_worn` | everything on | `outfit: fully_worn` |
| `outfit: removed` | everything off | `outfit: removed` |
| `outfit: {item_id: state, ...}` | exact per-item map | `outfit: {bra_01: straps_down}` |
| `transition: "advance: <item>"` | move one item one step forward | `transition: "advance: dress_01"` |
| `transition: "remove: <item>"` | take an item straight off | `transition: "remove: bra_01"` |
| `transition: "dress: <item>"` | put an item back one step | `transition: "dress: briefs_01"` |
| `transition: "set: <item> -> <state>"` | jump to an exact state | `transition: "set: bra_01 -> cups_pulled_down"` |
| `transition: "sequence: <item>"` | auto-step this item each shot | `transition: "sequence: dress_01"` |
| `transition: "reset"` | everything on again | `transition: "reset"` |

If a shot has **no** outfit/transition, it simply keeps the previous outfit
("inherit").

### 4.3 The undress narrative (the pro way to write 200 shots)

For a perfect set:
1. Shot 0 → `outfit: fully_worn`
2. Then advance ONE item per shot, cycling items: `advance: dress_01`,
   `advance: bra_01`, `advance: briefs_01`, …
3. Use `remove: <item>` to finish an item, `set:` to jump, `dress:` to re-wear
   for variety, `reset` to start a new cycle.
4. By roughly shot 60–80 everything is off → keep shooting all-off with varied
   zones/poses/framing, occasionally re-wearing an item.
5. Keep the piece compatible with the level — a pose lists its compatible
   levels in the location file.

---

## 5. PART C — The helper scripts (run from a terminal)

Open a terminal in the pack folder (`comfyui-artistic-set-builder/`). You need
**Python** installed (it comes with ComfyUI).

| Command | What it does | When to run |
|---|---|---|
| `python scripts/export_planner_data.py` | refreshes `web/planner_data.json` (the editor's copy of your data) | **after EVERY data edit** |
| `python scripts/validate.py` | checks all data files for mistakes, lists problems | after editing data (before a big shoot) |
| `python scripts/verify_plan.py my_plan.yaml` | checks a plan file will load in the node | before pasting an AI/hand-made plan |
| `python scripts/make_plan_prompt.py --model liora --location cozy_living --clothing elegant_dress_set --count 200 --out ai_prompt.txt` | builds the AI system prompt for a combo | when you want an AI to write you a 200-shot plan |
| `python scripts/generate_manifest.py --model liora --location cozy_living --clothing elegant_dress_set --mode level --out out/` | writes `prompts.csv` + caption files for a whole set, no ComfyUI needed | bulk offline generation |

**Example flow for a big shoot:**

```
1. python scripts/export_planner_data.py      # after editing data
2. python scripts/validate.py                 # "All data files OK" = good
3. python scripts/make_plan_prompt.py ...     # get AI prompt
4. (paste to AI, save its answer as plan.yaml)
5. python scripts/verify_plan.py plan.yaml    # "LOADABLE ✓ 200 shots"
6. open ComfyUI → ASB Shoot Plan → 📂 Load file → plan.yaml → ✓ Apply → run
```

---

## 6. PART D — How the nodes fit together (the two pipelines)

### Pipeline 1 — the manual chain (single art-directed shots)

```
ASB Load Model → model_prompt
ASB Load Location → location, lighting
ASB Select Zone → zone (dropdown from location)
ASB Select Prompt Piece → piece prompt + camera/framing
ASB Load Clothing → clothing
ASB Advance Clothing / ASB Set Item State → outfit changes
ASB Build Final Prompt → final prompt + negative
```

### Pipeline 2 — the shoot/batch path (whole sets)

```
ASB Shoot Plan  → plan_json, count, storyboard, shot_prompt/negative/seed
   (built-in editor: design shots, Auto N, Apply, server preview)
   use_internal_counter = ON → each run serves the next shot
ASB Set Plan    → full enumeration (level / random / exhaustive modes)
ASB Manifest    → logs every generated prompt to CSV/JSON
```

---

## 7. PART E — The editor files (what they do, in plain words)

| File | What it does | When you'd touch it |
|---|---|---|
| `web/planner_widget.js` | the whole editor UI inside the ASB Shoot Plan node (shot cards, toolbar, preview, server panel) | only for deep UI changes (not needed to add content) |
| `web/artistic_set_builder.js` | makes nested dropdowns fill from the connected node | only if adding new dropdown nodes |
| `web/planner.html` | the standalone plan-design web page (open via `/extensions/comfyui-artistic-set-builder/planner.html`) | same |
| `web/planner_data.json` | auto-generated snapshot of your data for the editor | **never edit by hand** — run the export script |

---

## 8. PART F — The engine files (advanced — normally untouched)

| File | What it is |
|---|---|
| `utils/database.py` | loads all data files; where cameras/framing folder support lives |
| `utils/shoot_plan.py` | expands a plan into per-shot prompts (the "director" engine) |
| `utils/planner.py` | the Set Plan enumeration engine (level/random/exhaustive) |
| `utils/prompts.py` | prompt assembly + style/quality presets |
| `utils/prompt_templates.py` | loads YAML templates + placeholders |
| `utils/levels.py` | the data-driven level system |
| `utils/manifest.py` | CSV/JSON export formatting |
| `utils/plan_storage.py` | server-side plan files (ComfyUI/user/asb_plans/) |
| `utils/validate.py` | the data checker used by validate.py |
| `nodes/*.py` | one file per node — the node's inputs/outputs/logic |

> 💡 **The one engine change you might want:** style presets and quality
> presets are *not* data files — they're defined in `utils/prompts.py`
> (`STYLE_PRESETS`, `QUALITY_PRESETS`). If you want a new style or quality
> preset, that's a 3-line edit there (add a dict entry). It's the single most
> common "code" edit and it's very safe. After editing, restart ComfyUI.

---

## 9. PART G — Adding a brand-new node (when you're ready to try code)

This is the "graduation" section. It's a simple recipe — you don't need to
understand Python deeply, just copy the shape.

**Step 1 — create the node file.** Make `nodes/my_node.py`:

```python
# A minimal ASB-style node.
# Inputs are declared in INPUT_TYPES; outputs in RETURN_TYPES.
# The FUNCTION name must match a method on the class.

class ASB_MyNode:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "text": ("STRING", {"default": "hello", "multiline": True}),
            },
            "optional": {
                "amount": ("INT", {"default": 3, "min": 1, "max": 100}),
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("out_text",)
    FUNCTION = "run"
    CATEGORY = "ArtisticSetBuilder/My Stuff"

    def run(self, text, amount=3):
        return (text * amount,)
```

**Step 2 — register it.** Open `__init__.py`. At the top add:

```python
from .nodes.my_node import ASB_MyNode
```

Then add two lines inside the big dicts — one in `NODE_CLASS_MAPPINGS`:

```python
    "ASB_MyNode": ASB_MyNode,
```

and one in `NODE_DISPLAY_NAME_MAPPINGS`:

```python
    "ASB_MyNode": "ASB My Node",
```

**Step 3 — restart ComfyUI.** Your node appears under **ArtisticSetBuilder /
My Stuff**.

**Step 4 (optional) — make a dropdown fill from an upstream node.** In
`web/artistic_set_builder.js`, add an entry to the `SPECS` object:

```javascript
ASB_MyNode: {
  input: "text",                 // the input that is connected upstream
  objectName: "some_output",     // upstream output holding a dict
  listName: "some_list_output",  // upstream output holding "a | b | c"
  widget: "text",                // the widget to turn into a dropdown
  extract: (obj) => Array.isArray(obj && obj.items)
      ? obj.items.map(x => x.name).filter(Boolean) : null,
},
```

---

## 10. PART H — Troubleshooting (the things that actually go wrong)

| Symptom | Cause | Fix |
|---|---|---|
| Dropdowns are plain text / empty | old JS cached in the browser | **hard refresh** (Ctrl/Cmd+Shift+R); run the graph once so upstream outputs exist |
| New data (model/location/…) doesn't appear | editor reads `planner_data.json` | run `python scripts/export_planner_data.py`, then restart ComfyUI |
| `plan_json`/`count` empty after running | plan box was empty at run time, OR a shot is invalid | check the ComfyUI server console for `[ASB] ShootPlan:` — `EMPTY PLAN` means paste/Apply first; `ERROR shot N:` means fix that shot (others still load) |
| "Apply to node" doesn't change output | outputs only refresh on RUN | Apply writes the plan; press Queue/Run afterwards |
| Saved plan loads with blank zones | old buggy saves | load it once — the editor auto-heals blank zones to the first zone and warns you to verify |
| Plan won't load | bad id (typo) somewhere | run `python scripts/verify_plan.py plan.yaml` — it names the exact shot + reason |
| Server panel says API unavailable | page opened outside ComfyUI, or old server | make sure you're loading via ComfyUI and restart after installing |
| Levels "wrong" | piece not marked for that level | check `compatible_clothing_levels` in the location file |

---

## 10.4b One location + one outfit per set (consistency rule)

**A photo set is ALWAYS one location + one clothing set.** Never mix two
locations or two outfits in the same set — that's what makes a gallery look
consistent. The engine has **no** per-shot `location` / `clothing_set`
overrides (any stray keys in a plan are ignored; the plan-level values win).

To utilize your whole database, generate **one set per combo** — change the
**Location** and **Clothing Set** dropdowns and click Auto N again (each combo
produces its own consistent set). The offline `generate_manifest.py` does this
for you automatically across every combo (`--mode level` = one canonical set
per combo).

Within a set, Auto N fully utilizes the selected data:
- **all zones** of the selected location are cycled and **reused** — each
  revisit has a progressed outfit state, so a 500-shot set in a 5-zone location
  uses each zone ~100 times without repeating (zone, pose, outfit),
- **all poses** per zone rotate (chosen for each shot's level),
- **every item** of the selected clothing set advances through its states,
- the sequence is **strictly linear all→none**: shot 0 fully dressed, the
  outfit advances one item-state at a time spread across the whole set, ending
  all-off (verified monotonic 0→4),
- **no shot-count limit** — `auto_shots` accepts up to 1,000,000,
- `gallery_mode`: `undress narrative` (default, linear all→none) or
  `MetArt gallery` (dress/undress arc then mostly artistic nude).

## 10.4 The `prompt` / `prompt_phrase` fields ARE the wording

This is the single most important thing to understand when writing data:

- **Locations:** each `prompt_pieces[]` entry's **`prompt`** field is the exact
  text that goes into the image prompt for that pose. The engine uses it
  **verbatim** — it never fabricates pose wording. Write the pose description
  you want to see in the image right there.
- **Clothing:** each item's `states[]` entry has a **`prompt_phrase`** — the
  exact text used when that garment is in that state ("wearing black panties",
  "no panties", "bra straps down", …). Same rule: verbatim, no inventing.
- The final image prompt is built by joining: model description + the current
  `prompt_phrase` of every garment + the piece's `prompt` + lighting + style +
  quality + camera/framing tech.

Proof: the editor now **shows the resolved wording inside every shot card**
(a "prompt:" line = piece `prompt` + the clothing `prompt_phrase` for that
shot's outfit), and the expanded preview/storyboard use the same server engine
that produces the real prompts. What you see there is exactly what the sampler
will receive.

## 10.5 The pack is fully data-driven (no hardcoded ids)

Nothing in the code assumes a specific model / location / clothing / camera
exists. Everything adapts to **your** `data/` folders:

- **All dropdowns** are built from whatever JSON files are present.
- **The Sample button** builds a sample plan from the *first available*
  model / location / clothing / camera — never a fixed id — so it always works
  with your data.
- **`python scripts/export_planner_data.py`** also writes
  `examples/sample_plan_from_data.yaml` — a small, loadable plan built from your
  data, regenerated every time you run it.
- **Script defaults** (`make_plan_prompt.py`, `generate_manifest.py`) use the
  first available entries: `python scripts/make_plan_prompt.py --count 200`
  just works with no arguments.
- **Missing ids are surfaced, not silent**: if you load a plan that references a
  model/location/clothing/camera you don't have, the editor warns
  ("⚠ not in current data: …") and the engine reports per-shot errors
  (`ERROR shot N: …`) while still loading the valid shots.

So: drop any number of files into `data/models/`, `data/locations/`,
`data/clothing/`, `data/cameras/`, `data/framing/`, run the export script, and
the whole pack (editor, dropdowns, samples, AI prompt, scripts) adapts.

## 11. Glossary (plain English)

| Term | Meaning |
|---|---|
| **Node** | a building block in ComfyUI's graph (a box with inputs/outputs) |
| **Workflow** | the saved graph of connected nodes (a `.json` file) |
| **Prompt** | the text that tells the image model what to draw |
| **Negative prompt** | what the model should NOT draw |
| **JSON** | a text format with `{ "key": "value" }` — used for data files |
| **YAML** | a text format with `key: value` lines — used for plans/templates |
| **Zone** | a spot inside a location (Window Zone, Sofa Zone) |
| **Piece** | a pose within a zone |
| **Item** | one garment in a clothing set |
| **State** | a step a garment can be in (`fully_worn` → … → `removed`) |
| **Level** | overall undress level of the outfit (`level_0` … `level_4`) |
| **Transition** | the wardrobe instruction between shots |
| **Seed** | a number that makes generation repeatable (same seed = same image) |
| **Manifest** | a log/export of everything generated (CSV/JSON/captions) |
| **Placeholder** | `{like_this}` — a slot a template fills with real text |

---

*Remember the golden workflow: **edit data → export_planner_data.py → restart
ComfyUI → validate → verify plans → shoot.** Everything in this pack is
designed so a non-coder can grow it one file at a time.*
