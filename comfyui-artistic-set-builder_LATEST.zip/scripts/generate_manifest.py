#!/usr/bin/env python3
"""
Generate a full image-set manifest offline (no ComfyUI needed).

For every (model, location, clothing set) in the requested combo, builds a
deterministic plan and writes:

    out/prompts.csv          one row per image
    out/manifest.json        same data, JSON
    out/captions/xxx.txt     per-image caption files (SD-style, with negatives)

Modes:
  level       (default) one canonical clothing combo per (piece, level)
  exhaustive  every item-state combination per piece (use --cap to limit)
  random      seeded random sample of --count images

Examples:
    # defaults: every model/location/clothing in your data/ (or pass any ids you have)
    python scripts/generate_manifest.py --mode level --out out/all

    python scripts/generate_manifest.py --mode random --count 200 \
        --seed 7 --min-level 2 --max-level 4 --out out/random200
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils import manifest as mf  # noqa: E402
from utils.database import get_clothing_list, get_location_list, get_model_list  # noqa: E402
from utils.planner import build_plan, renumber, to_manifest_entries  # noqa: E402
from utils.prompts import QUALITY_PRESETS  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description="Generate ASB image-set manifests")
    ap.add_argument("--model", action="append", default=[], help="model file name (repeatable)")
    ap.add_argument("--location", action="append", default=[], help="location file name (repeatable)")
    ap.add_argument("--clothing", action="append", default=[], help="clothing set file name (repeatable)")
    ap.add_argument("--all", action="store_true", help="use every model/location/clothing set")
    ap.add_argument("--mode", choices=["level", "exhaustive", "random"], default="level")
    ap.add_argument("--count", type=int, default=200, help="random mode sample size")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--min-level", type=int, default=0, choices=[0, 1, 2, 3, 4])
    ap.add_argument("--max-level", type=int, default=4, choices=[0, 1, 2, 3, 4])
    ap.add_argument("--cap", type=int, default=2000, help="exhaustive mode cap per piece")
    ap.add_argument("--detail", choices=["standard", "detailed", "minimal"], default="standard")
    ap.add_argument("--style", choices=["custom", "natural editorial", "studio glam",
                                        "black and white", "soft boudoir",
                                        "golden hour outdoor", "night neon"],
                    default="custom")
    ap.add_argument("--quality", choices=list(QUALITY_PRESETS.keys()), default="default")
    ap.add_argument("--out", default="out", help="output directory")
    args = ap.parse_args()

    if args.all:
        models, locs, cloths = get_model_list(), get_location_list(), get_clothing_list()
    else:
        models = args.model or get_model_list()
        locs = args.location or get_location_list()
        cloths = args.clothing or get_clothing_list()

    entries = []
    for mn in models:
        for ln in locs:
            for cn in cloths:
                plan = build_plan(
                    mn, ln, cn, mode=args.mode, seed=args.seed, count=args.count,
                    min_level=args.min_level, max_level=args.max_level, cap=args.cap,
                    detail=args.detail, style=args.style, quality=args.quality,
                )
                if plan:
                    entries.extend(plan)
                else:
                    print(f"[warn] nothing generated for {mn} x {ln} x {cn}",
                          file=sys.stderr)

    if not entries:
        print("No images generated — check your --model/--location/--clothing names.",
              file=sys.stderr)
        return 1

    renumber(entries, args.seed)
    mans = to_manifest_entries(entries)

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "prompts.csv"), "w", encoding="utf-8") as f:
        f.write(mf.to_csv(mans))
    with open(os.path.join(args.out, "manifest.json"), "w", encoding="utf-8") as f:
        f.write(mf.to_json(mans))
    mf.caption_files(mans, os.path.join(args.out, "captions"))

    print(f"Wrote {len(entries)} images to {args.out}/")
    print("  prompts.csv | manifest.json | captions/*.txt")
    return 0


if __name__ == "__main__":
    sys.exit(main())
