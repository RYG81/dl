#!/usr/bin/env python3
"""
Validate every JSON file in data/.

Usage:
    python scripts/validate.py
    python scripts/validate.py --json

Exit code 0 = all good, 1 = at least one error.
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.validate import validate_all, format_report  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description="Validate ASB data files")
    ap.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    args = ap.parse_args()

    issues = validate_all()
    errors = sum(1 for i in issues if i["level"] == "error")

    if args.json:
        print(json.dumps({"issues": issues, "error_count": errors}, indent=2))
    else:
        print(format_report(issues))

    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
