#!/usr/bin/env python3
"""
Show what the pack actually sees — counts per category from the pack's own
data/ folder PLUS any external data folders you've configured (data/config.json
or the ASB_DATA_DIRS env var). Run this if a dropdown looks short:

    python scripts/data_report.py

It lists every location / model / clothing set / camera / framing the nodes
will show, and where each came from (pack data vs external folder).
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils import database as db  # noqa: E402


def report():
    extras = db.extra_dirs()
    print("PACK DATA DIR :", db.DATA_DIR)
    if extras:
        print("EXTRA DATA DIRS:")
        for d in extras:
            print("  -", d)
    else:
        print("EXTRA DATA DIRS: (none — only the pack's own data/ is used)")
    print()

    cats = [
        ("models", "MODELS"),
        ("locations", "LOCATIONS"),
        ("clothing", "CLOTHING SETS"),
        ("cameras", "CAMERAS"),
        ("framing", "FRAMING"),
    ]
    for sub, label in cats:
        names = db.list_json_files(sub)
        print(f"{label}: {len(names)}")
        for n in names:
            # find which root it came from
            src = "pack"
            for d in extras:
                if os.path.isfile(os.path.join(d, sub, n + ".json")):
                    src = d
            print(f"    {n:<40s} ({src})")
        print()

    print("How to add more data:")
    print("  Option A: drop files into", db.DATA_DIR, "/<category>/")
    print("  Option B: edit data/config.json -> extra_data_dirs: [\"/your/folder\"]")
    print("  Option C: set env ASB_DATA_DIRS=/your/folder1:/your/folder2")
    print("  Then run: python scripts/export_planner_data.py  (and restart ComfyUI)")


if __name__ == "__main__":
    report()
