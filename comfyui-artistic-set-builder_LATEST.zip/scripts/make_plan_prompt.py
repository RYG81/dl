#!/usr/bin/env python3
"""
Assemble a SYSTEM PROMPT that makes an AI (ChatGPT / Claude / Gemini / Grok)
generate a full, consistent ASB shoot plan (up to 200+ prompts) from a small
JSON config, in the exact format the ASB_ShootPlan node loads.

Usage:
    # tailored prompt for one combo (prints to stdout):
    # defaults are the FIRST available model/location/clothing in your data/
    python scripts/make_plan_prompt.py --count 200

    # write it to a file:
    # or pick a specific combo by name (any ids you have):
    python scripts/make_plan_prompt.py --model <model> --location <location> \
        --clothing <clothing_set> --out ai_prompt.txt

    # regenerate the full reference doc (all data) in docs/:
    python scripts/make_plan_prompt.py --doc

The output prompt embeds:
  * the JSON input the AI must follow,
  * a DATA REFERENCE of the real ids (zones/pieces/items/states/cameras/framing)
    filtered to your selection (so the AI never invents ids),
  * the exact YAML output schema the node accepts,
  * consistency + undress-narrative rules for a perfect photo set.

Run scripts/verify_plan.py on the AI's output before loading it into the node.
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.database import (  # noqa: E402
    first_camera, first_clothing, first_location, first_model,
    get_clothing_list, get_location_list, get_model_list, load_cameras,
    load_framing, load_json,
)

ALL_LEVELS = ["level_0", "level_1", "level_2", "level_3", "level_4"]
DOC_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "docs", "AI_PLAN_SYSTEM_PROMPT.md")


def build_data_reference(models=None, locations=None, clothing=None):
    """Compact text of the real ids so the AI never invents anything."""
    lines = []
    lines.append("### MODELS (use these file names)")
    lines.append(", ".join(models or get_model_list()))

    lines.append("\n### LOCATIONS (zone_id -> pieces; [levels] = compatible levels)")
    for ln in (locations or get_location_list()):
        loc = load_json("locations", ln)
        lines.append(f"\n{ln}  (\"{loc.get('name', ln)}\")")
        for z in loc.get("photo_zones", []):
            zid = z.get("zone_id") or z.get("name")
            lines.append(f"  {zid}  (\"{z.get('name')}\"):")
            for p in z.get("prompt_pieces", []):
                lv = p.get("compatible_clothing_levels", ALL_LEVELS)
                pr = (p.get("prompt") or "").strip().replace("\n", " ")
                if len(pr) > 110:
                    pr = pr[:107] + "..."
                lines.append(f"    - {p.get('id')} | {p.get('type')}  [{' '.join(lv)}]")
                if pr:
                    lines.append(f"      prompt: {pr}")

    lines.append("\n### CLOTHING SETS (item_id -> states, in order)")
    for cn in (clothing or get_clothing_list()):
        cl = load_json("clothing", cn)
        lines.append(f"\n{cn}  (\"{cl.get('name', cn)}\")")
        for it in cl.get("items", []):
            states = " | ".join(s.get("state_id") for s in it.get("states", []))
            lines.append(f"  {it.get('item_id')}  \"{it.get('name')}\":  {states}")

    lines.append("\n### CAMERAS (id  \"brand model\")")
    for c in load_cameras():
        lines.append(f"  {c.get('id')}  \"{c.get('brand', '')} {c.get('model', '')}\"")

    lines.append("\n### FRAMING (id  \"name\")  — angle/coverage/view per shot")
    for f in load_framing():
        lines.append(f"  {f.get('id')}  \"{f.get('name')}\"")
    return "\n".join(lines)


def build_input_json(args):
    cfg = {
        "model": args.model,
        "location": args.location,
        "outfit": args.clothing,
        "style": args.style,
        "quality": args.quality,
        "camera": args.camera,
        "count": args.count,
        "min_level": args.min_level,
        "max_level": args.max_level,
        "seed": args.seed,
        "title": args.title,
    }
    return json.dumps(cfg, indent=2)


def build_system_prompt(cfg_json, ref_text, count=200, min_level=0, max_level=4):
    # total states -> rough shot where everything is off
    items_total = 0
    clothing = get_clothing_list()
    for cn in clothing:
        cl = load_json("clothing", cn)
        items_total = max(items_total, sum(len(it.get("states", [])) - 1
                                          for it in cl.get("items", [])))
    reach_off = max(10, min(count // 3, items_total + 8))

    return f"""You are a professional photography shoot director and prompt engineer
for the ComfyUI node pack "Artistic Set Builder" (ASB). From the JSON config
below, produce ONE complete shoot plan in the exact YAML format specified, so
it can be loaded directly into the ASB_ShootPlan node and expanded into
{count} consistent, high-quality image prompts.

=== INPUT (JSON) — obey exactly ===
{cfg_json}

=== DATA REFERENCE — use ONLY these ids; never invent others ===
{ref_text}

=== OUTPUT FORMAT (exact) ===
title: "<shoot title>"
model: <model file name from reference>
location: <location file name from reference>
clothing_set: <clothing set file name from reference>
style: <style>
quality: <quality>
camera: <camera id from reference>
seed: <seed>
shots:
  - zone: <zone_id>
    piece: <piece id>
    framing: <framing id>          # optional — omit to let the node auto-pick
    outfit: fully_worn             # or "removed", or a map: {{item_id: state, ...}}
    note: "<one short director's note>"
  - zone: <zone_id>
    piece: <piece id>
    transition: "advance: <item_id>"   # or remove: / dress: / set: / sequence: / reset
    ...

=== HARD RULES — a violated rule makes the plan fail to load ===
1. Use ONLY ids from the DATA REFERENCE (wrong ids = load error).
2. Output exactly {count} shots. RAW YAML ONLY — no markdown fences, no
   commentary, no trailing explanation. The whole reply must be parseable.
3. CONSISTENCY (perfect photo set): one model, one camera body, one style,
   one quality, one seed, one title for the entire plan. The model identity,
   lighting and style are fixed by the node — never change them mid-plan.
4. UNDRESS NARRATIVE (clothing timeline from the outfit database):
   - shot 0 starts with the outfit fully worn.
   - advance ONE item one state per shot ("advance: <item_id>"), cycling the
     items in order; use "remove: <item_id>" to finish an item, "set:
     <item_id> -> <state>" to jump, "dress: <item_id>" to re-wear an item for
     variety, and "reset" to start a fresh cycle if needed.
   - everything should be off (level {max_level}) by roughly shot {reach_off};
     keep the remaining shots all-off with varied zones/pieces/framing/notes
     (occasionally re-wear one item with "dress:" for variety).
5. ZONE/PIECE COMPATIBILITY: each piece lists its compatible levels in the
   reference ([level_0 level_1 ...]). Only use a piece at a shot whose outfit
   level is in that piece's list. Pick the piece accordingly.
6. VARIETY: cycle through zones and pieces, vary the framing ids, and write a
   short director's note for every shot. Keep it physically plausible and
   consistent (same person, same room, same camera, same light).
7. STAY IN RANGE: the plan must respect min_level {min_level} / max_level {max_level}.

=== MODEL PHASE DESCRIPTIONS ===
If the reference lists a model with phase-wise descriptions, the engine
automatically uses the phase text matching each shot's undress level (phase_1
at level_0 ... phase_5 at level_4). You never write that wording — you only
pick the model id and the transitions.

=== IMPORTANT — the `prompt` field IS the wording ===
Each piece in the reference has a `prompt:` line: that text is inserted into the
image prompt VERBATIM by the engine. Never invent pose wording — choose ids, and
the engine uses each piece's own `prompt` text and each clothing state's own
`prompt_phrase`. Your only job is to pick the right ids + transitions.

=== TRANSITION CHEAT-SHEET (what the node accepts) ===
  advance: <item_id>          one state forward
  remove: <item_id>           jump to last state
  dress: <item_id>            one state backward
  set: <item_id> -> <state>   jump to an exact state
  sequence: <item_id>         auto-step this item each shot
  reset                       all items fully worn again
  outfit: fully_worn|removed  all on / all off
  outfit: {{item_id: state}}  exact per-item map

=== SELF-CHECK BEFORE REPLYING ===
- every zone exists in the location reference
- every piece exists in its zone
- every item in outfit/transition exists in the clothing set
- every state exists for that item
- each shot's piece is compatible with the level its outfit reaches
- exactly {count} shots, no fences, valid YAML
"""


def main():
    ap = argparse.ArgumentParser(description="Build an AI shoot-plan system prompt")
    ap.add_argument("--model", default=first_model() or "model")
    ap.add_argument("--location", default=first_location() or "location")
    ap.add_argument("--clothing", default=first_clothing() or "clothing")
    ap.add_argument("--style", default="soft boudoir")
    ap.add_argument("--quality", default="film")
    ap.add_argument("--camera", default=first_camera() or "camera")
    ap.add_argument("--count", type=int, default=200)
    ap.add_argument("--min-level", type=int, default=0)
    ap.add_argument("--max-level", type=int, default=4)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--title", default="AI Directed Shoot")
    ap.add_argument("--out", default="", help="write prompt to a file instead of stdout")
    ap.add_argument("--doc", action="store_true",
                    help="regenerate docs/AI_PLAN_SYSTEM_PROMPT.md with the full data reference")
    args = ap.parse_args()

    if args.doc:
        cfg = {
            "model": first_model() or "model",
            "location": first_location() or "location",
            "outfit": first_clothing() or "clothing",
            "style": "soft boudoir",
            "quality": "film",
            "camera": first_camera() or "camera",
            "count": 200, "min_level": 0, "max_level": 4, "seed": 42,
            "title": "AI Directed Shoot",
        }
        ref = build_data_reference()  # full
        prompt = build_system_prompt(json.dumps(cfg, indent=2), ref, 200, 0, 4)
        os.makedirs(os.path.dirname(DOC_PATH), exist_ok=True)
        with open(DOC_PATH, "w", encoding="utf-8") as f:
            f.write(f"# AI Shoot-Plan System Prompt\n\n"
                    f"_Generated by `scripts/make_plan_prompt.py --doc`. Copy everything "
                    f"between the markers into any LLM, or use the tailored generator for "
                    f"one combo._\n\n"
                    f"```\n{prompt}\n```\n")
        print(f"wrote {DOC_PATH} ({os.path.getsize(DOC_PATH)} bytes)")
        return 0

    # validate the combo exists
    models, locs, cloths = get_model_list(), get_location_list(), get_clothing_list()
    if args.model not in models:
        print(f"ERROR: unknown model '{args.model}' (available: {', '.join(models)})", file=sys.stderr)
        return 1
    if args.location not in locs:
        print(f"ERROR: unknown location '{args.location}' (available: {', '.join(locs)})", file=sys.stderr)
        return 1
    if args.clothing not in cloths:
        print(f"ERROR: unknown clothing set '{args.clothing}' (available: {', '.join(cloths)})", file=sys.stderr)
        return 1

    ref = build_data_reference([args.model], [args.location], [args.clothing])
    cfg_json = build_input_json(args)
    prompt = build_system_prompt(cfg_json, ref, args.count, args.min_level, args.max_level)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(prompt)
        print(f"wrote prompt ({len(prompt)} chars) to {args.out}")
    else:
        print(prompt)
    return 0


if __name__ == "__main__":
    sys.exit(main())
