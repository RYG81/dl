#!/usr/bin/env python3
"""
CHECK YOUR INSTALL — run this inside your installed pack:

    cd ComfyUI\\custom_nodes\\comfyui-artistic-set-builder
    python scripts\\check_install.py

It reports:
  1. where the pack is reading data from,
  2. how many files are REALLY in each data subfolder,
  3. how many the node dropdowns will actually show (and why a file may be
     invisible: wrong extension, subfolder, invalid JSON, uppercase .JSON...),
  4. whether config.json / ASB_DATA_DIRS external folders are active,
  5. a checklist for making new files appear.

Paste the output here if the dropdown still looks short.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils import database as db  # noqa: E402

PACK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = db.DATA_DIR


def scan(category):
    """Return (visible, invisible_with_reasons, total_on_disk)."""
    folder = os.path.join(DATA, category)
    visible = set()
    if os.path.isdir(folder):
        visible = {f[:-5] for f in os.listdir(folder)
                   if f.endswith(".json") and os.path.isfile(os.path.join(folder, f))}
    # extras too
    for d in db.extra_dirs():
        f2 = os.path.join(d, category)
        if os.path.isdir(f2):
            visible.update(f[:-5] for f in os.listdir(f2)
                           if f.endswith(".json") and os.path.isfile(os.path.join(f2, f)))

    problems = []
    total = 0
    root = os.path.join(DATA, category)
    if os.path.isdir(root):
        for f in sorted(os.listdir(root)):
            p = os.path.join(root, f)
            if os.path.isdir(p):
                problems.append((f, "it is a SUBFOLDER — files must sit directly in the folder"))
                continue
            total += 1
            low = f.lower()
            if not low.endswith(".json"):
                problems.append((f, "not .json (has extension like .txt/.yaml/.JSON?)"))
                continue
            if f != low and not f.endswith(".json"):
                problems.append((f, "uppercase extension"))
            try:
                with open(p, "r", encoding="utf-8") as fh:
                    json.load(fh)
            except Exception as e:
                problems.append((f, f"INVALID JSON: {e}"))
    return visible, problems, total


def main():
    print("=" * 72)
    print("ASB install check")
    print("=" * 72)
    print("Pack root :", PACK)
    print("Data dir  :", DATA)
    print("This script sees data from the folder above.")

    extra = db.extra_dirs()
    print("\nExternal data folders (config.json / ASB_DATA_DIRS):")
    print("  ", extra if extra else "(none)")

    for cat, label in (("models", "MODELS"), ("locations", "LOCATIONS"),
                       ("clothing", "CLOTHING SETS")):
        visible, problems, total = scan(cat)
        print(f"\n--- {label} ---")
        print(f"  files on disk in {DATA}\\{cat}: {total}")
        print(f"  will appear in dropdowns      : {len(visible)}")
        missing = [f[:-5] for f in os.listdir(os.path.join(DATA, cat))]
        # simpler: names on disk that are NOT visible
        disk_names = set()
        folder = os.path.join(DATA, cat)
        if os.path.isdir(folder):
            for f in os.listdir(folder):
                if os.path.isfile(os.path.join(folder, f)):
                    disk_names.add(f[:-5] if f.lower().endswith(".json") else f)
        hidden = disk_names - visible
        if hidden:
            print(f"  files NOT in dropdown: {sorted(hidden)}")
        if problems:
            print("  problems:")
            for name, why in problems:
                print(f"    - {name}: {why}")

    # cameras/framing flat or folder
    cams = db.get_camera_ids()
    fr = db.get_framing_ids()
    print(f"\nCameras available : {len(cams)}")
    print(f"Framing available : {len(fr)}")

    # ---- version check: is this install the LATEST code? ----
    print("\n" + "=" * 72)
    print("VERSION CHECK (is your installed code up to date?)")
    marks = [
        ("utils/database.py", "extra_data_dirs", "external data folder support"),
        ("web/planner_widget.js", "Refresh data", "in-editor refresh button"),
        ("web/planner_widget.js", "buildSamplePlan", "dynamic sample plan"),
        ("nodes/shoot_plan.py", "gallery_mode", "gallery mode input"),
        ("__init__.py", "WEB_DIRECTORY", "web extension loading"),
    ]
    for rel, needle, what in marks:
        p = os.path.join(PACK, rel)
        found = False
        try:
            with open(p, "r", encoding="utf-8") as fh:
                found = needle in fh.read()
        except Exception:
            found = False
        print(f"  {'OK  ' if found else 'OLD '} {rel}: {what}")
    print("  If any line says OLD, your installed zip is outdated — reinstall")
    print("  the latest artistic-set-builder-comfyui-v2.zip and restart.")

    print("\n" + "=" * 72)
    print("CHECKLIST — to make a new file appear in the node:")
    print("  1. File must be directly in the right subfolder:")
    print("       data\\models\\    data\\locations\\    data\\clothing\\")
    print("  2. Name must end in .json  (e.g. my_place.json)")
    print("  3. File must be valid JSON  (run: python scripts\\validate.py)")
    print("  4. python scripts\\export_planner_data.py")
    print("  5. RESTART ComfyUI  (dropdowns are built once at startup)")
    print("  6. In the node editor use:  ↻ Refresh data")
    print("=" * 72)


if __name__ == "__main__":
    main()
