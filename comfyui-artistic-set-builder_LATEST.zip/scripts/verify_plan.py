#!/usr/bin/env python3
"""
Verify a shoot-plan file (YAML/JSON) is loadable by the ASB engine — i.e. that
it will expand into shots instead of erroring. Run this on anything an AI (or
a human) hands you before pasting it into the ASB_ShootPlan node.

Usage:
    python scripts/verify_plan.py plan.yaml
    python scripts/verify_plan.py plan.json --json
    cat plan.yaml | python scripts/verify_plan.py - 

Exit code 0 = loadable (with N shots), 1 = errors (the reason is printed).
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.shoot_plan import expand_plan, parse_plan_text  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description="Verify an ASB shoot plan is loadable")
    ap.add_argument("plan", help="path to plan file (.yaml/.yml/.json/.txt) or '-' for stdin")
    ap.add_argument("--json", action="store_true", help="emit machine-readable result")
    args = ap.parse_args()

    if args.plan == "-":
        text = sys.stdin.read()
    else:
        if not os.path.isfile(args.plan):
            print(f"ERROR: file not found: {args.plan}", file=sys.stderr)
            return 2
        with open(args.plan, "r", encoding="utf-8") as f:
            text = f.read()

    try:
        data = parse_plan_text(text)
    except Exception as e:
        if args.json:
            print(json.dumps({"ok": False, "error": str(e)}))
        else:
            print(f"NOT LOADABLE — parse error: {e}")
        return 1

    try:
        shots, report, story = expand_plan(data)
    except Exception as e:
        if args.json:
            print(json.dumps({"ok": False, "error": str(e)}))
        else:
            print(f"NOT LOADABLE — expand error: {e}")
        return 1

    if not shots:
        msg = "NO VALID SHOTS — the plan expands to zero shots:\n" + "\n".join(report)
        if args.json:
            print(json.dumps({"ok": False, "error": msg}))
        else:
            print("NOT LOADABLE — " + msg.replace("\n", "\n  "))
        return 1

    if args.json:
        print(json.dumps({
            "ok": True,
            "count": len(shots),
            "report": "\n".join(report) if report else "OK",
            "storyboard": story,
        }, indent=2))
    else:
        print(f"LOADABLE ✓  {len(shots)} shots")
        notes = "\n".join(report) if report else "OK (no notes)"
        print(f"notes: {notes}")
        print("\n--- storyboard (head) ---")
        print("\n".join(story.splitlines()[:6]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
