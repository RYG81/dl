"""Build Photoset Browser catalog from ASB data folders."""
from __future__ import annotations
import json, os, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"


def _load(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _stem_id(path: Path, obj: dict | None) -> str:
    if obj and obj.get("id"):
        return str(obj["id"])
    return path.stem


def build_catalog():
    locations = []
    location_groups = set()
    for p in sorted((DATA / "locations").glob("*.json")):
        d = _load(p)
        if not d:
            continue
        zones = d.get("photo_zones") or d.get("zones") or []
        gid = d.get("group") or d.get("category") or "general"
        location_groups.add(gid)
        zone_payload = []
        for z in zones:
            pieces = z.get("prompt_pieces") or []
            piece_list = []
            for pc in pieces:
                if not isinstance(pc, dict):
                    continue
                piece_list.append({
                    "id": pc.get("id") or "",
                    "type": pc.get("type") or "",
                    "prompt": (pc.get("prompt") or "")[:280],
                    "framing": pc.get("framing") or "",
                    "camera_angle": pc.get("camera_angle") or "",
                    "stage": pc.get("stage") or "any",
                    "levels": pc.get("compatible_clothing_levels") or [],
                })
            zone_payload.append({
                "zone_id": z.get("zone_id") or z.get("name") or "zone",
                "name": z.get("name") or z.get("zone_id") or "Zone",
                "category": (z.get("zone_id") or z.get("name") or "view"),
                "description": (z.get("description") or "")[:200],
                "piece_count": len(piece_list),
                "pieces": piece_list,
            })
        locations.append({
            "id": p.stem,
            "name": d.get("name") or p.stem.replace("_", " ").title(),
            "group": gid,
            "zone_count": len(zones),
            "zones": zone_payload,
            "piece_count_total": sum(z["piece_count"] for z in zone_payload),
            "lighting": (d.get("lighting") or "")[:200],
            "tags": d.get("tags") or [],
            "description_preview": str(d.get("overall_description") or d.get("description") or "")[:240],
            "active": d.get("active", True),
            "thumbnail": None,
        })

    outfits = []
    style_families = set()
    all_fabrics = set()
    all_colors = set()
    fabric_words = ("silk", "cotton", "lace", "mesh", "denim", "linen", "velvet", "leather", "satin", "knit", "chiffon", "microfiber", "sheer", "ribbed")
    color_words = ("black", "white", "red", "blue", "beige", "pink", "nude", "ivory", "burgundy", "green", "gold", "silver", "purple", "orange", "gray", "grey", "camel", "mauve")
    for p in sorted((DATA / "clothing").glob("*.json")):
        d = _load(p)
        if not d:
            continue
        items = d.get("items") or []
        name = d.get("name") or p.stem.replace("_", " ").title()
        blob = " ".join([name] + [(it.get("base_description") or it.get("name") or "") for it in items]).lower()
        fabrics = [f for f in fabric_words if f in blob]
        colors = [c for c in color_words if c in blob]
        style = d.get("style_family") or ("lingerie" if any("lingerie" in (it.get("category") or "") for it in items) else "classic")
        style_families.add(style)
        all_fabrics.update(fabrics)
        all_colors.update(colors)
        # Preserve recommended undress order for the UI timeline
        seq = d.get("recommended_undress_sequence") or []
        by_id = {(it.get("item_id") or it.get("name")): it for it in items}
        ordered_items = []
        for key in seq:
            # sequence entries may be plain item_id strings OR dicts {item_id, note}
            if isinstance(key, dict):
                key = key.get("item_id") or key.get("id") or key.get("name")
            if key and key in by_id:
                ordered_items.append(by_id[key])
        for it in items:
            if it not in ordered_items:
                ordered_items.append(it)

        layer_items = []
        for i, it in enumerate(ordered_items):
            states = it.get("states") or []
            undress_order = it.get("undress_order") or [s.get("state_id") for s in states if s.get("state_id")]
            state_map = {s.get("state_id"): s for s in states if s.get("state_id")}
            # Ordered state list with prompt phrases for browser side panel
            state_list = []
            for sid in undress_order:
                st = state_map.get(sid) or {"state_id": sid}
                state_list.append({
                    "state_id": sid,
                    "prompt_phrase": (st.get("prompt_phrase") or st.get("phrase") or sid),
                    "is_removed": sid in ("removed", "off", "gone") or "removed" in sid,
                })
            # Include any states not in undress_order
            for s in states:
                sid = s.get("state_id")
                if sid and sid not in undress_order:
                    state_list.append({
                        "state_id": sid,
                        "prompt_phrase": s.get("prompt_phrase") or s.get("phrase") or sid,
                        "is_removed": False,
                    })
            layer_items.append({
                "item_id": it.get("item_id") or it.get("name") or f"item_{i}",
                "name": it.get("name") or it.get("item_id") or f"item_{i}",
                "category": it.get("category") or "other",
                "base_description": (it.get("base_description") or "")[:300],
                "undress_order": undress_order,
                "states": state_list,
                "state_count": len(state_list),
                "removalOrder": i + 1,
                "removalPhaseRange": {"earliest": min(i + 1, 4), "latest": min(i + 2, 5)},
            })
        # Flatten full undress walk for side panel (one item at a time)
        undress_walk = []
        for it in layer_items:
            for st in it.get("states") or []:
                undress_walk.append({
                    "item_id": it["item_id"],
                    "item_name": it["name"],
                    "category": it["category"],
                    "state_id": st["state_id"],
                    "prompt_phrase": st["prompt_phrase"],
                    "is_removed": st.get("is_removed", False),
                })
        outfits.append({
            "id": p.stem,
            "name": name,
            "item_count": len(items),
            "items": layer_items,
            "recommended_undress_sequence": (
                [
                    (x.get("item_id") if isinstance(x, dict) else x)
                    for x in seq
                    if (x.get("item_id") if isinstance(x, dict) else x)
                ]
                if seq else [it["item_id"] for it in layer_items]
            ),
            "undress_walk": undress_walk,
            "undress_step_count": len(undress_walk),
            "style_family": style,
            "fabrics": fabrics[:6],
            "colors": colors[:6],
            "tags": d.get("tags") or [],
            "categories": list({it.get("category") for it in items if it.get("category")}),
            "active": d.get("active", True),
            "thumbnail": None,
            "preview": str((items[0].get("base_description") if items else "") or "")[:200],
        })

    subjects = []
    for p in sorted((DATA / "models").glob("*.json")):
        d = _load(p)
        if not d:
            continue
        hair = d.get("hair") or {}
        face = d.get("face") or {}
        if isinstance(hair, dict):
            hair_color = hair.get("color") or hair.get("description") or ""
        else:
            hair_color = str(hair)
        if isinstance(face, dict):
            eye_color = face.get("eyes") or face.get("eye_color") or ""
        else:
            eye_color = ""
        breasts = d.get("breasts") or {}
        pussy = d.get("pussy") or {}
        ass = d.get("ass") or {}
        skin = d.get("skin") or {}
        hair_d = hair if isinstance(hair, dict) else {}
        face_d = face if isinstance(face, dict) else {}
        subjects.append({
            "id": p.stem,
            "name": d.get("name") or p.stem.replace("_", " ").title(),
            "age": d.get("age"),
            "hair_color": hair_color if isinstance(hair_color, str) else str(hair_color),
            "eye_color": eye_color if isinstance(eye_color, str) else str(eye_color),
            "nationality": d.get("ethnicity") or d.get("nationality") or "",
            "body_type": d.get("body_type") or "",
            "height": d.get("height") or "",
            "hair": hair_d,
            "face": face_d,
            "skin": skin,
            "breasts": {
                "size": breasts.get("size"),
                "shape": breasts.get("shape"),
                "label": breasts.get("label"),
                "nipples": breasts.get("nipples_detail") or breasts.get("nipples"),
                "areola": breasts.get("areola"),
            },
            "pussy": {
                "type": pussy.get("type"),
                "labia": pussy.get("labia"),
                "hair": pussy.get("hair"),
                "hair_prompt": pussy.get("hair_prompt"),
                "color": pussy.get("color"),
                "perianal_hair": pussy.get("perianal_hair"),
            },
            "ass": {
                "shape": ass.get("shape"),
                "asshole": ass.get("asshole"),
                "color": ass.get("color"),
            },
            "overall_vibe": d.get("overall_vibe") or "",
            "tags": d.get("tags") or [],
            "preview": str(d.get("prompt_model_description") or d.get("overall_vibe") or "")[:400],
            "active": d.get("active", True),
            "thumbnail": None,
        })

    piercings = []
    pierce_path = DATA / "piercings" / "catalog.json"
    pc = _load(pierce_path) or {}
    items = pc.get("items") if isinstance(pc, dict) else (pc if isinstance(pc, list) else [])
    for it in (items or [])[:800]:
        if not isinstance(it, dict):
            continue
        pid = it.get("id") or it.get("name")
        if not pid:
            continue
        loc = (it.get("location") or it.get("placement") or it.get("requires") or "other")
        if isinstance(loc, list):
            loc = loc[0] if loc else "other"
        loc = str(loc).lower()
        if "nipple" in loc or "chest" in loc:
            location = "nipple"
        elif "navel" in loc or "belly" in loc:
            location = "navel"
        elif "nose" in loc:
            location = "nose"
        elif "ear" in loc or "helix" in loc or "lobe" in loc or "tragus" in loc or "conch" in loc:
            location = "ear"
        elif "lip" in loc or "face" in loc or "eyebrow" in loc or "septum" in loc:
            location = "face"
        else:
            location = "surface"
        piercings.append({
            "id": str(pid),
            "name": it.get("label") or it.get("name") or str(pid),
            "location": location,
            "material": it.get("material") or "metal",
            "style": (it.get("prompt") or it.get("description") or "")[:120],
        })

    return {
        "locations": locations,
        "outfits": outfits,
        "subjects": subjects,
        "piercings": piercings,
        "totals": {
            "locations": len(locations),
            "outfits": len(outfits),
            "subjects": len(subjects),
            "piercings": len(piercings),
        },
        "location_groups": sorted(location_groups) or ["general"],
        "style_families": sorted(style_families) or ["classic"],
        "all_fabrics": sorted(all_fabrics),
        "all_colors": sorted(all_colors),
        "warnings": [],
    }


def default_template():
    return (
        "[REAL PHOTOGRAPH — UNRETOUCHED]\n\n"
        "{{style_prefix}}. {{critical_guard}}.\n\n"
        "Subject: {{subject_identity}}\n\n"
        "Phase {{phase_number}}: {{phase_name}}. {{phase_description}}. "
        "Wardrobe: {{wardrobe_summary}}.{{outfit_recall}}\n\n"
        "Clothing: {{clothing_continuity}}\n\n"
        "Pose: {{subject_first_name}} is {{pose_description}}{{pose_bridge}}, "
        "while {{gaze_text}} with {{expression_text}}, conveying {{mood_word}}.\n\n"
        "Camera: {{shot_description}} from {{angle_description}}, {{framing_description}}.\n\n"
        "Location: {{location_name}}. {{location_desc}}.{{visible_surfaces}}{{visible_props}}{{visibility_directive}}\n\n"
        "Lighting: {{light_description}}.\n\n"
        "{{style_aesthetic}}, {{quality_tail}}.{{piercing_line}}"
    )
