"""
Pure prompt-assembly helpers (no node classes, no relative imports).

Shared by the node pack (inside ComfyUI) and the offline scripts. Everything
here is a plain function on plain data so it can be imported from anywhere.
"""

DEFAULT_QUALITY = (
    "photorealistic, professional erotic photography, beautiful natural skin "
    "texture, elegant composition, sharp focus, 8k"
)

# named quality presets — used by ASB Set Plan's dropdown; each expands to a
# full quality string. Users can still override with quality_custom.
QUALITY_PRESETS = {
    "default": DEFAULT_QUALITY,
    "editorial": (
        "editorial photography, natural skin texture, candid and effortless, "
        "sharp focus, medium format look"
    ),
    "studio": (
        "studio photography, softbox lighting, clean background, high detail, "
        "sharp focus"
    ),
    "film": (
        "35mm film photography, natural grain, soft muted tones, cinematic"
    ),
    "black & white": (
        "black and white fine art photography, high contrast, timeless film grain"
    ),
    "ultra detail": (
        "natural unretouched skin with visible pores and fine microtexture, soft subsurface scattering, real photograph, sharp optical focus, no beauty filter"
    ),
    "clean minimal": (
        "clean minimal composition, natural light, soft focus, airy"
    ),
    "metart": (
        "natural unretouched skin with visible pores, soft subsurface scattering, "
        "shot like a real photograph on an 85mm lens, shallow depth of field, sharp eyes, soft background falloff"
    ),
    "sensual editorial": (
        "sensual editorial photography, warm natural light, soft shadows along curves, "
        "Kodak Portra-like skin tones, visible pores, gentle film grain, "
        "magazine-quality composition, 85mm f/1.8 look"
    ),
}


def resolve_quality(quality=None, quality_custom=""):
    """Resolve a quality dropdown choice (or raw string) + custom override."""
    if quality_custom and quality_custom.strip():
        return quality_custom.strip()
    if quality and quality in QUALITY_PRESETS:
        return QUALITY_PRESETS[quality]
    if quality and quality.strip():
        return quality.strip()
    return DEFAULT_QUALITY


STYLE_PRESETS = {
    "custom": {
        "positive": "",
        "negative": "",
    },
    "natural editorial": {
        "positive": "natural editorial photography, candid and effortless, airy muted tones, soft window light",
        "negative": "harsh flash, oversaturated colors, heavy retouching",
    },
    "studio glam": {
        "positive": "studio glamour photography, dramatic softbox lighting, glowing skin, elegant high fashion styling",
        "negative": "natural daylight, harsh shadows, casual setting",
    },
    "black and white": {
        "positive": "black and white fine-art photography, high contrast, timeless film grain",
        "negative": "color, oversaturated, vivid hues",
    },
    "soft boudoir": {
        "positive": "intimate boudoir photography, moody warm tones, low-key lighting, silk and lace textures",
        "negative": "harsh lighting, clinical setting, office or kitchen background",
    },
    "golden hour outdoor": {
        "positive": "golden hour outdoor photography, warm sunlight flare, sun-kissed skin, shallow depth of field",
        "negative": "indoor setting, artificial lighting, gray overcast sky",
    },
    "night neon": {
        "positive": "night photography, neon city lights bokeh, cinematic teal and magenta grade, moody atmosphere",
        "negative": "daylight, natural window light, bright clean background",
    },
    "metart natural": {
        "positive": "fine art erotic photography, natural unretouched skin, candid confident presence, body as elegant line, intimate refined composition",
        "negative": "ugly pose, stiff mannequin posture, exaggerated grimace, heavy makeup, plastic airbrushed skin, oversaturated, harsh on-camera flash, fish-eye, text, watermark, extra limbs, deformed hands",
    },
    "sensual soft": {
        "positive": "sensual softcore editorial, warm window light, soft shadow on curves, relaxed confident gaze, natural skin sheen, intimate bedroom mood, refined erotic composition",
        "negative": "stiff pose, blank expression, plastic skin, harsh flash, cluttered background, text, watermark, extra limbs",
    }
}

# level -> negative additions that stop the model from hallucinating
# leftover/extra clothing at higher undress levels.
LEVEL_NEGATIVES = {
    "level_0": "",
    "level_1": "",
    "level_2": "extra outer garment, stray fabric not part of current outfit",
    "level_3": "extra clothing, stray fabric, fully covering underwear when exposed, hands covering genitals, modest covering pose",
    "level_4": "any clothing, underwear, bra, panties, stray fabric, cropped feet, stiff mannequin, closed legs when pose is open, hands covering genitals, modest hands over pussy, hidden hands when fingering, shy covering pose",
}


# phase_1..phase_5 <-> level_0..level_4 (the undress levels)
LEVEL_TO_PHASE = {"level_0": "phase_1", "level_1": "phase_2", "level_2": "phase_3",
                  "level_3": "phase_4", "level_4": "phase_5"}


def phase_key_for_level(level):
    return LEVEL_TO_PHASE.get(level or "level_0", "phase_1")




def visible_body_regions(level="level_0", framing_ref="", piece_prompt="", chest_exposed=False, groin_exposed=False, midriff_exposed=False):
    """Which body regions are likely visible given clothing exposure + framing + pose.
    Used to gate piercings/tattoos so nipple bars do not appear under a closed dress.
    """
    fr = (framing_ref or "").lower()
    pose = (piece_prompt or "").lower()
    lvl = (level or "level_0").lower()

    # Always assume face/ears unless extreme crop on lower body only
    regions = {"face", "ears", "nose", "hair"}

    tight_face = any(k in fr for k in ("close_up", "extreme_close", "detail_crop")) and "full" not in fr
    lower_only = any(k in fr for k in ("tight_crop_torso",)) and "face" not in pose

    if tight_face:
        return regions  # face/ears only

    regions.update({"shoulder", "arms", "wrist", "hands", "collarbone"})

    # Midriff / navel / ribs — need open midriff or late undress
    if midriff_exposed or chest_exposed or lvl in ("level_2", "level_3", "level_4"):
        regions.update({"midriff", "navel", "ribs", "hip"})

    if chest_exposed or lvl in ("level_3", "level_4"):
        regions.update({"chest", "nipples", "sternum", "underbust"})

    if groin_exposed or lvl == "level_4":
        regions.update({"hip", "thigh", "legs", "groin"})

    # Full body / wide shows ankles and more
    if any(k in fr for k in ("full_body", "wide", "negative_space", "environmental", "medium_full")):
        regions.update({"legs", "thigh", "ankle", "feet", "back", "spine", "lower_back"})

    # Pose cues
    if any(k in pose for k in ("from behind", "back to camera", "looking over", "all fours", "prone")):
        regions.update({"back", "spine", "lower_back", "shoulder"})
    if any(k in pose for k in ("profile", "side")):
        regions.update({"shoulder", "ribs"})
    if any(k in pose for k in ("feet", "ankle", "toes")):
        regions.update({"ankle", "feet", "legs"})
    if lower_only:
        regions.discard("face")
        regions.discard("ears")
        regions.discard("nose")

    return regions


def filter_accessory_parts(parts, visible):
    """Keep only accessory part lines whose requires ⊆ visible (or requires empty)."""
    out = []
    for part in parts or []:
        req = part.get("requires") or []
        if not req:
            if part.get("prompt"):
                out.append(part["prompt"])
            continue
        # visible if ANY required region is visible (navel needs navel OR midriff)
        if any(r in visible for r in req):
            pr = (part.get("prompt") or "").strip()
            if pr:
                out.append(pr)
    return out


def resolve_catalog_parts(folder, item_id):
    """Load parts list for a piercing/tattoo catalog id."""
    try:
        from .database import load_json
        cat = load_json(folder, "catalog") or {}
        for it in cat.get("items") or []:
            if it.get("id") == item_id:
                if it.get("parts"):
                    return it["parts"]
                pr = (it.get("prompt") or "").strip()
                return [{"prompt": pr, "requires": it.get("requires") or []}] if pr else []
    except Exception:
        pass
    return []

def _piercing_tattoo_lines(data, include_piercings=False, include_tattoos=False, tattoo_style="",
                            piercing_override="", tattoo_override="",
                            visible=None, piercing_id="", tattoo_id=""):
    """Optional accessory lines, gated by which body regions are visible.

    Nipple piercings only when chest/nipples visible; navel only when midriff
    visible; face piercings when face in frame; tattoos same rules.
    """
    if visible is None:
        visible = {"face", "ears", "nose", "hair", "shoulder", "arms", "wrist", "hands", "collarbone"}
    bits = []

    # Piercings: prefer catalog parts by id when available
    if include_piercings or piercing_override or piercing_id:
        parts = []
        if piercing_id and piercing_id != "none":
            parts = resolve_catalog_parts("piercings", piercing_id)
        if not parts and piercing_override:
            # override is free text — include only if we cannot gate (show as-is when any body shown)
            if "face" in visible or "chest" in visible or "midriff" in visible:
                bits.append(piercing_override.strip())
        elif parts:
            bits.extend(filter_accessory_parts(parts, visible))
        elif include_piercings:
            pier = data.get("piercings") or {}
            line = (pier.get("prompt") or "").strip()
            # crude keyword gate on model default prompt
            if line:
                low = line.lower()
                ok = False
                if "nipple" in low and ("nipples" in visible or "chest" in visible):
                    ok = True
                if "navel" in low and ("navel" in visible or "midriff" in visible):
                    ok = True
                if any(k in low for k in ("ear", "septum", "nose")) and ("ears" in visible or "face" in visible):
                    ok = True
                if ok:
                    bits.append(line)

    if include_tattoos or tattoo_override or tattoo_id:
        parts = []
        if tattoo_id and tattoo_id != "none":
            parts = resolve_catalog_parts("tattoos", tattoo_id)
        if not parts and tattoo_override:
            if len(visible) > 4:  # not face-only
                bits.append(tattoo_override.strip())
        elif parts:
            bits.extend(filter_accessory_parts(parts, visible))
        elif include_tattoos:
            tat = data.get("tattoos") or {}
            opts = tat.get("options") or {}
            if tattoo_style and tattoo_style in opts and opts[tattoo_style]:
                line = opts[tattoo_style]
            else:
                line = (tat.get("prompt") or "").strip()
            if line:
                low = line.lower()
                ok = False
                if any(k in low for k in ("rib", "navel", "hip", "sternum", "underbust", "underboob")) and (
                    "midriff" in visible or "chest" in visible or "ribs" in visible
                ):
                    ok = True
                if any(k in low for k in ("spine", "back", "shoulder blade")) and "back" in visible:
                    ok = True
                if "ankle" in low and "ankle" in visible:
                    ok = True
                if "thigh" in low and ("thigh" in visible or "legs" in visible):
                    ok = True
                if "wrist" in low and "wrist" in visible:
                    ok = True
                if "ear" in low and "ears" in visible:
                    ok = True
                if "collarbone" in low and ("collarbone" in visible or "chest" in visible):
                    ok = True
                if ok:
                    bits.append(line)

    # de-dupe
    seen = set()
    out = []
    for b in bits:
        k = b.lower()
        if k not in seen:
            seen.add(k)
            out.append(b)
    return ", ".join(out)


def build_model_prompt(data, detail_level="standard", level=None, include_piercings=False, include_tattoos=False, tattoo_style="", piercing_override="", tattoo_override="", visible=None, piercing_id="", tattoo_id=""):
    """
    Turn a model JSON dict into a prompt string + identity token.

    detail_level:
      standard - face, hair, body type, vibe (classic behavior)
      detailed - additionally includes skin, makeup and the body-detail blocks
      minimal  - name, age, vibe only (safe for SFW output)

    level (optional): if the model defines `prompt_model_description` with
    phase-wise text (phase_1..phase_5), the description for the matching
    phase is used instead of the static assembly — so the model's own wording
    can evolve as the shoot progresses (phase_1 = fully dressed, phase_5 =
    fully undressed). Empty phase text falls back to the static build.
    """
    phase_desc = data.get("prompt_model_description") or {}
    # Only use per-phase dict text. A single long string often contains full nude
    # anatomy and would leak nipples under clothing — fall through to gated static.
    if level and isinstance(phase_desc, dict):
        key = phase_key_for_level(level)
        ph = (phase_desc.get(key) or "").strip()
        if ph:
            name = (data.get("name") or "").strip()
            token = data.get("identity_token") or name
            if name and not ph.lower().startswith(name.lower()):
                ph = f"{name}, {ph}"
            # Safety: if this phase claims nipples while level is still dressed, skip to static
            low = ph.lower()
            lvl = (level or "level_0").lower()
            if lvl in ("level_0", "level_1") and any(k in low for k in ("nipple", "areola", "pussy", "labia", "asshole", "vulva")):
                pass  # fall through to gated static assembly
            else:
                extra = _piercing_tattoo_lines(data, include_piercings, include_tattoos, tattoo_style, piercing_override, tattoo_override, visible=visible, piercing_id=piercing_id, tattoo_id=tattoo_id)
                if extra:
                    ph = f"{ph} {extra}".strip()
                return ph, token

    # ---- static assembly ----
    # Anatomy is GATED by undress level / exposure. Never claim nipples, labia,
    # or asshole while those areas are still covered by clothing.
    #   level_0 / level_1 : face + hair + body type + soft silhouette under clothes
    #   level_2           : breasts may include nipples (chest bare); no genitals
    #   level_3 / level_4 : full intimate detail allowed
    lvl = (level or "level_0").lower()
    chest_bare = lvl in ("level_2", "level_3", "level_4")
    groin_bare = lvl in ("level_3", "level_4")

    parts = []
    if data.get("name"):
        parts.append(str(data["name"]))
    if data.get("age"):
        parts.append(str(data["age"]))
    if data.get("body_type"):
        parts.append(data["body_type"])

    hair = data.get("hair", {})
    if isinstance(hair, dict):
        h = " ".join(filter(None, [hair.get("length"), hair.get("style"),
                                   hair.get("color"), "hair"]))
        if h.strip():
            parts.append(h.strip())

    face = data.get("face", {})
    if isinstance(face, dict):
        fparts = []
        if face.get("smile"):
            fparts.append(f"{face['smile']} smile")
        if face.get("eyes"):
            fparts.append(f"{face['eyes']} eyes")
        if face.get("freckles") and face["freckles"] not in ("none", ""):
            fparts.append(face["freckles"])
        if detail_level != "minimal" and face.get("makeup"):
            fparts.append(f"{face['makeup']} makeup")
        if fparts:
            parts.append(", ".join(fparts))

    skin = data.get("skin", {})
    if detail_level != "minimal" and isinstance(skin, dict):
        s = " ".join(filter(None, [skin.get("tone"), skin.get("texture")]))
        detail = (skin.get("detail") or "").strip()
        if s.strip() and detail:
            parts.append(f"{s} skin, {detail}")
        elif s.strip():
            parts.append(f"{s} skin, visible skin pores, natural texture, subsurface scattering")
        elif detail:
            parts.append(detail)

    if detail_level == "minimal":
        pass
    elif not chest_bare and not groin_bare:
        # Fully / mostly dressed — silhouette only, no nipple or genital detail
        parts.append("soft figure lines under clothing, clothed silhouette")
    else:
        extra = []
        breasts = data.get("breasts") or {}
        if isinstance(breasts, dict) and chest_bare:
            # Chest exposed: shape/label + nipples OK
            for field in ("label", "size", "shape", "nipples", "nipples_detail", "areola"):
                v = breasts.get(field)
                if v and v not in ("none", ""):
                    extra.append(str(v))
                    if field in ("nipples_detail", "nipples", "label"):
                        break  # prefer one dense nipple phrase
            # Prefer nipples_detail over separate fields if present
            if breasts.get("nipples_detail"):
                extra = [x for x in extra if x not in (
                    str(breasts.get("nipples") or ""),
                    str(breasts.get("areola") or ""),
                )]
                if breasts.get("label"):
                    extra = [breasts["label"], breasts["nipples_detail"]]
                else:
                    extra = [breasts["nipples_detail"]]
        elif isinstance(breasts, dict) and not chest_bare:
            # Soft covered-chest mention only (no nipples)
            label = breasts.get("label") or " ".join(filter(None, [
                breasts.get("size"), breasts.get("shape"), "breasts"
            ])).strip()
            if label:
                extra.append(f"soft shape of {label} under fabric")

        pussy = data.get("pussy") or {}
        if isinstance(pussy, dict) and groin_bare:
            for field in ("hair_prompt", "type", "labia"):
                v = pussy.get(field)
                if v and v not in ("none", ""):
                    extra.append(str(v))
            col = (pussy.get("color") or "").strip()
            if col:
                extra.append(f"{col} intimate color close to surrounding skin tone")
            peri = pussy.get("perianal_hair")
            if peri:
                extra.append(str(peri))

        ass = data.get("ass") or {}
        if isinstance(ass, dict) and groin_bare:
            shape = (ass.get("shape") or "").strip()
            if shape:
                extra.append(shape)
            ah = (ass.get("asshole") or "").strip()
            if ah:
                # already includes close-to-skin from model DB when updated
                if "skin" not in ah.lower():
                    ah = f"{ah} close to surrounding skin tone"
                extra.append(ah)
        elif isinstance(ass, dict) and chest_bare and not groin_bare:
            # Rear may show while briefs still on — shape only, no asshole
            if ass.get("shape"):
                extra.append(str(ass["shape"]) + " hips under clothing")

        if extra:
            # de-dupe preserve order
            seen = set()
            clean = []
            for x in extra:
                k = x.lower()
                if k not in seen:
                    seen.add(k)
                    clean.append(x)
            parts.append(", ".join(clean))

    if data.get("overall_vibe"):
        parts.append(data["overall_vibe"])

    extra = _piercing_tattoo_lines(
        data, include_piercings, include_tattoos, tattoo_style,
        piercing_override, tattoo_override, visible=visible,
        piercing_id=piercing_id, tattoo_id=tattoo_id,
    )
    if extra:
        parts.append(extra)

    identity_token = data.get("identity_token") or str(data.get("name") or "")
    return ", ".join(parts), identity_token



def _scrub_positive_negations(text):
    """Never leave negative instructions in the positive prompt."""
    import re
    if not text:
        return text
    patterns = [
        r",?\s*no bare breasts or genitals visible",
        r",?\s*silhouette only, no[^.]*(?:\.|$)",
        r",?\s*not worn on the body",
        r",?\s*not visible on the body",
        r",?\s*completely removed from the body",
        r",?\s*no bare breasts[^.,]*",
        r",?\s*no genitals[^.,]*",
        r",?\s*no nipples[^.,]*",
        r",?\s*without (?:any )?(?:clothing|clothes|garments)[^.,]*",
    ]
    out = text
    for pat in patterns:
        out = re.sub(pat, "", out, flags=re.I)
    out = re.sub(r"\s{2,}", " ", out)
    out = re.sub(r"\s+,", ",", out)
    out = re.sub(r",\s*,", ",", out)
    return out.strip(" ,.")

def assemble_prompt(model_prompt, clothing_phrases, prompt_piece, lighting,
                    style, quality, level="level_0", camera_technical="",
                    negative_hints="", auto_negative=True,
                    clothing_off_neg="", scene_phrase="", expression_text="",
                    framing_tech="", narrative=True):
    """Combine all prompt parts -> (final_prompt, negative_prompt).

    Photographic narrative order (inspired by strong editorial/POV captions):
      1. Camera / capture tech (anchors "real photo")
      2. Pose / composition action (what the body is doing in frame)
      3. Expression / gaze
      4. Clothing still on the body (omitted when nude)
      5. Model identity + visible anatomy phase
      6. Environment / zone
      7. Lighting interacting with the scene
      8. Style + quality close ("authentic photograph…")

    When narrative=False, falls back to a flatter token order (legacy).
    """
    style_meta = STYLE_PRESETS.get(style, STYLE_PRESETS.get("custom", {"positive": "", "negative": ""}))
    if not isinstance(style_meta, dict):
        style_meta = {"positive": str(style_meta), "negative": ""}
    style_pos = style_meta.get("positive") or ""
    style_neg = style_meta.get("negative") or ""

    q = (quality or "").strip()
    if q and style_pos:
        style_tokens = set(style_pos.lower().replace(",", " ").split())
        q_tokens = set(q.lower().replace(",", " ").split())
        if style_tokens and len(q_tokens & style_tokens) / max(len(q_tokens), 1) > 0.45:
            q = ""

    # Strong photographic close — matches high-end adult editorial captions
    photo_close = (
        "real photograph, natural unretouched skin with visible pores and fine texture, "
        "soft subsurface scattering, true optical depth of field, "
        "mild natural grain in the shadows, available light with clear source and falloff"
    )
    if q and "authentic" in q.lower():
        photo_close = q
        q = ""
    elif not q:
        q = photo_close
    else:
        q = q + ", " + photo_close

    is_nude = (level or "").lower() in ("level_3", "level_4") and not (clothing_phrases or "").strip()
    expr = (expression_text or "").strip()
    cloth = (clothing_phrases or "").strip()
    pose = (prompt_piece or "").strip()
    cam = (camera_technical or "").strip()
    fr = (framing_tech or "").strip()
    # Merge framing into camera line when both present
    if fr and cam and fr.lower() not in cam.lower():
        cam = cam + ", " + fr
    elif fr and not cam:
        cam = fr

    # Lead camera with "Shot on …" when it looks like tech and does not already
    if cam and not cam.lower().startswith("shot on") and not cam.lower().startswith("photograph"):
        if any(k in cam.lower() for k in ("canon", "nikon", "sony", "fuji", "leica", "hasselblad", "mm", "eos", "rf ")):
            cam = "Shot on " + cam

    def _clean(s):
        return " ".join(str(s or "").strip().strip(",").split())

    cam = _clean(cam)
    pose = _clean(pose)
    expr = _clean(expr)
    cloth = _clean(cloth)
    model_prompt = _clean(model_prompt)
    scene_phrase = _clean(scene_phrase)
    lighting = _clean(lighting)
    style_pos = _clean(style_pos)
    q = _clean(q)

    if narrative:
        # Continuous photographic caption (MetArt / strong editorial order):
        # Camera → subject+pose → clothing still on → place → light → style/quality
        sentences = []
        if cam:
            sentences.append(cam if cam[0].isupper() or cam.lower().startswith("shot") else cam[0].upper() + cam[1:])
        # Pose is the main body of the caption — keep as continuous prose
        body_bits = []
        if pose:
            body_bits.append(pose)
        if expr and expr.lower() not in (pose or "").lower():
            body_bits.append(expr)
        if body_bits:
            body = ", ".join(body_bits)
            if body and body[0].islower():
                body = body[0].upper() + body[1:]
            sentences.append(body)
        if not is_nude and cloth:
            sentences.append(cloth)
        if model_prompt:
            sentences.append(model_prompt)
        place_bits = []
        if scene_phrase:
            place_bits.append(scene_phrase)
        if lighting and lighting.lower() not in (scene_phrase or "").lower():
            place_bits.append(lighting)
        if place_bits:
            sentences.append(", ".join(place_bits))
        close_bits = []
        if style_pos:
            close_bits.append(style_pos)
        if q:
            close_bits.append(q)
        if close_bits:
            sentences.append(", ".join(close_bits))
        # Join with periods for caption rhythm, then normalize spaces
        final = ". ".join(s.rstrip(" .") for s in sentences if s)
        final = final.replace("..", ".").strip()
        if final and not final.endswith("."):
            final += "."
        # Collapse accidental double spaces
        final = " ".join(final.split())
        final = _scrub_positive_negations(final)
    else:
        if is_nude:
            parts = [p for p in (
                scene_phrase, model_prompt, expr, pose, lighting,
                style_pos, q, cam,
            ) if p and str(p).strip()]
        else:
            parts = [p for p in (
                scene_phrase, model_prompt, cloth, expr, pose, lighting,
                style_pos, q, cam,
            ) if p and str(p).strip()]
        seen = set()
        clean = []
        for p in parts:
            t = str(p).strip().strip(",")
            key = t.lower()
            if not t or key in seen:
                continue
            seen.add(key)
            clean.append(t)
        final = ", ".join(clean)

    neg_parts = []
    if clothing_off_neg and clothing_off_neg.strip():
        neg_parts.append(clothing_off_neg.strip())
    if auto_negative and level in LEVEL_NEGATIVES:
        neg_parts.append(LEVEL_NEGATIVES[level])
    if style_neg:
        neg_parts.append(style_neg)
    if negative_hints and negative_hints.strip():
        neg_parts.append(negative_hints.strip())
    neg_parts.append(
        "illustration, painting, 3d render, cgi, plastic skin, airbrushed, "
        "extra limbs, deformed hands, text, watermark, logo, collage"
    )
    seen_n = set()
    uniq = []
    for p in neg_parts:
        for part in str(p).split(","):
            t = part.strip()
            if t and t.lower() not in seen_n:
                seen_n.add(t.lower())
                uniq.append(t)
    negative = ", ".join(uniq)

    return final, negative
