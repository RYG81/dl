"""
Shoot plan engine (v4).

A shoot plan is a declarative shot list for an entire photo shoot, like a
director's storyboard + wardrobe call sheet in one file. References are
ID-FIRST: zone_id / piece id / item_id (names also work as fallback), so the
plan stays compact and prompt phrases live only in the data files.
(EVERY id below is just an EXAMPLE — use the ids that exist in YOUR data/:

    title: "Liora — Elegant Undress"
    model: liora
    location: cozy_living
    clothing_set: elegant_dress_set
    style: soft boudoir
    quality: film
    shots:
      - zone: Z_Window
        piece: Win_01
        outfit: fully_worn
      - zone: Z_Window
        piece: Win_03
        transition: "advance: dress_01"      # next state in the DB
      - zone: Z_Sofa
        piece: Sofa_02
        transition: "advance: dress_01"
      - zone: Z_Sofa
        piece: Sofa_04
        transition: "set: bra_01 -> straps_down"

Per-shot fields:
  zone        - zone_id (or zone name) from the location
  piece       - piece id (or "id | type" label)
  outfit      - optional explicit outfit for this shot:
                  "fully_worn"                    all items -> first state
                  "removed" | "nude"              all items -> last state
                  { "dress_01": "slipped_off_shoulders", ... }   (item_id keys)
  transition  - optional directive applied to the PREVIOUS shot's outfit:
                  advance|undress|next: <Item>     one state forward
                  remove: <Item>                   jump to last state
                  dress: <Item>                    one state backward
                  set: <Item> -> <state>           jump to exact state
                  reset                            all items -> first state
                  sequence: <Item>                 auto: cycles the item one
                                                   step per remaining shot
  camera      - optional camera override
  note        - optional director's note
  level       - optional explicit target level (validated)

The engine validates every reference against the data files, expands
transitions into explicit per-item states, computes each shot's level and
prompt, and emits a storyboard + call-sheet text. Accepts JSON or YAML.
Expanded entries carry machine ids (zone_id, piece_id, outfit by item_id)
AND the resolved prompt strings for the sampler.
"""
import copy
import json
import re

try:
    # imported as part of the package (inside ComfyUI)
    from ..utils.database import load_cameras, load_framing, load_json
    from ..utils.levels import compute_level, item_state_ids
    from ..utils.planner import image_seed
    from ..utils.prompts import (
        QUALITY_PRESETS, assemble_prompt, build_model_prompt, resolve_quality,
    )
except ImportError:
    # imported top-level from scripts/
    from utils.database import load_cameras, load_framing, load_json
    from utils.levels import compute_level, item_state_ids
    from utils.planner import image_seed
    from utils.prompts import (
        QUALITY_PRESETS, assemble_prompt, build_model_prompt, resolve_quality,
    )

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

_CAMERA_CACHE = None
_FRAMING_CACHE = None



def _clothing_exposure_flags(clothing):
    """Heuristic chest / midriff / groin exposure from item states + categories."""
    removed = {"removed", "in_hand", "barefoot", "no panties", "no bra", "no top",
               "no skirt", "no dress", "no shirt", "no towel", "no robe"}
    chest = False
    midriff = False
    groin = False
    for it in clothing.get("items") or []:
        cur = (it.get("current_state") or "fully_worn").lower()
        cat = (it.get("category") or "").lower()
        name = (it.get("name") or it.get("item_id") or "").lower()
        is_off = cur in removed or cur.startswith("no ")
        # empty phrase also off
        if not is_off:
            for st in it.get("states") or []:
                if st.get("state_id") == cur and not (st.get("prompt_phrase") or "").strip():
                    is_off = True
        topish = any(k in cat or k in name for k in ("top", "shirt", "blouse", "crop", "tank", "dress", "bra", "towel", "robe", "gown"))
        bottomish = any(k in cat or k in name for k in ("short", "skirt", "pant", "brief", "panties", "thong", "jean", "bottom", "dress"))
        partial_chest = any(k in cur for k in (
            "lifted", "underbust", "neckline", "off_one_shoulder", "strap", "cup", "open", "unbuttoned", "pulled_aside", "slipping"
        ))
        if topish and is_off:
            chest = True
            midriff = True
        elif topish and partial_chest:
            chest = True
            if "crop" in name or "crop" in cat or "lifted" in cur or "underbust" in cur:
                midriff = True
        if bottomish and is_off:
            groin = True
        elif bottomish and any(k in cur for k in ("aside", "thigh", "knee", "pulled", "down", "open")):
            groin = True
        # crop tops always show midriff when worn
        if not is_off and ("crop" in name or "crop" in cat):
            midriff = True
    return chest, midriff, groin



def _camera_map():
    global _CAMERA_CACHE
    if _CAMERA_CACHE is None:
        _CAMERA_CACHE = {c.get("id"): c for c in load_cameras() if c.get("id")}
    return _CAMERA_CACHE


def _framing_map():
    global _FRAMING_CACHE
    if _FRAMING_CACHE is None:
        _FRAMING_CACHE = {f.get("id"): f for f in load_framing() if f.get("id")}
    return _FRAMING_CACHE


def resolve_camera(ref):
    """
    Resolve a camera reference (real camera from the camera database) to its
    technical prompt string.
    - ref matches a camera DB id  -> that camera's `tech` ("Canon EOS R5, ...")
    - ref matches a brand/model   -> that camera's `tech`
    - otherwise                   -> ref used as free-form text ("" stays "")
    """
    if not ref or not str(ref).strip():
        return "", ""
    ref = str(ref).strip()
    cams = _camera_map()
    if ref in cams:
        return cams[ref]["tech"], ref
    low = ref.lower()
    for cid, c in cams.items():
        brand = c.get("brand", "").lower()
        model = c.get("model", "").lower()
        full = f"{c.get('brand','')} {c.get('model','')}".lower()
        if low == brand or low == model or low == full or low in full:
            return c["tech"], cid
    return ref, ref


def resolve_framing(ref="", piece_type=""):
    """
    Resolve a framing reference (framing/angle/coverage/view) to its technical
    prompt string. Priority:
      1. explicit ref matches a framing DB id  -> that framing's `tech`
      2. explicit ref matches a framing name   -> that framing's `tech`
      3. no ref but piece_type has a default   -> that default's `tech`
      4. otherwise                             -> ref used as free-form text
    Returns (tech, ref_or_id).
    """
    framings = _framing_map()
    if ref and str(ref).strip():
        r = str(ref).strip()
        if r in framings:
            return framings[r]["tech"], r
        low = r.lower()
        for fid, f in framings.items():
            if f.get("name", "").lower() == low:
                return f["tech"], fid
        return r, r
    # auto-pick by piece type
    if piece_type:
        for f in framings.values():
            defaults = f.get("default_for_piece_types", [])
            if piece_type in defaults:
                return f["tech"], f["id"]
    return "", ""


class ShootPlanError(Exception):
    pass


# ---------------------------------------------------------------- parsing

def parse_plan_text(text):
    """Accept JSON or YAML. Raise ShootPlanError on failure."""
    if not text or not text.strip():
        raise ShootPlanError("plan is empty")
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    if yaml is not None:
        try:
            return yaml.safe_load(text)
        except Exception as e:
            raise ShootPlanError(f"YAML parse error: {e}")
    raise ShootPlanError(
        "Could not parse plan (JSON failed and PyYAML is not installed). "
        "Install pyyaml or export the plan as JSON."
    )


# ---------------------------------------------------------------- helpers
# ID-first lookup: every reference in a plan may be a machine id
# (zone_id / piece id / item_id) or a human name — ids win, names fall back,
# and substring matching keeps it forgiving. This is what lets plans stay
# compact and stable while prompt phrases live only in the data files.

def _find_item(clothing, ref):
    """Find an item by item_id (preferred) or name. Returns item dict or None."""
    target = str(ref).strip().lower()
    for it in clothing.get("items", []):
        iid = str(it.get("item_id", "")).lower()
        nm = str(it.get("name", "")).lower()
        if iid and (target == iid or target in iid):
            return it
        if nm and (target == nm or target in nm):
            return it
    return None


def _find_zone(location, ref):
    """Find a zone by zone_id (preferred) or name."""
    target = str(ref).strip().lower()
    for z in location.get("photo_zones", []):
        zid = str(z.get("zone_id", "")).lower()
        zn = str(z.get("name", "")).lower()
        if zid and (target == zid or target in zid):
            return z
        if zn and (target == zn or target in zn):
            return z
    return None


def _find_piece(zone, ref):
    """Find a piece by its id (preferred) or 'id | type' label."""
    target = str(ref).strip().lower()
    for p in zone.get("prompt_pieces", []):
        pid = str(p.get("id", "")).lower()
        plabel = f"{p.get('id', '')} | {p.get('type', '')}".lower()
        if pid and (target == pid or target in pid):
            return p
        if target == plabel or target in plabel:
            return p
    return None


def _set_item_state(item, state_id):
    ids = item_state_ids(item)
    if state_id in ids:
        item["current_state"] = state_id
        return True
    return False


def _all_items(clothing, state_idx):
    for it in clothing.get("items", []):
        ids = item_state_ids(it)
        if ids:
            it["current_state"] = ids[min(state_idx, len(ids) - 1)]


# ---------------------------------------------------------------- expansion

def expand_plan(data, base_seed=1, style=None, quality=None,
                detail="standard", auto_negative=True, negative_hints="",
                camera_override="", framing_override=""):
    """
    Validate + expand a parsed plan into fully-resolved shot dicts.
    Returns (shots, report_lines) where report_lines is a list of strings
    ("" for clean, otherwise validation notes per shot).
    """
    report = []

    model = (data.get("model") or "").strip()
    location_name = (data.get("location") or "").strip()
    clothing_name = (data.get("clothing_set") or data.get("clothing") or "").strip()
    title = data.get("title") or "Untitled shoot"
    style = style or data.get("style") or "custom"
    quality = quality or data.get("quality") or "default"
    quality_custom = data.get("quality_custom", "")
    detail = detail or data.get("detail_level") or "standard"
    auto_negative = auto_negative if data.get("auto_negative") is None else data["auto_negative"]
    negative_hints = negative_hints or data.get("negative_hints") or ""
    base_seed = int(data.get("seed", base_seed))
    camera_default = data.get("camera", "") or camera_override
    framing_default = data.get("framing", "") or framing_override
    erotic_level = (data.get("erotic_level") or "editorial").strip().lower()
    if erotic_level not in ("soft", "editorial", "explicit"):
        erotic_level = "editorial"

    if not model or not location_name or not clothing_name:
        raise ShootPlanError("plan must define 'model', 'location' and 'clothing_set'")

    mdata = load_json("models", model)
    if not mdata:
        mdata = {}
    mdata = dict(mdata)  # copy so we can stash UI flags
    mdata["_include_piercings"] = bool(data.get("_include_piercings") or mdata.get("_include_piercings"))
    mdata["_include_tattoos"] = bool(data.get("_include_tattoos") or mdata.get("_include_tattoos"))
    mdata["_tattoo_style"] = data.get("_tattoo_style") or mdata.get("_tattoo_style") or ""
    # Widget dropdowns: piercing / tattoo catalog ids → prompt overrides
    pier_id = (data.get("piercing") or "").strip()
    tat_id = (data.get("tattoo") or "").strip()
    mdata["_piercing_id"] = pier_id if pier_id not in ("", "none") else ""
    mdata["_tattoo_id"] = tat_id if tat_id not in ("", "none") else ""
    mdata["_piercing_override"] = ""
    mdata["_tattoo_override"] = ""
    if mdata["_piercing_id"]:
        mdata["_include_piercings"] = True
    if mdata["_tattoo_id"]:
        mdata["_include_tattoos"] = True
    # full override from ASB Load Model if provided
    if isinstance(data.get("_model_override"), dict):
        ov = data["_model_override"]
        mdata["_include_piercings"] = bool(ov.get("_include_piercings"))
        mdata["_include_tattoos"] = bool(ov.get("_include_tattoos"))
        mdata["_tattoo_style"] = ov.get("_tattoo_style") or ""
    ldata = load_json("locations", location_name)
    cdata = load_json("clothing", clothing_name)
    if not mdata:
        raise ShootPlanError(f"unknown model '{model}'")
    if not ldata:
        raise ShootPlanError(f"unknown location '{location_name}'")
    if not cdata or not cdata.get("items"):
        raise ShootPlanError(f"unknown clothing set '{clothing_name}'")

    mprompt, _ = build_model_prompt(mdata, detail)
    lighting = ldata.get("lighting", "soft natural light")
    quality_resolved = resolve_quality(quality, quality_custom)
    ident = mdata.get("name") or model

    raw_shots = data.get("shots") or []
    if not raw_shots:
        raise ShootPlanError("plan has no 'shots'")

    # -------- current outfit, carried across shots (ONE clothing set) --------
    clothing = copy.deepcopy(cdata)
    for it in clothing["items"]:
        ids = item_state_ids(it)
        it["current_state"] = ids[0] if ids else "fully_worn"

    shots = []
    for i, s in enumerate(raw_shots):
        idx = i
        try:
            _shot = _expand_one_shot(
                s, idx, ldata, cdata, clothing, mprompt, lighting,
                style, quality_resolved, detail, auto_negative, negative_hints,
                base_seed, ident, camera_default, framing_default,
                title, model, location_name, clothing_name, mdata,
                erotic_level=erotic_level,
            )
            shots.append(_shot)
            report.extend(_shot.get("_notes", []))
        except ShootPlanError as e:
            # isolate: skip this shot, keep the rest of the plan loadable
            report.append(f"ERROR shot {idx}: {e}")
            continue
        except Exception as e:
            report.append(f"ERROR shot {idx}: unexpected {type(e).__name__}: {e}")
            continue

    # -------- storyboard --------
    if not shots and report:
        story = ("NO VALID SHOTS — plan could not be expanded.\n"
                 "REPORT:\n" + "\n".join(report))
        return shots, report, story
    story = storyboard(shots)
    return shots, report, story



def _scenic_zone_desc(zone):
    """Zone text safe for prompts — strip developer/meta notes."""
    import re
    desc = (zone.get("description") or "").strip()
    desc = re.sub(r"Clothing-agnostic[^.]*\.", "", desc, flags=re.I)
    desc = re.sub(r"intimate pieces tagged[^.]*\.", "", desc, flags=re.I)
    desc = re.sub(r"min_level[^.]*\.", "", desc, flags=re.I)
    desc = re.sub(r"\s+", " ", desc).strip(" —,-")
    if not desc:
        desc = (zone.get("name") or zone.get("zone_id") or "").replace("_", " ")
    return desc

def _expand_one_shot(s, idx, ldata, cdata, clothing, mprompt, lighting,
                 style, quality_resolved, detail, auto_negative,
                 negative_hints, base_seed, ident, camera_default,
                 framing_default, title, model, location_name,
                 clothing_name, mdata, erotic_level="editorial"):
    """Expand a single shot; raises ShootPlanError on any bad reference.

    A plan uses ONE location + ONE clothing set for the whole shoot — this is
    what keeps a photo set consistent. (Per-shot overrides are NOT supported.)
    """
    notes = []
    zone_name = (s.get("zone") or "").strip()
    piece_label = (s.get("piece") or "").strip()
    erotic_level = (erotic_level or "editorial")
    if not zone_name:
        raise ShootPlanError("missing 'zone'")
    if not piece_label:
        raise ShootPlanError("missing 'piece'")

    zone = _find_zone(ldata, zone_name)
    if zone is None:
        raise ShootPlanError(f"shot {idx}: unknown zone '{zone_name}'")
    piece = _find_piece(zone, piece_label)
    if piece is None:
        raise ShootPlanError(
            f"shot {idx}: unknown piece '{piece_label}' in zone '{zone.get('name')}'")
    zname = zone.get("name", zone_name)
    plabel = f"{piece.get('id')} | {piece.get('type')}"

    # ---- outfit: explicit, transition, or inherit ----
    outfit_spec = s.get("outfit")
    transition = (s.get("transition") or "").strip()
    if outfit_spec is not None:
        if isinstance(outfit_spec, str):
            key = outfit_spec.strip().lower()
            if key in ("fully_worn", "worn", "dressed"):
                _all_items(clothing, 0)
            elif key in ("removed", "nude", "naked", "all off"):
                _all_items(clothing, -1)
            else:
                raise ShootPlanError(
                    f"shot {idx}: outfit string '{outfit_spec}' not a known "
                    "shortcut (use fully_worn / removed / a map)")
        elif isinstance(outfit_spec, dict):
            for item_name, state_id in outfit_spec.items():
                it = _find_item(clothing, item_name)
                if it is None:
                    raise ShootPlanError(
                        f"shot {idx}: outfit references unknown item '{item_name}'")
                if not _set_item_state(it, state_id):
                    raise ShootPlanError(
                        f"shot {idx}: item '{item_name}' has no state '{state_id}' "
                        f"(available: {', '.join(item_state_ids(it))})")
        else:
            raise ShootPlanError(f"shot {idx}: bad outfit spec")
    elif transition:
        _apply_transition(clothing, transition, idx, notes)

    # inherit = keep previous clothing state (default)

    # ---- camera (real body, common) / framing (per-shot) / note ----
    camera_ref = s.get("camera") or camera_default or ""
    camera, camera_id = resolve_camera(camera_ref)
    framing_ref = s.get("framing") or framing_default or ""
    framing, framing_id = resolve_framing(framing_ref, piece.get("type", ""))
    camera_technical = ", ".join(x for x in (camera, framing) if x)
    note = s.get("note") or ""
    level_override = s.get("level")
    level_id, level_name, removed_n = compute_level(clothing)

    if level_override and level_override != level_id:
        notes.append(f"note: requested level {level_override} but outfit gives {level_id}")
    if level_id not in piece.get("compatible_clothing_levels",
                                 ["level_0", "level_1", "level_2", "level_3", "level_4"]):
        notes.append(
            f"note: level {level_id} not in piece '{plabel}' compatible "
            "levels (piece may be blocked by the prompt)")

    # ---- per-shot prompt ----
    # Use shared clothing_phrases() so removed / off-body states are OMITTED.
    # Never put "completely removed…" in the positive prompt (ghost clothing).
    try:
        from .planner import clothing_phrases as _cp, clothing_off_negatives as _off
        clothing_phrases = _cp(clothing)
        clothing_off_neg = _off(clothing)
    except Exception:
        skip = {"removed", "barefoot"}  # in_hand kept as prop
        phrases = []
        for it in clothing.get("items", []):
            cur = it.get("current_state") or "fully_worn"
            if cur in skip or (isinstance(cur, str) and cur.startswith("no ")):
                continue
            for st in it.get("states", []):
                if st.get("state_id") == cur:
                    ph = (st.get("prompt_phrase") or "").strip()
                    low = ph.lower()
                    if (not ph or low.startswith("no ") or "not visible on the body" in low
                            or "completely removed" in low or "held in one hand" in low
                            or "held in hand" in low):
                        break
                    if ph:
                        phrases.append(ph)
                    break
        clothing_phrases = ", ".join(phrases)
        clothing_off_neg = ""
    # phase-wise model description for this shot's level (if the model defines
    # prompt_model_description), else the static mprompt
    try:
        from .levels import exposure_level
        _phase_lvl = exposure_level(clothing)
    except Exception:
        _phase_lvl = level_id
    pier_ov = (mdata.get("_piercing_override") or "").strip()
    tat_ov = (mdata.get("_tattoo_override") or "").strip()
    pier_id = (mdata.get("_piercing_id") or "").strip()
    tat_id = (mdata.get("_tattoo_id") or "").strip()
    chest_x, mid_x, groin_x = _clothing_exposure_flags(clothing)
    try:
        from .prompts import visible_body_regions
    except ImportError:
        from utils.prompts import visible_body_regions
    fr_ref = (s.get("framing") or "") + " " + (framing if isinstance(framing, str) else "")
    piece_pr = (piece.get("prompt") or "")
    visible = visible_body_regions(
        level=_phase_lvl, framing_ref=fr_ref, piece_prompt=piece_pr,
        chest_exposed=chest_x, groin_exposed=groin_x, midriff_exposed=mid_x,
    )
    mprompt_shot, _ = build_model_prompt(
        mdata, detail, level=_phase_lvl,
        include_piercings=bool(mdata.get("_include_piercings")) or bool(pier_ov) or bool(pier_id),
        include_tattoos=bool(mdata.get("_include_tattoos")) or bool(tat_ov) or bool(tat_id),
        tattoo_style=mdata.get("_tattoo_style") or "",
        piercing_override=pier_ov,
        tattoo_override=tat_ov,
        visible=visible,
        piercing_id=pier_id,
        tattoo_id=tat_id,
    )
    # Detailed place anchor — reduces model inventing random rooms/props
    scene_bits = []
    overall = (ldata.get("overall_description") or ldata.get("description") or "").strip()
    if overall:
        scene_bits.append(overall)
    zdesc = (zone.get("description") or "").strip()
    zlabel = (zone.get("name") or zone_name or "").strip()
    if zdesc:
        scene_bits.append(zdesc)
    elif zlabel:
        scene_bits.append(zlabel)
    # discourage drifting into other locations
    loc_name = (ldata.get("name") or "").strip()
    if loc_name and loc_name.lower() not in (overall or "").lower():
        scene_bits.insert(0, f"setting: {loc_name}")
    scene_phrase = ", ".join(scene_bits)

    # Strip framing conflicts inside pose text (e.g. "medium shot" vs full_body)
    piece_prompt = (piece.get("prompt") or "").strip()
    fr_ref = (s.get("framing") or framing_default or "").lower()
    if any(k in fr_ref for k in ("full_body", "wide", "negative_space", "environmental")):
        piece_prompt = re.sub(
            r",?\s*(extreme\s+)?(close-?up|medium shot|medium-full shot|waist-up|bust shot|headshot)\b",
            "",
            piece_prompt,
            flags=re.I,
        ).strip(" ,")
        if "full body" not in piece_prompt.lower() and "full figure" not in piece_prompt.lower():
            piece_prompt = (piece_prompt + ", full figure head to toe").strip(" ,")

    # Framing-specific negative helpers (anti crop)
    fr_neg = ""
    try:
        from ..utils.database import load_framing as _lf
        for fr in _lf():
            fid = (fr.get("id") or "").lower()
            if fid and fid in fr_ref.replace(" ", "_"):
                fr_neg = (fr.get("negative_helpers") or "").strip()
                break
            if (fr.get("name") or "").lower() in fr_ref:
                fr_neg = (fr.get("negative_helpers") or "").strip()
                break
    except Exception:
        fr_neg = ""
    if not fr_neg and any(k in fr_ref for k in ("full_body", "wide")):
        fr_neg = (
            "cropped feet, cropped head, cut off at knees, cut off at waist, close-up, "
            "face only, waist-up only, tight crop, missing feet"
        )
    merged_neg_hints = ", ".join(x for x in (negative_hints, fr_neg) if x)

    # Expression / erotic tone (never crash expand)
    expression_text = ""
    try:
        from .planner import expression_for_level, playful_expression
        import random as _rnd
        _rng = _rnd.Random(int(base_seed) + int(idx) * 17)
        try:
            expression_text = expression_for_level(level_id, rng=_rng, tone=erotic_level) or ""
            try:
                _lvn = int(str(level_id).split("_")[-1])
            except Exception:
                _lvn = 0
            if _lvn >= 2:
                expression_text = (expression_text + ", body language confident and unhurried, she owns the frame").strip(", ")
        except TypeError:
            expression_text = expression_for_level(level_id, rng=_rng) or ""
        if level_id in ("level_0", "level_1") and (_rng.random() < 0.08):
            try:
                play = playful_expression(rng=_rng)
            except Exception:
                play = ""
            if play:
                expression_text = play
        if erotic_level == "soft" and level_id == "level_4":
            try:
                expression_text = expression_for_level("level_3", rng=_rng, tone="soft") or expression_text
            except TypeError:
                pass
    except Exception:
        expression_text = ""

    try:
        final, neg = assemble_prompt(
            mprompt_shot, clothing_phrases, piece_prompt, lighting,
            style, quality_resolved, level=level_id,
            camera_technical=camera_technical, auto_negative=auto_negative,
            negative_hints=merged_neg_hints,
            clothing_off_neg=clothing_off_neg,
            scene_phrase=scene_phrase,
            expression_text=expression_text,
        )
    except TypeError:
        # Older prompts.py without expression_text kwarg
        final, neg = assemble_prompt(
            mprompt_shot, clothing_phrases, piece_prompt, lighting,
            style, quality_resolved, level=level_id,
            camera_technical=camera_technical, auto_negative=auto_negative,
            negative_hints=merged_neg_hints,
            clothing_off_neg=clothing_off_neg,
            scene_phrase=scene_phrase,
        )
        if expression_text:
            final = (expression_text + ", " + final).strip(", ")

    outfit_ids = {}
    outfit_names = {}
    for it in clothing["items"]:
        iid = it.get("item_id") or it.get("name") or "item"
        outfit_ids[iid] = it.get("current_state")
        outfit_names[it.get("name") or iid] = it.get("current_state")

    shot = {
        "index": idx,
        "title": title,
        "model": model,
        "location": location_name,
        "clothing_set": clothing_name,
        "zone_id": zone.get("zone_id") or zname,
        "zone": zname,
        "zone_description": _scenic_zone_desc(zone),
        "piece_id": piece.get("id") or "",
        "piece": plabel,
        "piece_prompt": piece.get("prompt", ""),
        "outfit": outfit_ids,          # machine contract: item_id -> state_id
        "outfit_names": outfit_names,  # human-readable mirror
        "level": level_id,
        "level_name": level_name,
        "removed_count": removed_n,
        "camera": camera,
        "camera_ref": camera_id or camera_ref,
        "framing": framing,
        "framing_ref": framing_id or framing_ref,
        "note": note,
        "seed": image_seed(base_seed, idx),
        "base_seed": base_seed,
        "filename_hint": f"{ident}_{idx:03d}_{_slug(zname)}_{_slug(piece.get('id',''))}",
        "model_prompt": mprompt_shot,
        "clothing_phrases": clothing_phrases,
        "lighting": lighting,
        "style": style,
        "quality": quality_resolved,
        "final_prompt": final,
        "negative_prompt": neg,
        "_notes": notes,
    }
    return shot


def _apply_transition(clothing, transition, idx, notes):
    t = transition.strip()
    low = t.lower()
    if low == "reset":
        for it in clothing["items"]:
            ids = item_state_ids(it)
            if ids:
                it["current_state"] = ids[0]
        return
    m = re.match(r"^(advance|undress|next|remove|dress|set|sequence)\s*:\s*(.*)$", t, re.I)
    if not m:
        raise ShootPlanError(
            f"shot {idx}: unknown transition '{t}' (use advance:/remove:/dress:/set:/sequence:/reset)")
    kind, arg = m.group(1).lower(), m.group(2).strip()

    if kind == "sequence":
        item_name = arg
        item = _find_item(clothing, item_name)
        if item is None:
            raise ShootPlanError(f"shot {idx}: sequence references unknown item '{item_name}'")
        ids = item_state_ids(item)
        cur = item.get("current_state")
        ci = ids.index(cur) if cur in ids else 0
        item["current_state"] = ids[min(ci + 1, len(ids) - 1)]
        return

    if kind == "set":
        parts = [p.strip() for p in re.split(r"->|→", arg)]
        if len(parts) != 2:
            raise ShootPlanError(f"shot {idx}: 'set:' needs 'Item -> state'")
        item_name, state_id = parts
        item = _find_item(clothing, item_name)
        if item is None:
            raise ShootPlanError(f"shot {idx}: set references unknown item '{item_name}'")
        if not _set_item_state(item, state_id):
            raise ShootPlanError(
                f"shot {idx}: item '{item_name}' has no state '{state_id}'")
        return

    item_name = arg
    item = _find_item(clothing, item_name)
    if item is None:
        raise ShootPlanError(f"shot {idx}: {kind} references unknown item '{item_name}'")
    ids = item_state_ids(item)
    cur = item.get("current_state")
    ci = ids.index(cur) if cur in ids else 0
    if kind in ("advance", "undress", "next"):
        item["current_state"] = ids[min(ci + 1, len(ids) - 1)]
        notes.append(f"note: {item.get('name')} advanced to '{item['current_state']}'")
    elif kind == "remove":
        item["current_state"] = ids[-1]
        notes.append(f"note: {item.get('name')} removed")
    elif kind == "dress":
        item["current_state"] = ids[max(ci - 1, 0)]
        notes.append(f"note: {item.get('name')} dressed back to '{item['current_state']}'")


def _slug(s):
    return re.sub(r"[^a-z0-9]+", "_", str(s).lower()).strip("_") or "x"


# ---------------------------------------------------------------- outputs

def storyboard(shots):
    """Monospace shot-list table (the director's call sheet)."""
    lines = []
    lines.append(f"SHOOT: {shots[0]['title'] if shots else ''}")
    lines.append(f"MODEL: {shots[0]['model'] if shots else ''}   "
                 f"LOCATION: {shots[0]['location'] if shots else ''}   "
                 f"WARDROBE: {shots[0]['clothing_set'] if shots else ''}")
    lines.append("")
    hdr = f"{'#':>3}  {'ZONE':<18} {'PIECE':<22} {'LEVEL':<7} {'FRAME':<12} OUTCOME"
    lines.append(hdr)
    lines.append("-" * len(hdr))
    for s in shots:
        items = ", ".join(f"{k}:{v}" for k, v in s.get("outfit_names", s["outfit"]).items())
        lines.append(
            f"{s['index']:>3}  {s['zone'][:18]:<18} {s['piece'][:22]:<22} "
            f"{s['level']:<7} {s.get('framing_ref','')[:12]:<12} {items}")
    return "\n".join(lines)


def shots_to_csv(shots):
    import io
    import csv

    out = io.StringIO()
    fields = ["index", "seed", "zone_id", "zone", "piece_id", "piece", "level",
              "framing", "outfit", "camera", "note", "filename_hint",
              "final_prompt", "negative_prompt"]
    w = csv.DictWriter(out, fieldnames=fields, lineterminator="\n")
    w.writeheader()
    for s in shots:
        row = {f: s.get(f, "") for f in fields}
        row["outfit"] = "; ".join(f"{k}={v}" for k, v in s.get("outfit", {}).items())
        w.writerow(row)
    return out.getvalue()
