"""
YAML prompt templates (v4).

A template defines the OUTPUT STRUCTURE of a prompt:

    name: editorial
    description: standard editorial structure
    joiner: ", "
    positive:
      - "{model_prompt}"
      - "{clothing_phrases}"
      - "{prompt_piece}"
      - "{lighting}"
      - "{style_positive}"
      - "{quality}"
      - "{camera_technical}"
    negative:
      - "{style_negative}"
      - "{level_negative}"
      - "{negative_hints}"

Placeholders are resolved from a context dict; missing ones become "" and
items that resolve to empty are dropped, so templates are flexible about
which inputs are wired. Templates live in data/templates/*.yaml and appear
automatically in the ASB Prompt Designer dropdown.
"""
import os

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

TEMPLATE_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "templates"
)

DEFAULT_TEMPLATE = "editorial"


def list_templates():
    if not os.path.isdir(TEMPLATE_DIR):
        return ["editorial"]
    names = [f[:-5] for f in sorted(os.listdir(TEMPLATE_DIR))
             if f.endswith(".yaml") or f.endswith(".yml")]
    return names or ["editorial"]


def load_template(name):
    """Return dict with keys: name, positive (list), negative (list), joiner."""
    for ext in (".yaml", ".yml"):
        path = os.path.join(TEMPLATE_DIR, f"{name}{ext}")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
            if yaml is not None:
                data = yaml.safe_load(text) or {}
            else:
                data = _fallback_parse(text)
            return {
                "name": data.get("name", name),
                "description": data.get("description", ""),
                "joiner": data.get("joiner", ", "),
                "positive": data.get("positive", ["{model_prompt}"]),
                "negative": data.get("negative", []),
            }
    # built-in fallback if the file is missing
    return {
        "name": name,
        "description": "",
        "joiner": ", ",
        "positive": ["{model_prompt}", "{clothing_phrases}", "{prompt_piece}",
                     "{lighting}", "{quality}"],
        "negative": [],
    }


def _fallback_parse(text):
    """Minimal YAML subset parser (used only if PyYAML is unavailable)."""
    data = {}
    section = None
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip())
        if indent == 0 and line.rstrip().endswith(":"):
            section = line.rstrip()[:-1].strip()
            data[section] = []
            continue
        if indent > 0 and line.strip().startswith("- "):
            if section:
                data[section].append(line.strip()[2:].strip().strip('"').strip("'"))
            continue
        if indent == 0 and ":" in line:
            k, v = line.split(":", 1)
            v = v.strip().strip('"').strip("'")
            if v:
                data[k.strip()] = v
    return data


class SafeFormat(dict):
    def __missing__(self, key):
        return ""


def render_template(template, context, positive=True):
    """Render positive (or negative) section. Returns joined string."""
    items = template["positive"] if positive else template["negative"]
    joiner = template.get("joiner", ", ")
    resolved = []
    ctx = SafeFormat(context)
    for item in items:
        try:
            val = item.format_map(ctx)
        except Exception:
            val = item
        if val and val.strip():
            val = val.strip()
            # trim a joiner left by an empty placeholder inside the item
            # (e.g. "cinematic composition, " when {camera_technical} is "")
            if joiner:
                toks = list(dict.fromkeys([joiner, joiner.strip()]))
                changed = True
                while changed:
                    changed = False
                    for tok in toks:
                        if tok and val.endswith(tok):
                            val = val[: -len(tok)].rstrip()
                            changed = True
                        if tok and val.startswith(tok):
                            val = val[len(tok):].lstrip()
                            changed = True
            if val:
                resolved.append(val)
    return joiner.join(resolved).strip()



def render_freeform(template_text: str, context: dict) -> str:
    """Render a Template-Builder style string with {{placeholders}}."""
    from .template_engine import TemplateEngine
    eng = TemplateEngine.from_text_template(template_text or "")
    return eng.render(context or {})


def render_section_template(name: str, context: dict) -> str:
    """Render a sections-YAML template by stem name."""
    from .template_engine import TemplateEngine
    return TemplateEngine(name).render(context or {})
