"""
Manifest helpers: turn generated prompts into a log you can export as
CSV / JSON / per-image caption files.

Used by the ASB_Manifest node and by scripts/generate_manifest.py
"""

import csv
import io
import json
from datetime import datetime

FIELDS = [
    "index",
    "timestamp",
    "seed",
    "filename_hint",
    "tags",
    "prompt",
    "negative_prompt",
]


def make_entry(index, seed, prompt, negative_prompt="", filename_hint="", tags="",
               timestamp=None):
    return {
        "index": index,
        "timestamp": timestamp or datetime.now().isoformat(timespec="seconds"),
        "seed": seed,
        "filename_hint": filename_hint,
        "tags": tags,
        "prompt": prompt,
        "negative_prompt": negative_prompt,
    }


def to_csv(entries):
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=FIELDS, lineterminator="\n")
    writer.writeheader()
    for e in entries:
        writer.writerow({f: e.get(f, "") for f in FIELDS})
    return out.getvalue()


def to_json(entries):
    return json.dumps(entries, ensure_ascii=False, indent=2)


def safe_filename(s, max_len=64):
    s = "".join(c if c.isalnum() or c in "._-" else "_" for c in str(s).strip().lower())
    return s[:max_len] or "img"


def caption_files(entries, caption_dir, negative=True):
    """
    Write one .txt caption file per entry in the classic SD-style format:

        prompt text
        (blank line)
        negative prompt text   (only when negative=True)
    """
    import os

    os.makedirs(caption_dir, exist_ok=True)
    paths = []
    for e in entries:
        hint = e.get("filename_hint") or f"img_{e['index']:04d}"
        path = os.path.join(caption_dir, f"{safe_filename(hint)}.txt")
        body = e.get("prompt", "")
        if negative and e.get("negative_prompt"):
            body += f"\n\n{e['negative_prompt']}"
        with open(path, "w", encoding="utf-8") as f:
            f.write(body)
        paths.append(path)
    return paths
