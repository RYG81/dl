"""
Data validation for the whole pack.

Runs a set of structural checks over every JSON file in data/ and returns a
list of issues. Used by the ASB_ValidateData node and scripts/validate.py.

Checks:
  - every file parses as JSON
  - models: name + age present, hair/face/skin blocks well-formed
  - locations: name + photo_zones present, zones have unique names,
    prompt pieces have unique ids, types, prompts, valid level refs
  - clothing: items present, item names unique, state ids unique per item,
    first state exists, current_state is a valid state id,
    level_config references only real state ids
"""

import json
import os

REQUIRED_MODEL_KEYS = ["name", "age", "body_type", "hair", "face", "overall_vibe"]
VALID_LEVELS = {"level_0", "level_1", "level_2", "level_3", "level_4"}


def load_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def validate_models(data_dir, issues):
    folder = os.path.join(data_dir, "models")
    if not os.path.isdir(folder):
        issues.append({"file": "models/", "level": "warn", "message": "models folder missing"})
        return
    for fn in sorted(os.listdir(folder)):
        if not fn.endswith(".json"):
            continue
        path = os.path.join(folder, fn)
        try:
            d = load_file(path)
        except Exception as e:
            issues.append({"file": f"models/{fn}", "level": "error", "message": f"not valid JSON: {e}"})
            continue
        for key in REQUIRED_MODEL_KEYS:
            if key not in d:
                issues.append({"file": f"models/{fn}", "level": "warn", "message": f"missing key '{key}'"})
        if d.get("age") is not None and not isinstance(d.get("age"), int):
            issues.append({"file": f"models/{fn}", "level": "warn", "message": "'age' should be an int"})


def validate_locations(data_dir, issues):
    folder = os.path.join(data_dir, "locations")
    if not os.path.isdir(folder):
        issues.append({"file": "locations/", "level": "warn", "message": "locations folder missing"})
        return
    for fn in sorted(os.listdir(folder)):
        if not fn.endswith(".json"):
            continue
        path = os.path.join(folder, fn)
        try:
            d = load_file(path)
        except Exception as e:
            issues.append({"file": f"locations/{fn}", "level": "error", "message": f"not valid JSON: {e}"})
            continue
        if not d.get("name"):
            issues.append({"file": f"locations/{fn}", "level": "error", "message": "missing 'name'"})
        zones = d.get("photo_zones", [])
        if not zones:
            issues.append({"file": f"locations/{fn}", "level": "error", "message": "no photo_zones"})
        zone_names = set()
        piece_ids = set()
        for z in zones:
            name = z.get("name")
            if not name:
                issues.append({"file": f"locations/{fn}", "level": "error", "message": "zone missing 'name'"})
            elif name in zone_names:
                issues.append({"file": f"locations/{fn}", "level": "error", "message": f"duplicate zone name '{name}'"})
            zone_names.add(name)
            pieces = z.get("prompt_pieces", [])
            if not pieces:
                issues.append({"file": f"locations/{fn}", "level": "warn", "message": f"zone '{name}' has no prompt_pieces"})
            for p in pieces:
                pid = p.get("id")
                if not pid:
                    issues.append({"file": f"locations/{fn}", "level": "error", "message": f"piece in '{name}' missing 'id'"})
                elif pid in piece_ids:
                    issues.append({"file": f"locations/{fn}", "level": "error", "message": f"duplicate piece id '{pid}'"})
                piece_ids.add(pid)
                if not p.get("type"):
                    issues.append({"file": f"locations/{fn}", "level": "warn", "message": f"piece '{pid}' missing 'type'"})
                if not p.get("prompt"):
                    issues.append({"file": f"locations/{fn}", "level": "warn", "message": f"piece '{pid}' missing 'prompt'"})
                for lv in p.get("compatible_clothing_levels", []):
                    if lv not in VALID_LEVELS:
                        issues.append({"file": f"locations/{fn}", "level": "error",
                                       "message": f"piece '{pid}' references invalid level '{lv}'"})


def validate_clothing(data_dir, issues):
    folder = os.path.join(data_dir, "clothing")
    if not os.path.isdir(folder):
        issues.append({"file": "clothing/", "level": "warn", "message": "clothing folder missing"})
        return
    for fn in sorted(os.listdir(folder)):
        if not fn.endswith(".json"):
            continue
        path = os.path.join(folder, fn)
        try:
            d = load_file(path)
        except Exception as e:
            issues.append({"file": f"clothing/{fn}", "level": "error", "message": f"not valid JSON: {e}"})
            continue
        items = d.get("items", [])
        if not items:
            issues.append({"file": f"clothing/{fn}", "level": "error", "message": "no 'items'"})
        item_names = set()
        all_state_ids = set()
        for it in items:
            name = it.get("name")
            if not name:
                issues.append({"file": f"clothing/{fn}", "level": "error", "message": "item missing 'name'"})
            elif name in item_names:
                issues.append({"file": f"clothing/{fn}", "level": "error", "message": f"duplicate item name '{name}'"})
            item_names.add(name)
            states = it.get("states", [])
            if not states:
                issues.append({"file": f"clothing/{fn}", "level": "error",
                               "message": f"item '{name}' has no states"})
                continue
            state_ids = [s.get("state_id") for s in states]
            if any(not sid for sid in state_ids):
                issues.append({"file": f"clothing/{fn}", "level": "error",
                               "message": f"item '{name}' has a state without 'state_id'"})
            if len(state_ids) != len(set(state_ids)):
                issues.append({"file": f"clothing/{fn}", "level": "error",
                               "message": f"item '{name}' has duplicate state ids"})
            for s in states:
                if not s.get("prompt_phrase"):
                    issues.append({"file": f"clothing/{fn}", "level": "warn",
                                   "message": f"item '{name}' state '{s.get('state_id')}' missing 'prompt_phrase'"})
            all_state_ids.update(state_ids)
            cur = it.get("current_state")
            if cur is not None and cur not in state_ids:
                issues.append({"file": f"clothing/{fn}", "level": "error",
                               "message": f"item '{name}' current_state '{cur}' not in states"})
        cfg = d.get("level_config")
        if cfg:
            for sid in cfg.get("removed_states", []):
                if sid not in all_state_ids:
                    issues.append({"file": f"clothing/{fn}", "level": "warn",
                                   "message": f"level_config.removed_states '{sid}' not used by any item"})
            th = cfg.get("thresholds", [])
            if len(th) != 5:
                issues.append({"file": f"clothing/{fn}", "level": "warn",
                               "message": "level_config.thresholds should have 5 values"})


def validate_all(data_dir=None):
    if data_dir is None:
        data_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data"
        )
    issues = []
    # also validate any external data folders configured by the user
    try:
        from .database import extra_dirs
        for d in extra_dirs():
            issues.append({"file": f"extra:{d}", "level": "note",
                           "message": "validating external data folder"})
            validate_models(d, issues)
            validate_locations(d, issues)
            validate_clothing(d, issues)
    except Exception:
        pass
    validate_models(data_dir, issues)
    validate_locations(data_dir, issues)
    validate_clothing(data_dir, issues)
    return issues


def format_report(issues):
    """Human-readable report string."""
    if not issues:
        return "All data files OK ({} checks passed).".format(
            "no issues")
    lines = []
    for i, iss in enumerate(issues, 1):
        lines.append(f"{i:3d}. [{iss['level'].upper():5s}] {iss['file']}: {iss['message']}")
    errors = sum(1 for i in issues if i["level"] == "error")
    warns = sum(1 for i in issues if i["level"] == "warn")
    lines.append(f"\n{len(issues)} issue(s): {errors} error(s), {warns} warning(s)")
    return "\n".join(lines)
