"""
Server-side plan storage: plans live in ComfyUI's user directory under
`asb_plans/` so they persist across browser sessions and machines.

The ComfyUI HTTP routes live in the pack's __init__.py; this module is pure
file logic (no ComfyUI imports) so it can be unit-tested standalone and used
by scripts.
"""
import os
import re

SUB = "asb_plans"
EXTENSIONS = (".yaml", ".yml", ".json", ".txt")

# test hook: set to a temp dir to override the default user directory
USER_DIR_OVERRIDE = None


def user_dir():
    if USER_DIR_OVERRIDE:
        return USER_DIR_OVERRIDE
    try:
        import folder_paths  # ComfyUI
        getter = getattr(folder_paths, "get_user_directory", None)
        if callable(getter):
            return getter()
        return os.path.join(folder_paths.base_path, "user")
    except Exception:
        return os.path.join(os.getcwd(), "user")


def plans_dir():
    d = os.path.join(user_dir(), SUB)
    os.makedirs(d, exist_ok=True)
    return d


def safe_name(name):
    """Sanitize a filename: basename only, safe chars, enforce an extension."""
    name = os.path.basename(str(name).strip()) or "plan"
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", name)
    if not name.lower().endswith(EXTENSIONS):
        name += ".yaml"
    return name[:120]


def list_plans():
    d = plans_dir()
    files = sorted(f for f in os.listdir(d) if f.lower().endswith(EXTENSIONS))
    return files, d


def read_plan(name):
    path = os.path.join(plans_dir(), safe_name(name))
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def write_plan(name, content):
    path = os.path.join(plans_dir(), safe_name(name))
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def delete_plan(name):
    path = os.path.join(plans_dir(), safe_name(name))
    if os.path.isfile(path):
        os.remove(path)
        return True
    return False
