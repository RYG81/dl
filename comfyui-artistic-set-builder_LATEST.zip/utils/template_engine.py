"""Section-based template engine ({{placeholders}}, conditions, post_process).

Supports YAML templates with a `sections` list — used by the Template Builder
widget. Existing list-style templates (positive/negative arrays) stay in
prompt_templates.py.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "data" / "templates"


class TemplateEngine:
    """Load a YAML template, render it with a context dict."""

    def __init__(self, template_name: str = "editorial_sections"):
        path = TEMPLATES_DIR / f"{template_name}.yaml"
        if not path.exists():
            path = TEMPLATES_DIR / f"{template_name}.yml"
        if not path.exists():
            raise FileNotFoundError(f"Template not found: {path}")
        text = path.read_text(encoding="utf-8")
        if yaml is None:
            raise RuntimeError("PyYAML required for section templates")
        self._tmpl = yaml.safe_load(text) or {}
        self._sections = self._tmpl.get("sections") or []
        self._post = self._tmpl.get("post_process") or []
        self.name = self._tmpl.get("name") or template_name

    @classmethod
    def from_dict(cls, data: dict) -> "TemplateEngine":
        obj = object.__new__(cls)
        obj._tmpl = data or {}
        obj._sections = obj._tmpl.get("sections") or []
        obj._post = obj._tmpl.get("post_process") or []
        obj.name = obj._tmpl.get("name") or "inline"
        return obj

    @classmethod
    def from_text_template(cls, text: str) -> "TemplateEngine":
        """Wrap a free-form {{placeholder}} string from the Template Builder."""
        return cls.from_dict({
            "name": "custom",
            "sections": [{
                "id": "body",
                "label": "",
                "template": text,
                "gap_after": False,
            }],
            "post_process": [
                {"action": "regex_replace", "pattern": r" +", "replacement": " "},
                {"action": "regex_replace", "pattern": r"\n{3,}", "replacement": "\n\n"},
            ],
        })

    def render(self, context: Dict[str, Any]) -> str:
        parts: List[str] = []
        for sec in self._sections:
            cond = sec.get("condition")
            if cond:
                if not context.get(cond, ""):
                    fallback_id = sec.get("fallback")
                    if fallback_id:
                        for s in self._sections:
                            if s.get("id") == fallback_id and "condition" not in s:
                                parts.append(self._render_section(s, context))
                                break
                    continue

            if sec.get("optional"):
                key = sec.get("id") or ""
                if key and not str(context.get(key, "")).strip():
                    continue

            parts.append(self._render_section(sec, context))

        raw = "".join(parts)

        for pp in self._post:
            if isinstance(pp, dict):
                action = pp.get("action", "replace")
                pattern = pp.get("pattern", "")
                replacement = pp.get("replacement", "")
                if action == "replace":
                    raw = raw.replace(pattern, replacement)
                elif action == "regex_replace":
                    raw = re.sub(pattern, replacement, raw)
            elif isinstance(pp, (list, tuple)) and len(pp) == 2:
                raw = raw.replace(pp[0], pp[1])

        # strip leftover empty placeholders
        raw = re.sub(r"\{\{\w+\}\}", "", raw)
        raw = re.sub(r"[ \t]+\n", "\n", raw)
        raw = re.sub(r"\n{3,}", "\n\n", raw)
        raw = re.sub(r" {2,}", " ", raw)
        return raw.strip()

    def _render_section(self, sec: dict, ctx: dict) -> str:
        label = sec.get("label") or ""
        template = sec.get("template") or ""
        gap = "\n\n" if sec.get("gap_after") else ""

        def repl(m):
            key = m.group(1)
            val = ctx.get(key, "")
            return str(val) if val is not None else ""

        rendered = re.sub(r"\{\{(\w+)\}\}", repl, template)
        return f"{label}{rendered}{gap}"


def list_section_templates() -> List[str]:
    if not TEMPLATES_DIR.is_dir():
        return []
    out = []
    for p in sorted(TEMPLATES_DIR.glob("*.yaml")):
        try:
            data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        except Exception:
            continue
        if isinstance(data, dict) and data.get("sections"):
            out.append(p.stem)
    return out
