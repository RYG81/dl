# Location Quality Standard (200-shot target)

Full system prompt: `LOCATION_DATABASE.md`

## Numbers
| Item | Min | Ideal |
|------|-----|-------|
| Zones | 4 | 4–5 |
| Pieces per zone | **35** | 40–50 |
| Total pieces | **140** | 160–250 |
| `target_shot_count` | 200 | 200 |
| Upright kneel per zone | **≤2** | 0–1 |

## Pose mix per zone
- Standing / walk 30–40%
- Sit / edge / straddle 20–25%
- Recline / lie 15–20%
- All-fours / dynamic 5–10% (side view, not upright kneel)
- Beauty / glamour 8–12%
- Intimate level_4 15–20%

## Prompt rules
1. One concrete pose — no “or”
2. Name the physical support
3. Full body / medium-full + negative space
4. Specific hands + gaze
5. Angle variety (front / 3/4 / profile / rear lookback)
6. No clothing words in pose text
7. No broken phrases (`the the`, `in the a`)

## Workflow
One location JSON at a time → verify Auto 200 → next.
