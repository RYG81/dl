# System prompts

| File | Use when | Output |
|------|----------|--------|
| `MODEL_DATABASE.md` | Create / rewrite a **model** identity | One model JSON |
| `LOCATION_DATABASE.md` | Create / upgrade a **location** (Tier-A) | One location JSON |
| `CLOTHING_DATABASE.md` | Create / rewrite an **outfit** | One clothing JSON |
| `LOCATION_QUALITY_STANDARD.md` | Quick numbers checklist for locations | Reference |
| `TEXT_TO_DATABASE.md` | Text brief → model + location + clothing pack | Multi JSON |
| `TEXT_TO_PROMPTS.md` | Text brief → final shot prompts | Prompt list |
| `PHOTOSET_TO_DATABASE.md` | Real photoset images → databases | Multi JSON |
| `PROMPT_QUALITY_NOTES.md` | Why weak prompts fail | Notes |

## How to use

1. Paste the chosen `.md` body as the **system** message.  
2. User message = brief, roster constraints, or JSON to upgrade.  
3. Model must return **JSON only** (except prompt-list modes).

## Current quality bar

- **Models:** unique hair, eyes, breasts, pussy, ass, perianal; `prompt_model_description` densed from fields.  
- **Locations:** 4–6 zones, 32–36 editorial + 28 explicit pieces/zone, `framing` + `camera_angle` on every piece.  
- **Clothing:** multi-state undress_order, detailed `prompt_phrase` per state, one-item-at-a-time sequence.
