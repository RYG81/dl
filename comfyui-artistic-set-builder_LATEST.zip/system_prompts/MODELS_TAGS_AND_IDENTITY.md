# Models tag coverage (EliteBabes-inspired dimensions)

We do **not** copy real model identities. Every entry is a fictional adult (22+) identity sheet.

## Tag axes we cover

| Axis | Values in DB |
|------|----------------|
| Ethnicity | Latina, East Asian, SE Asian, South Asian, African/AA, East African, Middle Eastern, Scandinavian, N/S/W European, Mixed |
| Hair | platinum/dirty/honey blonde, copper red, jet black, dark/chocolate/ash brown, short pixie, curls, braids, waves |
| Body | petite, slim, athletic, tall athletic, hourglass, curvy, thick/soft, mature soft |
| Breasts | petite, small, small-medium, medium, athletic medium, full + puffy nipple variants |
| Pubic | fully shaved, landing strip, triangle, trimmed short, soft natural bush |
| Misc | freckles, glasses, mature (30+), girl-next-door, elegant, sultry |

## How unique AI faces stay unique (research summary)

Sites and creators that invent people who never existed usually combine:

1. **Identity sheet (what we already do)**  
   Fixed name + face geometry + hair + skin + body tokens repeated in every prompt.  
   Vague prompts drift; locked descriptors hold ~60–70% alone.

2. **Reference lock (stronger)**  
   IP-Adapter / FaceID / InstantID with 1–3 reference portraits.  
   Face embedding is injected at generation time — best practical consistency without training.

3. **Character LoRA (production)**  
   Train a small LoRA on 15–30 curated images of one identity.  
   Highest consistency (90%+) across poses and outfits.

4. **Seed + template discipline**  
   Same seed helps short series; still drifts on big pose changes.  
   Always put identity block first and last in the prompt (attention peaks).

5. **What does *not* work alone**  
   Only changing the name, or “beautiful woman” with no anchors — model invents a new face every time.

**ASB recommendation:** keep expanding identity sheets (done here); for pixel-perfect same-face across 200 shots, add FaceID/IP-Adapter or a per-model LoRA in the Comfy graph later.
