# Krea 2 photorealism for ASB

## Prompt rules that matter on Krea 2

1. **Natural language sentences**, not SD1.5 tag soup.
2. **Do not use** `(word:1.5)` weighting — ignored / can hurt.
3. **Quality spam is dead weight:** `masterpiece, best quality, 8k, ultra detailed, score_9`.
4. **Order:** subject + action → place → camera/framing → **light (source + direction + quality)** → material/skin → medium.
5. **Negatives are weak** on Krea 2 — put energy into positive light + material wording.
6. **Length:** ~30–120 words of clear clauses beats 300 words of adjectives.

## Tokens / phrases that improve photoreal skin & photo feel

**Prefer**
- natural unretouched skin
- visible skin pores
- fine skin microtexture / peach fuzz / vellus hair (sparingly)
- soft subsurface scattering
- natural skin sheen (not oily glare)
- documentary photography / real photograph
- available light / soft window light from the left
- shallow depth of field
- 85mm portrait lens look / 50mm
- slight film grain / low dynamic range
- fabric weave, linen texture, denim texture (when clothed)

**Avoid / negative-side (if your pipeline supports negs)**
- airbrushed, plastic skin, waxy, over-retouched, beauty filter
- CGI, 3D render, illustration
- oversmooth featureless skin

**Light is the biggest lever**
Bad: `cinematic lighting`
Good: `soft daylight from large French doors, gentle fill from white walls, natural falloff`

## Recommended stack (Comfy)

| Piece | Role | Notes |
|-------|------|--------|
| **Krea 2 RAW** + Turbo LoRA ~0.6 | Base photoreal | Often better than Turbo checkpoint alone |
| **Krea 2 Realistic Skin Texture** | Pores / unretouched skin | Trigger: `inline-skin-lora, detailed skin texture` · strength 0.6–1.0 |
| **Realism by Stable Yogi Krea2** | Broad realism fine-tune | Skin + light |
| **CyberRealistic Krea 2** | Photographic default | Natural language prompts |
| **Famegrid Krea 2** | Modern photo / influencer realism | Keep moderate if stacking character LoRAs |
| **Lenovo UltraReal (Krea2)** | Texture + light | Author suggests ~0.8 on RAW |
| **IntoRealism Krea 2** | Photoreal + NSFW-capable | Fine-tune |
| **HMBody (Krea2)** | Nude body anatomy realism | Trigger `HMBody` · strength often 1.5–2.0 — test |
| **Vector Bypass / anti-censorship** | Prompt adherence | Community workflows recommend even for SFW |

**Pose / body (model-family dependent)**  
- Older “Nude women in more poses” style LoRAs were often **Flux/SD** — only use if a **Krea 2** version exists.  
- Prefer **HMBody** or Krea2-native body LoRAs over cross-architecture ports.

## ASB quality tail (MetArt-oriented, Krea2-friendly)

```
natural unretouched skin with visible pores and fine texture, soft subsurface scattering,
shot like a real photograph on an 85mm lens, shallow depth of field, sharp eyes,
soft background falloff, available light with clear source and direction
```

Do **not** append `8k, ultra realistic, masterpiece`.
