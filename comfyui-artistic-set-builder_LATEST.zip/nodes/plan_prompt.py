import json


class ASB_PlanPrompt:
    """
    Pull one image definition out of a plan by index.

    Connect plan_json from ASB Set Plan and an index (e.g. from ASB Batch
    Index) to render one image of the set: final prompt, negative prompt,
    the image's own deterministic seed, filename hint and full metadata.

    Out-of-range indexes clamp to the nearest valid entry.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "plan": ("STRING", {"forceInput": True}),
                "index": ("INT", {"default": 0, "min": 0, "max": 1000000}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "INT", "STRING", "STRING", "INT")
    RETURN_NAMES = ("final_prompt", "negative_prompt", "seed",
                    "filename_hint", "meta_json", "index")
    FUNCTION = "pick"
    CATEGORY = "ArtisticSetBuilder/Generation"

    def pick(self, plan, index):
        try:
            entries = json.loads(plan) if isinstance(plan, str) else plan
        except Exception:
            entries = []
        if not entries:
            return ("(empty plan)", "", 0, "", "{}", 0)
        idx = max(0, min(int(index), len(entries) - 1))
        e = entries[idx]
        return (e.get("final_prompt", ""),
                e.get("negative_prompt", ""),
                int(e.get("seed", 0)),
                e.get("filename_hint", ""),
                json.dumps(e, ensure_ascii=False),
                idx)
