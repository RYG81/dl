import copy
import random

from ..utils.levels import (
    compute_level,
    item_state_ids,
    max_reachable_level,
)
from .clothing_loader import item_labels


def _clamp_level(target, max_id):
    """Keep target level inside [level_0, max_id]."""
    max_idx = int(max_id.split("_")[1])
    idx = max(0, min(target, max_idx))
    return f"level_{idx}"


class ASB_RandomizeSet:
    """
    Seeded randomizer: picks a zone, a compatible prompt piece and a clothing
    combination at a target level. Same seed + same inputs = same result, so
    whole image sets are reproducible.

    Set zone_name to a specific zone to lock the zone and randomize the rest.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "location": ("ASB_LOCATION",),
                "clothing": ("ASB_CLOTHING",),
                "seed": ("INT", {"default": 1, "min": 0, "max": 0x7FFFFFFF}),
                "min_level": ("INT", {"default": 0, "min": 0, "max": 4, "step": 1}),
                "max_level": ("INT", {"default": 4, "min": 0, "max": 4, "step": 1}),
            },
            "optional": {
                "zone_name": ("STRING", {"default": ""}),
            },
        }

    RETURN_TYPES = ("ASB_ZONE", "STRING", "STRING", "STRING", "ASB_CLOTHING",
                    "STRING", "INT", "STRING", "STRING")
    RETURN_NAMES = ("zone", "zone_name", "prompt_piece", "selected",
                    "clothing", "level", "seed_used", "clothing_phrases",
                    "available_items")
    FUNCTION = "randomize"
    CATEGORY = "ArtisticSetBuilder"

    def randomize(self, location, clothing, seed, min_level, max_level,
                  zone_name=""):
        rng = random.Random(seed)

        zones = location.get("photo_zones", [])
        if zone_name and zone_name.strip():
            zname = zone_name.strip().lower()
            zones = [z for z in zones
                     if zname in z.get("name", "").lower()
                     or zname in z.get("zone_id", "").lower()] or zones
        if not zones:
            return ({}, "empty", "standing naturally, looking at camera",
                    "none", clothing, "level_0", seed, "", "(no zones)")

        zone = rng.choice(zones)

        # clamp the level range to what this clothing set can actually reach
        max_id = max_reachable_level(clothing)
        max_idx = int(max_id.split("_")[1])
        lo = max(0, min(min_level, max_idx))
        hi = max(lo, min(max_level, max_idx))
        target_idx = rng.randint(lo, hi)
        target_level = f"level_{target_idx}"

        # pick a piece compatible with the target level
        pieces = [p for p in zone.get("prompt_pieces", [])
                  if target_level in p.get("compatible_clothing_levels",
                                           ["level_0", "level_1", "level_2",
                                            "level_3", "level_4"])]
        piece = rng.choice(pieces) if pieces else rng.choice(zone.get("prompt_pieces", []))
        piece_label = f"{piece.get('id')} | {piece.get('type')}"
        piece_prompt = piece.get("prompt", "")

        # random clothing combination that lands exactly on the target level
        new_clothing = copy.deepcopy(clothing)
        items = new_clothing.get("items", [])
        achieved = None
        for _ in range(600):
            for item in items:
                ids = item_state_ids(item)
                if ids:
                    item["current_state"] = rng.choice(ids)
            achieved = compute_level(new_clothing)[0]
            if achieved == target_level:
                break

        if achieved != target_level:
            # deterministic fallback: remove exactly `target_idx` items
            ordered = sorted(items, key=lambda it: len(item_state_ids(it)))
            for i, item in enumerate(ordered):
                ids = item_state_ids(item)
                item["current_state"] = ids[-1] if i < target_idx else ids[0]

        level_id, _, _ = compute_level(new_clothing)

        skip = {"removed", "barefoot"}
        phrases = []
        for item in items:
            cur = item.get("current_state") or "fully_worn"
            if cur in skip or str(cur).startswith("no "):
                continue
            for st in item.get("states", []):
                if st.get("state_id") == cur:
                    ph = (st.get("prompt_phrase") or "").strip()
                    low = ph.lower()
                    if low.startswith("no ") or "not visible on the body" in low:
                        break
                    if ph:
                        phrases.append(ph)
                    break

        return (zone, zone.get("name", "zone"), piece_prompt, piece_label,
                new_clothing, level_id, seed,
                ", ".join(phrases), item_labels(new_clothing))
