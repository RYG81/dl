from ..utils.database import get_model_list, load_json
from ..utils.prompts import build_model_prompt

DETAIL_LEVELS = ["standard", "detailed", "minimal"]
TATTOO_STYLES = ["(model default)", "none", "rib_floral", "shoulder_script", "ankle_fine", "spine_minimal"]


class ASB_LoadModel:
    """
    Load a model from data/models/*.json.

    detail_level:
      standard - face, hair, body type, vibe
      detailed - + skin, breasts, anatomy blocks when not using phase text
      minimal  - name, age, vibe only

    include_piercings / include_tattoos:
      Optional body accessories. Off by default so every model stays clean
      unless the user enables them. Tattoo style picks from the model's
      options table (or model default prompt).
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": (get_model_list(),),
            },
            "optional": {
                "detail_level": (DETAIL_LEVELS, {"default": "detailed"}),
                "include_piercings": ("BOOLEAN", {"default": False}),
                "include_tattoos": ("BOOLEAN", {"default": False}),
                "tattoo_style": (TATTOO_STYLES, {"default": "(model default)"}),
            },
        }

    RETURN_TYPES = ("ASB_MODEL", "STRING", "STRING")
    RETURN_NAMES = ("model", "model_prompt", "identity_token")
    FUNCTION = "load"
    CATEGORY = "ArtisticSetBuilder"

    def load(self, model, detail_level="detailed", include_piercings=False,
             include_tattoos=False, tattoo_style="(model default)"):
        data = load_json("models", model)
        if not data:
            return ({}, "unknown model", model)

        # Stash UI choices on the model dict so plan/prompt nodes can reuse them
        data = dict(data)  # shallow copy — do not mutate the cached JSON
        data["_include_piercings"] = bool(include_piercings)
        data["_include_tattoos"] = bool(include_tattoos)
        style = "" if tattoo_style in ("(model default)", "none", "") else tattoo_style
        if tattoo_style == "none":
            data["_include_tattoos"] = False
        data["_tattoo_style"] = style

        prompt, token = build_model_prompt(
            data,
            detail_level=detail_level,
            include_piercings=data["_include_piercings"],
            include_tattoos=data["_include_tattoos"],
            tattoo_style=style,
        )
        return (data, prompt, token)
