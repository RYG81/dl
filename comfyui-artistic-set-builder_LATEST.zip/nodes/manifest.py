from ..utils import manifest as mf


class ASB_Manifest:
    """
    Accumulates one log entry per execution (seed, prompt, negative prompt,
    filename hint, tags) and exports the run as CSV / JSON text.

    Connect `reset = True` (or use a primitive toggle) to clear the log.
    Outputs are text so you can write them to disk with a text-save node.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "final_prompt": ("STRING", {"forceInput": True}),
            },
            "optional": {
                "negative_prompt": ("STRING", {"forceInput": True, "default": ""}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0x7FFFFFFF}),
                "filename_hint": ("STRING", {"default": ""}),
                "tags": ("STRING", {"default": ""}),
                "reset": ("BOOLEAN", {"default": False}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "INT")
    RETURN_NAMES = ("manifest_csv", "manifest_json", "last_entry", "count")
    FUNCTION = "log"
    CATEGORY = "ArtisticSetBuilder"

    def __init__(self):
        self.entries = []

    def log(self, final_prompt, negative_prompt="", seed=0, filename_hint="",
            tags="", reset=False):
        if reset:
            self.entries = []

        entry = mf.make_entry(
            index=len(self.entries) + 1,
            seed=seed,
            prompt=final_prompt,
            negative_prompt=negative_prompt,
            filename_hint=filename_hint,
            tags=tags,
        )
        self.entries.append(entry)

        last = (f"[{entry['index']}] seed={entry['seed']} "
                f"file={entry['filename_hint'] or '-'} :: {entry['prompt'][:120]}")
        return (mf.to_csv(self.entries), mf.to_json(self.entries),
                last, len(self.entries))
