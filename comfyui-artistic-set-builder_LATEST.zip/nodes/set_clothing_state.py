import copy

from ..utils.levels import item_state_ids
from .clothing_loader import item_labels, item_state_list


class ASB_SetClothingState:
    """
    Jump any item straight to any state (no step-by-step advancing).

    `target` uses the "ItemName [state]" format, e.g. "Black Briefs [around_ankles]".
    With the JS frontend extension this becomes a dropdown listing every
    (item, state) combination from the connected clothing object.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "clothing": ("ASB_CLOTHING",),
                "target": ("STRING", {"default": "Item [fully_worn]"}),
            }
        }

    RETURN_TYPES = ("ASB_CLOTHING", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("clothing", "changed", "item_states", "available_items")
    FUNCTION = "set_state"
    CATEGORY = "ArtisticSetBuilder"

    def set_state(self, clothing, target):
        new_clothing = copy.deepcopy(clothing)
        items = new_clothing.get("items", [])

        # parse "Name [state]"
        item_part = target.split(" [")[0].strip().lower()
        state_part = target.split("]")[0].split("[")[-1].strip() if "[" in target else ""

        changed = "item not found"
        for item in items:
            name = str(item.get("name", "")).lower()
            iid = str(item.get("item_id", "")).lower()
            if ((name and (name == item_part or item_part in name))
                    or (iid and (iid == item_part or item_part in iid))):
                ids = item_state_ids(item)
                if state_part and state_part in ids:
                    item["current_state"] = state_part
                    changed = f"{item.get('name')} \u2192 {state_part}"
                else:
                    changed = f"{item.get('name')}: state '{state_part or '?'}' not available"
                break

        return (new_clothing, changed, item_state_list(new_clothing),
                item_labels(new_clothing))
