from ..utils.database import first_zone_name


class ASB_SelectZone:
    """
    Select zone by exact name from the available_zones list.
    Example: "Window Zone", "Bed Zone", "Sofa Zone"
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "location": ("ASB_LOCATION",),
                "zone_name": ("STRING", {"default": first_zone_name()}),
            }
        }

    RETURN_TYPES = ("ASB_ZONE", "STRING", "STRING")
    RETURN_NAMES = ("zone", "zone_name", "available_pieces")
    FUNCTION = "select"
    CATEGORY = "ArtisticSetBuilder"

    def select(self, location, zone_name):
        zones = location.get("photo_zones", [])
        target = zone_name.strip().lower()

        selected = None
        for z in zones:
            name = z.get("name", "")
            zid = z.get("zone_id", "")
            if (name.lower() == target or zid.lower() == target
                    or target in name.lower() or target in zid.lower()):
                selected = z
                break

        if selected is None and zones:
            selected = zones[0]

        if selected is None:
            return ({"prompt_pieces": [], "name": "empty"}, "empty", "(none)")

        pieces = selected.get("prompt_pieces", [])
        piece_labels = [f"{p.get('id', i)} | {p.get('type', 'pose')}" for i, p in enumerate(pieces)]
        return (selected, selected.get("name", zone_name), " | ".join(piece_labels))
