"""ASB Photoset Browser — visual picker for model / location / clothing / piercings.

UI is attached by web/photoset_browser.js (Browse panel + Template Builder).
Selections write into these widgets; outputs feed Shoot Plan later.
"""


class ASB_PhotosetBrowser:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model_id": ("STRING", {"default": "", "multiline": False}),
                "location_id": ("STRING", {"default": "", "multiline": False}),
                "clothing_id": ("STRING", {"default": "", "multiline": False}),
                "piercing_ids": ("STRING", {"default": "", "multiline": False}),
                "tattoo_ids": ("STRING", {"default": "", "multiline": False}),
                "include_piercings": ("BOOLEAN", {"default": True}),
                "include_tattoos": ("BOOLEAN", {"default": False}),
                "style": ("STRING", {"default": "metart natural", "multiline": False}),
                "quality": ("STRING", {"default": "metart", "multiline": False}),
                "template": ("STRING", {"default": "", "multiline": True}),
            },
            "optional": {
                "seed": ("INT", {"default": 1, "min": 0, "max": 0xFFFFFFFF}),
            },
        }

    RETURN_TYPES = (
        "STRING", "STRING", "STRING", "STRING", "STRING",
        "BOOLEAN", "BOOLEAN", "STRING", "STRING", "STRING", "INT",
    )
    RETURN_NAMES = (
        "model_id", "location_id", "clothing_id", "piercing_ids", "tattoo_ids",
        "include_piercings", "include_tattoos", "style", "quality", "template", "seed",
    )
    FUNCTION = "run"
    CATEGORY = "Artistic Set Builder"
    DESCRIPTION = "Visual browser for model, location, clothing, piercings. Open Browse panel on the node."

    def run(
        self,
        model_id="",
        location_id="",
        clothing_id="",
        piercing_ids="",
        tattoo_ids="",
        include_piercings=True,
        include_tattoos=False,
        style="metart natural",
        quality="metart",
        template="",
        seed=1,
    ):
        return (
            (model_id or "").strip(),
            (location_id or "").strip(),
            (clothing_id or "").strip(),
            (piercing_ids or "").strip(),
            (tattoo_ids or "").strip(),
            bool(include_piercings),
            bool(include_tattoos),
            (style or "").strip(),
            (quality or "").strip(),
            template or "",
            int(seed or 0),
        )


NODE_CLASS_MAPPINGS = {"ASB_PhotosetBrowser": ASB_PhotosetBrowser}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_PhotosetBrowser": "ASB Photoset Browser"}
