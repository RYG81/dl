import json

from ..utils.database import get_camera_ids, get_framing_ids
from ..utils.prompt_templates import load_template, render_template, render_freeform
from ..utils.shoot_plan import expand_plan, parse_plan_text, resolve_camera, shots_to_csv




class ASB_ShootPlan:
    """
    Director's shot-list engine (v5).

    Takes a plan (JSON or YAML, id-first: zone_id / piece id / item_id) that
    declares the whole shoot, validates every reference against the data files,
    resolves cameras from the camera database, expands wardrobe transitions,
    and emits:

      plan_json / count / storyboard / shots_csv / report   (the full plan)
      index / shot_prompt / shot_negative / shot_seed /
      shot_filename_hint / shot_done                        (single-shot serve)

    The single-shot serve replaces the ASB_BatchIndex + ASB Plan→Prompt pair:
    turn on `use_internal_counter` and each execution serves the next shot
    (auto-run friendly), or wire an external `index`.

    Optional `model` input: connect ASB Load Model to apply piercings/tattoos
    toggles (and optionally override the plan model id).

    The embedded plan editor (frontend) uses `auto_shots` as the shot count
    for its "Auto N shots" button.
    """

    def __init__(self):
        self._counter = 0

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "plan": ("STRING", {"multiline": True, "default": ""}),
                "seed": ("INT", {"default": 1, "min": 0, "max": 0x7FFFFFFF}),
            },
            "optional": {
                "model": ("ASB_MODEL",),
                "style": ("STRING", {"forceInput": True, "default": ""}),
                "quality": ("STRING", {"forceInput": True, "default": ""}),
                "detail_level": (["standard", "detailed", "minimal"],
                                 {"default": "standard"}),
                "auto_negative": ("BOOLEAN", {"default": True}),
                "negative_hints": ("STRING", {"forceInput": True, "default": ""}),
                # Named template only (keeps node compact). Freeform lives in template_body (hidden; Template Builder).
                "template_preset": (["(none)"] + _template_list(), {
                    "default": "metart_narrative",
                }),
                # Filled by Template Builder button — not shown as a tall box (hidden in JS)
                "template_body": ("STRING", {
                    "default": "",
                    "multiline": True,
                }),
                "auto_shots": ("INT", {"default": 5, "min": 1, "max": 1000000}),
                "gallery_mode": (["Tease narrative", "MetArt gallery", "Slow strip",
                                  "Quick strip to nude", "Lingerie focus",
                                  "undress narrative"],
                                 {"default": "Tease narrative"}),
                "erotic_level": (["soft", "editorial", "explicit"],
                                 {"default": "editorial"}),
                "index": ("INT", {"forceInput": True, "default": -1,
                                  "min": -1, "max": 1000000}),
                "use_internal_counter": ("BOOLEAN", {"default": False}),
                "reset_counter": ("BOOLEAN", {"default": False}),
            },
        }

    RETURN_TYPES = ("STRING", "INT", "STRING", "STRING", "STRING",
                    "INT", "STRING", "STRING", "INT", "STRING", "BOOLEAN")
    RETURN_NAMES = ("plan_json", "count", "storyboard", "shots_csv", "report",
                    "index", "shot_prompt", "shot_negative", "shot_seed",
                    "shot_filename_hint", "shot_done")
    FUNCTION = "plan"
    CATEGORY = "ArtisticSetBuilder/Shoot"

    def plan(self, plan, seed=1, style="", quality="", detail_level="standard",
             auto_negative=True, negative_hints="",
             template_preset="metart_narrative", template_body="",
             auto_shots=5, index=-1,
             use_internal_counter=False, reset_counter=False,
             gallery_mode="Tease narrative", erotic_level="editorial", model=None, **kwargs):
        # `gallery_mode` is declared in INPUT_TYPES and passed by ComfyUI.
        # **kwargs swallows any other/older widget value so a frontend or
        # workflow version mismatch can NEVER crash node execution again.
        if reset_counter:
            self._counter = 0

        err_payload = (json.dumps([]), 0)
        # friendly message when the plan box is empty/whitespace — the #1 cause
        # of "empty plan_json" after running without Apply/paste
        if not plan or not str(plan).strip():
            err = ("EMPTY PLAN — the plan box is empty.\n"
                   "Click the editor's ✓ Apply to node (after building shots), or "
                   "paste a plan / ⟳ Load from plan / 📂 Load file / ☁️ Server, "
                   "then run.")
            print("[ASB] ShootPlan: EMPTY PLAN")
            return (*err_payload, err, err, err, -1, "", "", 0, "", False)
        try:
            data = parse_plan_text(plan)
        except Exception as e:
            err = f"ERROR: {e}"
            print(f"[ASB] ShootPlan: parse error -> {err}")
            return (*err_payload, err, "", err, -1, "", "", 0, "", False)

        # Optional ASB_MODEL from ASB Load Model (piercings / tattoos toggles)
        if model and isinstance(model, dict):
            mid = (model.get("id") or model.get("name") or "").strip().lower()
            if mid:
                data["model"] = mid
            # Stash accessory flags for expand_plan / build_model_prompt
            data["_model_override"] = model
            data["_include_piercings"] = bool(model.get("_include_piercings"))
            data["_include_tattoos"] = bool(model.get("_include_tattoos"))
            data["_tattoo_style"] = model.get("_tattoo_style") or ""

        # Erotic tone from node widget (soft | editorial | explicit)
        data["erotic_level"] = (erotic_level or data.get("erotic_level") or "editorial").strip().lower()

        try:
            shots, report, story = expand_plan(
                data, base_seed=seed, style=style or None,
                quality=quality or None, detail=detail_level,
                auto_negative=auto_negative, negative_hints=negative_hints,
                camera_override=(data.get("camera") or ""),
                framing_override=(data.get("framing") or ""),
            )
        except Exception as e:
            err = f"ERROR: {e}"
            print(f"[ASB] ShootPlan: expand error -> {err}")
            return (*err_payload, err, "", err, -1, "", "", 0, "", False)

        # Template: freeform from Template Builder (template_body) wins; else named preset
        template = (template_body or "").strip()
        if not template or ("{{" not in template and "}}" not in template):
            if template_preset and template_preset not in ("(none)", "", "(use template field)"):
                template = template_preset
        # optional template re-render of final prompts (structure control)
        if template and str(template).strip() and str(template).strip() != "(none)":
            freeform = ("{{" in str(template) and "}}" in str(template))
            tmpl = None if freeform else load_template(str(template).strip())
            for s in shots:
                ctx = {
                    "model_prompt": s.get("model_prompt", ""),
                    "clothing_phrases": s.get("clothing_phrases", ""),
                    "prompt_piece": s.get("piece_prompt", s.get("piece", "")),
                    "zone_description": s.get("zone_description", ""),
                    "lighting": s.get("lighting", ""),
                    "style_positive": s.get("style", ""),
                    "style_negative": "",
                    "quality": s.get("quality", ""),
                    "camera_technical": s.get("camera", ""),
                    "level": s["level"],
                    "level_negative": "",
                    "negative_hints": negative_hints,
                    "note": s.get("note", ""),
                    "index": str(s["index"]),
                    "total": str(len(shots)),
                    "title": s.get("title", ""),
                    "seed": str(s["seed"]),
                    # Template Builder aliases
                    "subject_identity": s.get("model_prompt", ""),
                    "subject_first_name": (s.get("model_name") or s.get("model") or ""),
                    "pose_description": s.get("piece_prompt", s.get("piece", "")),
                    "clothing_continuity": s.get("clothing_phrases", ""),
                    "location_name": s.get("location") or s.get("location_name") or "",
                    "location_desc": s.get("zone_description", ""),
                    "light_description": s.get("lighting", ""),
                    "style_prefix": s.get("style", "") or style or "",
                    "style_aesthetic": s.get("style", "") or style or "",
                    "quality_tail": s.get("quality", "") or quality or "",
                    "shot_description": s.get("framing") or s.get("camera") or "",
                    "angle_description": s.get("camera_angle") or "",
                    "framing_description": s.get("framing") or s.get("camera") or "",
                    "camera": s.get("camera") or "",
                    "prompt_piece": s.get("piece_prompt", s.get("piece", "")),
                    "style": s.get("style", "") or style or "",
                    "zone_description": s.get("zone_description") or s.get("zone") or "",
                    "phase_number": str(s.get("index", "")),
                    "phase_name": s.get("level", ""),
                    "phase_description": s.get("note", ""),
                    "wardrobe_summary": s.get("level", ""),
                    "pose_bridge": "",
                    "gaze_text": "looking toward the camera",
                    "expression_text": "a natural expression",
                    "mood_word": "presence",
                    "critical_guard": "single continuous photograph, one subject, realistic anatomy",
                    "outfit_recall": "",
                    "visible_surfaces": "",
                    "visible_props": "",
                    "visibility_directive": "",
                    "piercing_line": s.get("piercing_line") or "",
                }
                if freeform:
                    try:
                        s["final_prompt"] = render_freeform(template, ctx)
                    except Exception:
                        pass
                elif tmpl is not None:
                    s["final_prompt"] = render_template(tmpl, ctx, positive=True)
                    neg2 = render_template(tmpl, ctx, positive=False)
                    if neg2:
                        s["negative_prompt"] = neg2

        # ---- single-shot serve ----
        count = len(shots)
        if use_internal_counter:
            serve_idx = self._counter
            self._counter += 1
            done = count > 0 and serve_idx >= count - 1
            serve_idx = serve_idx % max(count, 1) if count else -1
        elif index is not None and index >= 0:
            serve_idx = max(0, min(int(index), max(count - 1, 0))) if count else -1
            done = count > 0 and serve_idx >= count - 1
        else:
            serve_idx = -1
            done = False

        if 0 <= serve_idx < count:
            s = shots[serve_idx]
            shot_out = (serve_idx, s.get("final_prompt", ""),
                        s.get("negative_prompt", ""),
                        int(s.get("seed", 0)), s.get("filename_hint", ""), done)
        else:
            shot_out = (-1, "", "", 0, "", done)

        report_txt = "\n".join(report) if report else "OK"
        # visible in the ComfyUI server console — helps debugging output issues
        print(f"[ASB] ShootPlan: plan={len(plan)} chars -> {count} shots | "
              f"report={'OK' if not report else str(len(report)) + ' notes'} | "
              f"serve_index={shot_out[0]}")
        if count == 0:
            # Surface why plan_json was empty (user often only watches plan_json)
            diag = {
                "error": "NO_VALID_SHOTS",
                "plan_chars": len(plan or ""),
                "report": report[:40] if isinstance(report, list) else [str(report)],
                "hint": "Check report output. Common: unknown zone/piece after location change, "
                        "unknown clothing_set, or plan not Applied to node before Queue.",
            }
            print("[ASB] ShootPlan: ZERO SHOTS — " + report_txt[:500])
            return (json.dumps([diag], ensure_ascii=False), 0,
                    story or report_txt, "", report_txt, *shot_out)
        return (json.dumps(shots, ensure_ascii=False), count,
                story, shots_to_csv(shots), report_txt, *shot_out)


def _template_list():
    from ..utils.prompt_templates import list_templates
    return list_templates()
