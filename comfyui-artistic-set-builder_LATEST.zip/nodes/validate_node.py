from ..utils.validate import validate_all, format_report


class ASB_ValidateData:
    """
    Validates every JSON file in data/ and reports issues.
    Useful to run once after editing data files, before generating a big set.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {}}

    RETURN_TYPES = ("STRING", "STRING", "INT")
    RETURN_NAMES = ("report", "status", "error_count")
    FUNCTION = "validate"
    CATEGORY = "ArtisticSetBuilder"

    def validate(self):
        issues = validate_all()
        errors = sum(1 for i in issues if i["level"] == "error")
        status = "OK" if not errors else "ISSUES FOUND"
        return (format_report(issues), status, errors)
