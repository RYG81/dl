from ..utils.database import get_clothing_list, load_json
from ..utils.levels import item_state_ids, item_current_state


def item_state_list(clothing):
    """'ItemName: state1 | state2 | ...' lines used by the JS dropdowns."""
    lines = []
    for item in clothing.get("items", []):
        name = item.get("name", item.get("item_id", "item"))
        lines.append(f"{name}: {' | '.join(item_state_ids(item))}")
    return "\n".join(lines)


def item_labels(clothing):
    """'ItemName [state]' labels, as before."""
    labels = []
    for item in clothing.get("items", []):
        name = item.get("name", item.get("item_id", "item"))
        labels.append(f"{name} [{item_current_state(item)}]")
    return " | ".join(labels)


class ASB_LoadClothing:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"clothing_set": (get_clothing_list(),)}}

    RETURN_TYPES = ("ASB_CLOTHING", "STRING", "STRING")
    RETURN_NAMES = ("clothing", "available_items", "item_states")
    FUNCTION = "load"
    CATEGORY = "ArtisticSetBuilder"

    def load(self, clothing_set):
        data = load_json("clothing", clothing_set)
        if "items" not in data:
            items = data if isinstance(data, list) else data.get("clothing_items", [])
            data = {"name": clothing_set, "items": items}

        for item in data.get("items", []):
            if "current_state" not in item:
                item["current_state"] = item_current_state(item)

        return (data, item_labels(data), item_state_list(data))
