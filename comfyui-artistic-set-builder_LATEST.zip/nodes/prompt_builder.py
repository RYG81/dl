from ..utils.prompts import (
    DEFAULT_QUALITY,
    LEVEL_NEGATIVES,
    STYLE_PRESETS,
    assemble_prompt,
)


class ASB_BuildPrompt:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model_prompt": ("STRING", {"forceInput": True}),
                "clothing_phrases": ("STRING", {"forceInput": True}),
                "prompt_piece": ("STRING", {"forceInput": True}),
                "lighting": ("STRING", {"forceInput": True}),
                "style": (list(STYLE_PRESETS.keys()), {"default": "custom"}),
                "quality": ("STRING", {
                    "default": DEFAULT_QUALITY
                }),
            },
            "optional": {
                "level": ("STRING", {"forceInput": True, "default": "level_0"}),
                "camera_technical": ("STRING", {"forceInput": True, "default": ""}),
                "negative_hints": ("STRING", {"forceInput": True, "default": ""}),
                "auto_negative": ("BOOLEAN", {"default": True}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING")
    RETURN_NAMES = ("final_prompt", "negative_prompt")
    FUNCTION = "build"
    CATEGORY = "ArtisticSetBuilder"

    def build(self, model_prompt, clothing_phrases, prompt_piece, lighting,
              style, quality, level="level_0", camera_technical="",
              negative_hints="", auto_negative=True):
        return assemble_prompt(
            model_prompt, clothing_phrases, prompt_piece, lighting,
            style, quality, level=level, camera_technical=camera_technical,
            negative_hints=negative_hints, auto_negative=auto_negative,
        )
