import json

from ..utils.prompt_templates import list_templates, load_template, render_template
from ..utils.prompts import STYLE_PRESETS


class ASB_PromptDesigner:
    """
    YAML-driven prompt designer (v4).

    Picks a template from data/templates/*.yaml (or a custom YAML string) that
    defines the OUTPUT STRUCTURE of the prompt — the order, the sections and
    the joiner — with placeholders filled from the wired inputs:

        {model_prompt} {clothing_phrases} {prompt_piece} {zone_description}
        {lighting} {style_positive} {style_negative} {quality}
        {camera_technical} {level_negative} {negative_hints}
        {index} {total} {note} {title} {seed} {filename_hint}

    Missing placeholders resolve to "" and empty items are dropped, so you can
    wire only what you need. Ship with 8 presets (editorial, cinematic,
    boudoir_sequence, studio_catalog, minimalist, fashion_editorial,
    black_white_art, documentary) — drop new .yaml files into data/templates/
    and they appear in the dropdown.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "template": (list_templates(), {"default": "editorial"}),
                "model_prompt": ("STRING", {"forceInput": True}),
                "clothing_phrases": ("STRING", {"forceInput": True}),
                "prompt_piece": ("STRING", {"forceInput": True}),
                "lighting": ("STRING", {"forceInput": True}),
                "quality": ("STRING", {"forceInput": True, "default": ""}),
            },
            "optional": {
                "style": (list(STYLE_PRESETS.keys()), {"default": "custom"}),
                "camera_technical": ("STRING", {"forceInput": True, "default": ""}),
                "level": ("STRING", {"forceInput": True, "default": "level_0"}),
                "negative_hints": ("STRING", {"forceInput": True, "default": ""}),
                "zone_description": ("STRING", {"forceInput": True, "default": ""}),
                "note": ("STRING", {"forceInput": True, "default": ""}),
                "index": ("INT", {"forceInput": True, "default": 0}),
                "total": ("INT", {"forceInput": True, "default": 1}),
                "title": ("STRING", {"forceInput": True, "default": ""}),
                "seed": ("INT", {"forceInput": True, "default": 0}),
                "custom_yaml": ("STRING", {"multiline": True, "default": ""}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("final_prompt", "negative_prompt", "template_name")
    FUNCTION = "design"
    CATEGORY = "ArtisticSetBuilder/Prompt"

    def design(self, template, model_prompt, clothing_phrases, prompt_piece,
               lighting, quality, style="custom", camera_technical="",
               level="level_0", negative_hints="", zone_description="",
               note="", index=0, total=1, title="", seed=0, custom_yaml=""):
        if custom_yaml and custom_yaml.strip():
            try:
                import yaml
                data = yaml.safe_load(custom_yaml) or {}
            except Exception:
                data = {}
            tmpl = {
                "name": data.get("name", "custom"),
                "description": data.get("description", ""),
                "joiner": data.get("joiner", ", "),
                "positive": data.get("positive", []),
                "negative": data.get("negative", []),
            }
        else:
            tmpl = load_template(template)

        style_meta = STYLE_PRESETS.get(style, STYLE_PRESETS["custom"])
        level_neg = {
            "level_2": "extra clothing, stray fabric",
            "level_3": "extra clothing, stray fabric, misplaced garment, visible clothing lines",
            "level_4": "any clothing, stray fabric, underwear",
        }.get(level, "")

        ctx = {
            "model_prompt": model_prompt,
            "clothing_phrases": clothing_phrases,
            "prompt_piece": prompt_piece,
            "zone_description": zone_description,
            "lighting": lighting,
            "style_positive": style_meta["positive"],
            "style_negative": style_meta["negative"],
            "quality": quality,
            "camera_technical": camera_technical,
            "level": level,
            "level_negative": level_neg,
            "negative_hints": negative_hints,
            "note": note,
            "index": str(index),
            "total": str(total),
            "title": title,
            "seed": str(seed),
        }

        final = render_template(tmpl, ctx, positive=True)
        neg = render_template(tmpl, ctx, positive=False)
        return (final, neg, tmpl["name"])
