class ASB_BatchIndex:
    """
    Session counter for batch queueing.

    Each graph execution increments the counter by one. Set ComfyUI's
    "Batch Count" to the size of your set and this node will walk the index
    from 0 .. total-1, one per queued run — letting ASB Plan → Prompt (or
    ASB Shoot Plan) serve a different image definition every run.

    AUTO-RUN: turn `auto_run` ON and the frontend extension will queue the
    next run automatically after each one completes, until `done` is True —
    one press of Run renders the whole shoot with no manual re-queueing.
    (Needs the ASB frontend extension; falls back to manual Batch Count.)

    `done` is True on the last index (handy for logging/branching).
    Toggle `reset` True (or reconnect it) to restart from 0.
    """

    def __init__(self):
        self._i = 0

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "total": ("INT", {"default": 57, "min": 1, "max": 1000000}),
                "reset": ("BOOLEAN", {"default": False}),
            },
            "optional": {
                "auto_run": ("BOOLEAN", {"default": False}),
            },
        }

    RETURN_TYPES = ("INT", "BOOLEAN", "INT")
    RETURN_NAMES = ("index", "done", "total")
    FUNCTION = "step"
    CATEGORY = "ArtisticSetBuilder/Generation"

    def step(self, total, reset, auto_run=False):
        if reset:
            self._i = 0
        n = max(1, total)
        idx = self._i % n
        self._i += 1
        done = idx == n - 1
        return (idx, done, n)
