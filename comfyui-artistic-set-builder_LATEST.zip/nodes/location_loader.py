from ..utils.database import get_location_list, load_json

class ASB_LoadLocation:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"location": (get_location_list(),)}}

    RETURN_TYPES = ("ASB_LOCATION", "STRING", "STRING")
    RETURN_NAMES = ("location", "lighting", "available_zones")
    FUNCTION = "load"
    CATEGORY = "ArtisticSetBuilder"

    def load(self, location):
        data = load_json("locations", location)
        lighting = data.get("lighting", "soft natural light")
        zones = data.get("photo_zones", [])
        names = [z.get("name", z.get("zone_id", f"Zone{i}")) for i, z in enumerate(zones)]
        return (data, lighting, " | ".join(names) if names else "(no zones)")
