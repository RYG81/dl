from ..utils.database import first_piece_label


class ASB_SelectPromptPiece:
    """
    Select by exact piece label from available_pieces.
    Example: "Bed_04 | reclining_open" or just "Bed_04"

    Also emits camera/lens technical metadata when the piece defines an
    optional `camera` field, e.g.:

        "camera": "85mm f/1.8, full-frame, 1/125s, ISO 100"
    """

    LEVELS = ["level_0", "level_1", "level_2", "level_3", "level_4"]

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "zone": ("ASB_ZONE",),
                "level": (cls.LEVELS, {"default": "level_0"}),
                "piece_name": ("STRING", {"default": first_piece_label()}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("prompt_piece", "selected", "camera_technical")
    FUNCTION = "select"
    CATEGORY = "ArtisticSetBuilder"

    def select(self, zone, level, piece_name):
        pieces = zone.get("prompt_pieces", [])
        if not pieces:
            return ("standing naturally, looking at camera, medium shot", "none", "")

        compatible = [
            p for p in pieces
            if level in p.get("compatible_clothing_levels",
                              ["level_0", "level_1", "level_2", "level_3", "level_4"])
        ] or pieces

        target = piece_name.strip().lower()
        for p in compatible:
            label = f"{p.get('id', '')} | {p.get('type', '')}".lower()
            pid = str(p.get("id", "")).lower()
            if target == label or target == pid or target in label or pid in target:
                return (p.get("prompt", ""), f"{p.get('id')} | {p.get('type')}",
                        p.get("camera", ""))

        p = compatible[0]
        return (p.get("prompt", ""), f"{p.get('id')} | {p.get('type')}",
                p.get("camera", ""))
