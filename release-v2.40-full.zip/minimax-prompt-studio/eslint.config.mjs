/* Static safety net for the Studio's own code.
 *
 * Why this exists: `npm run build` (esbuild) proves JSX and imports, but it does NOT
 * catch an identifier that is used and never defined — a missing local like `promptSet`
 * builds fine and only explodes at runtime, in the browser, mid-generation. `no-undef`
 * is the rule that catches exactly that class.
 *
 * Deliberately small: correctness rules only, no style. Run with `npm run lint`.
 */
import globals from 'globals'

const RULES = {
  'no-undef': 'error',
  'no-dupe-keys': 'error',
  'no-dupe-args': 'error',
  'no-dupe-class-members': 'error',
  'no-func-assign': 'error',
  'no-unreachable': 'error',
  'no-const-assign': 'error',
  'no-redeclare': 'error',
  'no-self-assign': 'error',
  'no-cond-assign': 'error',
  'no-sparse-arrays': 'error',
}

/* The code carries `eslint-disable-next-line react-hooks/exhaustive-deps` comments. The real
   plugin is not a dependency of this project, so an empty stub is registered here — the comments
   stay meaningful for anyone who does install it, and ESLint stops erroring on the rule name. */
const reactHooksStub = { rules: { 'exhaustive-deps': { create: () => ({}) } } }

export default [
  {
    files: ['src/**/*.{js,jsx}', 'scripts/**/*.mjs'],
    languageOptions: {
      ecmaVersion: 2023,
      sourceType: 'module',
      parserOptions: { ecmaFeatures: { jsx: true } },
      globals: {
        ...globals.browser,
        ...globals.node,
        ...globals.es2021,
        React: 'readonly',
      },
    },
    plugins: { 'react-hooks': reactHooksStub },
    rules: RULES,
  },
]
