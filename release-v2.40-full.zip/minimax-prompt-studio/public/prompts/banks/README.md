# 🧩 Your context files (banks)

Drop any `.md` file in here — a dialogue bank, a secondary-action bank, examples,
a wardrobe list, a style bible. It shows up in **⚙️ Settings → System prompt routing →
🧩 attach** and can be attached to any prompt slot without editing a single prompt file.

Two ways to use a file from here:

1. **Attach in the app (no editing).** ⚙️ Settings → System prompt routing → on the row you want
   (🌐 all generations, or H3 · SFW / LTX · SFW / H3 · 18+ / LTX · 18+), pick the file under
   **🧩 attach**. It is appended to the system prompt for those generations, its own `@include`s
   are resolved, and every generation logs what it attached.
2. **Include from a prompt file.** Put `@include banks/dialogue-bank.md` on its own line in
   `public/prompts/system-prompt-mature.md` (or any other prompt file).

> Files in this folder are **protected**: the updater never overwrites or deletes anything here.
