# Mature system prompt — your addendum

<!--
  This is a SECOND FILE that system-prompt-mature.md depends on.
  It is wired in with one line, at the end of system-prompt-mature.md:

      @include mature-addendum.md

  Write whatever you want in the space below and reload (⚙️ Settings → ↻ Reload from file,
  or just refresh the page). The text lands exactly where that line sits in the prompt —
  same folder, so no path is needed; a subfolder would be @include shared/whatever.md.

  Rules that keep it working:
    - the @include line must be ALONE on its own line
    - the include only matters while the 18+ switch is on and a mature generation runs
    - delete the @include line and the prompt simply goes back to the base file
    - if the file is missing or the path is wrong, the prompt still loads and ⚙️ Settings
      shows "⚠ missing public/prompts/mature-addendum.md"
-->

## Mature treatment — house addendum

Write your own mature-mode direction here, for example: how far a scene may go, how it is
lit and framed, what the camera never does, what must stay implied, the vocabulary you want
and the vocabulary you never want to read back, and how the mature register changes between
H3 and LTX output.
