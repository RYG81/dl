# (moved) FASHION CAMERA-PLAY CRAFT — now a prompt pack

This mode lives inside **prompts/packs/fashion.md** in its `[[MODE camplay]]` block, and is
switched on with the 🎥 camera plays chip beside the pack picker.

Nothing is loaded from this file any more.
