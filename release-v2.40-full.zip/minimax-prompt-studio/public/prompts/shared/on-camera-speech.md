# SPOKEN LINES — who is talking, and whether the mouth moves

The single most common failure in generated dialogue: the line plays as a **voice coming from
somewhere else** while the person on screen stands with a closed mouth. That is a voiceover, and it is a
different thing from a character speaking. Only one of them is ever written by accident.

## The two modes — name the one you want, never let it be implied

| mode | how it must be written | what the video shows |
|---|---|---|
| **ON-CAMERA SPEECH** (default whenever the user gives a line or asks for talking) | `<Subject N> (S1) says, <d>[Language] …</d>` and the sentence must state the mouth is visible and moving | the speaker's face is in frame, the mouth is unobstructed and moving with every word, jaw and lips articulating, the voice comes from that face |
| **VOICEOVER** (only when the user asks for narration, a brand line, a thought, or a line in a language the persona would not speak) | the exact phrase `says in an off-screen voiceover` **plus** a statement that the character's lips remain completely closed | the speaker is on screen not speaking — mouth closed, no articulation — or not on screen at all |

Never blur the two. A line written as on-camera speech must not resolve as a disembodied voice, and a
voiceover must never be given a moving mouth.

## On-camera speech — the five things the model must be told

1. **The speaker is in frame for the whole line.** Name the framing in that beat: `in a medium
   close-up`, `framed to the collarbone`, `the camera holds her face`. A face-cropping wide shot is not
   a place to put dialogue.
2. **The mouth is unobstructed and moving.** State it: `her lips move with every word`, `her jaw
   articulates the line`. Forbid the blockers in the same breath: no mask, no hand, glass, hair, fan,
   veil or shoulder crossing the mouth while the line plays; no head turned fully away; no profile so
   sharp the lips vanish; no bite, sip or drag on a cigarette inside the line.
3. **One speaker, one ID.** `<Subject 1> (S1)` on first vocalisation, and the same ID for every later
   line from her. Two speakers get `(S1)` and `(S2)`, never two `(S1)`s. A compound speaker is written
   `(S1,S2)`.
4. **The line is verbatim inside `<d>[Language] …</d>`** — same words, same punctuation, never
   translated, never paraphrased, never split across two `<d>` tags. The language tag is the language it
   is spoken in, not the language it was written in.
5. **Voice quality lives outside the tag**, in the sentence: pace, volume, breath, accent, emotional
   temperature — `she says flatly, holding his eyeline`, `she says, quiet and unhurried, without looking
   up`. Never inside `<d>`.

## Timings the words have to fit

Speech is not free. Budget it before the beats:

- a short line (5-8 words) ≈ **1.5-2 s** on screen;
- a medium line (9-15 words) ≈ **2.5-3 s**;
- anything longer needs its own shot and its own `[Shot N]` stamp.

So a 10-second clip holds **three short spoken beats at most** — one per shot, the line landing early in
the shot and the physical beat completing after it. If a line is cut off by the end of the video, mark it
`<cutoff>`. If the speech runs across a cut, place `<scenetrans>` at both connection points.

## Where dialogue must never end up

- **`overall_soundscape` never carries speech.** No quoted lines, no `<d>` tags there. That field is
  ambience, action sound and non-verbal human sound (breath, laughter, a gasp, a hum) — nothing
  intelligible. Words in the soundscape field are how a scripted line turns into background chatter.
- **`non_diegetic_music` never carries speech** either — it is instrumentation, tempo and dynamics only.
- **Ambient crowd talk is not dialogue.** If the scene has room tone with people in it, keep it as
  un-worded murmur in the soundscape and give it no tag — an intelligible second voice will fight the
  scripted line for the render.
- **On-screen text is not speech.** A printed line is not a spoken one, and a spoken line is never
  solved by writing it into the picture.

## Persona and point of view

A speaking character is a person, not a caption. When the user supplies a line, the delivery is part of
the direction: her attitude, her register, her vocabulary — matching how that specific woman would say
it. When she is meant to sound self-possessed, authoritative, warm, bored or defiant, say so in the
sentence around the tag; the line itself is never changed to achieve it.

## Checklist before a dialogue beat is written

1. Is the mode named (on-camera or voiceover) — and correct?
2. Is the speaker's face in frame, mouth unobstructed and moving (or explicitly the opposite for a voiceover)?
3. Is the line verbatim in `<d>[Language] …</d>`, with a stable `(S1)`?
4. Does the line fit the shot's time, with `<cutoff>` / `<scenetrans>` used if it does not?
5. Is every intelligible word kept out of `overall_soundscape` and `non_diegetic_music`?
