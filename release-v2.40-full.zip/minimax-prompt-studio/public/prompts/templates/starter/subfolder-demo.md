## Starter — subfolder demo (safe to delete)
model: h3
tag: fashion
description: Proof that templates work from SUBFOLDERS. This file lives in public/prompts/templates/starter/ — the picker shows it with a 📁 starter badge and a folder filter, and it behaves exactly like a file in the root of the templates folder. Copy this file into your own folder (or drag a folder of .md files in) — subfolders are scanned live, and everything inside a subfolder is treated as YOURS: updates never replace or move it. Delete this demo once you have made your own.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: multi3
camera: Auto
tip: Rename the folder to whatever you like (my-project, client-name, bridal-2026) — the folder name is what the picker filters on, so a folder per client or per campaign keeps a big library navigable.
idea: {STYLE TYPE — the register: tradition, office wear, evening, resort, streetwear} — {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish}, worn by {MODEL — age, hair, skin, build}, in {LOCATION — room, its light source, floor and one landmark}, moving with {MOVEMENT — gait, tempo} and {PRESENTATION — attitude, gaze}, as she {ACTION}, while {OUTFIT INTERACTION — what her hands do with the garment}, shot as {CAMERA — the lens and the move}.

```
integrated_multimodal_description: Shot on {CAMERA — lens, move and end-state}, 24fps, clean neutral grade, a {duration}-second three-shot sequence. THIS LOOK'S STYLE TYPE IS {STYLE TYPE — the register} and everything follows from it: garment family, coverage, fabric weight, footwear, room and the register of her voice. THE ROOM IS HERS: {LOCATION — its light source, floor and one landmark}. She is {MODEL — age, hair, skin, build} wearing {OUTFIT DESIGN — silhouette, fabric, construction} in {OUTFIT COLOUR — colour family and finish}, complete with its own footwear. LAYER STACK: the outfit is a closed stack — a named base layer (a camisole, a bodysuit or a bralette-and-brief) under it, the main piece, a stated bottom (trousers, a skirt or the garment's own lower half), and that footwear; nothing sheer, plunged or slit is left without a layer named beneath it. SHE PRESENTS THE LOOK HERSELF, ON CAMERA — face in frame, lips moving with every word, nothing covering her mouth, lines verbatim in <d>[Language] ...</d> with the delivery stated outside the tag, and no intelligible words in overall_soundscape. TIMING: three stamped shots, one spoken beat each, the final second a settled hold — follow the CLOCK given in the request. [Shot 1] She arrives into the light working the room with one contact — a doorframe, a curtain, a chair back — {PRESENTATION — attitude and gaze}, and says one short line naming the style type in her own voice. [Shot 2] At the clock's first cut she brings one hand to a single garment detail — neckline, waist, back, hem or shoe — says one short line about exactly that detail, and the fabric answers her hand. [Shot 3] At the clock's second cut she takes the strongest pose the room allows, lands the closing attitude line as herself — fashion sense, not a sales pitch — and holds still for the last second with this room's light unbroken.

overall_soundscape: this room's own layer — room tone, a street through glass or an echo off bare walls, fabric moving through air, footsteps on {FLOOR}, and non-verbal human sound only. No intelligible words here.

non_diegetic_music: {one rhythmic bed — a sparse percussive loop or a low synth pulse} at a steady tempo that rides the cuts and stays under her voice, or exactly N/A for pure editorial silence.
```
