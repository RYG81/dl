## MOA film — mechanism of action
model: h3
tag: medical
description: Pharmaceutical-grade mechanism-of-action film: a cinematic dive inside the body at cellular scale, one mechanism explained in one continuous visual argument — target, binding, cascade, consequence. Technically exact, confidently staged, never gory, no on-screen text.
category: Medical / Science
ratio: 16:9
resolution: 2K
duration: 10
music: subtle
structure: multi3
camera: Auto
flows: SCALE DESCENT | BINDING FIRST | CASCADE THEN RESOLVE | OUTSIDE IN
vary: MECHANISM | SCALE | TISSUE | PATHOLOGY OR HEALTH | VISUAL LANGUAGE
tip: Write the mechanism as a physical event, not as a claim: say what touches what, in what order, and what changes. Never invent a structure you cannot name accurately — replace it with a scale-appropriate equivalent (a signalling cascade, a channel, a transport protein, a cell surface). No gore, no wounds, no identifiable patient, no brand mark, no text overlay: this is an illustration of a mechanism, not medical advice — say so in the description if the clip is going out to patients.
idea: {MECHANISM — the exact mechanism to show, in one sentence: what acts on what and what changes} at {SCALE — the scale the camera works at}, through {TISSUE — the tissue or compartment the camera travels}, comparing {PATHOLOGY OR HEALTH — the untreated/disease state against the treated/healthy state}, rendered in {VISUAL LANGUAGE — house style: translucent tissue, matte clay anatomy, volumetric scan}.

```
integrated_multimodal_description: Shot as photoreal scientific visualisation: an octane-style volumetric render at 24fps, deep black background with the tissue lit from within, physically accurate subsurface scattering, shallow depth of field at true macro scale, a restrained palette of clinical teal, warm haemoglobin red and bone ivory, and a single moving key so every surface reads in three dimensions. SCALE IS THE LANGUAGE: state the scale at every beat and keep it continuous — the camera is at {SCALE}, travelling through {TISSUE}, and every structure on screen must belong to that scale (a cell is not next to a molecule, a vessel wall is not inside a capillary). Translucent, sectional, anatomically plausible geometry; no fantasy organs, no glowing magical auras, no cartoon faces, no gore, no wound, no exposed surgical field unless the request names it. THE MECHANISM: {MECHANISM} — shown as a physical sequence: TARGET (the surface or structure that matters, seen clearly and once, before anything acts on it), CONTACT (the event itself — the molecule arriving and docking, the current crossing a membrane, the plaque forming, the vessel widening — held long enough to be understood, in extreme close-up, with the binding site readable), CASCADE (the consequence spreading through the tissue in two or three disciplined steps, each one a physical change, never a particle burst just for drama), OUTCOME (the same view as TARGET, now different — {PATHOLOGY OR HEALTH}: name what changed so the before and after are the same shot twice). Keep one continuous spatial logic: the camera should be able to draw a line from the first beat to the last. SCIENTIFIC HYGIENE: no on-screen text, no labels, no numbers, no brand marks, no needles or pills unless the mechanism needs them; represent the rest at the scale of {SCALE} with accurate-looking structure rather than an icon; differentiate the therapeutic element from the body's own molecules by form and motion, not by colour alone, so it still reads in monochrome. {VISUAL LANGUAGE} governs the whole clip — do not change style between beats. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the mechanism: a receptor or enzyme story → BINDING FIRST, a signalling or immune story → CASCADE THEN RESOLVE, a whole-body or organ story → OUTSIDE IN, an abstract or multi-scale story → SCALE DESCENT. SCALE DESCENT = start outside the body or at organ level and descend through three scales to the molecular event. BINDING FIRST = open tight on the target surface, then pull back to show what the binding changed. CASCADE THEN RESOLVE = the consequence travelling outward, then one calming beat as it resolves. OUTSIDE IN = a whole-body or organ-wide establishing move that ends inside the affected tissue. TIMING: 10s total — 3 stamped shots of about 3.3s, one mechanism step per shot, each step held long enough to read, and the final second a slow settle on the outcome with the light steady.

overall_soundscape: an interior acoustic — a low body hum and pulse, fluid movement, a soft membrane-or-surface contact on each event, and a quiet room tone standing in for the space outside the body. No intelligible speech, no library whoosh, no sci-fi zap: the sound must stay plausible for what is on screen.

non_diegetic_music: {one restrained score — a single sustained cello, a soft synth pad, a slow two-note pulse that lands on CONTACT} mixed low under the interior sound, or exactly N/A for pure clinical silence.
```

## Disease-state journey — inside the body
model: h3
tag: medical
description: The progression story: one tissue shown at the same angle across time, so the viewer watches a state change from healthy to affected (or the reverse under treatment). Patient-safe, no gore, no shock imagery, and the same view returned to at the end so the change is undeniable.
category: Medical / Science
ratio: 16:9
resolution: 2K
duration: 10
music: subtle
structure: multi3
camera: Auto
flows: BASELINE THEN BREAK | BUILD UP THEN RELIEF | ONE STRUCTURE, THREE STATES | THE SAME VIEW TWICE
vary: CONDITION | TISSUE | TIMEFRAME | TREATED OR UNTREATED | VISUAL LANGUAGE
tip: Anatomy stays plausible and calm — swelling, narrowing, inflammation, plaque, degeneration and repair are all readable without blood, wounds or distress. Keep ONE anchor view: the same angle the sequence opens on is the angle it must return to, so the comparison is honest. Same rules as the MOA film: no text, no brand, no identifiable person, no diagnosis language.
idea: {CONDITION — the condition or process being shown, in neutral scientific words} in {TISSUE — the tissue or organ} over {TIMEFRAME — the period the change represents, e.g. minutes, weeks, years}, shown {TREATED OR UNTREATED — whether a treatment intervenes and what it changes}, rendered in {VISUAL LANGUAGE — translucent tissue, matte clay anatomy, volumetric scan, glass-and-fluid realism}.

```
integrated_multimodal_description: Shot as photoreal scientific visualisation: volumetric render at 24fps, deep neutral background, tissue lit from within with accurate subsurface scattering, a clinical but warm palette, and one slowly moving key so every surface turns in the light. ONE ANCHOR VIEW: the sequence opens on a fixed, well-lit view of {TISSUE} and returns to exactly that view at the end, so the change is measured against the opening frame — never change the camera's relationship to the tissue between states. PROGRESSION: {CONDITION} over {TIMEFRAME}, written as physical events rather than adjectives — the wall thickening, the channel narrowing, the surface roughening, the layer thinning, the swelling easing, the flow returning. Each state must be legible on its own and distinguishable from the last by more than colour. UNTREATED OR TREATED: {TREATED OR UNTREATED} — if a treatment intervenes, it arrives as one calm event (a molecule, a flow, a covering, a repair process) and its effect is shown as follows, not as magic. PATIENT-SAFE AND ACCURATE: no blood, no wound, no gore, no distress, no operating field, no identifiable person, no visible medical error, no cartoon faces; external anatomy stays generalised so the clip never reads as a specific patient. No text, labels, numbers, arrows, charts or brand marks on screen — the science must be carried by form, motion and light. {VISUAL LANGUAGE} governs the whole clip without changing between beats. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the story: a chronic process → BASELINE THEN BREAK, an acute event → BUILD UP THEN RELIEF, a comparison → ONE STRUCTURE, THREE STATES, a treated outcome → THE SAME VIEW TWICE. BASELINE THEN BREAK = healthy state held, then the first structural change, then the consequence. BUILD UP THEN RELIEF = the pressure or obstruction accumulating in three rising steps, then one release. ONE STRUCTURE, THREE STATES = three held views of the same structure, each one state further along. THE SAME VIEW TWICE = the anchor view, the journey away from it, and the honest return. TIMING: 10s total — 3 stamped shots of about 3.3s, one state per shot, transitions as slow continuous changes rather than cuts where possible, and the final second the settled return to the anchor view.

overall_soundscape: a low interior bed — body hum, breath-paced pulse, a soft fluid movement as the state changes — quiet and steady, never dramatic. No intelligible speech, no alarm tones, no whoosh.

non_diegetic_music: {one restrained bed — a low sustained drone, a slow piano note per state change} or exactly N/A so the interior sound leads.
```

## Classroom concept explainer — labelled 3D
model: h3
tag: medical
description: The classroom explainer in the Designmate / Eureka.in tradition — a clean 3D model of the subject, presented with slow teaching beats and a small number of legible on-screen labels, in a bright studio with nothing cinematic competing for attention. Every label is spelled exactly as given and never invents its own.
category: Medical / Education
ratio: 16:9
resolution: 768P
duration: 10
music: subtle
structure: multi3
camera: Auto
flows: ORIENT THEN ZOOM | PART BY PART | EXPLODE AND REASSEMBLE | CYCLE THEN ZOOM
vary: SUBJECT MODEL | COLOUR CODE | LABELS | LEVEL | PRESENTATION
tip: This template is deliberately un-cinematic: bright even light, clean neutral studio, the model as the only subject, one idea per beat. Give the LABELS as the exact words you want on screen — H3 renders on-screen text inside quotes, and a short label (1-3 words) survives a render far better than a sentence. Keep it to three labels per clip. Nothing here is a diagnosis or a substitute for a textbook — this is a teaching illustration.
idea: A clean 3D teaching model of {SUBJECT MODEL — the structure or system to teach} presented at {LEVEL — the level it is being taught at}, in a bright neutral studio, with the colour code {COLOUR CODE — which parts are tinted and in what colours} and the on-screen labels {LABELS — up to 3 short labels, spelled exactly}.

```
integrated_multimodal_description: A bright, clean 3D educational render — soft even studio light from a large key above and a fill in front, no harsh shadow, no dramatic contrast, a plain pale-grey or white environment with a soft contact shadow under the model and nothing else in frame. The model of {SUBJECT MODEL} is smooth, simplified, plausible geometry — the shapes a teacher would draw in three dimensions, not photoreal tissue and not a cartoon: consistent scale across all its parts, clean silhouettes, matte surfaces with a slight sheen so edges read. PALETTE AS A COLOUR CODE: {COLOUR CODE} — every tinted part keeps its colour for the whole clip and each colour means one thing only. ONE IDEA PER BEAT, three beats: ORIENT (the whole model turns slowly so its shape is understood, at about {DISTANCE — how much of the model fills frame}), then {TEACHING MOVE — this beat's move: isolate a part, open a section, explode, or start a cycle}, then ZOOM (the camera moves into the part that matters and holds it still while the labels sit calmly in place). LABELS: {LABELS} — rendered as short, clean English text in a plain sans-serif, sentences in title case, each label horizontal, legible, with a thin leader line to the part it names if a leader helps at this distance; never more than three labels on screen at once, never a paragraph, never a number that is not asked for, never text over the moving part as it turns. If a label would be occluded, the model turns back rather than the text moving. PRESENTATION: {PRESENTATION — turning hero object / exploded assembly / cutaway / system with flows}. NO EMBELLISHMENT: no lens flares, no particles, no glowing auras, no background props, no music-video cutting, no faces. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the subject: a whole structure → ORIENT THEN ZOOM, a system of parts → PART BY PART, an assembly → EXPLODE AND REASSEMBLE, a process → CYCLE THEN ZOOM. ORIENT THEN ZOOM = turn, then isolate, then hold the detail with labels. PART BY PART = the model holds still and one part at a time steps forward, is named, and returns. EXPLODE AND REASSEMBLE = the parts separate on a slow vertical axis, hold, then come back together in order. CYCLE THEN ZOOM = a repeated process is shown twice at full view, then the camera moves in for one clean cycle with the labels. TIMING: 10s total — 3 stamped shots of about 3.3s, one idea per shot, no fast cut, every move slow enough for a student to follow, and the last second a settled hold with the labels steady and undistorted.

overall_soundscape: a clean neutral room tone, a soft mechanical click or air-movement on each part change, and quiet handling sound if the model is presented by hand. PRESENTATION: {PRESENTATION — turning hero object / exploded assembly / cutaway / system with flows}. No intelligible speech, no music-video whoosh, no classroom walla.

non_diegetic_music: {one simple neutral bed — a soft marimba or piano figure at a slow steady tempo} mixed well under any narration, or exactly N/A so a teacher's own voice can be added later.
```

## Hybrid explainer — real footage + 3D inserts
model: h3
tag: medical
description: The hybrid teaching format that outperforms either half alone: live-action footage of the real thing cut against 3D animation inserts that show what is happening inside it. Real hands, real room, real texture — then the model takes over to explain the invisible mechanics — then back to real.
category: Medical / Education
ratio: 16:9
resolution: 2K
duration: 10
music: subtle
structure: multi3
camera: Auto
flows: REAL THEN INSIDE | REAL, INSIDE, REAL | INSIDE FIRST | MATCH THE ANGLE
vary: REAL SUBJECT | INSERT MECHANISM | INSERT SCALE | TRANSITION LOGIC | VISUAL LANGUAGE
tip: The whole effect rests on the hand-off: the real shot must state a camera angle, a light direction and a distance, and the 3D insert must open on that same angle, that same light direction and that same distance before it moves. Cut on a movement, not on a beat. Never mix footage of identifiable patients or real clinical procedures with invented anatomy — this is for teaching illustration, not documentation.
idea: A teaching sequence on {REAL SUBJECT — the real thing on camera: hands, a bench, a small device, a model on a table, a demonstration}, cut with a 3D insert that shows {INSERT MECHANISM — the mechanism inside it, at {INSERT SCALE — the internal scale}}, with the hand-off following {TRANSITION LOGIC — how the two halves connect}.

```
integrated_multimodal_description: Two visual languages in one clip, joined honestly. REAL HALF: live-action at 24fps, {VISUAL LANGUAGE — the real room's own light, named: a bench under a north window, a clinic room in daylight}, {REAL SUBJECT — the real thing on camera} held in {DISTANCE — the distance the camera keeps from it}, one locked or slowly drifting camera, no grade beyond a clean neutral, real texture, real imperfection — no stock-footage gloss, no logos, no text. 3D HALF: photoreal scientific visualisation of {INSERT MECHANISM} at {INSERT SCALE — the internal scale}, deep neutral background, tissue or material lit from within, subsurface scattering, one moving key, no gore, no text, no brand. THE HAND-OFF is the whole craft — {TRANSITION LOGIC}: hold the same ANGLE, the same LIGHT DIRECTION and the same DISTANCE ACROSS the cut, so the real object appears to keep existing while the view moves inside it; cut on a movement (a hand releasing, a tilt, a lift) rather than on a held pose, and cut at a moment where both halves share one shape or one line on screen. Never cut on a static beat, never dissolve into a new angle, never let the insert arrive with a different light. If the real half is a hand, keep the insert's scale anchored to what that hand holds. SEQUENCE: REAL (establish the real thing, its texture and its light; one action begins), INSIDE (the 3D insert takes the same view inside and shows what that action is doing at {INSERT SCALE}), RETURN (back to the real thing at the matching angle, where the action completes and its result is visible in the real world). Three beats, one argument, no repetition between halves. NO ON-SCREEN TEXT in either half, no captions, no arrows, no labels, no split screen, no picture-in-picture frame — the hand-off carries the teaching. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: the simplest teaching cut → REAL THEN INSIDE, a full explanation → REAL, INSIDE, REAL, a mechanism-led story → INSIDE FIRST, a strict-match story → MATCH THE ANGLE. REAL THEN INSIDE = real action begins, insert explains it, clip ends inside. REAL, INSIDE, REAL = real, inside, real — the safest teaching shape. INSIDE FIRST = the mechanism opens the clip, then the real world reveals what it belongs to. MATCH THE ANGLE = every cut is solved by matching camera position, light and distance exactly. TIMING: 10s total — 3 stamped shots of about 3.3s, one hand-off per cut, the action in the real half landing inside the final second.

overall_soundscape: the real room's own layer in the real half — room tone, the handling sound of {REAL SUBJECT}, a surface under it — and in the 3D half a low interior bed with a soft contact on each mechanism event, mixed so the cut does not jump in level. No intelligible speech in this field.

non_diegetic_music: {one restrained bed — a soft synth pad or a low pulse} carried across the cut so the two halves feel like one film, or exactly N/A so a narration can be added later.
```

## Physiology cycle — seamless teaching loop
model: h3
tag: medical
description: One physiological cycle, rendered so the last frame is the first frame — heartbeat, breathing, peristalsis, a neuron firing, a filtration pass. Built for classrooms and for screens that play on repeat: the loop is the lesson, so nothing may enter or leave the body of the cycle.
category: Medical / Education
ratio: 16:9
resolution: 768P
duration: 6
music: subtle
structure: single
loop: true
camera: Static or one closed orbit
flows: CYCLE THEN LABEL | SECTION THROUGH | PULSE WITH THE CYCLE | MACRO AT THE WORKING PART
vary: CYCLE | TISSUE | COLOUR CODE | PACE | PRESENTATION
tip: A LOOP is a promise: the final frame must be identical to the first in composition, light and pose, or the seam shows every cycle. Keep everything cyclic inside the clip — no one-way flow, nothing entering or leaving, no reveal that only happens once. One cycle per clip, one label at most, and the label must be static while the anatomy moves under it.
idea: A seamless teaching loop of {CYCLE — the physiological cycle: one heartbeat, one breath, one peristaltic wave, one nerve impulse, one filtration pass} in {TISSUE — the tissue or organ}, paced at {PACE — how many cycles the clip holds, e.g. one slow cycle or two quick ones}, with the colour code {COLOUR CODE — which parts are tinted and in what colours}, presented as {PRESENTATION — section through / cutaway / whole organ / macro at the working part}.

```
integrated_multimodal_description: A clean 3D educational render of a physiological cycle, seamless by construction: bright even studio key with a fill in front, plain pale-grey environment, a soft contact shadow, matte model surfaces with a slight sheen so edges read, no dramatic contrast, nothing else in frame. THE CYCLE: {CYCLE} in {TISSUE}, at {PACE} — write the cycle as its ordered events (fill, contract, empty, relax, repolarise, refill), each with a visible physical change, and let the last event hand back to the first so the body of the clip is continuous. THE LOOP CONTRACT: the final frame must match the first frame exactly in composition, light and the position of every moving part — no pop, no fade, no cut, no drift in the camera; any one-way detail (a bulk flow, a particle that only travels once, a wave that only travels once) must either return or be left out, because it will break the seam on the second play. Motion inside the cycle is cyclic: every displacement has its return. {COLOUR CODE} assigns one meaning per tinted part and holds for the whole clip, and {PRESENTATION} fixes how the cycle is seen — a section, a cutaway, the whole organ, or a macro at the working part. LABELS: one short label at most, 1-2 words, plain sans-serif, horizontal, static and legible while the anatomy moves beneath it — never a sentence, never a number the request did not give, never text over a surface that turns. NO EMBELLISHMENT: no lens flares, no particles for drama, no glowing auras, no background props, no music-video cutting, no faces. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the subject: a chamber or vessel → CYCLE THEN LABEL, a layered structure → SECTION THROUGH, a rhythmic organ → PULSE WITH THE CYCLE, a fine working part → MACRO AT THE WORKING PART. CYCLE THEN LABEL = the cycle plays once clean, then the label settles in for the second pass. SECTION THROUGH = the camera holds a stable cutaway while the cycle runs at the exposed layer. PULSE WITH THE CYCLE = the framing breathes a fraction with each phase, never drifting off the seam. MACRO AT THE WORKING PART = the camera stays at the valves, villi or synapse and the whole cycle happens inside the frame. TIMING: 6s total — one continuous take at the cycle's own pace; two cycles of a quick rhythm or one slow cycle, with the phase positions at the final frame identical to the opening frame.

overall_soundscape: a low interior bed matching the cycle — a pulse, a breath-paced air movement or a soft peristaltic rush — steady in level and rhythmic, so the audio loops without an audible seam too. No intelligible speech, no alarm tones.

non_diegetic_music: {one minimal loop-friendly bed — a soft pulse whose bar length divides evenly into the clip} at a steady tempo, or exactly N/A.
```
