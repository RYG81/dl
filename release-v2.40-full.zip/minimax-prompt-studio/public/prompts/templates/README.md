# templates/

Every `.md` file in this folder (and in any subfolder) is scanned **live** — drop a file in,
refresh the tab, and it appears in the picker. No manifest, no rebuild.

## The shape of a file

```md
## Template title
model: h3            # h3 | ltx
tag: fashion         # the filter chip in the picker
description: one line about what this skeleton does
category: Fashion / Lifestyle
ratio: 16:9
resolution: 2K
duration: 10         # the runtime this skeleton was written for (pins the Duration chip)
music: subtle
structure: multi3    # single | multi2 | multi3
camera: Auto
flows: A | B         # optional: named beat architectures, rotated per variant
vary: STYLE TYPE | OUTFIT COLOUR   # optional: dimensions that must differ per variant
chain: 5             # optional: send to the builder as 5 linked scenes
tip: shown on the card and after loading
idea: the prefilled idea line with {PLACEHOLDERS}

```
integrated_multimodal_description: …three fields, fenced or plain…
```
```

A block needs a `## Title` and a skeleton. `integrated_multimodal_description:` makes it an H3
block; `prompt:` (or `model: ltx`) makes it an LTX block. Placeholders are `{NAME — guidance}`:
the text after the dash becomes the 🧩 field hint. Keep a token under 120 characters.

## Subfolders (v2.7)

Organise the library however you like — the scan is recursive, up to 5 levels deep:

```
templates/
  core.md                      ← built-ins (replaced by app updates)
  medical-education.md
  starter/subfolder-demo.md    ← newly scanned the same way
  bridal-2026/sangeet.md
  client-acme/looks/hero.md
```

* The folder name shows on the card (`📁 bridal-2026`) and the picker + Templates page get a
  **folder filter**; the folder name is also searchable.
* **Everything inside a subfolder is yours.** Updates only ever write files in the *root* of this
  folder, so a folder tree you build is never replaced, moved or deleted
  (`DEFAULT_PROTECTED` carries `public/prompts/templates/**/`).
* Files whose name starts with `user` are yours too, root or nested.
* Same title overrides a built-in — your version wins.
* `README.md` and files starting with `_` are skipped (so this file is documentation, not a template).
