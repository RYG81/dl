## Medical reel — symptom hook to one action
model: h3
tag: medical
description: A 9:16 clinic reel that earns the first two seconds. One symptom as a real-life hook, one mechanism insert that explains it, one action to close — captions readable with the sound off, safe-area framing, and not a single claim the clinic cannot stand behind.
category: Medical / Education
ratio: 9:16
resolution: 768P
duration: 15
music: subtle
structure: multi3
camera: Auto
flows: HOOK THEN NAME IT | SYMPTOM THEN MECHANISM | ONE ACTION CLOSE | LOOP TO HOOK
vary: CONDITION | HOOK | MECHANISM | ACTION | SPEAKER OR SILENT
tip: Reel discipline, in this order — hook (a person doing the ordinary thing the symptom interrupts, 0–2s), name it (the plain-language name, once), show why (one mechanism insert), one action (the single next step, held still at the end so it can be screenshotted). One on-screen line per shot, quoted English only; if a line of speech is used it is on-camera with the face in frame and lips moving, or an exact off-screen voiceover with lips closed — never a floating voice. Never a diagnosis, never a dose, never "cures", never a before/after promise: this is illustration for understanding, and the clip says so on screen if it is going to patients.
idea: A 9:16 medical reel about {CONDITION — one condition or symptom, in plain words}, opening on {HOOK — the ordinary moment the symptom interrupts, e.g. a woman pausing mid-staircase}, explaining it through {MECHANISM — the single physical change that causes it}, and closing on {ACTION — the one next step a viewer can take}, spoken by {SPEAKER OR SILENT — an on-camera clinician/patient voice, or silent visual-first}, rendered as {VISUAL LANGUAGE — clean 3D teaching render inside real footage, or translucent-tissue macro}.

```
integrated_multimodal_description: A vertical 9:16 medical reel at 24fps shot like a real phone-first social clip, not like a hospital film: natural daylight, one honest location, skin with real texture, no stock-footage gloss, no gore, no wound, no distress, no identifiable patient, no brand mark. HOOK IS LAW: the first two seconds show the symptom as behaviour — {HOOK} — held close and unposed, with no caption competing for the eye; the viewer must recognise the moment before they are told anything. Then the reel argues in three beats. NAME IT — {CONDITION} said once in plain language while the shot stays on the person, so the words land on a face, not on a diagram. SHOW WHY — {MECHANISM} as a physical sequence at a scale a person can follow: the structure shown plainly once, the change happening, and the consequence, each step a visible change rather than a graphic effect; keep the anatomy generalised and keep one continuous spatial logic inside the insert. ONE ACTION — {ACTION} stated once and held, with the visual settling to stillness so it can be read twice without pausing the clip. The last second may return to the hook framing so the reel loops seamlessly. SPEECH AND TEXT: {SPEAKER OR SILENT} — if anyone speaks, they are on camera, face in frame, the mouth never covered or turned away, and the line is written verbatim; an off-screen voice is only allowed with the exact phrase "says in an off-screen voiceover" together with a statement that the lips remain closed; intelligible speech never enters overall_soundscape. On-screen text: at most one short quoted English line per shot, bottom third, in the safe area, horizontal, still while the image moves, exactly as written — no paragraphs, no numbers that were not asked for, no dosage, no percentage claims. CLAIMS HYGIENE: never a diagnosis, never "cures/treats/prevents", never a guarantee, never a before/after promise, never a real patient or a real clinic name unless the request asks for it; the clip is an educational illustration and may open or close with a short quoted line saying so. FRAMING: the face and the working detail sit in the middle of the vertical frame, nothing essential inside the outer margins where phone UI crops. TIMING: three even beats across the live runtime — the cut lands where each beat turns, never at a stamped second, and the clock you actually get is what the reel obeys; the hook lives inside the first two seconds and the last stretch stays steady on the action, so the reel can be watched twice without pausing.

overall_soundscape: a real room's tone — the space the hook happens in (a stairwell, a kitchen, a clinic corridor), with the small honest sounds of the action and one soft contact sound on each mechanism event. Mixed low and even, no alarm tones, no clock ticks, and no intelligible speech in this field.

non_diegetic_music: {one restrained bed — a soft pulsing pad or a two-note figure at a walking tempo, mixed well under the speech} or exactly N/A so a spoken track or trending audio can be laid in later. Do not imitate a recognisable commercial track.
```

## Medical reel — myth vs fact, on camera
model: h3
tag: medical
description: The correction format: a widely believed myth said out loud in the first two seconds, then the fact, then the reason it is true — delivered by a speaker who is on camera the whole time. Built for saves and shares, and deliberately incapable of promising anything.
category: Medical / Education
ratio: 9:16
resolution: 768P
duration: 12
music: subtle
structure: multi3
camera: Auto
flows: MYTH FIRST | FACT THEN WHY | WHY THEN PROOF | CORRECT THE CAPTION
vary: MYTH | FACT | AUDIENCE | SPEAKER | SETTING
tip: The myth has to be one a real person actually repeats, quoted as speech on camera — never a straw man. Then the fact, then the mechanism, in that order, and the fact is the line that gets held longest. Corrections are gentle: no shaming the viewer, no "actually" openers stacking up, one correction per reel. If a caption contradicts the voice, the caption loses — one line, corrected, on screen.
idea: An on-camera myth-busting reel about {MYTH — one belief real patients repeat, written as they would say it}, corrected to {FACT — the accurate statement in plain language}, for {AUDIENCE — who is watching}, spoken by {SPEAKER — an on-camera clinician or patient voice with face in frame}, in {SETTING — where the speaker stands, e.g. a consulting room, a kitchen, a pharmacy counter}.

```
integrated_multimodal_description: A vertical 9:16 on-camera reel, 24fps, shot documentary-clean: one speaker — {SPEAKER} — in one honest setting, {SETTING}, natural window or practical light, camera at chest height or slightly above, phone-first framing with the head in the upper-middle safe area and the shoulders filling the lower frame. The speaker talks to the lens the entire time, face always in frame, mouth never covered or turned away, and every spoken line is written verbatim as dialogue in the language it is actually spoken in — the visible lip, jaw and head movement has to match the words exactly. BEAT ENGINE, three shots: MYTH ({MYTH} said once, flat and unhurried, as the speaker's own words, while the shot stays close so the delivery is what holds attention), FACT ({FACT} stated once and clearly — this is the line the viewer remembers, so the framing is steadiest here and nothing moves distractingly), WHY ({AUDIENCE} is shown the reason: the mechanism or evidence in one legible step, either as the speaker explaining it or as a brief insert of the working detail, then back to the speaker to finish). If the request names a proof or a study, describe it only as far as the request does — never invent a number, a trial, a percentage or a patient outcome. TEXT: at most one short quoted English line per shot, bottom third, safe area, exactly as written; a caption may reinforce the fact but never contradict the voice, never carry a dose or a guarantee. CLAIMS HYGIENE: no cure, no guarantee, no diagnosis of the viewer, no "you should stop taking" advice, no fear framing about a named real product or clinic; the reel is educational and may close with a short quoted disclaimer line. TIMING: three even beats across the live runtime — the cuts land where the myth turns into the fact and the fact turns into the reason, never at stamped seconds; the myth lives inside the first two seconds and the fact is held to the end with the speaker still and looking at the lens.

overall_soundscape: the room the speaker stands in, recorded plainly — light traffic, a fridge hum, a corridor — with the small cloth and breath sounds of a person talking close to a phone. Level and honest; no intelligible speech in this field, no stingers.

non_diegetic_music: {one very light bed — a muted pulse or nothing but a low pad, mixed 12 dB under the voice} or exactly N/A so the natural voice carries the reel alone.
```

## Medical reel — the day of the procedure, what happens next
model: h3
tag: medical
description: The walkthrough that answers the fear: what the patient actually experiences, step by step, in the order it happens. Calm hand-held geography, equipment shown as an idea rather than an instrument, zero gore, and the aftercare step held still at the end.
category: Medical / Education
ratio: 9:16
resolution: 768P
duration: 15
music: subtle
structure: multi3
camera: Auto
flows: ARRIVE THEN REASSURE | STEP BY STEP | EQUIPMENT THEN PERSON | ONE ACTION CLOSE
vary: PROCEDURE | STEP | AFTERCARE | SETTING | VISUAL LANGUAGE
tip: Show the room before the treatment and the person's face before the equipment — a viewer who sees where they will stand stops scanning for threats. Nothing sharp is ever shown in close-up, no needle enters skin on screen, no blood, no wound, no exposed surgical field; represent anything clinical at the level of a prepared tray, a gloved hand, a monitor glow. The final step is the one the patient has to do at home, held still for a full second.
idea: A 9:16 patient walkthrough of {PROCEDURE — the procedure or visit, in plain words}, following one person through {STEP — the step that worries them most}, ending on {AFTERCARE — what they do afterwards and what to expect}, in {SETTING — the real kind of room, e.g. a day-clinic bay or a dental suite}, rendered as {VISUAL LANGUAGE — handheld real footage with one clean graphic insert}.

```
integrated_multimodal_description: A vertical 9:16 patient-walkthrough reel in {SETTING}, 24fps, filmed handheld with considered light, rendered as {VISUAL LANGUAGE}: the geography of the room is established before anything clinical happens, the person is followed rather than posed, and the camera stays at the patient's own eye level so the viewer occupies their point of view. CALM IS THE INSTRUCTION: low-contrast warm light, slow and legible motion, no fast push-ins, no percussive cuts, no startling sound — an anxious viewer should be able to watch this twice. BEAT ENGINE, three shots: ARRIVE (the room, the chair or bed, the window, the person set down their bag — the ordinary things first, so the space reads as safe), STEP BY STEP ({STEP} as a short ordered sequence the viewer can follow: what is prepared, who is present, what the person feels or is asked to do — the clinical part stays at the level of a prepared tray, a gloved hand at rest, a monitor glow, a sensor placed on skin with nothing entering it), AFTERCARE AND NEXT ({AFTERCARE} stated once in plain language, with what is normal and what would be worth a phone call, held still and uncluttered for a full second). Never show a needle entering skin, an incision, blood, a wound, a catheter in place, or any exposed surgical field, even if the request asks for realism — replace the moment with the prepared surface, the hand, the monitor or the room's reaction. No identifiable patient, no real clinic name or brand mark, no identifiable staff face unless the request asks for a performer. SPEECH AND TEXT: if a clinician speaks, they are on camera with the mouth unobstructed and the words written verbatim; off-screen voice only with the exact phrase "says in an off-screen voiceover" plus a statement that the lips remain closed; intelligible speech never enters overall_soundscape. At most one short quoted English line per shot, bottom third, safe area, exactly as written — no dose, no percentage, no success rate, no guarantee. FRAMING: the person's hands and face stay inside the middle of the vertical frame. TIMING: three even beats across the live runtime — the cut lands where each step ends, never at a stamped second; the aftercare line is held steady through the final stretch so it can be read twice.

overall_soundscape: the room as it really sounds — a door, a trolley wheel, the hum of equipment, cloth, a chair, the person's own movement — recorded clean and mixed low, with one soft contact sound when a device is placed on the skin. No alarm tones, no monitor beeps for drama, no intelligible speech in this field.

non_diegetic_music: {one calm bed — a soft piano or pad at a slow tempo, mixed under everything} or exactly N/A so the room carries the clip alone.
```
