# CinePrompt Studio — Template Library

> **Loaded at runtime** by the app via fetch('prompts/templates.md'). Edit or extend freely —
> copy any block, change the fields, reload the page (or Learn tab). Malformed blocks are skipped.
>
> Format per template: a '## Title' heading, then 'key: value' metadata lines, then the three-field
> skeleton in a fenced code block. Keys: tag, description, category, ratio, resolution, duration,
> music, structure, camera, idea.

## Brand film — model performance
model: h3
tag: fashion
description: A model performing a brand moment: beats, off-screen direction, optional voiceover line. single take
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
idea: A {AGE} model wearing {GARMENT — colour, fabric, cut} for {BRAND} at {LOCATION} — she {BEAT_1}, then {BEAT_2}, and settles into {FINAL_POSE} while an off-screen director calls out one line of direction.

```
integrated_multimodal_description: Shot on {CAMERA + LENS — e.g. an ARRI Alexa Mini with a Panavision 50mm}, vertical 9:16, 24fps. [Shot 1] {LOCATION dressed as a working set — light stands, backdrop, one crew detail}. A MODEL in {GARMENT — the actual piece: fabric, COLOUR, finish and construction detail} marks her spot, {BEAT_1}, then begins the move. An off-screen voice says "{DIRECTION}" in {TONE}; at the cue her expression shifts and she {BEAT_2}, fabric and hair responding to {WIND/LIGHT}. She finishes on {FINAL_POSE}, holding the last look as the camera {MOVE with end-state, e.g. trucks left, settling tight on her face}. {LIGHTING DESIGN}. {GRADE — palette, contrast, film look}. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 8s total — hook 0-2s, main action 2-6s, settle/CTA 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: {FOOTSTEP / FABRIC sounds — one or two, timed to her beats}, the director's voice carrying, {ONE ambient detail}.

non_diegetic_music: {GENRE} at {TEMPO}, {INSTRUMENTATION}, {dynamics under the final pose}.
```

## Product hero — macro showcase
model: h3
tag: product
description: Object-first commercial: turntable or arc, material detail, no people needed. single take
category: Product Showcase
ratio: 1:1
resolution: 2K
duration: 6
music: subtle
structure: single
camera: Arc shot
idea: {PRODUCT} on {SURFACE} against {BACKDROP} — it rotates slowly as the light traces every material detail, ending on the {HERO DETAIL}.

```
integrated_multimodal_description: Shot on {CAMERA + MACRO LENS, e.g. a RED V-Raptor with a 100mm macro}, 24fps. [Shot 1] A studio set: {BACKDROP}, {SURFACE}, {LIGHTING RIG}. {PRODUCT} rests centered. It rotates slowly while the light traces {MATERIAL DETAILS — mesh, stitching, liquid, grain}; {MICRO-MOTION, e.g. condensation, dust motes} reads in the beam. The camera {arcs/pedestals} with small amplitude at slow speed, ending settled on {HERO DETAIL}. Product stays centered and razor sharp; {RIM/KEY LIGHT behavior}. {GRADE}. No logos or text. TIMING: 6s total — hook 0-2s, main action 2-4s, settle/CTA 4-6s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: Near-silent studio tone, {ONE mechanical or material sound, e.g. turntable whir}.

non_diegetic_music: {Minimal style} at {tempo}, {soft low-end}, fading at the end — or N/A.
```

## Cinematic one-take
model: h3
tag: person
description: Single continuous motivated move, layered beats, atmosphere-first. single take
category: Cinematic Film Scene
ratio: 21:9
resolution: 2K
duration: 10
music: auto
structure: single
camera: Auto
idea: {CHARACTER} in {LOCATION} at {TIME} — {PRIMARY ACTION}, with small human beats around it; the camera {ONE continuous move} and settles on {END FRAME}.

```
integrated_multimodal_description: Shot on {ARRI/Panavision combination}, 24fps, {film grain}. [Shot 1] {LOCATION with layered depth — foreground, mid-ground, background}, {TIME}. {CHARACTER — age, wardrobe, one distinguishing detail} {PRIMARY ACTION}, and around it: {BEAT_1}, then {BEAT_2}, before {BEAT_3 — the turn}. Their expression moves from {STATE A} to {STATE B} in micro-detail. The camera {ONE continuous move}, coming to rest on {END FRAME}. {LIGHTING DESIGN — name the sources}. {GRADE}. TIMING: 10s total — hook 0-2s, main action 2-8s, settle/CTA 8-10s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: {ACTION sounds tied to each beat}, over {AMBIENT BED}.

non_diegetic_music: {INSTRUMENTATION, tempo, dynamics — or exactly N/A}.
```

## Dialogue two-hander
model: h3
tag: dialogue
description: Two speakers, lines in quotes with voice tone, reactions as beats. single take · silent.
category: Dialogue Scene
ratio: 16:9
resolution: 2K
duration: 10
music: none
structure: single
camera: Static shot
idea: {CHARACTER_A} and {CHARACTER_B} at {LOCATION} — A says "{LINE_1}", B reacts and answers "{LINE_2}" as the tension shifts.

```
integrated_multimodal_description: Shot on {CAMERA + LENS}, 24fps. [Shot 1] {LOCATION — decor, light quality, one ambient detail}. {CHARACTER_A} faces {CHARACTER_B} across {SPATIAL RELATION}. A's expression is {STATE}; {micro-beat before speaking}, then A says "{LINE_1}" in a {VOICE TONE}. B {REACTION BEAT — swallow, glance, hands}, and answers "{LINE_2}" in a {VOICE TONE — pace and register}. The power between them shifts: {WHAT CHANGES physically}. The camera holds a static shot at eye level, both faces framed; {LIGHTING}. {GRADE, e.g. cold noir palette}. TIMING: 10s total — hook 0-2s, main action 2-8s, settle/CTA 8-10s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: {ROOM TONE + one recurring ambient sound between the lines}.

non_diegetic_music: N/A
```

## Three-beat multi-shot
model: h3
tag: multi
description: Wide → medium → close detail, real cuts with timecodes, new info per shot. 3 shots · beats: WIDE → CLOSE
category: Multi-Shot Sequence
ratio: 16:9
resolution: 2K
duration: 12
music: auto
structure: multi3
camera: Auto
idea: {SCENE}: shot 1 establishes {WIDE INFO}, shot 2 finds {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} mid-action, shot 3 lands on {CLOSE DETAIL} as {RESOLUTION}.

```
integrated_multimodal_description: Shot on {CAMERA + LENSES}, 24fps. [Shot 1] {WIDE ESTABLISHING — location, time, atmosphere, depth layers}. {WIDE INFO — what actually moves inside the wide}. The camera {MOVE}. [Shot 2] At {T2, inside duration}.000, the camera cuts to {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing}: {WARDROBE consistent with shot 1}, {BEAT developing the action}. [Shot 3] At {T3}.000, the camera cuts to {CLOSE DETAIL}. {MICRO-EXPRESSION or material detail}. {LIGHTING consistent across shots}. {GRADE}. {NEGATION, e.g. No soft dissolves or fluid morphs}. TIMING: 12s total — Shot 1 0-5s, Shot 2 5-9s, Shot 3 9-12s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: {CONTINUOUS sound bed that bridges the cuts}, {cut-specific sounds}.

non_diegetic_music: {SCORE that carries across all three shots}.
```

## Vertical social hook
model: h3
tag: vertical
description: 9:16, one-second hook, direct-to-camera line, fast energy. single take · on a smartphone · beats: HOOK · score: at a fast tem.
category: Social Media Content
ratio: 9:16
resolution: 768P
duration: 5
music: beat
structure: single
camera: Shake slightly
idea: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} in {BRIGHT LOCATION} slams/places {OBJECT} and tells the lens "{HOOK LINE}" — punchy, one take.

```
integrated_multimodal_description: Shot on a smartphone, {24mm-equivalent} at f/1.8, vertical 9:16, handheld energy. [Shot 1] {BRIGHT LOCATION — hard daylight, clean background, one prop}. {CREATOR — 20-32 unless specified: age, look, wardrobe} stands {POSITION}; eyes bright, {HOOK PHYSICAL BEAT — slam/point/lean-in}. They say "{HOOK LINE}" in a {TONE — upbeat, fast, confident}, landing the beat on the {OBJECT/ACTION}. The camera shakes slightly with handheld energy, keeping the face in the upper frame. {LOOK — crisp whites / saturated tones}. TIMING: 5s total — hook 0-2s, main action 2-3s, settle/CTA 3-5s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: {THE signature prop sound}, room tone, {one extra detail}.

non_diegetic_music: {Snappy percussion/groove} at a fast tempo, with an accent hit on the {HOOK MOMENT}.
```

## Music video performance
model: h3
tag: music
description: Performer + wind machine + light sweeps, continuous arc move. single take · score: at .
category: Music Video
ratio: 21:9
resolution: 2K
duration: 10
music: beat
structure: single
camera: Arc shot
idea: {ARTIST} in {STYLIZED LOCATION} performs to the beat as wind and light sculpt the frame; the camera circles in one continuous move.

```
integrated_multimodal_description: Shot on {ARRI anamorphics / cinema camera}, 24fps, {flare character}. [Shot 1] {STYLIZED LOCATION — practicals, haze, repeating geometry}. {ARTIST — wardrobe with movement-friendly detail} performs: {VOCAL GESTURE}, head tipping back on the high note, eyes snapping to the lens; a wind machine sculpts {HAIR/FABRIC}. The camera tracks with large amplitude at fast speed around them in ONE continuous arc as light sweeps rake the frame — no cuts. {HEAVY FLARES / PUSHED GRAIN}. {PALETTE}. TIMING: 10s total — hook 0-2s, main action 2-8s, settle/CTA 8-10s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: {SPACE reverb bed}, cloth snapping in wind, {one electrical/mechanical texture}.

non_diegetic_music: {GENRE} at {BPM}, {KICK/BASS description} locking to the light strobes.
```

## Documentary craft
model: h3
tag: person
description: Hands at work, static close framing, natural sound, no score. single take · silent.
category: Documentary
ratio: 4:3
resolution: 2K
duration: 12
music: none
structure: single
camera: Static shot
idea: {CRAFTSPERSON} at {WORKBENCH} performs {PRECISE TASK} — total absorption, one held close shot, real sound only.

```
integrated_multimodal_description: Shot handheld on a documentary camera, {35mm} at T2.0, natural light, 24fps. [Shot 1] {WORKSHOP — tools, textures, one window source, dust in the beam}. {CRAFTSPERSON — age, hands, one wardrobe detail} {PRECISE TASK}, and around it: {BEAT_1 — preparation}, {BEAT_2 — the attempt}, then {BEAT_3 — the breath after}. Their expression: {ABSORPTION DETAIL — lips, brow, breathing}. The camera holds a static close shot on {HANDS + OBJECT}, shallow focus. Muted true-to-life colors, deep material texture. TIMING: 12s total — hook 0-2s, main action 2-10s, settle/CTA 10-12s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: {THE real sounds of the craft, layered}, {one distant world sound outside}.

non_diegetic_music: N/A
```

## Drone landscape reveal
model: h3
tag: landscape
description: Aerial move with layered depth, natural soundscape, orchestral swell. single take · on a cinema drone · score: A slow orchestral swell.
category: Nature / Landscape
ratio: 21:9
resolution: 2K
duration: 12
music: full
structure: single
camera: Tilt down
idea: {LANDSCAPE} at {TIME} — mist/light in layers; the drone tilts down to reveal {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} below.

```
integrated_multimodal_description: Shot on a cinema drone, {24mm equivalent} at f/2.8, three-axis stabilized, 24fps. [Shot 1] {LANDSCAPE} at {TIME}: {FOREGROUND layer}, {MID-GROUND layer with motion — mist, water, trees}, {BACKGROUND layer in haze}. {WHAT MOVES slowly — mist banks, light, one animal}. The camera tilts down with small amplitude at slow speed, revealing {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing}. Natural light, {EARTHY/COLD grade}. No titles or text. TIMING: 12s total — hook 0-2s, main action 2-10s, settle/CTA 10-12s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: {WIND + WATER + one far sound}, then a single {bird/animal} call, then stillness.

non_diegetic_music: A slow orchestral swell — {LOW STRINGS / distant horn} — rising under the reveal and holding.
```

## Animation character beat
model: h3
tag: animation
description: 2D/3D character moment: style notes, expressive physics, glow/light. single take · score: at a light tem.
category: Animation
ratio: 16:9
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Tracking shot
idea: {CHARACTER} in {STYLIZED WORLD} performs {JOYFUL ACTION} — each movement triggers {LIGHT/PARTICLE reaction}.

```
integrated_multimodal_description: {ANIMATION STYLE, e.g. Hand-drawn 2D over warm watercolor backgrounds}, 24fps, expressive linework with soft glow compositing. [Shot 1] {STYLIZED WORLD — palette, light logic, background detail}. {CHARACTER — shape language, colors, one signature feature} {JOYFUL ACTION}; each movement triggers {REACTION — sparks, swing, particles}, and the character's {ears/tail/eyes} {MICRO-REACTION}. The camera tracks alongside in profile, {PARALLAX layers} passing at different depths. {LIGHT BLOOM behavior}. {PALETTE}. TIMING: 8s total — hook 0-2s, main action 2-6s, settle/CTA 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: {PHYSICAL sounds stylized to match the animation}, {distant world detail}.

non_diegetic_music: {PLAYFUL instrumentation} at a light tempo with {percussion pulse}, brightening with the action.
```

## Seamless product loop
model: h3
tag: product
description: A perfectly loopable product shot: closed 360° camera path, cyclic micro-motion, last frame = first frame.
category: Product Showcase
ratio: 1:1
resolution: 2K
duration: 6
music: subtle
structure: single
camera: Auto
loop: true
idea: {PRODUCT} floating above {SURFACE} against {BACKDROP} — it rotates one full turn as the camera completes a matched 360° orbit, steam/condensation/light particles cycling, ending exactly where it began.

```
integrated_multimodal_description: Shot on {CAMERA + LENS}, 24fps, square framing. [Shot 1] {PRODUCT} floats centered above {SURFACE} against {BACKDROP}. The camera completes one full 360-degree orbit at constant speed while the product rotates in counter-rhythm; {CYCLIC MICRO-MOTION — rising steam, condensation droplets, drifting light particles} repeats on a cycle that reads identically at every point of the orbit. Light comes from {KEY} and {RIM}, specular highlights travelling across {MATERIAL DETAILS} as the angle changes. The orbit closes exactly where it began: the final frame is identical to the first frame in composition, lighting and subject pose — a perfect loop with no visible seam, no cuts, no fades, nothing entering or leaving in the final second. {GRADE}. TIMING: 6s total — hook 0-2s, main action 2-4s, settle/CTA 4-6s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: {ONE continuous cyclic texture — e.g. soft vapor hiss, turntable hum, low air}, constant in level so it loops without an audible seam.

non_diegetic_music: {MINIMAL loop-friendly groove} at {TEMPO} whose bar length divides evenly into {DURATION}s, or exactly N/A.
```

## 🎞️ Recreate from frames
model: h3
tag: preset
preset: true
workflow: multiref
description: Rebuild a video from an ordered sequence of keyframes.
tip: Now add 3–9 sequence frames (in order) under 🖼️ Reference assets — they will be read as numbered contact sheets and the prompt will describe the motion between them.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 10
music: subtle
structure: single
camera: Auto
keyframes: true
idea: Recreate this sequence: {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} in {LOCATION} — follow the attached keyframes in order and invent only the motion between them. TIMING: 10s total — hook 0-2s, main action 2-8s, settle 8-10s. These are proportions of the runtime: change the duration and every segment scales with it.

## 🔁 360° product loop
model: h3
tag: preset
preset: true
description: Perfect seamless loop: closed orbit, final frame = first frame.
tip: Seamless loop armed. Pick Orbit 360° under Camera motion for the classic perfect loop — or any closed path.
category: Product Showcase
ratio: 1:1
resolution: 2K
duration: 6
music: subtle
structure: single
camera: Auto
loop: true
idea: {PRODUCT} centered on {SURFACE} against {BACKDROP} — the camera completes a full 360° orbit as the product rotates in counter-rhythm, ending exactly where it began. TIMING: 6s seamless loop — orbit 0-5s, matching final frame 5-6s. These are proportions of the runtime: change the duration and every segment scales with it.

## 📱 Vertical loop (Reels)
model: h3
tag: preset
preset: true
description: 9:16 seamless loop built for social feeds.
tip: Vertical loop armed — keep the hero centered for the 9:16 frame and choose beat-driven music whose bars divide evenly into the duration.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 6
music: beat
structure: single
camera: Auto
loop: true
idea: {SUBJECT/PRODUCT} fills the vertical frame against {BACKDROP} — {CYCLIC ACTION} repeats on a cycle as the camera holds a gentle closed drift, looping seamlessly. TIMING: 6s seamless loop — orbit 0-5s, matching final frame 5-6s. These are proportions of the runtime: change the duration and every segment scales with it.

## 🖼️ First & last frame
model: h3
tag: preset
preset: true
workflow: fflf
description: Two images define the ends; H3 invents the motion between.
tip: Attach exactly 2 images in 🖼️ Reference assets and set their jobs to "first frame" and "last frame" — the prompt will force the shot to open and land on them.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 8
music: auto
structure: single
camera: Auto
idea: Transform from {STATE A — describe first frame} into {STATE B — describe last frame}: the camera {ONE motivated move} while {WHAT CHANGES between the frames}. TIMING: 8s total — hook 0-2s, main action 2-6s, settle 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

## 🎭 Identity lock
model: h3
tag: preset
preset: true
workflow: multiref
description: Keep one character perfectly consistent across a clip or series.
tip: Attach a character reference image and write its job as "talent — preserve identity exactly: {hair}, {eyes}, {wardrobe}, {distinguishing detail}". The prompt will list those features as an identity lock.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 10
music: auto
structure: single
camera: Auto
idea: {CHARACTER} in {LOCATION} — {ACTION with 2-3 human beats}; their appearance must match the attached reference exactly throughout. TIMING: 10s total — hook 0-2s, main action 2-8s, settle 8-10s. These are proportions of the runtime: change the duration and every segment scales with it.

## 🎵 Beat-sync cuts
model: h3
tag: preset
preset: true
description: Three cuts that land exactly on the music beats.
tip: Beat-driven score armed with 3 shots — name the track style in the idea and the cuts will be written to land on its beats.
category: Music Video
ratio: 16:9
resolution: 2K
duration: 9
music: beat
structure: multi3
camera: Auto
idea: {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} in {LOCATION} — {ACTION}. Three escalating angles cut on the beat: {BEAT 1 moment}, {BEAT 2 moment}, {BEAT 3 climax}. TIMING: 9s total — hook 0-2s, main action 2-7s, settle 7-9s. These are proportions of the runtime: change the duration and every segment scales with it.

## 🌅 Day → night
model: h3
tag: preset
preset: true
description: Slow cinematic time-shift in one continuous take.
tip: Single 12-second take armed — describe both light states in the idea; optionally attach two reference frames (day = first frame, night = last frame).
category: Cinematic Film Scene
ratio: 21:9
resolution: 2K
duration: 12
music: subtle
structure: single
camera: Push in
idea: {LOCATION} in golden daylight slowly sinking into night: {WHAT CHANGES — lights igniting, shadows stretching, sky shifting} while the camera {ONE slow move}. TIMING: 12s total — hook 0-2s, main action 2-10s, settle 10-12s. These are proportions of the runtime: change the duration and every segment scales with it.

## 🗣️ Talking head
model: h3
tag: preset
preset: true
description: Spokesperson / dialogue shot with natural delivery beats.
tip: Dialogue mode armed — replace {LINE} in the idea, and attach a face reference with job "talent — preserve identity" for a consistent speaker.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
dialogue: {LINE}
idea: {CHARACTER} speaks to camera in {LOCATION}: "{LINE}" — delivered with {TONE}, natural blinks, breaths and hand beats between phrases. TIMING: 8s total — hook 0-2s, main action 2-6s, settle 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

## 📦 Cross-post pack
model: h3
tag: preset
preset: true
description: One idea, three masters: 16:9 + 9:16 + 1:1 for every platform.
tip: Generate the 16:9 master first. Then flip the ratio chips to 9:16 (recompose vertical: hero centered) and 1:1 and generate again — History keeps all three versions.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 8
music: auto
structure: single
camera: Auto
idea: {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} in {LOCATION} — {ACTION}; compose the hero with headroom and lead-room so the moment survives re-crops to vertical and square. TIMING: 8s total — hook 0-2s, main action 2-6s, settle 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

## 💡 Before / after relight
model: h3
tag: preset
preset: true
workflow: fflf
description: Same scene, completely new lighting — composition untouched.
tip: Attach your original frame and set its job to "first frame — keep everything, change only the light". The prompt preserves composition while swapping the lighting design.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 8
music: auto
structure: single
camera: Auto
idea: Same scene, new light: {SCENE as it is now} re-lit as {NEW LIGHTING — night neon / golden hour / candlelight}; composition and subject unchanged, only illumination transforms. TIMING: 8s total — hook 0-2s, main action 2-6s, settle 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

## 🚁 Drone flythrough
model: h3
tag: preset
preset: true
description: One continuous aerial flight: approach → thread → reveal.
tip: Describe the flight path in order (start high, thread the gap, reveal the vista) — H3 follows spatial paths well. Keep it one shot, no cuts.
category: Cinematic Film Scene
ratio: 21:9
resolution: 2K
duration: 12
music: auto
structure: single
camera: Tracking shot
idea: Aerial drone flythrough of {LOCATION}: start {START — high above the ridge}, thread {OBSTACLE/PATH — between the towers}, and reveal {FINAL VISTA} in one continuous flight. TIMING: 12s total — hook 0-2s, main action 2-10s, settle 10-12s. These are proportions of the runtime: change the duration and every segment scales with it.

## 🍜 Food macro steam
model: h3
tag: preset
preset: true
description: Macro hero shot: steam, glisten, sizzle — appetite on camera.
tip: Macro plus cyclic steam/drips also loops beautifully — arm 🔁 Loop in the Camera section for a looping food hero.
category: Product Showcase
ratio: 1:1
resolution: 2K
duration: 6
music: subtle
structure: single
camera: Arc shot
idea: {DISH} fresh from {SOURCE — oven / pan / pour}: steam curls upward in slow macro, {DETAIL — sauce glisten, crust crackle, condensation beads}, lit by {LIGHT}. TIMING: 6s total — hook 0-2s, main action 2-4s, settle 4-6s. These are proportions of the runtime: change the duration and every segment scales with it.

## ⚡ Sports burst
model: h3
tag: preset
preset: true
description: Three escalating cuts around one decisive athletic moment.
tip: Name the decisive split-second in the idea — the 3 cuts escalate: wind-up → impact → aftermath, all landing on the beat.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 9
music: beat
structure: multi3
camera: Auto
idea: {ATHLETE} in {ARENA} — {MOVEMENT}: cut 1 the wind-up coils, cut 2 the impact freezes mid-air, cut 3 the aftermath erupts. TIMING: 9s total — hook 0-2s, main action 2-7s, settle 7-9s. These are proportions of the runtime: change the duration and every segment scales with it.

## 🤳 UGC testimonial
model: h3
tag: preset
preset: true
description: Handheld selfie-style review that sells because it feels real.
tip: Handheld imperfection sells the authenticity — keep it slightly unpolished. Replace {LINE} with the testimonial and attach a face reference to lock the creator.
category: Cinematic Film Scene
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
dialogue: {LINE}
idea: Handheld selfie-style: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} talks to camera from {LOCATION}: "{LINE}" — natural ums, a smile mid-sentence, one glance away, then back. TIMING: 8s total — hook 0-2s, main action 2-6s, settle 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

## 🎄 Seasonal ad pack
model: h3
tag: preset
preset: true
description: One product beat, re-skinned for every festival and season.
tip: Generate once per season: swap {HOLIDAY} and the palette in the idea (Diwali golds, Christmas reds, summer teals). Keep the product beat identical for brand continuity.
category: Product Showcase
ratio: 9:16
resolution: 2K
duration: 6
music: beat
structure: single
camera: Auto
idea: {PRODUCT} celebrating {HOLIDAY}: {SEASONAL ELEMENTS — lights / petals / snow / rangoli} swirl around it in {PALETTE}, ending on the hero product beat. TIMING: 6s total — hook 0-2s, main action 2-4s, settle 4-6s. These are proportions of the runtime: change the duration and every segment scales with it.

## Editorial fashion film
model: h3
tag: fashion
description: The flagship editorial fashion film, upgraded so EVERYTHING varies — outfit design, model, presentation, action, garment interaction, location and camera each come from a pool per variant, and the beats themselves run on four different architectures.
category: Fashion / Lifestyle
ratio: 16:9
resolution: 2K
duration: 10
music: subtle
structure: auto
camera: Auto
flows: TEXTURE → MOVE → HOLD | ARRIVE → REVEAL → EXIT | DETAIL CASCADE | SINGLE SWEEP
vary: OUTFIT DESIGN | OUTFIT COLOUR | MODEL | PRESENTATION | ACTION | OUTFIT INTERACTION | LOCATION | CAMERA | MOVEMENT | RHYTHM ENVELOPE | SCALE LADDER | CUT MOTIVATION | FRAMING DEVICE | OPEN DEVICE | CLOSE DEVICE | TRANSITION | SOUND FORMAT
tip: Everything varies — name the outfit, the model, her presentation, the action, the garment interaction, the location and the camera, and each becomes a beat; the run's variants draw different options from every pool, so no two outputs share a look. Leave a dimension unnamed and it disappears from the film.
idea: {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish} worn by {MODEL — 20-32 unless specified: age, hair, skin, build} whose presentation is {PRESENTATION — how she carries herself}; she {ACTION — the physical action of the clip} and {OUTFIT INTERACTION — what her hands do with the garment} at {LOCATION — the place, its light and its one landmark}, shot as {CAMERA — the lens and the move}, and this variant's own {MOVEMENT — how her body travels}.

```
integrated_multimodal_description: Shot on {CAMERA — the lens and the move: body, focal length, speed and the end-state it settles on}, 24fps, {MEDIUM — film stock or digital texture, e.g. 35mm grain, clean digital}. MEDIUM AND STYLE DECLARATION FIRST: name the format (editorial fashion film), the palette and the light design before the first shot. LOOK LOCK: {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish} keeps the same cut, fabric weight and colour in every shot — describe the silhouette once, then refer to it as "the same coat / the same slip dress". {MODEL — 20-32 unless specified: age, hair, skin, build} keeps identical features, hair and skin tone throughout; scale the beats to the requested duration. BEAT ENGINE — one beat per NAMED dimension, in physical order: FABRIC (a macro or raking-light beat on the weave, seam or hem — the material's behaviour in light, shallow focus) · PRESENTATION ({PRESENTATION — how she carries herself}: the posture, the gaze direction and the stillness-before-movement read in the body before she moves) · ACTION ({ACTION — the physical action of the clip}, written as a chain of small physical events, not one gesture) · INTERACTION ({OUTFIT INTERACTION — what her hands do with the garment}: the fabric answers the hand — it gathers, releases, swings, settles late) · LOCATION ({LOCATION — the place, its light and its one landmark}: the environment proves itself in one legible background detail, never a blurred backdrop) · CAMERA ({CAMERA — the lens and the move}: one motivated move with amplitude, speed and an end-state; the framing changes on the beat, not at random). Skip any dimension that is not named; never invent a second garment, a second model, a logo card or a smile to camera. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: classic editorial → TEXTURE → MOVE → HOLD, an entrance story → ARRIVE → REVEAL → EXIT, construction-led garment → DETAIL CASCADE, one continuous piece of movement → SINGLE SWEEP. TEXTURE → MOVE → HOLD = fabric macro, then the full figure in movement, then the sculptural hold. ARRIVE → REVEAL → EXIT = she enters the location, the garment reveals itself as she turns, she leaves the frame and the camera holds the empty space a beat. DETAIL CASCADE = three tight beats down the garment — collar or neckline, waist or closure, hem or shoe — each with its own light. SINGLE SWEEP = no cuts at all: one continuous move that passes the garment and comes to rest on her face. TIMING: 10s total — 3 stamped shots of about 3s, one new visible act every 1-1.5s inside them, no action held longer than 2s, and the final second a settled hold.

overall_soundscape: fabric moving through air, footsteps on {FLOOR — the surface underfoot}, {LOCATION'S ambient layer — the place's own sound, e.g. a distant street, wind in leaves, room tone}, and no speech.

non_diegetic_music: {one rhythmic bed — low pulse or sparse percussive loop} at a steady tempo that follows the beats, or exactly N/A for pure editorial silence.
```
## Try-on 360 reveal
model: h3
tag: fashion
description: Locked full-body frame, the model turns in place — the real short-form try-on grammar (front hook → turn → back reveal → profile close), duration-scaled.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 6
music: beat
structure: single
camera: Static shot
idea: {MODEL — 20-32 unless specified: age, hair, build} tries on {TOP — colour and finish, cut, detail} with {BOTTOM — colour and print, fit} in {CORNER SET — plain wall + leather sofa + big plant + mirror edge}: she presents front, turns through the back, and ends on a profile beat with eye contact.

```
integrated_multimodal_description: Shot on a smartphone, {35mm-equivalent} at f/2.0, vertical 9:16, a LOCKED full-body tripod frame from head to toe with breathing room above the hair; a bright aspirational corner — {CORNER SET}; soft diffused window light, no harsh shadows, 24fps. [Shot 1] BEAT 1 HOOK (0-1s): {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} faces camera mid-presentation, weight on one hip, one hand {GESTURE 1 — brushing hair back / adjusting the collar}; she wears {TOP described precisely: colour and finish, cut, sleeve volume, neckline, ties or hardware} and {BOTTOM described precisely: colour and print, rise, hem, fit}. BEAT 2 TURN: she rotates away in one smooth motion, hair swinging, {FABRIC DETAIL — puff sleeve / hem sway / print shift} reading mid-turn. BEAT 3 BACK REVEAL: full back view as one hand lifts through her hair to show {BACK DETAIL — open back, tie strings, zip, shirring}; a small weight shift makes the hem sway. BEAT 4 CLOSE: she turns to profile, both hands {GESTURE 2 — playing with the tie strings / smoothing the hem}, then meets the lens with a soft direct gaze and holds. DURATION-SCALED: at 5-6s keep exactly these four beats; at 8-10s add a second front gesture beat (pocket check, hoop-earring adjust) after the back reveal; at 12-15s add a two-step walk-in before the hook and a mirror-reflection beat before the close. One hand gesture per beat; every beat showcases ONE garment detail; nothing holds still longer than 1.5s. Natural skin texture, true fabric color, no logos, no on-screen text, crisp bright grade. TIMING: 6s total — reference density: 4 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: soft room tone, faint fabric rustle on each turn, one hair swish, light footfall on {FLOOR}{VOICEOVER — optional: , and her quick presentational line in quotes, upbeat and breathless}.

non_diegetic_music: {upbeat minimal groove — muted percussion, soft synth plucks} at a medium-fast tempo with a small accent tick on each turn beat; or exactly N/A when the voiceover leads.
```

## Walk-in approach
model: h3
tag: fashion
description: The walk-in: the garment arrives before the face does. Everything varies — the march, the presentation, the garment's reaction and the room she walks into all come from pools, on four different beat architectures. An adaptive version of this preset ships as “👗 Fashion preset film — adaptive beats” (adaptive-films.md) — beats derived from what you name.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: beat
structure: single
camera: Auto
flows: DOORS OPEN → WALK → STOP | LOW APPROACH | CROWD SPLIT | CIRCLING ARRIVAL
vary: OUTFIT DESIGN | OUTFIT COLOUR | MODEL | PRESENTATION | ACTION | OUTFIT INTERACTION | LOCATION | CAMERA | MOVEMENT | RHYTHM ENVELOPE | SCALE LADDER | CUT MOTIVATION | FRAMING DEVICE | OPEN DEVICE | CLOSE DEVICE | TRANSITION | SOUND FORMAT
tip: Everything varies — the same walk-in yields a street, a marble hall or a night pavement depending on the pools your variant draws. Name the surface she walks on: footsteps are half the beat.
idea: {MODEL — 20-32 unless specified: age, hair, skin, build} walking toward the camera in {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish}, presenting as {PRESENTATION — how she carries herself}, {ACTION — the physical action: the approach, the stop, what follows} while {OUTFIT INTERACTION — what she does with the garment mid-walk}, arriving into {LOCATION — the place, its light and its one landmark}, shot as {CAMERA — the lens and the move}, and this variant's own {MOVEMENT — how her body travels}.

```
integrated_multimodal_description: Shot on {CAMERA — the lens and the move: body, focal length, speed, end-state}, vertical 9:16, 24fps, {MEDIUM — stock or digital texture}. The walk is the whole film, so the surfaces carry it: {LOCATION — the place, its light and its one landmark} — the light source is legible in frame, the background has depth and one readable landmark, and the ground reflects or absorbs light as its material demands. {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish} moves as one weight: the hem leads, the fabric lags a beat behind her body, shadows on the ground answer the movement. {MODEL — 20-32 unless specified: age, hair, skin, build} holds identical features across the clip; her {PRESENTATION — how she carries herself} is readable in the first three steps — posture, arm swing, gaze, chin. BEAT ENGINE — one beat per NAMED dimension: APPROACH (a boot or shoe meeting {FLOOR — the surface}, then the stride establishing itself; the hem enters frame before the face does) · BODY (the garment's movement physics: fabric swinging, a coat opening, a skirt catching air, the fold lines changing with the step) · INTERACTION ({OUTFIT INTERACTION — what she does with the garment mid-walk}: hands in pockets, a cuff tugged, a strap adjusted, all without breaking stride) · ARRIVAL ({ACTION — the physical action: the approach, the stop, what follows}: the stop happens with weight, one foot planting, the body still moving for a beat after the feet stop) · PRESENCE ({PRESENTATION — how she carries herself}: the held look, one breath, the fabric settling last). Skip any dimension that is not named; never add a second model, a crowd that was not named, signage or a logo. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: a classic entrance → DOORS OPEN → WALK → STOP, an imposing garment → LOW APPROACH, a busy street → CROWD SPLIT, a presentation-led clip → CIRCLING ARRIVAL. DOORS OPEN → WALK → STOP = a doorway or threshold opens first, the walk follows, the stop is the last beat. LOW APPROACH = the camera starts at knee height and rises with her as she closes the distance. CROWD SPLIT = extras part around her without acknowledging her, the camera tracking from within the crowd. CIRCLING ARRIVAL = she walks past the lens and the camera arcs to meet her front-on at the stop. TIMING: 8s total — a new visible act every 1-1.5s (footfall, fabric event, hand event, gaze), the stop and hold inside the final 2s, nothing held static before the stop.

overall_soundscape: footsteps on {FLOOR — the surface}, the garment's own sound (fabric swing, a zip, leather creak), {LOCATION'S ambient layer — one continuous bed}, no speech.

non_diegetic_music: {a beat-driven bed} locked to the footfalls, ducking a fraction on the stop; or exactly N/A.
```
## Detail bookend
model: h3
tag: fashion
description: Faceless fabric close opens and closes the clip; wide presentation with a prop in between. Texture-first garment storytelling. An adaptive version of this preset ships as “👗 Fashion preset film — adaptive beats” (adaptive-films.md) — beats derived from what you name.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 8
music: subtle
structure: single
camera: Static shot
idea: {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} in {DRESS — colour and finish, fabric with visible texture: eyelet / rib / print} with {PROP — straw bag / tote}: opens on the fabric close, widens to a full-body presentation, walks in, ends back on the texture.

```
integrated_multimodal_description: Shot on a smartphone, {35mm-equivalent} at f/2.0, vertical 9:16, LOCKED tripod frame in {ROOM — bright open-plan interior with vaulted ceiling and layered depth}; 24fps. [Shot 1] BEAT 1 FABRIC CLOSE (faceless): torso-only framing on {DRESS COLOUR + FABRIC — the colour and finish, and the texture: eyelet / rib / weave / print}, both hands adjusting {TIE OR SASH} at the waist, {PROP handle} caught in one hand; stitching and texture razor sharp, shallow focus on the cloth. BEAT 2 WIDE REVEAL: framing widens (or she steps back) to full body — {MODEL — 20-32 unless specified: hair, smile, jewelry} presents the {DRESS silhouette + colour: neckline, waist, skirt flare, hem length}, {PROP} swinging gently at her side, one hand brushes her hair, she talks or smiles to camera. BEAT 3 WALK-IN: two or three steps toward the lens, {PROP} swinging, hem moving with each step, weight shifts making the skirt sway. BEAT 4 FABRIC CLOSE (faceless): back to the torso framing, hand smooths the skirt so the texture reads one last time, {TIE} ends settled. DURATION-SCALED: 5-6s = beats 1+2+4; 8-10s = all four; 12-15s add a turn beat at the wide (quarter turn showing the back, prop changing hands) and a second walk pass. Camera never moves or zooms; size changes come from her distance. Natural skin texture, true fabric color, no logos, no text. TIMING: 8s total — reference density: 6 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: soft room tone, {PROP} rustle or handle creak, faint fabric swish on the walk, light footfall on {FLOOR}.

non_diegetic_music: {soft acoustic or muted lounge bed} at a relaxed tempo, one gentle accent on the wide reveal; or exactly N/A.
```

## 360° garment turntable
model: h3
tag: product
description: E-commerce turn: model rotates slowly front to side to back — drape and construction from every angle.
category: Product Showcase
ratio: 1:1
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Static shot
idea: A model wearing {GARMENT — colour, fabric, cut} on {CLEAN SET — seamless cyclorama / soft daylight studio} turns one slow, continuous rotation showing front, side and back; fabric shifts weight naturally with each angle.

```
integrated_multimodal_description: Shot on {85mm prime}, 24fps. [Shot 1] {CLEAN SET — seamless background, soft even key with gentle side fill}. A model stands centered wearing {GARMENT — fabric, COLOUR and finish, construction detail}. She turns slowly and naturally through one full rotation: front — a half-beat pause, hand {SMALL GESTURE, e.g. smoothing the lapel}; side — the silhouette and drape line read clearly; back — {BACK DETAILS — seam, vent, print}; continuing without snapping or reversing back to front. The camera stays locked-off at {DISTANCE, e.g. full-body headroom}; only the model moves. {FABRIC BEHAVIOR — weight, swing, settle} reads at each angle. Identity stays exact throughout: same face, hair, fit, lighting. {GRADE}. No text or logos. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 8s total — reference density: 6 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only.

overall_soundscape: soft studio tone, faint fabric movement with each turn, controlled breathing.

non_diegetic_music: {minimal neutral bed at low level} or exactly N/A for clean product pages.
```

## Street-style walk
model: h3
tag: fashion
description: Street style: the garment cut out of a real street by light and timing. Everything varies — outfit, model, presentation, action, interaction, street and camera come from pools, across four beat architectures. An adaptive version of this preset ships as “👗 Fashion preset film — adaptive beats” (adaptive-films.md) — beats derived from what you name.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: beat
structure: single
camera: Auto
flows: PASS-BY | FOLLOW → TURN | STREET CORNER SETUP | TEXTURE OF THE PAVEMENT
vary: OUTFIT DESIGN | OUTFIT COLOUR | MODEL | PRESENTATION | ACTION | OUTFIT INTERACTION | LOCATION | CAMERA | MOVEMENT | RHYTHM ENVELOPE | SCALE LADDER | CUT MOTIVATION | FRAMING DEVICE | OPEN DEVICE | CLOSE DEVICE | TRANSITION | SOUND FORMAT
tip: Everything varies — the street itself is a character: name the ground, the light and the one landmark, and they will land in the frame. The pavement texture close-up is what makes it read street, not studio.
idea: {MODEL — 20-32 unless specified: age, hair, skin, build} on the street in {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish}, presenting as {PRESENTATION — how she carries herself}, {ACTION — the physical action: crossing, pausing, turning back} and {OUTFIT INTERACTION — what she does with the garment}, shot on {LOCATION — the street, its light and its one landmark} with {CAMERA — the lens and the move}, and this variant's own {MOVEMENT — how her body travels}.

```
integrated_multimodal_description: Shot on {CAMERA — the lens and the move with its end-state}, vertical 9:16, 24fps, {MEDIUM — 35mm grain, or clean digital}. STREET TRUTH FIRST: {LOCATION — the street, its light and its one landmark} must be real and specific — the pavement texture, the kerb, a doorway, a shopfront sign in an unfocused background, reflections in a puddle if wet; the light is the street's own (hard morning sun through buildings, overcast evenness, sodium at night), and the background carries life without stealing focus. {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish} keeps its cut, palette and fabric through the clip. {MODEL — 20-32 unless specified: age, hair, skin, build} identical throughout. BEAT ENGINE — one beat per NAMED dimension: GROUND (a low or walking-height beat where {FLOOR — the surface: wet asphalt, cobbles, dry dust} fills the frame and the feet enter) · SILHOUETTE ({PRESENTATION — how she carries herself} read against the street: the posture, the line of the garment, the way the light cuts the figure from the background) · MOTION ({ACTION — the physical action}, written as physical events with real timing, not a vague walk) · DETAIL ({OUTFIT INTERACTION — what she does with the garment}: hands, closures, a strap, the fabric's own reaction to the step) · DEPARTURE (the last beat: she exits frame, or turns into the lens and stops it cold, one held look). Skip any dimension that is not named; no passers-by unless they are named, no signage text, no brand marks, no faked street clutter. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: a pure garment clip → PASS-BY, a performance → FOLLOW → TURN, an establishing street → STREET CORNER SETUP, texture-led → TEXTURE OF THE PAVEMENT. PASS-BY = she crosses the frame laterally, the camera holds, the street does the work. FOLLOW → TURN = the camera follows one step behind and she turns back into the lens. STREET CORNER SETUP = she waits, adjusts, then moves on the beat. TEXTURE OF THE PAVEMENT = the clip opens and closes on the ground, with her crossing between. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 8s total — a new visible act every 1-1.5s, the walk never straight-line the whole way, the final look inside the last 1.5s.

overall_soundscape: real street layer — footsteps on {FLOOR — the surface}, traffic or wind at distance, one nearby human sound (a door, a bicycle, a laugh across the road), no speech.

non_diegetic_music: {a light beat bed} that sits under the street but never replaces it; or exactly N/A so the location carries it.
```
## Lookbook quick-cuts
model: h3
tag: fashion
description: The lookbook cutdown: several looks, each in one decisive beat. Everything varies — each look's outfit, the model, presentation, action, interaction, location and camera all draw from the pools per variant.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 10
music: beat
structure: auto
camera: Auto
flows: THREE LOOKS × ONE BEAT | FOUR-BEAT DRUM | LOOK FIRST, MODEL SECOND | ONE LOCATION, MANY GARMENTS
vary: OUTFIT DESIGN | OUTFIT COLOUR | MODEL | PRESENTATION | ACTION | OUTFIT INTERACTION | LOCATION | CAMERA | MOVEMENT | RHYTHM ENVELOPE | SCALE LADDER | CUT MOTIVATION | FRAMING DEVICE | OPEN DEVICE | CLOSE DEVICE | TRANSITION | SOUND FORMAT
tip: Everything varies — one look per shot, one decisive beat per look. Name the looks in order and each becomes a shot; naming a garment detail per look is what stops them blurring together.
idea: {MODEL — 20-32 unless specified: age, hair, skin, build} presenting {OUTFIT DESIGN — the looks in order, each: silhouette, fabric, one construction detail} in {OUTFIT COLOUR — each look's colour family and finish}; her presentation is {PRESENTATION — how she carries herself}, each look gets {ACTION — what happens in that beat} and {OUTFIT INTERACTION — the garment moment}, all at {LOCATION — the place and its light}, shot as {CAMERA — the lens and the move}, and this variant's own {MOVEMENT — how her body travels}.

```
integrated_multimodal_description: Shot on {CAMERA — one lens and one move language, reused per look with the framing changing}, vertical 9:16, 24fps, {MEDIUM — stock or digital texture}. CONSISTENCY FIRST: {MODEL — 20-32 unless specified: age, hair, skin, build} is identical in every shot — same face, hair and body; only the garment changes. {LOCATION — the place and its light} stays the same place (or one clearly-stated progression) so the eye reads the clothes, not the set. {PRESENTATION — how she carries herself} shifts slightly per look — each garment gets its own posture. BEAT ENGINE — one shot per NAMED look, one decisive beat inside each: SILHOUETTE (the look is legible in the first half-second: colour, cut, proportion) · GARMENT DETAIL (one construction detail per look reads clearly — a collar, a cuff, a hem, a closure) · INTERACTION ({OUTFIT INTERACTION — the garment moment}: one hand event per look, never the same event twice in the clip) · TRANSITION (the cut itself carries the rhythm: a hard cut on the beat, or a match cut through a shared shape — never a soft dissolve) · CLOSE (the final look gets the longest beat and the still hold). Skip any look that is not named and never repeat a garment detail across looks; no on-screen garment names or prices. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: a standard cutdown → THREE LOOKS × ONE BEAT, a fast piece → FOUR-BEAT DRUM, a model-led piece → LOOK FIRST, MODEL SECOND, one set → ONE LOCATION, MANY GARMENTS. THREE LOOKS × ONE BEAT = three shots, one beat each. FOUR-BEAT DRUM = four looks in ten seconds, each cut landing on the beat. LOOK FIRST, MODEL SECOND = open on the garments alone or cropped, the face revealed only in the last shot. ONE LOCATION, MANY GARMENTS = one continuous setting, the looks changing between shots. TIMING: 10s total — one shot per look, cuts on the beat, a detail legible inside each shot, the last look held for the final 1.5s.

overall_soundscape: {LOCATION'S ambient bed} with the garment sounds changing per look (fabric, chain, leather, a heel), footsteps on {FLOOR — the surface}; no speech.

non_diegetic_music: {a beat bed with a hard accent on every cut} — the cuts must land on the accents; or exactly N/A.
```
## Fabric macro detail
model: h3
tag: product
description: The detail that sells the fabric: weave, stitching, sheen — raking light, shallow focus. single take
category: Product Showcase
ratio: 1:1
resolution: 2K
duration: 6
music: subtle
structure: single
camera: Push in
idea: Extreme macro of {FABRIC/GARMENT DETAIL — colour, weave, embroidery, buttons, drape}: raking light reveals texture as the camera glides across the surface, fingers or movement disturb it gently.

```
integrated_multimodal_description: Shot on {100mm macro}, 24fps, extremely shallow depth of field. [Shot 1] {GARMENT DETAIL — colour, weave, hardware} fills the frame. Light rakes at a steep angle — {LIGHT BY FABRIC — silk = oblique diffuse + specular line; tweed = hard side light; sequin = strip light; knit = soft key}. The camera glides slowly across the surface with small amplitude at slow speed; focus racks gently from {PLANE A — a seam / button} to {PLANE B — the drape beyond}. {MICRO-DISTURBANCE — fingertips graze the pile / a breath of air lifts chiffon / the fabric settles after movement}. {THREAD/WEAVE/KNIT details visible}. {GRADE}. No logos. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 6s total — reference density: 4 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only.

overall_soundscape: near-silence amplified — {ONE tactile sound: fibers brushing, a button tap, cloth settling}, faint room air.

non_diegetic_music: {a single sustained texture — soft pad or felt piano} or exactly N/A.
```

## GRWM styling moment
model: h3
tag: fashion
description: Get-ready-with-me: the garment goes ON. Everything varies — what is worn, who wears it, how it is presented, the action, the handling, the room and the camera all come from pools.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 10
music: subtle
structure: multi2
camera: Auto
flows: PIECE BY PIECE | MIRROR WORK | FINAL ADJUSTMENT | REVEAL TO CAMERA
vary: OUTFIT DESIGN | OUTFIT COLOUR | MODEL | PRESENTATION | ACTION | OUTFIT INTERACTION | LOCATION | CAMERA | MOVEMENT | RHYTHM ENVELOPE | SCALE LADDER | CUT MOTIVATION | FRAMING DEVICE | OPEN DEVICE | CLOSE DEVICE | TRANSITION | SOUND FORMAT
tip: Everything varies — the dressing order is the beat order: name the pieces and each becomes a beat. Leave one out and the clip skips it. The mirror is a tool, not a crutch: name how much of the frame it takes.
idea: {MODEL — 20-32 unless specified: age, hair, skin, build} getting dressed in {LOCATION — the room, its light and what makes it lived-in}: {OUTFIT DESIGN — the pieces in the order they go on} in {OUTFIT COLOUR — the pieces' colour family and finish} while presenting as {PRESENTATION — how she carries herself}, {ACTION — what she does between pieces} and {OUTFIT INTERACTION — how she handles each piece}, shot as {CAMERA — the lens and the move}, and this variant's own {MOVEMENT — how her body travels}.

```
integrated_multimodal_description: Shot on {CAMERA — the lens and the move}, vertical 9:16, 24fps, {MEDIUM — stock or digital texture}. ROOM TRUTH FIRST: {LOCATION — the room, its light and what makes it lived-in} with one strong light source (window, lamp or vanity bulb), and small real objects at the edges of frame — a chair with yesterday's clothes, a phone, a cup, jewellery tray — never a styled set. {MODEL — 20-32 unless specified: age, hair, skin, build} identical throughout; her {PRESENTATION — how she carries herself} shows in how she handles the clothes: unhurried, familiar, precise. BEAT ENGINE — one beat per NAMED piece and dimension: PIECE (each garment named enters the story in its own beat — it is picked up, opened, stepped into or pulled over, with the fabric's behaviour in the hand) · INTERACTION ({OUTFIT INTERACTION — how she handles each piece}: zip, clasp, tie, fold, sleeve — the fastener is the action, not a gesture near it) · ADJUSTMENT ({ACTION — what she does between pieces}: a step back, a look down, a turn of the ankle in a new shoe, hair lifted out of a collar) · PRESENTATION ({PRESENTATION — how she carries herself}: the moment she stops dressing and becomes the look — spine, chin, hands placed) · FINISH (one deliberate final touch that ends the clip: a strap settled, a lapel straightened, one last look). Skip any piece or dimension that is not named; never add a second person, a pet, a ring light, or sped-up footage. MIRROR RULE: a mirror may be in frame only if named — show her reflection doing something her back already proves, never a double image of the same action. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: a clean sequence → PIECE BY PIECE, a performance → MIRROR WORK, craft-led → FINAL ADJUSTMENT, a social reel → REVEAL TO CAMERA. PIECE BY PIECE = the dressing order is the edit, one piece per beat. MIRROR WORK = the reflection does half the storytelling, the camera holding on the glass. FINAL ADJUSTMENT = the clip is mostly the last ten seconds of getting ready. REVEAL TO CAMERA = she finishes and turns to the lens in the final beat. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 10s total — 4-5 beats of about 2s, one deliberate hand event per beat, the final look in the last 1.5s.

overall_soundscape: the room's real detail — fabric over skin, a zip, a clasp, jewellery settling, a drawer, bare feet or heels on {FLOOR — the surface}, quiet room tone; no speech unless a line is named.

non_diegetic_music: {soft rhythmic bed — a looped drum, a muted guitar} at a relaxed tempo that follows the dressing beats; or exactly N/A.
```
## OOTD 5-second hook
model: h3
tag: fashion
description: The five-second OOTD hook: one garment, one reveal, no wasted frames. Everything varies — outfit, model, presentation, action, interaction, location and camera come from pools on four architectures.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 5
music: beat
structure: single
camera: Auto
flows: WHIP REVEAL | STEP-IN REVEAL | SPIN REVEAL | DETAIL FIRST
vary: OUTFIT DESIGN | OUTFIT COLOUR | MODEL | PRESENTATION | ACTION | OUTFIT INTERACTION | LOCATION | CAMERA | MOVEMENT | RHYTHM ENVELOPE | SCALE LADDER | CUT MOTIVATION | FRAMING DEVICE | OPEN DEVICE | CLOSE DEVICE | TRANSITION | SOUND FORMAT
tip: Everything varies — in five seconds only ONE thing can be the hook: name it (the fabric reveal, the step-in, the spin) and the rest of the clip is built to land on it. Unnamed details are noise here.
idea: {MODEL — 20-32 unless specified: age, hair, skin, build} in {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish}, presenting as {PRESENTATION — how she carries herself}, doing {ACTION — the single action that drives the hook} with {OUTFIT INTERACTION — the one garment moment}, at {LOCATION — the place and its light}, shot as {CAMERA — the lens and the move}, and this variant's own {MOVEMENT — how her body travels}.

```
integrated_multimodal_description: Shot on {CAMERA — the lens and the move, with an end-state inside 5 seconds}, vertical 9:16, 768P, 24fps, {MEDIUM — handheld phone-look or clean digital}. HOOK RULE: the first 700 milliseconds must contain visible movement and the garment's silhouette — no still opening, no logo, no text. {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish} is legible within the first second: its colour, its cut, and how it moves. {MODEL — 20-32 unless specified: age, hair, skin, build} identical throughout. BEAT ENGINE — exactly one NAMED hook plus one closing beat: HOOK ({ACTION — the single action that drives the hook}: the whip of fabric, the step into frame, the spin, or the fabric macro that pulls back to reveal) · CLOSE ({OUTFIT INTERACTION — the one garment moment} + {PRESENTATION — how she carries herself}: hands settling the fabric, the held look, the body arriving at rest as the frame ends). Skip everything that is not named — a five-second clip cannot carry a second idea; never add a location change, a second outfit or a cutaway. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: a fabric-led garment → WHIP REVEAL, an entrance → STEP-IN REVEAL, movement-led → SPIN REVEAL, construction-led → DETAIL FIRST. WHIP REVEAL = fabric fills frame and reveals her on the settle. STEP-IN REVEAL = she enters from off-frame in the first half-second. SPIN REVEAL = the turn is the hook and the garment finishes the clip still moving. DETAIL FIRST = a garment detail opens and pulls back to the full look. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 5s total — hook inside the first 1s, movement continuous, the close inside the final 1.2s, no dead frames.

overall_soundscape: {LOCATION'S ambient layer — one clear bed} plus the garment's own sound (fabric snap, chain, leather, a heel landing), no speech.

non_diegetic_music: {a beat bed with an accent on the hook frame} — the accent must land exactly on the reveal; or exactly N/A.
```
## Twirl reveal
model: h3
tag: fashion
description: The twirl: one rotation that shows the garment's full behaviour. Everything varies — outfit, model, presentation, action, interaction, location and camera come from pools across four architectures. An adaptive version of this preset ships as “👗 Fashion preset film — adaptive beats” (adaptive-films.md) — beats derived from what you name.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: beat
structure: single
camera: Arc shot
flows: SINGLE TWIRL | DOUBLE TURN | TURN AND CATCH | SPIN TO STILL
vary: OUTFIT DESIGN | OUTFIT COLOUR | MODEL | PRESENTATION | ACTION | OUTFIT INTERACTION | LOCATION | CAMERA | MOVEMENT | RHYTHM ENVELOPE | SCALE LADDER | CUT MOTIVATION | FRAMING DEVICE | OPEN DEVICE | CLOSE DEVICE | TRANSITION | SOUND FORMAT
tip: Everything varies — the garment drives this one: name the fabric weight and the flare it makes. Heavy fabric settles fast, light fabric keeps travelling — that difference is your clip.
idea: {MODEL — 20-32 unless specified: age, hair, skin, build} in {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish}, presenting as {PRESENTATION — how she carries herself}, {ACTION — how the rotation happens} with {OUTFIT INTERACTION — what she does with the garment around the turn}, at {LOCATION — the place and its light}, shot as {CAMERA — the lens and the move}, and this variant's own {MOVEMENT — how her body travels}.

```
integrated_multimodal_description: Shot on {CAMERA — the lens and the move, ending on a settled frame}, vertical 9:16, 24fps, {MEDIUM — stock or digital texture}. FABRIC WEIGHT FIRST: state what the material does when it is turned — heavy wool or crepe settles within a beat, mid-weight silk travels a half-turn behind, chiffon or organza keeps flying after she stops; the clip's choreography is written around that one physical fact. {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish} keep their cut and colour throughout; {MODEL — 20-32 unless specified: age, hair, skin, build} identical; hair behaves as its length and weight demand (kept in a low bun, whipping with the turn, settling over the shoulder). BEAT ENGINE — one beat per NAMED dimension: WIND-UP ({PRESENTATION — how she carries herself}: the still moment before the rotation, weight shifting to the pivoting foot) · TURN ({ACTION — how the rotation happens}: the pivot — heel and ball of the foot, shoulders leading the hips by a fraction, the whole body rotating in one plane) · FLARE (the garment's flight — fabric opening to its widest, seams and hems legible for a moment, the light catching the flare) · SETTLE ({OUTFIT INTERACTION — what she does with the garment around the turn} and the last movement of the fabric, one hand catching or releasing it) · STILL (the held end frame: {LOCATION — the place and its light} holds, the garment stops moving last). Skip any dimension that is not named; never make the fabric supernatural, never a slow-motion spin, never a doubling or mirror unless named. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: the classic → SINGLE TWIRL, a fuller garment → DOUBLE TURN, a movement piece → TURN AND CATCH, a controlled ending → SPIN TO STILL. SINGLE TWIRL = one rotation, the camera fixed, the garment doing everything. DOUBLE TURN = two rotations at different speeds, the second slower and closer. TURN AND CATCH = she turns and catches the fabric or her hair in the same movement. SPIN TO STILL = the camera arcs with her and stops dead as the fabric lands. LAYER STACK: the look is a closed stack, and anything sheer, net, plunged, open-backed, cut out or slit says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief), with a stated bottom (trousers, a skirt or the garment's own lower half) and named footwear; nothing is left to the renderer's imagination.

TIMING: 8s total — wind-up inside the first 1.5s, the turn about 2s, the flare and settle 2-3s, the still hold the final second. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: fabric in flight — a strong cloth whoosh, the pivot's footfall, {LOCATION'S ambient bed}, jewellery or a zip if the outfit has one; no speech.

non_diegetic_music: {a rhythmic bed with a swell under the flare} and a clean stop on the still; or exactly N/A.
```
## Walk-to-camera hook
model: h3
tag: fashion
description: She owns the lens: dead-center walk, hook move, no slow build. single take An adaptive version of this preset ships as “👗 Fashion preset film — adaptive beats” (adaptive-films.md) — beats derived from what you name.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 6
music: beat
structure: single
camera: Static shot
idea: {CHARACTER} in {OUTFIT — colour, fabric, cut} walks straight down the center of {LOCATION} into the lens — already mid-stride from frame one — hits {HOOK MOVE} on the beat, then {END — passes camera / stops inches from the lens}.

```
integrated_multimodal_description: Shot on {24-35mm, low locked-off angle}, 24fps, vertical. [Shot 1] {LOCATION with strong one-point depth — corridor / street / runway-like stretch}. From the very first frame {CHARACTER — presence, hair, one detail} is ALREADY mid-stride, walking dead-center toward the lens in {OUTFIT + shoes — colours, fabrics and finishing}; with every step {FABRIC} moves and {ACCESSORY} catches the light. No build-up — the walk IS the hook. On the beat she {HOOK MOVE — hand through hair / wink / shoulder drop / slow the walk with a stare}; the camera holds low as she {END — passes beside the camera with fabric brushing the frame / stops inches from the lens, holding eye contact}. {LIGHT — backlight silhouette into key / neon reflections}. {GRADE}. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 6s total — reference density: 4 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only.

overall_soundscape: confident footsteps growing louder toward the mic, fabric swish on the pass, {LOCATION tone}.

non_diegetic_music: {strut-tempo beat with a bass hit on the hook move}.
```

## Snap transition (2 looks)
model: h3
tag: fashion
description: The reel staple: one gesture, two outfits, cut at peak motion on the beat. 2 shots
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 7
music: beat
structure: multi2
camera: Static shot
idea: Two looks, one gesture: {CHARACTER} in {LOOK 1} does {TRANSITION MOVE — finger snap / jump / spin} and lands in {LOOK 2}, same spot, same light, fabric still moving from the transition.

```
integrated_multimodal_description: Shot on {35mm, locked-off tripod}, 24fps, vertical. [Shot 1] {CONSISTENT SET — same backdrop, framing and light for both looks}. {CHARACTER} wears {LOOK 1}; she performs {TRANSITION MOVE — finger snap / small jump / fast spin} with attitude: {BEAT before the move — look to lens / smirk}. Cut at PEAK motion — the exact middle of the {snap/jump/spin}. [Shot 2] At the cut the live clock sets, she lands in {LOOK 2} from the same position and angle, {FABRIC 2} still settling from the transition, hair finishing its follow-through; she lands the final pose on the beat: {FINAL BEAT}. Identical framing, lighting and body position across the cut — only wardrobe changed. {GRADE}. TIMING: 7s total — reference density: 5 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only.

overall_soundscape: the {snap/jump} sound cut crisp, one fabric swish through the transition, clean room tone.

non_diegetic_music: {beat-driven track}; the cut lands exactly on the downbeat.
```

## 🎬 Campaign film — 6-scene chain
model: h3
tag: fashion
description: A 60-second brand/fashion campaign built as six 10s chained clips — this template generates ONE scene and locks the continuity bible for the whole chain.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 10
music: subtle
structure: single
camera: Auto
idea: Scene {N — 1 to 6} of the {BRAND/PRODUCT} campaign film: {WHAT THIS SCENE DOES — 1 hooks on the hero piece, mid scenes develop it, 6 resolves on the signature look}. Everything stays continuous with the previous clip.
settings_note: Use the Story chain panel — ✨ Auto-plan writes the bible and all six scenes; Direct each scene, feeding the previous clip's last frame as first frame from scene 2 on.

```
integrated_multimodal_description: Shot on {CAMERA + LENS}, 24fps, {GRADE}. CONTINUITY FIRST: this is scene {N} of a continuous film — the same {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing}, same {LOCATION LOGIC}, same {LIGHTING DESIGN}, same color grade and lens language as every other scene; if continuing from the previous clip, open exactly where it ended ({BRIDGE — her mid-stride, the fabric still settling}) and carry the motion forward without a visible seam. {WHAT THIS SCENE DOES — hook / develop / turn / resolve: one primary action + two secondary beats, ~4 beats in the scene}. If the subject wears clothing, the movement must derive from the garment: {FABRIC BEHAVIOR — e.g. the chiffon flares on the turn then settles, the tailoring holds crisp through the walk}. End the clip on a clear visual state ({END STATE — held pose, fabric settling, eye contact}) that the next scene can pick up mid-motion. No logos, no on-screen text, no cuts unless specified. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 10s total — hook 0-2s, main action 2-8s, settle/CTA 8-10s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: continuous ambience matching the previous scene ({ROOM TONE / WIND / STREET}), fabric and footstep detail, no abrupt new sounds at the join.

non_diegetic_music: the campaign bed {DESCRIBE — tempo and texture} continuing from scene to scene; accents land on this scene's primary beat.
```

## 🧥 Lookbook film — one scene per look
model: h3
tag: fashion
description: A chained lookbook: one 8-10s scene per outfit, same model/set/grade across all scenes, garment-driven choreography for every look. An adaptive version of this preset ships as “🧥 Lookbook film — adaptive scenes, one scene per look” (adaptive-films.md) — beats derived from what you name.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 8
music: beat
structure: single
camera: Auto
idea: Look {N} of {TOTAL LOOKS} for the {COLLECTION} lookbook film: the model presents {GARMENT — colour and finish, fabric, cut, key details}; the choreography matches this garment's physics, not a fixed routine.
settings_note: Chain one scene per look with the Story chain panel; the bible locks model/set/grade, each scene swaps only the garment.

```
integrated_multimodal_description: Shot on {CAMERA + LENS}, vertical 9:16, 24fps. LOCKED SERIES LOOK: the same {MODEL — 20-32 unless specified: face, hair, build} in the same {SET — wall/corner/location + 2-3 styled props}, same soft diffused window light and same crisp grade as every other look in the film. She wears {GARMENT — fabric weight, drape, silhouette, construction details, colour and finish}. CHOREOGRAPHY DERIVES FROM THE GARMENT: {FLOW BEATS — flowy = spins + trailing walk; tailored = quarter turns; knit = sleeve-over-hands; denim = jacket flip}. One hand gesture per beat, each showcasing ONE garment detail; ~{BEATS — 3 to 4} beats of visible change in {DURATION}s; end on soft direct eye contact. No logos, no on-screen text. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 8s total — hook 0-2s, main action 2-6s, settle/CTA 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: soft room tone, fabric movement appropriate to the weight of the garment, light footfall on {FLOOR}.

non_diegetic_music: {upbeat minimal groove} at a medium tempo, one accent per turn beat; or exactly N/A for pure editorial silence.
```

## 🎞️ Fashion story arc — hook → turn → resolve
model: h3
tag: fashion
description: A three-scene narrative fashion film (~30s): the garment lives in a story — hook, turn, resolve — chained with one bible.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 10
music: subtle
structure: single
camera: Auto
idea: Scene {N — 1, 2 or 3} of a three-scene fashion story: scene 1 HOOK ({SETUP — where and how we meet her in the piece}), scene 2 TURN ({SHIFT — a change of location, weather or energy that tests the garment}), scene 3 RESOLVE ({LANDING — the final image the collection should be remembered for}).
settings_note: Use the Story chain panel with 3 scenes; Auto-plan the bible, then Direct each scene in order with last-frame → first-frame bridging.

```
integrated_multimodal_description: Shot on {CAMERA + LENS}, 24fps, {GRADE}. Scene {N} of a continuous three-part story. NEVER BREAK: same {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing}, same {WARDROBE — garment described identically every scene}, same lens language and grade as the other scenes; continuing from the previous clip, open mid-motion at {BRIDGE}. {SCENE CONTENT by role — HOOK: establish her and the garment in one strong opening action plus two secondary beats, ending on forward momentum; TURN: the shift — wind picks up / she enters a new space / the light changes — and the garment reacts physically to it ({FABRIC BEHAVIOR}); RESOLVE: the definitive closing image — slow, confident, one final gesture, held long enough to end the film}. Movement vocabulary chosen for this garment's fabric and weight, never a routine. ~4 beats of visible physical change; end on a clear state ({END STATE}) the next scene inherits. No logos, no on-screen text. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 10s total — hook 0-2s, main action 2-8s, settle/CTA 8-10s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: continuous story ambience ({WIND / STREET / ROOM}), garment physics audible — fabric in air, footfalls — carried across the join without reset.

non_diegetic_music: one narrative bed {TEMPO + TEXTURE} developing across all three scenes — sparse at the hook, fullest at the resolve.
```

## 🕯️ Boudoir portrait
model: h3
tag: mature
description: Warm candlelit boudoir — slow push-in, breath and fabric as beats, ends on a held gaze. 18+ fictional adults, suggestive-to-implied.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 10
music: subtle
structure: single
camera: Push in
idea: {CHARACTER — adult} in {BOUDOIR SET — candles, silk, window sheer} at night: she {SLOW GESTURE — lets a strap fall / draws a robe closed / tilts her head back}, candlelight tracing her shoulders, ending on a held gaze.

```
integrated_multimodal_description: Shot on {ARRI + fast prime, e.g. 50mm at f/1.4}, 24fps, shallow depth of field. [Shot 1] {BOUDOIR SET — warm practicals: candles on the nightstand, a bedside lamp through fabric, sheer-curtain window light}; deep soft shadows, skin texture in honest light. {CHARACTER — fictional adult, described precisely: face, hair, what she wears or how much is implied} moves at HALF the pace of normal beats: {SLOW GESTURE}, then a breath that lifts her shoulders, fingertips trailing {DETAIL — collarbone / the sheet / her own arm}, her gaze finding the lens and holding. The camera pushes in with small amplitude at slow speed, settling on her face as candle flame reflects in her eyes. Clothing and framing stay {EXPLICITNESS — suggestive shadows / implied partial framing} — sensuality carried by light, breath and gaze, never staged. Natural skin, warm amber grade, deep true blacks. LAYER STACK: the look is a closed stack, and anything sheer, net, plunged, open-backed, cut out or slit says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief), with a stated bottom (trousers, a skirt or the garment's own lower half) and named footwear; nothing is left to the renderer's imagination.

TIMING: 10s total — hook 0-2s, main action 2-8s, settle/CTA 8-10s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: slow breathing, fabric sliding softly, the faint tick of candle flame, room tone with {AMBIENT — rain on the window / distant city hush}.

non_diegetic_music: exactly N/A, or a single sustained warm cello note that fades before the end.
```

## 💞 Intimate two-hander
model: h3
tag: mature
description: Two fictional adults, one bed or one window — touch as action-reaction pairs, dialogue whispered, consent reads in every beat. 18+.
category: Dialogue Scene
ratio: 16:9
resolution: 2K
duration: 12
music: none
structure: multi2
camera: Static shot
idea: {CHARACTER_A} and {CHARACTER_B — fictional adults} in {INTIMATE SET} at {TIME}: A {FIRST TOUCH — traces B's jaw / entwines their fingers}, B answers with {REACTION}; one whispered line each, ending on a held shared gaze.

```
integrated_multimodal_description: Shot on {ARRI + 40mm at f/1.4}, 24fps. [Shot 1] {INTIMATE SET — rumpled linen, one warm practical, curtains half drawn}; {CHARACTER_A} and {CHARACTER_B}, both fictional adults, framed close — faces and hands carry the scene, framing stays {EXPLICITNESS — implied / partial}. A {FIRST TOUCH}, slow and deliberate; B answers — {REACTION — breath catching, fingers tightening, forehead resting against A's}. Their gazes meet and hold. A whispers "{LINE_A}" in a low intimate register, unhurried; B answers "{LINE_B}" softer still, a smile breaking halfway. The camera holds a static shot, no push in, no cuts — the stillness is the point. [Shot 2] At the cut the live clock sets, the camera cuts to a close beat: {CLOSE DETAIL — their intertwined hands / her fingers in his hair / shoulders settling}, breath audible, then back to both faces as the held gaze lands the scene. Warm low-key light, deep soft shadows, natural skin texture. TIMING: 12s total — keep the beat timings below inside 12s.

overall_soundscape: breathing in rhythm, sheets shifting softly, the whispered lines, {AMBIENT — rain, or nothing at all}.

non_diegetic_music: N/A — silence serves the scene.
```

## 🖤 Sensual fabric study
model: h3
tag: mature
description: Lingerie/silk as subject — detail-bookend grammar, hands and drape, model implied rather than shown. 18+ fictional adults.
category: Product Showcase
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
idea: {GARMENT — lace bodice / silk slip, in its colour and finish} on {SURFACE — rumpled sheets / velvet chair}: hands arrange it, it is worn in partial frame by {CHARACTER — adult, shoulders and back only}, candle light catching the texture.

```
integrated_multimodal_description: Shot on a 85mm macro and a 50mm, 24fps, shallow focus, warm candlelight. [Shot 1] Opens FACELESS on {GARMENT described precisely — its colour, lace pattern, silk sheen, straps and hardware} laid across {SURFACE}; two hands enter frame and arrange it slowly — lifting a strap, smoothing lace so every thread reads. The framing widens to show the garment now worn, framed {PARTIAL — from the shoulders down / back view only}: {CHARACTER — fictional adult}, candle rim-light tracing shoulders and spine as she turns slowly away, fabric catching light with each breath. Return to the close beat: fingertips lifting the {DETAIL — lace edge / silk hem}, texture razor sharp, flame blooming soft in the background. Warm amber grade, deep blacks, no logos, no on-screen text. TIMING: 8s total — hook 0-2s, main action 2-6s, settle/CTA 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: silk whispering, the small sound of a strap settling, slow breathing, candle ambience.

non_diegetic_music: a sparse low pulse at half tempo, one accent as the fabric catches the light.
```

## ⚡ LTX single-take scene
model: ltx
tag: person
target: ltx
description: The native LTX format — one flowing present-tense paragraph, camera with end-state, audio woven in. Forge or copy this shape for LTX blocks.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 8
music: auto
structure: single
camera: Auto
idea: {CHARACTER} in {LOCATION} at {TIME} — {PRIMARY ACTION}, with small human beats around it; the camera makes one motivated move and settles on {END FRAME}.

```
prompt: {CAMERA + LENS feel}, {GRADE}. {CHARACTER - face, wardrobe, build} stands in {LOCATION described concretely: decor, light sources, atmosphere} at {TIME}. Initially she {PRIMARY ACTION}, then {SECONDARY BEAT 1 - a small human behavior}, then {SECONDARY BEAT 2}; {FABRIC or OBJECT physics detail if relevant}. The camera {ONE motivated move with amplitude and speed}, settling on {END FRAME}. {LIGHT design - one named source and how it sculpts the frame}. Diegetic sound: {SOUND details}; {SCORE direction or silence}. If she speaks, she says "{LINE}" in {TONE}. TIMING: 8s total — hook 0-2s, main action 2-6s, settle/CTA 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, logo, extra limbs, warped face, jump cuts, flicker, oversharpened

tags: cinematic, natural light, film grain
```

## ⚡ LTX fashion — walk-in approach
model: ltx
tag: fashion
description: LTX single-paragraph walk-in: attitude first, garment physics second, locked end-state. single take.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
idea: A {AGE}-year-old model in {GARMENT — colour, fabric, cut} walks toward the lens at {LOCATION}, {ATTITUDE}, ending on {FINAL_POSE}.

```
prompt: {CAMERA feel, e.g. handheld 35mm with gentle parallax}, {GRADE}. A {AGE}-year-old model with {FACE/HAIR detail} wears {GARMENT described with its colour, fabric and cut} at {LOCATION described concretely: surfaces, light sources, depth}. She starts mid-stride walking toward the camera, chin level, gaze locked to lens, then {SECONDARY BEAT — adjust cuff / brush hair / shift strap}, {FABRIC physics — how the material moves per step}. The camera pulls back slowly at matching pace, settling on a {waist-up / full-length} end frame as she stops into {FINAL_POSE}, weight shifted, {MICRO-EXPRESSION}. One coherent {LIGHT design — named key source and its falloff}. Diegetic sound: {FOOTSTEPS on surface}, {ONE ambient layer}; {SCORE direction or silence}. If she speaks, she says "{LINE}" in {TONE}. TIMING: 8s total — hook 0-2s, main action 2-6s, settle/CTA 6-8s. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, logo, extra limbs, warped face, jump cuts, flicker, oversharpened, changing wardrobe

tags: fashion, walk-in, ltx, single take
```

## ⚡ LTX fashion — twirl & settle
model: ltx
tag: fashion
description: LTX spin choreography: momentum in, fabric bloom, breath-out settle. single take.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 7
music: beat
structure: single
camera: Auto
idea: Model in {FLOWY GARMENT — fabric, colour, how it moves} twirls at {LOCATION}, fabric blooming, settling into {FINAL_POSE}.

```
prompt: {LENS feel}, {GRADE}. At {LOCATION with light and set detail}, a model in {FLOWY GARMENT — fabric, colour, how it moves} plants her foot and spins once, arms trailing the motion, the {FABRIC} flaring into a full bloom at peak rotation; as momentum dies she settles into {FINAL_POSE}, one hand finishing at {PLACEMENT}, exhale visible, {MICRO-EXPRESSION}. The camera arcs a quarter turn with her at slow speed, coming to rest at {END FRAME}. {LIGHT design}. Diegetic sound: the fabric's swish, {FOOT pivot sound}, room tone; {SCORE accent on the bloom or silence}. TIMING: 7s total — hook 0-2s, main action 2-5s, settle/CTA 5-7s. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, extra limbs, warped face, flicker, jump cuts, stiff fabric

tags: fashion, twirl, fabric physics, ltx
```

## ⚡ LTX product orbit — material study
model: ltx
tag: product
description: LTX object orbit: one continuous move, material response to light, hero detail end-state. single take.
category: Product Showcase
ratio: 1:1
resolution: 2K
duration: 6
music: subtle
structure: single
camera: Arc shot
idea: {PRODUCT} on {SURFACE} — a slow orbit as light traces materials, ending on {HERO DETAIL}.

```
prompt: {LENS feel — macro character, shallow depth of field}, {GRADE}. {PRODUCT with material finish} rests on {SURFACE} against {BACKDROP with depth detail}. The camera begins a slow continuous orbit at low amplitude; as it travels, {LIGHT response — speculars sliding across metal/glass/fabric}, {ONE secondary detail — dust mote, condensation bead, reflection}. The orbit eases to rest framing {HERO DETAIL} in razor focus, background dissolving into {BOKEH character}. {LIGHT design — one practical source named}. Diegetic sound: {subtle material sound — tick, breath of air, none}; {SCORE direction or silence}. TIMING: 6s total — hook 0-2s, main action 2-4s, settle/CTA 4-6s. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, logo, floating product, warping geometry, flicker

tags: product, orbit, macro, ltx
```

## ⚡ LTX street style — whip-follow
model: ltx
tag: fashion
description: LTX urban follow: subject turns a corner, camera whips to keep them, lands clean. single take.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: beat
structure: single
camera: Auto
idea: Street-style subject in {LOOK} crosses {STREET DETAIL}, camera whips at the corner, lands on {END FRAME}.

```
prompt: {LENS feel — street documentary 28mm}, {GRADE}. On {STREET described: pavement texture, signage light, pedestrian depth}, a subject in {LOOK with silhouette detail} walks with purpose; at {CORNER/DETAIL} they pivot sharply and the camera whips with the turn, motion smearing the background for a beat, then locks clean as they continue toward {END FRAME — over-shoulder / profile}, {FABRIC or accessory physics} trailing the pivot. {LIGHT design — time of day named, one dominant source}. Diegetic sound: {FOOTSTEPS}, {CITY layer — distant traffic, one voice}, {SCORE or silence}. If they speak: "{LINE}" in {TONE}. TIMING: 8s total — hook 0-2s, main action 2-6s, settle/CTA 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, warped face, extra limbs, flicker, jump cuts

tags: street style, whip pan, urban, ltx
```

## ⚡ LTX food — steam & pour
model: ltx
tag: food
description: LTX culinary single take: pour, steam bloom, garnish beat, settle on hero angle. single take · backlight light.
category: Product Showcase
ratio: 16:9
resolution: 2K
duration: 7
music: subtle
structure: single
camera: Auto
idea: {DISH} at {SET} — a pour releases steam, garnish lands, camera settles on the hero angle.

```
prompt: {LENS feel — 50mm food-table height}, {GRADE}. On {SET described: surface, props, window light}, {DISH with texture detail}; a hand enters and {POUR/DRIZZLE action}, steam blooming in the {LIGHT shaft}, then {GARNISH beat — flake, zest, herb drop} landing with a small physical settle. The camera pushes in gently through the steam, ending tight on {HERO DETAIL — gloss, crumb, crema}. {LIGHT design — backlight named for steam}. Diegetic sound: {POUR sound}, {CRISP garnish tick}, kitchen room tone; {SCORE or silence}. TIMING: 7s total — hook 0-2s, main action 2-5s, settle/CTA 5-7s. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, floating food, warping hands, flicker

tags: food, steam, culinary, ltx
```

## ⚡ LTX wildlife dawn — patient lens
model: ltx
tag: animal
description: LTX nature single take: long lens, animal behavior beats, breath-still end frame. single take.
category: Nature / Landscape
ratio: 16:9
resolution: 2K
duration: 9
music: none
structure: single
camera: Auto
idea: {ANIMAL} at {HABITAT} in dawn light — two natural behavior beats, ending still.

```
prompt: {LONG LENS feel — 400mm compression, breathing bokeh}, {GRADE}. In {HABITAT described: mist layer, vegetation, horizon}, a {ANIMAL with coat/plumage detail} {PRIMARY BEAT — forage, preen, lift head}; it freezes, ears/fins adjusting, then {SECOND BEAT — step, shake, call} sending {PHYSICS detail — dew, feather ruffle}. The camera holds nearly still with a slow drift, settling on a breath-still {END FRAME}. {LIGHT — dawn angle named, rim on subject}. Diegetic sound: {WIND in vegetation}, {ANIMAL sound}, {DISTANT layer}; no score. TIMING: 9s total — hook 0-2s, main action 2-7s, settle/CTA 7-9s. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, morphing animal, extra limbs, flicker, jump cuts

tags: wildlife, dawn, long lens, ltx
```

## ⚡ LTX portrait — window light
model: ltx
tag: person
description: LTX intimate portrait: window key, micro-expression arc, shallow end-state. single take · window light light.
category: Cinematic Film Scene
ratio: 9:16
resolution: 2K
duration: 6
music: subtle
structure: single
camera: Auto
idea: Close portrait of {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} by a {WINDOW TYPE} — a thought crosses the face, ending on {FINAL EXPRESSION}.

```
prompt: {LENS feel — 85mm at f/1.8, painterly falloff}, {GRADE}. Beside {WINDOW described: pane light quality, dust, curtain edge}, {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} holds a neutral gaze; a thought crosses — {MICRO-BEAT 1 — breath in, eyes lower}, then {MICRO-BEAT 2 — small smile or set jaw} blooming into {FINAL EXPRESSION}. The camera drifts almost imperceptibly closer, settling at {END FRAME — eye-line composition}. {LIGHT — soft window key, one shadow side named}. Diegetic sound: {ROOM tone — radiator tick, distant street}; {SCORE whisper or silence}. TIMING: 6s total — hook 0-2s, main action 2-4s, settle/CTA 4-6s. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, warped face, flicker, oversharpened

tags: portrait, window light, micro-expression, ltx
```

## ⚡ LTX neon night drive
model: ltx
tag: vehicle
description: LTX urban night: wet asphalt reflections, one continuous follow, neon end-state. single take · neon light.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 8
music: beat
structure: single
camera: Auto
idea: {VEHICLE} glides through {NEON STREET} after rain — reflections streak, ending on {END FRAME}.

```
prompt: {LENS feel — anamorphic flare character}, {GRADE}. After rain on {STREET described: puddle map, signage colors, steam vents}, {VEHICLE with finish detail} glides at steady pace; neon signs streak across its {SURFACE}, puddles mirroring the pass, {SECONDARY BEAT — wiper sweep / brake glow}. The camera tracks alongside at matching speed, then eases to rest as the vehicle recedes into {END FRAME — tail-light bokeh}. {LIGHT — practical neon sources named}. Diegetic sound: {TIRES on wet asphalt}, {ELECTRIC hum or engine note}, city wash; {SCORE pulse or silence}. TIMING: 8s total — hook 0-2s, main action 2-6s, settle/CTA 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, warping vehicle, flicker, jump cuts

tags: neon, night drive, reflections, ltx
```

## ⚡ LTX performance — on the beat
model: ltx
tag: person
description: LTX music moment: gesture accents land on audible beats, single take energy. single take.
category: Music Video
ratio: 16:9
resolution: 2K
duration: 8
music: full
structure: single
camera: Auto
idea: {MUSICIAN} performing {INSTRUMENT/ACT} at {VENUE} — gestures locked to the track's beats.

```
prompt: {LENS feel — concert 35mm, haze in the beams}, {GRADE}. At {VENUE described: stage depth, practicals, crowd silhouette}, {MUSICIAN with look detail} {PRIMARY GESTURE on the downbeat}; between beats {SECONDARY BEAT — head tilt, string bend, breath}, haze drifting through {LIGHT beams}. The camera creeps in on the verse and settles on {END FRAME — hands or face} exactly as {ACCENT moment}. {LIGHT design — named practicals}. The track: {GENRE at TEMPO with INSTRUMENTATION}; diegetic layer: {CROWD/ROOM sound}; gestures land on the audible beats. TIMING: 8s total — hook 0-2s, main action 2-6s, settle/CTA 6-8s. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, warped hands, extra limbs, flicker

tags: music video, performance, beat sync, ltx
```

## ⚡ LTX athlete burst — slow to fast
model: ltx
description: LTX sports single take: coiled stillness, explosive release, debris physics. single take.
tag: person
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 7
music: none
structure: single
camera: Auto
idea: {ATHLETE} at {VENUE} — coiled breath, explosive first step, {DEBRIS} kicked up.

```
prompt: {LENS feel — telephoto compression}, {GRADE}. At {VENUE described: surface texture, morning air, background compression}, {ATHLETE with build and kit detail} coils into the start — {MICRO-BEAT — breath fog, grip adjust}; then the release: first stride driving {DEBRIS — dust, water, gravel} up behind the shoe, kit and hair snapping with the acceleration. The camera pans fast to hold the runner mid-frame, settling as they power into {END FRAME}. {LIGHT — raking angle named}. Diegetic sound: {BREATH}, {FOOTSTRIKE}, {DEBRIS scatter}; no score. TIMING: 7s total — hook 0-2s, main action 2-5s, settle/CTA 5-7s. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, extra limbs, warping body, flicker

tags: sports, burst, physics, ltx
```

## ⚡ LTX seamless loop — floating product
model: ltx
tag: product
description: LTX closed-path loop: product bobs and rotates, last frame identical to first. single take.
category: Product Showcase
ratio: 1:1
resolution: 2K
duration: 6
music: subtle
structure: single
camera: Auto
loop: true
idea: {PRODUCT} floats over {SURFACE} in a closed orbit — cyclic bob, seamless loop.

```
prompt: {LENS feel}, {GRADE}. Over {SURFACE with reflection detail}, {PRODUCT} hovers with a slow cyclic bob and continuous rotation; {SECONDARY CYCLIC DETAIL — orbiting particle, liquid swirl, light sweep} repeats the same rhythm. The camera completes a closed 360° orbit returning exactly to its start, the final frame identical to the opening frame so the clip loops with no seam. {LIGHT design}. Diegetic sound: {soft hum or air}; {SCORE loop-friendly one-bar motif or silence}. TIMING: 6s total — hook 0-2s, main action 2-4s, settle/CTA 4-6s. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, seam, jump, flicker, warping geometry

tags: loop, product, seamless, ltx
```

## ⚡ LTX interior reveal — space breathing
model: ltx
tag: space
description: LTX architecture single take: doorway reveal, dust in light shafts, settle on the view. single take.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 9
music: subtle
structure: single
camera: Auto
idea: Camera crosses a {THRESHOLD} into {ROOM} — materials, light shafts, ending on {VIEW}.

```
prompt: {LENS feel — wide with controlled distortion}, {GRADE}. The camera crosses {THRESHOLD described} into {ROOM described: materials, furniture placement, ceiling height}; dust motes hang in {LIGHT shafts}, {SECONDARY DETAIL — curtain breath, plant shadow moving}. One continuous slow push through the space, ending settled on {VIEW — window vista / focal wall}. {LIGHT design — time of day and source named}. Diegetic sound: {FOOTSTEPS on floor material}, {SPACE tone — HVAC breath, birds outside}; {SCORE or silence}. TIMING: 9s total — hook 0-2s, main action 2-7s, settle/CTA 7-9s. These are proportions of the runtime: change the duration and every segment scales with it.

negative_prompt: text, watermark, warping architecture, flicker, jump cuts

tags: interior, architecture, reveal, ltx
```

## 👗 Campaign showcase — editorial fashion
model: h3
tag: fashion
description: Editorial campaign grammar: acting pack, camera play, glamour light, outfit-readable beats, she stays in frame.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
idea: A {AGE}-year-old model in {GARMENT — colour, fabric, cut} of {FABRIC} at {LOCATION} — hook, develop with fabric physics, one detail beat, composed resolve.

```
integrated_multimodal_description: Shot on {CAMERA + LENS, e.g. ARRI Alexa Mini with 65mm macro-capable prime}, vertical 9:16, 24fps, editorial campaign grade. [Shot 1] {LOCATION dressed as an aspirational set — one bright corner, 2-3 styled props, soft diffused key}. A {AGE}-year-old model with {FACE/HAIR detail} wears {GARMENT with cut, construction and its colour}, the {FABRIC} catching a soft beauty-dish key at 45° with a rim light separating her from the set. HOOK: she opens in full-length silhouette, chin lift, gaze locked to lens. DEVELOP: {WALK/TURN beat matched to the fabric — e.g. she turns slowly in the steady frame, the FABRIC sliding under the key light}, plus {SECONDARY ACT — fingertip on lapel / hair sweep with follow-through / weight shift}, micro-expression {e.g. a smile that forms and fades}. DETAIL: she presents {DETAIL ELEMENT — stitching / back cut / hardware / earring} toward the steady lens (wrist turn / step-in / shoulder drop), then settles back, focus never leaving her. RESOLVE: she settles into {FINAL_POSE}, composed, outfit legible, holding eye contact in the steady {END FRAMING — full-length / three-quarter} frame. She never exits frame; the camera frames, she performs — no zooms, no push-ins. {GRADE}. TIMING: 8s total — reference density: 6 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: {HEEL CLICKS on surface}, {FABRIC swish on the turn}, one ambient layer, clean room tone.

non_diegetic_music: {GENRE — e.g. minimal deep-house} at {TEMPO}, bass pulse under the develop beat, dip under the resolve.
```

## 👗 Campaign showcase — LTX editorial
model: ltx
tag: fashion
description: One-paragraph LTX editorial: hook, fabric physics with secondary acts, camera play, detail anchor, composed end frame — she stays in frame.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
idea: A {AGE}-year-old model in {GARMENT — colour, fabric, cut} of {FABRIC} at {LOCATION}, editorial campaign energy, ending composed on {FINAL_POSE}.

```
prompt: {LENS feel, e.g. 65mm with gentle handheld parallax}, editorial campaign grade. A {AGE}-year-old model with {FACE/HAIR detail} wears {GARMENT — colour and finish, described with cut and construction} at {LOCATION as aspirational set: surfaces, one bright key, styled props}. She opens full-length, chin lift, gaze to lens — the {FABRIC} reads instantly under a soft beauty-dish key with rim light. She {WALK/ORBIT beat matched to the fabric, e.g. turns slowly in the steady frame, the satin sliding under the key light}, adding {SECONDARY ACT — cuff adjust / hair sweep / weight shift} and {MICRO-EXPRESSION}. She presents a detail anchor ON HER ({DETAIL ELEMENT}) toward the steady lens, then settles into {FINAL_POSE}, composed, eye contact held, outfit legible. She never exits frame; every move re-frames around her. Diegetic: {HEEL CLICKS}, {FABRIC swish}; {SCORE direction — minimal beat dipping under the resolve}. TIMING: 8s total — reference density: 6 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

negative_prompt: text, watermark, logo, extra limbs, warped face, jump cuts, flicker, subject leaving frame, isolated object close-ups, zoom-ins, camera push-ins

tags: fashion, editorial, campaign, ltx
```

## Sari — she-performs showcase
model: h3
tag: ethnic
description: From the sari reference set: locked full-length frame, pallu lift and float, pleat-adjust and over-shoulder turns, jewelry macro inserts anchored on her.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 12
music: subtle
structure: auto
camera: Static shot
idea: {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} in a {SARI COLOR + FABRIC — organza float / silk slide / net sheerness} sari with {BLOUSE DETAIL — cut and colour} at {SET — heritage stairs / painted mural / clean wall}: she walks in, lifts the pallu to let it flow, and turns over her shoulder into a smile.

```
integrated_multimodal_description: Shot on {CAMERA + LENS, e.g. Sony A7S III with 50mm}, vertical 9:16, 24fps, a LOCKED steady full-length frame — all size changes come from cuts or her approach, the camera never zooms. [Shot 1] {SET} in {LIGHT — soft window light / warm halo practicals / golden-hour rim against a dark curtain}. {MODEL — 20-32 unless specified: hair over one shoulder, bangles, jhumkas} walks in at a graceful clip — pleats swaying, bangles ticking, gaze down then up, every second active; she lifts the pallu with fingertips and lets it {FABRIC BEHAVIOR — organza float / silk slide / net shimmer}, then turns over her shoulder into a soft smile, gaze down then up to the lens. [Shot 2] Anchored insert ON HER: macro of {JEWELRY — jhumka sway / bangle glint / necklace catch} against {GARMENT DETAIL — embroidered blouse and zari border, in the sari's palette}, light playing on every bead. [Shot 3] She settles: one hand {ACT — adjusts pleats at the hip / tucks hair / rests on hip with a wall lean}, head tilt, playful-coy side glance resolving to confident eye contact; the {SARI COLOR} drape and {BORDER — shimmer / zari} fully readable. {GRADE — warm cinematic}. She never exits frame. LAYER STACK: the look is a closed stack, and anything sheer, net, plunged, open-backed, cut out or slit says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief), with a stated bottom (trousers, a skirt or the garment's own lower half) and named footwear; nothing is left to the renderer's imagination.

TIMING: 12s total— Shot splits as before, but inside EVERY shot one distinct act per 1.5s (9 stamped beats total); no action >2s; final 1s hold only.

overall_soundscape: soft fabric rustle, bangle chime on the wrist turn, light anklet/footfall, {AMBIENT — temple bells far off / quiet room tone}.

non_diegetic_music: {slow melodic bed — tanpura shimmer or soft strings} at a gentle tempo, one accent on the over-shoulder turn; or exactly N/A.
```

## Beach swim / resort walk-in
model: h3
tag: fashion
description: From the beach reference: hard sun as key, wind as co-performer, walk-in laugh, hair sweep, hands-on-hips — steady handheld, cuts for size changes.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 10
music: beat
structure: single
camera: Auto
idea: {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} in {SWIMWEAR — cut, color, hardware} steps in laughing across the near edge of {BEACH SET} at {TIME — hard noon / golden hour}, sweeps her hair, cocks a hip, and glances back over her shoulder.

```
integrated_multimodal_description: Shot on {CAMERA, e.g. handheld cinema camera with 35mm}, vertical 9:16, 24fps, steady handheld float — no zooms, size changes via her walk and cuts. [Shot 1] {BEACH SET — dune line / palm shade / wet sand mirror} under {SUN — hard noon key with skin and water speculars / low golden sun}. {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} takes two grounded steps in from the edge of the frame, laughing, {SWIMWEAR described: cut, color, strap hardware, cover-up or sarong knot}; sea wind works as co-performer, lifting hair and the {COVER-UP FABRIC}. BEATS: walk-in laugh → hair sweep held one beat → hands-on-hips hip cock → glance off, then back to lens with a half-smile. {ACCESSORY GLINTS — hoops, anklet, sunglasses pushed up}. Print and sheer panels stay readable in the hard light; natural skin texture, no logos. {GRADE — sun-bleached highlights, saturated sea}. LAYER STACK: the set is complete and stated — the top piece and its matching bottom, whatever sits under it where the cut exposes skin (a seamless base), and the footwear (sandals, flats or barefoot by request); never one half of a two-piece on its own.

TIMING: 10s total — reference density: 7 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only.

overall_soundscape: surf breaks, wind in the mic softened, sand footfall, her laugh carried once.

non_diegetic_music: {breezy resort groove — muted percussion, warm bass} at medium tempo, accent on the hip cock; or exactly N/A.
```

## GRWM try-on angle pass
model: h3
tag: fashion
description: From the GRWM references: minimal set with one prop, locked full-length, she turns through front/profile/back, then self-presented detail touches that guide the eye.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 10
music: subtle
structure: single
camera: Static shot
idea: {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} shows {DRESS — colour and finish, cut, straps, detail} against {MINIMAL SET + ONE PROP — easel with flowers / mirror edge / chair}: front, profile, back, then fingertips trace the {DETAIL — neckline appliqué / slit / strap}.

```
integrated_multimodal_description: Shot on a smartphone, {35mm-equivalent} at f/2.0, vertical 9:16, LOCKED full-length tripod frame; {MINIMAL SET — plain wall, one styled prop}; soft even light, 24fps. [Shot 1] {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} presents {DRESS described precisely — colour and finish named} front-on with calm confident neutrality; she turns in place — profile, back, return — each angle a crisp 1.5s beat with a hand or gaze accent, hem and {FABRIC} reading on every turn. Then the detail pass: fingertips trace {DETAIL 1 — neckline appliqué / seam}, a hand settles {DETAIL 2 — strap / slit edge}, the touch guiding the eye while the camera stays put. Small smile optional; natural skin, true fabric color, no text. TIMING: 10s total — reference density: 7 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only.

overall_soundscape: quiet room tone, faint fabric rustle per turn, one soft heel step.

non_diegetic_music: {minimal warm groove — soft keys, brushed tick} at a relaxed tempo; or exactly N/A.
```

## Dancing movement showcase
model: h3
tag: fashion
description: From the dance references: garment-selling dance acts — overhead clap, hip sway, skirt lift, spin flare — joyful energy in a locked medium-to-full frame.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 10
music: beat
structure: single
camera: Static shot
idea: {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} in {TWO-PIECE / DRESS — colour and finish, ruffles, slit, flow} dances at {OUTDOOR SET — courtyard / garden wall}: clap pose overhead, hip sway, skirt lift and one spin with fabric flare, smiling on the accents.

```
integrated_multimodal_description: Shot on {CAMERA + LENS}, vertical 9:16, 24fps, LOCKED medium-to-full frame so full-body motion always fits — the camera never chases. [Shot 1] {OUTDOOR SET — foliage bokeh, clay pots, tiled step} in {LIGHT — late sun through leaves}. {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} performs garment-selling dance beats on the rhythm: hands clapping overhead with {TOP — colour and finish, ruffle tiers} bouncing, hip sway making {SKIRT — colour, fabric weight, cut} swing, one hand lifting the hem to show {SLIT / LINING}, a spin where {FABRIC} flares then settles, step-touch bounce between. Joyful performed energy — smile, eye contact on accent beats; {JEWELRY} keeps time with her. Fabric physics named per beat: flare, sway, settle. {GRADE — warm, saturated}. TIMING: 10s total — reference density: 7 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only.

overall_soundscape: fabric swish on the spin, jewelry tick, footfall on {FLOOR}, leaf-wind.

non_diegetic_music: {upbeat groove — percussion-forward, 100-120 BPM} with accents landing exactly on the clap and spin.
```

## Traditional brand-ad cinematic
model: h3
tag: ethnic
description: From the brand-ad references: seamless cyclorama or heritage set, regal serene performance, back-view turn for the drape fall, fabric-spread reveal, logo-safe composed finish.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 12
music: subtle
structure: single
camera: Static shot
idea: {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} in {ETHNIC SET — embroidered cape / dupatta + lehenga, palette} on {CYCLORAMA — warm grey / deep teal}: downcast gaze lifting slowly, back-view turn for the drape fall, arms wide to spread the full print, ending composed and centered.

```
integrated_multimodal_description: Shot on {CAMERA + LENS, e.g. 85mm}, vertical 9:16, 24fps, locked frame; {CYCLORAMA or dressed heritage set}; {LIGHT — soft diffused key for quiet luxury / dramatic rim on a dark teal backdrop}. [Shot 1] {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} stands regal and serene in {ETHNIC SET described: embroidery motifs, drape layers, palette}, downcast gaze lifting slowly, composed chin, unhurried breath; statement {JEWELRY — earring swing, ring catch} beats on each micro-movement, one hand on hip. She turns to the back view to reveal {DRAPE FALL — cape / dupatta print and back detail}, then faces home and lifts both arms wide to spread the full {FABRIC PRINT}, letting it settle in slow motion-feel; ends centered, outfit fully readable, logo-safe. {GRADE — quiet-luxury, low contrast or rich saturated}. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 12s total — reference density: 9 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only.

overall_soundscape: near-silent studio tone, one soft fabric sweep, faint jewelry chime.

non_diegetic_music: {sparse cinematic bed — sustained strings or tanpura drone} swelling once at the fabric spread; or exactly N/A.
```

## Bridal heavy-embroidery montage
model: h3
tag: ethnic
description: From the bridal references: jewel-tone backdrop, candle-warm key, faceless texture inserts anchored on her body, full jewelry set co-starring, composed regal finish.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 12
music: subtle
structure: auto
camera: Static shot
idea: A bride in {LEHENGA — crimson / wine velvet with zardozi} against {JEWEL BACKDROP — emerald / midnight}: portrait beat, hands-with-bangles insert, skirt embroidery insert, then a composed full finish.

```
integrated_multimodal_description: Shot on {CAMERA + LENS, e.g. 100mm + 50mm}, vertical 9:16, 24fps; {JEWEL BACKDROP} with a warm candle-like key; raking light that lifts zardozi, velvet and beadwork. [Shot 1] Medium portrait: {BRIDE — 20-32 unless specified: maang tikka, choker, jhumkas} in {LEHENGA described: color, velvet/silk, embroidery motifs, cross-strap or neckline detail, latkan tassels}; downcast serene gaze, slow blink, two hands adjusting {BANGLE STACKS} at the waist; every micro-movement earns a glint. [Shot 2] Faceless insert anchored ON HER BODY: folded hands with polki bangles and {HAND-CHAIN / RINGS} against the skirt's embroidery rows, {LATKAN TASSELS} hanging in frame. [Shot 3] Composed three-quarter finish: she settles, chin tilt, dupatta edge catching the key; the full {LEHENGA COLOR + GOLD WORK} readable, stillness regal. {GRADE — rich, saturated, warm}. TIMING: 12s total— Shot splits as before, but inside EVERY shot one distinct act per 1.5s (9 stamped beats total); no action >2s; final 1s hold only.

overall_soundscape: bangle glass-chime, soft fabric weight shifting, one distant shehnai-like tone.

non_diegetic_music: {slow regal bed — strings and soft bells} at a stately tempo, one swell at the finish; or exactly N/A.
```

## UGC skeptic testimonial ad
model: h3
tag: vertical
description: Talking-head testimonial with product B-roll: skeptical hook, what changed, recommendation-style CTA — the highest-trust UGC structure. An adaptive version of this preset ships as “🎬 UGC ad — adaptive beats, everything derived” (adaptive-films.md) — beats derived from what you name.
category: Social Media Content
ratio: 9:16
resolution: 768P
duration: 12
music: none
structure: single
camera: Static shot
idea: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} in their {REAL ROOM — bedroom / kitchen} talks to the phone about {PRODUCT}: "I didn't believe the hype because {DOUBT}" — cut with B-roll of {PRODUCT} in use, ending on a friend-to-friend CTA.

```
integrated_multimodal_description: Shot on a smartphone front camera, {26mm-equivalent} at f/1.8, vertical 9:16, 30fps, slightly underexposed natural light, NO grade — it must read as a real person's video. [Shot 1] {CREATOR — 20-32 unless specified: everyday look, no styling crew} sits in {REAL ROOM — unmade bed / dishes drying / bathroom mirror bulbs}, holding the phone at arm's length; they say "{SKEPTIC HOOK — I didn't believe the hype because…}" in a casual, unscripted pace, one honest pause mid-sentence. Intercut B-roll: {PRODUCT} in real use — hands, counter, morning light — then back to face for "{WHAT CHANGED — the specific result, in plain words}", a small shrug and half-smile. Bold synced captions, 1-3 words per frame, bottom third: {CAPTION LINES}. CTA lands like a recommendation, not a pitch: "{CTA — it's linked, that's it}". Natural skin, room clutter visible, no logos, no end card. TIMING: 12s total — hook 0-2s, main action 2-10s, settle/CTA 10-12s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: room tone, one household sound (kettle / traffic / fan), voice close and dry like a phone mic.

non_diegetic_music: exactly N/A — silence is the authenticity signal.
```

## UGC unboxing first reaction
model: h3
tag: vertical
description: Real-time opening with honest sensory detail: package on the bed, first touch, one genuine surprise beat, quick value line. An adaptive version of this preset ships as “🎬 UGC ad — adaptive beats, everything derived” (adaptive-films.md) — beats derived from what you name.
category: Social Media Content
ratio: 9:16
resolution: 768P
duration: 10
music: none
structure: single
camera: Auto
idea: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} opens {PACKAGE} on {BED / DESK} — box texture, first pull-out, "{SURPRISE LINE}", then shows {DETAIL} close to the lens and ends with "{VERDICT LINE}".

```
integrated_multimodal_description: Shot on a smartphone, vertical 9:16, 30fps, top-down over {BED / DESK — real sheets, one unrelated object in frame}, window light, no grade. [Shot 1] {PACKAGE — mailer, tape, label} centered; {CREATOR — 20-32 unless specified: age, look, the way she talks to lens}'s hands enter, slice the tape, and the box opens in real time — tissue, insert card, then the first pull-out of {PRODUCT}. One genuine surprise beat: "{SURPRISE LINE — oh, it's heavier than it looks}" as fingers test {TEXTURE DETAIL}; the product tilts into the light and the camera refocuses like a phone does. Close pass: {DETAIL — stitching / port / seam / print} held near the lens, slight handheld wobble. Face beat at the end, front camera: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} gives "{VERDICT LINE — okay, I get it}" with a nod. Bold synced captions bottom third: {CAPTION LINES}. No logo stingers, no end card. TIMING: 10s total — hook 0-2s, main action 2-8s, settle/CTA 8-10s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: tape tear, cardboard friction, tissue crinkle, the product's first click/thud, phone-mic voice.

non_diegetic_music: exactly N/A.
```

## UGC problem-solution demo
model: h3
tag: vertical
description: PAS arc on camera: name the pain in one line, show the struggle, product as the discovery, soft CTA — the workhorse performance format.
category: Social Media Content
ratio: 9:16
resolution: 768P
duration: 12
music: none
structure: single
camera: Auto
idea: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} opens on "{PAIN LINE — if you're tired of…}", shows the struggle with {OLD WAY}, then demos {PRODUCT} solving it in {REAL SETTING}, closing with "{SOFT CTA}".

```
integrated_multimodal_description: Shot on a smartphone, vertical 9:16, 30fps, natural light in {REAL SETTING — kitchen / bathroom / hallway}, unstyled and honest. [Shot 1] HOOK (0-2s): {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} to camera, mid-frustration: "{PAIN LINE}". PROBLEM (2-6s): quick cuts of the struggle — {OLD WAY failing: spilled, tangled, re-doing it, sighing}, one exasperated glance at the lens. SOLUTION (6-20s): {PRODUCT} enters as a discovery, not an ad: "{DISCOVERY LINE — then I found this}" — demo in real time, hands doing the thing, the fix visibly working on first try, one "{HONEST CAVEAT — it's not magic, but}" line for credibility. PROOF beat: the after-state held two seconds, {CREATOR — 20-32 unless specified: age, look, the way she talks to lens}'s relieved shoulders. CTA soft, friend-to-friend: "{SOFT CTA}". Bold synced captions bottom third on every beat: {CAPTION LINES}. Phone-mic audio, no grade, no logos. TIMING: 12s total — keep the beat timings below inside 12s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: the struggle sounds (clatter, sigh), then quieter focused demo sounds, voice dry and close.

non_diegetic_music: exactly N/A.
```

## UGC before-after transformation
model: h3
tag: vertical
description: Creator-documented journey: day-1 honesty, montage of the middle, visible result held on camera — the outcome does the selling. An adaptive version of this preset ships as “🎬 UGC ad — adaptive beats, everything derived” (adaptive-films.md) — beats derived from what you name.
category: Social Media Content
ratio: 9:16
resolution: 768P
duration: 12
music: none
structure: multi3
camera: Static shot
idea: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} documents {GOAL — clearer skin / tidier desk / 5k runs} with {PRODUCT}: day-1 honesty, middle montage, then the result held in the same frame as day 1.

```
integrated_multimodal_description: Shot on a smartphone, vertical 9:16, 30fps, SAME locked framing and SAME {CORNER OF THE ROOM} across all shots so the change is the story. [Shot 1] DAY 1: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} in {CORNER}, flat light, tired and honest: "{DAY-1 LINE — so, day one of actually trying this}"; {START STATE visible — clutter / skin / posture}, one skeptical eyebrow. [Shot 2] THE MIDDLE: three fast in-place beats in the same frame — {MIDDLE BEATS: week-two shrug, halfway check-in, product nearly used up} — with a hand-written {DAY COUNTER} held up each time. [Shot 3] THE RESULT: same frame, better light by accident; {AFTER STATE visible}; {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} doesn't overclaim: "{RESULT LINE — okay… this actually worked}", turns {THE CHANGED THING} to the window light and holds it two full seconds. Bold synced captions bottom third: {CAPTION LINES}. No logos, no end card, no grade. TIMING: 12s total — Shot 1 0-5s, Shot 2 5-9s, Shot 3 9-12s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: phone-mic voice, room tone shifting slightly across the three shots (rain → quiet → birds) to sell the time passing.

non_diegetic_music: exactly N/A.
```

## UGC day-in-the-life soft sell
model: h3
tag: vertical
description: The product embedded naturally in a real routine — lifestyle snapshot, never the hero; the sell is how casually it appears. An adaptive version of this preset ships as “🎬 UGC ad — adaptive beats, everything derived” (adaptive-films.md) — beats derived from what you name.
category: Social Media Content
ratio: 9:16
resolution: 768P
duration: 12
music: none
structure: multi3
camera: Auto
idea: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens}'s {MORNING / EVENING} routine in {HOME}: six honest slices of real life where {PRODUCT} just happens to appear, voiceover like a diary note.

```
integrated_multimodal_description: Shot on a smartphone, vertical 9:16, 30fps, available light only; six short honest slices, each 1.5-2.5s, cut on movement. [Shot 1] {ROUTINE OPEN — alarm hand, kettle switch, curtain pull} in {HOME}; voiceover in a low diary tone: "{VO LINE 1}". [Shot 2] Middle slices: {SLICE BEATS — coffee poured, shoes at the door, bag packed, stairwell, bus window}; {PRODUCT} appears casually in two of them (on the counter, in the bag strap) — never centered, never presented; "{VO LINE 2 — the only thing that's stayed consistent is…}". [Shot 3] Evening close: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} on the sofa, one lamp, phone down; final diary line "{VO LINE 3}" and a cut to black one beat early. Slight underexposure, real clutter, no staging, no logos. Bold synced captions optional bottom third: {CAPTION LINES}. TIMING: 12s total — Shot 1 0-5s, Shot 2 5-9s, Shot 3 9-12s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: kettle, spoon in mug, door latch, bus air-brake, sofa cushion — the routine IS the soundscape.

non_diegetic_music: exactly N/A, or a single lo-fi hum under the last slice only.
```

## UGC three-step how-to tutorial
model: h3
tag: vertical
description: Specific outcome in a tight timeframe: three numbered steps on camera, one visible result, "do this instead" energy. An adaptive version of this preset ships as “🎬 UGC ad — adaptive beats, everything derived” (adaptive-films.md) — beats derived from what you name.
category: Social Media Content
ratio: 9:16
resolution: 768P
duration: 12
music: none
structure: single
camera: Static shot
idea: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} shows "{OUTCOME} in {TIME}" with {PRODUCT}: step one {STEP 1}, step two {STEP 2}, step three {STEP 3} — result held, "save this" closer.

```
integrated_multimodal_description: Shot on a smartphone propped against a jar, vertical 9:16, 30fps, {REAL WORK SURFACE — counter / desk / mat}, window light. [Shot 1] HOOK: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens}'s hands freeze mid-task, face leans in: "{HOOK — do this instead of {OLD WAY}}". Then three numbered steps, each one clean take: "1" — {STEP 1 performed, 2s}; "2" — {STEP 2, the product doing its visible job, 3s}; "3" — {STEP 3, the finish, 2s}; big synced number captions pop on each step plus 1-3 word bottom-third captions: {CAPTION LINES}. RESULT: the outcome held two seconds in the same frame, {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} taps it once: "{RESULT LINE}". Closer like a favor between friends: "{CLOSER — save this, you'll need it}". Slight wobble when the phone gets bumped = authenticity. No logos, no grade. TIMING: 12s total — hook 0-2s, main action 2-10s, settle/CTA 10-12s. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: task sounds per step (pour, click, swipe), phone-mic voice, room tone.

non_diegetic_music: exactly N/A.
```

## Luxury editorial atmosphere film
model: h3
tag: fashion
description: Atmosphere-led luxury: light, texture and stillness instead of beats. Everything varies — outfit, model, presentation, action, interaction, location and camera come from pools across four architectures.
category: Fashion / Lifestyle
ratio: 16:9
resolution: 2K
duration: 12
music: subtle
structure: single
camera: Auto
flows: LIGHT FIRST | OBJECT STUDY | CLEAR ROOM | ONE FIGURE
vary: OUTFIT DESIGN | OUTFIT COLOUR | MODEL | PRESENTATION | ACTION | OUTFIT INTERACTION | LOCATION | CAMERA | MOVEMENT | RHYTHM ENVELOPE | SCALE LADDER | CUT MOTIVATION | FRAMING DEVICE | OPEN DEVICE | CLOSE DEVICE | TRANSITION | SOUND FORMAT
tip: Everything varies — this format breathes: name the light source and the surface textures, and let the action be small. A big gesture breaks the luxury; a held still with one small movement sells it.
idea: {MODEL — 20-32 unless specified: age, hair, skin, build} in {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish}, presenting as {PRESENTATION — how she carries herself}, {ACTION — a small, contained action} with {OUTFIT INTERACTION — the one garment moment}, inside {LOCATION — the room or landscape and its light}, shot as {CAMERA — the lens and the move}, and this variant's own {MOVEMENT — how her body travels}.

```
integrated_multimodal_description: Shot on {CAMERA — the lens and the slow move with an end-state}, 16:9, 24fps, {MEDIUM — a fine film stock, or clean digital with gentle grain}. ATMOSPHERE FIRST: {LOCATION — the room or landscape and its light} is the subject alongside the garment — a single dominant light source with a legible direction and falloff, texture that reads (plaster, marble, linen, foliage, worn wood), and dust, steam or movement in the air where the light crosses. {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish} catches the light and changes with the movement of the body. {MODEL — 20-32 unless specified: age, hair, skin, build} identical throughout; her {PRESENTATION — how she carries herself} is composure — few expressions, no performance. BEAT ENGINE — one beat per NAMED dimension: LIGHT (a beat where the light itself is the subject — a shaft moving, a reflection travelling, a curtain breathing) · TEXTURE (a material beat: the garment's weave, skin with real texture and pore, a surface the light touches) · FIGURE ({OUTFIT DESIGN} in the space, framed so the scale and proportion read) · SMALL ACTION ({ACTION — a small, contained action}: a turn of the head, a hand on a surface, a step, a breath — the movement stays inside a small radius) · INTERACTION ({OUTFIT INTERACTION — the one garment moment}, done slowly and finished) · STILL (the final hold, breath moving, nothing else). Skip any dimension that is not named; never add jewellery glitter, lens flares, a logo, a second figure or a big gesture. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: light-led → LIGHT FIRST, product or accessory focus → OBJECT STUDY, an interior → CLEAR ROOM, a figure study → ONE FIGURE. LIGHT FIRST = the clip opens on the light alone and the figure enters later. OBJECT STUDY = the garment or one accessory is studied like a sculpture before the figure. CLEAR ROOM = the empty space is established and the figure crosses it once. ONE FIGURE = the whole clip is one continuous framing of the figure, the light changing around her. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 12s total — slow, 4-5 beats, no cut faster than 2s, no gesture completed in under a second, the final 2s a held still with breath.

overall_soundscape: the location's own air — room tone with one distant sign of life, fabric moving slowly, a single footstep, breath at the closest beat; no speech.

non_diegetic_music: {a sparse score — a single sustained string, a low piano note, an ambient pad} with almost no rhythm, one dynamic swell and a resolve; or exactly N/A so the room carries it.
```
## DTC founder-story lifestyle ad
model: h3
tag: fashion
description: Lifestyle/aspiration mode: founder narration over slow B-roll of product in the real world — ethos first, garment as proof.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 15
music: subtle
structure: multi3
camera: Auto
idea: {FOUNDER}'s voice tells why {BRAND} makes {GARMENT — colour, fabric, cut} from {MATERIAL ORIGIN} over slow B-roll: material close, workshop hand, garment worn in {REAL WORLD}.

```
integrated_multimodal_description: Shot on {cinema camera, natural light}, 24fps, vertical 9:16; slow patient B-roll, each shot 2.5-4s. [Shot 1] {MATERIAL ORIGIN — flax field wind / merino hillside / recycled bale opening} in macro-slow motion; FOUNDER VO (warm, unhurried, slightly imperfect): "{VO 1 — we started with one stupid question: why…}". [Shot 2] The making: {WORKSHOP BEATS — hands at a flat-fell seam, steam press, chalk line, button tin} — real tools, real benches; VO: "{VO 2 — so we made it slower, from {MATERIAL}, and it lasts…}". [Shot 3] The proof in the real world: {WEARER — 20-32 unless specified: not a model-perfect cast} in {GARMENT — colour, fabric, cut} doing {REAL LIFE — school run / bike lock / market carry}, fabric moving honestly; VO closes: "{VO 3 — that's the whole pitch}". One quiet text line at the end only: {BRAND + ONE-LINE ETHOS}. No hard sell, no price. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 15s total— Shot splits as before, but inside EVERY shot one distinct act per 1.5s (11 stamped beats total); no action >2s; final 1s hold only.

overall_soundscape: field wind, sewing machine tick, steam hiss, bike freewheel, market murmur — VO sits on top, dry.

non_diegetic_music: {acoustic minimal — one guitar or piano figure} entering at shot 2, resolving at the last line.
```

## Community athleisure sunrise ad
model: h3
tag: fashion
description: Community/UGC mode: run-club-at-sunrise energy, multi-person collage, lo-fi audio — the brand as a crew, not a logo.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 12
music: beat
structure: multi3
camera: Auto
idea: {CITY} run club at sunrise in {KIT — matching palette athleisure}: laces tying, breath in cold air, group cresting a hill, phone-passed cuts, ending on the crew laughing, not posing.

```
integrated_multimodal_description: Shot mixed: cinema camera for the wide + phone-passed verticals for the intimate beats, 24fps, vertical 9:16. [Shot 1] SUNRISE WIDE: {CITY STREET / BRIDGE} in first light, a loose group of {RUNNERS — mixed ages, builds, paces} in {KIT}; breath visible in cold air; lo-fi ambient audio, one runner's phone playing {TRACK — muffled, bass-light}. [Shot 2] PHONE-PASS BEATS: laces double-knotted, a water bottle handed off, someone fixing a friend's collar, a selfie-angle laugh mid-jog — each 1-1.5s, slight wobble, real sweat sheen on {FABRIC — ribbed, compressive, matte}; the clothing reads through use, stretch and recovery visible at the knee and shoulder. [Shot 3] The crew crests {HILL / STEPS} together into full sun; they stop laughing, not posing — hands on knees, one points at the view; final frame holds the group, {LOGO-LESS KIT} fully readable. No text, no logo. TIMING: 12s total— Shot splits as before, but inside EVERY shot one distinct act per 1.5s (9 stamped beats total); no action >2s; final 1s hold only.

overall_soundscape: breath, shoe scuffs, muffled track from a phone, one genuine group laugh.

non_diegetic_music: {lo-fi groove — dusty drums, warm bass} mixed low, like it's coming from the runner's phone.
```

## Outfit transition three ways
model: h3
tag: fashion
description: The Reels styling format: one hero piece, three styled looks, snap transitions on the beat, "three ways to wear it" captions.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 10
music: beat
structure: single
camera: Static shot
idea: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} styles {HERO PIECE} three ways — {LOOK 1 casual}, {LOOK 2 work}, {LOOK 3 night} — snap transitions on the beat, ending with "which one?" to camera.

```
integrated_multimodal_description: Shot on a smartphone on a tripod, vertical 9:16, 30fps, LOCKED medium-full frame in {CORNER SET — plain wall + one prop}; identical framing across all looks so the transitions snap clean. [Shot 1] LOOK 1: {CREATOR — 20-32 unless specified: age, look, the way she talks to lens} in {HERO PIECE} styled {CASUAL — sneakers, tee, tote}; one gesture (clap / spin / hand over lens) triggers the cut ON THE BEAT to LOOK 2: same piece styled {WORK — blazer, loafers, structured bag}, posture shifted; second beat-cut to LOOK 3: {NIGHT — heels, jewelry, slicked hair}. Each look gets two styling beats (tuck, roll sleeve, add layer) so the piece's versatility is the story; bold synced captions bottom third: "1 — errands", "2 — office", "3 — after" per look: {CAPTION LINES}. Closer: she shrugs to camera, "{CLOSER — which one are we wearing?}" Natural light, true colors, no logos. TIMING: 10s total — reference density: 7 stamped beats, a new visible act every 1–1.5s (0–1.5 …, 1.5–3 …, …); layer hands + gaze + fabric on each beat; no action >2s; final 1s hold only.

overall_soundscape: fabric swish per transition, one heel click, room tone.

non_diegetic_music: {beat-forward groove, 100-115 BPM} with the snap cuts landing exactly on the kicks.
```

## Streetwear hype drop ad
model: h3
tag: fashion
description: Fast-cut attitude: flash frames, low angles, hardware macro, attitude walk — scarcity energy without saying a word.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: beat
structure: multi3
camera: Auto
idea: {DROP NAME} lands: {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} in {STREETWEAR — heavyweight hoodie / cargo / chain} under {CITY NIGHT LIGHT}: flash cuts, low-angle walk, macro on {HARDWARE DETAIL}, freeze-frame end.

```
integrated_multimodal_description: Shot on {cinema camera + flash strobe}, 24fps with 2-3 frame flash inserts, vertical 9:16, {CITY NIGHT — sodium light, shutter doors, wet asphalt}. [Shot 1] ATTITUDE WALK: low angle, {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} walks straight at the lens in {STREETWEAR described: weight, drop shoulder, stitch detail, chain}, shoulders rolling; flash frames freeze the fabric mid-swing. [Shot 2] HARDWARE MACROS: {DETAIL — zip pull, embroidered hit, lace lock, rivet} in three half-second strobes, each lit by a single hard flash; a hand {GESTURE — adjusts the chain / pulls the hood}. [Shot 3] She stops one meter out, chin down, eyes up; the frame FREEZES with a half-frame flash burn, holds two seconds, cut black. No price, no words — scarcity is the copy. {GRADE — crushed blacks, sodium highlights}. TIMING: 8s total— Shot splits as before, but inside EVERY shot one distinct act per 1.5s (6 stamped beats total); no action >2s; final 1s hold only.

overall_soundscape: shutter-door rattle, distant siren, flash capacitor whine, boot scuffs on wet asphalt.

non_diegetic_music: {drill / industrial beat — 140 BPM half-time, distorted 808} cut hard at the freeze.
```

## Jewelry macro luxury ad
model: h3
tag: fashion
description: Velvet-dark macro cinema: caustic light, stone fire, wrist turns — desire built entirely from light physics on the piece.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 10
music: subtle
structure: auto
camera: Auto
idea: {PIECE — solitaire / tennis bracelet / jhumka} on {VELVET / SKIN} in darkness: one beam of light wakes the stones, a wrist turn fires the facets, macro to wide reveal on {HAND / EAR}.

```
integrated_multimodal_description: Shot on {macro cinema lens, e.g. 100mm macro at f/2.8}, 24fps, vertical 9:16; {VELVET-BLACK SET} with a single shaped beam — caustics dancing like water light. [Shot 1] SLEEPING STONE: {PIECE} lies dark on {VELVET / SKIN}; the beam slides in and the {STONE — cut and setting} wakes — fire traveling facet to facet in slow motion feel; dust motes in the beam. [Shot 2] THE TURN: worn now — {HAND / WRIST / EAR} rotates one slow degree at a time; every increment fires a new flash pattern from {SETTING DETAIL — prongs / pavé / fringe}; skin texture honest, no retouch shine. [Shot 3] Macro pulls to a three-quarter reveal: {WEARER — 20-32 unless specified: one bare shoulder, dark backdrop} settles, the piece the only bright thing in frame; hold, one final sparkle, fade. No text, no logo. {GRADE — velvet blacks, champagne highlights}. TIMING: 10s total— Shot splits as before, but inside EVERY shot one distinct act per 1.5s (7 stamped beats total); no action >2s; final 1s hold only.

overall_soundscape: near-silence — one soft breath, a faint crystal tick on the turn.

non_diegetic_music: {single sustained note — glass harmonica / bowed crystal} rising with the turn, released at the fade.
```

## Room outfit showcase — ref beat-for-beat
model: h3
tag: fashion
description: The exact grammar of the 8-second room reference: locked handheld, bright white coastal living room, walk-in → knot adjust → hair sweep → back turn, one act per second.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 8
music: beat
structure: single
camera: Static shot
idea: {MODEL — 20-32 unless specified: shoulder-length hair} in {DRESS — COLOUR and finish, spaghetti straps, waist-tie knot, midi length} with {FOOTWEAR} showcases it in {ROOM — bright white coastal living room}: walks in, adjusts the knot, sweeps her hair, turns to show the back — eight acts in eight seconds.

```
integrated_multimodal_description: Shot on a smartphone, {35mm-equivalent} at f/2.0, vertical 9:16, 30fps, LOCKED handheld at chest height with only a breath-float — the camera never moves, never zooms; every size change comes from her approach or her turns. {ROOM — white walls, a window bench with cream cushions, a low table of books, one pendant lamp}, bright soft daylight from {WINDOW SIDE}, no harsh shadows. TIMING: 8s total — ONE act per second, stamped: 0-1s {MODEL — 20-32 unless specified: young, beautiful, fashion-model quality - hair, skin, build, the mood she plays} takes two steps toward the lens onto her mark, arms relaxed swinging, direct gaze, full body in frame with the floor and her feet readable; 1-2s closer, legs crossing mid-stride, hips swaying slightly, gaze still locked on lens; 2-3s she arrives at medium-full, gaze drops to {DRESS described: colour and finish, strap style, neckline, waist-tie knot, ruched skirt, midi hem}, head tilts, one hand drifts toward the knot; 3-4s medium: BOTH hands at the knot, fingers adjusting the tie in a 3/4 turn, soft downcast look; 4-5s hands drop, torso squares, face lifts to the lens with calm confidence, straps and neckline fully readable; 5-6s one hand sweeps hair back off her forehead, eyes closing a half-beat mid-sweep, weight shifting to one hip; 6-7s the same hand flicks her {HAIR — bob / length} at the side as her body starts rotating, gaze snapping back to lens; 7-8s she completes the turn to a full BACK view — open back, strap hardware, zip line — and looks back over her shoulder into the lens, lips parted mid-word. No beat longer than 1.5s; hands, gaze and hem move on different channels every second; natural skin texture, true fabric color, no logos, no text. DURATION-SCALED: at 5-6s keep walk-in + knot adjust + hair sweep + back turn; at 10-12s add one extra walk stride at the start and a hem/footwear glance between the sweep and the turn. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: bare heel-steps on {FLOOR — tile / rug}, one soft fabric rustle at the knot, quiet bright room tone{VOICEOVER — optional: her quick presentational line in quotes, upbeat}.

non_diegetic_music: {breezy minimal groove — soft percussion, warm synth plucks} at medium tempo with a tick on the knot-adjust and the back turn; or exactly N/A with voiceover.
```

## Room outfit tour — adaptive beats
model: h3
tag: fashion
description: Locked-camera room showcase whose beats AND beat order are dynamic: every garment detail you name becomes its own showcase beat, and the flow library re-orders them — top-down tour, reverse reveal, detail cascade, bookend, arrival-hold or twirl-centre. Variants and chain scenes rotate the flows automatically.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 8
music: beat
structure: single
camera: Static shot
flows: TOP-DOWN TOUR | REVERSE REVEAL | DETAIL CASCADE | BOOKEND DETAIL | ARRIVAL-HOLD | TWIRL-CENTRE
tip: Dynamic beats + 6 flows. Name the outfit's real details (neckline, waist knot, hem, back, sleeves, hair) and each becomes a beat; leave one out and it is skipped. Each variant / chain scene runs a different flow, so the tour is re-ordered, never re-written.
idea: {MODEL — 20-32 unless specified: shoulder-length hair} in {OUTFIT — name the real pieces AND their details: neckline, waist detail, hem length, back, sleeves, print} with {FOOTWEAR} presents it in {ROOM — bright interior with layered depth}: she walks in and tours the garment feature-by-feature, one named detail per beat, ending on an eye-contact hold.

```
integrated_multimodal_description: Shot on a smartphone, {35mm-equivalent} at f/2.0, vertical 9:16, 30fps, LOCKED handheld at chest height with only a breath-float — the camera never moves, never zooms; every size change comes from her approach or her turns. {ROOM — walls, furniture, window bench, coffee table, rug}, bright soft daylight from {WINDOW SIDE}, no harsh shadows. BEAT ENGINE — never a fixed sequence: the tour is composed ONLY from the details you actually named in the idea. Skip any beat whose detail is not named; never invent a knot, slit, sleeve, print or back detail the garment does not have; if only two details are named, use those two at two different scales instead of inventing a third. Each beat = ONE act of 1–1.5s with hands, gaze and fabric on separate channels, matched ON the motion into the next beat. OPEN is always first: {MODEL — 20-32 unless specified: hair, build, jewelry} enters from the room's depth and walks straight at the locked lens, {FOOTWEAR} light, {OUTFIT — colour, fabric, cut} moving with her stride, full body with headroom. CLOSE is always last: she settles facing the lens, gaze locked, a calm confident hold to the final frame. FEATURE BEATS (each used only if its detail is named): NECKLINE — she arrives to three-quarter, gaze drops to the {NECKLINE}, one hand drifts up while the other stays still a beat. WAIST — both hands meet at the {WAIST DETAIL}, fabric dimpling under the touch, soft downcast look. HEM/FOOTWEAR — weight shifts to one hip, the {HEM} sways, she glances down at {FOOTWEAR} and back up. SLEEVES/CUFFS — one arm lifts, the {SLEEVE} line reads, cuff adjust, slow blink. BACK — she turns through a full back view, {BACK DETAIL} fully readable, then looks back over her shoulder into the lens. HAIR — one hand sweeps {HAIR} back off the forehead, eyes closing a half-beat mid-sweep. FLOW LIBRARY — if the request names a BEAT FLOW, build the beat ORDER on exactly that flow; otherwise choose one from the outfit: open back or cape → REVERSE REVEAL, flowy or pleated → TWIRL-CENTRE, one hero detail → BOOKEND DETAIL, tailoring or a minimal outfit → ARRIVAL-HOLD, short and dense → DETAIL CASCADE, otherwise TOP-DOWN TOUR. A flow only re-orders which named beats come when — it never adds a beat, never breaks the skip rule, never changes the 1–1.5s density. TOP-DOWN TOUR = OPEN → neckline → waist → hem/footwear → sleeves → back → hair → CLOSE. REVERSE REVEAL = OPEN → back view first → over-shoulder look → full turn to the front → neckline → waist → CLOSE. DETAIL CASCADE = OPEN → three detail beats back to back → one full-length settle → back → CLOSE. BOOKEND DETAIL = OPEN on an extreme close of {STRONGEST DETAIL} (she steps in until it fills frame, face out of frame) → she steps back to full length → presents {SECOND DETAIL} → steps in again to the first detail → CLOSE on eye contact. ARRIVAL-HOLD = OPEN held long (a slow walk-in, ~3s) → the two strongest details → CLOSE. TWIRL-CENTRE = OPEN → one slow turn on the spot, fabric flaring → detail beats as the turn settles → back → CLOSE. DURATION BUDGET — about one beat per second: 5-6s = OPEN + 2-3 named beats + CLOSE; 8s = OPEN + 5-6 named beats + CLOSE; 10-12s = OPEN + 7-9 named beats + CLOSE. No beat longer than 1.5s; hands, gaze and hem keep moving every second; natural skin texture, true fabric colour, no logos, no text. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

overall_soundscape: bare heel-steps on {FLOOR — tile / rug}, one soft fabric rustle per touch beat, quiet bright room tone{VOICEOVER — optional: her quick presentational line in quotes, upbeat}.

non_diegetic_music: {breezy minimal groove — soft percussion, warm synth plucks} at medium tempo with a soft accent tick on each beat change; or exactly N/A with voiceover.
```

## 💎 Jewellery glint cut montage — adaptive inserts
model: h3
tag: fashion
description: Cut-shot jewellery film: every piece you actually name earns its own macro insert, and the montage alternates performance beats with inserts, cutting on the glint itself. Pieces left unnamed get no insert and are never invented.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 12
music: subtle
structure: auto
camera: Auto
flows: PIECE-BY-PIECE | GLINT TO EYES | ASCEND | HERO SINGLE
tip: Cut-shot engine — name the real pieces (earrings, necklace, ring, bangles, watch, tikka) and each gets a macro insert cut; skip an unnamed piece and the beat disappears. Each variant runs a different flow, so the same jewels cut together in a new order.
idea: {WEARER — 20-32 unless specified: bare shoulder, hair, skin, no retouch shine} wears {PIECES — list every real piece and its metal/stone: earrings, necklace, ring, bangles, watch} in {SET — charcoal velvet wall / window-lit room}, and each named piece gets its own macro insert cut, with the montage cutting on the glint.

```
integrated_multimodal_description: Shot on {100mm macro + 50mm}, vertical 9:16, 24fps; {SET — charcoal velvet / soft window light}, one shaped key plus a rim that separates skin from darkness, caustics playing across the {SET}. CUT ENGINE — the montage alternates a performance beat with a macro INSERT for every piece you actually named in the idea, one insert per piece, in the order the flow sets; an unnamed piece gets no insert and is never invented; if only one piece is named, give it two inserts at two different scales plus one wide instead of inventing more. Every cut lands ON a glint — the flash of {STONE} is the cut point, so each incoming shot opens already sparkling. [Shot 1] {WEARER — 20-32 unless specified: skin, hair, bare shoulder} turns slowly through three-quarter; {PIECE 1} catches the key and fires; micro-expression — eyes drop to the piece, then rise to the lens. [Shot 2] At the cut the live clock sets, macro insert anchored ON HER: {PIECE 1} fills frame, {SETTING DETAIL — prongs / pavé / fringe} legible, facets walking one degree at a time, and the hand, wrist or earlobe is the thing that moves — the piece never floats free of her. [Shot 3] At the cut the live clock sets, back on her — profile or over-shoulder, {PIECE 2} now the brightest object in frame, breath moving the collarbone. [Shot 4] At the cut the live clock sets, macro on {PIECE 2 — the hero} then a pull to a held three-quarter close: she settles, gaze to lens, {PIECE SET} the only jewellery visible and every stone still lit. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the pieces: three or more named → PIECE-BY-PIECE, her eyes are the emotional anchor → GLINT TO EYES, mixed heights (bangles and rings below, necklace and earrings above) → ASCEND, one hero piece → HERO SINGLE. A flow re-orders and re-frames the same inserts; it never adds a piece. PIECE-BY-PIECE = performance → insert of piece 1 → performance → insert of piece 2 → held close. GLINT TO EYES = every insert match-cuts straight back to her eyes before the next piece. ASCEND = inserts run low to high: hands and rings → wrist and bangles → chest and necklace → ears → head ornament. HERO SINGLE = the hero piece takes two inserts at different scales plus one wide where it is the only bright thing in frame. TIMING: 12s total — cuts at the cut the live clock sets / the cut the live clock sets / the cut the live clock sets, every shot carrying one distinct act per 1.5s (8 stamped beats), no action longer than 2s, final second a held look only. No text, no logo, no retouch gloss on skin.

overall_soundscape: near-silence — one soft breath per beat, a faint crystal tick on each turn, fabric settling, distant room tone.

non_diegetic_music: {single sustained note — glass harmonica / bowed crystal} rising with each insert, released at the held close; or exactly N/A.
```

## 💎 Jewellery try-on — counter to mirror cuts
model: h3
tag: fashion
description: Getting-ready jewellery piece with cut-shots: tray to lift to clasp to mirror turn, one macro insert per named piece, ordered the way she would actually put them on. Dressing order is the flow.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 10
music: subtle
structure: auto
camera: Auto
flows: DRESSING ORDER | PIECE-FIRST | MIRROR DIALOGUE | BOX REVEAL
tip: Name the pieces and the putting-on order follows ears → neck → wrist → hand. Each variant runs a different flow: chronological try-on, piece-first macro, mirror dialogue or box reveal. Unnamed pieces never appear.
idea: {WEARER — 20-32 unless specified: hair tied or loose, robe or outfit} puts on {PIECES — name the real pieces: earrings, necklace, bangles, ring, watch} at {COUNTER — dressing table with tray, mirror, soft lamp}, hands working the clasps, ending on a composed gaze into the {MIRROR}.

```
integrated_multimodal_description: Shot on {50mm + 100mm macro}, vertical 9:16, 24fps; {COUNTER — marble or wood dressing table, tray, hand mirror, one soft lamp plus window light}, warm practical key with a cool rim so metal reads against skin. CUT ENGINE — every piece you named in the idea gets one beat plus, where it helps, one macro INSERT of the moment it fastens; an unnamed piece never appears, and no extra jewellery is invented to fill the montage; with three or more named pieces follow the human dressing order — ears → neck → wrist → hand → hair. [Shot 1] The film opens ON HER: {WEARER — 20-32 unless specified: hair, skin, bare shoulder} at the {COUNTER}, waist-up with the tray and the mirror in frame, then she lifts {PIECE 1} from the tray, the clasp or hook turned toward the lens, breath held a beat as it catches; her face is the whole performance — tongue between the teeth, a small satisfied exhale on the click. [Shot 2] At the cut the live clock sets, macro insert anchored ON HER: the {CLASP / HOOK / CLOSURE} closing at the {EARLOBE / NAPE / WRIST}, skin honest, {PIECE 1} settling with a last tick of movement. [Shot 3] At the cut the live clock sets, the mirror: she turns her head to check the {PIECE 2 if named — otherwise her own reflection}, sees the piece catch the lamp, and her expression shifts — a private half-smile, eyes flicking to the lens through the glass. [Shot 4] Composed finish: she settles facing the mirror, {PIECE SET} readable, one hand resting at the collarbone, gaze holding to the last frame. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the moment: a full get-ready sequence → DRESSING ORDER, the piece is the hero → PIECE-FIRST (the piece lifted in her hand out of the tray, then the fastening on her, then her), the reflection carries the emotion → MIRROR DIALOGUE (her, then her reflection, then back, each cut landing on a new micro-expression), the piece arrives in a box → BOX REVEAL (lid, tissue, lift, wear, look). TIMING: 10s total — cuts at the cut the live clock sets / the cut the live clock sets / the cut the live clock sets, one distinct act per 1.5s inside every shot (7 stamped beats), no action over 2s, final second held only. No text, no logo.

overall_soundscape: the small sounds that sell it — metal tick on tray, clasp click, hinge of the mirror, fabric of the robe, one exhale on each settle.

non_diegetic_music: {warm minimal piano or soft synth pad} at a slow tempo, quiet under the clicks; or exactly N/A.
```

## 💎 Bridal jewel cascade — one insert per ornament
model: h3
tag: fashion
description: Ornament-led bridal film built from cut-shots: every ornament you name gets its own insert against jewel-tone light, and the flows run the cascade low-to-high, high-to-low, in counting rhythm or on one hero ornament.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 12
music: subtle
structure: auto
camera: Static shot
flows: ASCENT | DESCENT | SET COUNT | HERO ORNAMENT
tip: Name the real ornaments (maang tikka, jhumkas, choker, rani haar, bangles, hand-chain, rings, nath, latkan) — each named one gets an insert cut; unnamed ones never appear. With one or two named ornaments the same piece is shown at two scales instead.
idea: {BRIDE — 20-32 unless specified: hair, makeup, calm} wears {ORNAMENTS — name each real piece: maang tikka, jhumkas, choker, rani haar, bangles, hand-chain, rings} against {JEWEL BACKDROP — emerald / wine / midnight}, the ornaments lit so every stone fires, cut as one insert per named piece.

```
integrated_multimodal_description: Shot on {100mm macro + 85mm}, vertical 9:16, 24fps; {JEWEL BACKDROP} with a warm candle-like key and a raking rim so gold, polki and gemstones throw fire; soft bokeh points behind (fairy lights or diyas) that read as light, never as objects. CUT ENGINE — one insert for every ornament you named, none for the ones you did not, and never an invented ornament; with three or more named pieces each insert is a different ornament at a different scale, and with one or two named pieces the same piece is shown twice at two scales. [Shot 1] {BRIDE — 20-32 unless specified: hair, makeup, expression} in medium portrait — {ORNAMENT 1} swinging as she lifts her chin, downcast gaze rising slowly, one slow blink; stillness reads regal, only the jewellery moves. [Shot 2] At the cut the live clock sets, macro insert anchored ON HER BODY: {ORNAMENT 2} fills frame against {SKIN / EMBROIDERY}, {SETTING DETAIL — polki cut, pearl fringe, kundan edge} legible, the bangle or earring still moving a half-beat after her hand settles. [Shot 3] At the cut the live clock sets, wider again — three-quarter, {ORNAMENT 3} catching the key as she turns her head one degree, breath moving the collarbone, the ornament the only bright thing in frame. [Shot 4] At the cut the live clock sets, insert on {ORNAMENT 4 or the hero}, then a composed held finish: chin tilt, dupatta edge and {ORNAMENT SET} both readable, gaze to lens, stillness to the last frame. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the set: a full set from bangles to tikka → ASCENT, a full set working down from the head → DESCENT, many small pieces in a rhythmic montage → SET COUNT (each cut lands on the chime and counts in a new ornament), one statement piece → HERO ORNAMENT. ASCENT = inserts run low to high: hands and rings → wrist and bangles → chest choker and rani haar → ears → maang tikka. DESCENT = the reverse, head first, hands last. SET COUNT = rapid inserts, one ornament per cut, the sound of each closing the previous beat. TIMING: 12s total — cuts at the cut the live clock sets / the cut the live clock sets / the cut the live clock sets, one distinct act per 1.5s inside every shot (8 stamped beats), no action longer than 2s, final second held only. No text, no logo.

overall_soundscape: bangle chime on the insert cuts, the weight of fabric shifting, one held breath on each settle, a distant shehnai-like tone far under the mix.

non_diegetic_music: {stately strings with soft bells} at a slow tempo, one swell into the held finish; or exactly N/A.
```
## 🎼 Product tour — adaptive beats
model: h3
tag: product
description: Product film whose beats are the features you name — finish, texture, mechanism, scale, contents, label — each getting its own beat at its own scale. Unnamed features are skipped, and the flows change the order of the tour (surface-first, mechanism-first, scale reveal, bookend macro, in-use).
category: Product Showcase
ratio: 1:1
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
flows: SURFACE FIRST | MECHANISM FIRST | SCALE REVEAL | BOOKEND MACRO | IN-USE SANDWICH
tip: Dynamic beats — name the real product features and each becomes a beat at the scale that shows it best. Each variant runs a different flow, so the same object is toured in a new order.
idea: {PRODUCT — the real features: material and finish, texture, its mechanism, scale in hand, the label} on {SURFACE — stone / linen / water / brushed concrete} in {LIGHT — strip-box + gradient void}, the camera touring one named feature per beat.

```
integrated_multimodal_description: Shot on {50mm macro + 100mm}, 24fps, {LIGHT — strip-box speculars, gradient sweep behind for separation, contact shadow so the object sits on something real}. BEAT ENGINE — build the tour only from the features you actually named in the idea; skip the beat of any feature that is not named and never invent a mechanism, texture or label; if only two features are named, give each two scales instead of inventing a third. One beat = one feature at the scale that shows it: FINISH (a slow arc so the specular sweeps across {FINISH}, reflections moving with the object) · TEXTURE (macro push until {TEXTURE} fills frame, light raking so relief reads) · MECHANISM (the real action performed once — {MECHANISM} opens, clicks, unscrews or extends, and its consequence is visible) · SCALE (it meets a hand, a coin or a ruler, so size lands instantly) · CONTENTS (the packaging opens or pours and {CONTENTS} behaves with named viscosity) · LABEL (brand mark faces the lens and the key light rakes across it) · IN-USE (the object doing its job in a real hand, with the consequence visible). FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the story: material is the selling point → SURFACE FIRST, the mechanism is the selling point → MECHANISM FIRST, size is surprising → SCALE REVEAL, one strong texture and a logo → BOOKEND MACRO, it is used by a person → IN-USE SANDWICH. A flow re-orders the same named beats; it never adds one. SURFACE FIRST = finish arc → texture macro → mechanism → label → held hero. MECHANISM FIRST = the mechanism close and upfront, then surface, then scale, then the label closing frame. SCALE REVEAL = extreme macro first (unrecognisable), pull wider to reveal the object, hand enters for scale, held hero. BOOKEND MACRO = macro texture → wide hero with label → back to macro → held hero. IN-USE SANDWICH = hero wide → hand uses it (beat with consequence) → macro of the part that did the work → held hero. TIMING: 8s total — about one beat per second for the named features (6-7 acts), no action longer than 2s, final second held only. Highlights must move continuously — a specular that jumps between frames reads as plastic.

overall_soundscape: {the object's real foley — click, cap thread, hinge, pour, spray} timed to the exact beat, plus a quiet studio-ambient bed and the surface's own character.

non_diegetic_music: {restrained electronic bed — one pulse, one warm pad} at a calm tempo, dropping out for the mechanism beat so the click carries; or exactly N/A.
```

## 🎼 UGC demo — adaptive beats
model: h3
tag: vertical
description: Creator-style demo whose beats come from what you actually name — the problem, each demo step, the result, the ask. Nothing named means no beat, so the arc compresses cleanly; flows run problem-first, result-first, three-step ladder or day-in-life sandwich.
category: Social Media Content
ratio: 9:16
resolution: 768P
duration: 10
music: beat
structure: multi2
camera: Auto
flows: PROBLEM FIRST | RESULT FIRST | THREE STEP LADDER | DAY-IN-LIFE SANDWICH
tip: Dynamic beats — name the problem, the demo steps and the result and each becomes a beat; leave the problem out and the clip opens straight on the demo. Each variant runs a different flow, and the arc always compresses to the duration you set.
idea: {PERSON — age, look, real room} shows {PRODUCT — real name and what it does} in {ROOM — kitchen / bedroom / car / bathroom}: hook on {PROBLEM or RESULT — whichever you name}, {DEMO STEPS — the real actions, one per beat}, then {ASK — the recommendation-style close}, phone-shot, talking to the lens.

```
integrated_multimodal_description: Shot on a phone, {26mm-equivalent} at f/1.8, vertical 9:16, 30fps, handheld with autofocus breathing and one wrist-turn re-grip; {ROOM — lived-in, window or practical lamp as the only light, slightly underexposed, real clutter at the edges}. BEAT ENGINE — build the arc ONLY from what you named: HOOK opens the clip and always exists (the named problem seen or the named result shown); each DEMO step you name becomes its own beat with the product doing real work in real hands and its consequence visible; PROBLEM, RESULT and ASK appear only if you named them — an unnamed problem is never invented, so the clip simply opens on the demo. Speech stays in quotes with tone and pace, short enough to say twice inside its shot; the CTA sounds like advice, never a pitch. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: a problem people recognise → PROBLEM FIRST, a dramatic result → RESULT FIRST, a process with clear steps → THREE STEP LADDER, the product sits inside a routine → DAY-IN-LIFE SANDWICH. A flow re-orders the same named beats; it never adds one. PROBLEM FIRST = the named problem happening in frame → the product arrives → demo beats → result → ask. RESULT FIRST = the payoff or transformation in the first second, then a rewind to the problem, demo beats, ask. THREE STEP LADDER = hook, then each named step performed and spoken as it happens, then the ask. DAY-IN-LIFE SANDWICH = morning routine beat, the product appears naturally inside it, one demo beat, ask. DURATION BUDGET — 5s = hook + one demo beat + ask; 8s = hook + problem + demo + ask; 10-12s = hook + problem + two demo beats + result + ask; 15s and up = the full arc with three demo beats. No beat longer than 2s of screen time, no beat without a visible consequence.

overall_soundscape: phone-mic realism — room tone that never drops, the true foley of the demo (taps, clicks, pours, packaging, fabric), music low and diegetic to the room, no score swell, no studio reverb.

non_diegetic_music: {a soft lo-fi loop under the speech} or exactly N/A if the voice carries it.
TIMING: derive every cut from the live CLOCK — how many shots the runtime holds is what the film gets, and the beats inside them run at their own pace (~1.5s each) rather than being stretched to fill a shot. Change the duration and every segment scales with it.
```

TIMING: derive every cut from the live CLOCK — how many shots the runtime holds is what the film gets, and the beats inside them run at their own pace (~1.5s each) rather than being stretched to fill a shot. These are proportions of the runtime: change the duration and every segment scales with it.
## 🎼 Dish story — adaptive beats
model: h3
tag: food
description: Food film built from the techniques you name — the pour, the sizzle, the steam, the pull, the crust, the garnish each become a beat with their own foley; skip an unnamed technique and the beat disappears. Flows run build-up, table-first, one-take kitchen or steam-first.
category: Commercial / Brand Film
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: multi2
camera: Auto
flows: BUILD-UP | TABLE FIRST | ONE-TAKE KITCHEN | STEAM FIRST
tip: Dynamic beats — name the real techniques (pour, sizzle, steam, pull, crust, garnish) and each becomes a beat with its own sound; the flows decide whether the film builds to the plate, opens on the finished dish, or stays in one locked kitchen shot.
idea: {DISH — real name and its components} in {SETTING — home kitchen / restaurant pass / table}, the making shown through {TECHNIQUES — name each real one: pour, sizzle, steam, pull, crust, garnish}, backlit so steam and gloss live, ending on the plate presented.

```
integrated_multimodal_description: Shot on {50mm + 100mm macro}, vertical 9:16, 24fps, backlit or side-back so steam, oil sheen and condensation glow, one bright specular on every wet surface, fill only enough to keep shadow detail. BEAT ENGINE — each TECHNIQUE you named becomes one beat with its own sound and its own physical consequence: POUR (viscosity named — beaded stream, glossy mound, a drip that holds then releases) · SIZZLE (oil popping at the pan edge, an ingredient laid in, crust forming) · STEAM (backlit curl drifting across frame, changing shape beat to beat) · PULL (tension until it snaps — cheese, dough, caramel) · CRUST (a break that cracks, yolk giving way, a shell splitting) · GARNISH (the last element landing on the hero surface) · COLD (frost blooming, carbonation rising, condensation running). Skip any technique that is not named, never invent an ingredient, and never repeat the same technique twice unless the idea asks for it. Hands and tools enter in part — tongs turning, a spoon sliding under the sauce, a hand breaking the crust — never covering the gloss. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the piece: the making is the drama → BUILD-UP, the finished plate is the hook → TABLE FIRST, hands only, no cuts → ONE-TAKE KITCHEN, steam is the star → STEAM FIRST. A flow re-orders the same named beats; it never adds one. BUILD-UP = raw ingredient → each named technique in order → the plate presented and still alive. TABLE FIRST = the finished dish in best light, then a cut back to the making beats, then the plate again. ONE-TAKE KITCHEN = one locked frame, hands only, the named techniques happening inside it in order. STEAM FIRST = backlit steam curl opening, then the technique beats, then the plate with steam still rising. TIMING: 8s total — one beat per second across the named techniques (6-7 acts), no beat over 2s, final second a held presentation with steam still moving. Food must stay in the same light across cuts so it reads as one meal.

overall_soundscape: the techniques' own foley — crack, sizzle, fizz, pour, crunch, dome-pop, cling — timed sample-accurate to the picture, kitchen ambience under it.

non_diegetic_music: {warm sparse acoustic bed} at a relaxed tempo, dropping out for the loud beats; or exactly N/A.
```

## 🎼 Space reveal — adaptive beats
model: h3
tag: space
description: Interior or architecture film whose beats are the elements you name — window, staircase, artwork, floor, ceiling, furniture, view — each getting one clean beat at the height and distance where it reads. Flows run enter-and-ascend, detail-first, light-chase or symmetry axis.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 10
music: subtle
structure: multi2
camera: Auto
flows: ENTER AND ASCEND | DETAIL FIRST | LIGHT CHASE | SYMMETRY AXIS
tip: Dynamic beats — name the real elements of the space and each becomes a beat; unnamed elements are skipped, so the film never fills itself with generic room shots. Each variant runs a different flow, re-ordering the tour of the space.
idea: {SPACE — real type and materials} at {LIGHT — time of day + source}, its {ELEMENTS — name each real one: window, staircase, artwork, floor, ceiling, furniture, view} revealed one clean beat at a time, with {FIGURE — optional person} giving scale.

```
integrated_multimodal_description: Shot on {24mm + 50mm}, 16:9, 24fps, {LIGHT — window shafts with visible dust, practicals with visible falloff, or a cool overcast wash}; verticals stay vertical and the camera never fights the architecture. BEAT ENGINE — each ELEMENT you named becomes one beat at the height and distance where it reads: WINDOW (shafts across the floor, dust in the beam, the patch moving as the shot progresses) · STAIRCASE (a lateral slide or a slow rise following the flight) · ARTWORK or OBJECT (a slow push until texture and frame read) · FLOOR (low travel across {FLOOR MATERIAL} so grain and reflection land) · CEILING (a tilt or rise that reveals structure and height) · FURNITURE (a frame composed around one piece, its material honest) · VIEW (a move toward the opening until the outside reads as a second plane) · FIGURE (a person crosses through depth, giving scale and time). Skip any element that is not named; never invent rooms that are not in the idea. Keep at least two ambient channels moving every beat — a sun patch, a curtain breathing, steam, dust. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the space: a big volume or a mezzanine → ENTER AND ASCEND, one material carries the space → DETAIL FIRST, hard directional sun → LIGHT CHASE, a hall or a corridor → SYMMETRY AXIS. ENTER AND ASCEND = enter at floor level, rise through the volume, finish wide at the highest readable point. DETAIL FIRST = material macro opens, then the room widens around it, then one element beat, then the composed wide. LIGHT CHASE = the camera follows the light — shafts, pools, practicals — each beat landing where the light already is. SYMMETRY AXIS = locked on the axis, elements revealed by slow lateral movement and the figure crossing. TIMING: 10s total — one beat per second across the named elements (7-8 acts), no shot shorter than 2s, final second a composed architectural hold with the figure exactly where the geometry wants them. Move idea per shot, never per beat.

overall_soundscape: the room's own reverb — footsteps with a long tail, a door closing into a large silence, a distant hum, water somewhere, air movement; silence here is a texture, not an absence.

non_diegetic_music: a sparse ambient bed that swells only with the widest reveal, or exactly N/A.
```

## ⚡ LTX adaptive flow — beats by the beat
model: ltx
tag: fashion
description: The one-paragraph version of the dynamic beat engine: each sentence is a beat built from a detail you actually name, in the order of the flow you get — rise, fall, pivot or reveal — and the paragraph length scales with the duration.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 8
music: beat
camera: Auto
flows: RISE | FALL | PIVOT | REVEAL
tip: Dynamic beats for LTX — one sentence per named detail, unnamed details skipped, and each variant runs a different flow so the paragraph is re-ordered, not re-written. No cut language at all: LTX stays one continuous paragraph.
idea: {SUBJECT — 20-32 unless specified: person or product} with {DETAILS — name each real detail you want shown: neckline, fabric, hem, print, hardware, hair} in {SETTING} at {LIGHT}, shot as one continuous take.

```
prompt: Shot on a smartphone, {35mm-equivalent} at f/2.0, vertical 9:16, 30fps, handheld with a slow breath-float, {SETTING} in {LIGHT}. Beat engine for a single paragraph: write ONE sentence per DETAIL you actually named in the idea — {DETAIL 1}, {DETAIL 2}, {DETAIL 3} — and skip any detail that is not named; never invent a feature, and never write a sentence that only restates the setting. Each sentence carries one act (1–1.5s of visible change) with the hands doing one thing, the gaze another and the fabric or surface a third, so no sentence is a static description. Follow the flow named in the request, otherwise pick from the subject: {FABRIC that moves or drape} → RISE, {structured tailoring / posture} → FALL, {a piece that reads on a turn} → PIVOT, {one hero detail} → REVEAL. RISE = the paragraph travels up the body or the object, finishing on the face or the hero surface. FALL = it starts at the face and settles downward into the detail. PIVOT = the turn is the spine of the paragraph and details land as it passes. REVEAL = hold one detail back until the final sentence, then land on it and end the paragraph there. Match the sentence count to the duration: 5-6s ≈ 3-4 sentences, 8s ≈ 5, 10-12s ≈ 6-7. End on a still, composed sentence — gaze to lens or the hero surface fully lit — and never repeat a descriptive phrase twice in the paragraph.

negative_prompt: text, watermark, logo, morphing, extra limbs, warped hands, duplicated details, cut, dissolve, montage, flicker

tags: fashion, adaptive, ltx, t2v, vertical
```
## 👤 Portrait — adaptive beats
model: h3
tag: portrait
description: Portrait film whose beats come from the features you actually name — eyes, hands, hair, a wardrobe detail, a prop, breath — and whose flows decide whether the film lives in window light, in the room, in the hands, or opens already close. Unnamed features get no beat.
category: Cinematic Film Scene
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
flows: WINDOW LIGHT | ENVIRONMENT | HANDS AT WORK | CLOSE FIRST
tip: Dynamic beats — name the real features (eyes, hands, hair, a collar, a cup) and each becomes a micro-expression beat; leave one out and it disappears. Each variant runs a different flow, so the same face reads new.
idea: {SUBJECT — 20-32 unless specified: age, face, one signature feature} is {ACTION — waiting / working / listening} in {SETTING} at {LIGHT — window / lamp / overcast}, the camera reading {FEATURES — name each real one: eyes, hands, hair, collar, prop}, ending on a settled gaze.

```
integrated_multimodal_description: Shot on {50mm or 85mm} at f/1.8, vertical 9:16, 24fps, focus on the nearer eye, {LIGHT} as the key with an eye-light so the eyes live and a rim separating {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing}'s hair from {SETTING}; foreground occlusion (a doorframe, curtain edge, plant or another shoulder) seats the person in a real room, and the background stays soft but legible. BEAT ENGINE — write only the features you actually named, one micro-beat each: EYES (a blink that lands after a thought, the gaze moving before the head does, a slow return to the lens) · HANDS (given one job — a cup, a collar, hair, a tool — with the fingers finishing their movement after the sentence ends) · HAIR (a strand displaced by breath or wind, or swept back and settling) · COLLAR or WARDROBE detail (one adjustment, fabric creasing then relaxing) · PROP (held, turned, set down — its consequence visible) · BREATH (chest and shoulder movement on a long exhale, jaw loosening). Skip any feature that is not named, never invent a second prop or a second person, and never let the clip become a held stare: a micro-expression must be resolving at all times. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the subject: the face is lit from one window → WINDOW LIGHT, the room carries the meaning → ENVIRONMENT, the person is doing something with their hands → HANDS AT WORK, the eyes are the whole story → CLOSE FIRST. WINDOW LIGHT = start three-quarter in the light, name beats as the light changes on the face, finish in a near-profile with the light grazing. ENVIRONMENT = open wide enough to read the room, then move in feature by feature, ending close and settled. HANDS AT WORK = the hands open the clip, the face is revealed as they pause, the beats live with the hands, and the gaze closes it. CLOSE FIRST = begin at the closest framing, then breathe outward one step at the end. TIMING: 8s total — about one beat per second (6-7 micro-beats), no feature beat longer than 2s, no held expression past 1.5s, and the final second is a settled gaze with the breath still moving.

overall_soundscape: intimate room truth — breath between beats, cloth shifting, the prop's small foley, continuous room tone, one distant world sound (a street, a kettle, a bird).

non_diegetic_music: {one sparse sustained instrument} at a slow tempo, or exactly N/A so the breathing carries it.
```

## 🏃 Sport peak — adaptive beats
model: h3
tag: sports
description: Action film built around the named peak instant — the contact, the release, the plant of a foot. Beats come from the mechanics you name (load, drive, contact, follow-through, recovery) and the flows decide whether the clip builds to the peak, opens on it, rides reps, or studies the technique.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 8
music: beat
structure: multi2
camera: Auto
flows: BUILD TO PEAK | PEAK FIRST | SET RHYTHM | TECHNIQUE STUDY
tip: Dynamic beats — name the real mechanics (crouch, load, drive, contact, follow-through, land) and each becomes a beat; the PEAK is the named instant everything is built around. Each variant runs a different flow.
idea: {ATHLETE — build, kit, one detail} performs {SPORT ACTION} at {VENUE} in {LIGHT}, the decisive instant being {PEAK — contact / take-off / release / landing}, with {SURFACE} reacting under them.

```
integrated_multimodal_description: Shot on {long lens or low handheld} at {f-stop}, {RATIO} 16:9, {fps — 24 for film, 60+ only if the idea asks for slow motion}; {LIGHT — floodlights with visible flare, hard morning sun, gym practicals or overcast wash}. BEAT ENGINE — write the mechanics you actually named, one beat each, in physical order: PREP (crouch, load, grip, breath held — muscles visibly loading before they fire) · DRIVE (the stride, the hip rotation, the arm path — give the chain: heel plant → hip → shoulder → wrist) · PEAK (the named instant, held crisply — ramp into it and out of it, never slow the whole clip) · FOLLOW-THROUGH (recovery of the body after the effort, one clear secondary motion — the arm trailing, the torso unwinding) · SURFACE (the surface reacting: turf divots, chalk dust, water spray, sand, a shoe squeal) · AFTERMATH (chest heaving, a hand on a knee, a fist relaxing, sweat flicking). Skip any mechanic that is not named; never invent a scoreboard, crowd chant or second athlete. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: the peak is a spectacle → BUILD TO PEAK, the result matters more than the process → PEAK FIRST, a gym or track set with repeats → SET RHYTHM, technique coaching → TECHNIQUE STUDY. BUILD TO PEAK = real-time approach, ramp slow just before the instant, hold the impact crisp, explode out of it. PEAK FIRST = open on the instant in slow motion, then cut back to real time and rebuild to it. SET RHYTHM = one rep per beat with the count audible, the last rep the fullest. TECHNIQUE STUDY = locked frame, the mechanics clean and readable, one beat per phase, no speed ramp at all. One speed change per beat; a clip that is entirely slow motion has no peak. TIMING: 8s total — 5-6 stamped beats, the peak never longer than 1.5s on screen, final second the aftermath rather than a held body in mid-air. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: sample-accurate impacts (thud, hand on leather, footfall, net snap, whistle), breath as the rhythm bed, the venue's ambience under it; music only if it belongs to the event.

non_diegetic_music: {percussive sports bed} locked to the beats, dropping out entirely for the peak instant; or exactly N/A.
```

## 🚗 Car walkaround — adaptive details
model: h3
tag: vehicle
description: Cut-shot walkaround: every feature you name — wheel, headlight, badge, paint reflection, interior, engine bay, boot — gets its own beat at its own scale, with the flows running wheels-up, front-to-rear, interior-first or a detail bookend.
category: Commercial / Brand Film
ratio: 16:9
resolution: 2K
duration: 10
music: subtle
structure: multi3
camera: Auto
flows: WHEELS UP | FRONT TO REAR | INTERIOR FIRST | DETAIL BOOKEND
tip: Dynamic beats — name the real features and each gets its own beat; the flows decide the tour order. One rolling shot at the end sells weight — the wheel rotation and motion blur must match the speed.
idea: {CAR — make, finish, signature detail} on {LOCATION — wet city night / mountain road / studio}, the camera touring {FEATURES — name each real one: wheels, headlight, badge, paint, interior, engine bay, boot}, ending on {CLOSING — a rolling shot or a held hero}.

```
integrated_multimodal_description: Shot on {35mm + 85mm}, 16:9, 24fps; {LIGHT — streetlights and signage raking the paint, soft studio strip across the flank, or hard sun with long shadows}. BEAT ENGINE — one beat per feature you actually named, at the scale that sells it: WHEELS (low mount at wheel height, spokes turning, brake caliper legible) · HEADLIGHT (ignition sweep or light landing on the bumper, flare blooming then controlled) · BADGE (macro with the key raking across it so the metal reads) · PAINT (reflection logic — sky gradient, passing trees, neon sliding along the flank) · INTERIOR (door opens, dials waking, gear lever thrown, stitching and screen legible) · ENGINE BAY (lid up, light travelling across the bay, bay walls honest) · BOOT (closing with weight, the latch landing) · CLOSING ROLLING SHOT (matched speed, shallow depth on the body, road rushing under, wheel rotation and motion blur matched to the speed). Skip any feature that is not named; never invent a feature or a second car; wheels must stay identical across every shot or the cut reads as a different vehicle. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the story: stance and wheels sell it → WHEELS UP, the silhouette sells it → FRONT TO REAR, the cabin is the point → INTERIOR FIRST, one material carries the car → DETAIL BOOKEND. WHEELS UP = wheels and stance first, then travel up the body, finish on the front and a held hero. FRONT TO REAR = a lateral travel past the flank from the nose to the tail, features landing as they pass. INTERIOR FIRST = open inside, then step out and tour the exterior, closing on the rolling shot. DETAIL BOOKEND = macro on the signature detail, wide hero, back to the macro, held hero. TIMING: 10s total — cuts at the cut the live clock sets / the cut the live clock sets / the cut the live clock sets, one feature beat per shot and one distinct act per 1.5s inside each (7-8 beats), no beat over 2s, final second a held hero or a rolling pass, never a wheel spinning against a static frame.

overall_soundscape: engine note with a specific character (rpm rise and fall, turbo spool, induction flutter), tyre scrub and gravel rattle, door thud and latch click, road noise inside the cabin — every foley landing exactly on the picture.

non_diegetic_music: {restrained cinematic bed with a low pulse} that drops out for the engine start and returns on the closing shot; or exactly N/A.
```

## 🎥 Craft process — adaptive beats
model: h3
tag: documentary
description: Workshop documentary whose beats are the process steps you name — the measurement, the cut, the joint, the finish — with faceless hands-and-tool inserts. Flows run hands-first, tool-first, start-to-finish or a detail cascade.
category: Documentary
ratio: 16:9
resolution: 2K
duration: 10
music: subtle
structure: multi2
camera: Auto
flows: HANDS FIRST | TOOL FIRST | START TO FINISH | DETAIL CASCADE
tip: Dynamic beats — name the real process steps (measure, cut, sand, join, finish) and each becomes a beat with its own sound; inserts are anchored on the hands, never floating objects. Each variant runs a different flow.
idea: {CRAFTSPERSON — age, hands} makes {OBJECT} in {WORKSHOP — light, tools, mess}, working through {STEPS — name each real step: measure, mark, cut, sand, join, finish}, with {TOOL} and {MATERIAL} doing the visible work.

```
integrated_multimodal_description: Shot handheld on a documentary camera, {35mm} at T2.0, 16:9, 24fps, {LIGHT — window light with dust in the beam, a single work lamp, or overcast through the doorway}, available light only, slight noise in the shadows kept. BEAT ENGINE — one beat per STEP you actually named, each with its own foley and its own physical consequence: MEASURE/MARK (rule or square placed with a pencil line drawn and checked) · CUT (blade or saw entering, chips or swarf leaving the line) · SHAPE (planes, chisels, spokeshave — shavings curling, the surface changing) · SAND/FINISH (dust blooming in the light, texture flattening under the hand) · JOIN/ASSEMBLE (parts meeting, a mallet or clamp landing, the fit checked by hand) · HEAT/TREAT (flame, steam, oil, quench — the material answering) · REVEAL (the finished object turned to the light, held in the working hands). Skip any step that is not named, never invent a machine, a second craftsperson or a product label. FACELESS INSERTS anchored ON THE HANDS or the working body — a thumb pressing a seam, chips on a forearm, sweat under a work light, the tool worn smooth; never a floating object shot. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the piece: hands are the subject → HANDS FIRST, one beautiful tool is the story → TOOL FIRST, a complete build from raw to done → START TO FINISH, one material with fine work → DETAIL CASCADE. HANDS FIRST = open on hands already working, stay intimate, widen once at the end to show the person and the workshop. TOOL FIRST = tool macro, then the hands using it, then the work, then the object held. START TO FINISH = raw material, each named step in order, the finished object in the same frame at the end. DETAIL CASCADE = three inserts back to back (dust, texture, the fit), then one wide of the craftsperson working, then the object. TIMING: 10s total — cuts at the cut the live clock sets / the cut the live clock sets, one distinct act per 1.5s inside every shot (7-8 stamped beats), no step stretched past 2s, final second the object held and still. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: the work's own sounds first (tool bite, wood or metal under pressure, sanding rasp, a mallet, a kettle or radio somewhere), room tone continuous under every cut, breath audible when the effort is real, no score competing with the workshop.

non_diegetic_music: a single sparse instrument that enters only for the final held frame, or exactly N/A.
```


## ✂️ Papercraft cut-out explainer — adaptive beats
model: h3
tag: papercraft
description: Tactile cut-paper explainer: layered diorama sets, halftone photographic cut-outs and flat colour fields that assemble piece by piece to land one idea. Beats come from the pieces you actually name — a piece left out never appears. Collage foley only, no music or voice by default.
category: Animation
ratio: 16:9
resolution: 2K
duration: 8
music: none
structure: single
camera: Auto
flows: PIECE IN | FIELD FIRST | LAYER BUILD | TURN OF THOUGHT
tip: Dynamic beats — every named piece (a cut-out figure, a prop, a symbol, a layer of the set) becomes one stop-motion beat and one sound. Name it and it assembles; leave it out and it stays off-screen.
idea: {IDEA — one sentence the viewer should understand} built as a paper collage: {PIECES — name each cut-out, 3-5 of them: a figure, a machine, a symbol, a prop}, assembling on {FIELD — the base colour field, e.g. deep teal cardstock, warm cream, oxblood}, with {ACCENT — the single coloured cardstock accent}.

```
integrated_multimodal_description: 16:9, 24fps, a tactile stop-motion paper-collage film: a flat {FIELD} cardstock field, black-and-white halftone photographic cut-outs, one {ACCENT} cardstock accent, warm cream keylines, soft physical shadows, subtle paper fibre and slightly torn deckled edges — clean and refined hand-made texture, never distressed, brown or over-aged. No readable text anywhere: no letters, numerals, logos, subtitles or UI. BEAT ENGINE — one beat per NAMED piece, in this order of construction: PIECE (it appears whole, slides or pops into position, gives a light bounce, presses flat, pauses, then locks) · LAYER (a set layer drops in behind the acting pieces and deepens the space) · GESTURE (a piece crosses, points, lifts or replaces another, its paper edge visibly overlapping) · DISCARD (one piece is pulled out and the composition closes the gap it leaves) · LOCK (the final assembly settles and holds, shadows agreeing with the field). Skip any piece that is not named; never invent a second figure, a second prop, or a background character. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the idea: a metaphor with one clear subject → PIECE IN, the space itself carries the meaning → FIELD FIRST, a system or process → LAYER BUILD, an opinion or turn → TURN OF THOUGHT. PIECE IN = the field is bare, pieces arrive one by one around the subject. FIELD FIRST = the whole field fills with flat colour and shapes before any cut-out enters. LAYER BUILD = foreground, midground and background arrive in that order, each layer tightening the scale. TURN OF THOUGHT = the composition holds one meaning, then one new piece lands and re-reads everything before it. MOTION LAW: paper moves by hand and then sits still — never spin, flip, fly chaotically, cross-fade, or drift with a digital pan or zoom. Keep foreground / midground / background separation, one clear subject hierarchy and controlled negative space. TIMING: 8s total — about one beat per 1.3s (6-7 beats maximum), the last beat locks the composition and holds it for the final second.

overall_soundscape: tactile collage foley only, each action owning one sound — a paper slide, a soft pop, a press-flat thump, a light rustle, one low tap when a piece locks; quiet room tone under it, no voices, no music.

non_diegetic_music: exactly N/A — the collage sounds are the soundtrack unless the user asks for score.
```

## 🧊 Minimalist product ad — copy-beat film
model: h3
tag: minimalist
description: Premium clean-room product film: seamless coloured backdrop, one soft key, one object, and the selling points you name turned into on-screen copy beats that land with the camera reveals. No hands, no props, no clutter.
category: Product Showcase
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: multi2
camera: Auto
flows: PLINTH ORBIT | SEAMLESS SWEEP | TOP-DOWN REVEAL | COPY-LED CUTS
tip: Dynamic beats — every selling point you name becomes one copy beat locked to one camera reveal. Two points, two beats; five points, five beats and a busier edit.
idea: {PRODUCT — form, material, finish, colour and where the brand mark sits} alone on {BACKDROP — one seamless colour, e.g. stone-grey paper sweep}, lit by {LIGHT — one large soft key with a slow gradient falloff}; copy beats in order: "{COPY 1 — 2-5 words}", "{COPY 2}", "{COPY 3}", closing on {HERO LINE — the final line above the product}. Selling points to dramatise: {POINTS — e.g. battery life, weight, material, fit}.

```
integrated_multimodal_description: 9:16, {24 or 30}fps, a premium minimalist product film: a seamless {BACKDROP} paper sweep with no horizon line, floor and wall one continuous colour, one large soft key with a slow gradient falloff, a soft contact shadow under the product and a whisper of fill — clean commerce lighting, no hard specular, no visible light source, no set dressing. The object is the only thing in frame: no hands, no second product, no props unless the idea names one. BEAT ENGINE — one beat per NAMED selling point, each beat a copy line landing with its own reveal: PROFILE (a slow orbit opens the silhouette and the first copy line fades up in the negative space) · TEXTURE (a macro sweep crosses the material as its copy line cuts in) · SCALE (the move steps back or the object turns to show proportion) · DETAIL (one specific feature — a button, a seam, a port, a badge — holds for its line) · HERO (the product settles front-on for the closing line, mark legible and inside a safe zone). Skip any point that is not named; never invent a claim, a number, a price or a certification. On-screen copy uses English double quotation marks VERBATIM, exact words, one line at a time, 2-5 words, placed in the negative space and never over the product's mark. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the object: a sculptural object → PLINTH ORBIT, a flat or fabric product → SEAMLESS SWEEP, a set of parts or a kit → TOP-DOWN REVEAL, copy is the whole story → COPY-LED CUTS. PLINTH ORBIT = one continuous orbital move, the product on a raised plane. SEAMLESS SWEEP = dolly across the seamless backdrop, the product entering and exiting frame. TOP-DOWN REVEAL = an overhead move with the object laid out, copy in the margin. COPY-LED CUTS = hard cut on each copy line, camera restated each time. One camera move per shot, written as motion type + amplitude + speed with an end-state. TIMING: 8s total — 3-4 stamped beats of about 2s each, no copy line on screen longer than 2s, the closing line holds to the last frame.

overall_soundscape: the object's own foley, small and precise — a fabric rub, a click, a lid seating, a zipper, a casing settling on stone — pitched clean and close, with a very quiet studio room tone; no voices.

non_diegetic_music: {minimal score — one synth pad, a soft kick on the beats, or a single sustained piano note} at a slow to mid tempo, clean and uncluttered, dropping to a bare note under the closing hero line; or exactly N/A for a silent luxury treatment.
```

## 🔤 Kinetic lyric type — beat-locked subtitles
model: h3
tag: lyric
description: Music-video treatment where the lyric lines ARE the edit: every line appears verbatim as on-screen typography locked to the vocal and the downbeat, the type style reacting to the beat while the camera lands its cuts on the same pulse.
category: Music Video
ratio: 9:16
resolution: 2K
duration: 12
music: beat
structure: multi3
camera: Auto
flows: ONE LINE PER BEAT | TYPE CASCADE | CUT ON THE DOWNBEAT | VERSE TO CHORUS
tip: Dynamic beats — one named lyric line per beat. Give fewer lines and the film breathes on the instrumental; give more and the type gets busier and the cuts tighten.
idea: {TRACK — genre, tempo, one signature instrument} at its tempo; the performer {PERFORMER — one signature detail: hair, jacket, tattoo, silhouette} {ACTION — sings / mouths / moves} in {SETTING — one real place with depth}; lyric lines in order, exact words: "{LYRIC 1 — exact words of the first line}", "{LYRIC 2 — exact words of the second line}", "{LYRIC 3 — exact words of the third line}"; type set in {TYPE STYLE — e.g. condensed grotesque, hand-lettered marker, neon tube, torn paper letters} at {PLACEMENT — lower third, centred, tracking the performer}.

```
integrated_multimodal_description: 9:16, 24fps, a stylised music-video segment: {LIGHT — design: source, direction, contrast} with practical colour in the background, {GRADE — palette and contrast}, grain held fine and even, the frame composed with deliberate negative space for typography. The performer replaces the words with breath and body only when the line is off-screen — never invent new lyrics. LYRIC BEAT ENGINE — one NAMED lyric line per beat, verbatim, in English double quotation marks, appearing as on-screen typography as it is heard and leaving with the beat after it: LINE (one line at a time, 2-6 words, type in {TYPE STYLE — e.g. condensed grotesque, hand-lettered marker, neon tube}, placed in the negative space and never across the face) · REACTION (the type answers the music — a scale pop on the kick, a mask wipe on the snare, a letter cascade on the riser, a clean static hold on the tail) · MOTION (the performer moves on the pulse and the camera answers within the same beat) · BREATH (on an instrumental bar no new line appears and the frame lives on the performance). Never repeat a line that has already played, never translate, never paraphrase. VOICE: if the performer sings the line as well, keep the same words inside official <d>[Language] ...</d> markup with a stable speaker ID (S1) and leave the lips agreeing with the track. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the track: a hook with few words → ONE LINE PER BEAT, dense fast words → TYPE CASCADE, a hard-hitting track → CUT ON THE DOWNBEAT, a build with a chorus payoff → VERSE TO CHORUS. ONE LINE PER BEAT = one line per bar, camera moves gently under each. TYPE CASCADE = lines stack and hand off in one continuous move. CUT ON THE DOWNBEAT = a hard cut on each downbeat, the line already in place. VERSE TO CHORUS = verse type small and restrained, chorus type large, the change landing on the first chorus beat. Camera: motion type + amplitude + speed with an end-state, one move per shot; cuts land on musical beats, not on arbitrary seconds. TIMING: 12s total — about 5-6 stamped beats, one lyric line per beat, no line on screen longer than 2s, the last beat holds the final line to the cut. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: the room answering the track — the performer's breath and cloth on the beat, one or two real venue sounds (a reverb tail off a wall, a footstep, a distant crowd), mixed under the music; no dialogue.

non_diegetic_music: the track itself — {TRACK — genre, tempo, one signature instrument} — with the arrangement's dynamics stated bar by bar so the cuts and the type can lock to it; never N/A unless the user asks for a mute treatment.
```

## 📜 Reveal scroll — one continuous take
model: h3
tag: scroll
description: One continuous take where rough glowing hand-drawn lines living on a real surface wake up, morph through shared shapes, escape into the room and get chased by a hand-held camera that reacts a beat late. Surreal and playful, never horror.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 15
music: subtle
structure: single
camera: Auto
flows: CONTACT FIRST | MORPH CHAIN | ESCAPE ROUTE | CHASE DELAY
tip: Dynamic beats — the named contact points, morph steps and the escape opening become the beats. Name three morphs and the chain is three moves long; name one and the drawing simply wakes and flees.
idea: {SPACE — a real lived-in room with texture: tiled wall, wooden desk, steamed window, concrete floor} with {SURFACE — the surface the drawing lives on}; a rough glowing {MEDIUM — chalk, ink, marker} line touches the surface and becomes {FIGURE — the drawn thing: a creature, a hand, a fish, a key}, then morphs through {MORPHS — name each step, e.g. key → bird → door}, escaping into {EXIT — the real opening: a doorway, a drawer, a page, a screen}, the camera noticing a beat late.

```
integrated_multimodal_description: 16:9, 24fps, one continuous take, no cuts: a live-action {SPACE} shot hand-held, {LIGHT — practical window light with the room's own shadows}, real texture and imperfections kept, shallow but legible depth. The drawing is rough and glowing {MEDIUM}: uneven hand pressure, visible wobble, a few confident strokes, edges that bleed slightly into the paper of the surface — its glow lands on the real wall or table around it, and wherever the line touches real geometry it casts a soft contact shadow so the two worlds agree. BEAT ENGINE — one beat per NAMED element: CONTACT (the line arrives physically — drawn by a real hand, or the drawing pushing up out of the surface — and the surface responds: dust, a ripple, a lens of light) · DRAW (the {FIGURE} completes itself in three or four strokes, then looks around) · MORPH (each named step transforms through a shared shape — key to bird through the shaft, bird to door through the wing — one continuous morph per beat, the line never redrawing itself from scratch) · ESCAPE (it reaches {EXIT} and leaves through the real opening, the last stroke of it still visible as it goes) · CHASE (the camera notices it a beat late and swings after it hand-held, overshooting slightly, then the drawing turns to meet the lens). Skip any step that is not named; never add a second creature, a human face, a jump scare, gore, or a dark distorted figure — the tone stays curious and playful. Camera: hand-held, reactive, delayed — it is never already waiting; one continuous move with motion type + amplitude + speed and an end-state. TIMING: 15s total — about 5-7 beats, no beat longer than 3s, the last two seconds are the chase resolving into a held frame with the drawing still alive in the space.

overall_soundscape: real room tone with the drawing making its own small sounds — a chalk scratch, a dry ink crackle, a soft papery flutter as it moves — plus the room's physical sounds as the camera follows (a floorboard, fabric brushing, a breath close to the mic); no voices.

non_diegetic_music: {one sparse instrument — a plucked string, a music box, a low synth pulse} at a curious walking tempo, thin and playful under the contact beats, tightening with the chase and cutting out cleanly on the final held frame; or exactly N/A.
```

## 🎮 Co-op game intro — player cards & menu
model: h3
tag: game
description: Two-player game title screen: a fixed menu framework with two character cards, coordinated colour, icons and typography, the characters flanking the menu while the selection highlight glides and the cards settle. UI copy verbatim, legible and stable.
category: Animation
ratio: 9:16
resolution: 2K
duration: 8
music: beat
structure: multi2
camera: Auto
flows: PLAYER CARDS | CHARACTER FIRST | MENU LOCK-UP | VERSUS BEAT
tip: Dynamic beats — each named UI element (title bar, two player cards, a button, the highlight, a cursor token) becomes one beat. Name both characters and the intro reads as co-op, not solo.
idea: {GAME — genre and mood, e.g. a co-op dungeon crawler} title screen; player one {HERO A — silhouette, palette, one signature prop} and player two {HERO B — silhouette, palette, one signature prop}, their player cards reading "{CARD A — the exact words on the card}" and "{CARD B — the exact words on the second card}"; UI palette {PALETTE — e.g. deep indigo and warm amber}, typeface {TYPE — chunky rounded, slab, condensed}; the menu offers {BUTTONS — name the exact labels: "PLAY", "CO-OP", "SETTINGS"}.

```
integrated_multimodal_description: 9:16, 30fps, a stylised co-op game title screen: {RENDER — hand-painted 2D, cel-shaded 3D, pixel-art layered}, illustrated background depth behind a clean UI layer, {PALETTE — two coordinated colours with one accent}, {TYPE — chunky rounded, slab, condensed}, and soft rim light on both characters so their silhouettes separate from the background; the composition is a fixed menu framework: a title band, two player cards, a stacked button list, and a highlight bar. Both characters hold stable identity cues — silhouette, palette, and one signature prop each — and never swap costume, weapon or accent colour. BEAT ENGINE — one beat per NAMED UI element, in this order of assembly: TITLE (the title band lands first, type settling with a small overshoot) · CARDS (each player card slides in from its side and snaps flat, portrait, name, one stat; the exact words stay on screen and legible) · HEROES (each character steps into its own side of the frame and holds a signature pose, the card's colour matching its character) · CURSOR (the selection highlight glides down the button list and the hovered label reacts — a scale pop, a glow, a shove — the unselected labels dim) · PRESS (the highlight lands on {START LABEL — e.g. "PLAY"} and the frame answers the press with a weight shift, light bloom or a small screen shake). On-screen UI copy uses English double quotation marks VERBATIM, spelled exactly as given, in one typeface throughout, never wobbling, warping or re-spelling mid-clip; keep every label inside a safe margin and never repeat a label twice. Skip any element that is not named; never invent a third player, a scoreboard, a health bar or a studio logo. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the brief: the menu is the subject → PLAYER CARDS, the characters are the subject → CHARACTER FIRST, the UI moment is the payoff → MENU LOCK-UP, two rivals rather than partners → VERSUS BEAT. PLAYER CARDS = the two cards assemble first and the characters fill them. CHARACTER FIRST = both characters hold a beat, then the framework builds around them and the cards land beneath. MENU LOCK-UP = the camera pushes into the finished menu, every element already placed, the highlight doing the last beat. VERSUS BEAT = the two sides arrive on alternating beats and meet at the centre. Camera: one move per shot, motion type + amplitude + speed with an end-state; keep the UI plane square to the frame so labels stay readable. TIMING: 8s total — 5-6 stamped beats of about 1.5s, the highlight never held still for more than 2s, the closing second holds the finished menu fully readable. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: game-menu foley and UI voice — a soft whoosh as each card lands, a plastic click on the highlight move, a chunky confirm press, a low UI hum and a distant ambient loop from the game world behind the screen; no spoken dialogue.

non_diegetic_music: {game-theme bed — an 8-bit arpeggio, a brass fanfare, a synth pulse at N bpm}, building one layer per beat and resolving on the confirm press with a short tail; or exactly N/A for a cold, quiet title screen.
```

## 💇 Film-set meta hair spot — 20s chain (2 × 10s)
model: h3
tag: beauty
description: The "hair too perfect for the scene" ad: the talent is shooting a dramatic film scene, the director calls cut because their hair looks freshly salon-done for someone in distress, and the fiery rebuttal turns the complaint into the product. 20 seconds as two 10s chained clips — this template generates ONE of them, and the hair craft only fires on the details you actually name.
category: Commercial / Brand Film
ratio: 9:16
resolution: 2K
duration: 10
music: subtle
structure: multi2
camera: Auto
flows: CUT IS CALLED | MONOLOGUE FIRST | HAIR HERO END | TWO-PART SHOWDOWN
tip: 20s = two clips — run the 🔗 Story chain panel with 2 scenes × 10s: scene 1 is the film set and the director's complaint, scene 2 is the monologue and the hair/product finish. Paste your own lines so they stay verbatim, and give the director one signature mannerism — the comedy lives in his delivery, not in the hair.
idea: {BRAND} hair-care ad, scene {N — 1 or 2} of 2: {TALENT — age, hair length / texture / colour, one signature detail} is shooting a {SCENE BEING SHOT — e.g. a dramatic abduction scene} for director {DIRECTOR — build, wardrobe and one mannerism} when he calls "Cut!" — {THE COMPLAINT — e.g. your hair looks like you just walked out of a salon} — and she answers with {THE RETORT — her comeback line, delivered straight into the lens}. Product: {PRODUCT — the range and its single claim}. Dialogue language: {LANGUAGE}.
settings_note: Feed the previous clip's last frame as the first frame from scene 2 on, so the set, wardrobe, light and grade match at the join. The claim appears ONCE, at the very end, as on-screen text.

```
integrated_multimodal_description: Shot on {CAMERA + LENS}, 24fps, {GRADE — warm tungsten set light with cool monitor spill}. [Shot 1] {SET — a working film set: lights on stands, cables taped to the floor, a monitor on a cart, crew just out of frame}, {TALENT — age, hair length / texture / colour, one signature detail} mid-performance in {HER SCENE WARDROBE}, playing {SCENE BEING SHOT — e.g. a dramatic abduction scene}; her hair is {HAIR STATE — freshly styled, glossy, every strand in place}, which is the joke. [Shot 2] At the cut the live clock sets, the camera cuts to {DIRECTOR — build, wardrobe and one mannerism}, who lowers his hand from the clap, unimpressed, and says, <d>[{LANGUAGE}] {DIRECTOR'S LINE — e.g. Cut!}</d> and then <d>[{LANGUAGE}] {THE COMPLAINT — e.g. your hair looks like you just walked out of a salon}</d>, his one signature mannerism riding the line (pushing his glasses up with a knuckle, pointing at the AD's genuinely messy hair). [Shot 3] At the cut the live clock sets, the camera cuts tight to {TALENT — age, hair length / texture / colour, one signature detail}: {THE REACTION — the intake of breath before she speaks}, her chin lifting, {HAIR DETAIL — e.g. one strand falling forward and being swept back} as she begins {THE RETORT — her comeback line, delivered straight into the lens}. HAIR ENGINE — the hair is the hero product, so write only the hair details you actually named, each as a physical beat: GLOSS (a soft highlight travelling along the curve of the hair as she turns — specular, not glitter: the light source is visible in the sheen) · FLUIDITY (the mass of hair moving as one weight with strand separation at the ends, lagging a beat behind her head — never stiff, never floating) · FLIP (a single decisive sweep that travels and settles, a few strands landing last) · WIND (one fan pass lifts the hair and lets it fall back into place) · MACRO (a close pass across the strands where individual fibres, cuticle sheen and light refraction are legible) · PRODUCT (hands lift the {PRODUCT — the range and its single claim} bottle into frame, squeeze, and the texture of the formula reads — thick, silky, catching light). Skip any detail that is not named; never make the hair supernatural, never add sparks, glitter or lens-flare gimmicks. PERFORMANCE — the director plays annoyance, never cruelty, and the talent never whines: her retort is confident and amused, the smile arriving after the line. The claim appears exactly once, at the very end, as on-screen text in English double quotation marks VERBATIM: "{CLAIM — e.g. 100 HOURS OF HYDRATION}". No other text, no logos on screen. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: the joke is the cut → CUT IS CALLED, the comeback is the whole spot → MONOLOGUE FIRST, the hair is the payoff → HAIR HERO END, both of them trade lines → TWO-PART SHOWDOWN. CUT IS CALLED = performance → cut → complaint → her reaction, in that order, the director's line landing on the cut. MONOLOGUE FIRST = open on her mid-retort, then cut back into the set so the audience catches up. HAIR HERO END = the set plays shorter and the last three beats are hair, hair, product. TWO-PART SHOWDOWN = shot / reverse-shot lines, alternating, tightening one size each return. TIMING: 10s total — 3-4 stamped beats of about 2s, the cut landing before the halfway mark, the closing beat either her final line or the product hero — never both crowded together. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: a live set bed — the clap-board, cables and stands shifting, crew murmur and a distant fan, {TAKE SOUNDS — e.g. a breath, fabric, a scuff on the floor} under the take, then the set going quiet for the director's verdict; a single wind-machine gust if WIND is named. No music here.

non_diegetic_music: {SCORE BED — e.g. a light percussive tick, a plucked string} at a mid tempo, dropping out completely for the director's line so the comedy plays dry, and returning with a lift under the retort into the product hero; or exactly N/A if the dialogue should carry it alone.
```


## 🐮 Topical mascot cartoon — pun tagline ad
model: h3
tag: mascot
description: The topical cartoon-ad format: a hand-drawn mascot reacts to one current event, the prop does the joke, and a short punning line lands on screen while the brand device winks in the last beat. Flat ink-and-fill 2D, limited animation, one idea only.
category: Animation
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
flows: REACTION FIRST | GAG BUILD | PUN LANDING | PRODUCT WINK
tip: Dynamic beats — name the event, the prop and the pun: each becomes a beat. Leave the pun out and the spot plays as a silent gag; keep the line to 3-6 words so it lands before the clip ends.
idea: {MASCOT — the mascot: age, hair, one costume detail, drawn in the same hand throughout} reacts to {THE TOPIC — the current event, e.g. a monsoon downpour, a cricket final, a heatwave} at {SETTING — one location drawn in the mascot's flat 2D world}, working {PROP — the single prop that carries the gag}; the on-screen line reads "{PUN — 3-6 words, the on-screen line}"; the brand device {BRAND DEVICE — the pack, board or badge that appears at the end} closes the ad. Drawn in {PALETTE — the drawn palette, e.g. three flat colours on cream paper}.

```
integrated_multimodal_description: Hand-drawn 2D cartoon, vertical 9:16, 24fps: bold uneven ink outlines with visible line-weight variation, flat poster fills, {PALETTE — the drawn palette, e.g. three flat colours on cream paper}, and the mascot's own colour running through every frame; the world is drawn in flat shapes with no perspective drift, lit graphically with hard shadow blocks and no gradients, no rendered volume, no camera moves other than one graphic slide. The mascot is {MASCOT — the mascot: age, hair, one costume detail, drawn in the same hand throughout} — always readable and front-facing, same eye shape, same hair silhouette, no proportional drift between beats. BEAT ENGINE — one beat per NAMED element, in this order: SETUP (the setting states the event in one graphic image, the prop already in frame) · ESCALATION (the reaction grows in two visible steps — eyebrows first, then the whole body, while the event asserts itself around them) · GAG (the prop does the joke: it acts on the mascot, the mascot answers it) · LINE (the pun appears as on-screen text and holds while nothing moves but one small mascot beat) · WINK (the brand device enters with a single pop or slide and settles into a corner). Skip any beat whose element is not named; never add a second character, a logo wall, a caption block or a sponsor line. On-screen text uses English double quotation marks VERBATIM, one line only, drawn in the same inked style, kept clear of the mascot's face. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the idea: the event is the joke → REACTION FIRST, the prop is the joke → GAG BUILD, the line is the whole ad → PUN LANDING, the brand must be the last beat → PRODUCT WINK. REACTION FIRST = the event already happening at frame one, the mascot reacting into it. GAG BUILD = prop, then mascot, then line. PUN LANDING = the frame holds the mascot still, the text lands, one eyebrow answers it. PRODUCT WINK = the gag resolves early so the final second belongs to the brand device. Motion is limited-animation: hold, then snap to the next drawing — never smooth interpolation. TIMING: 8s total — 4-5 beats of about 1.5s, the pun on screen for the final 2s, the brand device in the last beat.

overall_soundscape: drawn-world foley, dry and close with no reverb — the event's own sound (rain on sheet metal, a stadium roar swelling, a fan whirring), the prop's sound (a lid popping, a page turning, a glass clinking), and one mascot sound (a hum, a sigh, a slurp). No voices here.

non_diegetic_music: one instrument running the joke — a plucked ukulele, a two-step piano or a whistle at a walking tempo, with a single sting landing exactly on the pun; or exactly N/A when the drawn sound should carry it alone.
```

## 🧸 CG character short — twist ending
model: h3
tag: cg
description: The wordless CG story spot: one character, one want, one obstacle, and a twist ending that turns the whole clip — the brand enters only in the final beat. Stylised 3D with soft global light, real fur or cloth simulation and cinematic depth of field.
category: Animation
ratio: 16:9
resolution: 2K
duration: 15
music: subtle
structure: multi2
camera: Auto
flows: WANT AND TWIST | COLD OPEN ON THE TWIST | FAIL TWICE WIN ONCE | TWO CHARACTERS MEET
tip: Dynamic beats — the story is only as long as the beats you name: want, obstacle, reaction, twist. Leave the twist unnamed and the clip plays as a straight product demo; name how many failures come before the win.
idea: A stylised 3D CG short: {CHARACTER — species, build, one silhouette signature; never a real person} wants {WANT — the one thing they are trying to reach or do} but {OBSTACLE — the physical thing in the way}, failing {FAILURES — how many times, e.g. twice} before {TWIST — the turn that changes the outcome}; the brand enters only here: {BRAND BEAT — the product used naturally in the last moment}. Set in {WORLD — the miniature or everyday world, its scale and one landmark}.

```
integrated_multimodal_description: Stylised 3D CG, 16:9, 24fps: {RENDER LOOK — e.g. soft-sculpted characters, matte materials, simulated fur or cloth}, {LIGHT — one big soft key with global bounce and a warm practical in frame}, shallow depth of field with a legible focal plane, gentle lens breathing, and a graded palette of {PALETTE — three coordinated colours}. Scale is the whole joke: the world reads miniature and handmade but with real mass — cloth folds, dust, condensation, a surface that dents. {CHARACTER — species, build, one silhouette signature; never a real person} holds the same proportion, colour and material in every shot; there is no dialogue and no lip-sync anywhere — the story is told through posture, eye direction and breath. BEAT ENGINE — one beat per NAMED story element: WANT (the character reaches for {WANT — the one thing they are trying to reach or do}, eyes arriving before the hands) · OBSTACLE (the block acts physically: it moves, resists, or takes more than it gives) · FAILURE (one distinct failed attempt per named failure — each with its own physics and its own recovery, never the same gag twice) · REACTION (the small human beat between attempts: a sigh that moves the whole body, a look to camera, a shoulder drop) · TWIST (the turn that changes the meaning of everything before it — the obstacle was the help, the want was the wrong thing, the character was not alone) · BRAND (the product appears in the last moment, used naturally by the character, in focus, never floating). Keep the brand beat's first appearance inside the final three seconds; invent no second character unless the flow calls for one. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: an emotional arc → WANT AND TWIST, a punchy short cut → COLD OPEN ON THE TWIST, comedy by repetition → FAIL TWICE WIN ONCE, a relationship story → TWO CHARACTERS MEET. WANT AND TWIST = linear real-time, the twist landing in the last third. COLD OPEN ON THE TWIST = the reveal plays first, the explanation follows. FAIL TWICE WIN ONCE = escalating attempts, the third inventing the solution. TWO CHARACTERS MEET = the obstacle belongs to a second character and the twist is the handshake. One motivated camera move or a static frame per shot — never a showcase orbit; cut only when new story information arrives. TIMING: 15s total — 5-6 beats of about 2.5s, each failure shorter than the one before, the twist no longer than 3s, the brand beat the final 2s.

overall_soundscape: miniature-scale foley recorded close — the character's breath and footfalls, the obstacle's material (paper skidding, metal ticking, jelly wobbling), room tone with one distant world sound behind it; no speech, no laughter, no voices.

non_diegetic_music: {small ensemble — strings and a music box, a marimba duo, a single cello line} at {TEMPO} bpm, following the character beat by beat, thinning to one instrument through the twist and lifting softly under the brand beat; or exactly N/A for a silence-cut comedy.
```

## 🪆 Claymation mascot product spot
model: h3
tag: claymation
description: Handmade stop-motion product spot: a plasticine mascot in a miniature practical set demonstrates the product in one continuous bit of business. Fingerprints, armature seams and thumb marks stay visible, and the motion runs on stop-motion holds and snaps, not interpolation.
category: Animation
ratio: 16:9
resolution: 2K
duration: 10
music: beat
structure: single
camera: Auto
flows: CRAFT FIRST | MASCOT DEMO | SET TOUR | TINY DISASTER
tip: Dynamic beats — name the mascot's one bit of business and the set details you want: each becomes a beat. Leave the disaster unnamed and the spot stays a clean demo; name it and the mascot fumbles, then recovers.
idea: A plasticine {MASCOT — build, colour and one hand-made detail, e.g. wonky ears, a knitted scarf} demonstrates {PRODUCT — the object, its material and the one claim} inside {SET — the miniature practical set, with two hand-made details}, doing {BUSINESS — the one continuous bit of business, e.g. squeezing a dollop onto a tiny counter and tasting it}.

```
integrated_multimodal_description: Handmade stop-motion claymation, 16:9, 24fps with a two-frame cadence: visible thumbprints, tool marks, dust specks and armature seams on every surface; plasticine with a matte, slightly oily sheen; cloth that is stiff and fine at model scale; warm practical light with a hard key, a soft fill, gentle falloff and real contact shadows; the set is miniature and constructed — seams in the walls, flocked ground, a painted sky — and the frame is deep enough to read foreground props and background set at once. {MASCOT — build, colour and one hand-made detail, e.g. wonky ears, a knitted scarf} keeps the same shape and wear marks in every shot. BEAT ENGINE — one beat per NAMED element: ENTRANCE (the mascot arrives with weight — a real step, the set registering the footfall) · PICK-UP (the mascot handles {PRODUCT — the object, its material and the one claim} and the material answers: it squashes, tips, clicks, pours) · DEMO (the one continuous bit of business, in the smallest number of cuts possible — hands, product and reaction all visible) · REACTION (the whole body answers what happened, including a small wobble or a blink) · DISASTER (only if named: one clean mishap with real consequences in the set, then a recovery inside the same beat) · PACKSHOT (the product alone in the miniature set for the final moment, label square to the lens, in focus). Invent no third character, and no claim beyond the one named; any text uses English double quotation marks VERBATIM and stays on the pack, never floating. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: the product is the point → MASCOT DEMO, the making is the charm → CRAFT FIRST, the world is the charm → SET TOUR, comedy → TINY DISASTER. CRAFT FIRST = open on the workshop hands and materials before the mascot arrives. MASCOT DEMO = straight into the business, the set already dressed. SET TOUR = the camera leads through the miniature world and the product is discovered. TINY DISASTER = the mishap lands mid-clip and the recovery sells the claim. Motion law: everything moves on holds and snaps — no smooth morphs, no digital drift, no floating objects; clay and cloth keep their stiff handmade weight. TIMING: 10s total — 4-5 beats of about 2s, one continuous demo beat rather than many small cuts, the packshot holding the final 1.5s.

overall_soundscape: close practical foley mixed dry — the mascot's footfall on the set surface, the product's material sound (a lid seating, a squeeze, a crinkle, a pour), one small set creak, and quiet room tone recorded near the floor; no voices, no crowd, no reverb tail.

non_diegetic_music: {toy-instrument score — a glockenspiel, a ukulele, a brushed snare and a woodblock} at {TEMPO} bpm, ticking with the stop-motion cadence and stopping dead for one beat on the product's squeeze before returning under the packshot; or exactly N/A.
```

## 📺 Retro cel jingle ad — 1950s cartoon
model: h3
tag: retro
description: Golden-age television cartoon ad: hand-inked cels with visible registration wobble, limited animation, a sung jingle whose lyric appears on screen verbatim, wipe transitions and a painted packshot finale. Flat vintage colour, cel grain, optical-printing imperfection.
category: Animation
ratio: 4:3
resolution: 2K
duration: 10
music: full
structure: single
camera: Static shot
flows: JINGLE HOOK | CALL AND RESPONSE | PRODUCT PARADE | PACKSHOT FINALE
tip: Dynamic beats — every named verse of the jingle becomes one beat, and each named product feature gets its own gag. Fewer two-word lines keep it a real 50s jingle; a longer chorus makes the ad a musical number.
idea: A 1950s-style cel-animated ad for {PRODUCT — what it is and what it does, in plain words}: {CHARACTER — the cartoon animal or kid mascot, drawn in the house style} sings "{JINGLE VERSE — one lyric line}", the chorus answers "{JINGLE CHORUS — the repeated hook line}", and the ad ends on {PACKSHOT — the tin, bottle or box shown off in the painted setting}.

```
integrated_multimodal_description: Hand-inked 2D cel animation in a golden-age television style, 4:3, 24fps: flat painted colour with slight cel-to-cel registration wobble, soft uneven line weight, a matte painted background with no gradients, dust and a fine film grain, faint colour fringing on the edges and a warm slightly faded palette; no modern lens effects, no bloom, no vignette, no camera movement beyond a straight push or a single pan. {CHARACTER — the cartoon animal or kid mascot, drawn in the house style} keeps the same oval eyes, the same four-fingered hands and the same silhouette in every cel. BEAT ENGINE — one beat per NAMED element: HOOK (the character bursts into frame already singing — mouth shapes are broad and held, the lyric appearing on screen as painted title card text) · GAG (each named product feature animates as its own visual joke: the product doing the thing it claims, drawn as exaggeration, with rubber-hose limbs and squash-and-stretch) · CHORUS (the lyric repeats and the frame answers it — a chorus of small characters, a shower of stars, a spinning product, all rendered in the same flat cel style) · WIPE (each change of idea is a hard graphic wipe: an iris, a bar-wipe, a star wipe — never a soft dissolve) · PACKSHOT ({PACKSHOT — the tin, bottle or box shown off in the painted setting} holds centre frame with the product name painted beneath it, unmoving, while the jingle resolves). Any on-screen lyric uses English double quotation marks VERBATIM, one short line at a time, in the painted card style; never add a modern logo animation, a lower-third or a legal line. Singing uses official markup: <d>[English] {"{JINGLE VERSE — one lyric line}"}</d> on the verse and <d>[English] {"{JINGLE CHORUS — the repeated hook line}"}</d> on the chorus, with the same singer (S1) throughout. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: the song is the whole ad → JINGLE HOOK, two voices trade lines → CALL AND RESPONSE, the product is shown many ways → PRODUCT PARADE, the reveal is the payoff → PACKSHOT FINALE. JINGLE HOOK = the verse opens cold, the hook lands twice. CALL AND RESPONSE = the mascot sings a line and the chorus answers, alternating, one gag per trade. PRODUCT PARADE = the product appears in a new painted setting on each beat, the lyric naming each use. PACKSHOT FINALE = the gags run fast and the last two beats belong to the packshot with the jingle resolving underneath. TIMING: 10s total — 4-5 beats of about 2s, the hook said twice, the packshot holding the final 2s with the last line of the jingle still audible.

overall_soundscape: a mono, mid-century sound bed — the mascot's rubber-hose footsteps and a boing on every take, a slide whistle on the gags, the product's thumb-piano-ish ping, and a quiet studio room tone at the very end; the sung jingle belongs to the music field, so no voices are written here beyond the singing.

non_diegetic_music: the ad's own jingle — {small studio band: upright bass, brush kit, a two-part vocal harmony, a muted trumpet} at {TEMPO} bpm, verse and chorus alternating, ending on a resolved cadence under the packshot with the last line spoken rhythmically rather than sung; never exactly N/A, this format is a song.
```

## 🎌 Anime-style product spot
model: h3
tag: anime
description: The Japanese-style animated product film: a hand-painted sky, soft bloom and a small emotional beat around one product moment. Cel-shaded characters with expressive eyes, light that changes between shots, and a quiet voice-over line instead of a sales pitch.
category: Commercial / Brand Film
ratio: 16:9
resolution: 2K
duration: 12
music: subtle
structure: multi2
camera: Auto
flows: QUIET MOMENT | SEASONAL ARC | MAKER'S HANDS | PRODUCT HERO BEAT
tip: Dynamic beats — name the emotional beat (a reunion, a first day, a goodbye) and the product moment separately: each becomes one beat. Leave the voice-over unnamed and the spot stays wordless; name it and it carries the line.
idea: An anime-style spot: {CHARACTER — age, hair, one signature outfit detail, drawn in a cel-shaded style} in {PLACE — the location and the time of day, hand-painted} has {EMOTION BEAT — the small human moment, e.g. arriving home after a long day}, and the product arrives as {PRODUCT MOMENT — how the product enters the moment}; optional voice-over: "{VO LINE — one short line, in the character's own voice}".

```
integrated_multimodal_description: Cel-shaded anime, 16:9, 24fps: hand-painted backgrounds with visible brushwork and soft atmospheric perspective, characters with clean line art, two-tone cel shading and deliberately expressive eyes; light is painted and it CHANGES between shots — morning bloom through a window, the golden hour edge on hair, blue hour in the street, practical warmth indoors; layered depth with a hazy far distance, light streaks, stray petals or dust through the beam, subtle chromatic warmth in the highlights, and no photoreal rendering, no 3D-looking materials, no film-grain grunge. {CHARACTER — age, hair, one signature outfit detail, drawn in a cel-shaded style} keeps identical eye shape, hair shape and palette across every shot. BEAT ENGINE — one beat per NAMED element: ESTABLISH (the place as a painting — one landscape or interior beat with nobody in it, or the character small in frame) · LOOK (a close beat on the character: eyes, breath, a hand touching something — held long enough to read) · EMOTION (the named human moment arrives in the body, not in words: the shoulders drop, the eyes widen, a smile is decided rather than shown) · PRODUCT ({PRODUCT MOMENT — how the product enters the moment}: the product is handled naturally, in focus, with the light catching it, and the frame gives it one clear moment) · RELEASE (the last beat opens the frame back up — sky, window, street — while the feeling settles). Any spoken line uses the official markup <d>[Japanese] {"{VO LINE — one short line, in the character's own voice}"}</d> if a voice-over is named; deliver it as "says in an off-screen voiceover" with the lips remaining completely closed on screen, and never write a sales claim as dialogue. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: an internal moment → QUIET MOMENT, time passing → SEASONAL ARC, craft or food made by hand → MAKER'S HANDS, the product is the whole story → PRODUCT HERO BEAT. QUIET MOMENT = one location, the camera slowly moving in on the feeling. SEASONAL ARC = two or three time-of-day or season states in sequence, the light doing the storytelling. MAKER'S HANDS = insert beats on hands, ingredients and tools, the product emerging from the work. PRODUCT HERO BEAT = the product is introduced in a held hero frame with the light at its best, then the character responds to it. Camera is slow, patient and deliberate — one considered move per shot with an end-state; never a fast whip or a showy orbit. TIMING: 12s total — 5 beats of about 2.5s, the product moment no longer than 3s, the final beat holding on the character's settled feeling rather than on the pack.

overall_soundscape: intimate real-world bed — a room tone with one distant sign of life (traffic, cicadas, a kettle, a train), cloth and foot movements, breath and a small swallow at the closest beat, the product's material sound when it is handled; voices only as the named voice-over, kept off screen.

non_diegetic_music: {piano and strings, or a single koto and a soft pad} at a slow {TEMPO} bpm, one theme building in small steps across the beats, thinning to a single instrument under the emotional beat and resolving gently on the release; or exactly N/A if the room should carry the clip.
```

## 🍬 Anthropomorphic product characters — comedy spot
model: h3
tag: toon
description: The product-as-character ad: the product itself has a face, feet and a mouth, bickers with the others in the pack, and settles the argument by being exactly what it is. Squash-and-stretch CG comedy with a clean tabletop world and a punchline in the last line.
category: Animation
ratio: 16:9
resolution: 2K
duration: 10
music: beat
structure: multi3
camera: Auto
flows: PACK BICKERING | NEWCOMER ARRIVES | CHALLENGE AND WIN | SPLIT-SCREEN STANDOFF
tip: Dynamic beats — each named character's line is one beat and each named trait is one gag. Two characters make a sketch; four make a crowd scene with a competing rhythm. Name the punchline, or the spot ends on a shrug.
idea: {PRODUCT — the product, its shape and colour, now with a face, feet and hands} meets {OTHERS — the other product characters in the pack, each with one strong personality trait} on {SURFACE — the tabletop or shelf they live on}; they trade lines — "{LINE 1 — the first character's line}" then "{LINE 2 — the answering line}" — until the punchline "{PUNCHLINE — the closing line, 3-8 words}" settles it.

```
integrated_multimodal_description: Stylised CG comedy, 16:9, 24fps: the product is a character — {PRODUCT — the product, its shape and colour, now with a face, feet and hands} with real materials rendered cleanly (glossy label, matte cap, textured wrapper), two expressive eyes and a working mouth, and simple rubber-hose limbs with squash-and-stretch on every take; the world is a clean tabletop or shelf at product scale — a few props at the right size, no human hands in frame; lighting is bright, even and commercial with a soft key, a defined shadow under each character and a gentle specular on every label, and the palette is {PALETTE — three coordinated colours}. Every character keeps a stable face rig, the same label wording and the same colour through all shots — nothing about the pack changes except expression and pose. BEAT ENGINE — one beat per NAMED element: REVEAL (each named character is introduced doing one characteristic thing, its trait readable in a single gesture) · LINE (each named line is delivered with a held mouth shape, brows and a tiny body lean — the speaking character gets the frame, the others react) · GAG (each named trait animates as its own physical bit: the tall one leans too far, the small one gets squashed, the shiny one is blinded by its own label) · SETTLE (the punchline lands, everyone freezes for one beat, then the winning product gives the tiniest nod) · PACK (the winning product alone in frame, label legible, one soft light sweep across it). Dialogue uses the official markup with stable speaker IDs — <d>[English] {"{LINE 1 — the first character's line}"}</d> is (S1), <d>[English] {"{LINE 2 — the answering line}"}</d> is (S2), and the punchline "{PUNCHLINE — the closing line, 3-8 words}" stays in English double quotation marks VERBATIM with the winning character (S1) delivering it. Never use brands or characters from real advertisements: the pack is whatever the user names. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: a dialogue sketch → PACK BICKERING, an introduction → NEWCOMER ARRIVES, a claim to prove → CHALLENGE AND WIN, two sides only → SPLIT-SCREEN STANDOFF. PACK BICKERING = the established characters argue until the newcomer ends it. NEWCOMER ARRIVES = the spot opens on the regulars and the new product walks in. CHALLENGE AND WIN = each character attempts the named task and fails until the hero succeeds. SPLIT-SCREEN STANDOFF = two characters face off across a split frame, each line tightening the framing. Camera is one small motivated move per shot at product height, never a wide human-eye view. TIMING: 10s total — 5 beats of about 2s, one line per beat, the punchline in the final 2s followed by the pack beat.

overall_soundscape: tabletop foley at product scale, dry and crisp — the little feet on the shelf, a cap being twisted, a wrapper crinkling, a plastic tap when someone is flicked, and a quiet room tone behind; the spoken lines carry the scene, so nothing else is written here.

non_diegetic_music: {comedic bed — a pizzicato bass, a tuba, a muted trumpet and light brushes} at {TEMPO} bpm, punctuating each line with a short sting, dropping out completely on the punchline so the last line plays dry, then one clean hit under the pack beat; or exactly N/A.
```

## 🎨 Artist & muse — period sketch session
model: h3
tag: artist
description: The reclining-portrait session: an artist sketches a subject holding a pose by lamplight in a period room, and the tension is the held gaze plus the hand. One continuous take — the drawing craft only fires on the details you name, and the page never tries to be legible art.
category: Cinematic Film Scene
ratio: 16:9
resolution: 2K
duration: 12
music: subtle
structure: single
camera: Push in
flows: MUSE FIRST | HAND AND PAGE | GAZE LOCK | REVEAL THE PAGE
tip: Dynamic beats — name the details you want (the jewel, the fabric, the graphite, the hand) and each becomes a beat; leave one out and it vanishes. Keep it one take: any timecode here would be a different template.
idea: {ARTIST — age, build, one wardrobe detail, hands that read} sketches {SUBJECT — 20-32 unless specified: age, hair, one feature} holding {POSE — the pose, held still} and wrapped in {FABRIC — the drape or robe and how it falls} in {ROOM — the period room: era, furniture, one lamp, one window}; the jewel at {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing}'s throat is {JEWEL — the piece and how it catches light}; the artist works in {MEDIUM — charcoal / graphite / conte, on paper}, saying only <d>[{LANGUAGE}] {ARTIST'S LINE — 2-4 words, e.g. Hold your gaze on me.}</d>.

```
integrated_multimodal_description: Shot on {CAMERA + LENS — e.g. a 40mm anamorphic on 35mm film}, 16:9, 24fps, {ERA — the period, e.g. 1912, first-class passenger cabin}: warm lamp practical as the key, a soft window fill grazing the subject's shoulder, deep falloff into the panelled wall, one hard edge of light catching the jewel, and a graded palette of {PALETTE — e.g. amber, oxblood, cold blue in the shadows}; fine film grain, gentle halation on the lamp, shallow-but-legible depth of field with the near foreground soft. ONE CONTINUOUS TAKE, no cuts: the camera pushes in slowly with small amplitude at a steady speed, arriving at the hands and holding there. BEAT ENGINE — write only the NAMED details, one beat each: THE POSE (the subject settles and holds — breath moving the drape, one small adjustment of weight, the head turning a degree and stopping) · THE GAZE (eyes fixed on the artist, blinking slowly, the look never leaving — the tension of being watched while being drawn) · THE HAND (wrist pivoting from the elbow, knuckles rolling, the tool meeting the paper in short strokes; graphite dust and a faint smudge on the side of the hand) · THE PAGE (the marks read as tone and mass from an angle — a soft haze of shading, a clear dark accent — never as legible portraiture, never as a finished face) · THE JEWEL (a small specular travelling along the stone and the chain as the chest rises, one bright point against the low-key room) · THE FABRIC (drape sliding a centimetre as the subject shifts, folds answering, the fabric holding its weight) · THE ROOM (the period truth around them: a lamp's slow flicker, the ship's faint vibration through a glass, a curtain breathing at the porthole). Sequence them so the take has one arc: the pose holds, the hand works, the gaze never breaks, and the last beat resolves the drawing or the look. Guard: no on-screen text, no camera equipment visible, no crew, no modern objects, no audience, no cutaway, no second person unless named, and the paper never shows readable words or a recognisable face. Sound design lives in the fields below; speech appears exactly once, in the official markup, and never anywhere else. TIMING: 12s total — one continuous take of 6-7 beats of about 1.5s, the hand working for the middle third, the gaze unbroken throughout, and the final beat a settled hold that resolves the tension.

overall_soundscape: the room at its real level — the tool scratching on paper in irregular short strokes, paper shifting once, the subject's quiet breath, a small creak in the woodwork, and a low continuous engine hum felt more than heard. No speech here, no music.

non_diegetic_music: {one instrument — solo piano, a low string line, a single sustained cello} at a slow tempo with a simple rising figure, thinning to a single held note under the final beat; or exactly N/A so the pencil scratch carries it.
```

## 🖋️ The same session — 1912, in two shots
model: h3
tag: artist
description: The two-shot cut of the sketch session: a wide that seats the room and the pose, then a tight on the hand and page — for when you want the drawing craft readable inside a shorter clip.
category: Cinematic Film Scene
ratio: 9:16
resolution: 2K
duration: 10
music: subtle
structure: multi2
camera: Auto
flows: WIDE THEN TIGHT | TIGHT FIRST | POSE TO PAGE | GAZE TO HAND
tip: 10s, two shots: the wide seats the room and the subject, the tight lives on the hand and the page. Name the jewel and the fabric and both get their own beat in the wide.
idea: {ARTIST} draws {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} holding {POSE} in {ROOM} by lamplight; the medium is {MEDIUM}, {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} is wrapped in {FABRIC} with {JEWEL} at the throat, and the artist's only words are <d>[{LANGUAGE}] {ARTIST'S LINE}</d>.

```
integrated_multimodal_description: Shot on {CAMERA + LENS}, vertical 9:16, 24fps, {ERA} period truth: warm lamp practical key, window fill, deep shadows, one hard specular on the jewel, fine grain and halation, shallow depth with the near foreground soft; palette of {PALETTE}. [Shot 1] The room seats the scene — {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} reclining and holding {POSE} in {FABRIC}, the jewel catching the lamp, {ARTIST} at the easel side-on with the paper angled away from camera; the camera holds and drifts slightly, no cut yet. [Shot 2] At the cut the live clock sets, the camera cuts tight to the hand and the page: {MEDIUM} meeting paper in short strokes, knuckle shadows and graphite dust, the marks reading as tone and mass — and the artist speaks once, <d>[{LANGUAGE}] {ARTIST'S LINE}</d>, while the subject's breath moves the drape in the background. Guard: marks stay illegible as portraiture, no readable words anywhere, no crew, no modern objects, no third person. TIMING: 10s total — wide 0-5s (2 beats: the pose settling, the jewel catching light), tight 5-10s (2 beats: the hand working, the held gaze landing), the last second a still hold. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: tool on paper in short irregular strokes, the subject's quiet breath and one fabric shift, woodwork creaking, a low engine hum under everything. No speech here.

non_diegetic_music: {solo piano or a single low string} at a slow tempo, one rising figure across the cut, easing on the final hold; or exactly N/A.
```

## Room photo shoot — every dimension dynamic
model: h3
tag: fashion
description: ONE room, ONE look, and EIGHT live dimensions — location, model, clothing, movement, presentation, action, interaction and camera. Nothing is fixed except the format: fill a field and it becomes a beat, leave it blank and it disappears. Variants draw a different option from every pool.
category: Fashion / Lifestyle
ratio: 16:9
resolution: 2K
duration: 8
music: subtle
structure: multi3
camera: Auto
flows: ENTER AND SETTLE | LIGHT FIRST | WALL WORK | SEATED FRAME
vary: OUTFIT DESIGN | OUTFIT COLOUR | MODEL | MOVEMENT | PRESENTATION | ACTION | OUTFIT INTERACTION | LOCATION | CAMERA | RHYTHM ENVELOPE | SCALE LADDER | CUT MOTIVATION | FRAMING DEVICE | OPEN DEVICE | CLOSE DEVICE | TRANSITION | SOUND FORMAT
tip: The blank slate: eight fields, no fixed beats. Fill them yourself or leave them 🧩 and let the app propose values — every field you fill becomes a beat, nothing is invented for you. One room only (name its light source, its floor and one landmark). Run 2-4 variants and each one draws a different option from every pool (public/prompts/fashion-variation.md), so two variants never share a room, a woman, a garment, a movement or a camera. For a whole shoot across rooms, chain templates instead (Templates page → 🔗 Chain mode).
idea: {OUTFIT DESIGN — the garment: silhouette, fabric, construction detail} in {OUTFIT COLOUR — colour family and finish} worn by {MODEL — 20-32 unless specified: age, hair, skin, build}, moving with a {MOVEMENT — gait, tempo, footwork, where the weight lands} and a {PRESENTATION — how she carries herself} presence, {ACTION — the physical action of the clip} while {OUTFIT INTERACTION — what her hands do with the garment}, photographed in {LOCATION — the one room: its light source, floor and one landmark}, shot as {CAMERA — the lens and the move}.

```
integrated_multimodal_description: Shot on {CAMERA — lens, move and medium: body, focal length, speed, and the end-state it settles on}, 24fps, a clean neutral grade with no stylised filter. THE ROOM IS THE SECOND SUBJECT: {LOCATION — the one room: its light source, floor and one landmark}. Name the light before anything moves and let it do the shaping — a hard window shaft laying a bright bar across the floor and one wall, a soft top-light box making a clean pool, warm bounce off a coloured wall holding her edge, or a vertical strip practical edging her silhouette. One room, one light design, no location change anywhere in the clip — the camera may turn, but the set does not move. {MODEL — 20-32 unless specified: age, hair, skin, build} keeps identical features, hair and skin tone throughout, and {OUTFIT DESIGN — the garment: silhouette, fabric, COLOUR and construction detail} keeps the same cut, fabric weight and colour ({OUTFIT COLOUR — the same colour in every shot}) in every shot — describe it once with its colour named, then call it "the same knit / the same coat". NEVER leave the garment colourless — white, ivory and cream are choices the user makes, never the model's default. BEAT ENGINE — one beat per NAMED dimension, in physical order: ENTRY (she steps into the light's bar and settles, full body, weight landing) · PRESENTATION ({PRESENTATION — how she carries herself}: posture, gaze direction, and the stillness before she moves) · MOVEMENT ({MOVEMENT — how she travels through the room: gait, tempo, footwork, the landing of the weight}, written as a rhythm the camera can follow — the fabric answers it, hems lagging, sleeves swinging, a coat flaring on the turn and settling late) · ACTION ({ACTION — the physical action}, written as a chain of small physical events, not one gesture) · INTERACTION ({OUTFIT INTERACTION — what her hands do with the garment}: the fabric answers the hand — it gathers, releases, swings, settles late) · TEXTURE (ONE faceless insert — a macro on the garment's weave, seam, hardware or hem in raking light, or the back of her head with the hair falling; no second face, no product card) · CAMERA ({CAMERA — the lens and the move}: one motivated move with amplitude, speed and an end-state; the framing changes on the beat, not at random). FACE LEGIBILITY: never resolve this look only in a full-body wide — the room establishes, then the coverage tightens to medium or close before the end, and the render stays at 2K so the face survives the distance. Skip any dimension that is not named; never invent a second garment, a second model or a smile to camera. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise pick by the material: a walk-in story → ENTER AND SETTLE, a light-led room → LIGHT FIRST, tailoring and attitude → WALL WORK, a calm portrait-led look → SEATED FRAME. ENTER AND SETTLE = she comes in through the light, crosses, and settles on her mark as the frame tightens. LIGHT FIRST = the clip opens on the empty lit room, she enters and the light closes on her. WALL WORK = she works the wall — lean, shoulder roll, push off — with the room's light raking across the fabric. SEATED FRAME = she takes a seat in the room (ledge, step, chair) and the beats resolve into stillness with the garment spread. TIMING: 8s total — 3 stamped shots of about 2.5s, one new visible act every 1-1.5s inside them, no action held longer than 2s, and the final second a settled hold with the light unbroken.

overall_soundscape: {ROOM TONE — this one room's own layer: room tone, a street through glass, an echo off bare walls}, fabric moving through air, footsteps on this room’s floor surface, and no speech.

non_diegetic_music: {one rhythmic bed — a sparse percussive loop or a low synth pulse} at a steady tempo that follows the beats, or exactly N/A for pure editorial silence.
```

## Photo-shoot tour chain — same model, many rooms
model: h3
tag: fashion
description: The chain recipe: ONE template that runs as a linked photo shoot across rooms — the same woman, a new room and a completely new look in every scene, cut together like a campaign film. Send it from the Templates page and the builder opens with every scene armed.
category: Fashion / Lifestyle
ratio: 16:9
resolution: 2K
duration: 8
music: subtle
structure: multi3
camera: Auto
chain: 4
chainrule: same woman in every scene — identical face, hair, skin and build; a different room with its own light, a different garment, and a different action in each scene; the grade and lens language never change
flows: ENTER AND SETTLE | LIGHT FIRST | WALL WORK | SEATED FRAME
vary: OUTFIT DESIGN | OUTFIT COLOUR | MODEL | PRESENTATION | ACTION | OUTFIT INTERACTION | LOCATION | CAMERA | MOVEMENT | RHYTHM ENVELOPE | SCALE LADDER | CUT MOTIVATION | FRAMING DEVICE | OPEN DEVICE | CLOSE DEVICE | TRANSITION | SOUND FORMAT
tip: A chain recipe, not a single clip — send it from the Templates page and the builder opens with 4 linked scenes of this template, each with its own room, look and action, plus a consistency bible written for you. Render scene 1, then feed each clip's last frame into the next scene (Direct arms I2V for you).
idea: Photo-shoot tour: {MODEL — 20-32 unless specified: the same woman in every scene} wears {OUTFIT DESIGN — this scene's garment} in {LOCATION — this scene's room, its light source and one landmark}, {ACTION — this scene's action} while she {OUTFIT INTERACTION — what her hands do with this garment}, shot as {CAMERA — the lens and the move}, and this variant's own {MOVEMENT — how her body travels}.

```
integrated_multimodal_description: Shot on {CAMERA — lens, move and medium: body, focal length, speed, and the end-state it settles on}, 24fps, the SAME clean neutral grade as every other scene in this chain — grade, lens language and frame rate never change across the shoot. THIS SCENE'S ROOM: {LOCATION — this scene's room, its light source, its floor and one landmark}. The room changes completely between scenes and each one brings its own light design — a hard window shaft on a wooden floor, a soft top-light box in a white studio, cold daylight through industrial steel glazing, warm bounce off a coloured wall, or vertical strip practicals in a blacked-out space. Name this scene's light before anything moves. THE WOMAN IS THE SAME PERSON AS EVERY OTHER SCENE: {MODEL — 20-32 unless specified: the same woman: age, hair length/colour/texture, skin tone, build} with identical face, hair and skin tone; never re-describe her from scratch, reference the locked identity and spend the words on this room and this garment. THIS SCENE'S LOOK: {OUTFIT DESIGN — this scene's garment: silhouette, fabric, construction} in {OUTFIT COLOUR — this scene's colour family and finish} — she wears a different garment in every scene of the chain, and this one is complete (garment, fabric weight, colour, footwear). BEAT ENGINE — one beat per NAMED dimension, in physical order: ENTRY (she steps into this room's light and settles, full body, weight landing) · PRESENTATION ({PRESENTATION — how she carries herself in this scene}: posture, gaze direction, stillness before movement) · ACTION ({ACTION — this scene's action}, a chain of small physical events, not one gesture) · INTERACTION ({OUTFIT INTERACTION — what her hands do with this garment}: the fabric answers the hand) · TEXTURE (ONE faceless insert in this room's light — macro on the garment's weave, seam, hardware or hem, or the back of her head with the hair falling; no second face). In ONE scene of the chain the shooting kit is in frame — a cinema camera on a tripod, a softbox or a C-stand in the foreground with her performing past it — so the chain reads as a photo shoot, not a catalogue; only that scene carries it. FACE LEGIBILITY: never resolve a scene only in a full-body wide — the room establishes, then the coverage tightens to medium or close before the scene ends, and the render stays at 2K so the face survives the distance (upscalers and face-restorers do not fix it — resolution does). Skip any dimension that is not named; never invent a second garment, a second model or a smile to camera. FLOW LIBRARY — obey a BEAT FLOW named in the request; otherwise rotate by room: ENTER AND SETTLE, LIGHT FIRST, WALL WORK or SEATED FRAME, and never repeat the previous scene's flow. LAYER STACK: the look is a closed stack — an outer piece (jacket, blazer, coat, corset, kaftan, sheer overlay) is never worn alone, so it goes over a named inner GARMENT and a stated bottom (trousers, a skirt, or the garment's own lower half), and the footwear is named. NAME INNERWEAR ONLY WHERE IT IS SEEN: anything sheer, translucent, net, plunged, open-backed, cut out, slit or cropped-above-the-waist says exactly what sits under it (a camisole, a bodysuit or a bralette-and-brief); a closed, lined look names NO base layer at all — underwear nobody can see becomes visible underwear in the render.

TIMING: 8s total — 3 stamped shots, one new visible act every 1-1.5s inside them, no action held longer than 2s, and the final second a settled hold with this room's light unbroken.

overall_soundscape: this room's own layer — {ROOM TONE — room tone, a street through glass, an echo off bare walls}, fabric moving through air, footsteps on {FLOOR — this room's floor surface}, and no speech.

non_diegetic_music: {one rhythmic bed — a sparse percussive loop or a low synth pulse} that continues across the whole chain — the same cue in every scene, its level riding the cuts, or exactly N/A for pure editorial silence.
```

