## Equirectangular 360 — sphere tour
model: h3
tag: immersive
description: A whole environment in one frame — monoscopic equirectangular 360°, horizon on the middle line, the scene wrapping continuously around the viewer as if every edge rejoins. Built for the equi360 LoRA: trigger word first, then the layout sentence, then the world and its sound.
category: Immersive / 360
ratio: 21:9
resolution: 768P
duration: 5
music: subtle
structure: single
camera: Slow orbit — one smooth move, no cuts
flows: STAND AND TURN | SLOW ORBIT | WALK THE SPHERE | LOOK UP AND DOWN
vary: LOCATION | TIME OF DAY | WEATHER | SUBJECT | SOUND BED
tip: LoRA `shamanic/minimax-h3-equi360-lora` at scale 1.0 on the FL2VA base, 21:9 · 768P · 5s, prompt expansion OFF. The trigger `equirect360` and the layout sentence must be the first words of the prompt — the template writes both for you. Resize the rendered 21:9 frame to 2:1 before tagging it as conventional equirectangular media, and add mono-360 spherical metadata for players that need it (resize only — never crop, or the sphere tears at the seam).
idea: {LOCATION — the world that must wrap: interior or landscape, its light and one landmark that can stand on the horizon} at {TIME OF DAY — the hour and its light}, {WEATHER — air, weather and ground condition}, with {SUBJECT — 20-32 unless specified: who or what is in the middle of the world, or the word none}, and {SOUND BED — the ambience that belongs to this place}.

```
integrated_multimodal_description: equirect360 Equirectangular 360-degree panoramic video: the frame is a full spherical projection, a complete environment wrapping around the viewer on all sides, with the horizon at the vertical middle of the frame. Stationary camera, no cuts, no zoom, no roll — the viewer's head does the looking, so the camera never tilts across the horizon line. THE WORLD: {LOCATION — interior or landscape, its light and one landmark}. Nothing is off-screen: every direction must be worth looking at, so build the environment as four walls or a full horizon and keep detail out of the polar zones directly overhead and underfoot, where the projection stretches hardest. {TIME OF DAY — the hour and its light} carries the palette; name where the light comes from in more than one direction, because a single-source key leaves half the sphere dark. {WEATHER — air, weather and ground condition} gives the ground a material that answers light. {SUBJECT — 20-32 unless specified: who or what stands in the world, or none}: place it at about {DISTANCE — metres from the viewer} on the horizon line where the projection is truest, and if it moves, it moves in a slow arc rather than crossing the seam. WRAP CONTINUITY: the left and right edges of the frame are the same direction of the sphere, so they must join invisibly — no object may straddle that seam, keep the sun, lights, signage and architecture away from straight ahead and straight behind, and prefer repeating, continuous forms (ground, sky, water, walls, tree lines) over discrete ones near the edges. POLAR RULE: the top and bottom of the frame are the zenith and nadir — keep ceilings, chandeliers, trench gratings and floor detail either wide and simple or out of those bands entirely; no thin vertical object may reach the top of frame, where it will smear. BEAT PLAN — the world IS the beat list: LIGHT (name the two or three directions the light comes from and what it touches), DEPTH (foreground ground texture, mid-ground landmark, far horizon), LIFE ({SOUND BED — what is actually alive or moving in this place}: leaves, water, fabric, a scooter passing one way only, distant chatter — never intelligible words), and one slow reveal the viewer can turn to find. If {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} is present, the subject is the only discrete element: no cut-outs, no cutaways, no second subject. TIMING: 5s total — one continuous move or hold; the visible change is light, weather and the slow motion of {SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing}, not edits. Render flat and clean: no letterbox, no vignette at the edges, no frame border.

overall_soundscape: an all-around bed for {LOCATION} — {SOUND BED — room tone or landscape air, the ground underfoot, the near layer, the far layer}, mixed so that no single sound sits hard at the front, since the listener is standing inside it. No intelligible speech anywhere in this field.

non_diegetic_music: {one ambient bed — a sustained airy pad or a slow percussive pulse} or exactly N/A so the place's own ambience carries the sphere.
```

## VR180 stereo pair — immersive walk
model: h3
tag: immersive
description: VR180 stereoscopic side-by-side — the left half is the left eye, the right half is the right eye, each a 180° hemisphere with real depth. Built for the vr180sbs LoRA: trigger and layout sentence first, then one continuous move through a world the viewer stands inside.
category: Immersive / VR180
ratio: 21:9
resolution: 768P
duration: 5
music: subtle
structure: single
camera: One continuous move at walking pace, no cuts
flows: WALK FORWARD | SLOW PAN AND SETTLE | ARRIVE AND LOOK AROUND | PASS THROUGH A THRESHOLD
vary: LOCATION | SUBJECT | TIME OF DAY | PACE | SOUND BED
tip: LoRA `EllipsesMark/minimax-h3-vr180-sbs-lora` at scale 1.0 (on fal the path is `rehan-fal/minimax-h3-vr180-sbs-lora`), 21:9 · 768P · 5s, prompt expansion OFF — and stay on the minimax/h3 route, the 8-step h3-max LoRA route degrades the stereo pair. Packages as: `ffmpeg -i out.mp4 -vf "scale=1536:768:flags=lanczos,setsar=1" -c:v libx264 -crf 16 -pix_fmt yuv420p -c:a copy tmp.mp4` then `python spatialmedia -i --v2 -s left-right -p equirectangular -b 0:0:1073741824:1073741824 tmp.mp4 out_LR_180.mp4`. Put it on a headset before trusting it.
idea: {LOCATION — the world the viewer stands in: its light, its ground and one landmark within arm's reach}, {SUBJECT — who or what is in the scene, kept {DISTANCE — metres away} in front}, moving at {PACE — the walking pace or stillness}, with {SOUND BED — the ambience of this place}.

```
integrated_multimodal_description: vr180sbs Stereoscopic VR180 video shown side by side: the left half is the left-eye view and the right half is the right-eye view of the same 180-degree scene, nearly identical with a slight horizontal offset. One continuous take at {PACE — walking pace or near-stillness}, no cuts, no zoom, no whip pan — fast pans drift between the eyes, so every move is slow and motivated. THE WORLD: {LOCATION — light, ground and one landmark within arm's reach}. The viewer is standing inside it, so build the near field as carefully as the far field: the ground underfoot must be real and continuous, and the first two metres in front of the lens must hold something worth looking at, because that is what the depth reads on. STEREO DISCIPLINE: {SUBJECT — 20-32 unless specified: who or what is in the scene} stays about {DISTANCE — metres from the viewer} away — nearer than about 1.5 m breaks the stereo comfort, farther than about 4 m loses the depth entirely; keep hands, props, hair and fabric out of the half-metre in front of the lens, never let anything cross hard between the eyes, and keep one subject rather than a crowd, so the disparity stays clean. Left and right eyes must hold the same moment: no object may appear in one eye only, no reflection or mirror trick, no text or signage presenting at an angle where the two eyes disagree — no on-screen text at all. DEPTH STACK, deliberately: a near layer (ground, grass, gravel, floorboards, a table edge), a mid layer ({SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing}), and a far layer (sky, tree line, wall, horizon) so the stereo has something to measure at every distance. LIGHT: {TIME OF DAY — the hour and its light} with the light coming from inside the 180° field rather than behind the viewer, and keep dark porthole vignettes out of the outer edges of each eye. BEAT PLAN: ENTER (the first second establishes the ground and the near layer), APPROACH ({SUBJECT — 20-32 unless specified: age, build, hair, skin, what the face is doing} reveals itself as the move closes gently), PASS (the world streams past at one steady pace), SETTLE (the move eases to stillness and the depth holds). TIMING: 5s total — one continuous move; 10-15s clips keep the pair intact if the pace stays even. Render flat and clean: no letterbox bars inside either eye, no frame border, no split-screen graphics. These are proportions of the runtime: change the duration and every segment scales with it.

overall_soundscape: a stereo bed for {LOCATION} — {SOUND BED}, with the near sounds (footsteps, fabric, breath) sitting close and the far sounds (traffic, water, wind) held back, so the depth of the image is matched by the depth of the sound. No intelligible speech in this field.

non_diegetic_music: {one ambient bed — sustained air, a low drone, a soft percussive pulse} or exactly N/A so the place carries it.
```
