# YOUR templates — this file is yours.
# App updates replace templates.md but NEVER touch this file.
# Paste forged blocks below (## Title + meta + fenced skeleton), one per template.
# Rebuild the app any time — everything here stays.
# LTX block example (one flowing paragraph, prompt: + negative_prompt: + tags: inside the fence):
# ## My LTX reel
# tag: fashion
# model: ltx
# category: Fashion / Lifestyle
# ratio: 9:16
# duration: 8
# idea: …
# ```
# prompt: …one flowing present-tense paragraph with {PLACEHOLDERS}…
# negative_prompt: text, watermark
# tags: ltx
# ```

## 👤 User example — H3 fashion beat
model: h3
tag: fashion
description: Example H3 block: three-field skeleton with [Shot 1], placeholders become 🧩 fields.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
idea: A {AGE}-year-old model in {GARMENT — colour, fabric, cut} at {LOCATION} — {BEAT_1}, then {BEAT_2}, settling into {FINAL_POSE}.

```
integrated_multimodal_description: Shot on {CAMERA + LENS, e.g. an ARRI Alexa Mini with a Panavision 50mm}, vertical 9:16, 24fps. [Shot 1] {LOCATION dressed concretely — surfaces, one practical light, depth}. A {AGE}-year-old model in {GARMENT with colour, fabric and cut} marks her spot, {BEAT_1 — settle / inhale / glance}, then {BEAT_2 — the developing move}; fabric and hair respond to {WIND/LIGHT detail}. She finishes on {FINAL_POSE}, holding the look as the camera {MOVE with end-state, e.g. trucks left and settles tight on her face}. {LIGHTING DESIGN — one named key and its falloff}. {GRADE}. LAYER STACK: no garment stands alone — the look is a closed stack: a named base layer (a camisole, a bodysuit or a bralette-and-brief) under the main piece, a stated bottom (trousers, a skirt or the garment's own lower half), the outer layer only if the look actually has one, then the footwear; a top or an outer piece is never worn alone and nothing is left for the renderer to invent.

overall_soundscape: {FOOTSTEP/FABRIC sounds}, {ONE ambient detail}, clean room tone.

non_diegetic_music: {GENRE} at {TEMPO}, {INSTRUMENTATION}, dipping under the final pose.
```

## 👤 User example — LTX fashion walk
model: ltx
tag: fashion
description: Example LTX block: ONE flowing paragraph + negative + tags; placeholders become 🧩 fields.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 2K
duration: 8
music: subtle
structure: single
camera: Auto
idea: A {AGE}-year-old model in {GARMENT — colour, fabric, cut} walks toward the lens at {LOCATION}, ending on {FINAL_POSE}.

```
prompt: {LENS feel, e.g. handheld 35mm with gentle parallax}, {GRADE}. A {AGE}-year-old model with {FACE/HAIR detail} wears {GARMENT described with its colour, fabric and cut} at {LOCATION described concretely: surfaces, light sources, depth}. She starts mid-stride walking toward the camera, chin level, gaze locked to lens, then {SECONDARY BEAT — adjust cuff / brush hair}, {FABRIC physics per step}. The camera pulls back at matching pace, settling on a {waist-up / full-length} end frame as she stops into {FINAL_POSE}, {MICRO-EXPRESSION}. {LIGHT design — one named key source}. Diegetic sound: {FOOTSTEPS on surface}, {ONE ambient layer}; {SCORE direction or silence}. LAYER STACK: no garment stands alone — the look is a closed stack: a named base layer (a camisole, a bodysuit or a bralette-and-brief) under the main piece, a stated bottom (trousers, a skirt or the garment's own lower half), the outer layer only if the look actually has one, then the footwear; a top or an outer piece is never worn alone and nothing is left for the renderer to invent.

negative_prompt: text, watermark, logo, extra limbs, warped face, jump cuts, flicker, changing wardrobe

tags: fashion, walk-in, ltx, user
```
