# Real MiniMax H3 example prompts

Curated from the community corpus [ostris/minimax_h3_1k](https://huggingface.co/datasets/ostris/minimax_h3_1k) — real-world prompts in the exact three-field H3 contract. Copy them, or load one into the Studio idea box and use ENHANCE mode.

Add your own: copy any block below, edit, and reload from Settings.

## Film noir
genre: Black-and-white 1940s film noir on grainy 35mm with hard chiaroscuro s

```
integrated_multimodal_description: [Shot 1] Black-and-white 1940s film noir on grainy 35mm with hard chiaroscuro shadows and faint gate flicker, a middle-aged white woman in a belted trench coat and slouch hat bursts through a frosted-glass office door stenciled "MARLOW & SONS INVESTIGATIONS", snatches a manila dossier off the desk, and shoves a tall filing cabinet crashing over to block the doorway behind her. Venetian-blind shadows rake across her face as she wrenches open the sash window, swings her legs over the sill, and drops onto the iron fire escape. The camera trucks right with large amplitude at fast speed to stay with her across the office, then holds as steam from a street grate below swallows her clattering descent into the dark.
```

## Rubber-hose animation
genre: 2D-animated in 1930s rubber-hose style, black-and-white with heavy fil

```
integrated_multimodal_description: [Shot 1] 2D-animated in 1930s rubber-hose style, black-and-white with heavy film grain and slight frame jitter, a lanky cartoon cat chef with pie-cut eyes and noodle-limp arms flips a teetering tower of pancakes in a tiny diner kitchen. His arm winds up in three full rope-like rotations before the flip; the pancakes sail upward in an arc, flatten against the ceiling, peel off one by one, and stack themselves neatly onto a plate he catches with his tail. A pot-bellied stove in the corner bounces in rhythm, its chimney pipe accordioning, while the cat's whole body squashes and stretches with each catch and his bow tie spins like a propeller as the last pancake lands. The camera holds a static shot while the entire kitchen bobs to the beat around him.
```

## Claymation
genre: Claymation with visible fingerprint texture and gently stuttering stop

```
integrated_multimodal_description: [Shot 1] Claymation with visible fingerprint texture and gently stuttering stop-motion movement, a round clay hedgehog baker in a flour-dusted apron chases a runaway blob of dough across a miniature bakery counter. The dough blob springs off a rolling pin, splats against a jar of raisins that wobbles and tips, and bounces between loaf tins as the hedgehog lunges after it and belly-flops into a flour sack that erupts in a soft white cloud. The camera pedestals up with small amplitude at slow speed from counter level to reveal the blob perched atop a towering wedding cake, quivering, while the hedgehog surfaces from the flour with his spectacles askew and shakes himself off in a puff of white. Cotton-wool flour dust drifts across the handmade set as crumbs of clay scatter off the counter edge.
```

## Dashcam incident
genre: Dashcam footage, wide-angle and slightly fisheyed with washed-out morn

```
integrated_multimodal_description: [Shot 1] Dashcam footage, wide-angle and slightly fisheyed with washed-out morning glare and the timestamp "05/14/2024 07:42 AM" burned into the lower corner, a two-lane highway rolls forward at speed behind a rust-red pickup truck stacked with furniture. A strapped mattress on the pickup's bed works loose, lifts on the wind, and cartwheels off the tailgate straight toward the lens. The recording car brakes hard and swerves onto the shoulder; the camera shakes slightly with the sudden deceleration as the mattress bounces twice on the asphalt and flops flat across the neighboring lane, where a silver hatchback fishtails around it and kicks up a plume of dust. The pickup's hazard lights start blinking as it eases toward the shoulder far ahead.
```

## Nature macro
genre: Nature documentary footage in crisp macro with shallow depth of field

```
integrated_multimodal_description: [Shot 1] Nature documentary footage in crisp macro with shallow depth of field and morning dew beading every stem, a green praying mantis pivots its triangular head and creeps along a branch, forelegs folded, stalking a hoverfly that lands on a sunlit leaf and grooms its wings. The camera pans right with small amplitude at slow speed to hold both insects in frame as the mantis rocks its body side to side, edging closer with each sway. The hushed elderly British female narrator (S1), voice soft, breathy, and measured, says in an off-screen voiceover: <d>[English] She has waited an hour for this moment.</d> — no on-screen subject's lips move to mouth the words. [Shot 2] At 00:03.000, the shot cuts to a tighter macro angle; the mantis's forelegs snap out in a blur and seize the hoverfly as the leaf whips from the impact and scattered dewdrops flare in the backlight.
```

## 80s soap opera
genre: Shot-on-video 1980s daytime soap opera with soft diffusion glow and fl

```
integrated_multimodal_description: [Shot 1] Shot-on-video 1980s daytime soap opera with soft diffusion glow and flat three-point studio lighting, in a wood-paneled living-room set the silver-haired Latina matriarch in a shoulder-padded blazer (S1), her voice low, commanding, with a dry rasp and deliberate pace, hurls a folder of documents across the coffee table and says: <d>[English] You forged his will, Marisol.</d> Her adult daughter (S2), a woman in her thirties with a high, trembling, rapid voice, stumbles backward into the drinks cart, rattling the glassware, clutching at her necklace as she answers: <d>[English] Mama, please, I can explain—</d> [Shot 2] At 00:03.500, the shot cuts to a tight close-up; the camera zooms in with large amplitude at fast speed on S1's face as she rips the pearl strand from her own neck, beads bouncing across the parquet, and says: <d>[English] Get out of my house.<cutoff></d>
```

## 90s toy commercial
genre: Grainy 1990s broadcast toy commercial with oversaturated color and sli

```
integrated_multimodal_description: [Shot 1] Grainy 1990s broadcast toy commercial with oversaturated color and slight tape wobble, two kids — a South Asian boy of about eight and a freckled redheaded girl of about ten — slam neon plastic worm-shaped racers down a looping orange track across a basement floor, the racers whipping through the loop and flinging glitter sparks. The energetic adult male announcer (S1), voice booming, fast, and hyper-articulated, says in an off-screen voiceover: <d>[English] New Turbo Wormz! They loop! They launch!</d> — the on-screen children's lips remain closed while the voiceover plays. [Shot 2] At 00:02.000, the shot cuts to the girl yanking a ripcord; her worm racer rockets off a ramp over a cardboard volcano while the boy pumps both fists. [Shot 3] At 00:03.500, the shot cuts to a spinning product box on a sparkling backdrop stamped "TURBO WORMZ!" and "ONLY $19.99!" as S1 continues in the off-screen voiceover, no one on screen to mouth the words: <d>[English] Grab yours before they wriggle away!<cutoff></d>
```

## Gospel documentary
genre: Live-action, handheld documentary-style with warm tungsten light, insi

```
integrated_multimodal_description: [Shot 1] Live-action, handheld documentary-style with warm tungsten light, inside a storefront church a twelve-member gospel choir in blue robes claps double-time and sways in stepped rows while a Hammond organ and tambourine drive the song from the corner of the room. The soloist, a heavyset middle-aged Black woman (S1) with a rich, powerful contralto and unhurried phrasing, strides forward from the front row, raises one hand high, and sings: <d>[English] Lift me higher, higher over the mountain!</d> The full choir (S2), a massed blend of male and female voices in close harmony, answers as they rock side to side: <d>[English] Higher, higher!</d> The camera arcs around S1 with large amplitude at slow speed, sweeping from her profile to face-on as she plants her feet, throws her head back, and drives the final note upward while the tambourine player circles into frame striking on every offbeat.
```

## Sports broadcast
genre: Broadcast sports coverage in clean high definition with a scoreboard g

```
integrated_multimodal_description: [Shot 1] Broadcast sports coverage in clean high definition with a scoreboard graphic reading "CHEN 10 - 9 VOGEL" pinned to the upper corner, a table tennis match point unfolds under arena lights: a wiry Chinese man in his fifties on the left and a tall young German woman on the right trade a ferocious rally, the ball skimming the net tape on every counter-loop. He lunges wide for a backhand chop, she smashes cross-court, and he dives full-stretch to clip the edge of the table for the winner, sliding across the floor on his chest as she spins away shaking her head. The camera pans left and right with small amplitude at fast speed, whipping to follow the ball through the rally. The excited middle-aged male commentator (S1), voice bright, rapid, and cracking with volume, says in an off-screen voiceover — neither player's on-screen lips move to mouth the words: <d>[English] Oh, the edge! He's done it! Unbelievable scenes!<cutoff></d>
```

## Neon rain chase
genre: Live-action, cinematic, handheld verité camerawork under high-contrast

```
integrated_multimodal_description: [Shot 1] Live-action, cinematic, handheld verité camerawork under high-contrast neon-and-rain lighting, a wiry Filipino line cook in his twenties (no ID, non-vocalizing) bursts out of a steaming noodle stall clutching a grease-stained ledger, knocking over a rack of hanging ducks that swing and clatter behind him. He sprints down a narrow market alley slick with rain, splashing through puddles and shouldering past a fruit cart that spills oranges rolling underfoot. Behind him a corrupt beat cop in a rain-slicked poncho draws a baton and vaults the fallen cart in pursuit, boots slapping the wet pavement. The camera tracks alongside them with large amplitude at fast speed, weaving between hanging lanterns and steam vents as the cook cuts hard left through a beaded curtain, beads clattering and swinging violently, the cop crashing through half a second behind and stumbling on the wet tile before regaining his footing and closing the gap.
```

## Sci-fi corridor
genre: Live-action, cinematic, sterile spaceship corridor lighting strobing e

```
integrated_multimodal_description: [Shot 1] Live-action, cinematic, sterile spaceship corridor lighting strobing emergency red, a Black starship captain in her forties (no ID, non-vocalizing) backs down a narrow corridor firing a pulse rifle at a segmented alien creature clawing through a buckled bulkhead, sparks and severed cable ends showering down around her boots. She slams a fist against a wall panel twice, the signal for an emergency seal, and keeps firing as a crewman ahead scrambles to the control switch. The camera shakes strongly at fast speed, handheld and tight, tracking the creature's lunging strikes against the corridor walls. [Shot 2] At 00:03.200, the shot cuts to the bulkhead grinding shut behind her as she dives through the narrowing gap, the creature's claw slamming into the sealed door a heartbeat later, denting the metal outward with a booming impact that echoes down the corridor as she rolls to her feet, chest heaving, weapon still raised toward the shuddering door.
```

## Frozen lake
genre: Live-action, cinematic, stark overcast light over a frozen lake render

```
integrated_multimodal_description: [Shot 1] Live-action, cinematic, stark overcast light over a frozen lake rendered in a cold blue grade, a Chinese scientist in her forties (S1), breath ragged in the freezing air, runs hard across open ice clutching a sealed data drive to her chest, her boots skidding as two agents on snowmobiles fan out behind her, engines roaring and throwing plumes of snow. She glances back and shouts: <d>[Mandarin] 冰要裂了,别追了!</d> The camera tracks alongside her with large amplitude at fast speed, tilting down with small amplitude at moderate speed to show spiderweb cracks racing outward beneath her feet. [Shot 2] At 00:03.000, the shot cuts to a wider angle as one snowmobile's front ski punches through the weakened ice, the driver bailing hard to the side as the machine sinks with a lurch, while S1 reaches the shoreline rocks and hauls herself up, the second agent abandoning pursuit to drag his partner from the freezing water.
```

## Casino neon
genre: Live-action, cinematic, saturated casino neon washing across green fel

```
integrated_multimodal_description: [Shot 1] Live-action, cinematic, saturated casino neon washing across green felt tables in shallow depth of field, a lean Vietnamese-American card counter in his thirties (S1) fans a stack of high-value chips across the table with practiced speed while a pit boss's attention is pulled by a staged commotion at the next table. A woman's voice crackles through his hidden earpiece, low and clipped: <d>[English] Floor manager's turning back, move now.</d> S1 sweeps the chips into his jacket lining in one fluid motion and stands, knocking his stool back with a deliberate clatter. The camera trucks right with large amplitude at fast speed, following him through the crowd toward the exit. [Shot 2] At 00:03.100, the shot cuts to the pit boss shoving through gamblers toward the vacated table, slamming a hand down on the felt as he realizes the chip rack is short, while S1 slips through revolving doors into the bright exterior daylight, breaking into a run across the valet lane.
```

## Hospital verité
genre: Live-action, cinematic, Steadicam tracking through fluorescent-lit hos

```
integrated_multimodal_description: [Shot 1] Live-action, cinematic, Steadicam tracking through fluorescent-lit hospital corridors with a cool clinical color grade, a Latina nurse in her thirties (no ID, non-vocalizing) shoves through a set of double doors, abandoning a loaded supply cart that crashes into a wall rack and sends bandage rolls bouncing across the floor. She sprints past startled orderlies, snatching a fire extinguisher off its mount without slowing, while behind her a gaunt older hitman in a stolen orderly's coat shoulders through the same doors, knocking a wheelchair spinning into the wall. The camera tracks alongside her with large amplitude at fast speed then pushes in with small amplitude at slow speed on her face as she glances back, before she rounds a corner and hurls the extinguisher at his knees, the canister skittering and hissing white fog across the tile as he stumbles through it, one hand slamming into a gurney that rolls free and blocks the corridor behind him.
```

## Rooftop heist
genre: Live-action, modern cinematic film with anamorphic flares and rain-sli

```
integrated_multimodal_description: [Shot 1] Live-action, modern cinematic film with anamorphic flares and rain-slick night textures, a handheld tracking shot follows two thieves sprinting across a wet rooftop, satchels of stolen bearer bonds bouncing on their backs. The wiry East Asian woman in a black windbreaker (S1), her voice sharp, breathless, and quick-paced, vaults an air duct and shouts: <d>[English] Don't slow down — jump!</d> Her partner, a stocky bearded Black man in his forties, hurdles a vent pipe and clips a stack of paint cans that clatter away behind them. [Shot 2] At 00:03.000, the shot cuts to a low angle at the roof edge; the camera pushes in with small amplitude at fast speed as both leap the alley gap, coats flaring against sodium-lit fog, and crash-roll onto the gravel of the far rooftop, scattering pigeons.
```

## Alien dusk
genre: Live-action, cinematic, golden dusk light silhouetting a towering alie

```
integrated_multimodal_description: [Shot 1] Live-action, cinematic, golden dusk light silhouetting a towering alien form against a bruised sky, an elderly white farmer in his seventies (no ID, non-vocalizing) stumbles backward through his own cornfield, stalks snapping and flattening beneath his boots as a spindly-limbed alien creature descends toward him on a column of shimmering distortion, corn husks scattering in the downdraft. He drops his shotgun into the dirt and raises both trembling hands, backing into a scarecrow that topples behind him. The camera pushes in with small amplitude at slow speed on the alien's elongated head as it tilts, studying him. [Shot 2] At 00:03.500, the shot cuts to a wider angle as the farmer, breathing hard, straightens and says, voice shaking but clear: <d>[English] I ain't got a fight in me, just wanted my supper.<cutoff></d> The creature's long fingers uncurl slowly, releasing a soft pulse of light across the flattened corn around them both.
```

## Sari × brand-ad cinematic combo
genre: studio-crafted combo — templates "Sari — she-performs showcase" × "Traditional brand-ad cinematic"; multi-shot with anchored insert

```
integrated_multimodal_description: Shot on a Sony A7S III with an 85mm at f/2.0, vertical 9:16, 24fps, locked frame on a deep-teal cyclorama with a warm key and cool rim. [Shot 1] A model in a burnt-orange organza sari with a silver-zari border and a gold-embroidered halter blouse walks in slow from depth, pleats swaying; she lifts the pallu with her fingertips and lets it float, then turns over her shoulder into a soft smile, gaze down then up to the lens — bangles chiming on the wrist turn. [Shot 2] At 00:05.000, the camera cuts to an anchored insert ON HER: macro of the jhumka swing and necklace catch against the embroidered blouse, light firing off every bead while her chin tilts. [Shot 3] At 00:08.000, the camera cuts back wide as she lifts both arms to spread the full pallu print, lets it settle in slow motion-feel, and ends centered with one hand on her hip, outfit fully readable, logo-safe. Warm cinematic grade, velvet blacks; she never exits frame and the camera never zooms.
```

## GRWM × bridal montage combo
genre: studio-crafted combo — templates "GRWM try-on angle pass" × "Bridal heavy-embroidery montage"; angle turns plus faceless jewelry inserts

```
integrated_multimodal_description: Shot on a smartphone 35mm-equivalent at f/2.0, vertical 9:16, 30fps, locked full-length tripod frame; a warm-grey cyclorama with one candle-warm key raking across zardozi. [Shot 1] A bride in a crimson velvet lehenga with gold floral embroidery, cross-strap blouse and latkan tassels presents front-on with downcast serene gaze; she turns in place — profile hold showing the dupatta edge, back hold showing the cape fall and back detail, return — each angle held a beat, the embroidery reading on every turn. [Shot 2] Faceless insert anchored ON HER BODY: folded hands with stacked polki bangles and a hand-chain against the skirt's embroidery rows, latkan tassels hanging in frame, every micro-movement earning a glint. [Shot 3] Back to the locked full frame: fingertips trace the neckline, a hand settles the waist, her gaze lifts with a slow blink and a composed chin tilt; stillness regal, the full crimson-and-gold readable. Rich saturated warm grade, no text.
```

## Skeptic testimonial × unboxing combo
genre: studio-crafted combo — templates "UGC skeptic testimonial ad" × "UGC unboxing first reaction"; talking head intercut with real-time opening

```
integrated_multimodal_description: Shot on a smartphone front camera 26mm-equivalent at f/1.8, vertical 9:16, 30fps, slightly underexposed bedroom light, no grade. [Shot 1] A creator in an unstyled bedroom holds the phone at arm's length: "I did NOT believe the hype about this hair dryer, because my last three were lies" — casual pace, one honest pause. [Shot 2] Intercut top-down unboxing in real time on the duvet: tape tear, tissue crinkle, first pull-out; fingers test the weight — "oh, it's heavier than it looks" — and the nozzle tilts into window light while the phone refocuses. [Shot 3] Back to face, hair visibly smoother over one shoulder: "two weeks, same routine, and it's just… quieter, faster, done" with a small shrug; bold synced captions bottom third, 1-3 words per frame; CTA like a favor: "it's linked, that's it". Room clutter visible, phone-mic voice, kettle in the background; no logos, no end card.
```

## Day-in-the-life × problem-solution combo
genre: studio-crafted combo — templates "UGC day-in-the-life soft sell" × "UGC problem-solution demo"; routine slices carry the PAS arc

```
integrated_multimodal_description: Shot on a smartphone, vertical 9:16, 30fps, available light only, six honest slices cut on movement. [Shot 1] Morning: alarm hand, kettle switch, a tired face in the bathroom mirror; low diary voiceover: "so, week one of actually fixing my sleep". [Shot 2] The struggle embedded in routine: phone scrolled at 1am (screen glow on the pillow), a third coffee poured, a sigh at the desk — the pain shown, never announced; then the product appears casually on the nightstand, never centered: "then this little lamp entered the chat". [Shot 3] Solution in real time: thumb slides the warm dimmer down, the room amber, the phone face-down; evening slices — book page, slower breath, lights out at ten; final sofa beat, one lamp: "fourteen days: same job, same stress, different mornings" and a cut to black one beat early. Slight underexposure, real clutter, phone-mic voice; no logos, no end card.
```

## Three-ways × skeptic testimonial hybrid
genre: studio-crafted combo — templates "Outfit transition three ways" × "UGC skeptic testimonial ad"; fashion grammar delivered with UGC honesty

```
integrated_multimodal_description: Shot on a smartphone tripod, vertical 9:16, 30fps, locked medium-full frame in a plain-wall corner with one plant; natural light, true colors. [Shot 1] Face-to-camera, arm's length: "everyone said this linen shirt does three outfits, so I wore it for a week to prove them wrong" — skeptical, unscripted. [Shot 2] Beat-cut ON a clap to LOOK 1: sleeves rolled over a white tee, sneakers, tote — "errands, obviously"; clap-cut to LOOK 2: tucked into tailored trousers with loafers, posture shifted — "office, and it did NOT wrinkle by 3pm, I checked"; clap-cut to LOOK 3: open over a slip dress with heels, hair slicked — "and then dinner happened". Each look gets two honest styling beats; bold synced captions bottom third: "1 — errands", "2 — office", "3 — after". [Shot 3] Back to face, shrug: "okay. I was wrong. Three ways, easily" — CTA as a friend: "which one are you wearing first?" No logos, no grade.
```
