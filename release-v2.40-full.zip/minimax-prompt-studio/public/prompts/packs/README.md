# Prompt packs — one craft brain per video type

A **pack** is a block of domain craft that is appended to the system prompt **only when the
generation is actually about that domain**. This replaces the old behaviour where fashion craft
was baked into every system prompt and fired on the `Fashion / Lifestyle` category alone — which
leaked garment vocabulary into product, portrait, dialogue and animation prompts.

## How a generation picks its pack

1. **Your pick** — the `🧠 Prompt pack` drop-down in the Scene section (`Auto` = let the app decide,
   `Base only` = append nothing).
2. **Template tag** — the tag on the template you picked (or the scene's own template in chain mode).
   Some tags are *mode* tags, not verticals (`person`, `preset`, `multi`, `vertical`, `longvideo`,
   `mature`) — those never vote, the category/idea decides instead.
3. **Category** — the category chip in the builder.
4. **Idea keywords** — the `keywords:` list of each pack, matched against your idea sentence.
   2+ distinct hits outrank the category; 3+ outrank everything except a real template tag.
5. Nothing matched → the base prompt runs alone. At most **two** packs are ever stacked, and only
   when one of them declares `stack-with:` the other (e.g. fashion + social/UGC).

Every generation logs the decision to the console (`routing: prompt packs …`) and the generated
card shows which packs were used.

## Adding your own pack

Drop a `.md` file in this folder. Header lines first, then a blank line, then the craft body:

```
pack: welding            # id — also the drop-down value
label: 🔧 Welding & metalwork
tags: welding, metal, workshop        # template tags that select this pack
categories: Documentary               # builder categories that select this pack
keywords: weld, arc, sparks, steel    # idea-word fallback
stack-with:                          # optional: pack id that may ride along
order: 90                            # tie-break / drop-down order (lower = first)
hint: arc light, spatter physics, glove close-ups

SCOPE GUARD: use only the lines that match this shot.

## ...craft sections...
```

Name a file `user-something.md` and it overrides a built-in pack with the same `pack:` id
(updates never touch your files). `README.md` and `_*.md` are ignored by the scanner.

### Mode-gated sections

Some craft only applies in one mode (e.g. fashion: *she performs* vs *camera plays*). Wrap those
parts in markers — the loader injects only the block matching the active mode:

```
[[MODE perform]]
...locked-frame craft...
[[MODE camplay]]
...moving-camera craft...
[[/MODE]]
```

Everything outside the markers is always injected.
