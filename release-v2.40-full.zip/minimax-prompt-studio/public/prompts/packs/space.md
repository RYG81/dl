pack: space
label: 🏛 Spaces & architecture
tags: space, interior, architecture, room, building, location
keywords: interior, architecture, room, hallway, cathedral, temple, museum, corridor, building, lobby, staircase, loft, warehouse, hotel, apartment, attic, church, courtyard, kitchen interior
categories: 
stack-with: 
order: 55
hint: governing geometry, light as the subject, human scale, room reverb

# 🏛 SPACES & ARCHITECTURE — domain craft
SCOPE GUARD: apply the lines that match the space; skip the rest.

## Geometry first
Pick the governing line and stay honest to it: one-point perspective down a corridor, a symmetry axis across a hall, a diagonal staircase, a repeated colonnade. Verticals stay vertical unless the tilt is deliberate; the camera does not fight the architecture.

## Light is the subject
Shafts with visible dust · pools of window light on the floor that move as the shot progresses · practical fixtures with visible falloff · bounce from a bright wall shaping the shadow side · a single tungsten lamp against a cold exterior. Name light direction, what stays in shadow, and how the surfaces answer it.

## Human scale
One person — often small, silhouetted, or half-hidden — walking, sitting, waiting, or crossing the frame at the end of the move. They give the space its size and the shot its time signature. Never crowd the architecture; one figure is enough.

## Ambient channels (at least two in motion)
Sun patch crawling across the floor, curtains breathing, steam from a cup, dust drifting in the beam, a cat crossing, lights switching on in stages, a door swinging on its hinge, rain on glass.

## Movement grammar (one idea per shot)
Gimbal walk-through at a slow constant speed · slow rise up a facade · lateral slide past a colonnade · locked frame that lets people move through the composition · slow push into a doorway that opens onto a second space. No whip pans, no handheld drift in architectural frames.

## Material honesty
Stone grain, polished reflections carrying the windows, wood pores, concrete form marks, tile scale, the way a metal handrail catches a stripe of light. Shoot each material at the height and distance where it reads; wide frames lose texture.

## Sound
The room's own reverb is the track: footsteps with a long tail, a door closing into a large silence, distant hum, water somewhere, air movement. Silence here is a texture, not an absence — do not fill it with music unless asked.

## End frame
The composed architectural image — symmetry, a strong leading line, or a figure exactly where the geometry wants them — everything settled and legible.
