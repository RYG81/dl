pack: dialogue
label: 🗣 Dialogue & scenes
tags: dialogue, conversation, scene, actors, script
keywords: dialogue, conversation, argument, interview, whisper, talks, replies, banter, confrontation, meeting, confesses, negotiates
categories: Dialogue Scene
order: 25
hint: two-hander coverage, eyelines, subtext in behaviour, reaction beats

# 🗣 DIALOGUE & SCENES — domain craft
SCOPE GUARD: apply the lines that match the scene in front of you; skip the rest.

## Speakers
Tag each speaking character on first appearance — "(S1)" / "(S2)" — and carry the tag inline with the action. Voice direction rides in the same sentence: "her voice low and level, the last word clipped". A speaker who is not visible in a shot still gets their voice placed in the room (off-frame left, behind the door, on the phone).

## Geometry & eyelines
Fix where each person is and which way they face: across a table, in a doorway, in a car, on a bench. Hold the eyeline — the camera does not cross the line between the two unless disorientation is the point. Screen direction stays consistent for the whole scene.

## Coverage logic
Wide to establish the room and the power balance, then singles or over-the-shoulders for the exchange. Every shot change must add information: whose face we need, who is now in control, what the listener is doing with their hands. Never cut just to change the view of a talking face.

## Write the subtext as behaviour
What the body does while the mouth talks: a thumb circling a glass rim, a chair pushed back a half-inch, a napkin folded twice, a lighter that will not catch. Pauses are action too — a beat of silence, a swallow, an inhale before a hard line.

## Beat arc (scale to duration)
APPROACH — the room and the temperature of the exchange → THE LINE — the sentence that changes the pressure → REACTION — the silent beat that answers it (jaw setting, eyes dropping, a half-smile that fails) → EXIT — the door, the held look, or the answer no one says aloud. A 5-second scene still needs the line and the reaction.

## Reaction shots earn their cut
Name the listener's micro-expression: eyes flicking down and back, a short exhale through the nose, lips pressing, brow tightening a fraction. Cut to the listener at the worst possible moment for the speaker.

## Naturalism
Minor interruptions, one half-sentence finished by the other, a speech restart, one ellipsis where a character decides not to say it. Keep each line short enough to be spoken twice inside the shot's duration.

## Sound
Continuous room tone under the whole scene so cuts do not breathe; cloth and chair creaks, cutlery, a distant street, breath before a hard line. Dialogue dry and forward in the mix, ambience behind it. If a score exists it stays under the words, not over them.

## End frame
The image that means more than the last line — a hand still holding the cup, the door closing, the look held a beat past comfortable.
