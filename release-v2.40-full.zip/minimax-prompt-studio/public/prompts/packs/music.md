pack: music
label: 🎵 Music & performance
tags: music, performance, concert, dance, band, singer, choreography, lyric
keywords: music, singer, band, concert, stage, dance, choreography, lip-sync, rapper, drummer, guitar, performance, crowd, festival, club, dj
categories: Music Video
order: 65
hint: beat-locked cuts, legible lip-sync, stage haze & practicals, energy arc

# 🎵 MUSIC & PERFORMANCE — domain craft
SCOPE GUARD: apply the lines that match the performance; skip the rest.

## The beat is the clock
State the tempo and let everything land on it: cuts, body hits, light changes, camera accents, a hand hitting a surface. A move that lands off the beat reads as an error, not as style. Decide which beat is the anchor (kick, snare, or a specific accent) and return to it after every section.

## Performance energy
Lip-sync must be legible — mouth shapes matching the phrase, jaw and breath visible, a head tilt on the long vowel. Energy has an arc across the clip: restraint in the first beat, build in the middle, full release at the climax, hold at the end. Sweat, breath and fabric movement prove the body is working.

## Stage and crowd
Practical lights inside the frame — pars, strobes, phone screens, a follow spot — with haze or smoke so beams read. Silhouette moments against a hard backlight; crowd bodies with their own independent motion; hands rising into frame at the drop.

## Choreography beats
Name moves with counts: step-touch on 1 and 3, hair whip on the drop, arm lift on the pre-chorus, freeze on the silence, formation break on the bridge. Group sections either hold formation or break it deliberately — never drift between the two.

## Camera per section
Locked hero frame for dance and formations · handheld push for the chorus · whip-pan or crash-zoom only on a musical accent · low-angle silhouette for the bridge · slow arc around a soloist for the outro. One camera idea per section, not per shot.

## Wardrobe and hair move with the beat
A jacket opening on a downbeat, a braid swinging on a turn, sequins catching a strobe — stylised but physically continuous, with mass and follow-through.

## Sound
The track leads. Live-room bleed only for a concert scene; foley (heel taps, breath, mic thump, cloth) sits under the mix. Keep the mix forward and dry on the voice.

## End frame
Land the final beat on a held image: a pose, a look to camera, a wide of the stage with the lights still going — never a fade-out mid-motion.
