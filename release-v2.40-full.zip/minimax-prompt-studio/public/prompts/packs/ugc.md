pack: ugc
label: 📱 Social & UGC
tags: ugc, social, reel, tiktok, creator, testimonial, unboxing, shortform
keywords: ugc, creator, testimonial, review, unboxing, haul, tiktok, reel, viral, influencer, vlog, selfie, honest, skeptic, hook, promo
categories: Social Media Content
stack-with: fashion, product
order: 15
hint: phone-real look, hook→demo→CTA arc, creator delivery, real rooms

# 📱 SOCIAL & UGC — domain craft
SCOPE GUARD: this pack owns the LOOK, the ARC and the DELIVERY. When a subject pack (fashion, product, food…) is also active, that pack owns how the subject behaves.

## Camera = a phone in a real hand
Slight handheld drift, autofocus breathing on a product the person brings closer, occasional imperfect framing, a wrist-turn re-grip, the front-camera wide look with a slightly bent horizon unless the framing is corrected. Never a rig-smooth dolly, never a locked studio frame, never a cinematic anamorphic flare.

## Room reality
Bedroom, kitchen, car, bathroom, balcony, shop floor — with a window or a practical lamp as the only source, slightly underexposed, mixed colour temperature, lived-in clutter at the edges doing background duty. Never a seamless backdrop, never a beauty dish.
Make the room say something about the person: a plant, a stacked mug, a laundry pile, a wall poster.

## Creator delivery
A person talks to the lens or narrates over B-roll, unpolished rather than rehearsed: a mid-sentence restart, a small self-deprecating laugh, a glance down at the product, a hand entering frame to point. Speech in quotes with tone and pace; keep every line short enough to say twice in the shot. CTA sounds like advice to a friend, never a pitch.

## Arc — compress to the requested duration
HOOK (0–3s): the surprising claim, the result, or the mess — something already happening in frame one, no wind-up. CONTEXT/PROBLEM (3–8s): one sentence of why it matters. DEMO (8–20s): the product doing its real job in real hands, with the consequence visible. CTA (last 3–5s): who it is for and what to do next.
Scale it: 5s = hook + one demo beat + CTA; 8s = hook + problem + demo + CTA; 15–20s = the full arc with two demo beats.

## Winning formats (pick one, do not blend)
- First-reaction unboxing: packaging foley, hands in frame, genuine surprise on the face, the reveal held one beat longer than comfortable.
- Skeptic testimonial: "I did not believe it" → what changed → who it is for → recommendation-style close.
- Before/after transformation: same framing, same light, the change happens on camera or via a hard cut.
- Problem → solution demo: show the failure first (the leak, the stain, the tangle), then the fix.
- Day-in-the-life soft sell: the product appears in a routine — morning, commute, desk, evening — narrated casually.
- Three-step how-to: step numbers spoken as they happen, hands always the subject.
- Comparison / POV: side-by-side or first-person framing that puts the viewer inside the moment.

## Captions & on-screen text
Any spoken line is written in quotes with tone; on-screen captions belong in post — never render text inside the generated video (the base rules ban baked-in text). Emphasise delivery through pacing instead: punch the key word, pause before the claim.

## B-roll intercut
Cut away to the product detail or the hands while the voice continues — the audio bed must stay continuous across those cuts so the result feels like one take of speech with coverage.

## Sound
Phone-mic realism: room tone that never drops, the true foley of the demo (clicks, taps, pours, fabric, packaging), music low and diegetic to the room, no score swell, no studio reverb.

## Grade
Honest phone colour, mild contrast, a slightly hot window, no teal-and-orange, no film grain. If the clip is a deliberate creator-style cinematic piece, say so and grade accordingly.

## End frame
The person mid-relationship with the product — holding it, using it, looking at the lens — not a posed hero shot.
