pack: vehicle
label: 🚗 Vehicles & machines
tags: vehicle, car, motorcycle, machine, automotive, transport
keywords: car, truck, motorcycle, bike, engine, wheel, drift, rally, supercar, train, plane, boat, cockpit, road, highway, racer, tyre, chrome, jeep, tractor, scooter
categories: 
stack-with: 
order: 50
hint: rolling shots, reflection logic, motion physics, engine-note sync

# 🚗 VEHICLES & MACHINES — domain craft
SCOPE GUARD: apply the lines that match the machine; skip the rest.

## Identity lock
Make and silhouette, paint colour and finish, wheel design, one signature detail (grille, badge, exhaust, headlight shape) — stated once, referenced briefly afterwards. Wheels must match across every shot: a changed rim reads as a different vehicle.

## Rolling shots
Camera car at matched speed with a shallow depth of field on the body and a blurred road rushing under it · low mount skimming the tarmac at wheel height · tracking alongside the front quarter at a constant distance · gimbal orbit at a fixed radius on a static hero · rear-follow through a corner as the body loads and settles. Wheel rotation and motion blur must match the actual speed — spinning wheels on a static frame is the fastest way to break the illusion.

## Reflection logic
Paint carries the world: sky gradient down the flank, passing trees strobing across the roof, streetlights sliding along the doors, wet-road reflections pulling the machine into the ground. Name what the surface reflects so the finish reads.

## Environment matched to the story
Mountain switchback with a valley drop · wet city night with neon on the paint · salt flat with heat shimmer · tunnel with repeated light strokes · gravel track throwing dust · dawn desert highway with long shadows. Weather on the road: spray behind the tyres, raindrops beading and streaking on glass, dust plumes hanging after the pass.

## Motion physics
Weight transfer into a corner, suspension compressing over a bump then recovering, tyre smoke and marbles on exit, brake discs glowing under hard use, exhaust heat shimmer, the chassis settling when it stops. The machine obeys momentum — nothing floats or slides sideways without a cause on screen.

## Detail beats (one per selling point)
Headlight ignition sweep · badge macro with the light raking across it · brake caliper and pad behind the spokes · stitching, dials and gear-lever throw in the cabin · key turn and screen wake · hand on the shifter · boot closing with weight.

## Sound
Engine note with a specific character — rpm rise and fall, turbo spool and wastegate chirp, induction flutter, tyre scrub, gravel rattle — landing exactly on the visual beats. Interior scenes carry road noise, wind and body resonance; a silent car reads as fake.

## Camera honesty
Do not use a move the world cannot explain unless the shot is explicitly aerial or rigged; a floating camera breaks the machine's weight.
