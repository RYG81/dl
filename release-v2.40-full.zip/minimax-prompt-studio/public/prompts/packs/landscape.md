pack: landscape
label: 🏔️ Nature & places
tags: landscape, nature, travel, drone, aerial, ocean, mountain, scenery
keywords: mountain, valley, sea, ocean, beach, forest, waterfall, desert, sunrise, sunset, drone, aerial, cliff, lake, snow, storm, canyon, jungle, glacier, aurora, meadow, waves
categories: Nature / Landscape
order: 35
hint: reveal order, drone grammar, weather as drama, real ambience bed

# 🏔️ NATURE & PLACES — domain craft
SCOPE GUARD: apply the lines that match the location and light; skip the rest.

## Reveal strategy
Choose the order and commit: tiny detail → wide grandeur (a frost crystal, then the whole ridge), or wide → intimate (the valley, then the lichen on the rock). A single human or animal element in frame gives the landscape its true size — a walker on the path, a boat on the water, birds crossing the ridge. Never an entire clip of postcard wides with nothing to anchor them.

## Drone grammar (one continuous move per shot)
Lateral push past a ridge · slow rise revealing the valley floor · orbit around a pinnacle at constant radius · descending crane into the tree line · pull-back from a subject to reveal the scale. Keep the horizon stable, the move single-direction, and the speed constant or deliberately eased. Never stack two drone moves in one shot.

## Weather is the drama
Name cloud shape and movement, a break of light sweeping the ground, a fog band, wind visible in grass, water or snow, spray on rocks. Time of day decides the palette: blue hour, golden rim, flat overcast, hard midday sun with black shadows.

## Motion channels (at least two live at all times)
Water flow and foam, grass and leaf sway, birds crossing, mist drifting, waves breaking and dragging back, cloud shadow travelling across a hillside, heat shimmer above a plain.

## Macro nature
Frost forming, dew on a web, rain hitting a leaf, sand moving grain by grain, an insect working — for texture subjects a single sustained macro can be the whole clip if the motion evolves.

## Composition
Rule of thirds or deliberate centered symmetry; foreground anchor (rock, branch, dune grass, a wet boulder) so the depth reads; the brightest element decides where the eye lands, so put the hero there. Verticals stay vertical; the horizon stays level unless the subject is the tilt.

## Sound
Layer real ambience: wind through named vegetation, water at a stated distance, one identifiable bird call, gravel underfoot, no music unless requested (then one sparse sustained tone that swells with the reveal).

## Honesty
No fantasy lighting, no glowing edges, no over-saturated leaves. The place should look like it did on the day, only better framed.
