pack: ethnic
label: 👰 Ethnic & bridal wear
tags: ethnic, bridal, sari, lehenga, traditional
keywords: sari, saree, lehenga, kurta, kameez, salwar, anarkali, ghagra, choli, dupatta, pallu, drape, zari, zardozi, embroidery, mehendi, haldi, sangeet, bharatanatyam, temple, traditional, ethnic, desi, indian, wedding, bridal, bride, jewellery, jewelry, jhumka, bangles, mangalsutra, potli
categories: Fashion / Lifestyle
stack-with: fashion
order: 12
hint: drape physics, regal performance beats, embroidery/jewellery inserts, jewel-tone light

# 👰 ETHNIC & BRIDAL WEAR — domain craft
SCOPE GUARD: apply only the lines that match the garment and the moment (a sari walk is not a bridal montage — pick the matching set); skip the rest. When the 👗 fashion pack is also loaded, that pack owns garment physics and camera modes; this pack owns drape culture, ceremonial beats and ornament inserts.

## Drape physics — the garment IS the movement
The drape writes every beat: a pallu floats on the turn, a zari or shimmer border glints as it travels, pleats sway with the walk, a dupatta lifts and settles a half-beat after her hand. Name the fabric and its behaviour (organza float, silk slide, net sheerness, georgette fall, velvet weight, brocade stiffness) and how the named key light plays on it — that is how the outfit reads as couture rather than costume.

## Sari / drape performance vocabulary — from the reference set
Fingertip pallu lift letting it flow · pleat or drape adjust (gaze down at the fabric, then up to the lens) · over-shoulder turn into a smile · hair tuck with head tilt · shy down-glance rising to eye contact · hip hand with a wall lean · playful side-glance · pallu drawn across the shoulder as she settles. Grace first: a new act every 1–1.5 seconds, and the hands almost always working the drape.

## Ornament-led beats (jewellery is a co-star)
Jhumka sway · bangle glint at the wrist turn · necklace or mangalsutra catch on a head tilt · maang tikka reading against the hairline · anklet in the walk · potli or ring in the hand beat. Give one ornament its own beat rather than dressing every beat with all of them. And the wearer comes first: an ornament-led film opens on her in the room with the whole set legible at real scale, every insert stays anchored on her skin and her garments, and no beat ever cuts to the piece alone.

## Ceremonial moments (pick the one the piece is about)
- **Bridal ready-and-composed:** two-hand bangle adjust at the waist, slow dupatta arrange, downcast serene gaze with one slow blink, composed chin tilt — stillness reads regal, only the ornaments move.
- **Sangeet / dancing:** step-touch on the beat, skirt or dupatta lift revealing a slit or lining, spin with the flare settling, clap pose overhead, jewellery keeping time with her — joyful, performed energy, eye contact on the accents.
- **Processional walk:** slow approach with fabric trailing, veil or dupatta lifted clear of the face at the last step, gaze rising to the lens on arrival.
- **Family / two-person beat (only if the idea asks):** a second figure adjusts a drape, offers a tray, or shares the frame — keep them a supporting silhouette, never a competing subject.

## Faceless inserts — anchored on her, never floating
Shoulder and blouse embroidery, hands folded with stacked polki bangles and a hand-chain, skirt pleats and embroidery rows, hanging latkan tassels, mehendi-covered hands turning in the light, a potli being closed. Cutaways must stay anchored on her body; if her face is not in frame the gesture still needs to belong to her.

## Light & mood
- Indoor elegance: soft window light or warm halo practicals; warm cinematic grade.
- Outdoor: golden-hour rim with cool shade; hard sun only if the idea asks for heat and dust.
- Ceremonial: deep jewel-tone backdrop (emerald, wine, midnight) with a candle-like key and raking light that lifts zardozi, velvet and beadwork; a warm practical or two as firelight.
- Quiet-luxury brand register: seamless cyclorama (warm grey, deep teal) or a dressed heritage set, soft diffused key or a dramatic rim on a dark backdrop.

## Signature reveals
Back-view turn showing cape or dupatta fall and the back detail · fabric-spread act — arms lifted wide to display the full print, then letting it settle · veil or dupatta drawn back to frame the face · embroidery macro insert anchored on her · a turn that lands her composed, centred, outfit fully readable.

## Beat density & rhythm
A new visible act every 1–1.5s (7s ≈ 5–6 acts, 12s ≈ 8–10). Montage rhythm when inserts are used: medium portrait beat → texture insert → ornament/hands insert → composed full or three-quarter finish. Serene is not static: fingers, breath, fabric and ornaments keep micro-moving every second, and no action spans more than 2s.

## LTX note
Compress into the single paragraph in this order: set and light → drape physics as she moves → one ceremonial or performance beat → ornament beat anchored on her → composed finish. Keep the frame rule inside the paragraph: the camera either holds steady while she performs or makes ONE motivated move that re-frames around her — she never leaves frame.
