pack: animation
label: 🎨 Animation & stylised
tags: animation, anime, cartoon, stylised, claymation, stopmotion, illustrated, papercraft, game, mascot, cg, retro, toon
keywords: animation, animated, anime, cartoon, claymation, stop-motion, illustrated, toon, puppet, pixel, doodle
categories: Animation
stack-with: 
order: 60
hint: medium lock, 12fps honesty, squash & stretch, illustrated effects

# 🎨 ANIMATION & STYLISED — domain craft
SCOPE GUARD: apply the lines that match the medium; skip the rest.

## Declare the medium in the opening clause and never drift
2D cel with line boil and flat fills · watercolour with paper grain and bloom edges · 3D with subtle subsurface and plastic sheen · claymation with fingerprint texture and thumb marks · stop-motion with visible armature seams and fabric fibres · cut-out collage with visible paper edges and shadow gaps. The medium decides every other choice.

## Frame-rate honesty
Hand-drawn and stop-motion read on twos or threes with a slight stutter and a held last drawing; 3D and spatial animation read smooth with eased curves. Never mix the two registers inside one clip, and never let a photoreal detail (skin pores, real lens flare, true depth of field, film grain) leak into an illustrated world.

## Motion laws
Squash and stretch on every impact, anticipation before a move, follow-through on hair, cloth, ears and tails, overlapping action so the parts do not stop together, and one held key pose at the end of each beat. Motion arcs curve rather than travel straight.

## Design language
Silhouettes must read at a glance (test each pose as a black shape in your head). Colour palette limited and intentional — 3 to 5 hues with one accent. Shapes matched to character: round reads soft, angular reads threat, tall reads authority.

## Effects in the medium's own language
Speed lines, impact stars, dust puffs, sparkle motes, sweat drops, flat water with a hard white highlight; effects keep the same line weight, palette and frame-rate as the world they live in. A particle sim with realistic physics in a hand-drawn world breaks it.

## Camera lives inside the medium
A 2D multi-plane pan with parallax, a paper-texture push-in on a cutout layer, or a hard frame change that reads as a cut — not a photoreal drone move or a rack focus with real bokeh. Perspective obeys the illustration's own rules, not a lens.

## Sound
Score-forward: state instrumentation and tempo, and let the accents land frame-exactly on the animation beats. Foley is stylised — a woodblock step, a slide-whistle run, a metal tap, a rubber squeak — never real-world foley over an illustrated action.

## End frame
The last held drawing: the pose the audience remembers, with the palette still intact and no motion blur left on screen.
