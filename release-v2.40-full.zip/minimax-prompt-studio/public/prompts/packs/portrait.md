pack: portrait
label: 👤 Portrait & people
tags: portrait, face, character, model, headshot, artist
keywords: portrait, face, headshot, gaze, elderly, eyes, close-up face, stubble, wrinkles, freckles
categories: 
stack-with: 
order: 70
hint: identity lock, micro-expression arc, face light, hands with a job

# 👤 PORTRAIT & PEOPLE — domain craft
SCOPE GUARD: apply the lines that suit this person and setting; skip the rest. If the clip is really about what they are WEARING, the fashion pack owns the garment choreography; this pack owns the face and the presence.

## Identity lock
Enumerate 3–5 defining features once (face shape, hair, brows, one scar or mark, one signature item) and reference them briefly afterwards. The face must remain recognisable across the whole clip and across any cut.

## The face is the action
Write a micro-expression arc, not one held expression: a blink that lands after a thought, the jaw loosening before a smile arrives, eyes moving before the head does, a swallow on a hard beat, breath rising in the chest, the smile fading rather than switching off. Micro-expressions are the whole performance at close range.

## Light for faces
One clear key with a soft falloff and an eye-light so the eyes live; a rim separating the hair from the background; negative fill for cheek and jaw shape; window light as the key whenever the space allows. Avoid flat frontal fill — it erases the face.

## Lens honesty
50–85mm compression, shallow but not creamy focus, focus on the near eye. Use foreground occlusion (doorframe, curtain edge, plant, shoulder of another person) to seat the person in a real room.

## Hands and posture
Give the hands a job — holding a cup, adjusting a collar, resting on a table, pushing hair, holding a phone. Let posture drift through the clip: a lean in, a weight shift, shoulders dropping on an exhale.

## Implied world
The out-of-focus background and reflections carry the room: city lights, a lamp, a TV flicker, a window with rain. Say what is soft rather than showing everything sharply.

## Breath and voice
If audio is present, breath is audible between lines; one exhale is released on the final beat. Keep any spoken line short enough to say twice in the shot.

## End frame
The person settled, eyes alive, micro-expression still resolving — the frame that feels like an interruption into a real moment rather than a pose.
