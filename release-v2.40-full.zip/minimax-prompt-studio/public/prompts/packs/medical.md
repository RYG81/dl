pack: medical
label: 🩺 Medical & science animation
tags: medical, medical-animation, science, anatomy, education, explainer, biology, health, pharma, patient-education, classroom, immersive, 360, vr180
keywords: anatomy, cell, cellular, neuron, nerve, heart, artery, vein, blood, organ, tissue, molecule, protein, dna, rna, virus, bacteria, immune, antibody, receptor, enzyme, hormone, mechanism, moa, disease, condition, symptom, treatment, therapy, drug, dose, vaccine, surgery, patient, clinical, microscope, biology, chemistry, physics, classroom, lesson, teaching, explainer, infographic, model, 360, equirectangular, vr, vr180, stereo, immersive
categories: Medical / Science, Medical / Education, Science / Education, Immersive / 360, Immersive / VR180
stack-with: product, cinematic, animation
order: 26
hint: mechanism as a physical event, plausible anatomy, no gore, no invented text (medical content is illustration, not advice)

# 🩺 MEDICAL & SCIENCE ANIMATION — domain craft
SCOPE GUARD: apply ONLY the rows that match the subject and the idea in front of you; skip the rest. This craft never overrides the base format rules, and it never overrides the style the request asks for (a cinematic MOA film and a bright classroom explainer want opposite lighting — obey the request).

## The one rule that ruins medical clips: mechanism is a physical event
"Improves blood flow" is not filmable. "The vessel wall relaxes, the channel widens, and the flow changes from a thread to a full stream" is. Before writing a beat, convert every claim into:
**what touches what · in what order · what visibly changes**.
If a beat cannot be drawn as three physical events, it is copy, not description — replace it.

## Accuracy without a textbook on set
- Name only structures you can place at the scale you are shooting. A capillary wall, a receptor, a protein, a nerve bundle and an organ are different worlds; never put two of them in one frame unless the shot is explicitly a multi-scale transition.
- When the exact structure is unknown to you, use a scale-appropriate equivalent and keep it generic (a channel, a transport protein, a signalling cascade, a cell surface, a fibre) rather than inventing a named part.
- Keep the visual grammar of anatomy consistent inside a clip: if the tissue is translucent, it stays translucent; if the model is matte clay, no part becomes glass for drama.
- Direction of flow, left/right, inside/outside and up/down must stay consistent across beats — a viewer who notices a flow reversing stops trusting the clip.
- Label colour coding means ONE thing only, and it holds for the whole clip.
- Anything meant for a patient must read as illustration, never as advice or diagnosis: no dosage, no brand, no before/after promise, no "cure" language on screen or in the description.

## Safety and dignity (non-negotiable)
- No gore, no wounds, no surgical field, no blood spray, no distress, no identifiable patient, no real clinical footage mixed with invented anatomy.
- External anatomy is generalised: age, sex and body features only as the science requires, never as spectacle.
- A diseased state is shown as a state, not as a horror: swelling, narrowing, inflammation, plaque, degeneration and repair all read better calm than shocking — and they read longer.
- Sound stays plausible: interior hum, fluid, breath-paced pulse, a soft contact on an event. No library whooshes, no sci-fi zaps, no alarm tones, no heartbeat-as-jump-scare.

## On-screen text — the one place H3 will write for you
H3 renders text written as English quotes verbatim, which is exactly what a labelled teaching model needs — and exactly what ruins a cinematic medical film.
- **Classroom / labelled explainer:** allowed and useful. Keep it to **three labels maximum**, 1-3 words each, plain sans-serif, horizontal, spell them exactly as the request gives them, and never let a label sit over a turning part where it will smear.
- **MOA film, disease-state film, hybrid explainer, 360/VR180:** no text at all. No labels, numbers, arrows, charts, captions, split screens or logos. The science must be carried by form, motion and light.
- Never invent a label the request did not give, and never translate one.

## Lighting and materials by format
- **Cinematic science (MOA, disease state):** deep neutral background, lit from within, subsurface scattering, one slowly moving key, shallow depth of field at true macro scale, restrained palette (clinical teal, haemoglobin red, bone ivory). The subject is the only lit thing in frame.
- **Classroom explainer:** bright even studio light, large soft key, fill in front, plain pale background, a soft contact shadow, matte model surfaces with a slight sheen so edges read. No mood, no background props, no dramatic shadow — clarity is the aesthetic.
- **Hybrid real + 3D:** the real half keeps its own honest light, the 3D half keeps the scientific lighting, and the two halves must match in angle, light direction and distance across the cut, or the illusion of "the same object, seen inside" collapses.
- **Immersive (360 / VR180):** lighting must come from inside the field of view, never from behind the viewer; keep detail out of the polar bands in equirectangular, and keep the near two metres alive in VR180.

## Camera grammar at scale
- Scale must be declared and continuous: name it in the beat (this is a capillary, this is a whole organ) and never drift scale inside one shot without a deliberate, described transition.
- Moves are slow: a descent, a lateral travel along a surface, a pull-back to reveal, a push-in to an event. Fast moves kill comprehension and, in stereo, kill the depth.
- One mechanism step per shot. If two things change at once, the viewer follows neither.
- In the classroom format, one idea per shot and every move slow enough to follow; in the cinematic formats, the camera can travel as long as the physical logic of the journey holds.

## Sound beds
- Interior (inside the body / inside a cell): low hum, pulse, fluid movement, one soft contact per event. Mixed close and dry.
- Classroom: clean neutral room tone, a soft click when a part moves, handling sound if a hand presents the model. Silent enough for narration to be added later.
- Hybrid: the real half keeps room tone and handling sound, the 3D half keeps the interior bed, and the level must not jump across the cut.
- Immersive: near sounds close, far sounds held back, no single sound hard at the front, and no intelligible speech anywhere in the soundscape — a line belongs in the description as dialogue, never in the ambience.

## Immersive projection rules (360 / VR180)
- **Equirectangular:** horizon on the vertical middle line, nothing straddling the wrap seam, detail kept out of the zenith and nadir bands where the projection stretches, repeating continuous forms near the edges, no cuts, no horizon tilt.
- **VR180 stereo:** one continuous take, slow moves only, subject held roughly 1.5-4 m away, nothing crossing the half-metre in front of the lens, one subject rather than a crowd, no text anywhere (the two eyes disagree on it), and a deliberate near/mid/far depth stack so the stereo has something to measure.
