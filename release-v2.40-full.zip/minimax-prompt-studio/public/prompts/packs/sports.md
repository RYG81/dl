pack: sports
label: 🏃 Sport & action
tags: sports, sport, athlete, action, fitness, workout
keywords: athlete, sprint, runner, football, cricket, basketball, tennis, boxing, gym, workout, training, match, race, swim, skate, climb, goal, surfing, cyclist, goalkeeper
categories: 
stack-with: 
order: 75
hint: peak-moment grammar, speed ramps, body mechanics, impact-accurate sound

# 🏃 SPORT & ACTION — domain craft
SCOPE GUARD: apply the lines that match the sport; skip the rest.

## Peak-moment grammar
Choose the decisive instant — contact, take-off, release, the plant of a foot, the top of a jump — and build the clip around it. Approach in real time, ramp slow just before the instant, hold the impact crisp, then explode out of it. One speed change per beat; a clip that is all slow motion has no peak.

## Body mechanics, named
Write the actual chain: heel plant → hip rotation → shoulder drive → wrist snap; or crouch → load → extend → land soft. Add the evidence: sweat flicking off a ponytail, breath fogging cold air, muscles loading before they fire, the face in concentration or a grimace, a hand taping a wrist.

## Surfaces react
Turf divots flying, chalk dust rising, water spray off a board, sand exploding on a landing, gravel scattering, mat condensation squeezing out, rope vibration, a shoe squeal on the floor. The ground is a co-performer.

## Camera options (one per shot)
Long-lens tracking from a distance with compression and heat shimmer · low tarmac-level pan as the athlete passes through frame · handheld chase inside the action with the frame fighting to keep up · drone rising over the arena for the wide emotional beat · a locked frame for the technique study so the mechanics read clean.

## Arena and environment
Flooded overheads with a visible flare, darker terraces with phone lights, flags and bodies in motion behind the action, morning mist over a field, rain slanting through a stadium light. Name one environmental channel in motion.

## Sound
Impact thuds and the slap of a hand on leather must be sample-accurate to the visual contact; footfall and breath are the rhythm bed; crowd swell timed to the moment; whistle, umpire call, shoe squeal, net snap. Music only if it belongs to the event (crowd PA, warm-up).

## End frame
The release or the recovery — chest heaving, ball settling, a hand raised, the athlete bent over their knees — never a body stopped in mid-air.
