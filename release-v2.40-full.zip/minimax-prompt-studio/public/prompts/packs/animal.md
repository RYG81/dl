pack: animal
label: 🐾 Animals
tags: animal, pet, wildlife, bird, dog, cat, creature
keywords: dog, cat, puppy, kitten, pup, bird, wolf, horse, tiger, elephant, lion, animal, wildlife, pet, fur, feather, paws, cub, fox, bear, monkey, rabbit, goat, cow, sheep, deer, squirrel, owl, eagle, duck, whale, dolphin, penguin, turtle, lizard, snake, bee, butterfly, insect, retriever, labrador, beagle, corgi, terrier, spaniel, tabby, siamese, kitten, pig, rooster, swan, seal
categories: 
stack-with: landscape
order: 45
hint: true ethology, fur/feather texture, animal-tempo beats, honest sound

# 🐾 ANIMALS — domain craft
SCOPE GUARD: apply the lines that match the species; skip the rest.

## Ethology first — write what the species actually does
A cat's slow blink, tail flick, knead, ear rotation · a dog's play bow, shake-off, tail-set change, head tilt before a pounce · a bird's head-tilt before take-off, feather settle after landing, preen · a horse's ear swivel, hoof paw, nostril flare, weight shift · a big cat's shoulder-driven stalk with a low head. Never anthropomorphize posture, never give an animal a human expression or a human pause.

## Eyes, fur, feathers
Rim light separating fur strands, wet nose sheen, whisker silhouettes against backlight, feather overlap and iridescence, tongue texture, paw pads on a hard floor. A macro beat on a paw, an eye or a wing gives the clip its life — anchor it on the animal, never a floating detail.

## Beat tempo comes from the animal
Stalk speed, tail-wag frequency, wing-beat rate, herd drift, the sudden stillness before a pounce. Beats land on the animal's own rhythm rather than a human editing pulse; when a CUT is used, cut on the animal's movement — a head turn, a leap, a landing.

## Physics the animal leaves behind
The shake-off spray in slow motion (fur flattening, then springing back, droplets catching the light) · dust kicked up · sand or snow displaced · leaves disturbed · claws on bark · a bowl pushed across the floor · grass springing back after the body passes.

## Interaction with the world
The animal must be DOING something to something: pushing a bowl, batting a toy, digging, climbing, carrying, herding, drinking, pushing a door open. Unmotivated sitting idles the whole clip.

## Camera honesty
Long lens with shallow focus and compressed depth for wildlife — imply distance and never suggest stress; handheld macro at floor level for pets, putting the viewer inside the animal's world; slow follow at the animal's eye height so the body reads through the whole move.

## Sound
Species-specific vocalization placed at the real beats (one identifiable call, not a loop), breath and footfall, tongue and water, the ambient habitat bed. No cartoon effects, no orchestral swell unless asked.

## End frame
A held natural behaviour — settling, an ear flick, a head turn toward the lens, the body relaxing — never a posed stare into the camera.
