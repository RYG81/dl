pack: product
label: 📦 Product & object
tags: product, ecommerce, gadget, tech, packshot, packaging, minimalist
keywords: product, bottle, phone, gadget, device, packaging, unboxing, packshot, headphones, smartphone, laptop, watch, keyboard, serum, cream, cosmetics, flask, speaker, bottle, perfume, sneaker
categories: Product Showcase
stack-with: ugc, fashion, animation
order: 20
hint: material macros, orbit hero moves, spec beats, hands-off staging

# 📦 PRODUCT & OBJECT — domain craft
SCOPE GUARD: apply only the lines that suit this object and shot; skip the rest.

## Object bible
Lock the object in one clause: form factor, material, finish, colour, and where the brand mark sits. Repeat it briefly in later beats ("the same brushed-steel flask") — never re-describe it as new information. One object per clip unless the idea is explicitly a comparison.

## Surface physics — say how the material behaves in light
- Brushed / bead-blasted metal: a broad soft specular that sweeps as the object turns; fine anisotropic streaks.
- Polished metal, chrome, glass: a hard mirror highlight carrying the room (window bars, softbox edge, the operator's silhouette); reflections must move with the object, not sit on it.
- Matte ceramic / rubber: soft gradient falloff, no hotspots, texture held in the shadow side.
- Fabric / leather goods: grain catching a raking light, creases responding when pressed, edge stitching legible at macro.
- Liquid, gel, cream: viscosity named — a slow beaded pour, a glossy mound that settles, a drip that holds then releases; surface tension reads as a highlight ring.
- Transparent / frost: refraction of the background, caustics thrown on the surface below, condensation beading then running.

## Hero moves (one per shot)
15–30° turntable or arc · constant-radius orbit · slow dolly across the face of the object · top-down reveal with the object rotating · lift-and-settle onto a surface with one secondary motion (cap click, liquid slosh, lid snap) · macro push to the mechanism, port, logo or texture.
Keep highlight motion continuous — a specular that jumps between frames reads as plastic.

## Light & set
- Strip-box speculars for edge definition, a gradient sweep or a dark void behind for separation, a rim to lift the silhouette off the background, contact shadow so the object sits on something real.
- Set surface chosen for material contrast: stone, linen, water, brushed concrete, glass. Reflection floor for glossy goods; atmosphere (steam, mist, dust motes) only if the product story justifies it.
- Props only when they give SCALE or context (a coin, a hand, a ruler, a mouthful); they must never compete for the frame.

## Spec beats — one selling point per beat, no faster than one per second
Name the part and the demonstration: button press with a click, cap unscrew and the thread turning, hinge travel, clasp release, spray cone, pump compression, pour and stop, zip run, screen waking, LED sequence. Each beat = a verb plus its consequence.

## People in product clips
Prefer hands-only or a partial figure (shoulders, forearm, silhouette). If a model appears, they stay secondary: their wardrobe must not carry more visual weight than the product, and the face never steals the hero beat.

## End frame
The commercial close: brand mark facing the lens, label legible, object centered, key light on the hero surface, highlight and shadow both still readable.

## LTX note
Compress to: object bible → the move and its material behaviour → one spec beat with its consequence → the set and light → the composed commercial close.
