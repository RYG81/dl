pack: food
label: 🍽 Food & drink
tags: food, drink, cooking, kitchen, restaurant, coffee, beverage
keywords: food, dish, coffee, tea, cake, pizza, noodles, ramen, steak, burger, dessert, steam, sizzle, kitchen, chef, plate, curry, chocolate, cocktail, bread, cheese, salad, chai
categories: 
stack-with: 
order: 40
hint: appetite light, sizzle/steam/pour beats, texture macro, ASMR foley

# 🍽 FOOD & DRINK — domain craft
SCOPE GUARD: apply the beats that match the dish; skip the rest.

## Appetite light
Backlight or side-back so steam, oil sheen, condensation and sauce gloss glow; one bright specular on the wet surface; fill only enough to keep shadow detail. Never flat frontal light on food — it kills texture and reads as a flash photo.

## The beat list (scale to the dish, one per beat)
- The pour: viscosity named — a slow beaded stream, a glossy mound that settles, a drip that holds then releases.
- The steam curl: backlit, drifting across the frame, changing shape beat to beat.
- The sizzle: oil popping at the pan edge, an ingredient laid in, an audible crust forming.
- The pull or stretch: cheese, dough, caramel, mochi — tension until it snaps.
- The break: crust cracking, yolk giving way, chocolate shell splitting, a crispy top shattering.
- The drape: sauce poured over an uneven surface, running and pooling in the valleys.
- The build: layers assembled in real hands, ingredient by ingredient, in a rhythm.
- The cold contrast: frost blooming on the glass, ice settling, carbonation rising, condensation running.
- The final garnish landing on the hero surface — the last beat before the held frame.

## Textures must sound like what they are
Name crispness, glaze, crumb, char, sheen, and match the foley exactly: crack, sizzle, fizz, pour, crunch, slurp, cling, dome-pop. The sound design is half the appetite.

## Hands & tools
Partial human presence sells it: a hand entering to break the crust, chopsticks lifting, tongs turning, a spoon sliding under the sauce. Fingers stay clean, out of the hero's light, and never cover the gloss.

## Camera
Macro push into texture · slow arc over a plated dish · top-down for pattern and symmetry · low pan across a table at plate height · handheld push toward the sizzling pan. One move per beat; the food stays in the same light across cuts so it reads as one meal.

## Kitchen & chef scenes
Real kitchen light (a window plus an overhead), stainless reflections, backsplash steam, motion in the background — a pan tossed, a plate wiped, a cloth thrown over a shoulder. Heat, flour dust and water are the atmosphere channels.

## Drink craft
Ice clinking and settling, bubbles rising in a column, the pour breaking on the surface, condensation beading then running, a garnish drop; backlight so the liquid glows amber or clear.

## End frame
The dish presented and still alive — steam rising, gloss uneaten, best light on the hero surface, the plate composed rather than styled to death.
