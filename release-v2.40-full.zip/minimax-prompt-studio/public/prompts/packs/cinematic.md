pack: cinematic
label: 🎬 Cinematic & narrative
tags: cinematic, film, narrative, drama, longvideo, scroll
keywords: cinematic, film, drama, noir, moody, grainy, thriller, character, narrative, monologue, silhouette, twilight
categories: Cinematic Film Scene
order: 30
hint: motivated camera, blocking as story, film-stock light logic, atmosphere

# 🎬 CINEMATIC & NARRATIVE — domain craft
SCOPE GUARD: apply the lines that suit this scene; skip the rest.

## Declare the look in the opening clause
Stock or format + era + light logic in one breath, so everything after inherits it: "Kodak 500T pushed one stop, hard practicals, deep shadow", "shot on video, flat 1980s soap lighting", "digital clean, cool overcast, no fill". Name the grade in words, not as an instruction: "cool shadows, warm skin, low saturation, fine grain, soft highlight halation".

## Motivated camera
Every move needs a reason inside the world: a character walks and the camera follows; a door opens and the frame drifts with the draught; the operator reacts a half-beat late to something happening off-frame. No unmotivated orbit, no drone move the scene cannot explain.

## Blocking is the story
Decide where the body goes and why — crossing to the window, sitting on the crate, turning away from the news — then let camera and lighting serve that path. The frame should record the decision, not announce it.

## Light from the world
Windows, lamps, fire, headlights, neon signs, TV screens, a fridge door. Name the falloff and what stays dark. Practicals inside the frame are the cheapest way to make a scene feel real; a screen flicker on a face reads instantly as time passing.

## Lived-in environment
Dust in the beam, wear on surfaces, background life at the edge of frame (a distant car, a hanging cloth, a stranger crossing), weather active if it fits. Never a blank stage: the room should have been there before the character arrived.

## Arc inside any duration
ESTABLISH (where, who, one hook detail) → ESCALATE (the single thing that changes) → LAND (reaction or a held image with forward momentum). Even a 5-second clip gets all three; a 12-second clip gets the middle one twice, not the same beat stretched.

## Atmosphere channels
Haze, steam, embers, rain on glass, smoke curling, a curtain breathing, insects in the light — keep at least one atmospheric channel moving through the whole clip.

## Restraint
No explainer voiceover unless asked, no music-video cutting, no orchestral swell under dialogue, no slow-motion without a motivated beat to slow down, no filter that fights the light logic you declared.
