pack: fashion
label: 👗 Fashion & styling
tags: fashion, try-on, ootd, garment, lookbook, apparel, clothing, beauty
keywords: outfit, dress, sari, saree, lehenga, skirt, jacket, coat, blouse, gown, jeans, kurta, wardrobe, garment, styling, lookbook, model, runway, bridal, heels, handbag, dupatta, try-on, haul, ootd
categories: Fashion / Lifestyle
stack-with: ugc, product
order: 10
hint: garment physics, performance beats, glamour light, frame discipline (ethnic/bridal craft → 👰 pack)

# 👗 FASHION & STYLING — domain craft
SCOPE GUARD: apply ONLY the rows that match the garment and the idea in front of you; skip the rest. This craft never overrides the base format rules.

## Garment intelligence — movement must derive from the clothing (never reuse a fixed sequence)
Before writing ANY beat, silently classify the garment: fabric weight and drape, silhouette, construction, and what actually sells it. Then choose ONLY the movement verbs that physically demonstrate it. Two different garments must never receive the same choreography.
- Flowy / lightweight (chiffon, tulle, maxi, flowing dress): spin and twirl, walking with fabric trailing, weight shifts that make the hem flare and settle; show the drape falling back after the movement.
- Structured tailoring (blazer, coat, sharp shoulders): crisp quarter turns, confident walk, hands settling lapels and shoulders, pocket beats; stillness and posture are the story — fabric does not fly.
- Knits / soft casual: cozy micro-gestures — sleeve pulled over the hands, collar adjust, a pinch that shows softness, relaxed sway; texture close beats.
- Denim / leather / heavy weight: angular poses, pocket beats, jacket flipped onto the shoulders, zip and button play; hard stops, minimal sway, attitude over fabric motion.
- Body-hugging (knit dress, bodysuit, slip satin): slow controlled turns, weight shifts tracing the silhouette, seated-to-standing beats; satin catches light — let a window rim light slide across the fabric.
- Streetwear / oversized: bounce, hop, swagger walk, jacket flip, exaggerated pose snaps on the beat; motion amplitude matches the volume of the garment.
- Accessories-forward (bags, jewelry, shoes, hats): dedicated detail beats — bag swing and strap adjust, wrist turn in the light, step-in and heel pivot, hat tilt.
- Activewear / swim: full dynamic range — stretch, jump, run-in-place energy; fabric performance and body lines are the point.
Selection rules: name the fabric's physical behaviour inside the beat ("the chiffon flares, then settles"); match beat SPEED to fabric weight (light fabrics float in slow graceful beats, heavy garments snap in crisp short ones); if the idea names no garment, invent one specific garment and derive from it; never copy a previous clip's choreography — re-derive every time.

## Colour — the garment carries one, always
A garment with no colour named renders as white, and white is the model's default, not a decision. Before any beat is written:
- NAME the garment's colour and its finish in the same phrase ("oxblood brushed wool", "cobalt satin with a liquid finish"). A silhouette and a fabric are not a look.
- NEVER default to white, ivory, cream, ecru or beige. Use them only when the user asked for that, when the style type demands it (a bridal white, an optic-white poplin shirt) or when you contrast them against a saturated room. If the room is white or brightly lit, the garment must be the colour that carries the frame.
- Three colours maximum per look, with areas: body 60% · secondary 30% · accent 10%, plus one metal family (all-gold or all-silver, never both).
- State where each colour sits: body, trim, lining, hardware, footwear. A colour with no location drifts in the render.
- Colour must be placed against the light: say how the room's key changes it — raking light deepening a weave, a warm practical turning blue to teal, a hard shaft flattening a matte into a silhouette. Never let the grade decide the garment's colour.
- Deep and saturated mid-tones survive a 2K render better than pale ones; if the brief genuinely wants white, give it texture (broderie, slub, heavy rib, sheen break-up) so it does not blow out into a blank.
- Rotate the colour family across variants: two variants of the same template must never share a garment colour.
- Colour is never a substitute for construction detail and construction detail is never a substitute for colour — a finished look states both.

## Acting & secondary beats
Choose 2–3 secondary acts per shot and name the micro-expressions: chin lift · slow blink · a smile that forms and fades · glance off-camera and back · breath rising in the chest · fingertip tracing a lapel · cuff or strap adjust · hair sweep with follow-through · weight shift with hip cock · heel pivot. The face performs as much as the fabric.

## Glamour light pack
Soft beauty key at 45°, rim/hair light separating her from the set, gentle negative fill; specular glints on satin, silk, earrings, nails. Evening glamour may swap window light for warm practicals plus a cool rim. Mood = campaign confidence, never a catalog.

## Bridal and occasion — three registers, pick one and commit

**Heritage** — ritual, heirloom, craft-forward: see the register below. **Modern glamour** — this decade's couture: sculptural corsetry, liquid metallics, crystal, architectural rooms, high jewellery worn as styling. **Heirloom editorial** — one deep hand-embroidered bridal look (oxblood, crimson, marsala, rani pink) shot on a single seamless ground: the veil drawn across the face, the worked bodice, skirt border and belt at true macro on her body, a back beat, a calm face close. Its money is HAND work — zardozi with dabka, resham, marori, pearl-and-bead fringe, kiron, a deep worked hem — with antique gold jewellery (choker, tikka, studs) and the camera locked off; heavy hand work is wanted there, and machine mirror or sequin sparkle is not. Choose by what the request asks for, never mix them by accident, and never default to heritage: "modern", "contemporary", "glam", "luxury" or "couture" means the glamour register (no haveli, no jharokha, no marigold, no mirror work, no heirloom banarasi, no matching polki-kundan parure). In the glamour register an Indian request stays Indian-modern — Indian silhouettes built like couture (corseted lehenga, pre-draped concept saree, saree-gown, cape lehenga), Indian high jewellery (a choker with its maang tikka, a nath, stacked bangles, a kamar bandh), Indian glam beauty and an Indian contemporary set — and never a Western gown, ballgown or atrium on an Indian bride. The money is in construction and material — duchess satin, silk gazar, satin lamé, tulle, boned corsetry, a horsehair hem, hand-set crystal, a cut-out closed by a gold bar — and the jewellery is one dominant high-jewellery piece with the rest fine and quiet: a diamond rivière choker alone, a body chain across a bare back, an ear cuff climbing the helix, layered fine diamond chains.

## Bridal and occasion — the heritage register

A bridal look is a DESIGN, not a costume, and the difference is naming. Ask for the piece, not the category:

- **Fabric and weight first** — and say which direction: the LIGHT register (raw silk, tissue, organza, dupion, brocade, chanderi — a look that moves) or the HEIRLOOM register (deep red or marsala with heavy hand-embroidered blouse, skirt and veil border). Both are current. What is over is MACHINE sparkle: the all-over mirror "disco ball" skirt, industrial sequin scatter, and "zari work" with nothing named.
- **Silhouette + blouse cut** — cape lehenga, pre-draped saree-gown, fish-cut or mermaid line, jacket lehenga, heirloom re-cut; the blouse is the hero piece (corset, sweetheart, off-shoulder, shirt-cut, halter, high neck with a covered back).
- **One embroidery TECHNIQUE with its motif** — gota patti vines, zardozi border, bandhani dots, meenakari, jaali, kasab edging. "Zari work" with nothing named is how a bridal look turns generic.
- **Colour** — oxblood, old rose or dusty pink, ivory-and-gold, champagne antique metallic, emerald, sapphire, sage or pistachio, butter yellow, or an ombré; a contrast blouse modernises a traditional silhouette.
- **Jewellery is styled, not listed** — one DOMINANT piece with every other piece answering it: a close choker with ONE long haar, polki kept raw and uncut, temple gold for the traditional register, pastel stones (aquamarine, rose quartz) against a pastel garment, sleeker chains instead of heavy mangalsutras.
- **Balance is the craft** — an oversized maang tikka or matha patti runs with medium earrings and a quiet choker, never full jhumkas as well; a wide choker takes a single long haar; one metal family with its finish named, stones chosen against the garment's colour.
- **The veil is styled, never just draped** — a scalloped organza cape instead of a dupatta, a double dupatta (one over the head, one over the forearm), a pleated sash, a pearl-edged net; say which edge is finished and how it is held.

## Layer stack — an outfit is never one garment

Gaps are the most common way a fashion render goes wrong: the model is told about one piece and invents the silence around it — a jacket with no trousers, a corset with nothing under it, a skirt with no top. Write the stack top to bottom and never leave a layer out:

1. **Base layer** — named ONLY when it is seen. If the outfit is sheer, translucent, net, plunged, open-backed, cut out, slit or cropped above the waist, say exactly what touches the skin there: camisole, bodysuit, bralette and brief, vest, petticoat, or the garment's own lining. A closed, lined look names NOTHING here — inventing a camisole or a bra for an outfit that covers everything is exactly how visible underwear gets rendered.
2. **Main piece** — the garment the request is about, fully constructed (cut, fibre, closure, hem).
3. **Bottom or lower half** — trousers, skirt, shorts, the draped lower half of a sari or lehenga. A top with no bottom is an incomplete outfit.
4. **Outer layer** (only if the look has one) — jacket, blazer, coat, kaftan, dupatta, cape. An outer layer is always shown over a named inner GARMENT (a shirt, a blouse, a knit) and a named bottom — never bare, and never a base layer it does not need; a bare chest under an open coat is not a look, it is a missing shirt.
5. **Footwear and accessories** — named, wearable, and consistent across every shot.
6. **Continuity** — the stack never changes between shots of one scene; if she takes something off, the next beat says what she is wearing underneath.

Special cases: swimwear and lingerie are described as the complete piece set (top and bottom, or the piece and what it is worn with); a dress, sari, jumpsuit or kaftan is a whole garment and needs no separate bottom, but still needs its base layer when the cut exposes one; a body-con piece needs its bottom and footwear stated, but a base layer only where the fabric is genuinely sheer — opacity decides that, never cling.

## Jewelry and accessories — the wearer is in frame

An accessory with nobody wearing it is a catalogue shot with no scale. Whenever the piece is the point — jewellery, bags, shoes, hats, watches, hair pieces, embroidery — the camera goes:

1. **On her first.** A full-length, seated three-quarter or waist-up frame in which the whole look and the whole set read at real scale. This frame is the measuring stick: after it, every close shot is understood as worn.
2. **In context next** — the set on her at mid scale: the necklace over the neckline with the collarbone and throat in frame, the bag held against the waist with the skirt behind it, the shoe on the foot with the ankle and hem in frame.
3. **True macro only after that, and still on her** — the fastening at the nape, the ring on a hand resting at the waist, the earring against the jaw, the pendant lying on skin. Skin, hair or fabric is the ground of every insert, and the garment stays at the edge of frame so the colour does not fall out.

Never cut to the piece alone on a tray, on velvet or floating on black; a floating macro of an ornament has no size and no wearer. Micro-movement only (breath, a chain settling, one hand lifting a pendant, a chin turning a degree) and the film ends on her — a held close with the set still readable, or, only when the request names a brand, a wordmark still with the piece still visible on her.

## Movement, presentation, camera and cuts — derived per generation

A shot list copied from another clip is the fastest way to make a good garment look generic. Four things are re-decided for every idea:

| derived from | the question | the law |
|---|---|---|
| **the garment's physics** | what can this material actually do? | chiffon/tulle/dupatta fly, trail and settle a beat late · tailoring turns a quarter and stops dead, fabric never flies · knit moves in small familiar gestures · satin, latex, sequin carry the light across the surface · denim, leather and brocade move as one piece and stay where they land · a lehenga's pleats swing and restack, ornaments swinging a half-beat behind |
| **the presentation** | what is being shown, and how? | an ornament or accessory is a ladder — she is established first, then the set in context, then a true macro still on her body, one named piece per beat · a dressing sequence is the order she puts things on, the fastening is the action · a walk is the approach and the frame grows by her walking, never by a zoom — but a walk is two to four grounded steps, never a crossing (see Motion below) · a turn shows the back for a moment inside its own beat and comes back; the film stays face-forward |
| **the camera** | where does it start and how does it move? | establish at the scale that holds the whole look, then tighten by cutting. A rack focus or a push-in inside one shot is a beat, not a cut. One continuous move is one shot |
| **the cut** | what makes a good cut point? | the peak of a movement — the widest point of a flare, a footfall, the settle after a turn, a glint, a clasp click. A cut mid-gesture kills the gesture, and a cut mid-sentence kills the line |

How many beats exist is set by the live runtime (one beat per 1.5–2s, never two shots with the same verb), and the flow library sets their order. The **shape** of those beats — the rhythm envelope, the scale ladder, the cut motivation and the framing device — is a separate draw per generation from the FORM pools, and two variants of one template never share them: see `RHYTHM` in the motion plan and `NEVER SHARE AXES` in the variation contract. The option lists you write into a template are the grammar the garment can choose from — not a fixed sequence to reproduce.

## Motion — the walk is a walk, and the mark is continuous

Two faults make a locked-camera film read as a slideshow of jumps instead of a filmed shoot, and both come from the same place: asking the model for movement it cannot physically animate.

**REALISM FIRST — A CAPTURE, NOT A RENDER.** Say the realism instead of assuming it: skin keeps its texture, its fine hair and its own unevenness; fabric keeps its weave, its fibres and the marks of a day; surfaces keep their wear; the light behaves the way it does in the room. Micro-imperfection is welcome — a crease, a stray thread, dust in the air, a smudge on a surface — as long as it never takes a beat. Name the material proof per register (the twill's diagonal weave, the wool's nap, the yarn's fuzz, salt drying on skin, lace as thread with its own shadow) so the detail is specific rather than a promise. Refuse the render look: no smoothing, no plastic sheen, no beauty filter, no glow, no morphing or warping, no floating objects, no extra fingers or limbs, no text or logo anywhere in frame. Where the register is intimate or swimwear, the realism obeys that register's own guards — the camera height, what stays worn, and no reveal.

**THE SPACE HAS DEPTH AND DRESS.** A fashion film is never shot in a bare room: the location is built in three planes — a NEAR plane just inside the frame (a doorway or counter edge, a rail, a curtain, a chair back, a plant, a crate), the MIDDLE where she stands and the beat happens, and a FAR plane that recedes with its own architecture, material and light (a window, a corridor, panelling, a courtyard, a lit opening, a shaft across the floor). Name the materials — plaster, limewash, stone, terracotta, wood grain, brick, brass, cane, glass, velvet — and two or three real objects that give the place life (a lamp that is on, a chair with a throw, books, a mirror, a bowl, a rug, a potted plant, a workbench), plus one practical source in the room so the space has its own light signature. Depth is shown, not travelled: overlapping planes, light falling off into the distance, a near object softly out of focus. THE DRESS STAYS DRESS: nothing moves on its own, nothing takes a beat, nothing blocks her mark, nothing sits hard behind her head, no text or branding, no other people, no extra garments, no religious or culture-specific object unless the request named it — and a minimal set is a choice the request can make, never the default.

**A walk is a walk, not a crossing.** An entrance is **two to four steps taken in real time at about one step per second** — never a journey across the room, because a distance the model cannot cover inside the beat is rendered as a hop, a glide or a teleport. Name the floor under her, the **heel-then-toe contact**, the weight passing from foot to foot, and that **both feet are never off the floor at once**. Keep the **floor and her feet in frame** for the whole walk beat (cropped at the waist there is no ground reference and she floats), give the walk **its own beat of at least two seconds**, and let **the cut land on her stop, never mid-stride** — a cut inside a step is what makes one walk read as a jump between two positions. Second persons and furniture never walk: if a reflected or companion figure moves, she is the only one who crosses.

**The mark is continuous.** With the camera locked, she does not relocate between shots. The walk happens **once**, in the opening beat, and **every later shot finds her on the same mark** — the cuts change scale, angle and what she does, never where she stands. A subject who reappears somewhere new after every cut reads as a jump even when each shot is perfect. A film that genuinely needs her in a second position earns it by showing the steps that got her there, or by cutting to her already settled with the movement inside the shot.

**The film is face-forward.** At most **one** beat shows her from behind, about a second, and only when the idea names what is to be read there (the ties, the nape, the veil's drape, the low bun). Never open on her back and never close on it: the first and last shots are toward the lens. Write a turn as **three-quarters away and back inside the same beat**, not as "she turns through a full back view" — an open-ended turn is an invitation to finish the film behind her.

**The cut is the only honest scale change** when the camera is locked: she steps in, or the edit tightens. A film whose framing changes because the lens crept is not following either law above.

**THE MODEL IS 20 TO 32 — young, beautiful, fashion-model quality — unless the request names an age.** Cast her inside that band and write ONE age, not a range: a stated age is a lock the renderer cannot drift from, and across variants of one run it is the SAME woman, so the age, the face and the body are repeated exactly while the clothes, the room and the acts change. The register is the current editorial/runway one — clear skin with real texture, defined bone structure, even features, long limbs, healthy and camera-ready, presence rather than a pageant smile. An age named in the request wins over the band and then becomes the lock. Never cast a teenager or a child-like face or body, and never a school setting that implies one; if a brief asks for under-20, she is an adult of 20 or over. A template that explicitly asks for a real-person register (a UGC creator, a `not a model-perfect cast` note, a character reference) keeps that register — but she is still an adult and still in the band unless the request says otherwise.

**Every beat carries one micro-gesture — never stillness.** A beat with nothing moving is the other way a batch clones itself: the model returns the same frozen pose every time it is told to hold. Write one specific small action into every beat — a grip, a breath that lifts the veil edge, a wrist turning, a gaze leaving and returning, a weight shift — with the micro-level named (hand position, gaze angle, where the weight sits). "Still" is never the instruction; "living still" is.

## Outfit readability
Design and material must be legible THROUGH the performance: every fabric gets its physics demo (drape / sway / sheen / stiffness / translucency) driven by her acts; name the material and how the named key light plays on it (satin slide, sequin sparkle, matte wool, chiffon float); reveal construction by choreography — neckline on the turn, back cut over the shoulder, hem in the walk, sleeve line on the arm lift.

## Short-form structures — vocabulary chosen BY the garment, not applied blindly
- A) TURN-IN-PLACE — flowy / layered / drapey pieces where spinning shows the fabric: front hook with a hand gesture → smooth turn, hair swinging → back view, hand through the hair revealing the back design → weight shift, hem flare → profile beat playing a garment detail → direct eye-contact hold.
- B) WALK-IN APPROACH — tailoring, denim, streetwear, heels, where walking sells structure and attitude: wide full-body walk toward the camera out of the set's depth → framing tightens naturally to three-quarter on arrival → one or two close detail beats (eyes down at the detail, then up) → hair sweep and eye contact to close.
- C) DETAIL BOOKEND — accessories-forward or texture-rich pieces (knits, hardware, embroidery): open FACELESS on a fabric or hardware close (hands adjusting) → widen to a full-body presentation with a prop in hand → short walk-in → return to the detail close to end.

## Swim / resort — from the reference style
- Natural hard sun replaces the beauty dish: the sun is the key, skin and water carry the speculars; turquoise sea plus a clean sky backdrop; wind is a co-performer (hair lift, sheer sarong or chiffon flutter).
- Vocabulary: walk-in toward the lens with a genuine smile or a head-back laugh, hand-through-hair hold, hip cock, both-hands-on-hips, sarong knot play, a glance off to the sea and back to the lens — a new act every ~2 seconds.
- Accessories carry the glamour: sunglasses glint, a delicate necklace and earrings catching sun; the print and any sheer layer stay readable in every frame.

## GRWM / try-on showcase
- Minimal neutral set with one or two styled props (easel, flowers, mirror); soft even light.
- Show the garment by turning through angles — front, profile, back — holding each beat; calm confident neutrality, small smile optional.
- Self-presented detail touches: fingertips tracing a neckline, an appliqué or slit, a hand settling a strap — the touch guides the eye while the framing stays put.

## Dancing / movement showcase
- Dance acts chosen to showcase the garment: clap pose overhead, hip sway, a skirt or dupatta lift revealing a slit or lining, spin with fabric flare, step-touch bounce on the rhythm. Joyful performed energy; eye contact on the accent beats.
- Fabric physics at speed (flare, sway, settle) named per beat; the jewelry keeps time with her.

## Multi-room photo-shoot tour — from the ref18 brand film (2-min campaign, studied frame-by-frame)
ONE TEMPLATE = ONE ROOM = ONE PHOTO SHOOT. A multi-room shoot is a CHAIN, not a single clip: run several templates (or the "Photo-shoot tour chain" recipe) with the same woman and a new room, light, garment and action per scene.
The format: the MODEL IS THE CONSTANT and everything around her changes. A new room means a new light AND a new backdrop AND a new look — never the same corner re-dressed. 5-8 rooms across a full film; 2-3 rooms inside a 12s cut.
- Give every room its own named light signature, and let the figure cast its own shadow: a window key throwing a hard shaft across a wood floor in a white-painted loft with black steel windows · an even top-light box in a white cyclorama studio, the light itself sometimes visible in frame · warm bounce off a terracotta-plaster wall with the sun edge cutting a diagonal across it · cold daylight through industrial steel glazing over raw concrete and a reflective floor · a blacked-out room edge-lit by vertical LED strip practicals.
- One faceless insert per tour pass: a macro on the garment (sleeve, zip, hardware, hem) at raking light, or the back of her head with the hair falling — the face stays out of inserts.
- One meta beat sells the format: the shooting kit inside the frame — a cinema camera on a tripod, a softbox, a C-stand — in the foreground with her performing past it. Clear the kit on the final shot.
- Tour vocabulary observed: walk-in past tall windows, quarter turn, lean on a wall mid-laugh, arms crossed, hands in pockets, hair fix in front of the lens, glance over the shoulder, sleeve or cuff adjust, seated cross-legged with elbows on the knee, stride out of frame as the cut lands.
- The look list is the catalogue: one wardrobe per room and no repeats — the wardrobe carries the variety, so keep the person identical (same hair, same face, same skin) between rooms.
- Brand cards are part of the grammar: open on a blurred foreground card while the room is sharp behind it, close on a floating logo at chest height, end on a clean card. Any on-screen text stays in English quotes, once.
- FACE AT DISTANCE — the reference author's own finding: in full-body wides nothing saved the face except rendering at ~2 MP; upscalers and face-restorers did not. So for fashion tours prefer 2K over 768P, keep a close or medium coverage in every room, and never let a look resolve only in a wide.

## Beat density — match the reference energy
- The references show a NEW visible act every 1–1.5 seconds: 7s ≈ 5–6 acts, 10s ≈ 7–8 acts, 12s ≈ 8–10, 15s ≈ 10–12. A 12s clip built as three long phases always feels empty next to them.
- Write the prompt as a stamped beat chain (0–1.5s X, 1.5–3s Y, …) with a concrete verb per beat: lift, turn, tuck, glance, step, flick, adjust, sweep. No single action may span more than 2s; only the final second may hold.
- Layer simultaneous motion on every beat: the hands do one thing, the gaze another, the fabric a third — three motion channels at once.
- Serene / luxury is not static: calm face and slow grade, but fingers, breath, jewelry and drape keep micro-moving every second.
- Cuts are beats: match-cut ON action (full → insert → medium), each cut landing as a new act, never as a rest.

[[MODE perform]]
## CAMERA MODE — 🧍 SHE PERFORMS (locked frame)
- The camera frames, SHE performs. The camera never zooms or pushes in: every size change and every detail reveal comes from her moving through depth.
- She holds the center third; full length is the default so the outfit reads. For a detail beat she steps in or presents it herself (wrist turn, lifted hem, shoulder drop), then returns to position.
- HARD FRAME RULE: she never exits frame — no walk-off, no occlusion. The end frame lands her composed, gaze to the lens, outfit legible.
- Beat recipe scaled to duration: ① HOOK — silhouette and first gaze, the garment shape reads instantly. ② DEVELOP — walk or in-place turn with fabric physics plus one secondary act. ③ DETAIL — she presents ONE construction element toward the steady lens. ④ RESOLVE — final pose, eye contact, micro-expression hold.
[[/MODE]]
[[MODE camplay]]
## CAMERA MODE — 🎥 CAMERA PLAYS (motivated moves)
- One motivated camera move per beat, and every move RE-FRAMES AROUND HER: slow three-quarter orbit, tracking at her walk pace, gentle push-in to a texture beat anchored on her, rack focus from a glint to her eyes, low-angle track for tailoring, handheld swagger track for denim and leather.
- She holds the center third; full length is the default so the outfit reads, three-quarter for detail beats, headroom respecting the hairstyle.
- HARD FRAME RULE: she never exits frame. The end frame lands her composed, gaze to the lens, outfit legible.
- Beat recipe scaled to duration: ① HOOK — silhouette and first gaze. ② DEVELOP — the move with her walk or orbit, fabric physics plus one secondary act. ③ DETAIL — push in or rack focus to ONE construction element anchored on her, then back to her eyes. ④ RESOLVE — final pose, eye contact, micro-expression hold.
[[/MODE]]

## LTX note
Compress this craft into the single paragraph in this order: hook and set → her performance with fabric physics and secondary acts → the camera behaviour with light-on-fabric → the detail anchor → composed end frame. Never let the paragraph lose the frame rule.
