pack: documentary
label: 🎥 Documentary & real life
tags: documentary, interview, verite, reallife, process
keywords: documentary, workshop, artisan, craftsman, blacksmith, baker, process, maker, behind-the-scenes, craftsman, fisherman, farmer
categories: Documentary
stack-with: 
order: 32
hint: observational camera, available light, process close-ups, ambient-first sound

# 🎥 DOCUMENTARY & REAL LIFE — domain craft
SCOPE GUARD: apply the lines that match the subject; skip the rest.

## Observational camera
Handheld with a human operator's reactions: a slight lag behind the subject's movement, a re-frame that arrives a beat late, small corrections that are never quite settled. Tripod only for a deliberate static study of a process. No drone moves, no gimbal gloss unless the piece is explicitly a polished profile.

## Available light, honest colour
Window light, workshop lamps, overhead tubes, overcast outdoor — mix them as they are instead of correcting them. Slight noise in the shadows is a feature. Never add a cinematic grade to a real workshop; keep the palette of the place.

## Subject-led pacing
Beats are set by what the person is doing, not by an edit rhythm: measure twice, cut once, wipe the blade, check the fit, breathe. Hold on the work longer than a commercial would dare, then cut on the moment something changes.

## Interview framing
Subject placed slightly off-centre with the eyeline just past the lens; environment visible and informative behind them (tools, shelves, weather); shallow but not creamy depth so the place stays legible. Hands come into frame when they start explaining — hands telling the story is the documentary's signature.

## Process close-ups
Macro on the work: dust in the light beam, a thumb pressing a seam, sweat on a forehead, saw chips on a forearm, water in a bucket, calloused hands, the tool worn smooth. Anchor every detail insert on the person's body or hands — never a floating object shot.

## The world at the edges
A radio in the corner, a passing car, a neighbour calling out, a dog crossing, weather coming in. Background life proves the scene is not a set.

## Sound is half the piece
Priority order: real ambience first, the work's own foley second (tool noise, breath, footsteps, material under pressure), speech third only when it is meant to be heard. No score, or one very sparse bed that never competes with the room.

## End frame
The work held up, the person still in the gesture, or the empty workshop with the evidence of the process still on the bench — never a posed hero shot.
