# (moved) FASHION CRAFT — now a prompt pack

The fashion craft that used to be appended here lives in **prompts/packs/fashion.md** and is
selected automatically (template tag `fashion`, category `Fashion / Lifestyle`, or idea words)
or manually via the **🧠 Prompt pack** picker in the Scene section.

Nothing is loaded from this file any more. Edit `prompts/packs/fashion.md` instead —
the `[[MODE perform]]` block there is the old "she performs" mode, `[[MODE camplay]]`
is the old camera-plays mode, and the 🧍 / 🎥 chips in the builder pick between them.
