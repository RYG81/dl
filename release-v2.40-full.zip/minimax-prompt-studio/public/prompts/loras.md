# LoRA library — MiniMax H3 × LTX-Video
# One block per LoRA. Extend by appending "## Name" + meta lines.
# model: h3 | ltx | both · type: style | motion | accel | ic | audio | quality | image
# trigger: word to place in the prompt (or "none") · strength: recommended range

## Authentic Cinematic Texture
model: h3
type: style
trigger: DY
strength: 0.7 (drop to 0.5 for high-motion segments)
description: Kills the plastic AI look — natural lighting, color depth, DoF, skin texture, lens character. The community favorite for narrative/dialogue/ads on local H3.

## CinemaGrade
model: h3
type: style
trigger: cinemagradestyle (put FIRST in the prompt)
strength: 1.0 (epoch 35 softer, epoch 50 stronger)
description: Cinematic color-grade / reality enhancer; changes the look, not the subject. Best with sketch storyboards + character refs.

## KreaLand Landscape
model: h3
type: style
trigger: krealandstyle (put FIRST)
strength: 1.0
description: Bradhamel landscape grade for H3 (beta — verify the look first).

## Better Motion
model: both
type: motion
trigger: none
strength: 0.4–0.8
description: Natural, consistent body movement for LTX and H3 (T2V-trained, works I2V). Keep sentences short to avoid prompt bleeding.

## H3 Turbo (4-step)
model: h3
type: accel
trigger: none
strength: n/a — swaps 20 steps for 4
description: LightX2V/larryvrh acceleration LoRA; pruned-FL2VA variants exist for first+last-frame. Slight face-detail loss possible.

## H3 Photoreal Image Gen
model: h3
type: image
trigger: ph0t0r34l
strength: 1.0 (1.5 in the Cicaloo one-frame workflow)
description: Turns H3 into a photoreal still-image generator up to 3840×2176; also injects an input image via I2V mode.

## LTX-2 Camera Control — Dolly In
model: ltx
type: motion
trigger: none
strength: 0.5–0.7
description: Smooth cinematic push-in locked as a movement pattern.

## 360° Panoramic Shot
model: ltx
type: motion
trigger: none
strength: 0.5–0.7
description: Full panoramic sweep for LTX-2.3.

## Bullet Time
model: ltx
type: motion
trigger: bullet-time
strength: 0.6–0.8
description: Frozen-time sweep around the subject.

## Through Object
model: ltx
type: motion
trigger: through-object
strength: 0.6–0.8
description: Camera passes through solid geometry (1000–2500 training steps recommended).

## Snorricam
model: ltx
type: motion
trigger: snorricam
strength: 0.6–0.8
description: Face-locked rig — background swirls while the face stays framed.

## 60 FPS Buttery Smooth
model: ltx
type: motion
trigger: none
strength: 0.5–0.7
description: Smoother temporal feel for LTX-2.3 motion.

## PhysLTX — Better Physics
model: ltx
type: motion
trigger: none
strength: 0.5–0.7
description: Physical plausibility pass for I2V.

## VBVR Video Reasoning
model: ltx
type: quality
trigger: none
strength: per card
description: The "H3 for LTX" reasoning/quality boost (I2V+T2V); most-downloaded LTX-2.3 LoRA.

## IC-LoRA Depth
model: ltx
type: ic
trigger: none (reference video carries motion)
strength: 1.0 (0.5–0.8 to soften; 1.2–1.5 on distilled)
description: Locks camera path & 3D geometry from a reference video; prompt then describes STYLE ONLY.

## IC-LoRA Pose
model: ltx
type: ic
trigger: none
strength: 1.0
description: Human performance transfer via DWPose skeletons; prompt styles only.

## IC-LoRA Canny
model: ltx
type: ic
trigger: none
strength: 1.0
description: Composition/silhouette preservation for stylized looks.

## IC-LoRA CrossView
model: ltx
type: ic
trigger: crossview. new camera angle: {to the right|to the left|same angle}, {higher|lower|same height}, {closer|further}.
strength: 1.0 (1.2–1.5 distilled)
description: Re-shoot a scene from a new angle; fixed 63-phrase vocabulary only.

## Whisper & Soft-Spoken Audio
model: ltx
type: audio
trigger: none — natural language "(woman, whispering)"
strength: 1.0
description: True whisper/soft registers for LTX-2.3 dialogue.

## Cozy Felt Diorama
model: ltx
type: style
trigger: cozy felt style phrase
strength: 0.6–0.8
description: Handmade felt miniature world.

## Claymation Style
model: ltx
type: style
trigger: claymation style phrase
strength: 0.6–0.8
description: Fingerprint-textured clay miniature world with warm light.

## Fantasy Anime Style
model: ltx
type: style
trigger: fantasy anime style phrase
strength: 0.6–0.8
description: Cel-shaded epic-fantasy anime look.

## Cinematic Post-Apocalyptic
model: ltx
type: style
trigger: P0st4p0c0
strength: 0.5–1.0
description: Grounded survival photoreal; supporting phrases help (ash-filled ruined environment, weathered survivor).

## Ingredients (reference sheet)
model: ltx
type: ic
trigger: none — two-part prompt: "Reference sheet:" / "Generated video:"
strength: 1.0 (2.3 variant: 1.4, guidance 4.0, 30 steps)
description: Characters/props/set locked to a reference-sheet image; only sheet elements can appear. Use the 🎛 IC protocol builder — it assembles the exact two-part contract.

## Colorization
model: ltx
type: ic
trigger: COLORIZE (inside the fixed "Reference shows… Edited shows… COLORIZE …" convention)
strength: 1.0 (0.8–0.9 if oversaturated)
description: Grayscale → natural color, geometry untouched. 🎛 builder assembles the convention.

## Decompression
model: ltx
type: ic
trigger: ENHANCE QUALITY (same Reference/Edited convention)
strength: 1.0
description: Removes compression macroblocking/chroma bleed/ringing only (not blur/noise). 🎛 builder.

## Clean Plate
model: ltx
type: ic
trigger: none — describe the desired EMPTY scene, name occluders as "no X" in both prompts
strength: 1.0
description: People/object removal with background intact. 🎛 builder.

## In/Outpainting
model: ltx
type: ic
trigger: none — empty/minimal prompt, or describe ONLY the masked region
strength: 1.0
description: Mask-conditioned fill/extend; describing the full scene duplicates objects. 🎛 builder.

## Relight (sun ball)
model: ltx
type: ic
trigger: relight the video to match the light-direction ball. {direction}
strength: 1.0 · single-stage, exteriors only
description: Re-lights exteriors to a composited direction ball; prompt = trigger + one look phrase, never scene content. 🎛 builder.

## ReStyle (Cseti)
model: ltx
type: ic
trigger: Make it {style} style.
strength: 1.0 · CFG 1.1–2.0 on non-distilled
description: Style-image-as-frame-0 restyling; short template form is the safe default. 🎛 builder.

## Licon MSR V1 — Multiple Subject Reference (LTX-2.5)
model: ltx
type: reference
trigger: none — label each reference explicitly: "Image 1", "Image 2", … and state what each provides (character / clothing / object / background)
strength: 1.0 (official default; lower to ~0.8 if references over-stick)
description: Encodes up to FIVE reference images as visual tokens with learned slot embeddings (ComfyUI-LTX2.5-MSR plugin). Prompt contract: describe each Image N clearly, specify subject actions + spatial relationships, and say which reference supplies the character vs wardrobe vs prop vs background.

## Equi360 — equirectangular 360° (shamanic)
model: h3
type: style
trigger: equirect360 (put FIRST, followed by: "Equirectangular 360-degree panoramic video: the frame is a full spherical projection, a complete environment wrapping around the viewer on all sides, with the horizon at the vertical middle of the frame."
strength: 1.0 (reviewed v2, step 2500)
description: Full-sphere monoscopic equirectangular video with H3's native audio, on the FL2VA base. Evaluated settings: 21:9 · 768P · 5s · prompt expansion OFF. Resize the 21:9 frame to 2:1 for conventional equirect media and add mono-360 spherical metadata; never crop, or the sphere tears at the wrap seam. Ships as: public/prompts/templates/immersive.md → "Equirectangular 360 — sphere tour". Known limits: wrap discontinuities, polar stretching, unintended motion — always check it in a spherical viewer.

## VR180 SBS — stereoscopic side-by-side (EllipsesMark)
model: h3
type: style
trigger: vr180sbs (put FIRST, followed by: "Equirectangular 360-degree panoramic video: the frame is a full spherical projection, a complete environment wrapping around the viewer on all sides, with the horizon at the vertical middle of the frame."
strength: 1.0 (lower values fade back toward mono before losing the split)
description: VR180 stereo, one hemisphere per eye, with native audio. Evaluated settings: 21:9 · 768P · 5s · prompt expansion OFF (10-15s keeps the pair intact; stay on the minimax/h3 route — the 8-step h3-max LoRA route degrades the stereo). Package with ffmpeg to 1536x768 then spatialmedia `-s left-right -p equirectangular` (spherical V2). Known limits: dark porthole vignettes at the eye edges, a bias toward first-person outdoor walks, faces/text no better than base H3, fast pans can drift between the eyes. Ships as: public/prompts/templates/immersive.md → "VR180 stereo pair — immersive walk".
