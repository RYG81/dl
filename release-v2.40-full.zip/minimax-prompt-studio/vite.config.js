import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import fs from 'node:fs'
import path from 'node:path'
import { templateIndex, templateFolders, scanTemplates } from './scripts/templatescan.mjs'

/* Live index of the drop-in templates folder — the app scans ALL .md files in it,
   so adding a template = dropping a file. No manifest, no user-templates editing. */
function templatesIndex() {
  const handler = (server) => (req, res, next) => {
    const url = (req.url || '').split('?')[0]
    /* Every .md under public/prompts, relative — the picker for system prompts,
       context files and banks. Depth-capped, README/_ files skipped. */
    if (url === '/prompts/_tree.json') {
      try {
        const base = path.join(server.config.root, 'public', 'prompts')
        const out = []
        const walk = (dir, rel, depth) => {
          if (depth > 3) return
          for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
            if (e.name.startsWith('_') || /^README/i.test(e.name) || e.name.startsWith('.')) continue
            const r2 = rel ? rel + '/' + e.name : e.name
            if (e.isDirectory()) walk(path.join(dir, e.name), r2, depth + 1)
            else if (e.name.endsWith('.md')) out.push(r2)
          }
        }
        if (fs.existsSync(base)) walk(base, '', 0)
        respond(res, out.sort())
      } catch (e) { res.statusCode = 500; res.end('[]') }
      return
    }
    /* `_index.json` (the .md files of a prompts folder) and `_folders.json` (its
       subfolders). The TEMPLATES tree is scanned RECURSIVELY, so subfolders are
       first-class: the index carries relative paths ("medical/moa.md") and the app
       fetches them by that path; a folder's own _index.json is relative to it. */
    const m = url.match(/^\/prompts\/(.*?)_(index|folders)\.json$/)
    if (!m) return next()
    const sub = m[1].replace(/\/$/, '')
    try {
      const dir = path.join(server.config.root, 'public', 'prompts', sub)
      const isTemplates = sub === 'templates' || sub.startsWith('templates/')
      if (m[2] === 'folders') { respond(res, isTemplates ? templateFolders(scanTemplates(dir)) : []); return }
      const files = isTemplates
        ? templateIndex(dir)
        : (fs.existsSync(dir)
            ? fs.readdirSync(dir).filter((f) => f.endsWith('.md') && !/^README/i.test(f) && !f.startsWith('_')).sort()
            : [])
      respond(res, files)
    } catch (e) { res.statusCode = 500; res.end('[]') }
  }
  return {
    name: 'templates-index',
    configureServer: (s) => { s.middlewares.use(handler(s)) },
    configurePreviewServer: (s) => { s.middlewares.use(handler(s)) },
    /* A built copy served by a plain static host has no middleware — write the indexes into
       dist/ so drop-in folders (and their subfolders) keep working there too. */
    writeBundle() {
      const root = process.cwd()
      const out = path.join(root, 'dist', 'prompts')
      const dir = path.join(root, 'public', 'prompts', 'templates')
      try {
        const files = scanTemplates(dir)
        fs.mkdirSync(path.join(out, 'templates'), { recursive: true })
        fs.writeFileSync(path.join(out, 'templates', '_index.json'), JSON.stringify(files.map((f) => f.rel)))
        fs.writeFileSync(path.join(out, 'templates', '_folders.json'), JSON.stringify(templateFolders(files)))
        /* per-folder indexes, relative to that folder: /templates/medical/_index.json */
        for (const folder of templateFolders(files)) {
          if (!folder) continue
          const rel = files.filter((f) => f.folder === folder || f.folder.startsWith(folder + '/')).map((f) => (f.folder === folder ? f.name : f.rel.slice(folder.length + 1)))
          const dest = path.join(out, 'templates', folder)
          fs.mkdirSync(dest, { recursive: true })
          fs.writeFileSync(path.join(dest, '_index.json'), JSON.stringify(rel))
        }
      } catch (e) {}
    },
  }
}

const respond = (res, data) => {
  res.setHeader('Content-Type', 'application/json')
  res.setHeader('Cache-Control', 'no-store')
  res.end(JSON.stringify(data))
}

// The dev server proxies /ollama/* to your local Ollama server-side.
// That means: NO CORS setup, NO OLLAMA_ORIGINS, works on Windows/macOS/Linux as-is.
//
// IMPORTANT: the target is 127.0.0.1 (IPv4), not "localhost".
// On Windows, Node resolves "localhost" to ::1 (IPv6) first, but Ollama listens
// on IPv4 only — that causes "connect ECONNREFUSED ::1:11434".
// Point it elsewhere with:  OLLAMA_URL=http://192.168.1.5:11434 npm run dev
const OLLAMA_URL = process.env.OLLAMA_URL || 'http://127.0.0.1:11434'

export default defineConfig({
  plugins: [react(), templatesIndex()],
  server: {
    host: true,          // 0.0.0.0
    port: 5173,
    allowedHosts: true,  // allow tunneled/preview hostnames
    proxy: {
      '/ollama': {
        target: OLLAMA_URL,
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/ollama/, ''),
        configure: (proxy) => {
          // When Ollama is down, answer with a clean JSON 502 the app understands.
          proxy.on('error', (err, req, res) => {
            if (res && !res.headersSent) {
              res.writeHead(502, { 'Content-Type': 'application/json' })
              res.end(JSON.stringify({
                error: String(err && err.message || err),
                hint: 'Is Ollama running at ' + OLLAMA_URL + '? Start it with: ollama serve',
              }))
            }
          })
        },
      },
    },
  },
  build: { outDir: 'dist' },
})
