// Central log capture. Mirrors console + errors + network into a ring buffer that
// can be dumped to a file, so a failing run can be handed over verbatim.
//
// Console output uses collapsed, colour-badged groups (pattern borrowed from the
// LC_LOG logger) so devtools stays readable, while the same events are pushed to
// the in-app panel and the saved log file.

const MAX = 4000;
const buf = [];
let seq = 0;
const listeners = new Set();

const now = () => new Date().toISOString();
const t0 = performance.now();

// ── console styling ──────────────────────────────────────────────────────────
const style = (color, bg = 'transparent') =>
  `color:${color};background:${bg};font-weight:700;padding:1px 5px;border-radius:3px;font-family:ui-monospace,monospace`;
const BRAND = style('#fff', '#c2762a');
const TAG_COLOR = {
  llm: '#22d3ee', fetch: '#7dd3fc', scene: '#a3e635', render: '#f0a35e',
  status: '#c4b5fd', stage1: '#f9a8d4', stage2: '#f9a8d4', console: '#94a3b8',
  window: '#f87171', promise: '#f87171', boot: '#6ee7b7', log: '#94a3b8',
};
const LEVEL_BG = { error: '#7f1d1d', warn: '#78350f', info: '#1e3a5f', debug: '#334155' };

function fmt(v, depth = 0) {
  if (v instanceof Error) return `${v.name}: ${v.message}\n${v.stack || ''}`;
  if (typeof v === 'string') return v;
  if (typeof v === 'function') return `[fn ${v.name || 'anon'}]`;
  if (v === undefined) return 'undefined';
  if (v === null) return 'null';
  if (typeof v !== 'object') return String(v);
  if (depth > 2) return '[…]';
  if (typeof HTMLElement !== 'undefined' && v instanceof HTMLElement) {
    return `<${v.tagName.toLowerCase()}${v.id ? '#' + v.id : ''}>`;
  }
  try {
    const s = JSON.stringify(v, (k, val) => (typeof val === 'number' ? Math.round(val * 1e4) / 1e4 : val));
    return s && s.length > 1200 ? s.slice(0, 1200) + `…(+${s.length - 1200} chars)` : s;
  } catch { return Object.prototype.toString.call(v); }
}

export function log(level, tag, ...args) {
  const rec = {
    n: ++seq,
    ts: now(),
    ms: Math.round(performance.now() - t0),
    level,
    tag,
    msg: args.map((a) => fmt(a)).join(' '),
  };
  buf.push(rec);
  if (buf.length > MAX) buf.splice(0, buf.length - MAX);
  listeners.forEach((f) => { try { f(rec); } catch {} });
  return rec;
}

export const logger = {
  debug: (tag, ...a) => log('debug', tag, ...a),
  info: (tag, ...a) => log('info', tag, ...a),
  warn: (tag, ...a) => log('warn', tag, ...a),
  error: (tag, ...a) => log('error', tag, ...a),
  async step(tag, label, fn) {
    const s = performance.now();
    log('info', tag, `▶ ${label}`);
    try {
      const r = await fn();
      log('info', tag, `✔ ${label} (${Math.round(performance.now() - s)}ms)`);
      return r;
    } catch (e) {
      log('error', tag, `✘ ${label} (${Math.round(performance.now() - s)}ms):`, e);
      throw e;
    }
  },

  // ── LLM traffic: full request/response visibility ──────────────────────────
  llmReq(provider, endpoint, payload) {
    const color = TAG_COLOR.llm;
    const msgs = payload.messages || [];
    const chars = msgs.reduce((a, m) => a + (typeof m.content === 'string' ? m.content.length : 0), 0);

    if (rawConsole.groupCollapsed) {
      rawConsole.groupCollapsed(`%c ShootLab %c ${provider.toUpperCase()} ↑ %c ${payload.model || '—'} %c ${chars} chars`,
        BRAND, style('#000', color), style('#aaa'), style('#64748b'));
      msgs.forEach((m, i) => {
        const rc = m.role === 'system' ? '#a78bfa' : m.role === 'user' ? '#34d399' : '#fb923c';
        const prev = String(m.content ?? '').slice(0, 300);
        rawConsole.log(`%c  [${i}] ${m.role.toUpperCase()}`, style(rc), prev + (prev.length >= 300 ? '…' : ''));
      });
      const params = {};
      for (const k of ['temperature', 'max_tokens', 'top_p', 'stream', 'format', 'response_format']) {
        if (payload[k] !== undefined) params[k] = payload[k];
      }
      if (payload.options) Object.assign(params, payload.options);
      if (Object.keys(params).length) rawConsole.log('%cParams', style(color), params);
      rawConsole.groupEnd();
    }

    log('info', 'llm', `↑ ${provider}/${payload.model || '—'} @ ${endpoint} — ${msgs.length} messages, ${chars} chars` +
      (payload.options ? `, opts ${JSON.stringify(payload.options)}` : ''));
  },

  llmRes(provider, endpoint, { content = '', thinking = '', usage = null, finish = '', ms = 0 }) {
    const color = TAG_COLOR.llm;
    if (rawConsole.groupCollapsed) {
      rawConsole.groupCollapsed(`%c ShootLab %c ${provider.toUpperCase()} ↓ %c ${ms}ms %c ${content.length} chars`,
        BRAND, style('#000', color), style('#6ee7b7', '#052e16'), style('#64748b'));
      if (thinking) rawConsole.log('%cThinking', style('#a78bfa'), thinking.slice(0, 300) + (thinking.length > 300 ? '…' : ''));
      rawConsole.log('%cContent', style(color), content.slice(0, 600) + (content.length > 600 ? '…' : ''));
      if (usage) rawConsole.log('%cTokens', style('#6ee7b7'),
        `prompt=${usage.prompt_tokens ?? '?'} completion=${usage.completion_tokens ?? '?'} total=${usage.total_tokens ?? '?'}`);
      rawConsole.groupEnd();
    }
    const tok = usage
      ? ` — tokens ${usage.prompt_tokens ?? '?'}/${usage.completion_tokens ?? '?'} (total ${usage.total_tokens ?? '?'})`
      : '';
    log('info', 'llm', `↓ ${provider} ${ms}ms, ${content.length} chars${tok}${finish && finish !== 'stop' ? `, finish_reason=${finish}` : ''}`);
    if (thinking) log('debug', 'llm', `thinking (${thinking.length} chars): ${thinking.slice(0, 200)}`);
  },
};

export function onLog(fn) { listeners.add(fn); return () => listeners.delete(fn); }
export function getLogs() { return buf.slice(); }
export function clearLogs() { buf.length = 0; seq = 0; log('info', 'log', 'cleared'); }
export function counts() {
  const c = { debug: 0, info: 0, warn: 0, error: 0 };
  for (const r of buf) c[r.level] = (c[r.level] || 0) + 1;
  return c;
}

export function logText(meta = {}) {
  const head = [
    `# ShootLab 3D log`,
    `generated : ${now()}`,
    `userAgent : ${typeof navigator !== 'undefined' ? navigator.userAgent : 'n/a'}`,
    `url       : ${typeof location !== 'undefined' ? location.href : 'n/a'}`,
    ...Object.entries(meta).map(([k, v]) => `${k.padEnd(10)}: ${fmt(v)}`),
    `entries   : ${buf.length} (${JSON.stringify(counts())})`,
    ''.padEnd(78, '-'),
    '',
  ].join('\n');
  const body = buf.map((r) =>
    `${String(r.n).padStart(4, '0')} +${String(r.ms).padStart(7)}ms ${r.level.toUpperCase().padEnd(5)} [${r.tag}] ${r.msg}`
  ).join('\n');
  return head + body + '\n';
}

// ── install: mirror console + global errors, without losing devtools output ───
const rawConsole = {};
let installed = false;

export function installLogCapture() {
  if (installed) return;
  installed = true;

  for (const level of ['log', 'info', 'warn', 'error', 'debug', 'group', 'groupCollapsed', 'groupEnd']) {
    rawConsole[level] = console[level] ? console[level].bind(console) : () => {};
  }

  for (const level of ['log', 'info', 'warn', 'error', 'debug']) {
    const orig = rawConsole[level];
    console[level] = (...args) => {
      log(level === 'log' ? 'info' : level, 'console', ...args);
      orig(...args);
    };
  }

  window.addEventListener('error', (e) => {
    log('error', 'window', e.message, `at ${e.filename}:${e.lineno}:${e.colno}`, e.error || '');
  });
  window.addEventListener('unhandledrejection', (e) => {
    log('error', 'promise', 'Unhandled rejection:', e.reason);
  });

  // network visibility — every fetch, its status and duration
  const of = window.fetch.bind(window);
  window.fetch = async (input, init) => {
    const url = typeof input === 'string' ? input : input?.url || String(input);
    const method = (init?.method || 'GET').toUpperCase();
    const s = performance.now();
    try {
      const r = await of(input, init);
      log(r.ok ? 'info' : 'error', 'fetch',
        `${method} ${url} → ${r.status} ${r.statusText} (${Math.round(performance.now() - s)}ms)`);
      return r;
    } catch (e) {
      log('error', 'fetch', `${method} ${url} → network error (${Math.round(performance.now() - s)}ms):`, e);
      throw e;
    }
  };

  log('info', 'boot', 'log capture installed');
}

// styling helpers reused by the in-app panel
export const LOG_COLORS = { TAG_COLOR, LEVEL_BG };
