# Prompt architecture, template craft & roadmap

Written after a full audit of the corpus (`npm run audit` → `docs/prompt-audit.md`).
Numbers below are measured, not estimated.

---

## Q1 — We broke the system prompt into several files. Is that good?

**Yes — for this app it is the right call. But it is only safe because of four rules, and one of
them (the size balance) is currently being broken.**

### Why splitting is right here

| Reason | Evidence from your own setup |
|---|---|
| **Attention is the scarce resource on a local model.** Mixed craft dilutes it. | Fashion craft used to sit inside every system prompt → product/portrait/animation prompts wrote garment vocabulary. That was the bug you reported. |
| **Vocabulary must be domain-exact.** | "Speculars + spec beats" (product) vs "drape + hem flare" (fashion) vs "ethology, never anthropomorphise" (animal) — three different languages. |
| **Routing can be tested and overridden.** | 88 templates through the router: 87 get a domain pack, only `Three-beat multi-shot` resolves to base-only; 12 correctly stack two packs. 0 real text drift between packs. |
| **Chains need per-scene brains.** | A chain mixing a fashion scene, a product scene and a dialogue scene only works if craft is modular. |
| **Maintenance.** | Editing one vertical no longer risks a regression in another. |

### The four rules that keep it healthy (audit verifies them)

1. **Base owns the universal, packs own the domain.** Format contract, shot design, consistency,
   timing, audio live in the base and are never restated in a pack → measured **real drift: 0**.
2. **Deterministic routing + a manual override + evidence.** tag → category → idea words, capped at
   2 packs, with the reason printed on the card and in the console.
3. **A scope guard in every pack** — all 15 packs carry it ("apply only the lines that match the
   subject"). This is what protects you when the router guesses slightly wrong.
4. **Size balance.** ← *the one that needs work.*

### The one thing to fix now: pack sizes are lopsided

| | chars |
|---|---|
| median pack | ~2.3k |
| 📦 product | 3.1k |
| 📱 ugc | 3.6k |
| **👗 fashion** | **9.7k — 4× the median** |

Worst-case call today: base 14.2k + fashion 9.7k + ugc 3.6k ≈ **8.4k tokens of system prompt** before
your idea. On a 32B that is affordable but wasteful; on a 7–8B it eats the context you need for
the idea itself.

**Recommendation — SHIPPED ✅ (measured result).** `fashion.md` was split into:

| | before | after |
|---|---|---|
| fashion pack | 9,732 chars | **7,518** |
| ethnic pack | — | **4,296** (`stack-with: fashion`) |
| worst-case call | ≈8,430 tokens | **≈7,323** |
| a streetwear clip loads | 9,732 (garment + sari + bridal craft) | 7,518 (garment + structures + modes) |
| a sari/bridal clip loads | 9,732 (same) | 11,814 (both, because both genuinely apply) |

Also fixed while measuring: the router no longer stacks two packs that merely matched the *same*
category (that was loading bridal craft into streetwear shoots), `cinematic` no longer claims the
`documentary` tag, and keyword lists are de-duplicated at parse time.

The original plan was:
- `fashion.md` — garment intelligence, acting pack, short-form structures, glamour light, camera
  modes ([[MODE perform]] / [[MODE camplay]]), beat density. (~4.5k)
- `ethnic.md` — sari/drape, bridal & heavy embroidery, traditional brand-ad, jewellery-adjacent
  beats. `stack-with: fashion`, keywords: sari, saree, lehenga, kurta, bridal, dupatta, zardozi…
  (~4.5k)

Result: a western streetwear clip loads ~4.5k instead of 9.7k, a sari clip loads both (~9k, which is
correct because both genuinely apply), and the router has a second, sharper decision to make.

### What we should NOT split (and why)

- **Not by style** (noir, anime, handheld) — those are already chips/inputs, not craft.
- **Not per template** — 88 templates × own prompt is unmaintainable and duplicates craft.
- **Not the format contract / audio / timing** — universal; splitting them would make prompts
  inconsistent across domains, which is exactly the "voice fragmentation" risk of modular prompts.

**Verdict:** two-layer composition (base + ≤2 packs) is the correct architecture. Keep it, right-size
the fashion pack, keep the scope guard, and run `npm run audit` whenever packs or templates change.

---

## Q2 — How should we make templates, and how do we make authoring + chaining better?

### The template contract — 5 lines that separate a good block from a dead one

1. **One beat grammar, not a shot list.** "Arrive → present neckline → turn to back → eye-contact
   hold" is grammar. "Shot 1 does X, Shot 2 does Y" is a story that only fits one idea.
2. **Placeholders are decisions, with guidance.** `{GARMENT — name the real details: neckline,
   fabric, hem}` beats `{GARMENT}`. The guidance text is what the UI can show as a hint.
3. **A TIMING line.** *(17 shipped H3 templates are missing it — audit flags them.)*
4. **Conditional beats, not fixed ones.** *"Use this beat only if the detail is named; never invent
   one."* That is what made the room tour feel alive.
5. **Flows when the architecture can vary.** `flows: A | B | C` + a FLOW LIBRARY paragraph.
6. **≤8 placeholders.** *(40 templates exceed this — they get heavy to fill.)*

**Future rule: new templates are dynamic by default** (conditional beats + flows). A static block is
justified only when the reference grammar is rigid (e.g. the ref beat-for-beat room showcase).

### Authoring UX backlog (ranked — small effort, big win first)

| # | Change | Why | Effort |
|---|---|---|---|
| 1 | **Template Linter** in Forge + Manager: placeholders · timing ✓/✗ · flows · conditional beats · size · near-duplicate vs library | Makes "is my template good?" answerable before you use it. The audit code already does this — it only needs a UI. | M |
| 2 | **Forge → ⬇ Save as `user-<slug>.md`** (download + copy) | Turn a finished prompt into a drop-in file in one click instead of hand-writing markdown. | S |
| 3 | **Placeholder guidance in the fill UI** — parse `{TOKEN — guidance}` and show the guidance as the field hint | Kills the "value for GARMENT" blankness; the templates already carry the guidance. | S |
| 4 | **Near-duplicate warning** ("⚠ 82% similar to *Street-style walk* — extend or merge?") | Prevents the fashion-library sprawl from repeating in 15 other domains. | M |
| 5 | **Composed-prompt preview**: a "view the exact system prompt being sent" modal | Trust + debugging; answers "why did it write that?" without reading console logs. | S |
| 6 | **Template usage stats** (used N times, last used, recently used first) | The library gets long; usage is the best sort order. | S |

### Chaining UX backlog (for longer videos)

| # | Change | Why | Effort |
|---|---|---|---|
| 1 | **Story timeline strip**: each scene a row with idea · 📐 template · 🧠 pack · 🎼 flow · duration · end-state, editable inline, drag to reorder, total runtime + shot budget shown | Right now per-scene template/flow/pack exists in the engine but is invisible in the UI. Making it visible is what turns the chain from a text box into a tool. | M |
| 2 | **Campaign recipes**: save/load the whole chain (bible + scenes + templates + settings) as JSON; ship 3 starter recipes ("6-look lookbook", "3-scene product story", "micro-drama pilot") | A campaign is reused far more often than a single prompt. This is the single biggest time-saver left. | M |
| 3 | **Continuity guard**: end-state is captured per scene — compare the next scene's idea against it and warn on wardrobe/location contradictions | Cheap heuristic, catches the most common chain failure (identity drift by text). | M |
| 4 | **Bridge assistant**: per-scene "render order" checklist + copy-ready bridge note (last frame → next first frame) | Removes the manual dance between the app and ComfyUI. | S |
| 5 | **Budget planner**: enter target length → suggests scene count/durations at one beat per second, warns when the 15s cap or beat density breaks | Chained videos fail on math, not on craft. | S |

---

## Q3 — What video types and templates should we add next?

### Coverage gaps the audit found

| pack | templates that route to it | status |
|---|---|---|
| 👤 portrait | **1 — 👤 Portrait adaptive beats (shipped)** | was 0 |
| 🏃 sports | **1 — 🏃 Sport peak adaptive beats (shipped)** | was 0 |
| 🚗 vehicle | **2 — car walkaround + LTX night drive (shipped)** | was 1 |
| 🎥 documentary | **2 — craft process + documentary craft (shipped)** | was 1 |
| 🐾 animal | 1 (LTX wildlife only) | still thin |
| 🎨 animation | 1 | still thin |
| 🍽 food | 2 | OK |
| 🏛 space | 2 (LTX + new dynamic) | OK |
| 🗣 dialogue | 2 | OK |

### Tier 1 — highest demand, craft already exists (build these first)

| Template | Pack | Why it matters |
|---|---|---|
| 🎭 **Vertical micro-drama episode** — 3s hook, conflict beat, cliffhanger frame; flows for reveal-driven / reversal / countdown | dialogue + cinematic (new `drama` pack if it earns one) | The dominant short-form genre of 2026, and it is chain-native (episodes = chains). |
| 🗣 **Talking-head / podcast cut** — interview framing, jump cuts, B-roll intercut, captions-free | dialogue + portrait | The most-requested creator format in every tool survey; pairs with the portrait pack that currently has no template. |
| 🛍 **Comparison / "3 reasons" review ad** — two products or two options, split-screen or A→B | ugc + product | Highest-intent affiliate/ad format; the UGC set covers testimonials but not comparison. |
| 🏠 **Real-estate walkthrough** — dynamic beats from named rooms (entry, kitchen, view, bedroom), cut-shots between rooms | space | Huge commercial market, and your space pack already exists. |
| 💍 **Wedding highlight montage** — haldi / sangeet / reception entry / vidai, cut on music, one insert per named ornament | fashion + ethnic + ugc | Your India market; every craft piece (bridal, jewellery, ethnic) is already built and would finally have a home. |

### Tier 2 — fill the empty packs (target: every pack gets ≥2 dynamic templates)

👤 Portrait dynamic (identity lock + micro-expression arc; flows: window-light / environment /
hands-at-work) · 🏃 Sport peak-moment (form check, 30-second set, slow-mo peak) · 🚗 Car walkaround
(dynamic beats from named features: wheels, interior, engine bay) · 🐾 Pet product ad
(animal + ugc) · 🎥 Craft-process film (documentary: hands, process close-ups) · 🎨 Animation
short-story loop (claymation / anime) · 🎵 Lyric performance + dance-challenge loop (music).

### Tier 3 — format experiments (add if the data asks for them)

ASMR texture loop · horror / found-footage scare (vertical) · recipe 5-step reel ·
travel day-in-place · explainer with hands + objects · fashion transition-on-beat pack.

### Speed of delivery

The dynamic engine makes these cheap to produce: a Tier-1 template is one 90-line block with a
FLOW LIBRARY and conditional beats — no app changes needed. Realistic pace: **5 templates per
batch**, verified by `npm run audit` (parse, flows, routing, coverage) before shipping.

---

## Suggested order of work

1. **Right-size prompts** — split `fashion` → `fashion` + `ethnic` (Q1 fix, ~1 hour, immediate
   quality + token win).
2. **Template Linter + Forge download + placeholder guidance** — the authoring loop becomes
   self-serve (Q2 items 1–3).
3. **Chain timeline + campaign recipes** — the biggest remaining UX gap (Q2 chaining 1–2).
4. **Tier-1 templates** — micro-drama, talking-head, comparison, real-estate, wedding.
5. **Tier-2 templates** — one per empty pack, two batches.

---

## Q1b · Official H3 spec compliance — SHIPPED

Source: the official prompt-writing skill `MiniMax-AI/MiniMax-H3 → skills/h3-prompt-writing`
(`SKILL.md`, `references/base-en.txt`, `references/ref-en.txt`). Full line-by-line diff lives in
`docs/official-h3-spec-review.md`.

| Gap | Fix |
|---|---|
| No official instruction line on keyframe modes | `alignmentLine()` emits the exact I2VA / FL2VA / L2VA sentence with the real duration (2 dp) and final shot index |
| L2VA mode missing entirely | 🎯 L2V workflow chip + last-frame box + L2V discipline block |
| Ref2VA used the three-field format | Six official sections (`subject_definitions → summary → retention_analysis → detailed_description → overall_soundscape → non_diegetic_music`) in the prompt, the parser, the copy text, the card UI and a 13-check Ref2VA audit |
| Dialogue written as plain quotes | `<d>[Language] …</d>` verbatim + speaker IDs `(S1)` / `(S1,S2)`, off-screen voiceover phrase + lips closed, `<scenetrans>` / `<cutoff>` |
| Audio fields uncapped | soundscape 1–4 sentences (no dialogue/diegetic-music repetition), music 1–3 sentences (no mood words, diegetic split), exact `N/A` rules |
| On-screen text unmarked | English double quotation marks, verbatim, untranslated |

Verification: `/tmp/h3check.mjs` — 23/23 assertions (message contract per mode, dialogue markup,
LTX unaffected, ref2va round-trip through `finalizeOutput` + `fullPromptText`, section order).
System prompts grew 12,471 → 18,756 (SFW) and 14,255 → 20,540 (mature); drift check still 0 real.

## Q1c · Official style-skill templates — SHIPPED

Five templates derived from the official Hub style skills (see `docs/official-h3-spec-review.md` §5):
✂️ Papercraft cut-out explainer · 🧊 Minimalist product ad · 🔤 Kinetic lyric type ·
📜 Reveal scroll · 🎮 Co-op game intro. Library 92 → **97 blocks (18 dynamic)**; new tags claimed
by packs so the auto-router stays explicit. Housekeeping in the same pass: four >120-char tokens
that were invisible to the 🧩 fields (Fabric macro, Campaign film ×2, Lookbook film, Boudoir) were
trimmed into real guided fields — the Room demo templates were left untouched by request. The audit
script's own token counter was switched to `src/lib/tokens.js` (it still counted the old 48-char
ceiling); it now reports the true placeholder distribution.

**Verification recipe (any change):** grep anchors → python patch → `npm run selftest` (H3 contract + template hygiene + pack routing, no server needed) → `npm run build` → `npm run audit` → curl the dev server. `npm install --no-audit --no-fund` first when the sandbox reports `vite: not found`.

## Q1d · Length policy — SHIPPED (user directive)

**Do not limit prompt length.** Removed every cap: the 7,000-char scoring check (both H3 and Ref2VA paths),
the 1,500-word ceiling, the builder's `N / 7000` counter, the Tips "character limit" row, the linter's
4,200-char skeleton nudge, and the 300-char chain hand-off truncation. Added an explicit no-limit rule to
both H3 system prompts + both inline fallbacks, and `num_predict: -1` on the streaming generation call so
the model's answer is never cut off. The output card now shows the prompt size as information only.
Covered by `npm run selftest` suite 4 (13 assertions, incl. an 8k-char description and a 16k-char Ref2VA body).
Guide documents the one physical bound: the local model's context window (`OLLAMA_CONTEXT_LENGTH` / `num_ctx`).

## Q1e · Film-set meta hair spot — SHIPPED (ad recreation)

Recreated the Jan-2026 TRESemmé India format (Ananya Panday / Anurag Kashyap): the talent shoots a
dramatic scene, the director calls "Cut!" because their hair looks too salon-perfect for someone in
distress, and the fiery rebuttal turns the complaint into the product. Shipped as
**💇 Film-set meta hair spot — 20s chain (2 × 10s)** (tag `beauty`, flows CUT IS CALLED / MONOLOGUE
FIRST / HAIR HERO END / TWO-PART SHOWDOWN).

- **20 s = two 10 s chained clips** (a single H3 clip caps at 15 s): scene 1 = set + cut + complaint,
  scene 2 = retort + hair hero + product finish; `settings_note` tells the chain to feed the previous
  clip's last frame as the next first frame.
- **Brand-neutral**: {BRAND} {TALENT} {DIRECTOR} {PRODUCT} {CLAIM} tokens — the format, not the marks.
- **New craft folded in**: a HAIR ENGINE (gloss as specular travel, fluidity with strand separation
  lagging the head, one decisive flip, wind pass, macro fibre sheen, product squeeze) with an explicit
  "never supernatural — no sparks, glitter or flare gimmicks" guard; the performance rule (director
  annoyed, never cruel; talent confident, smile after the line); the claim appearing exactly once as
  verbatim on-screen text; and the music dropping out for the director's line so the comedy plays dry.
- Dialogue uses the official `<d>[Language] …</d>` markup with the user's own lines verbatim.
- New `beauty` tag (chip in all four tag maps + Forge), claimed by the fashion pack for routing.
- Library **98 blocks · 19 dynamic**; template lints clean (20 fields, 1 guided share), closest
  neighbour 0.22 (threshold 0.72).

## Q1f · Animation-ad archetypes — SHIPPED

Six brand-neutral templates built from the formats that made animated advertising famous (no real
brands, characters or campaigns in the files — only the format):

| Template | Format it recreates | Tag |
|---|---|---|
| 🐮 **Topical mascot cartoon — pun tagline ad** | the hand-drawn topical cartoon ad with a punning line and a brand wink | `mascot` |
| 🧸 **CG character short — twist ending** | the wordless 3D story spot where the twist reframes everything and the brand arrives last | `cg` |
| 🪆 **Claymation mascot product spot** | the handmade stop-motion mascot demo — thumbprints, armature seams, holds and snaps | `claymation` |
| 📺 **Retro cel jingle ad — 1950s cartoon** | golden-age television cel animation with a sung jingle and a painted packshot | `retro` |
| 🎌 **Anime-style product spot** | the Japanese-style animated spot — hand-painted light, one emotional beat, a quiet voice-over | `anime` |
| 🍬 **Anthropomorphic product characters — comedy** | the pack-as-characters comedy spot with a punchline that settles the argument | `toon` |

All six are dynamic (4 beat flows each), carry a TIMING contract, use guided placeholders, keep
on-screen text verbatim in quotes and dialogue in official `<d>[Language]` markup with speaker IDs.
Animation pack now claims `mascot / cg / retro / toon` (plus `claymation / anime` already), and the
product pack stacks with animation so an animated product spot keeps both craft brains.
Library: **104 blocks · 25 dynamic · 0 parse skips**; closest neighbour 0.22–0.25 (threshold 0.72).

## Q1h · Poor-result triage + Forge hardening — SHIPPED

A user-forged block ("Titanic Drawing Scene") generated poorly. Diagnosis of that exact block:

| Symptom in the block | Why it wrecks the generation | Fixed by |
|---|---|---|
| `At 00:04.000 focus racks…` inside `[Shot 1]` | timecodes with no `[Shot N]` — the model reads them as cuts and invents shots that were never planned | linter warn "Timecodes without [Shot N] markers" |
| `structure: single` + 2 timecodes | the block contradicts itself | linter warn "Declared single-take but 2 cuts are written" |
| `{ARTIST}'s quiet "Hold still."` in `overall_soundscape` | speech in the soundscape field — official spec keeps dialogue in the description as `<d>[Language] …</d>` with a speaker ID | linter warn + scoring check "No dialogue left inside overall_soundscape" |
| `Subtle strings swelling at 00:03.000…` | cut times in the music field (it takes instrumentation/tempo/dynamics only) | linter warn + scoring check "Music field carries no cut times" |
| No `TIMING:` line, 5 beats in 8s | the model has no clock to pace against | linter warn "Pacing contract" (already existed) |
| No "Shot on … , 24fps" opening | no medium/look lock — the render drifts generic | linter info "No medium / camera declaration" |
| Named real actors in the user's idea | the SFW prompt had **no** real-people rule, so the face was either approximated into mush or ignored | fictional-characters rule added to both H3 system prompts, both inline fallbacks, the Forge prompt and the Guide |

Forge hardening (`public/prompts/template-forge.md` now teaches the craft contract): medium/camera
declaration, `[Shot 1]` without timestamp, timecodes always owed a shot marker, structure/skeleton
agreement, mandatory `TIMING:` line, soundscape = no dialogue, music = no cut times, verbatim
on-screen text, fictional characters, guidance-style `{TOKEN — what belongs here}` placeholders and a
preference for 4 `flows:`. Regression guard: `npm run selftest` suite 4b runs the actual bad block
through the linter and asserts every one of these fires, while the replacement template stays clean.

Two replacement templates shipped for that scene: **🎨 Artist & muse — period sketch session**
(12s, one continuous take, 4 flows) and **🖋️ The same session — 1912, in two shots** (10s, multi2).
Both carry a drawing-craft engine (graphite as tone, never legible portraiture), period production
design, the held-gaze beat, jewel specular and a single spoken line in official markup. Library:
**106 blocks · 27 dynamic**.

## Q1i · Tab-switch state loss — FIXED (ux)

**Reported:** forged a template, generated in Studio, came back to the Forge — empty box.

**Cause:** `App.jsx` renders each view behind `{view === 'x' && …}`, so switching tabs *unmounts*
the panel and React throws its state away. The Forge lost its description, pasted prompt, output and
parsed block; the Studio builder lost the whole half-written brief; Camera Director lost its shot list.
Nothing was persisted because only Forge *results* (`cps_forged`) were.

**Fix — `src/lib/persist.js`** (new, guarded read/write so a storage failure can never break a render):

| Panel | Key | Restored |
|---|---|---|
| 🔥 Forge | `cps_forge_v1` | mode, description, pasted prompt, target, tag/category/ratio/duration/music, selected LoRAs, forged output, parsed block, system prompt |
| 🛠️ Prompt Builder | `cps_form_v1` | the whole form (idea, refs metadata, placeholders, characters/chain, workflow, ratios, duration…) |
| 🛰️ Camera Director | `cps_cam_kfs_v1`, `cps_cam_box_v1` | keyframe shot list, subject framing |

Details that matter:
- **Mid-stream safe**: the Forge writes the growing answer to storage every 700 ms and flushes a
  snapshot on unmount, so switching tabs *while it is writing* no longer swallows the block.
- **Storage hygiene**: reference **thumbnails are never persisted** (base64 image bytes would blow the
  5 MB quota) — the panel's existing "previews are session-only, files never leave this machine"
  behaviour is unchanged.
- **Consent is not sticky**: the 18+ checkbox only restores ticked when the 18+ switch is still on,
  so the kill switch can always revoke it.
- **Transient state stays transient**: `busy`, errors and the streaming buffer are not stored.
- **Deliberate exit**: a `🗑 Start over` chip clears the Forge (saved templates untouched) and a quiet
  `♻️ kept` marker shows when the panel is showing restored work (it disappears the moment you edit).

Verification: `npm run selftest` suite 5 — 15 assertions on the persistence layer (round-trip, corrupt
JSON, quota failure, whitelist, restore hooks in all three panels, unmount flush, throttled stream writes).

## Q1j · `max_tokens must be positive, got: -1` — FIXED

**Reported:** `Suggestion failed: Ollama HTTP 400 {"error":"max_tokens must be positive, got: -1"} — offline filler used instead.`

**Cause:** my own no-length-limit change sent `num_predict: -1` on every Ollama chat call.
Older builds read `-1` as "generate until the context is full", but newer builds and the hosted
service validate positivity and reject the whole request — which killed the ✨ Suggest call (and would
have killed generation too), falling back to the offline filler.

**Fix — a positive ladder with automatic retry** (`src/lib/ollama.js`):
1. Default cap is now `16384` (positive, effectively unlimited for prompt writing) — never a negative.
2. If a server answers 400 naming `max_tokens` / `num_predict` as invalid, the SAME call steps down
   `16384 → 4096 → 2048 → omit` and retries automatically. The user never sees an error.
3. The working value is remembered (`cps_num_predict`), so the next call goes straight there — one
   request, no repeated failures.
4. An unrelated 400 (bad model name, etc.) is **not** swallowed and never touches the stored mode.
5. An explicit per-call cap (the vision reads use 180/220) is still respected.

Prompt length remains unlimited: this only bounds how many tokens the model may write back, and
nothing is truncated on our side. Verification: `npm run selftest` suite 6 — 7 assertions driven by a
stubbed Ollama that reproduces the exact reported 400.

## Q1k · 🔀 Everything-varies fashion templates — SHIPPED

**Reported:** "where are all those new fashion templates where everything varies — outfit design, model,
her presentation, action, interaction with outfit, location, camera?" **Honest answer: it had not been
built.** Only 6 fashion templates were dynamic (Room tour, 3 jewellery, LTX adaptive flow, hair spot);
every other fashion template was static and *nothing* varied per variant — variants only rotated the
beat flow and raised temperature.

**Now shipped — the variation engine:**

| Piece | What it does |
|---|---|
| `public/prompts/fashion-variation.md` | the pools: 6 concrete options each for **MODEL · OUTFIT DESIGN · PRESENTATION · ACTION · OUTFIT INTERACTION · LOCATION · CAMERA** (external md, consistent with house rules) |
| `templates.js` | parses `vary: A | B | …` into `t.vary` and round-trips it through `templateToMd` |
| `prompts.js` | `variationBlock()` states the contract per variant: *"variant 2 of 3 — take option #2 of every pool; variant 1 owns #1, variant 3 owns #3; do NOT reuse their outfit silhouette, model, presentation, action, interaction, location or camera"* — injected in both H3 and LTX paths |
| `StudioForm.jsx` | carries `templateVary`, attaches the contract with `variantIndex/variantTotal`, fetches the pools on demand and appends them as system craft **only** for varying templates; console logs `🔀 variation contract: 7 dimensions · variant 2 of 3` |
| UI | 🔀 pill on the template card (shared by library + picker) and a builder line "*7 dimensions vary — every variant draws a different option from each pool*" |

**8 fashion templates upgraded in place** (same titles, now 4 flows + 7 varying dimensions each):
Editorial fashion film · Walk-in approach · Street-style walk · GRWM styling moment · OOTD 5-second hook ·
Twirl reveal · Lookbook quick-cuts · Luxury editorial atmosphere film. Each keeps its existing craft and
gains a FLOW LIBRARY (4 architectures) plus a per-dimension BEAT ENGINE — an unnamed dimension
disappears from the film, a named one becomes a beat.

**Result:** a 3-variant run of one template now yields 3 beat architectures × 3 outfits × 3 models ×
3 presentations × 3 actions × 3 garment interactions × 3 locations × 3 camera languages.

**Verified:** `npm run selftest` suite 7 (18 assertions: every 🔀 template lints clean with 7 dims and 4
flows, pools file complete per dimension, variant 1/2/3 receive different option assignments, the
no-repeat rule is present, a non-varying template gets no contract, pools are never inlined in code).
Library: **106 blocks · 35 dynamic · 8 varying**. Audit prints the new count.

## Q1l · System-prompt dependencies, detail density, women-only fashion cast — SHIPPED

**Asked:** *"what if my system prompt depends on additional files?"* · *"push adding more details for location,
subject, outfit — more details give AI more consistent output"* · *"all our fashion is for woman no man, please
ensure this."*

### 1 · A system prompt can depend on other files — `@include`
`src/lib/sysfiles.js` resolves directives in any system prompt before it reaches the model:

```
@include shared/craft-detail-and-cast.md      ← relative to the prompt file
@import packs/fashion.md                      ← same thing, alias
[[include: packs/ugc.md]]                     ← bracket form
```

- paths resolve **relative to the including file**, with a **root-relative fallback** (so `@include packs/x.md`
  written inside `packs/` still finds its target); a leading `/` means the site root
- **includes nest** (an included file may include further files), **depth-capped at 5**
- a **missing file** or a **circular include** is refused with a visible marker — the rest of the prompt still loads
- resolved dependencies are shown in ⚙️ Settings → System prompt ("📎 Dependencies") and logged on every
  generation (`system prompt set: SFW-H3 (22,394 chars) · 📎 dependencies inlined: …`)
- a dropped-in override file gets the same treatment

**The app's own prompts now walk the talk:** the shared doctrine lives in ONE file,
`public/prompts/shared/craft-detail-and-cast.md`, and all four system prompts (H3 + LTX × SFW + mature) pull it in
with `@include shared/craft-detail-and-cast.md` — edit it once, all four change on reload.

### 2 · More detail = more consistency (location · subject · outfit)
Added to all four system prompts, both inline fallbacks, the 🔨 Forge craft rules, the Guide, and re-stated in the
user message of **every** H3 and LTX generation (`DETAIL DENSITY`):

- **LOCATION** — type of place, era, materials, light source, 2-3 things actually in frame (never "a room"/"a street")
- **SUBJECT** — age range, build, hair length/colour/texture, skin tone, 1-2 distinguishing features, what the face is doing (never "a woman"/"a model")
- **OUTFIT** — garment, cut, fabric, colour, construction, fit, footwear; fabric behaviour in motion (never "a dress"/"clothes")
- the framing: *a stated detail is a lock the model cannot drift from* — and a blank placeholder must be filled
  with a specific value, never a category word

### 3 · Fashion is women-only
- **Cast lock** injected into every fashion / styling / lookbook / try-on / beauty / hair / jewellery / ethnic
  request in **both** H3 and LTX user messages — so it holds even with a user-supplied system prompt
- rule written into all four system prompts + both inline fallbacks + the 🎨 Fashion pack + the 🔀 variation pools
  file + the Forge craft rules + the Guide
- **`MODEL` pool fixed**: options 3 and 5 were men — replaced with women (all six options are women now)
- **Ethnic pack**: menswear routing keywords (`groom`, `sherwani`) removed
- **Linter**: new check `👩 Fashion cast — women only` warns if a fashion / beauty / ethnic block mentions a man
  (the `boyfriend jeans` garment idiom is whitelisted)
- **Audit**: `Cast lock (fashion / beauty / ethnic = women only): 43 blocks checked · masculine casting refs: 0`

**Verified — selftest suite 8 (33 assertions, 137 total):** include resolution (inline · nest · relative + root-relative ·
missing · circular · depth cap · the shipped prompts resolve with zero missing deps), doctrine present in all four
resolved prompts + both fallbacks + Forge + Guide, cast lock lands in H3 and LTX messages for fashion and *does not*
land on a cinematic request, a fashion idea under `category: Auto` is still locked, no fashion template mentions a
man, the MODEL pool is all women, and the linter catches a synthetic `a man in a linen shirt` fashion block while
passing `boyfriend jeans`.

## Q1m · Mature prompt can never be displaced by packs — SHIPPED

**Reported:** *"the pack thing killed our mature system prompt use."*

**Verified first (empirically, all 16 packs × 2 modes):** packs are purely additive — a mature generation's
system prompt is byte-identical at the front, with the pack appended after it. Measured on the real files:

| pick | reason | base | composed |
|---|---|---|---|
| auto | fashion (7,518) | system-prompt-mature.md intact | 33,025 chars |
| fashion | manual pick | intact | 33,025 |
| ugc | manual pick | intact | 29,074 |
| none | base only | intact | 25,507 |

So the pack system does not replace the mature prompt. **But tracing it surfaced two real defects that do kill
mature use, silently:**

1. **The log lied.** If `system-prompt-mature.md` was unreachable or empty, the run quietly used the SFW prompt
   while the console still printed `system prompt set: MATURE-H3 (… chars — system-prompt-mature.md)`. Same for the
   finish chip, which said `🔞 mature prompt set`.
2. **The fallback was silent.** Nothing in the Studio told you the 18+ run had no mature prompt.

**Fixed — new pure module `src/lib/syscompose.js`:**
- `chooseBase()` picks the base and, if a mature run has no mature prompt, returns `fellBack: true` with the reason
  — the Studio now logs it at **warn** level (`⚠ 18+ run has NO mature system prompt: … — this generation runs on
  system-prompt.md`) and raises a toast pointing at ⚙️ Settings.
- `composeSystem()` appends craft blocks and returns `baseIntact` — the base is a prefix of the composed text,
  nothing reorders, summarises or replaces it. StudioForm logs an error if that invariant ever breaks.
- `promptReport()` prints the truth: `system prompt set: MATURE-H3 · system-prompt-mature.md (25,507 chars) +
  📦 fashion +7,518 = 33,025 chars · 📎 dependencies: …`
- the finish chip is honest too: `🔞 mature prompt set` / `🛡️ SFW prompt set` / `⚠ 18+ unavailable — SFW prompt used`

**Mature rules stay OUT of the pack system** (user's direction): packs carry domain craft only; mature direction
lives in `system-prompt-mature.md` + `system-prompt-mature-ltx…` and their `@include`d files. A selftest asserts no
pack file can ever be a mature prompt.

**Verified — selftest suite 9 (17 assertions, 160 total):** base selection for H3/LTX × mature/SFW, reported
fallback for an unreachable or empty mature file, craft appended in order with the base byte-identical at the front,
`baseIntact` and block accounting, the honest report string, **the mature base surviving all 16 packs × 2 modes with
the mature-only addendum still present**, no mature pack file, and the StudioForm wiring (compose · report · warn ·
invariant).

## Q1n · System-prompt routing — pick your own file, or make one universal — SHIPPED

**Reported:** *"but it never used? we had universal system (auto) mode where it should use our default system
prompt we created — or have a way to pick that also."*

**Why a created prompt was never used:** there was no picker at all. The app had exactly four fixed slots and the
only way in — Settings → "📂 Override with local .md" — wrote straight into the **H3 · SFW** slot. So a prompt
created/uploaded by the user was silently ignored whenever the target was LTX, or the 18+ switch was on, or the
content routed to mature. Nothing in the UI showed which file a given generation would use.

**Shipped — a router with five entries:**

| route | meaning |
|---|---|
| 🌐 **Universal** | ONE file used for every generation — H3 + LTX, SFW + 18+ |
| 🎯 `H3 · SFW` | own file for the H3 SFW slot (default `system-prompt.md`) |
| 🎯 `LTX · SFW` | own file for the LTX SFW slot |
| 🎯 `H3 · 18+` | own file for the mature H3 slot (default `system-prompt-mature.md`) |
| 🎯 `LTX · 18+` | own file for the mature LTX slot |

- any file in `public/prompts/` (top level + `shared/`) is selectable — a new live index `/prompts/_index.json`
  from the same Vite middleware that indexes templates, so dropping a `.md` in makes it appear in the picker
- **📂 Upload .md → universal** makes a local file the universal prompt immediately, resolving its `@include`s, and
  remembers it in this browser (`cps_syscustom`) instead of the old session-only override
- routing is persisted (`cps_sysroute`); `↺ All Auto` restores stock behaviour in one click
- the picker shows per-slot status: the file in use, `📎 n` dependencies, and `⚠ missing …` for a route whose file
  is gone — a dead route is a **reported** fallback, never a silent swap
- the console names the source every generation: `🌐 universal prompts/my-file.md`, `🎯 routed …`,
  `🔞 mature file system-prompt-mature.md`, `⚠ SFW fallback`; the finish chip shows `🌐 universal prompt: …`
- template → native conversion in 📖 Learn follows the same route (`effSysText`)
- **Auto remains the default**, byte-for-byte the old behaviour — zero routes = the four fixed files

**Verified — selftest suite 9 extended (+18, 178 total):** universal wins for H3 SFW *and* LTX 18+; a per-slot file
applies only to its slot; universal beats a per-slot file; the 18+ slot can be routed to your own file; a routed file
that no longer exists reports a fallback with the path in the reason; an empty route reproduces the old automatic
behaviour exactly; `slotOf()` covers all four combinations; the report is labelled; Settings lists live files, offers
the Universal row + four slot rows, flags an empty routed file, and the upload now routes instead of being ignored;
route + custom prompt persist across reloads; the Learn conversion follows the route.

## Q1o · ref18 — the "H3 Fashion Photo shoot" brand film, studied and folded in

**Source:** reddit r/StableDiffusion `1wqgmyy` (author R34vspec) — a 1:58 UNIQLO-branded multi-room photo-shoot film.
Reddit blocked every HTML/JSON path, so the video was pulled the reliable way: `/rss` for the post, then the
`HLSPlaylist.m3u8` → `CMAF_720.m3u8` byte-range segment list → 30 ranged appends → a playable 20 MB mp4
(1280×706, 30 fps). Study assets: `uploads/ref/ref18.mp4`, 14 `ref18-f*.jpg` frames, two 3×4 contact sheets.

**What the film actually does (watched, not imagined):** the MODEL IS THE CONSTANT and everything around her changes —
8 rooms, each with its own light signature and its own look, cut as one tour. Rooms: white-painted loft with black
steel windows and a hard window shaft on wood · white cyclorama studio with the top-light box visible in frame ·
raw-concrete industrial hall, cold daylight, reflective floor · terracotta-plaster room with a diagonal sun edge ·
blacked-out studio edge-lit by vertical LED strips. Beats per room: walk-in past the windows → quarter turn →
lean-and-laugh → arms crossed → hands in pockets. Inserts are **faceless**: a rust-bomber sleeve/zip macro, and the
back of her head with the hair falling. One shot puts the **cinema camera on its tripod in the foreground** — the
photo-shoot reads as a set. Brand cards open (blurred card, room sharp behind) and close (logo at chest height,
then an end card). The author's own note: *"the only way to get a decent face at long shots is to really crank up
the resolution… latent upscale, face detailer — nothing works as good as just rendering it at 2.0MP."*

**Shipped:**
- **Craft** → `public/prompts/packs/fashion.md` §"Multi-room photo-shoot tour" — room-light signatures, faceless
  inserts, the camera-kit meta beat, the observed tour vocabulary, one-look-per-room catalogue rule, brand-card
  grammar, and **FACE AT DISTANCE** (prefer 2K, keep a close/medium per room, never resolve a look only in a wide).
- **Template** → "Photoshoot tour — many rooms" (H3 · 16:9 · 2K · 12s · multi3 · 10 fields · 4 flows:
  ROOM TO ROOM WALK | CLOSE FIRST, ROOM SECOND | INSERT LADDER | CAMERA KIT IN FRAME) and **everything varies**
  — `vary:` on all 7 dimensions, so variants rotate rooms, looks, models, presentation, action, garment
  interaction and camera together.
- **Linter** → new per-template check `🖼️ Render resolution for faces — <res>`: ok at 2K, info when a
  fashion-family template is set to 768P or lower, quoting the reference finding.
- Library: **107 blocks · 36 dynamic · 9 varying** (audit verified).

**Token discipline:** the block was written at 14 placeholders, then genuinely-redundant tokens were merged
(medium → CAMERA, floor → LOCATION) rather than left to trip the merge hint — final 10 fields, longest inner
token 99 chars, lint score 92, zero warnings.

## Q1p · One room = one photo shoot · chains of templates — SHIPPED

**Asked:** *"yes but one template means one room one photo shoot, chain same model different look and different
location photo shoot — this will be new template. also we can have a chain option on template page which can be
clicked and allows select multiple template then send them together to input box and then suggestion handles
consistency to generate prompts."*

### 1 · The template rule, corrected
- **"Room photo shoot — one room, one look"** — the unit: ONE room, one light design, one look, one faceless
  insert; the camera may turn but the set never moves. 4 flows (ENTER AND SETTLE · LIGHT FIRST · WALL WORK ·
  SEATED FRAME), 7 varying dimensions, 9 fields.
- **"Photo-shoot tour chain — same model, many rooms"** — the chain recipe that replaces the old single-clip
  multi-room tour: `chain: 4` + `chainrule:` metadata, one clean scene per generation, same woman, new room-light,
  new garment and new action per scene, with the ref18 craft (room light signatures, faceless inserts, the
  camera-kit-in-frame beat, face-at-distance resolution rule).

### 2 · 🔗 Chain mode on the Templates page
- a **🔗 Chain mode** button in the Templates hub: tick templates in order, the bar lists them as
  `1. name ✕ · 2. name ✕ …` with ⇅ reorder and clear, then **➜ Send chain to Builder (N)**
- a **chain recipe** card skips selection entirely — its CTA reads **🔗 Chain 4 scenes** and sends N scenes of
  itself in one click
- templates travel as `cps-load-chain` → App latch → builder, one scene per template, each scene keeping its own
  skeleton (the chain panel already supported per-scene templates — now something fills them)

### 3 · The suggestion handles consistency
When a chain lands in the builder, `planTemplateChain()`:
- fills `chain.scenes` (one per template, own template attached), points the builder at scene 1, and sets the plan
  length to scenes × clip length
- asks the planner in **TEMPLATE CHAIN mode** — the new rules in `chain-planner.md` tell it to lock the person
  (face, hair, skin, build, sole-subject) and the technical constants (grade, lens language, frame rate) while
  every scene gets its own room, its own named light and its own garment, and to write ONE directable action per
  scene matching that scene's template
- writes a **rule-based bible offline** too (no provider needed): *SAME WOMAN IN EVERY SCENE … CONSTANT ACROSS
  THE CHAIN … CHANGES PER SCENE …* plus the template list
- the Forge can now author chain recipes (a chain toggle + scene count in the recipe request)

### 4 · Placeholder identity bug found and fixed on the way
Linting the new pair exposed it: the same placeholder written twice with different guidance
(`{MODEL — the same woman}` in the idea, `{MODEL — age, hair, skin, build}` in the skeleton) counted as TWO
placeholders — which meant **two 🧩 fields for one token**, and filling one left the other unfilled.
Fixed at the source: `uniqueTokens()` + `normalizePhValues()` in `tokens.js`, one field per token NAME with the
richest guidance kept, `fillText` resolves by name first, the builder, the template card, the linter and the audit
all count per name, and values saved under the old full-text keys migrate on load. Older library templates now
report honest field counts (the hair-spot block: 20 → its true count).

**Verified — selftest suite 10 (38 assertions, 217 total):** chain metadata parses, clamps and round-trips;
non-numeric values are ignored; the unit template carries no chain; the Templates page has chain mode off by
default, collects in order, refuses a one-template chain, sends one scene per template with the consistency rule;
recipe cards send N scenes of themselves; App latches and the builder consumes `kind: 'chain'`; scene templates,
plan length, planner mode, offline bible and per-scene actions are all wired; the planner documents TEMPLATE CHAIN
mode; and the placeholder-identity fix is asserted end to end (count once, richest hint, fill by name, migrate old
keys, all four counters agree).

## Q1q · Mature prompt brought up to the official skill (and pinned so it can't drift) — SHIPPED

**Asked:** *"if we updated mature system prompt also with the logic we learned from official skill?"*

**Audited first.** Section-by-section diff of SFW vs mature: every official-skill section
(craft techniques, community patterns, workflow modes incl. Ref2VA, duration scaling, camera/cuts,
dialogue & markup, audio) was already **byte-identical** between `system-prompt.md` and
`system-prompt-mature.md` (12 sections) and between the LTX pair (8 sections) — they were built from the same
official-spec batch. So nothing was missing there; what was missing was a guarantee that it *stays* that way.

**Shipped:**

1. **`public/prompts/shared/mature-craft.md`** — mature direction in ONE file, included by both mature prompts
   (`@include shared/mature-craft.md`), so H3 and LTX 18+ can never drift apart. It merges the two previously
   separate inline mature sections and adds the official-skill logic applied to mature work:
   - `<d>[Language] …</d>` carries **intelligible speech only** (stable speaker IDs, `<scenetrans>`/`<cutoff>`);
     **breath, gasps, moans, laughter are non-verbal human sound and belong in `overall_soundscape`** — never
     inside `<d>`, never in quotation marks
   - the exact voiceover phrasing ("says in an off-screen voiceover" + lips completely closed)
   - soundscape 1–4 sentences / music 1–3 sentences / `N/A` as the correct answer for most intimate scenes
   - **mature changes the subject, never the craft** — the format grammar applies unchanged
   - continuity across a mature series (lock identity once, reuse the same referring phrase, keep grade and
     lens constant), the own-talent reference = the identity path, and the coverage/resolution rule
   - no on-screen text over an intimate scene
2. **Both mature prompts** now carry a one-line policy pointer at the top plus
   `## Mature craft (18+ opt-in)` → the include. Their old inline sections are gone (no duplication).
3. **The ref18 resolution finding generalised** into `shared/craft-detail-and-cast.md`
   (all four prompts): never resolve a person only in a full-body wide — a face at distance is lost by the
   render, not fixed by upscaling; give the sequence a close or medium coverage.
4. **Drift guard in the selftest:** every section that exists in both the SFW and mature builds must be
   identical after include-stripping (H3: 12 sections, LTX: 8) — so a future edit to one prompt can no longer
   silently miss the other.

**Bug found and fixed on the way (real, user-visible):** the include resolver treated `@include` lines written
inside `<!-- HTML comments -->` as live directives — the instructions in `mature-addendum.md`'s own header were
being executed, which produced a bogus `[[ include refused — circular: prompts/mature-addendum.md ]]` marker
**inside the mature system prompt** on every 18+ generation. The resolver is now comment-aware: comments are the
author's notes, stripped before the prompt reaches the model, and a directive inside one is never executed.

**Verified:** resolved sizes — SFW H3 22,641 · SFW LTX 10,569 · mature H3 28,226 (3 deps) · mature LTX 16,106
(3 deps), all with **0 missing and 0 cycles**. Selftest **232 assertions**: mature-craft is one file shared by
both targets, SFW prompts never pull it in, the official speech/non-verbal split + voiceover phrasing + sound
budgets are asserted, both mature prompts receive the full craft, comments never act as directives, the
addendum's instructions stay out of the prompt, and the SFW↔mature drift guard passes for both targets.

## Q1r · `promptSet is not defined` — runtime crash fixed, and the class of bug now has a guard

**Reported:** after generating, the output card showed `⚠ promptSet is not defined` twice (one card per variant)
while the status line still read `1 variant in 193.1s … 🔞 SFW prompt set`.

**Cause:** my Q1m rewrite of the prompt-composition block replaced the old
`const promptSet = (matureOn ? 'mature-' : 'sfw-') + (isLtx ? 'ltx' : 'h3')` line with the new
`chooseBase()/composeSystem()` flow and did **not** re-declare `promptSet` — while `genOllama()` still did
`v.promptSet = promptSet` at the end. `npm run build` passed: **esbuild proves JSX and imports, it does not prove
that a name exists.** The failure only appeared in the browser, after the model finished streaming.

**Fixed:**
- the label is now a pure function, `promptSetLabel(baseInfo, isLtx)` in `src/lib/syscompose.js`, so it is unit-testable
  instead of living inline in a 2,000-line component
- it tells the truth about the run: `mature-h3` / `sfw-h3` / `routed-ltx · prompts/mine.md` /
  `sfw-h3 · ⚠ mature unavailable, SFW used: …` — a silent SFW downgrade can never look mature
- `OutputPanel` gained the matching badge: 🔞 mature · 🎯 routed prompt · 🛡️ SFW

**Also found by the new linter (pre-existing crash):** `CameraCard` rendered `⏱ {inp.duration}s` but the component
never receives `inp` — the 3D camera-path card would have thrown the same way the moment it rendered. Now reads
`opts.duration` from its own scope.

**Guard shipped — `npm run lint` (ESLint 10, flat config, `eslint.config.mjs`):**
- `no-undef` + `no-dupe-keys`, `no-const-assign`, `no-redeclare`, `no-unreachable`, `no-dupe-args`,
  `no-dupe-class-members`, `no-func-assign`, `no-self-assign`, `no-cond-assign`, `no-sparse-arrays`
- no style rules at all; only correctness — the check that would have caught this bug before it reached the browser
- an empty `react-hooks` plugin stub keeps the existing `eslint-disable-next-line react-hooks/exhaustive-deps`
  comments valid without adding the real plugin as a dependency
- **selftest suite 11** runs the same ESLint API in-process (skips with a note if dev deps are missing) and asserts
  `no-undef` is clean, plus the four `promptSetLabel` behaviours and that `promptSet` is defined where it is used

**Verified:** `npx eslint src scripts` → **0 errors** (4 unused-disable warnings from the stub rule).
selftest **243 assertions green** (suites 1–11), build ✓, audit ✓, app rebuilt and live on :5173.

## Q1s · Your banks, your files, and updates that can't erase them — SHIPPED

**Asked:** *"why empty? what exactly need to do"* · *"in my external file I have dialogues bank and examples,
secondary action bank to guide mature system — how exactly I add that to our system"* · *"I download complete
project and merge by hand, one mistake and my changes are gone — need a patching zip that never overwrites my
changes"* · *"if we have to manually edit any other file to bring those external data then I have to learn how"*.

### 1 · Why the cell was empty (diagnosis)
`📎` counts a prompt file's **own** `@include` lines. `H3 · 18+  📎 0` means that file (the user's own
`system-prompt-mature.md`, 10,760 chars) includes nothing — while their LTX mature file includes three. Not a bug.
The panel now says **"no dependencies of its own"** in words instead of leaving a blank gap.

### 2 · 🧩 Attach your own files — no prompt file edited
- `public/prompts/banks/` — a home for banks (dialogues, secondary actions, examples, wardrobe bibles) with a README
- new endpoint `/prompts/_tree.json` (same Vite middleware, recursive, depth-capped) lists every `.md` under
  `public/prompts/` for the pickers
- ⚙️ **Settings → System prompt routing → 🧩**: five attach rows (🌐 all generations · H3 · SFW · LTX · SFW ·
  H3 · 18+ · LTX · 18+). Pick a file → appended to the system prompt **for those generations only**, includes
  resolved, removable chips, persisted with the rest of the routing
- the generation log names them: `… + 🧩 dialogue-bank.md +4,102 = 39,846 chars · 🧩 attached context: prompts/banks/…`
- `public/prompts/system-prompt-sample.md` ships as a copy-me starting point for a routed prompt of your own

### 3 · `npm run patch` — an updater that cannot overwrite your work
New tooling: `scripts/patch.mjs` + `scripts/ziplib.mjs` (dependency-free ZIP reader/writer, tests prove the CRC32).

| command | what it does |
|---|---|
| `npm run patch -- patch.zip` | applies an update safely; writes `PATCH-REPORT.md` + `patches/applied.json` |
| `npm run snapshot` | hashes the whole project → `patches/state.json` (the "what I shipped" reference) |
| `npm run make-patch -- v1.2` | zips every file changed since the snapshot, with base hashes in `manifest.json` |

**The rule:** a local file is replaced only when it is byte-identical to the version we shipped. Otherwise the
incoming version is written as `<file>.new`, the local file is left exactly as it is, and the conflict is listed.
**Nothing is ever deleted**, and the tool never renames a `.new` over a user file.

**Never touched at all:** `banks/**`, `user/**`, `mature-addendum.md`, `*mature*.md`, `templates/user-*.md`,
`system-prompt-sample.md`, `.env`, `patches/**` — extensible via `patch.config.json`.

**Verified — selftest suite 12 (32 assertions):** glob semantics, protected-path coverage, the full decision table
(update · same · add · conflict · keep), the report content, ZIP round-trip + CRC32, and a real end-to-end run on a
throwaway tree — the unmodified file updated, the user-edited file **not** overwritten with its new version at
`.new`, the protected bank untouched, a new file added, an unmentioned file untouched, nothing deleted, exactly one
conflict reported. Plus wiring checks for the commands, config, snapshot, banks folder and attach feature.

**Docs:** `docs/YOUR-FILES-AND-UPDATES.md` — the three procedures (one-line include · app attach · patching), a
short "what survives updates" table per job, and the receiving checklist.

### Q1s addendum · the patch that travels alone
Every archive now carries **`apply.mjs`** — `scripts/ziplib.mjs` + `scripts/patchcore.mjs` +
`scripts/apply-standalone.mjs` inlined by `npm run make-patch`, so a receiver whose copy predates the patcher can
still apply the update with plain Node (`--list`, `--dry-run`, `--accept-new`, `--clean`). `--accept-new` is the
one-command finish: new version in place, the receiver's previous copy saved under `.patch-backup/<version>/` first,
protected paths still untouched. Mature prompts are excluded from releases by default (`MATURE_EXCLUDES`; a release
must pass `--include-mature`), and `--allow <path>` exists for the one-time shipment of a protected file (a new
`patch.config.json`, the banks README) — the receiving side still refuses to replace a file that already exists.
Suite 12 grew standalone tests: the generated applier is syntax-checked on plain Node, run against a throwaway
project, and asserted to add what is missing, never overwrite a differing file, back up on `--accept-new`, leave no
stale `.new`, never touch a mature prompt or a bank, and clean up only its own scaffolding.

## Q1t · "I can't find it" + "my mature prompt isn't used" + the outfit expander — SHIPPED (v2.2)

**Asked:** *"I am still not able to find these things we made — the room fashion template with everything
dynamic (location, model, clothing, movement, action, interaction)"* · *"I am still not getting my mature
system prompt used"* · *"fashion clothing generation — study this system prompt I made long ago, we can do
better"*.

### 1 · The mature prompt that never ran (root cause, fixed)
`StudioForm` computed `mature = consent && wants`, where `wants = looksMature(idea + template)`. A mature
run therefore required the *idea text* to hit a keyword regex: switch on + an idea the regex missed = the
SFW file silently, with the only clue in the console. Now:

- `src/lib/maturegate.js` — `matureRouting({consent, blocked, wants})`, pure and tested: **the switch is
  the decision**, the detector only returns `advisory`.
- StudioForm uses it in both paths (generation + native-multishot label); the regex moved out of the
  component and got a wider vocabulary (bra, corset, teddy, stockings, intimate, undress, seduct`…`).
- the builder prints the file that will run, its char count and `📎` count under the switch, warns when
  that file is empty/unreachable, and keeps the loud SFW-fallback message;
- suite 11c pins the four cases (on/off × reads-18+/reads-SFW) plus a static guard that the veto is gone.

### 2 · The everything-dynamic room template (findability + one axis more)
`Room photo shoot — one room, one look` → **`Room photo shoot — every dimension dynamic`**, now carrying
**eight** live dimensions (OUTFIT DESIGN · MODEL · **MOVEMENT** · PRESENTATION · ACTION · OUTFIT
INTERACTION · LOCATION · CAMERA). A `## MOVEMENT` pool was added to `fashion-variation.md` (gait, tempo,
footwork, weight landing) — distinct from PRESENTATION (attitude) — so variants differ in *how she moves*
as well. Suite 7 now asserts the template declares all eight dims with a live `{MOVEMENT}` token and that
every dimension any template varies has a pool.

Attempted first and **rejected by the near-duplicate guard** (86% overlap with the room template): a
separate "everything dynamic" template. The guard was right — one template with eight fields beats two
near-copies — and the incident is a nice proof the similarity gate works.

### 3 · 👗 Fashion outfit expander (the user's prompt, rebuilt)
`public/prompts/fashion-outfit-expander.md` — keeps the user's contract (one line, nothing else, verbatim
preservation, no angle brackets, `Main:`/`Top:/Bottom:` labeling, lingerie discipline, seven-part
footwear, trend score, designer lineage) and adds: a fixed 13-label field order where every field always
appears (`none` when empty) so the line stays parseable; a banished-adjective table that forces
manufacturable description; a 60/30/10 three-colour discipline with one metal; an executable era table
(1920s→2030s with construction markers); traditional dress with real component names (Choli/Ghagra/
Dupatta, Nivi drape, pleat counts); byte-stable re-call names for series continuity; variation by axis;
a ten-point silent self-check; and three fully instantiated worked examples. Wired into the app:
**👗 Expand outfit** in the 🧩 dialog runs it for `{OUTFIT DESIGN}` and drops the finished line into the
field. Suite 11d pins the contract, the file's existence and the wiring.

## Q1u · Spoken outfit reveals, style-type-first, and dialogue that actually leaves her mouth — SHIPPED (v2.3)

**Asked:** *"dialogues coming background voice model not talking"* · *"for fashion outfit demos the details should be
spoken — if there is a sweetheart neckline she moves her hand over it and says something, then a waist item, then the
back"* · *"also interact with world around and outfit"* · *"feminism, glamour, attitude, her fashion sense"* · *"as first
placeholder I want style/type defined — tradition, office wear, swimwear — used to actually define the outfit further"* ·
*"if you need, just give it as a new template, or variations for various style/type"*.

### 1 · The dialogue bug: a voice from nowhere
The request told the model *what* to say but never *that the character is the one saying it*. Result: the line played as
narration while the person on screen stood with a closed mouth. Fixed in two places:

- **`public/prompts/shared/on-camera-speech.md`** (new, included by both SFW system prompts) — the two modes
  (ON-CAMERA SPEECH vs VOICEOVER), the five things an on-camera line must state (face in frame, mouth unobstructed and
  moving, one stable speaker ID, verbatim `<d>[Language] …</d>`, voice quality outside the tag), timing budgets
  (5-8 words ≈ 1.5-2 s, 9-15 ≈ 2.5-3 s), and the rule that no intelligible word ever enters `overall_soundscape` or
  `non_diegetic_music`.
- **`src/lib/prompts.js`** — a requested line is now written as `- Dialogue: ON CAMERA …` with *"her face is in frame
  and her lips move with every word … never resolve this line as an off-screen voice"*; the no-line-requested path
  defaults to on-camera too, with voiceover allowed only when the line is narration.

Suite 11e pins all of it (7 assertions on the craft file + 4 on the built message).

### 2 · The spoken detail tour (new drop-in template file)
`public/prompts/templates/outfit-reveal.md` — two blocks, add-only in a patch (a new file can never conflict):

- **Outfit reveal — spoken detail tour**: STYLE TYPE is the **first field**; then ANNOUNCE (the style type out loud) ·
  NECKLINE/COLLAR (hand on the line + a line about it) · WAIST · BACK/DRAPE · HEM/FOOTWEAR · CLOSING. One spoken beat
  per shot, one world contact per shot (chair back, doorframe, curtain, ledge, table), exactly one texture insert, and
  every spoken beat framed to the collarbone or closer so the mouth reads. Four flows: TOUCH AND TELL · MIRROR
  CONFESSION · FEET FIRST · WORLD FIRST.
- **Wardrobe series — one woman, many style types**: `chain: 5` recipe rotating STYLE TYPE per scene with a spoken
  introduction in each.

### 3 · STYLE TYPE as a first-class dimension
A 12-option `## STYLE TYPE` pool in `fashion-variation.md` (tradition, office, swimwear, evening, bridal, streetwear,
athleisure, resort, winter outerwear, denim, lingerie/boudoir, heritage-meets-modern) — variants rotate registers, not
just garments. The outfit expander gained a **STYLE TYPE FIRST** section: the register fixes the garment family, the
coverage and weight (120-220 gsm swimwear vs 480-800 gsm outerwear), the footwear family, the ornament register and the
finish language, and a conflict with a named garment is resolved in cut and styling, never by swapping the garment.

### 4 · Static-host fix
`vite.config.js` now writes `prompts/templates/_index.json` into `dist/` at build time, so drop-in template files are
picked up on any static host, not only under `npm run dev` / `npm run preview`.

## Q1v · Garment colour, the two immersive LoRAs, and medical/science animation — SHIPPED (v2.4)

**Asked:** *"we are not handling colors in clothing, i found always white color outfit"* · *"lets do some template for
below loras: shamanic/minimax-h3-equi360-lora, EllipsesMark/minimax-h3-vr180-sbs-lora"* · *"lets add few medical
animation templates, for reference you can search for Hybrid educational videos or designmate educational videos on
youtube"*.

### 1 · The white-outfit bug (diagnosed, fixed in four places)
The garment placeholder read `{OUTFIT DESIGN — the garment: silhouette, fabric, construction detail}` in **15
templates** — colour was never requested, so the model used its own default (white), reinforced by four exemplars with
white/ivory garments in the few-shot library. Fixes:

- `{OUTFIT COLOUR — colour family and finish}` is now a live field on **every** fashion template that asks for a
  garment, and a 🔀 varying dimension on the showcase four (room shoot, chain, reveal, series) — **9 dimensions** on
  the everything-dynamic room template;
- a **12-family `## OUTFIT COLOUR` pool** in `fashion-variation.md`, each family naming colours *and* finish, and all
  six `OUTFIT DESIGN` pool options rewritten to carry their own colour;
- a **`## Colour — the garment carries one, always`** doctrine in `packs/fashion.md`: name colour + finish together,
  never default to white/ivory/cream, 60/30/10 areas + one metal family, state where each colour sits, place colour
  against the room's light, prefer saturated mid-tones at 2K, rotate colour across variants;
- two exemplars rebalanced (ivory knit → tobacco-brown, ivory coat → tomato-red), leaving two intentional whites.

Suite 11g pins all of it, including a template-wide sweep asserting no template can ask for a garment without also
asking for its colour.

### 2 · Immersive templates for the two H3 LoRAs
`public/prompts/templates/immersive.md` — **Equirectangular 360 — sphere tour** and **VR180 stereo pair — immersive
walk**, both written to the LoRA authors' evaluated settings (21:9 · 768P · 5s, expansion off, scale 1.0) with the
trigger words and the exact layout sentences from the model cards, plus the projection craft (wrap seam, polar bands,
no horizon tilt, 2:1 resize-not-crop for 360; 1.5-4 m stereo window, no fast pans, no on-screen text, ffmpeg +
`spatialmedia` packaging for VR180). Both LoRAs entered `loras.md` with triggers and settings, and they route to the
`medical` pack, which also carries the projection rules (order 26). Suite 11h verifies the layout sentences
**verbatim**, the settings, the stereo window, the text ban and the packaging command.

### 3 · Medical & science animation
`public/prompts/templates/medical-education.md` (4 templates) + `public/prompts/packs/medical.md` — modelled on the two
references: **Hybrid Medical Animation** (pharmaceutical MOA and disease-state storytelling, cinematic macro,
translucent anatomy) and **Designmate / Eureka.in** (classroom 3D science, labelled teaching models). Templates: MOA
film, disease-state journey, classroom labelled explainer, and the hybrid real-footage + 3D-insert format that
outperforms either half alone in the published RCTs. The pack's core rule: **a mechanism is a physical event** (what
touches what, in what order, what changes visibly) — and medical content is written as illustration, never advice.

Suite 11h also asserts each of those four templates routes to the medical pack, and that the audit's routing dry-run
reaches a pack for every template but one (the multi-shot mode template, by design).

## Q1w · Colour second pass · chain reordering · two more medical templates — SHIPPED (v2.5)

**Asked:** *"we are not handling colors in clothing, I found always white"* (repeated) · *"is it possible to
rearrange scenes in chain?"* · *"add few medical animation templates"* (repeated).

**1 · The colour fix was incomplete.** v2.4 swept only `{OUTFIT DESIGN}`. A library-wide audit found **30+ more**
garment placeholders that never asked for a colour — `{GARMENT — fabric weight, drape, silhouette, construction
details}`, `{DRESS — cut, straps, detail}`, `{SKIRT}`, `{TOP — cut and detail}`, `{BOTTOM — print and fit}`,
`{LEHENGA …}`, `{ETHNIC SET …}`, bare `{GARMENT}`, bare `{OUTFIT DESIGN}` — all now naming colour and finish. The
selftest guard was widened from one token name to **every token matching a garment word, block-wide**, with a
30-word colour vocabulary. The instant engine gained a **wardrobe bank** (12 families) that fires only for
fashion ideas with no colour word and never overrides a user's colour.

**2 · Chain reordering.** Templates page: `◀ ▶` step, `⇤ ⇥` jump to front/back, `✕` remove, `⇅` reverse. Builder:
`↑ ↓` per scene row, with `moveScene` remapping `active` so the scene being Directed stays the same scene. Suite
11i tests the splice/jump/remap semantics directly.

**3 · Medical templates: six.** Added **Physiology cycle — seamless teaching loop** (`loop: true`, a real loop
contract) and **Patient-education short — vertical** (9:16, calm, one takeaway, phone-safe, honest narration).

## Q1y · "Changing template not changing the inputs" + "are we doing prompt duration correctly" — SHIPPED (v2.6)

**1 · The bug.** Every template-switch path kept `ph` (the placeholder values) and, from the picker, did not apply the template's pinned
settings at all: switching from an outfit template to a medical one left the old 🧩 values in place, and same-named tokens were silently
filled with the previous template's content. `switchTemplate(prev, tpl)` (pure, in `src/lib/templates.js`) now owns the whole operation —
pinned settings applied, `ph` pruned to tokens the new material actually contains, the template's own idea adopted only when the idea box
is empty — and the picker, the Templates page (`{ ...tp.settings, template: tp.t }`), a chain scene's Direct button, the chain planner and
imported examples all route through it. Suite 11j pins the behaviour.

**2 · Duration.** The audit found the pipeline's real weakness: the runtime lived in the user message but nowhere in the generated text, and
the pacing formula ignored the user's own 1/2/3-shot choice (`duration<=6 → "ONE shot"` even for `structure: multi3`). Now
`src/lib/duration.js` computes the clock once — shots from the structure, cuts spread evenly, ≥1.5s per shot, loop = one take — and
`clockLineH3`/`clockLineLtx` hand it to the model as a hard budget (exact timecodes, "no timecode may be 00:10.000 or later", the tail rule,
the runtime-stated-in-the-opening-sentence rule, per-shot word budget). The instant engine uses the same clock for its plan and timecodes
(5s × 3 shots was cutting 2/2/**1s**; now 1.67s each). The audit gained six checks (runtime stated, timecodes in window, ≥1.5s tail, shot
count, per-shot speech fit, wardrobe contradiction) and the linter warns when a skeleton's example cut times overrun its own pinned
duration. Run against the prompt the user pasted: at **10s/multi3** it passes the clock (cuts 3.5/7.0, tail 3.0s) and fails only on the
missing runtime statement and the wardrobe contradiction; at **8s** it fails the tail (1.0s) and the speech fit — which is exactly the
mismatch the new clock removes. Suite 11k pins the maths, the messages and the audit behaviour.

## Q1z · Subfolder templates — SHIPPED (v2.7)

**Asked:** *"add support for sub folder template"*.

The library was flat by construction: the vite plugin's `_index.json` used a plain `readdirSync`, and the loader did
`String(f).split('/').pop()` before fetching — so a nested file was invisible, and even if listed it would have been fetched
from the wrong path. Now:

* **`scripts/templatescan.mjs`** — one recursive scanner (returns `{rel, folder, name, abs}`, skips `_*`/`README*`/dotfiles,
  4-level cap) used by `vite.config.js`, `scripts/audit-prompts.mjs` and `scripts/selftest.mjs`, so all three can never
  disagree about the folder.
* **`src/lib/templatepaths.js`** — the browser-safe half: `templateUrl` (encodes every segment, keeps slashes),
  `isUserTemplate` (a subfolder file is the owner's), `withFileMeta` (stamps `file/folder/src`).
* **Loader** fetches by relative path and reports `N files scanned · M subfolders: …`.
* **UI** — folder filter in the picker and the Templates page, `📁` pill on every card, folder name searchable.
* **Patch safety** — `public/prompts/templates/*/*` + `*/*/**` + `**/user-*.md` are protected, so updates never touch a
  folder tree; the shipped demo needed an explicit `--allow` to ride in as a new file.
* **Build/host** — recursive `_index.json`, `_folders.json`, per-folder `_index.json` in `dist/`, plus a `_folders.json`
  fallback in the loader for static hosts. Suite 11l pins the scanner, the paths, the protection rule, the loader and the UI.

## Q1aa · "the placeholder filler still not filling color variety, mostly ivory or white" — SHIPPED (v2.8)

**Root cause.** Three independent pale biases, none of which the v2.5 work touched (it fixed the *templates*, not the *fillers*):

1. `public/prompts/placeholder-filler.md` had **no colour rule at all** — "matching era, tone, style and palette" makes a model reach for the editorial default, ivory.
2. The offline filler's colour pool literally contained `'ivory white'` (1-in-6) and its fabric pool had no colours at all.
3. Nothing rotated: pressing ✨ Suggest again, or filling two colour tokens in one go, returned the same family — so a batch looked monochrome even when the picks were random.

**Fix.** `src/lib/colourbank.js` is now the single source: twelve families (one deliberately pale), `namedColourOf`, `familyForColour`, `isPaleLed`, `rotationBrief`, `wardrobeSentence`. `src/lib/filler.js` holds the filler implementation (stateful wheel + "echo the named colour" rule) so the UI, the instant engine and the self-test share it. `placeholder-filler.md` carries the doctrine. The Studio's ✨ path injects `rotationBrief()` and advances the wheel by 3 per press; the instant engine's `WARDROBE` rotates with the variant index; `fashion-variation.md`'s OUTFIT COLOUR pool gained the rule line ("White, ivory and cream are choices, never defaults… the base is always a colour"). Suite 11m pins the bank, the filler behaviour (12 presses → 12 families, named colour echoed, named white respected), the prompt doctrine and the engine's per-variant spread. 489 ✔.

## Q1ab · "I created a file named fashio_beat.md and added in starter — not getting them listed" — SHIPPED (v2.9)

**Root cause: not the file.** The two rooms-outfit-tour templates the user pasted parse perfectly — suite 11n keeps their exact
shape as a fixture (`scripts/fixtures/user-fashio-beat.md`, outer ```` ```markdown ```` fence + inner fences + two H3 blocks
with six flows) and pins 2 blocks / 0 skipped. The install, however, was seven patches behind: its `vite.config.js` predates
v2.7, so the plugin it runs writes a **flat** `_index.json` (root files only) and `prompts/templates/starter/fashio_beat.md` is
never fetched. Reproduced exactly with a stand-in server in "old" mode: 5 root files, their file absent.

**Fix (works on an install that never accepts a new `vite.config.js`).**

* `listTemplateSources()` in `src/lib/templates.js` now **unions three sources**: `prompts/templates/_index.json` →
  `prompts/_tree.json` (written by *every* config version, so it is the escape hatch for old installs) → `prompts/templates/_folders.json`
  + per-folder indexes. Returns `{files, indexSeen, treeSeen, nestedSupported}`; the `_tree.json` route is filtered to `templates/`
  and to real template files. Old-mode probe went from 5 files → 7 including `starter/fashio_beat.md`.
* **Nothing is dropped silently.** A scanned file that yields no blocks becomes a `fileNotes` entry with the reason
  (`no template block found — a block needs a "## Title" line and a skeleton: integrated_multimodal_description: … for H3, or
  prompt: … for LTX`), surfaced in the picker, the Templates page and the console; the header counts
  `7 files scanned · 1 with templates`. A flat-index copy logs `subfolders unreadable in this copy` instead of pretending.
* **`await window.cpsTplDiag()`** — a console helper printing a table (file · folder · fetched · block count · titles) with the
  `nestedSupported` flag, so "why is my file not listed" is one call away.
* Loader bug found while pinning this: the legacy flat-file fallback (`prompts/templates.md`) used to fire whenever the folder
  scan produced **zero blocks** — so a folder that *was* scanned, but held nothing parseable, hid its own explanation behind a
  generic 404 message. It now only fires when the scan found no file at all, and the scan-failure path logs the reason
  (`window.cpsTplDebug = true` for the full error).
* Guide → Templates gained the five-step check order; the test copy of the user's file was removed from the shipped library
  (keeping it would have listed a duplicate they own) and lives on as the suite fixture instead.

**A second bug fell out of the rehearsal, and it was a bad one.** Rehearsing the patch against a byte-exact v2.8 install whose
`mature-addendum.md` had a *single-line* note appended (`<!-- my own mature direction for this shoot -->`, exactly how a user
annotates their own file) **hung the receiver**: the receiver's self-test stopped dead at the four-system-prompt resolution.
Root cause in `src/lib/sysfiles.js` — the HTML-comment stripper scanned the same line again after removing a comment:
`indexOf('<!--')` found the same comment forever, so the loop never terminated. Multi-line comments were fine (the shipped
addendum uses one), which is why it stayed hidden; any one-line note — and any line with two comments — froze the resolver,
and with it every prompt build that included that file. Fixed by walking `rest` forward instead of re-scanning `line`; three
pins added (one-line comment stripped, an include on the following line still resolves, multi-line block still stripped whole).
A user's own note can no longer freeze their app. **506 ✔**.

## Q1ac / Q1ad · "medical reel template is very poor" + the fashion reference set — SHIPPED (v2.10)

**Q1ac.** The medical library was film-shaped, not reel-shaped: `medical-education.md` shipped five 16:9 films (MOA, disease
state, classroom, hybrid, physiology loop) and one thin 9:16 block whose "hook" was a suggestion rather than a structure.
Replaced by `templates/medical-reels.md` — three reels that are built around how a reel is actually watched: the symptom hook
must land inside two seconds and is written as behaviour, not as a caption; the mechanism takes exactly one insert; the close
is ONE action held still so it can be screenshotted; the myth format puts the myth in the speaker's own mouth on camera with
verbatim dialogue; the walkthrough shows the room and the person before any equipment and never shows the clinical moment
(prepared tray, gloved hand at rest, monitor glow instead of a needle). All three carry a claims contract — no diagnosis, no
dose, no percentage, no cure, no before/after promise — a one-quoted-line text cap, safe-area framing and a timecoded budget.
Suite 11h keeps the whole pack honest (9 new checks: hook law, one action, on-camera speech, no needle, text cap, claims,
per-shot pacing, 9:16).

**Q1ad.** 22 fashion reference clips (Pinterest) were downloaded and studied — 4 frames per clip, contact sheets in
`refs/fashion/`, the reading written up in `docs/refs-fashion-2026-09.md`. Six of the recurring formats became
`templates/fashion-campaign.md`: the e-commerce 4-up cut collage, the jewellery macro ladder (one ornament per beat, macro
with a scale reference), the resort swim trio (water is the co-star, continuity of tan/wet hair/swim piece), the quiet-luxury
studio (mono-palette held to three tones, texture lit by a raking source, one close detail as the payoff), the heritage
doorway reveal (silhouette first, then the light takes over) and the breeze float (fabric only floats if she walks, turns or
lifts it). Every block names its palette and keeps the garment's colour stated, so the pack cannot drift back to default
white. The fetch recipe (savepin/kapadiya decode → pinimg MP4 route, because the `iht/hls/` path is dead and the sandbox's
ffmpeg segfaults on it) is recorded in the study doc for next time. **513 ✔ · 129 templates across 8 files · 0 skipped.**

## Q1ae · "always getting terracotta color now" — SHIPPED (v2.11)

**Root cause (mine, from v2.8).** The wheel was real but it could not move: the ask step was `3` against `FAMILY_COUNT = 12`,
so gcd(3, 12) = 3 and repeated presses only ever visited **four** families — oxblood, **terracotta**, deep plum, tomato red —
and because `createFiller()` started at position 0 on every mount, a session's *first* press always landed on family #4,
**terracotta**. Reproduced exactly: `familyAt(0 + 3).name === 'terracotta'`, and `new Set(i*3).size === 4`.

**Fix.** `COLOUR_STEP = 5` (coprime with 12, so twelve presses visit twelve families, from any starting position — pinned
for all twelve starts). The position **and the last family handed out** are remembered in `localStorage`
(`cps_colour_wheel`), so a new visit continues the wheel instead of restarting it; an answer never opens on the family the
previous answer used; the in-answer draw walks forward from the ask's start without advancing the stored position (the two
advances used to gang up: step 3 + one draw = net 6, gcd 6 again); `rotationBrief(index, avoid)` now tells the LLM which
family its previous answer used and forbids reusing it; and the instant engine offsets its seed by the remembered wheel and
advances it after every WARDROBE line, so regenerating one idea in a sitting gives a new family each time. Eight new pins
(the old symptom, coprime step, full coverage from every start, in-answer draw isolation, six mounts → six families, no
consecutive repeat, stored position, the brief's avoid line, and the engine's five-for-five). **525 ✔.**

## Q1af · two more fashion refs (intimates) — SHIPPED (v2.12)

The set grew by two: a lingerie **collection-launch** reel (launch card → lace macro → face/personality → second colourway, wordmark
once on the closing card) and a **shapewear demo** (locked front/side/back turn, waistband stretch-and-release, seam smooth, comfort
sit; benefit copy as one quoted line per beat). Both are product-first shop-window clips, so the templates were written to that
register rather than the boudoir one: framing stops at the garment's own coverage, body language stays factual, and the demo's copy
is restricted to what the construction does — no weight/inches/before-after/testimonial/medical claim, no price or discount, brand
wordmark only when named. The refs' copy and overlays are Spanish; the template keeps the structure and lets the request pick the
language for the quoted line. Folded into `templates/intimates-reels.md` (2 blocks, 4 flows and 5 varying dimensions each) with the
study addendum in `docs/refs-fashion-2026-09.md`. Library stands at **131 templates across 9 files · 0 skipped**.

## Q1ah · "missing inner garments — top jacket is there and no pants, or even undergarments" — SHIPPED (v2.13)

**Root cause.** A template may name a single piece and leave the rest of the body's clothing unstated; the renderer then fills
the silence with its own prior (usually nothing). The probe found **30 of 131 blocks** with a layer gap — outer layer with no
bottom (Lookbook film, Traditional brand-ad, Room outfit tour, Wardrobe series), top with no bottom (Fabric macro, DTC
founder-story, Photo-shoot tour, Quiet-luxury studio), something sheer/plunged with nothing named under it (Twirl reveal,
Boudoir portrait, Sari showcase, Beach swim, Heritage doorway, Breeze float). Two behaviours made it worse: the engine's
`WARDROBE` line only ever described **one** garment, and when the user's own idea carried a colour word the line was skipped
entirely — so a red jacket stayed a lone red jacket.

**Fix, in five places.** (1) The shared doctrine that all four system prompts include now opens the OUTFIT DETAIL rule with
*the stack is always closed*: base layer → main piece → bottom/lower half → outer (only if the look has one) → footwear, with
an explicit ban on a jacket/corset/sheer overlay appearing alone and a rule that anything sheer, plunged, open-backed or slit
names what sits beneath it. (2) The fashion pack gained the six-point checklist and the special cases (swim/lingerie = the
complete set; dress/sari/jumpsuit = whole; body-con still names its base). (3) The expander gained **LAYER COMPLETENESS** and
self-check 4b without touching its one-line output or its 100% preservation rule. (4) 30 template blocks were given a tailored
`LAYER STACK:` clause (generic / exposed / outer / swim variants). (5) A new warn-only linter check **🧵 Layering
completeness**, an audit line (`57 / 57 blocks carry the closed stack`), and an engine that now always states the stack —
echoing the user's own colour ("a bottom in the same crimson") rather than imposing a family — while leaving wardrobe-free
scenes alone. The pool's coat-over-knit option (literally a jacket with no trousers) was completed. **542 ✔**, suite 11o.


## Q1ai · "Jewellery macro ladder … not even 1% of what i have seen in video i shared" — SHIPPED (v2.14)

**What the user asked for.** *"we should start with full model framing and then show jwelley but in a way that we have model in context."*

**Root cause.** The block was derived from the refs' *macro* craft and its flow list opened with `MACRO FIRST`, and `flows[0]` is what the first variant, the first chain scene and the first generation use. So the default output opened on a hand and a pendant with the wearer "entering the frame only at the edge" — the exact inverse of the reference films, where frame 1 is the model in the room with the whole set legible and every macro after it is anchored on her body (sheet-01 frame 1 → pendant on her chest → face with tikka and jhumkas; sheet-11 frame 1 seated full look → neckline + hands → ring on the hand at the waist with the skirt; sheet-12 full model → necklace on shoulder skin → earring against the jaw → dark wordmark still).

**Fix.** (1) The template rewritten around a three-rung ladder — whole look in the room, the set in context, a true macro still anchored on her — with `NO ORPHAN MACRO` as a stated ban, a `{FRAMING}` placeholder for the opening frame, the closing beat moved back onto her face, the flows re-ordered (`FULL THEN LADDER` first) and the resolution raised to 2K so the new wide keeps the face. (2) A doctrine bullet in the shared craft file that all four system prompts include, so *every* ornament, accessory or detail beat is shot on the person. (3) The same rule as an operating procedure in the 🎨 Fashion pack, a line in the ethnic ornament section, and a house rule in the Forge. (4) The core try-on template's `PIECE-FIRST` flow and `[Shot 1]` no longer start on the piece alone. (5) A new linter check **📸 Wearer in frame** plus an audit count — **5 / 5** jewellery blocks open on her. Self-test suite 11p pins the doctrine, the linter's three verdicts, the template's flows/framing/2K and the whole library.


## Q1aj · "does not provide an export named 'readColourMemory'" — SHIPPED (v2.15)

**What happened.** After applying v2.14 the app would not load: `Uncaught SyntaxError: The requested module '/src/lib/filler.js' does not provide an export named 'readColourMemory' (at offline.js:2:10)`.

**Root cause — a protection with a sharp edge.** v2.11 added `readColourMemory` / `writeColourMemory` to `src/lib/filler.js`. On this install that file differed from what we shipped, so the patch engine parked the new one as `src/lib/filler.js.new` and left the owner's copy alone (exactly the "never overwrite my changes" rule). v2.13 then shipped a new `src/lib/offline.js` that imports those names by **name**. An ES module that imports a missing name fails at link time — before any code runs — so a stale helper file took the whole bundle down.

**Fix.** (1) New `src/lib/colourlink.js`: `colourbankBridge()` / `fillerBridge()` link by namespace and hand back the real functions when they exist, a working stand-in when they do not, and a single console note naming the file to take. (2) `offline.js` and `StudioForm.jsx` use them, so an older `filler.js` / `colourbank.js` degrades the feature (no remembered wheel position, no wardrobe line) instead of killing the app. (3) `PATCH-REPORT.md` now lists, under each conflict, the other files in the patch that import it plus the one-line fix. (4) The patch **ships `src/lib/filler.js` anyway** — it is unchanged since v2.11, so a normal diff would have skipped it, and a receiver whose copy is old would stay degraded forever. (5) Self-test suite **11q** pins the bridges, the stand-in wheel, the namespace linking, an end-to-end instant-engine run without the memory API, and the new report dependency line. **573 ✔**.


## Q1ak · "we hard code requirements … learn how model moves, how she represents her cloths how camera moves and cuts" — SHIPPED (v2.16)

**The complaint.** After trying the templates derived from the shared reference videos: every one of them hard-coded its requirements — a fixed shot list and fixed cut times — instead of learning *how the subject moves, how she presents the garment, how the camera behaves and where the cuts land*.

**Root cause.** `fashion-campaign.md` and `intimates-reels.md` were written as literal transcriptions of the reference structure: `BEAT ENGINE, three shots: …` plus `TIMING: 12s total — 3 stamped shots of 4s, cuts at 00:04.000 and 00:08.000`. A transcription cannot know what the user's garment does, how many pieces were named, or what runtime they picked — so the beats fought the clock and every idea got the same choreography.

**Fix.** (1) New `src/lib/choreography.js`: the movement grammar in code — `garmentFamily()` (eight families with their own verbs, presentation options, camera behaviour and cut triggers), `presentationKind()` (ladder / dressing / walk / turn / craft / scene), `motionPlan()` (fit to the live clock and the variant, never repeating a verb inside a clip) and `motionPlanText()`. (2) `prompts.js` injects a **MOTION PLAN** into every H3 and LTX request whose scene has a person, stating that a template's beats are grammar to be rebuilt, not a list to be copied. (3) `offline.js` uses the same module, so the instant engine derives its beats per idea as well. (4) All 8 video-derived blocks: fixed stamps removed, beat engines recast as option sets under `BEAT ENGINE — THE GRAMMAR, NOT A SHOT LIST`, timings recast as *derive every cut from the live CLOCK — one beat per 1.5–2s*. (5) Doctrine in the shared craft file (all four system prompts), the derivation table in the fashion pack, a **write laws, not shot lists** rule in the Forge, and a new advisory linter check **🧭 Beat derivation**. Suite **11r** pins the families, the kinds, the clock fit, the variant variance, the injected block, the instant engine and the templates.


## Q1al · "not happy with the templates for studio … we did not reach the same level we had with room clothing tour" — SHIPPED (v2.17)

**Diagnosis.** Measured against `Room outfit tour — adaptive beats` (its beats and their order dynamic, keyed to named garment details, `OPEN` first / `CLOSE` last, skip-if-not-named, 6 defined flows) the studio block was a thin cousin: three prose beat options, four flows declared and never defined, five dimensions, and a palette the template *forced* to cream — which is exactly why the two saturated refs never fitted it.

**Fix.** (1) **Quiet-luxury studio** rebuilt on the room-tour engine: named-detail feature beats (cuff, placket, seam, waistband, pocket, shoulder, hem, rib, lining), the two-details rule, the never-invent ban, one act of 1–1.5s per beat, `OPEN`/`CLOSE` invariants, six flows each defined in the skeleton, nine live dimensions, palette as a live field, 2K. (2) New **Hard-sun studio — shadow play, saturated palette** for the two refs that had no home (refs 07 and 15): same engine, its own detail beats and six flows, sun written as a character. (3) **E-commerce 4-up** given the flow definitions it never had, a derived panel set and two more dimensions. Suite **11s** pins the whole family against the room-tour benchmark (engine phrases, invariants, flow coverage, dimension counts, no fixed stamps, near-duplicate guard). One bonus fix found while testing the new block: the choreography engine's swim family matched a bare "sand" and "sea", so *"a heavy linen shirt … in warm sand tones"* was planned as a beach scene — both words are now colour words, and the water words alone decide the family (pinned).





## Q1aw · "Cannot access 'tAll' before initialization" — two crashes, and the reason the build never saw them

The user, from their own dev server: `LearnSection.jsx:79 Uncaught ReferenceError: Cannot access 'tAll' before initialization` — twice, then a React unmount trace.

**Both crashes were mine, and both came from the v2.27 tag refactor.** Fixed here:

1. **`LearnSection.jsx`** — I replaced the local tag list with `const tTags = tagFilters(tAll)` and wrote it **one line above** `const tAll = LIB.filter(…)`. A `const` is in the temporal dead zone until its own declaration runs, so the component threw on every render.
2. **`TemplateCard.jsx`** — my edit produced `const tagLabel = tagLabel(t.tag)`: the local const shadowed the imported helper, so the call resolved to the *local* binding and threw.

**Why the build passed both times.** `vite build` + esbuild transform syntax; they do not execute the component. A temporal-dead-zone reference and a self-referencing const are valid JS — they are *runtime* faults. Everything we had — the 794-check suite, the audit, the receiver rehearsal — reads files as text or parses them as data. **Nothing we had ever ran a component.**

**So this pass adds the missing layer:**

- **`scripts/rendersmoke.mjs`** (`npm run smoke`) — esbuild (already a Vite dependency) bundles each component with React external, then `react-dom/server` **renders it** under stub props and a minimal browser stub. All nine components render. Written first as a diagnostic, it immediately caught the second crash (`tagLabel2` in the bundle output) before the user could hit it.
- **Suite 15** runs the smoke test as part of `npm test`, so a component that throws on first paint fails the suite, plus the static half of the same check: `tTags` must be declared after `tAll`, and no component may shadow an imported helper with a local const of the same name.
- **`src/components/ErrorBoundary.jsx`** — used around the Studio panels, the Templates page and the Learn page. A panel that throws now shows a card with the message, the component stack, **↺ Try again**, **⟳ Reload the page** and **📋 Copy the error**, and the rest of the app keeps running. The user's console literally suggested this; it should have shipped long ago, because a single bad line should never cost a blank screen.

**Measured:** `npm run smoke` → **9/9 components render** · suite **800 checks** · build ✓ · both crashes verified fixed by rendering the real components.

---

## Q1av · The library audit — 136 templates read against every law we have built since

The user: *"lets re go through all our templates, see what improvements we can make. if there is update required create a new version keeping old one. we have discussed lot of things new since we started template creating… Also i found some of fashion\lifestyle category template coming in person category."*

**The reported bug was real, and the audit found its cause.** The picker grouped by the `tag:` line of each template — so a template whose metadata said `tag: person` appeared under 👤 Person even when its `category:` said **Fashion / Lifestyle**. Eleven templates were misfiled that way, and because the tag list had been copy-pasted into three components, three tags in use — `preset`, `immersive`, `medical`, **25 templates** — had no label anywhere and could not be filtered at all.

**The first honest step was making the audit itself fair.** A template is not the only thing that reaches the model: the **engine** injects READING BEAT, SHOT DESIGN, DETAIL DENSITY, TOKEN DISCIPLINE, the cast lock, the motion plan and the variation contract on every generation, and the **packs** carry the closed-stack law, innerwear-where-seen and the colour bank. So "this template never mentions the closed stack" is *not* a defect — a first naive scan reported 113 of 133 templates as needing work, which was mostly noise. The tool now reports only what is actually wrong, in three severities, and prints the layers it is accounting for:

- **`scripts/audit-templates.mjs`** (also `npm run audit:templates --strict` for CI) — ERROR (the UI or the model is being misled) · WARN (the template contradicts a law the engine also carries) · INFO (advisory: a fixed shot count where Auto exists, no flows, a long stretch with no beat language).

**What the audit found, and what was done:**

| finding | count | action |
|---|---|---|
| templates misfiled by tag (Fashion/Lifestyle under Person, and friends) | 11 | tags repaired; **and** the group is now decided by a single `groupOf()` so a misfiled tag can never hide a template again |
| tags with no label anywhere (`preset` · `immersive` · `medical`) | 25 templates | labels added; **three drifting copies of the tag list replaced by one file**, `src/lib/tags.js` |
| skeletons that stamp **when their own cuts happen** (`At 00:03.000 the camera cuts…`) | 12 templates, 33 stamps | removed everywhere — a cut is never stated in seconds, it is derived from the live clock, so changing the duration cannot leave a template describing a cut that no longer happens there |
| timing lines stating an absolute budget (`hook 0-2s, action 2-10s…`) | 129 lines | now declare themselves **proportions of the runtime** — change the duration and every segment scales |
| templates deriving cuts with no timing contract at all | 3 | contract added |
| placeholder tokens over the 120-char budget | 5 | shortened |
| templates whose top-level camera language contradicted the contract | 0 real (5 were the audit reading a **ban** as a request) | the check now understands "never a whip pan" |

**New versions, old ones kept.** Three templates ship as the 2026 adaptive versions of eleven older presets — **🎬 UGC ad — adaptive beats**, **👗 Fashion preset film — adaptive beats**, **🧥 Lookbook film — adaptive scenes** (`public/prompts/templates/adaptive-films.md`). Each carries what the presets predate: beats **derived from the named elements** rather than a fixed list, a declared **flow library**, live dimensions, fabric-driven choreography, the closed stack, derived timing. The originals are untouched in `core.md` and each now carries a line pointing to its successor.

**Measured:** `npm run audit:templates` → **136 templates · 0 ERROR · 0 WARN** (96 INFO, all advisory) · suite **790 checks** (new suite 14 pins the one-vocabulary rule, the `groupOf` fallbacks, the no-stamped-cut invariant library-wide, the token budget, the audit tool's layering and the three successors) · build ✓.

---

## Q1au · The Engine card moves into Settings — and the panel becomes navigable

The user, with a screenshot of the Studio form's ENGINE card: *"move engine setting to actual setting panel — we should improve our setting panel too."*

The card was in the wrong place for a real reason: **the engine controls depend on the provider and the model list, and those lived in ⚙️ Settings** — so a first run meant configuring the provider in one place, then setting the engine that calls it in another, two screens apart. Settings itself was a single long scroll where keys, endpoints, the model list, prompt routing, dependency tables and the template importer were stacked with no navigation.

**What changed (v2.26):**

- **New `src/lib/enginesettings.js`** — one home for the block: `engine`, `variants`, `temperature`, `detail`, `fewshot`, `enhance`, with `ENGINE_DEFAULTS`, `ENGINE_MODES`, `ENGINE_OPTIONS` (the switch list, declared **once** and rendered by the panel, so the UI and the summary can never drift), `loadEngineSettings` / `saveEngineSettings` (defensive — a corrupt stored value falls back to the defaults instead of breaking the app), and `engineSummary()` — a **pure** function returning the one-line summary the form shows.
- **The 18+ switch keeps its original `cps_nsfw` key.** It moved into the panel with everything else, but the key it writes is unchanged, because `lib/maturegate.js` — consent + routing — reads exactly that value. Moving a control must never move its contract.
- **⚙️ Settings is now four tabs**: 🎛 Engine · 🤖 Provider · 📄 System prompts · 📂 Templates, with a connection pill in the tab bar and a sticky bar so the tab never scrolls away. The App holds `settingsTab` and `openSettings(tab)`, so a link can open the panel *on the right tab*.
- **The Engine tab** opens with a **"next generation runs…"** strip (mode · model · variant count · active switches · temperature), then engine mode, model (live list + typed names), variant chips, the temperature slider, the five switches with their explanations and the accurate prompt-file line, and **↺ Reset defaults**.
- **The Studio form keeps a summary, not editors.** `<summary>5 Engine</summary>` now carries the same line, and the body holds the "next generation" strip, **⚙️ Change in Settings** · **🤖 Provider & model list** buttons and the mature/prompt-routing status (kept there deliberately — it is about *this* generation). A `useEffect` hydrates the form from the shared settings and follows later changes, so opening Settings, changing the model and returning needs no refresh.

**Measured:** build ✓; new suite **13** pins the module (defaults, mode ids, the single switch declaration, a save/load round-trip, the corrupt-value fallback, the mature key, the summary shape including "an offline run never advertises a model it will not call"), the panel (tabs, the Engine block, the now-strip, reset) and the form (no editors left, summary from the shared helper, both links, the hydrate effect) — **769 checks** total.

---

## Q1at · An Indian bridal request came back Western — the register was missing, not the template

The user pasted back a generated prompt: a burnished-copper corset, a sapphire choker, a tomato-red concrete atrium, `{GLAM LIGHT}` still in the body — *"this not look like indian bridal show."*

**Two real defects, both ours, both now fixed.**

**1 · The register.** That output identifies its template exactly (`{GLAM LIGHT}` is a token only the modern bridal glamour tour carries; 6 × 3s at 18s with "small amplitude at slow speed" is its pin). Its pools described a Western couture film: `GLAM GARMENT` offered duchess satin, silk gazar gowns and a tulle ballgown; `LUXE JEWELS` offered platinum rivières, ear climbers and a body chain; `MODERN SET` opened with *"contemporary architecture… no jharokha"*. Even the set pool's own copy told the model the room should not be old. Correct for a Paris couture brief; **wrong for the words "Indian bridal".**

The fix is a **branch, not a ban** — the template stays the modern-glamour register, but it now reads the request first:

- **INDIA BRANCH** (`bridal-glamour.md`): when the idea names an Indian bride or wedding (bride, shaadi, wedding, lehenga, choli, dupatta, saree, mehendi, sangeet, tikka), every element stays Indian **and** modern — an Indian silhouette built like couture (corseted lehenga, pre-draped concept saree, saree-gown, cape lehenga, a jewelled bustier with a lehenga skirt), Indian high jewellery (choker with its maang tikka, a nath when named, stacked bangles, a kamar bandh), Indian glam beauty, an Indian contemporary set (marble hall in a palace-turned-hotel, jali set into glass, a water court). Explicitly forbidden there: a Western gown, a ballgown, ear architecture where a maang tikka belongs, a Western room. **The coordinated set becomes correct** in this branch — the choker, the tikka and the studs answering each other *is* the styling; the parure ban applies outside it.
- **The pools follow the branch** (`fashion-variation.md`): `GLAM GARMENT` opens with a corseted oxblood lehenga and ends its Western ballgown with "kept for requests that name no Indian element"; `LUXE JEWELS` opens with the Indian high-jewellery set; `GLAM BEAUTY` dresses the parting for the tikka; `MODERN SET` gains the palace-turned-hotel corridor, the jali wall and the water court alongside the Western rooms. Keeping **one dominant piece** survives intact — it was never the problem.
- **The pack says it for every fashion request**, so any bridal brief — not just this template — lands in the right register.

**2 · The leaked token.** `{GLAM LIGHT}` reached the finished prompt as text. The unfilled-placeholder line only fired when the field was blank *and* the model obeyed; now both builders (H3 and LTX) carry a standing **TOKEN DISCIPLINE** law: a `{TOKEN}` is an input field, never text — the finished prompt carries no braces and never prints a field or dimension name, and every dimension named in the variation contract arrives as an invented, filmable, specific value.

**Delivered with it:** the user's own pasted prompt, rewritten as an actual Indian bridal show (oxblood zardozi lehenga, choker + maang tikka + nath, midriff, veil as red net, back beat, face close, on a deep-green sweep) — `indian-bridal-glamour-prompt.md`.

**Measured:** suite **744 checks** (new 11aa block pins the India branch, the four rewritten pools, the pack line and the token law); audit unchanged in shape — 135 templates · 61 dynamic · 61/61 closed stack · 0 fixed shot lists.

---

## Q1as · Bridal editorial — the register the refs actually show

The user after v2.23, with four Pinterest refs attached: *"still its deshi old look not modern bridal glamour, lets do one thing make new bridal tour template but with modern touch, latest expensive wear and jewellery."*

**The refs were studied frame by frame before anything was written** (nine-frame contact sheets per film, kept at `refs/pin-2026-09/`). What they show, in one line: **a controlled coloured studio ground (a deep-green mural studio, or one palace corner), ONE dense jewel-toned lehenga — oxblood, crimson or marsala — with heavy hand embroidery (gold zardozi, crystal, meenakari, and silver or pearl-white thread worked on red), a choker worn with a tikka and a nath, stacked bangles, the midriff and skin shown as part of the look, the veil as a bordered net with a gold edge, a back shot, macro beats on the choker, the sleeve, the hem and the waistband, and a smiling face close.** The film is a *tour of the look*, not of a place.

That diagnosis also exposed a bug in our own doctrine: the `BRIDAL GARMENT` pool opened with **"light beats heavy"** and the heritage pack repeated it, so every bridal request was being steered *away* from heavy hand work. Both were corrected — hand work is the money now, and what is banned is **machine** sparkle (all-over mirror, industrial sequin scatter, "zari work" with nothing named).

**New file `public/prompts/templates/bridal-editorial.md`** — *📱 Bridal editorial — veil, border and bodice ladder* (18s · 9:16 · 2K · auto · small/slow). Its three laws:

- **ONE GROUND, NO TOUR.** One seamless sweep or a single set; the background changes only by light or a single step; **scale changes by CUTTING, never by zooming**, and no beat walks her through a location. This is the difference from the costume-drama look the user rejected.
- **THE VEIL IS THE DEVICE.** Named with its border, in three states — OVER THE HEAD, ACROSS THE FACE (the signature beat: she draws the embroidered veil across her eyes, then lowers it and finds the lens through the net) and HELD. Never draped and forgotten.
- **THE LOOK IS THE ARGUMENT.** The embroidery must name its technique and motif and repeat across blouse, skirt and veil border; one macro beat exists to prove it — and **every macro keeps her body in frame** (border macro with her hand on the fabric, bodice with her collarbone, belt with the midriff, sleeve with the arm), which is the same wearer-in-frame law the jewellery films already obey.

Beats: OPEN full length → FEATURE BEATS in priority (veil states, THE FACE, then the macro ladder, then the back) → CLOSE on the face — plus the bodice, border macro, waist and belt, sleeve and cuff, back and tie, and a three-quarter HEM AND FOOT beat that never becomes a foot-only crop. Six flows (VEIL FIRST · FULL THEN LADDER · LADDER UP · BACK REVEAL · BODICE THEN FACE · HEIRLOOM CASCADE) re-order and re-scale the same beats and never add one. Nine live fields drive it.

**Three new pools** in `fashion-variation.md`: `EMBROIDERY` (ten hand techniques with their motifs), `HEIRLOOM PALETTE` (eight deep colour stories, each with one accent) and `STUDIO GROUND` (eight sweeps and single sets) — pools 27 → **30**. The fashion pack now reads **"three registers, pick one and commit"** — heritage, modern glamour, heirloom editorial — with the heirloom editorial register written out so any bridal request can land in it.

**Measured:** suite **738 checks** (new 11z block pins the register, the flows, the veil states, the wearer-in-frame macro law, the innerwear and closed-stack rules, and that the pools came with it); near-duplicate distance to the heritage bridal film 0.43 and to the couture glamour film 0.44 — three templates, three registers, no reskin.

---

## Q1ar · Modern bridal glamour — a second register, not a rewrite

The user after the v2.22 pass: *"still its deshi old look not modern bridal glamour, lets do one thing make new bridal tour template but with modern touch, latest expensive wear and jewellery."*

Correct diagnosis of what v2.22 missed: it modernised the *options* inside the heritage register but left heritage as the only register, and words like heirloom, polki, mehendi, haveli and gota patti pull any prompt toward ritual. So this pass adds a **second register with its own template** rather than editing the first:

**New file `public/prompts/templates/bridal-glamour.md`** — *📱 Modern bridal glamour tour — couture, not costume* (18s · 9:16 · 2K · beat · auto cuts · pinned small/slow). The tour machinery follows the house standard: `OPEN` first, `CLOSE` last, one named element per beat (BODICE AND BUST · DRAPE AND TRAIN · THE SPARKLE · THE NECK · THE HEAD · THE HANDS · THE WAIST · THE BACK · THE HEM AND SHOES · THE FACE), each conditional on the idea naming that element, six defined flows, nine live dimensions, derived timing, the hem beat shot as a low three-quarter frame (never a foot-only crop), and a camera contract that bans the wedding-video vocabulary outright: no whip pan, no handheld jitter, no zoom, no speed ramp.

Two laws do the heavy lifting and are worth keeping in view:

- **"EXPENSIVE IS SPECIFIC."** The film must state construction — boning in the bodice, hand-set crystal, horsehair in the hem, the cut-out and what closes it, the train and how it pools — because *stated construction reads as couture and unnamed "heavy embroidery" reads as costume*. Adjectives do not buy the frame; materials and build do.
- **The register is enforced.** The heritage-drag words are named as forbidden defaults (haveli, jharokha, marigold, mirror work, heirloom banarasi, polki-kundan-jhumka parure) and the grade explicitly refuses nostalgia (no warm wash, no soft-focus glow, no vignette).

**Seven new pools** in `fashion-variation.md`: `GLAM GARMENT` (duchess satin corsetry, liquid lamé concept saree, silk gazar gown with a cathedral train, crystal column, sculptural cape-gown, monochrome two-piece, rose-gold lamé with an obi, black velvet slit column, draped jersey with a gold-bar cut-out, tulle ballgown), `LUXE JEWELS` (rivière choker alone, layered fine chains with ear climbers, statement emerald with bare ears, modern headpiece, ear architecture, rose-cut polki worn down, tennis bracelet stack, sapphire high jewellery, back body chain, rubellite climbers), `GLAM BEAUTY`, `MODERN SET` (marble hall, glasshouse, infinity terrace, colonnade, chandelier ballroom, pool deck, brutalist stairwell, gallery room), `JEWEL METAL`, `GLAM PALETTE` and `GLAM LIGHT`. The fashion pack now opens its bridal section with **"two registers, pick one and commit"** and explicitly says never to default to heritage — so any bridal request, not just this template, can land in the right register.

Suite **11y** pins it: the file's settings and pinning, the register statement and the forbidden heritage defaults, the EXPENSIVE-IS-SPECIFIC law, the high-jewellery styling and modern beauty language, the OPEN/CLOSE tour with all ten element beats, conditional/derived beats with no stamped cuts, the hem beat's framing rule, six defined flows, nine pool-backed dimensions, the camera and speed contracts, the room-as-architecture law, a clean lint (no warnings) and near-duplicate distance from both the heritage bridal film and the room tour (< 0.6, measured 0.36 / 0.24).
## Q1aq · The 2026 bridal register — researched design vocabulary

The user, watching the bridal output: *"i think the anklet is causing poor bridal wear design / the designs of cloths and jewellery is not coming good / we really need research and work on latest trending bridal wear and jewelry design ideas online and improve the quality of it / modernize it."*

Research first (opening this season's bridal market — designer houses, jewellery trade and trend reports — rather than guessing), then three changes:

1. **The design pools.** `fashion-variation.md` previously carried eight pools; the bridal film varies on nine dimensions and only LOCATION / MOVEMENT / CAMERA existed. Added **BRIDAL GARMENT · ORNAMENT SET · METAL AND STONE · STONE PALETTE · METAL · GARMENT · VEIL · MEHENDI · LIGHT**, each with a `>` law at the top and 5–10 fully-specified options. The garment pool is fabric-forward (raw silk, tissue, organza, dupion, brocade, chanderi, bandhani drape) with silhouettes such as cape-lehenga, pre-draped saree-gown, fish-cut, mermaid line, jacket lehenga and the heirloom re-cut, each naming its blouse cut, hem treatment and embroidery technique with its motif. The ornament pool encodes the season's styling: one dominant piece with everything else answering it, choker + single rani haar, the polki revival, temple gold's return, pastel stones for pastel looks, and the balance rule — *an oversized maang tikka runs with medium earrings and a quiet choker, never full jhumkas as well*. The "over" list is named explicitly so the model stops defaulting to it: the ten-kilo velvet-and-mirror lehenga, all-over mirror work, and "zari work" with no technique.
2. **The register inside the film.** A `DESIGN REGISTER — 2026 BRIDAL, NAMED` paragraph in the template body (with "melt this into the prose, never print these rules") and a new *Bridal and occasion — the 2026 register* section in the fashion pack, so the doctrine reaches every fashion request, not only this template. This is the part that changes output quality most: the placeholders now ask for design decisions (technique, motif, blouse cut, metal finish, balance) rather than descriptions of a category.
3. **The ground beat.** The anklet beat became `THE GROUND`: a low three-quarter frame in which the embroidered border, the footwear and the anklets read together while she takes one slow step, with her hand or the veil edge kept in the top of the frame — never from below, never a foot-only crop. It is conditional (no named anklets/footwear → dropped, not invented), a reading hold like every other beat, and the **lowest priority beat**: never first, never the longest, first to be cut. Rationale: a foot-only orbit shows no design and takes the wearer out of frame, which is exactly the "poor design" reading the user reported.

Also this pass: the instant engine (no LLM) gained a **bridal bank** — `BRIDAL_RE`, ten modern silhouettes and six styled ornament formulas, with `wardrobeSentence` branching for bridal ideas and `stackSentence` adding the styled set (never a skirt over a lehenga's own hem). Suite **11x** pins all of it: that every dimension the bridal film varies has a pool, that the pools carry the modern register and the "over" list, the ornament styling and balance laws, the veil styling options, the mehendi law, the register's presence in both the template and the pack, the whole ground-beat rule set, and the engine's bridal branch (silhouette + styled set, colour preserved, non-bridal looks untouched, the bank rotating across a batch).
## Q1ap · The bridal camera — damping, reading holds and a rise that climbs

The user, after watching the first bridal render: *"bridal template we just made need to improve camera, it some time very fast and very quick, like from face to anklet not happening and it straight goes to full body now even letting the head and jewelries in frame to be viewed."*

Diagnosis, and it was three separate defects rather than one:

1. **`camera: Auto` threw the amplitude and speed away.** `camTxt` only wrote `"<move>, small amplitude, slow speed"` when a *named* move was chosen; on Auto it handed the decision to the model with no governor — hence a sweep where a drift belonged. A template may now pin `amp:` / `speed:` (validated against the real option lists in `templates.js`, written back by `templateToMd`, spoken by `describeSettings`), and Auto appends the pin to its instruction: *"the scene is pinned to small amplitude at slow speed … a slow speed means the move reads as a drift rather than a sweep."* Fixing that exposed a second latent bug: a missing `camera` field took the non-Auto branch and printed *"undefined, small amplitude…"* — a missing camera is now treated as Auto in both builders.
2. **Nothing in the doctrine asked for a still frame.** BEAT DENSITY says the *subject* always moves; that was read as "the camera always moves", so details were swept past. The engine-wide **READING BEAT** law now says the opposite where it matters: when a beat exists to show something, the frame holds still ~1.5s with only breath, fabric or light moving, movement never carries a detail, and the camera's move happens *between* details. The `ladder` presentation kind in `choreography.js` carries the same hold for ornament films specifically.
3. **The arc never fitted the runtime.** 15s auto = 5 shots for a 6-beat arc, so the closing orbit had to climb ankle-to-wide inside one 3s shot — the "straight to full body" jump, with the face and the jewellery never getting a reading frame. The bridal film is now **18s (6 shots, one per beat)** and its rise is its own beat that **climbs her body** — hem, waist and kamar bandh, neck stack, then the face closest and longest — with `THE RISE NEVER SKIPS A STEP` and the widening as the last thing that happens. To make 18s reachable the duration ceiling moved from 15 to **20** in both the template parser and the damping slider (20 is the clock's own cap; it had simply been unreachable from the UI).

Suite **11w** pins the mechanism: amp/speed round-trip through `templateToMd`/`parseTemplatesMd`, rejection of invalid values, the toast, the raised ceiling (18 in, 99 → 20), Auto obeying the pin in both builders, no `undefined` camera, the READING BEAT law in H3 *and* LTX, and the ladder's hold. Suite **11u** gained three bridal pins: the orbit climbs rather than jumping to a wide, the rise order with her face last to leave frame, the speed contract and per-beat holds, and the beat-count-follows-ornaments rule at 18s/six beats.
## Q1ao · Coverage follows exposure — the closed-stack rule corrected

The user: *"we fixed innerwear issue but now we making it even bigger issue, when we already have outerwear we should not add innerwear unless visible. but now we adding it in every outfit."*

They were right, and the over-correction was in two places at once:

**The engine.** `stackSentence` (v2.13) had no idea what the outfit looked like — it always emitted `a camisole/a bodysuit/a vest with a matching brief under it`, and always appended a bottom, so a lehenga came back as *"a smooth matte bodysuit under it, a bottom in the same red (a bias-cut midi skirt)"* — the garment's own lower half plus an invented skirt. The line now reads the idea: `needsBase(idea)` (exposure words only — sheer, translucent, net, organza, mesh, plunge, open-back, cut-out, slit, bare midriff, crop top), `INTIMATE_RE` (lingerie / boudoir / swimwear, where the base *is* the outfit, so nothing is added under or over it), `WHOLE_GARMENT_RE` (its own lower half instead of a second bottom) and `STATED_BOTTOM_RE` (a bottom already named is never invented twice). `EXPOSED_RE` deliberately excludes words that are *not* exposure: chiffon may be lined, a cropped jacket over high-waist trousers shows nothing, a strapless gown has its own bodice — a false positive here means adding a layer the renderer then draws.

**The doctrine.** The unconditional line — *"a named base layer (a camisole, a bodysuit or a bralette-and-brief) under the main piece"* — was in 18 places in `core.md`, four in `fashion-campaign.md`, plus `outfit-reveal.md`, the shared craft file all four system prompts include, the fashion pack, the placeholder filler and the variation pool. Every one now carries the same law: the stack stays closed, an outer goes over a named inner **garment**, and **innerwear is named only where it is seen** — a closed, lined look names no base layer at all. Sentences earlier patches pinned ("THE STACK IS ALWAYS CLOSED", "NEVER worn alone", "an unstated layer is a missing layer", "A garment is never alone", "Every option here is a complete stack", the six pack labels) are all preserved so the doctrine chain and its pins stay intact.

Suite **11v** pins the whole law end to end: engine decisions per look (closed / sheer / plunge / slit / cut-out / midriff / crop-over-covered-waist / lingerie / lehenga / named-trousers / coat), the doctrine phrases in the shared file, the absence of the old unconditional sentence anywhere in the shipped library, and the linter's advisory — which stays **info**, because a camisole under a blazer is a legitimate styling choice; only the *unseen* base layer is the bug. The library-wide check skips the user's own protected template files.
## Q1an · The dynamic bridal show — the user's own six-beat arc

The user's brief, in their words: a jewellery showcase demo — a young bride in full traditional bridal wear (maang tikka, nath, neck stack, kamar bandh, wrist and palm jewels, mehendi to the elbow, anklets), a heritage location with five spots for the beats, and the arc *full body → torso → face → hands → ankles on a left-to-right orbit → the same orbit rising and pulling back to full body, closing on her smile to camera*.

Built as **📱 Bridal jewellery show — five spots, one closing orbit** (`fashion-campaign.md`, 15s · 9:16 · 2K · beat · auto cuts). The design decision worth recording: **an arc this specific is the format's shape, not a shot list.** A jewellery show has to be ordered to read as a show, exactly like the room tour needs `OPEN` first and `CLOSE` last — so the six beats are laws, and everything inside them is derived:

- every beat is keyed to an ornament the idea names (skip-if-not-named, never invent a piece, a spot or a gemstone; two families → two scales);
- the five spots are a live dimension read off the location field, so the background changes while she does not;
- six flows re-order the same beats (`LADDER UP` · `LADDER DOWN` · `WALK THE SPOTS` · `ORBIT CLOSE` · `HANDS AND VEIL` · `SEATED SET`) and never add one;
- nine live dimensions, every one carried by a token;
- the Q1ah wearer law holds everywhere — the tikka keeps her hairline and ear, the nath keeps cheek and jaw, the neck stack keeps collarbone and throat, the kamar bandh keeps the waist and the skirt's top edge, the haath phool keeps hand, wrist and forearm, the anklets keep the foot and the hem; the ornament is never alone on black;
- **`NEVER BREAK THE ORBIT`**: the closing orbit continues across the cut at the same direction and speed, rising as it pulls back, so the last two beats are one move seen twice and the film closes where it opened — her, full body, smiling to camera.

Two build-time catches worth keeping: the block was first titled *"Bridal show"*, which meant the title-gated **wearer-in-frame** linter never judged it (jewellery blocks are matched by their title) — renamed to *Bridal jewellery show* so the rule applies and so it is findable; and the orphan-macro sentence had to read *"never the ornament alone on black…"* rather than *"no ornament is ever shot alone…"* for the linter's negation stripper to see doctrine instead of a gap. Suite **11u** pins the whole block: the arc's order, every ornament family from the brief, the five-spot law, the orbit law and the closing smile, the wearer anchors, flow coverage, the nine token-carried dimensions, no stamped cuts, and that the linter rates wearer-in-frame and beat-derivation `ok`.
## Q1am · The template is a shoot, not a shot — shots, beats, speech

The user pasted a real output from **Heritage doorway reveal** against the ref it was built from and said: *"I don't feel it matching to video at all."* Comparing the two exposed three app-level causes, none of them cosmetic:

1. **A fixed shot count.** `structure: multi3` was a hard 3 in `shotClock`, so a 12s film got three 4s windows while its own beats run at 1–1.5s — the beats got stretched and the film crawled. `shotClock` now understands **`auto`**: `round(dur/3)` shots, clamped 1–6 and never under `MIN_SHOT`. `clockLineH3` gained the **SHOT vs BEAT** rule (beats ride through the cuts, never stretched to fill one) and says when the count was computed from the runtime. `alignmentLine` follows the last auto shot so a last-frame ref still lands on the real last shot. The picker (`StudioForm` + `TemplateManager`) and `describeSettings` know the mode; `templates.js` no longer silently coerces an unknown structure to `single` (it was swallowing `auto` — and would have swallowed any future mode).
2. **An invitation to invent speech.** With no line requested, the H3/LTX messages told the model to include dialogue "where it naturally elevates the scene" — which is how a silence-first drape film acquired *"शुभ प्रभात।"* to camera. The default is now explicit: **wordless**, soundscape and fabric carry it; a line only when the idea asks or the format is a dialogue/ad read. The on-camera rules (face in frame, lips moving, nothing over the mouth, never off-screen) are unchanged for lines that do belong.
3. **Ledger lists.** Parenthetical production notes bolted mid-sentence, including self-contradictions ("mustard-ochre … *all concealed in silhouette*"). Now a standing rule in the clock line and the message: no stacked asides, no label contradicting its own sentence, secondary beats written as prose.

4. **The template's own law was wrong.** Ref 14 (sheet-14) does not silhouette her at the door — the red lehenga is the light source in the frame, the carving is what it plays against. The block now opens on *the fabric is the light*, adds the **in-context macro pass** (fabric fills frame, her still in it — the anchor rule from Q1ah) and the **veil portrait** close, and hands its cuts to the clock. Every fashion block now runs auto cuts — the six in `fashion-campaign.md` plus twelve older editorial / sari / bridal / jewellery / intimates / outfit-reveal films in `core.md`, `intimates-reels.md` and `outfit-reveal.md` (18 in the library, pinned by suite 11t). The locked e-commerce collage keeps its single take, and the remaining fixed three-shot blocks are the formats where three is the grammar (medical explainers, kinetic type, UGC ads) — an open offer, not a default.

Suite **11t** pins the doctrine: auto counts per runtime (12s→4, 6s→2, 20s→6, 4s→1), minimum shot length, loop-is-one-take, explicit counts unchanged, SHOT vs BEAT + runtime-derived note, the ledger ban, the wordless default for a visual template, the on-camera rules for a requested line, the LTX default, and the doorway block's four corrected laws.

## Q1ax · The ref-derived templates vs Room outfit tour — the measurement, and the six rebuilds

Complaint, verbatim: *"unfortunately none of the template we made from video is as good as room outfit tour… we really need to think again on how to make them better."* Correct, and it turned out to be **countable** rather than a matter of taste.

**The counters** (now permanent in `scripts/audit-templates.mjs`, reported per template): subject acts (verbs where her body does something) · camera-tasks (beats where the *lens* is told to go looking) · who causes each change of frame size — her or the camera — and the brief's word weight.

| | run | words | subject acts | camera-tasks | by HER | by CAMERA |
|---|---|---|---|---|---|---|
| ★ Room outfit tour | 8s | 807 | 61 | 2 | 5 | **0** |
| Jewellery macro ladder | 12s | 891 | 3 | 1 | 0 | 1 |
| Quiet-luxury studio | 10s | 1083 | 20 | 1 | 2 | 0 |
| Hard-sun studio | 10s | 1053 | 20 | 0 | 0 | 0 |
| Bridal editorial | 18s | 1455 | 14 | 3 | 2 | 0 |
| Modern bridal glamour | 18s | 1619 | 20 | 1 | 2 | 8 |
| Bridal jewellery show | 18s | 2062 | 28 | 0 | 0 | 11 |

**The five reasons, in the order they mattered:** (1) the camera was the only thing that moved — a still subject re-framed by a travelling lens is a slideshow, a subject who walks through framings is a film; (2) beats were *views*, not *acts* — "the camera reads the wrist" instead of "she lifts her wrist"; (3) weight — mostly all-caps law the engine already injects, crowding out the performance; (4) 3.3 beats a second in an 18s film, which forces the model to invent, compress or drop the details you named; (5) a seamless sweep has no near wall and no far wall, so nothing can change across distance — the room tour's real secret is that it has a room. Plus the macro law that took the ornament off her body, which we had already outlawed library-wide.

**Shipped:** `public/prompts/templates/tour-grammar.md` — six rebuilds mapped one-to-one (bridal tour ← bridal editorial · jewellery tour ← macro ladder · quiet-luxury tour · hard-sun tour · bridal glamour tour ← modern bridal glamour · bridal jewellery tour — five light spots ← bridal jewellery show), each with a locked watchtower camera, her-act beats at one act per second, six-flow libraries that re-order and never add, OPEN/CLOSE, the layer stack and live-clock TIMING. Originals untouched, each carrying a forward pointer. The audit gained the slideshow-risk check (wearer-gated, so product films that travel by design are exempt); suite section 16 pins 0 camera moves, ≥2 scale changes by her, no beat outsourced to the lens, and under 1,200 words per rebuild. `npm run doc:tour` regenerates `docs/why-the-room-tour-works.md` from the audit counters, so the write-up can never drift from the tool.

**Open question for the next pass:** whether the camera-travelling templates we deliberately kept (E-commerce 4-up, the two product films, the classroom explainer) should get tour rebuilds as well — the audit now names them, so it is a decision rather than a blind spot.

---

## Q1ay · The photo-shoot film — model/location/clothing dynamic, with the crew as an option

Ask: *"lets create template for similar to this type video where model is being photo shoot — model, location, clothing, mostly dynamic. We also include cut shots showing photographer and other crew supporting in shoot as option."* The reference is the consistent-character shoot workflow (`.char` refs / reference sheets feeding MiniMax H3's reference channel — the Reddit thread and the InlineStudio/OmniChar workflows), where the visible result is a model shoot: she works the mark, and the camera world around her is a real set.

**Shipped:** `public/prompts/templates/photo-shoot.md` — **📸 Photo shoot — the set is in the film** (12s · 16:9 · 2K · auto · 6 flows · 10 varying dimensions · 1,187 words).

- **Dynamic by construction:** MODEL · OUTFIT DESIGN · OUTFIT COLOUR · PRESENTATION · MOVEMENT · ACTION · OUTFIT INTERACTION · LOCATION · CAMERA · **CREW** — every one a 🔀 dimension, and the new `## CREW` pool in `fashion-variation.md` carries six options, including *no crew in frame at all*. Three variants = three different women, places, garments, actions and crews.
- **The crew is opt-in, never invented:** write `NONE` (or leave it blank) and no crew member, hand, stand or shadow enters frame. Name one and at most one cutaway appears — the photographer at the shutter, an assistant turning the reflector with her still lit, a stylist's hand at the hem, the two over the back of the camera, or a wider frame showing the room as a set.
- **Crew laws:** the cutaway is a CUT, never a camera move; never the first or last shot; capped by the runtime (one per three seconds — the shot clock gives 12s four shots, so two at most); never leaves the one light design; no crew dialogue (voices stay muffled under the picture); and it may not steal her beat — `ONE FRAME TOO` keeps her in the same frame as them, over-the-shoulder or in reflection.
- **The v2.29 tour mechanics carried in:** the lens is locked inside every shot, every scale change comes from her walking or stepping in, one act per beat at 1–1.5s derived from the live clock, six flow libraries that re-order named beats and never add one, OPEN on her / CLOSE on her, the closed stack with innerwear-where-seen, colour always stated, face legible at 2K.
- **`RESET RHYTHM`** — she breaks the pose, breathes and re-enters — is the beat that makes the film read as a shoot rather than a pose reel.
- **Identity across cuts:** the tip names the reference route (attach the character reference / reference sheet, the `.char` way) so the same face, body and clothes hold through every framing.
- Siblings kept: **Room photo shoot** and **Photo-shoot tour chain** in `core.md` (both keep the crew out of frame and the second one shows the shooting kit in one scene of the chain); the new template's header names all three so the family reads.

**Measured:** audit 143 templates · 0 ERROR · 0 WARN on the new file (29 acts · 0 camera-tasks · 5 scale changes by her · 0 camera moves) · suite section 17 (18 pins) · build ✓.

**Open:** whether the crew should get its own multi-scene chain variant (setup A → setup B → the review, three clips, one set) — the pools would support it, but it is a new chain recipe rather than a template.

---

## Q1az · The ornament-show refs — scale by cut, the wide reset, and her face in every frame

Two refs (2026-09-28): a **fine-jewellery campaign** (20.1s) and a **yellow bridal show** (28.9s). Both analysed frame by frame; cut times measured with ffmpeg scene detection.

**What they measured:** ref B cuts at `3.08 · 5.52 · 7.12 · 8.92 · 11.12 · 13.04 · 14.80 · 16.12` — **eight cuts, most exactly 1.0s apart**, one piece per cut, with the opening and closing held longer. Ref A holds for six seconds at a time (`0–5.9s`, `11–20.2s`) then fires a tail of ~0.5s cuts, and repeats its full-length walk shot as a bookend.

**The four laws they prove:** (1) **the cut changes the scale, never the camera** — ref B moves the frame size four times and the lens never travels inside a shot, which is exactly what our ref-derived jewellery templates got wrong (`Bridal jewellery show` measured 11 camera moves, 0 by the subject); (2) **a tight beat is still a shot of her** — the ring macro keeps her face blurred behind the hand, the earring beat the jaw, the choker beat the chin and collarbone, and no frame in the film shows an ornament alone; (3) **the hand does the work** — her own hand is in every jewellery beat, which is what gives a close-up context and motion; (4) **the wide reset** — never more than three tight beats before a wider frame brings back the whole look.

**Shipped:** `public/prompts/templates/ornament-shows.md` — **💎 Heirloom jewellery show — one piece per cut, her face in every frame** (20s · 9:16 · 2K · 6 flows · 7 varying dimensions, incl. an optional **BRAND LINE** wordmark spelled exactly and held once over the close) and **🧵 Palette-wall bridal show — she holds the frame, the cut changes the scale** (16s · 9:16 · 768P · 6 flows · 7 varying dimensions, with held-but-alive frames, the veil hood and the veil-by dissolve). Pools: `ORNAMENT SET` + option 10 (polki and rose over pearl — the campaign's exact set), `STUDIO GROUND` + option 9 (the carved-medallion wall). The two superseded originals (`Bridal jewellery show`, `Jewellery macro ladder`, and the bridal editorial) each carry a pointer to their rebuild.

**Audit:** 145 templates · **0 ERROR · 2 WARN** — the first time the WARN list contains nothing in the fashion register. A template whose description names its successor now reports its camera-travel note as INFO ("superseded by a rebuild that is already in the library") instead of WARN, so WARN keeps meaning *nobody has looked at this yet*. The two survivors are the e-commerce 4-up collage and the labelled 3D classroom explainer — formats where the travelling camera is the format.

**Suite:** section 18 (22 pins) — 0 camera travel, scale-by-cut, the four laws, the pools, the pointers, the audit demotion.

**Open:** whether to build the same cut-based grammar for the **other** kept originals (E-commerce 4-up is a grid format and probably should stay; the classroom explainer is a 3D register and the camera there is doing geometry, not fashion) — and whether the brand wordmark belongs in more jewellery templates or only this one.

---

## Q1ba · "Walking is like jumping", "mostly showing back view", "beats are not as the ref" — the field report

The first test outputs from the bridal templates. Three faults, all of them ours, all now laws.

**1 · The walk was asked to cross a distance.** Entrances read *"she walks in from the ground's depth"*, *"she crosses the wall at full length"*, *"walks in from the room's depth"*. A distance the model cannot animate inside a 1–2s beat becomes a hop, a glide or a teleport, and there was no ground language at all — no floor, no step count, no weight transfer. **Law:** a walk is **two to four steps** at about one step a second — never a crossing; name the floor, heel-then-toe, the weight passing foot to foot, **both feet never off the floor at once**; **keep the floor and her feet in frame**; the walk gets **its own beat of at least two seconds**; **the cut lands on her stop, never mid-stride**.

**2 · She relocated between cuts.** With a locked camera, a subject who appears somewhere new after every cut reads as a jump even when each shot is perfect — the cut becomes a teleport instead of a scale change. **Law:** **the mark is continuous** — the walk happens once in the opening beat, every later shot finds her on the same mark, and cuts change scale, angle and action only.

**3 · The turns were open-ended, and two flows opened on her back.** Every back beat was written as *"she turns through a full back view"*, and `BACK FIRST = she enters already turned away` shipped in two flow libraries. **Law:** **the film is face-forward** — at most **one** back beat, about a second, only when the idea names what is read there, written as **three-quarters away and back inside the same beat**, never first or last. `BACK FIRST` → `SHOULDER FIRST` library-wide.

**Two further culprits the new check found:** the **ACTION pool** (drawn by every varying fashion template) offered *"walking a straight line toward the lens"* and *"turning away and walking out of frame, then glancing back over the far shoulder"* — the second contains both faults; both rewritten. And the older **beach walk-in**, **Room outfit showcase**, **mirror walk** (heritage doorway) and **threshold** entrances carried the same distance phrasing; corrected. **Room outfit tour was left untouched** — it is the benchmark and its walk and single back beat are the ones that work; the law caps the back view rather than banning it.

**4 · The bridal show's beats were not the ref's.** Rebuilt to the reference's inventory: walk · hold · **the veil across her face with the frame reading through the net** · **the veil spread overhead as a canopy** · face · **the hand on the cuff (the detail insert)** · bangle · waist · three-quarter turn · the look — plus a **BOOKEND** flow repeating the opening frame near the end, as the reference does.

**Shipped:** doctrine in `public/prompts/packs/fashion.md` (**"Motion — the walk is a walk, and the mark is continuous"**) so every fashion and bridal generation inherits it; the templates that contradicted it corrected (tour-grammar ×6, ornament-shows ×2, photo-shoot, outfit-reveal, bridal-glamour, fashion-campaign, core ×2); the ACTION pool rewritten; audit **WALK RISK** + back-view counter (wearer-gated, camera-crossing exempt); suite section 19 (20 pins). While writing the check I hit the v2.28 TDZ class in my own audit script (`hasWearer` used above its declaration) — fixed, and the suite now pins the declaration order.

**Open:** whether the *held* full-length frame needs its own "micro-life" audit rule (the bridal show requires one second of visible life per held frame, and nothing measures it yet).

---

## Q1bb · "More variations in beats" — the edit becomes a varying dimension

> *"need more research on doing more variations in beats, how to add dynamic variations that help us not clone same video that just look like model changed."*

**Diagnosis (measured, not guessed):** `shotClock()` split every runtime into equal windows on every run, and every `vary:` dimension in the library was **content** — who, what, where, doing what. So two variants of one template, with a different woman in a different room, still had **byte-identical cut times**. The film was the same film; only its contents changed. That is precisely "the same video that just looks like the model changed".

**Research:**
- **Cutting, DeLong & Nothelfer (2010)** measured shot-length sequences across hundreds of films: they follow a **1/f ("pink noise") distribution** — long shots grouped with long, short with short, neither even nor random — and films have grown *more* clustered since 1960. Evenly-cut footage is the machine-made signature.
- **Tempo is read from shot length, not movement** (KTH study on cinematic tempo; editing theory agrees: steadily shortening shots accelerate, lengthening shots decelerate). **ASL:** modern features ≈4s, cinematic social ads ≈1.2s, action ≈2.4s — a 20s film at 8 cuts is ≈2.5s, in the reference band.
- **AI-video practice:** repeats come from *"every generation running on the same prompt"*; the fixes are one action per beat, per-shot movement direction written at the micro level (weight distribution, hand position, gaze angle), varying angle/framing shot to shot, and **"prompt one micro-gesture, never stillness"** (over-literal stillness freezes the subject). Coverage grids (3×3 of one beat) yield 20+ usable shots from one setup. Multi-shot fields exist only on Kling `settings.multi_shot` and Runway's `multi_shot_video`; everywhere else multi-shot is prose + a verbatim style contract.

**Shipped (v2.33):**
1. **Seven rhythm envelopes** in `src/lib/duration.js` — flat · slowburn · decelerate · bookend · pink · stutterpop · holdfirst — with `pickEnvelope(seed, duration)` drawn from the same seed as the motion plan (`idea|title|variantIndex|flowIdx`), so variants never share a shape; `windowsFor()` keeps every window ≥ `MIN_SHOT` (1.5s), renormalises, and the bounds are snapped so the plan ends **exactly** on the runtime. No envelope → byte-identical to the old even split; drawn flat → identical too; <3 shots → flat (nothing to shape).
2. **Both clock call sites wired:** `motionPlan` (LLM path) passes the drawn envelope and its windows into the **RHYTHM** line of the motion plan that rides in the user message; `genVariantOffline` re-reads its clock through `choreo.envIdx`, so the instant engine cuts on the same shape.
3. **Eight FORM pools** in `public/prompts/fashion-variation.md` (45 options) + `src/lib/formdims.js` (the class + the **never-share set**), and the variation contract in `src/lib/prompts.js` now separates *what is in the frame* from *how the film is built*, forbids a shared edit signature, and gives the model the test: similar cut times / same scale order / same trigger = the same film twice.
4. **27 templates declare the form axes** (the ten rebuilt/new fashion templates, the core family, the three adaptive films, outfit-reveal, fashion-campaign, intimates). Deliberately not: the 2×2 collage (its rhythm *is* the grid), the two immersive formats (no cuts by definition), the seven medical templates (different register) — the audit reports those as INFO.
5. **Two practice laws:** one micro-gesture per beat (fashion pack) and the coverage grid (SCALE LADDER option 7).
6. **Bug found and fixed:** the offline composer wrote only shots 1–3, so a 12s (4-shot) film dropped one shot and a 20s (6-shot) film dropped two — the header claimed shots the description never described. It now writes every shot the clock budgets, the last always resolving on the hold.
7. **Audit + suite:** a varying template with no form axis reports **clone risk** as INFO; suite section 20 (18 pins) pins the envelope behaviour, the exact sums, the floor, the byte-compat path, the wiring, the pools, the contract and the research doc.

**Note for the future:** form variety and identity lock are complements, not rivals — the same research warns that every added person and beat multiplies drift, so the rule is **lock the identity, vary the form** (never vary the woman between variants unless MODEL is a drawn dimension).

**Open:** whether the RHYTHM line should also be able to come from the *user* (a picker: "let this one be a slow burn") — the engine accepts an explicit `envelope` on the plan input already, and nothing in the UI writes it.

---

## Q1bc · "Not just structure, content also" — the acts become a drawn dimension

> *"2 bridal video made can not be same action\movement with only model and clothing changed."*

**Measured first:** `motionPlan` drew each shot's act with a **rotation** of a fixed bank (`rot(fam.move, seed)`), so variant 1 and variant 2 got **4 of 4 acts identical** — and no bridal template declared `ACTION`, `MOVEMENT` or `PRESENTATION`, so the LLM path could not vary the acts at all. The v2.33 pass fixed the edit signature; this one fixes the film.

**Shipped (v2.34):**
1. **Banks expanded** — 8 motion families, 14–21 acts each (ethnic/bridal 21) and 6 presenting gestures (was 4–5 moves, 3 gestures).
2. **Disjoint blocks, not rotations** — the bank is shuffled once per idea (`hash(idea|title)`, no variant index in it) and each variant takes the next block: variant 1 = block 0, variant 2 = block 1. Measured **0 shared acts between two and between three variants**; wrapping passes are re-shuffled so a wrapped variant cannot repeat an earlier one exactly. Ethnic bank at 4–5 acts per film covers four disjoint variants.
3. **Envelopes stepped, not hashed** — `pickEnvelopeFor(seed, duration, variantIndex)`: variant 1 takes the drawn shape, variant 2 the next. A probe showed hash collisions (v1 and v3 both drew `bookend`); now 7/7 distinct across seven variants.
4. **Flow-aware posture** — a seated act never lands in a walking flow (`SEATED_RE`, `flowName` from the beat flow); a flow naming a seat keeps them.
5. **Exclusive act-set instruction** in the motion block, naming the failure: *"another variant of this run draws a different set of acts, so two films that share their movements read as one film with a different model in it."*
6. **Templates declare the acts** — `ACTION`/`MOVEMENT`/`PRESENTATION` on **34 templates** (all bridal tours, both ornament shows, bridal editorial, bridal glamour, photo shoot, core family, outfit reveal, fashion campaign, intimates, adaptive films). Kept out by design (audit INFO): 2×2 collage, UGC ad, 3D explainer.
7. **Pools deepened** — `ACTION` 14 · `MOVEMENT` 12 · `PRESENTATION` 12 options (was 6 each), including the bridal acts the refs use.
8. **Never-share now covers the acts** — `NEVER_SHARE` = 4 edit axes + ACTION · MOVEMENT · PRESENTATION (`NEVER_SHARE_FORM` / `NEVER_SHARE_ACTS` sub-lists exported), and the contract carries a `WHAT SHE DOES IS NOT SHARED` paragraph.
9. **Audit** — a wearer-gated INFO: *"varies nothing about what she does — no ACTION, MOVEMENT or PRESENTATION dim, so every variant of a run performs the same acts."* Fires on 3 templates, all explained.

**Suite:** section 21 (18 pins) — bank sizes, zero overlap between variants, distinct envelopes, the seeded-separation rule, flow-aware posture, the exclusivity wording, the never-share set, the pool depths, the template count.

**Open:** whether the *presenting gesture* should be drawn per shot rather than once per variant (it is one act for the whole film today), and whether the medical/education register wants its own act pools (the fashion act language does not fit a pathology explainer).

---

## Q1bd · The model is 20–32 unless the request names an age — young, beautiful, fashion-model quality

> *"keep models between 20-32, unless specified. Young, beautiful fashion model quality."*

A standing law, not a template note. Where it now lives, and why in each place:

1. **`CAST_LOCK` (`src/lib/prompts.js`)** — the lock injected into every fashion/beauty/ethnic generation, so it holds even when the user runs their own system prompt. Adds: the band, one concrete age (not a range), the quality register, the override rule, the under-20 floor, and "background people, hands, reflections and any companion are adults too".
2. **`DETAIL_DENSITY`** — the SUBJECT rule now reads *"a concrete age inside 20-32 unless the request names one"* (it said "age range").
3. **`public/prompts/shared/craft-detail-and-cast.md`** — inherited by all four system prompts: the band in SUBJECT DETAIL (with the worked example now "a woman of 26") and in the cast bullet, plus the real-person exception.
4. **`public/prompts/packs/fashion.md`** — the register in full, including the exception for templates that deliberately ask for a real-person cast (UGC creator, `not a model-perfect cast`, a character reference): the register stays real, the age stays in band.
5. **`public/prompts/template-forge.md`** — what every future template is told to name.
6. **138 person tokens across the templates** — every `{MODEL}`, `{CREATOR}`, `{WEARER}`, `{SUBJECT}` and `{BRIDE}` field now opens with `20-32 unless specified:`. Anatomy tokens (`{SUBJECT MODEL}` in the medical explainers) and the `{SUBJECT/PRODUCT}` loop token are deliberately untouched — they are not a cast.
7. **The instant engine** — `modelLine(idea)`: a concrete age drawn from the **idea** (so a run keeps one woman while clothes, rooms and acts vary), stated with the register and the never-teenager floor; an age written in the idea wins (`a 38-year-old…` → 38, and the band sentence is dropped). Wired into both the H3 and the LTX generators.
8. **The audit** — WARN for any age named outside the band (`teens`, `forties`, `middle-aged`, `elderly`, or a numeric age/range outside 20–32) and INFO for a template that casts a person without stating the band. Corpus today: **0 out-of-band, 0 casts missing the band**.

**Suite:** section 22 (13 pins) — the lock text, its presence in the built message, DETAIL_DENSITY, the shared craft, the pack, the forge, every template, the engine's band + override + per-idea stability, and the audit checks.

**Open:** whether the band should be a **UI field** on the Model row (a slider 20–32 with "as written" for anything else) rather than a law the user has to override in prose — the engine accepts an explicit age already.

---

## Q1be · Nine outfit tours across the wear types — the coverage pass

> *"We need to cover more fashion outfit tour for different types of women wear."*

The tour engine (`tour-grammar.md`, six tours) only knew the bridal, jewellery, quiet-luxury and hard-sun registers — a denim look, a saree, a suit or a gym set had no tour of its own even though the machinery (locked lens, OPEN/CLOSE, feature beats, flow library, live clock) fits all of them. This pass adds a second file, `public/prompts/templates/outfit-tours.md`, with nine tours, one per wear type, without touching the shipped six.

**The nine (each 12s · 9:16 · 768P · Static shot · amp small · speed slow · 4 flows · full vary dims):**

| Tour | Register | Flows |
| --- | --- | --- |
| 👖 Denim | wash, weight, fade; the stack at the ankle | THE WASH FIRST · WALK AND STACK · DENIM ON DENIM · CLOSE FIRST |
| 🧥 Coat | the outer layer and the act of taking it off | COAT ON FIRST · THE REMOVAL · COLLAR AND CUFF · CLOSE FIRST |
| 🧶 Knit | soft, close, unhurried; the stitch under the light | SLEEVE AND STITCH · SIT AND SETTLE · TEXTURE FIRST · CLOSE FIRST |
| 👟 Athleisure | gym to street; fabric under load | STRETCH AND HOLD · MAT TO MARK · POCKET AND HOOD · CLOSE FIRST |
| 👗 Evening | the gown: the drag, the turn, the back | HEM FIRST · THE TURN · BACK AND LIGHT · CLOSE FIRST |
| ✨ Festive ethnic | kurta/co-ord/anarkali for a festival, not a wedding | SIDE SLIT FIRST · HEELS AND HEM · DUPATTA AND DRAPE · CLOSE FIRST |
| 🧣 Saree | six yards: pleat fan, pallu, border | PLEAT AND PALLU · BORDER RUN · WALK AND TUCK · CLOSE FIRST |
| 🧕 Modest | abaya/kimono/modest co-ord; drape, sleeve, belt, hem | SLEEVE AND DRAPE · BELT AND LINE · HEM AND FLOOR · CLOSE FIRST |
| 👔 Tailoring | suit/shirting; line, posture, the quarter turn | BUTTON AND LAPEL · THE QUARTER TURN · DESK TO LIGHT · CLOSE FIRST |

**Measured:** 9 blocks · 54,916 B (54,270 characters) · 36 flows (28 distinct names) · **77 feature beats** · 21 distinct vary dimensions; every block carries the 20–32 band in its `{MODEL}` token; 0 lint warns, 0 audit errors; the near-dup guard holds (flows declared, no stamped cut times).

**What each block holds** (the tour laws, restated per register rather than assumed): the lens is bolted down and every scale change is hers; OPEN is a two-to-four-step entrance and CLOSE is the last beat with her eyes on the lens; the beats are *her* acts, one per beat, with hands, gaze and fabric doing different things at once; FEATURE BEATS fire only when the idea names that element, never invented; the fabric answers a beat late and settles last; the layer stack closes at the footwear; LAYER STACK clause names what sits under anything sheer/plunged/cropped and nothing under a lining.

**Two new pools** in `fashion-variation.md` back the new garment dimensions — **DENIM AND WASH** (6 options: raw indigo → selvedge) and **WEAVE AND TEXTILE** (6 options: Banarasi → handloom linen) — so `{DENIM AND WASH}` and `{WEAVE AND TEXTILE}` are live dims rather than dead tokens.

**Register-specific laws worth keeping:** the modest tour writes the camera as fixed *and respectful* (no low angles, no travel up or down the body) and its drape beat arranges the styling without unwrapping it; the festive tour explicitly forbids veil/mandap/ceremony (a festival is not a wedding); the evening tour is built on the drag and the slow half turn in one pool of light; the tailoring tour forbids flying fabric — posture, weight and quarter turns only.

**Open:** whether the nine registers should also become **UI presets** (a picker of wear type above the template list, the way ⚙️ Settings holds the engine) — and whether the 4 kept camera-travelling templates should now be rebuilt on this grammar.

---

## Q1bf · The space has depth and dress — never a bare room

> *"Don't lock to simple room add more details, depth in room. The space must feel visually …"*

The tour family had been written against set dressing: the quiet-luxury tour said *"nothing in frame but the room, no prop, no set dressing"*, the saree tour *"no furniture, no prop, no drape"*, the evening tour *"no furniture, no drape, no prop"*, the denim tour *"no prop, no set dressing, no signage"*, and the bridal glamour tour *"no heritage furniture"*. The result was a bare ground with one light on it — clean, and visually flat. This pass replaces that law with its opposite, in **all fifteen tours** (nine outfit tours + the six in `tour-grammar.md`) and, more importantly, **in the engine**, so every generation dresses the space whether or not a template says so.

**The law — THE SPACE HAS DEPTH AND DRESS.** Three planes: a **NEAR** plane just inside the frame (a doorway or counter edge, a rail, a curtain, a chair back, a plant, a crate), the **MIDDLE** where she stands and the beat happens, a **FAR** plane that recedes with its own architecture, material and light (a window, a corridor, panelling, a courtyard, a lit opening, a shaft across the floor). The **materials are named** (plaster, limewash, stone, terracotta, wood grain, brick, brass, cane, glass, velvet), **two or three real objects** give the place life (a lamp that is on, a chair with a throw, books, a mirror, a bowl, a rug, a workbench), and **one practical source** lights the room. Depth is *shown, not travelled*: overlapping planes, light falling off into the distance, a near object softly out of focus. **The dress stays dress** — nothing moves on its own, nothing takes a beat, nothing blocks her mark or sits hard behind her head; no text or branding, no other people, no extra garments, no religious or culture-specific object unless the request named it. A minimal set is a choice the request can make, never the default.

**Where it now lives**

1. **`public/prompts/templates/outfit-tours.md`** — the register clause in all nine tours rebuilt (denim's wall and floor, the coat room, the lived-in knit room, the working studio, the dark room behind the pool, the dressed festive ground, the saree hall, the modest courtyard, the real office), each with its own near / far / materials / objects lists.
2. **`public/prompts/templates/tour-grammar.md`** — same law in all six shipped tours, with the culture guards kept: the bridal tour still says *no mandap, no idol, no ritual prop unless the idea named it*, bridal glamour keeps *no temple prop*, and the festive tour keeps *no religious object*.
3. **`src/lib/prompts.js`** — `DETAIL_DENSITY` item (1) LOCATION now demands the three planes in depth and refuses "a bare sweep"; both fallback system prompts now say *"describe locations elaborately and in depth — a near plane, the middle and a far plane, named materials, two or three real objects and one practical source … never a bare room, never staged"*. `DETAIL_DENSITY` is pushed into both generators, so the law rides in every H3 and LTX message.
4. **`public/prompts/packs/fashion.md`** — the doctrine paragraph, above the walk law.
5. **`public/prompts/shared/craft-detail-and-cast.md`** — LOCATION DETAIL now carries the three planes (inherited by all four system prompts).
6. **`public/prompts/fashion-variation.md`** — a new pool **SPACE AND DRESS** (8 options, from a limewash room with a chair and a lamp to a courtyard with arches and a lantern), plus the old *"bare concrete studio"* LOCATION option rewritten as a dressed-but-stark one. All nine outfit tours declare it in `vary` and carry the `{SPACE AND DRESS}` token, so the room varies between variants while she stays the same woman.

**Measured:** all 15 tours carry the three planes, the materials clause, the objects clause and the practical source; zero tours still forbid dressing; `SPACE AND DRESS` = 8 options; nine tours token-carry it; the pack, craft file, `DETAIL_DENSITY` and both fallbacks carry it; suite §24 (11 pins) green.

**Note on weight:** the law adds ~60–90 words to every tour, which pushed the two heaviest bridal blocks past the old 1,200-word weight ceiling. The clauses were cut twice (the shared law is now 70 words instead of 95) and the ceiling moved to **1,275** with the reason recorded in the pin — the check still catches a template that doubles.

**Open:** whether `SPACE AND DRESS` should be a **UI row** (a field for the room, the way LOCATION is one) and whether the 8 options should be extended with regional interiors (a Gujarati haveli room, a Bombay art-deco flat, a Kerala courtyard).

---

## Q1bg · Six more wear types — swim, boho, night, intimates, ski, street

> *"Swimwear, Bohemion, Nightwear, Lingerie etc?"*

The first coverage pass (v2.36) took the outfit-tour family to nine registers; this one adds the six categories a womenswear library gets asked for next. `outfit-tours.md` now holds **fifteen tours**, all on the same engine — locked lens, OPEN first, CLOSE last, one act per beat, conditional feature beats, flow library, live-clock timing, closed stack, 20–32 cast, three-plane space law.

| Tour | Register | Own dimension |
| --- | --- | --- |
| 🩱 Swimwear and resort | sun, water, cloth; the strap, the tie, the cover-up on and off the shoulders | `SWIM AND COVER` |
| 🧿 Bohemian | layers with weight; the print, the fringe, the coin belt, the open road | `PRINT AND TEXTURE` |
| 🌙 Nightwear | the slow morning; silk or brushed cotton under one window | `FABRIC AND FINISH` |
| 🖤 Lingerie | the dressing-room film; silk, lace and posture, camera high | `SILK AND LACE` |
| 🎿 Ski and apres-ski | the cold and the kit; the long zip, the hood, the cuff over the glove | `WINTER KIT` |
| 🛹 Streetwear | proportions and hardware; the layer, the cap, the strap, the sneaker | `STREET LAYERS` |

**Six new pools** in `fashion-variation.md` (6 options each) back those dimensions, so every token resolves: `SWIM AND COVER` · `PRINT AND TEXTURE` · `FABRIC AND FINISH` · `SILK AND LACE` · `WINTER KIT` · `STREET LAYERS`.

**Two restraint guards, written into the blocks.** These are the first tours where bare skin is part of the register, so the guards are law rather than taste:

- **🖤 Lingerie — a dressing room, not a boudoir.** A folding screen, a rail, a cheval mirror at the frame's edge, one tall window. The block states that **she is dressed throughout**, the robe is worn and stays available, **nothing is removed, unfastened or adjusted under the cloth**, **no beat is a reveal**; the camera is **respectful and fixed** — chest height and above, no low angle, no travel up or down the body, coverage chest-up or head-to-knee. No bed, no second framing through the mirror.
- **🩱 Swimwear — the cover-up is arranged, never removed.** She stays dressed as the idea draws her, the cover-up comes back on before the film ends, the camera stays at chest height or above, and the register inside the frame is fabric and light — the water line darkening the cuff and drying in place.

**Why this matters beyond the six tours:** the guards are pinned in the suite (§25), so the file can be extended later without quietly drifting into a register the app is not for — and the lint's existing intimate-wear logic (the innerwear advisory is skipped for a block whose title is intimates or swim) already agrees with that framing.

**Measured:** 15 blocks · 105,204 B · 60 flows (44 distinct) · 133 feature beats · 28 vary dimensions · 0 lint warns · 0 audit errors · every block under the 1,275-word weight ceiling; suite §25 = 14 pins (the six registers, their dims and pools, their own feature beats, the two restraint guards, the no-nudity guard).

**Open:** the same `etc?` list still has candidates — 🍼 maternity, 🎾 tennis and golf, 🎤 stage and performance, 🎓 preppy and collegiate, 💃 dance and festival. Say which and they join the file the same way.

---

## Q1bh · Fifteen unique vocabularies, five required fields, and the realism law

> *"I hope all 15 are unique, follow the required presentation, location, model, mood and esthetic. They need to be next level of realism."*

Three corrections in one pass, each measured rather than asserted.

**1 · Uniqueness, measured.** A census of the pack found real overlap: ten tours shared a beat called **THE WALK**, seven shared **THE BACK**, six shared **THE TURN**, five each shared **THE CUFF** and **THE SLEEVE**, and three shared a flow called **LAYERS FIRST**. Every shared name was replaced with a register-owned one — THE WALL WALK · THE ARRIVAL · THE WALK IN · THE SIX-YARD WALK · THE QUIET WALK · THE CROSSING · THE DECK WALK · THE ROAD WALK · THE BOARDWALK · THE KERB WALK, and the same treatment for the back, the turn, the cuff, the sleeve, the pocket, the strap, the seam, the belt, the hem, the foot, the hood, the layer, the sneaker, the boot, the collar, the robe and the walk. Flows renamed: **SHAWL FIRST** (boho) · **KIT FIRST** (ski) · **ON THE KERB** (streetwear) · **SASH AND LINE** (modest) · **THE CUFF AND PLACKET** (nightwear) · **SNEAKER AND SLEEVE** (streetwear). Result: **119 distinct beat names**, every one owned by a single tour except **THE FACE** (the house close, all fifteen), and **46 flow names**, every one owned by a single tour except **CLOSE FIRST** (the house close-first option). Each tour owns 7–10 beats of its own. The streetwear sleeve act was also rewritten — it had been a near-copy of the nightwear one.

**2 · The five required fields, in every tour.** MODEL (the 20–32 band, in the idea), LOCATION (with SPACE AND DRESS), PRESENTATION, and now two new ones with their own pools in `fashion-variation.md`: **MOOD** (8 options — the register she plays, carried in the shoulders and the eyes) and **AESTHETIC AND GRADE** (8 options — the look of the finished frame, named as a grade rather than a filter). All fifteen tours carry both tokens, declare both as varying dimensions, and **no two tours share a mood or a grade** — thirty distinct values. The lighting sentence that opens each tour is distinct too (15/15), which took sharpening three that had drifted together (festive, saree, modest).

**3 · Next level of realism.** A **REALISM FIRST** law now sits in every tour and in four engine places — `packs/fashion.md`, `shared/craft-detail-and-cast.md`, `DETAIL_DENSITY` in `src/lib/prompts.js` (pushed into both the H3 and the LTX message) and both fallback system prompts. The law: *the frame is a capture, not a render — skin keeps its texture, its fine hair and its own unevenness, fabric keeps its weave and the marks of a day, surfaces keep their wear, and the room's light behaves; micro-imperfection is welcome and never takes a beat; no smoothing, no plastic sheen, no beauty filter, no morphing, no floating objects, no text in frame.* Each register then names **its own material proof** — salt drying on skin (swim), breath vapour in the cold (ski), the yarn's fuzz (knit), lace as thread with its own shadow (lingerie), dye bleeding at the selvedge (boho), fleece pilling at the cuff (streetwear), the press of the crease (tailoring), floor dust at the hem (evening). The two restraint guards (lingerie, swimwear) are honoured by the realism law too: realism obeys the register's own camera height and stays within what the block allows.

**Measured:** suite **§26** (13 pins) — fifteen vocabularies, the five fields with distinct moods and grades, fifteen distinct lighting openings, the realism law in all fifteen blocks, the engine carrying it, and the uniqueness of the laws themselves. One knock-on: the weight ceiling moved from 1,275 to **1,320** words, because the space law and the realism law are two mandatory paragraphs per tour (heaviest block now 1,293).

**Open:** whether the same treatment should be applied to the six `tour-grammar.md` tours (bridal, jewellery, quiet-luxury, hard-sun ×2, bridal jewellery) — their beat names are already mostly register-specific, but THE WALK · THE TURN · THE FACE still repeat there — and whether MOOD should be a UI row rather than a drawn dimension.

---

## Q1bi · The H3 and LTX contracts, checked in code

> *"Now make sure we write prompt properly that matches h3 and ltx requirement."*

Until now the contracts lived in the system prompts and in documentation — the model was *taught* the rules, and the instant engine was not held to them at all. A live probe of the two offline generators (Saree, Streetwear, Lingerie) measured the gap: **H3 19/21 · 19/21 · 20/21 and LTX 16/19 ×3.** Four faults, all in `src/lib/offline.js`:

1. **Director instructions reached the shots.** Choreography and flow pool text written for the LLM — *"Establish her once at full or three-quarter scale…"*, *"the flow sets…"*, *"opens wide enough…"* — was emitted verbatim into `integrated_multimodal_description` and into the LTX paragraph.
2. **`Static shot` ignored amplitude and speed**, so the H3 "amplitude and speed in plain words" requirement failed whenever the camera was locked off — and the same entry started lowercase, which defeated the LTX writer's `/^The camera /` strip and produced *"The camera the camera holds…"*.
3. **H3 protocol labels inside the LTX paragraph.** `WARDROBE:` and `THE MODEL IS` were pasted in verbatim; the LTX contract has no labels at all.
4. **A broken audio join** — *"The scene breathes with the space carries its natural ambience"*.

**What was built.** A dependency-free contract layer, `src/lib/contracts.js`, with **`checkH3` (21 checks)** and **`checkLtx` (19 checks)**, `contractLine(res, engine)` for the card badge, and the shared vocabulary the whole pack now uses — `DIRECTIVE_RE`, `MUSIC_MOOD_WORDS`, `LTX_CUE`, `ltxSentenceBand`. Then both generators were fixed rather than documented around:

- **The scrub has a single home.** `scrubDirectives()` runs at the *output boundary* — after all assembly — on the H3 description, the soundscape, the music field and the LTX paragraph, so a director instruction never ships no matter where it came from (a pool line, a value the user typed, text converted from the other engine). A sentence that is entirely instruction leaves; inside a shot sentence the instruction clause leaves and the beat survives.
- **The camera always states its motion.** Every entry in the camera table now takes the amplitude and speed clause, including the locked-off and handheld ones, and a template naming a camera the table does not carry (`Auto`, *"Slow orbit — one smooth move"*) no longer throws `CAM[type] is not a function` — it resolves to a real phrase with a stated amplitude.
- **The LTX writer was rebuilt around the LTX contract.** One flowing present-tense paragraph: the subject and the garment, the setting in depth, the block's own beats in order with their connectors, one motivated camera move that names where it settles, the block's realism sentence, the audio stated as audio *inside* the paragraph, then the score as instrumentation and tempo. No labels, no numbered shots, no timecodes. Sentences are normalised one by one before assembly (the old path shipped *"stillness., fine mist curls…"*), the paragraph is trimmed to the duration band by dropping the flourish, then the grade, then beats — never the camera, the realism line or the audio — and at 5–6 s the place folds into the opening sentence so the band can be met. A physical cue is guaranteed: if the trim takes the only one, it is folded into the realism sentence.
- **A runtime past 15 s is a chain, and says so.** H3 makes 4–15 s films in one generation. Rather than clamping a 16/18/20 s request silently, the prompt now states its own split — *"Delivered as a chain of 2 segments, each inside the 4–15-second window: 0–10s, 10–20s"* — and the contract accepts a runtime past the window **only** when the prompt names its chain.
- **The music field names instrumentation and tempo, never a mood.** Three bank entries and a block-level label (`"SCORE BED — e.g. …"`) were rewritten or stripped; a stub falls back to the bank instead of shipping the label.

**Where the checks live.** `checkH3`/`checkLtx` are folded into `scoreH3` (and a new `scoreLtx`) so the Audit tab carries `H3 contract · …` / `LTX contract · …` rows — a card cannot look clean and break its engine. Both cards show the badge (`🎬 H3 contract ✓` / `🎬 LTX contract ✓`) with the breaks on hover. The fallback critique now judges each target by its own contract (it used to apply an H3-shaped word ceiling to LTX paragraphs). The template linter judges every block on the laws a block can be held to — no director instruction, no protocol label, no numbered shot, no timecode, no doubled word, no emotion label. Converting an H3 prompt to LTX strips `[Shot N]`, timecodes and field labels before the paragraph is written.

**Measured:** every shipped block generated through both engines — **159/159 H3 clean (21/21 checks) and 159/159 LTX clean (19/19)**, repeated runs; the five blocks past the 15 s window all declare their chain. Suite **§27** (12 pins) holds it: the pins regenerate from the whole library and fail the build on a single break. Suite total **992 ✔ / 0 ✘**. Two older pins had encoded the very breaks this pass removed (they asserted `WARDROBE:` inside the LTX paragraph and a `wardrobeLtx+modelLtx` call site); both now assert the contract-correct law.

**Open:** the ≤120-character token ceiling and the `{TOKEN}` grammar mean a block that carries a token the filler never sees ships literal braces — the contract flags it on the card, but the block itself is only warned, not blocked. And a chain is declared, not sliced: the app still writes one prompt per scene, so a 20 s film is described as a chain and the scene planner does the splitting.
