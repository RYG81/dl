# Template modernization audit — 2026-09-27

**Every template in the library, read against every law built since the first ones shipped.**
Run it yourself any time: `npm run audit:templates` (add `--json` for machine output, `--info` for the
advisories, `--strict` to fail on an error).

## Read this first — three layers reach the model, not one

A template is not the only thing that shapes a generation, so "this template never mentions the
closed stack" is **not** a defect:

| layer | what it guarantees on every generation |
|---|---|
| **engine** — `src/lib/prompts.js` | READING BEAT · SHOT DESIGN · DETAIL DENSITY · TOKEN DISCIPLINE · the cast lock · the motion plan · the variation contract |
| **packs** — `public/prompts/packs/*.md` | the closed-stack law · innerwear-where-seen · the colour bank · the register rules for the domain |
| **template** | its own beats, camera grammar, timing and flow library |

A first scan that ignored those layers flagged **113 of 133** templates. After accounting for them
the real numbers are small — and they are all now zero.

## Where the library stands

| | count |
|---|---|
| templates audited | **136** |
| **ERROR** — the UI or the model is being misled | **0** |
| **WARN** — the template contradicts a law the engine also carries | **0** |
| INFO — advisory only (a fixed shot count where Auto exists, no flows, a long stretch with no beat language) | 96 |

## What was wrong, and what was done

| finding | found | action taken |
|---|---|---|
| templates misfiled by tag — a **Fashion / Lifestyle** template showing under **👤 Person**, plus 7 similar | 11 | tags repaired **and** grouping now resolved by `groupOf()`, so a misfiled tag cannot hide a template again |
| tags in use with **no label anywhere** (`preset` · `immersive` · `medical`) | 25 templates | labels added; the three drifting copies of the tag list were replaced by one file, `src/lib/tags.js` |
| skeletons that **stamp when their own cuts happen** (`At 00:03.000 the camera cuts…`) | 12 templates · 33 stamps | removed — a cut is never stated in seconds; it is derived from the live clock, so changing the duration cannot leave a template describing a cut that no longer happens there |
| timing lines stating an **absolute** budget (`hook 0-2s, action 2-10s…`) | 129 lines | now declared as **proportions of the runtime** — change the duration and every segment scales |
| templates that derive cuts but stated **no timing contract** | 3 | contract added |
| placeholder tokens over the **120-char** budget | 5 | shortened |
| camera language contradicting the contract | 0 real — 5 were the audit reading a **ban** ("never a whip pan") as a request | the check now understands negation |

## New versions — and the old ones kept, as asked

Three templates ship as the **2026 adaptive versions** of eleven older presets
(`public/prompts/templates/adaptive-films.md`). Each carries what the presets predate:
beats **derived from what you name**, a declared **flow library**, live dimensions,
fabric-driven choreography, the closed stack, derived timing.

| new version | replaces | why it is better |
|---|---|---|
| **🎬 UGC ad — adaptive beats, everything derived** | UGC skeptic testimonial · unboxing · before-after · day-in-the-life · three-step how-to | the five presets each hard-code three shots; this derives the beats from the hook, problem, steps, result and ask you actually name, with four flows and seven live dimensions |
| **👗 Fashion preset film — adaptive beats** | Walk-in approach · Detail bookend · Twirl reveal · Street-style walk · Walk-to-camera hook | the presets each fix one shot; this derives beats from the garment's fabric and cut, choreographs the fabric's real behaviour, and carries the closed stack and the reading hold |
| **🧥 Lookbook film — adaptive scenes** | 🧥 Lookbook film — one scene per look | keeps the chained lookbook but each scene now derives its own beats and flow, and states its place in the series so the chain cuts on a change of clothes and nothing else |

Every replaced preset is **still in the library**, untouched, and each now carries one line pointing
to its successor.

## Per-template result


### Errors

_None — the library is clean._

### Warnings

_None._

### Advisory notes (INFO) — 96 templates

These are not defects. A 6-second preset with one fixed shot is a legitimate format; an
advisory here means "worth a look only if this template is doing more work than it was designed for".


**`core.md`** — 86 templates

| template | advisory |
|---|---|
| Brand film — model performance | no beat-flow library; 25 tokens (soft target is 12) |
| Product hero — macro showcase | no beat-flow library |
| Cinematic one-take | no beat-flow library; 24 tokens (soft target is 12) |
| Dialogue two-hander | no beat-flow library; 21 tokens (soft target is 12) |
| Three-beat multi-shot | fixed multi3 at 12s — Auto derives the count from the runtime; no beat-flow library; 22 tokens (soft target is 12) |
| Vertical social hook | no beat-flow library |
| Music video performance | no beat-flow library |
| Documentary craft | no beat-flow library |
| Drone landscape reveal | no beat-flow library; a 12s H3 film with no beat language |
| Animation character beat | no beat-flow library |
| Seamless product loop | no beat-flow library |
| 🎞️ Recreate from frames | no beat-flow library |
| 🔁 360° product loop | no beat-flow library |
| 📱 Vertical loop (Reels) | no beat-flow library |
| 🖼️ First & last frame | no beat-flow library |
| 🎭 Identity lock | no beat-flow library |
| 🎵 Beat-sync cuts | no beat-flow library |
| 🌅 Day → night | no beat-flow library; a 12s H3 film with no beat language |
| 🗣️ Talking head | no beat-flow library |
| 📦 Cross-post pack | no beat-flow library |
| 💡 Before / after relight | no beat-flow library |
| 🚁 Drone flythrough | no beat-flow library; a 12s H3 film with no beat language |
| 🍜 Food macro steam | no beat-flow library |
| ⚡ Sports burst | no beat-flow library |
| 🤳 UGC testimonial | no beat-flow library |
| 🎄 Seasonal ad pack | no beat-flow library |
| Editorial fashion film | 21 tokens (soft target is 12) |
| Try-on 360 reveal | no beat-flow library |
| Walk-in approach | 22 tokens (soft target is 12) |
| Detail bookend | no beat-flow library |
| 360° garment turntable | no beat-flow library |
| Fabric macro detail | no beat-flow library |
| GRWM styling moment | fixed multi2 at 10s — Auto derives the count from the runtime |
| Walk-to-camera hook | no beat-flow library |
| Snap transition (2 looks) | no beat-flow library |
| 🎬 Campaign film — 6-scene chain | no beat-flow library |
| 🧥 Lookbook film — one scene per look | no beat-flow library |
| 🎞️ Fashion story arc — hook → turn → resolve | no beat-flow library |
| 🕯️ Boudoir portrait | no beat-flow library |
| 💞 Intimate two-hander | fixed multi2 at 12s — Auto derives the count from the runtime; no beat-flow library |
| … | 46 more |

**`medical-education.md`** — 4 templates

| template | advisory |
|---|---|
| MOA film — mechanism of action | fixed multi3 at 10s — Auto derives the count from the runtime |
| Disease-state journey — inside the body | fixed multi3 at 10s — Auto derives the count from the runtime |
| Classroom concept explainer — labelled 3D | fixed multi3 at 10s — Auto derives the count from the runtime |
| Hybrid explainer — real footage + 3D inserts | fixed multi3 at 10s — Auto derives the count from the runtime |

**`medical-reels.md`** — 3 templates

| template | advisory |
|---|---|
| Medical reel — symptom hook to one action | fixed multi3 at 15s — Auto derives the count from the runtime |
| Medical reel — myth vs fact, on camera | fixed multi3 at 12s — Auto derives the count from the runtime |
| Medical reel — the day of the procedure, what happens next | fixed multi3 at 15s — Auto derives the count from the runtime |

**`bridal-glamour.md`** — 1 templates

| template | advisory |
|---|---|
| 📱 Modern bridal glamour tour — couture, not costume | 24 tokens (soft target is 12) |

**`fashion-campaign.md`** — 1 templates

| template | advisory |
|---|---|
| 📱 Bridal jewellery show — five spots, one closing orbit | 25 tokens (soft target is 12) |

**`subfolder-demo.md`** — 1 templates

| template | advisory |
|---|---|
| Starter — subfolder demo (safe to delete) | no beat-flow library |

---

**Verdict: the library needs no further rewrite.** The real defects were metadata, stamped cut
times and token budgets — all fixed, all now pinned by suite 14 so they cannot come back.
