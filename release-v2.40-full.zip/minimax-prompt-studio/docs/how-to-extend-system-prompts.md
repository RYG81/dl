# How to give a system prompt a second (or third) file

The app loads four system prompts, all plain `.md` in `public/prompts/`:

| file | used when |
|---|---|
| `system-prompt.md` | H3 target, normal (SFW) mode |
| `ltx-system-prompt.md` | LTX target, normal (SFW) mode |
| `system-prompt-mature.md` | H3 target, **18+ switch on** |
| `ltx-system-prompt-mature.md` | LTX target, **18+ switch on** |

Any of them can depend on other files. The syntax is one line, alone on its own line:

```
@include my-rules.md               # same folder as the prompt file
@include shared/my-rules.md        # a subfolder
@include packs/fashion.md          # root-relative — also works from inside a nested file
@import  packs/ugc.md              # same as @include
[[include: packs/ugc.md]]          # bracket form
```

## Steps (18+ example)

1. Create the file: `public/prompts/mature-addendum.md` — write anything you like in it.
2. Open `public/prompts/system-prompt-mature.md` and add the line where you want that text to land
   (the end is the usual place):

   ```
   @include mature-addendum.md
   ```

3. Do the same in `public/prompts/ltx-system-prompt-mature.md` if LTX should follow the same direction.
4. Reload: ⚙️ Settings → **↻ Reload from file**, or refresh the page.
5. Confirm in ⚙️ Settings → System prompt: the row `H3 · 18+` shows the size, `📎 2` and the two file
   paths it pulled in (`prompts/shared/craft-detail-and-cast.md` + `prompts/mature-addendum.md`).
   The `ollama` console line on every generation repeats it.

Already wired in this project: both mature prompts depend on **two** files —
`shared/craft-detail-and-cast.md` (shared craft rule, included by all four prompts) and
`mature-addendum.md` (a second file, empty of your content — write yours there).

## What happens when something is wrong

| situation | behaviour |
|---|---|
| wrong path / file missing | prompt still loads; ⚙️ Settings shows `⚠ missing public/prompts/…`; the console line reports it |
| the file includes itself (directly or in a loop) | that include is refused, `⚠ circular …` is shown, the rest of the prompt loads |
| includes nested deeper than 5 levels | the extra include is skipped and reported |
| you delete the `@include` line | the prompt goes back to being a single-file prompt, nothing else changes |

Notes: `.md` files are served statically, so no build step and no code change is ever needed. Paths are
relative to the file doing the including, with a root-relative fallback (`packs/…` means
`public/prompts/packs/…` from anywhere). Includes nest: an included file may include further files.
Mature prompt files are only used while the 18+ switch is on.

## Or skip the editing: route it from the app

⚙️ **Settings → System prompt routing**

- **🌐 Universal** — pick any file and it is used for **every** generation (H3 + LTX, SFW + 18+). Use this for
  your own default prompt.
- **Per-slot rows** — `H3 · SFW`, `LTX · SFW`, `H3 · 18+`, `LTX · 18+`. Any row left on *Auto* keeps the stock
  file, so you can route only the 18+ slots to your own file and leave SFW alone.
- **📂 Upload .md → universal** — drops a file from your disk in as the universal prompt right away (its
  `@include`s are resolved), saved in this browser.
- The list is the live contents of `public/prompts/` (+ `shared/`) — drop a `.md` in and it appears.
- The console line on each generation names the source, e.g.
  `system prompt set: SFW-H3 · 🌐 UNIVERSAL ROUTE · 🌐 universal prompts/my-file.md (12,004 chars) + 📦 fashion +7,518 = 19,522 chars`.
- `↺ All Auto` in the same panel restores the stock four-file behaviour.

## HTML comments are author notes

In any prompt file (system prompts, packs, shared craft), an HTML comment is stripped before the
prompt reaches the model:

```md
<!--
  Notes for whoever edits this file. An @include written in here is NOT executed —
  documentation can never trigger itself.
-->
```

Anything outside a comment is prompt text. This matters for the SYSTEM prompt tokens: comments cost
nothing and can never accidentally include a file.

## Mature direction

Both mature prompts depend on three files, in this order:

1. `shared/craft-detail-and-cast.md` — the shared doctrine (detail density, women-only cast)
2. `shared/mature-craft.md` — the studio's mature craft: guardrails, explicitness ladder,
   cinematography, the official speech/non-verbal audio split, continuity and ending rules
3. `mature-addendum.md` — **your** file, included last so your direction is the final word

Editing (2) changes both the H3 and the LTX mature prompt at once. Editing (3) changes only your own
addendum. Render settings that pair with the craft: 2K or better, and give every sequence a close or
medium coverage — a face at full-body distance is lost by the render, not fixed by upscaling.

## The 18+ switch and the mature prompt files (rule, as of v2.2)

`public/prompts/system-prompt-mature.md` and `public/prompts/ltx-system-prompt-mature.md` are the user's
own files. The behaviour that matters:

- **The 18+ opt-in switch is the decision.** Switch ON → the mature file is the base of the generation,
  whatever the idea reads like. Switch OFF → the SFW file.
- The keyword detector only **advises**: write an 18+ idea with the switch off and the app says so in a
  toast, then stays SFW. It never silently downgrades a switched-on run (that was the v2.1 behaviour and
  it is the reason a user-maintained mature prompt could appear to be ignored).
- The builder prints, under the switch, **which file will run**, its size and its `📎` dependency count;
  an empty or unreachable file produces a warning and a loud `⚠ SFW fallback`, never a quiet one.
- The output card carries 🔞 (`mature-h3` / `mature-ltx`), 🛡️ (`sfw-h3`) or 🎯 (`routed-…`) plus the file
  actually used; the console line `system prompt set: MATURE-H3 · 🔞 mature file …` names it too.
- Logic lives in `src/lib/maturegate.js` and is pinned by suite 11c of `npm run selftest`.

