# Beat variation — why a batch looks like one film with a different model, and the fix

_Research pass 2026-09-28 · with the numbers this library now produces._

## The complaint, stated precisely

> "How to add dynamic variations that help us not clone same video that just look like model changed."

That is the right diagnosis of the wrong machinery. Our `vary:` dimensions were **all content**: who
she is, what she wears, which room, what she does. Swap all of those and you still get the same
film — because the film is not made of its content. It is made of **how the time is spent, how the
frame size moves, what earns each cut, and how the lens finds her**. Those four were identical in
every generation.

## What the research says

**1 · Real films don't cut evenly — they cluster.**
The largest study of shot lengths (Cutting, DeLong & Nothelfer, *Attention, Perception & Psychophysics* /
reported in the New York Times, 2010) measured shot-length sequences across hundreds of films and
found they follow a **1/f — "pink noise" — distribution**: neither random nor rigid, with long shots
grouped with long and short with short, in wave-like patterns. Films since 1960 have become *more*
clustered, converging on "a pattern of shot length that forces the reorientation of attention in the
same way we do it naturally." **Our clock cut every film into equal windows.** `/2`, `/3`, `/4` — a
metronome. That uniformity is what a viewer reads as "machine-made", and it is the same in every
variant.

**2 · Tempo is read from shot length, not from movement.**
A KTH study on cinematic tempo (shot length + motion across action films) found **shot length was the
dominant factor in how viewers perceive tempo**; motion mattered far less. Editing theory agrees and
states the shape: *"steadily lengthening shots create a slowing tempo, while successively shorter
shots create an accelerating one"* (rhythm relations, CMU editing lecture). So the *sequence of
lengths* is a first-class creative decision — and we never made it.

**3 · The reference numbers.** Modern features ≈ **4s** average shot length (Cutting); social/vertical
cinematic ads ≈ **1.2s** (SIGGRAPH-adjacent study of AI cinematic ads); action ≈ 2.4s (*Bourne
Supremacy*); a fast sequence can run at 0.58s (*Taken 3*); a single-take film's ASL is the whole
runtime (*1917*). A 20s jewellery show at eight cuts is ≈ 2.5s — in the reference band. A 20s film cut
into 12 equal 1.67s pieces is not.

**4 · Why generations loop.** Practitioner research on AI video repeats is blunt: clips resemble each
other "when every generation runs on the same prompt"; the fixes are *a different action per beat*,
*varying the camera angle and framing shot to shot*, and *writing the movement direction per shot at
the micro level — weight distribution, hand position, gaze angle*. And: *"prompt one micro-gesture,
never stillness"* — over-literal stillness freezes the subject, which produces the same static
non-motion in every clip.

**5 · The coverage-grid technique.** One production documented a 3×3 coverage grid — nine shots of a
single beat at three distances and three heights — yielding 20+ usable shots from one setup. Coverage
is a way to build variety *inside* a film rather than between films.

**6 · Transitions are a form decision, not decoration.** Editing theory separates the four relations
between shots — graphic, rhythmic, spatial, temporal — and notes that dissolves cluster in real films
with *longer* shots on both sides of them (preparation before, re-acceleration after). A cut is not
neutral: what the transition *is* changes what the audience reads.

**7 · What does not need varying.** The same research warns the opposite way too: every added person
and every added beat multiplies the model's interpretation ("one of them drifting is enough to break
the scene"), and character consistency comes from *locking* identity, not from moving it. So the
answer is not "vary everything" — it is **lock the identity, vary the form**.

## What shipped

### 1 · The clock now has a shape (engine, all paths)

`src/lib/duration.js` gained **seven rhythm envelopes** and `shotClock()` takes one:

| envelope | 12s example (4 shots) |
|---|---|
| flat | 3.00 / 3.00 / 3.00 / 3.00 |
| slow burn (accelerating) | 4.26 / 3.29 / 2.52 / 1.94 |
| decelerating | 1.95 / 2.60 / 3.30 / 4.16 |
| bookend | 5.22 / 2.61 / 2.09 / 2.09 |
| clustered (1/f-ish) | 5.18 / 1.91 / 3.27 / 1.64 |
| stutter then pop | 2.48 / 2.48 / 2.90 / 4.14 |
| one held opening | 5.36 / 2.57 / 2.14 / 1.93 |

Windows are proportional to the envelope's weights, clamped so no shot falls under `MIN_SHOT`, then
snapped to sum **exactly** to the runtime. The default (no envelope) is unchanged, so every existing
path and pin behaves as before.

The envelope is **drawn with the choreography** — `pickEnvelope(seed, duration)` uses the same seed as
the motion plan (`idea | title | variantIndex | flowIdx`), so:

- **variant 1 and variant 2 of one template never share a rhythm** — proof from the offline engine at
  12s: v1 bookend → cuts `5.217 / 7.826 / 9.913`; v2 holdfirst → `5.357 / 7.928 / 10.071`; v3
  stutterpop → `2.483 / 4.966 / 7.863`.
- the LLM path receives it too: the MOTION PLAN block now carries a **RHYTHM** line —
  *"the shot lengths follow a bookend — long opening and closing shots, tight middle envelope —
  5.2s / 2.6s / 2.1s / 2.1s. Write the beats to that shape … Never even out the cut lengths."*

### 2 · Eight FORM dimensions (pools + contract)

`public/prompts/fashion-variation.md` gained a **FORM** block with 8 pools: **RHYTHM ENVELOPE** (7) ·
**SCALE LADDER** (7, including the coverage grid) · **CUT MOTIVATION** (6) · **FRAMING DEVICE** (8) ·
**OPEN DEVICE** (6) · **CLOSE DEVICE** (6) · **TRANSITION** (6) · **SOUND FORMAT** (5).

`src/lib/formdims.js` defines the class and the **never-share set** (rhythm · ladder · framing · cut
motivation). The variation contract in `src/lib/prompts.js` now says, in the model's own instructions:

> FORM vs CONTENT: 3 content dimension(s) change WHAT is in the frame; 5 form dimension(s) change HOW
> the film is built … NEVER SHARE AXES — RHYTHM ENVELOPE · SCALE LADDER · FRAMING DEVICE · CUT
> MOTIVATION: your option on each of these must differ from every other variant in the batch, even
> when the woman, the room and the garment are the same. Two variants may share a model or a location;
> they may never share an edit signature.

### 3 · The templates declare them

**26 templates** now carry the eight form axes on their `vary:` line — the ten rebuilt/new fashion
templates, the whole `vary:`-bearing core family (9 adaptive templates + Room photo shoot + the
photo-shoot chain), the three adaptive films, both ornament shows, the outfit-reveal pair, the
fashion-campaign films and the intimates reels. Ten templates deliberately do **not**: the 2×2
e-commerce grid (its rhythm *is* the grid), the two immersive formats (no cuts by definition) and the
seven medical templates (a different register, and the fashion pools do not apply). The audit reports
those as INFO, which is now an accurate statement rather than a blind spot.

### 4 · Two more laws from the practitioner research

- **One micro-gesture per beat, never stillness** — into the fashion pack's motion doctrine, with the
  micro-level named (hand position, gaze angle, where the weight sits). Over-literal stillness is what
  makes a batch return the same frozen pose.
- **The coverage grid** — as SCALE LADDER option 7: one beat shot as a 3×3 of three distances and
  three heights, cut from the nine.

## The acts, not just the cuts — the second half of the same fault

> *"not just structure, content also. 2 bridal video made can not be same action/movement with only model and clothing changed."*

Correct, and the measurement proved it. The engine drew each shot's act with a **rotation** of a
fixed list (`rot(fam.move, seed)`), so two variants got the *same four acts in a new order* — the
pairwise act overlap between variant 1 and variant 2 was **4 of 4**. Different woman, different
clothes, identical film. On the LLM side it was worse: none of the bridal templates declared
`ACTION`, `MOVEMENT` or `PRESENTATION` at all, so the contract could not vary what she does even in
principle — the beat inventory came from the template and was the same every run.

**What changed:**

1. **The act banks were expanded** — every motion family now carries **14–21 acts** (ethnic/bridal 21)
   and **6 presenting gestures**, up from 4–5 moves and 3 gestures. Writing mattered here: the acts
   are the film.
2. **Variants draw disjoint blocks, not rotations.** The bank is shuffled once per *idea*
   (idea + title, deliberately **without** the variant index, or two variants could collide), and
   each variant takes the next block of that shuffle: variant 1 = block 0, variant 2 = block 1, and
   so on. Measured: **0 of 4 shared acts between variants 1 and 2, and 0 across three variants** —
   for a four-act film the first four variants share nothing at all. Past that the blocks wrap, and
   a wrapped pass is re-shuffled so it cannot repeat an earlier variant exactly.
3. **The rhythm was given the same guarantee.** Envelopes were drawn per variant by hash, which can
   and did collide (variants 1 and 3 landed on the same shape in a probe). They are now **stepped**
   by the variant index — variant 1 takes the drawn envelope, variant 2 the next — so a run of seven
   generations gets seven different shapes, measured 7/7 distinct.
4. **Posture agrees with the flow.** A seated act ("she sits and the skirt pools around her") cannot
   land inside a beat flow called *WALK THE GROUND*, so a flow that names a seat draws from the full
   bank and every other flow draws from the standing acts.
5. **The instruction is explicit and exclusive.** The motion block now reads *"SUBJECT MOVEMENT
   (this variant's act set — one act per shot, never the same verb twice, and these acts only) …
   Do NOT stage an act outside this set — not even one the template lists as an example beat.
   Another variant of this run draws a different set of acts, so two films that share their
   movements read as one film with a different model in it."*
6. **The templates declare the acts.** `ACTION`, `MOVEMENT` and `PRESENTATION` are now varying
   dimensions on **34 templates** (the bridal tours, both ornament shows, bridal editorial, bridal
   glamour, photo shoot, the core family, outfit reveal, fashion campaign, intimates, adaptive
   films). Three templates still vary nothing about what she does and are reported as INFO: the 2×2
   collage (its rhythm is the grid), the UGC ad (its beats are the ad structure) and the labelled 3D
   explainer (different register).
7. **The pools were deepened** so option #k is always a different act: `ACTION` 6 → 14 options,
   `MOVEMENT` 6 → 12, `PRESENTATION` 6 → 12 — including the bridal acts the refs use (the veil
   across and overhead, the hand insert, the seated presentation beat, the bangle stack, the gajra,
   the anklet beat).
8. **The never-share set now covers the acts.** `NEVER_SHARE` = the four edit axes **plus ACTION ·
   MOVEMENT · PRESENTATION**, and the contract states it plainly: *"Another variant of this batch
   may not walk the same way, turn the same way, sit or rise the same way, or present the piece the
   same way — two films that share their actions read as ONE film with a different model and
   different clothes, which is the exact fault this template exists to prevent."*

**Measured result** (bridal idea, 16s, 5 shots, two variants of one template):

| | variant 1 | variant 2 |
|---|---|---|
| rhythm | pink (5.0 / 3.9 / 3.0 / 2.3 / 1.8s) | stutter then pop |
| acts | hand to the cuff · the pleats swing out · embroidery catches the key · the pallu lifts across the arm · she lifts the chin | the veil across her face · the veil overhead · she sits and the skirt pools · the waistband set straight · bangles stacked |
| presenting gesture | the pleat stack arranged, gaze down then up | one hand flat on the waistband |
| cuts | 3.2 / 6.4 / 9.6 / 12.8s | 5.0 / 8.9 / 11.9 / 14.2s |

**Act overlap between them: 0.** Nothing about these two films is the same except the woman and the
clothes — which is the point.

## How to see it working

Run 3 variants of any fashion template and compare, in order:

1. the **cut times** — not evenly spaced, and not matching between variants;
2. the **acts** — nothing she does in variant 1 should appear in variant 2 or 3: different walk,
   different turn, different hands, different presentation;
3. the **rhythm name** — the ⏱ chip and the RHYTHM line in the prompt name the drawn shape.

If two variants cut at similar times, at the same scale order, on the same trigger, or with her doing
the same things, they are the same film twice — that is what this pass exists to prevent.
