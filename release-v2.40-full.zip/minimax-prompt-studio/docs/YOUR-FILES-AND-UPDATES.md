# Your files, your edits, and updates that can't eat them

Three short procedures. Read §1 once (it answers "why is that cell empty?"), then §2 and §3 whenever you need them.

---

## 0 · Why the "📎 0" cell was empty

`📎` counts the files a prompt pulls in **itself** — its `@include` lines. In your screenshot:

- `H3 · 18+  10,760 chars  📎 0` → **your** `public/prompts/system-prompt-mature.md` has no `@include` line in it,
  so nothing is pulled in. Not a bug, not an error — the file simply stands alone.
- `LTX · 18+  33,450 chars  📎 3` → that file *does* include three: `shared/craft-detail-and-cast.md`,
  `mature-addendum.md`, `shared/mature-craft.md`.

If your dialogue bank / secondary-action bank / examples should reach the H3 18+ prompt, either add one line to
that file (§1) or attach the bank in the app (§2 — no editing at all).

---

## 1 · Add a file with one line (the `@include` route)

1. Put your file in `public/prompts/banks/` — e.g. `public/prompts/banks/dialogue-bank.md`.
2. Open the prompt that should use it, e.g. `public/prompts/system-prompt-mature.md`, and add **one line on its own**:

   ```
   @include banks/dialogue-bank.md
   ```

   Paths are relative to the file doing the including (`banks/…` works from `system-prompt-mature.md`, because both
   live in `public/prompts/`). `@import …` and `[[include: …]]` work the same way.
3. Reload: ⚙️ **Settings → ↻ Reload from file** (or refresh the page).
4. Check: the `H3 · 18+` row now reads `📎 1` and names the file. If you typo the path it shows `⚠ missing …` and the
   prompt still loads.

Do the same in `ltx-system-prompt-mature.md` if the LTX target should get the bank too.

---

## 2 · Attach a file in the app (no editing, no `@include`)

⚙️ **Settings → System prompt routing → 🧩**

Each row has an attach picker: **🌐 all generations**, `H3 · SFW`, `LTX · SFW`, `H3 · 18+`, `LTX · 18+`.
Pick a file → it's appended to the system prompt **for those generations only**, its own `@include`s are resolved,
and it shows as a chip you can click to remove. Every generation logs it:

```
system prompt set: MATURE-H3 · 🔞 mature file system-prompt-mature.md (28,226 chars) + 📦 fashion +7,518
   + 🧩 dialogue-bank.md +4,102 = 39,846 chars · 📎 dependencies: … · 🧩 attached context: prompts/banks/dialogue-bank.md
```

Use this when you want the bank in more than one prompt, or when you'd rather not touch a prompt file at all.
Attachments are saved in this browser with your other settings and are re-resolved on every load.

**Where to put bank files:** `public/prompts/banks/` (any `.md` there appears in the picker). Nothing in that folder is
ever overwritten by an update — see §3.

---

## 3 · Updating without losing your work

The old workflow (download the whole project, merge by hand) is replaced by a patcher that **cannot** overwrite a file
you changed. The rule is one sentence:

> A file of yours is only replaced when it is **byte-identical** to the version we shipped.
> Otherwise your copy stays and the incoming version is written beside it as `<file>.new`.

### What is never touched, even if you never edited it

```
public/prompts/banks/**              your banks
public/prompts/user/**               anything you park here
public/prompts/mature-addendum.md    your mature addendum
public/prompts/*mature*.md           BOTH mature system prompts
public/prompts/templates/user-*.md   your templates
public/prompts/system-prompt-sample.md
.env                                 your keys
```

Add more with `patch.config.json` in the project root:

```json
{ "protected": ["public/prompts/fashion-craft.md", "src/components/StudioForm.jsx"] }
```

### Applying an update

Every patch archive carries **`apply.mjs`** — the same engine, inlined, with no dependencies. It works on a copy
that has never seen the patcher before, and it needs nothing but Node:

```bash
node apply.mjs --list                 # what is in the patch, change nothing
node apply.mjs --into ~/cineprompt-studio        # apply (safe default)
node apply.mjs --dry-run --into ~/cineprompt-studio
node apply.mjs --accept-new --into ~/cineprompt-studio   # finish: take the new versions, old ones backed up
node apply.mjs --clean                # delete apply.mjs + manifest.json + files/ when you are done
```

Run it from inside your project and `--into` can be omitted. If you unzipped the archive *into* your project, that
also works — `--clean` tidies the three scaffolding entries away afterwards.

Step 1 leaves a report (`PATCH-REPORT.md`) listing what changed and which files were left alone. Step 2 takes the new
version of those left-alone files, after copying your current version into `.patch-backup/<version>/…` — so even
then a revert is one copy command.

After the patch, the patcher is part of your project (`npm run patch`, `npm run snapshot`, `npm run make-patch`), so
the commands below work from then on:

```bash
npm run patch -- patch-v2.2.zip
```

You get `PATCH-REPORT.md`:

| action | meaning |
|---|---|
| `add` | file you don't have yet → created |
| `update` | you never touched it → replaced with the new version |
| `same` | already current → nothing to do |
| `keep` | protected path → your file kept as-is, new one beside it as `.new` |
| `conflict` | **differs from what we shipped** → your file kept, new version at `<file>.new` |
| `accepted` | you ran `--accept-new` → replaced, your old copy saved in `.patch-backup/` |

**Nothing is ever deleted**, and the patcher never renames a `.new` over your file — that decision is always yours
(or `--accept-new`'s, and even then your copy is backed up first).

### Which files a patch will never contain

`public/prompts/*mature*.md` is excluded from every release: those are yours. A patch only carries a mature prompt
when there is new MiniMax H3 prompting knowledge to fold in, and the manifest says so when it does. The same goes for
`banks/**`, `user/**`, `mature-addendum.md`, `templates/user-*.md`, `system-prompt-sample.md`, `.env`,
`patch.config.json`, `.patch-backup/**` and `patches/**`.

### Making a patch (when you're the one sending changes)

```bash
npm run snapshot         # record the current state as "what I shipped"
# … make your edits …
npm run make-patch -- v1.2
# → patches/v1.2.zip  (only changed files + a manifest of the previous hashes)
```

`patches/state.json` is the reference point. Because the manifest carries the hash of the version you shipped, the
receiver's patcher can tell "unmodified" from "they edited this" without any manual bookkeeping.

---

## 4 · Which workflow for which job

| you want to change… | do this | survives updates? |
|---|---|---|
| your own direction for 18+ | edit `mature-addendum.md` or attach a bank (§2) | yes — protected |
| the guards/craft for 18+ (both targets) | edit `public/prompts/shared/mature-craft.md` | conflict-report, never silent |
| a bank (dialogues, actions, examples) | drop it in `banks/` and attach it (§2) | yes — protected |
| a stock system prompt | edit it, or better: **route** your own file (Settings → routing) | routed file = never touched |
| a template | make it `user-*.md` (Settings → 📂 paste/import, or Forge) | yes — protected |
| app code | edit it; updates will report it as a conflict instead of overwriting | conflict-report |

## Subfolders in the template library (v2.7)

You can organise `public/prompts/templates/` into folders — `bridal-2026/`, `client-acme/looks/`, anything.
The scan is recursive (4 levels), the folder shows up as a filter in the picker, and **everything inside a subfolder is
treated as yours**: updates only ever write files into the *root* of that folder, so your tree is never replaced,
flattened or reordered. Files whose name starts with `user` are yours too, at any depth.

`README.md` and files starting with `_` are skipped — use them for notes you do not want in the picker.

**A file that is scanned but lists nothing now says why (v2.9).** If one of your files is found but has no `## Title` +
skeleton, the picker, the Templates page and the console name it — *“1 file in prompts/templates/ gave no templates”* — instead
of hiding it. And a file in a subfolder is listed even if your copy's `vite.config.js` is an older flat-index one, because the
loader also reads `prompts/_tree.json`, which every config version writes. `await window.cpsTplDiag()` in the console prints
every file the loader can see, its folder, and its block count.

