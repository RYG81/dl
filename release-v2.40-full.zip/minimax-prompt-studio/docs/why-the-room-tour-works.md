# Why the Room outfit tour beats the templates we built from the video refs

_Companion to v2.29 · every number below is produced by `npm run audit:templates`, the same
counters the audit now runs on every shipped file._

You said it first: **none of the templates we made from the video refs is as good as Room outfit
tour.** It is not taste and it is not the register — the refs' register (oxblood and zardozi, choker
and tikka, hard sun, quiet silk) is good. It is **mechanics**, and mechanics can be counted. So they
were counted: subject acts against camera-tasks, who causes each change of frame size, how many
words the brief spends on the performance against how many it spends shouting law, and how many
beats a runtime can actually hold.

## The measurement

| template | run | words | subject acts | camera-tasks | scale change by HER | scale change by CAMERA |
|---|---|---|---|---|---|---|
| ★ **Room outfit tour** — the benchmark | 8s | 807 | 61 | 2 | 5 | **0** |
| 📱 Jewellery macro ladder | 12s | 891 | 3 | 1 | 0 | **1** |
| 📱 Quiet-luxury studio | 10s | 1083 | 20 | 1 | 2 | **0** |
| 📱 Hard-sun studio | 10s | 1053 | 20 | 0 | 0 | **0** |
| 📱 Bridal editorial | 18s | 1455 | 14 | 3 | 2 | **0** |
| 📱 Modern bridal glamour | 18s | 1619 | 20 | 1 | 2 | **8** |
| 📱 Bridal jewellery show | 18s | 2062 | 28 | 0 | 0 | **11** |
| 🧵 Bridal tour | 10s | 1062 | 39 | 0 | 6 | **0** |
| 💎 Jewellery tour | 10s | 976 | 38 | 0 | 4 | **0** |
| 🧵 Quiet-luxury tour | 10s | 923 | 28 | 0 | 4 | **0** |
| ☀️ Hard-sun tour | 10s | 911 | 25 | 0 | 5 | **0** |
| 👑 Bridal glamour tour | 12s | 1113 | 43 | 0 | 4 | **0** |
| 💎 Bridal jewellery tour | 15s | 877 | 21 | 0 | 2 | **0** |

_Then: the benchmark and the six ref-derived films as they shipped. Now: the six rebuilds in
`tour-grammar.md`. Words = the film brief plus the idea. Subject acts = verbs where her body does
something. Camera-tasks = beats where the lens is told to go looking. Scale change = who makes the
frame tighter or wider._

## What the numbers say

**1 · In the refs the camera is the only thing that moves.** `Bridal jewellery show` changes frame
size 11 times and **not once because she moved**. `Jewellery macro ladder`: one camera move,
zero by her. The room tour is the exact inverse — **0 camera moves, 5 by her**. That one fact is
most of the difference. When the subject travels through the framings, the framings arrive as a
consequence of *her* and the result reads as a film; when the lens travels across a still subject,
the result is a sequence of framings — a slideshow with good lighting. It is the same reason a
walk-in beats a pan.

**2 · A beat was a view, not an act.** 61 of the room tour's beats are things her body *does* — she
walks, lifts, turns, settles, looks. In the macro ladder the beat budget goes to looking instead:
*the camera reads the wrist*, *a macro on the tikka*. A view costs the model nothing to satisfy and
produces nothing to watch. An act is the thing that gets photographed while it happens. **The
ornament is read because she presented it — never because the lens hunted it.**

**3 · Weight.** The benchmark says all of it in 807 words. The ref-derived films take
891–2,062, and most of the extra is all-caps law blocks (10–29 per film) restating
rules the engine already injects — TOKEN DISCIPLINE, READING BEAT, DETAIL DENSITY, the closed stack.
A brief that is mostly rule-book crowds out the performance, and the passing detail you actually
named is the first thing to go. Every rebuild is under 1,200 words and carries no heavy law blocks.

**4 · Duration against beats.** `Bridal jewellery show` asks for 60 acts inside 18 seconds — 3.3 a
second, which cannot be filmed. The model must invent, compress, or quietly drop. The room tour runs
at about **one act per second**, and says so. The rebuilds carry the same contract: one act per
beat at 1–1.5s, and a longer runtime gives the beats more room rather than adding more of them.

**5 · A flat ground cannot be travelled.** Most of the refs stand her on a seamless sweep — no near
wall, no far wall — so nothing can change across distance, and the only way to change the frame is
to move the lens. Every rebuild names a ground with **a bright zone and a deep zone she can walk
between**. The room tour's real secret is that it has a room.

**6 · The macro law was a loop.** The refs' ornament macro takes the piece off her body. That is
also a rule we later outlawed library-wide for jewellery films, and it is why those beats read as
product shots dropped into a portrait. The rebuilds keep every piece on her, in frame, in context.

## What shipped

- **`public/prompts/templates/tour-grammar.md` — one new pack, six rebuilt templates**, each mapped
  to the ref it rebuilds: 🧵 Bridal tour (← bridal editorial) · 💎 Jewellery tour (← jewellery macro
  ladder) · 🧵 Quiet-luxury tour (← quiet-luxury studio) · ☀️ Hard-sun tour (← hard-sun studio) ·
  👑 Bridal glamour tour (← modern bridal glamour) · 💎 Bridal jewellery tour — five light spots
  (← bridal jewellery show).
- Every rebuild carries: a **locked camera** (no travel, no zoom, no orbit), beats written as **her
  acts**, one act per second, a **flow library that re-orders named beats and never adds one**, the
  OPEN walk-in first and the CLOSE gaze-hold last, the layer stack with innerwear-where-seen, live
  clock TIMING, and the register of its parent — jewel tone and kamar bandh, hard sun, quiet silk.
- The six originals are **untouched**, and each now carries a forward pointer to its rebuild.
  Nothing you have been shooting with has been taken away.
- **`npm run audit:templates` now measures this on every file**: a `SLIDESHOW RISK` warning when
  camera-tasks outnumber her acts, and a camera-travel warning when the lens does the travelling in
  a film that has a wearer in it. Product films travel by design, so they are exempt. The four
  remaining warnings are exactly the refs you called out — kept, and now labelled.
- **New suite pins** in section 16 hold the rebuilds to 0 camera moves, at least two scale changes
  caused by her, no beat outsourced to the lens, and under 1,200 words each.

## How to judge the next output

Count the camera moves in the generated film. If the frame tightens because the lens went looking,
that template did not do its job — say so and the flow gets tightened. The frame should change only
where **she** walks, stops, turns or steps in, and the close should arrive as a step, not a zoom.
