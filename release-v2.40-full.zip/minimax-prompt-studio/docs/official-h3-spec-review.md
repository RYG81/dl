# Official H3 spec review — what we already matched, what was missing, what changed

Source: **MiniMax-AI/MiniMax-H3 → `skills/h3-prompt-writing`** (the official prompt-writing skill:
`SKILL.md` + `references/base-en.txt` for T2VA / I2VA / FL2VA / L2VA, and `references/ref-en.txt`
for full-reference Ref2VA), last touched Aug 2026. Every claim below was checked line-by-line
against `public/prompts/system-prompt.md`, `src/lib/prompts.js` and the builder.

---

## 1 · What we already had right (no change needed)

| Official rule | Our implementation |
|---|---|
| Three core fields, exact names and order: `integrated_multimodal_description` → `overall_soundscape` → `non_diegetic_music` | ✅ system prompt + `normalizeVariant` aliases |
| `[Shot 1]` carries **no** timestamp; later shots `[Shot N] At MM:SS.mmm`, strictly increasing | ✅ stated twice in the base prompt |
| A cut must add NEW information; if only distance/angle changes, move the camera instead | ✅ verbatim rule |
| Camera written as **natural English inside the shot**, with motion type + amplitude + speed | ✅ identical rule, and our `CAMERAS` chip list is the official vocabulary table word-for-word (Static shot → Roll counterclockwise) |
| Style/medium declared at the start of `[Shot 1]` (cinematic, live-action, 2D-animated, 3D CG, claymation, watercolor, vintage film) | ✅ "medium-declaration clause" rule |
| Duration 4–15 s, total must match the requested length | ✅ parser clamps to 4–15, builder offers 5–15 |
| Prefer concrete detail over abstract words | ✅ (our "no generic ambience", "name specific sounds") |
| Timecoded shot blocks for multi-beat prompts | ✅ |

So the core grammar we've been writing against was correct — your instinct was right.

---

## 2 · Gaps found (all were real deviations from the official spec)

### 2.1 Keyframe modes must open with an exact instruction line — we never emitted it
The official guides require the answer to **begin** with a fixed sentence, then one blank line,
then the fields:

- **I2VA** — `For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.`
- **FL2VA** — `How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot N) aligns with the S.SS-second mark of the target video.`
- **L2VA** — `How the reference pictures align with the target video — <Picture 1> (from [Shot N]) aligns with the S.SS-second mark of the target video.`

with `S.SS` = the effective duration to **exactly two decimals** and `N` = the real final shot index.
Our I2V/FFLF modes wrote the description directly and had no alignment line at all.

### 2.2 L2VA did not exist in the app
Official mode list is T2VA / I2VA / FL2VA / **L2VA** / Ref2VA. We shipped t2v / i2v / fflf / multiref / a2v —
**last-frame-to-video was missing entirely**. It is a genuinely different task: the image is the
*final* frame, so the model must invent a plausible earlier state and converge on it.

### 2.3 Full-reference mode output structure was wrong
We were emitting the **three-field** format for Ref2VA and citing references in prose
("Use Image 1 for the talent's face"). The official Ref2VA output is **six labeled sections, in order**:

```
subject_definitions → summary → retention_analysis → detailed_description → overall_soundscape → non_diegetic_music
```

with a fixed label vocabulary (`<Subject N>` / `<Picture N>` / `<Video N>` / `<Audio N>`), fixed
relationship markers (`fully_preserved` / `partially_preserved` / `attribute_transfer` /
`weak_reference`; audio: `fully_copy` / `partially_copy` / `reference` / `weak_reference`), a
bracketed **task-type prefix** on `summary` (`[keyframe completion]`, `[reference generation]`,
`[video editing]`, `[video continuation]`, `[audio reuse]`, `[audio reference]`, combined with ` + `),
a style/palette/light sentence **before** `[Shot 1]`, and a 350–500-word body for generation tasks.

### 2.4 Dialogue markup
Official: `<d>[Language] …</d>` with the user's words **verbatim**, stable speaker IDs `(S1)`,
compound IDs `(S1,S2)` for a group, no ID for non-vocalizing characters, the exact phrase
`says in an off-screen voiceover` plus a statement that the lips remain completely closed,
`<scenetrans>` when a line crosses a cut, `<cutoff>` when speech is truncated by the video end.
We were writing "speech in quotes with tone and pacing" — close, but not the trained markup.

### 2.5 Audio field punctuation
Official: `overall_soundscape` = **1–4 sentences**, must **not** repeat dialogue / singing / diegetic
music (those live in the description), `N/A` only for explicitly requested silence.
`non_diegetic_music` = **1–3 sentences**, instrumentation / speed / rhythm / dynamics, **no abstract
mood words**, diegetic music belongs to the description, `N/A` when none. We had good instincts
here but no caps and no repetition ban.

### 2.6 Smaller items
- Visible on-screen text (banner, sign, neon, subtitle) must be in **double quotation marks, verbatim, untranslated**.
- Cut phrasing has five accepted official variants ("the camera cuts to", "the shot cuts to / transitions to / changes to / switches to").
- FFLF **favors a single shot** so the model can interpolate continuously; multiple shots only when asked.
- I2VA internal path: first-frame anchor → action onset → continuous development → result/reaction.
- L2VA internal path: plausible preceding state → action/transition path → gradual convergence → landing.

---

## 3 · What changed (shipped)

| # | Change | Where |
|---|---|---|
| 1 | **🎯 L2V mode** added to the workflow chips, with its own last-frame box, hint and validation | `StudioForm.jsx` |
| 2 | **Exact official alignment line** emitted for I2V / FFLF / L2V, resolved with the real duration (2 decimals) and final shot index | `lib/prompts.js` → `alignmentLine()` |
| 3 | **Ref2VA six-section contract** wherever workflow = Refs: section order, label vocabulary, retention markers, task-type prefixes, 350–500-word guidance, style sentence before `[Shot 1]`, labels for the session's own attached references | `lib/prompts.js` + both H3 system prompts |
| 4 | **Six-section parsing** — `finalizeOutput()` detects the ref format, keeps the alignment line, and aliases `detailed_description` → `integrated_multimodal_description` so scoring, copy and template flows keep working | `lib/ollama.js` |
| 5 | **Copy/download is platform-ready** — the alignment line prints first, followed by blank line and either the three fields or the six sections | `lib/format.js` → `fullPromptText()` |
| 6 | **Card UI** — alignment line shown as its own labeled block, six sections rendered in order, `🧩 Ref2VA` badge | `OutputPanel.jsx` |
| 7 | **Ref2VA audit** — 13 checks against the official structure (sections, labels, prefix, markers, `[Shot 1]` timestamp rule, style sentences, word count, sentence caps) | `lib/scoring.js` |
| 8 | **Dialogue markup** — `<d>[Language] …</d>` verbatim, speaker IDs, voiceover phrase + lips-closed, `<scenetrans>` / `<cutoff>`; LTX keeps plain verbatim quotes | both H3 system prompts + `lib/prompts.js` |
| 9 | **Audio punctuation** — sentence caps, no dialogue repetition in the soundscape, no mood words in the music field, diegetic-vs-non-diegetic split, `N/A` rules | both H3 system prompts |
| 10 | **Visible text in quotes, verbatim, untranslated** | both H3 system prompts |
| 11 | **Cut phrasing** — the five official variants listed | both H3 system prompts |
| 12 | **FFLF single-shot preference** + internal paths for I2V and L2V | both H3 system prompts |

Not changed: the LTX prompt set (its own model, own contract — the official guide is H3-only),
the templates, the packs, and every rule we were already compliant on.

---

## 4 · Watch items for the next review

- **`<Subject N>` vs `<Picture N>` discipline** is the most likely failure: models tend to give an
  identity image its own `<Picture N>` line *and* a `<Subject N>` line. The prompt now states the
  rule; the audit flags missing labels but cannot detect duplication yet.
- **Task-type prefix** must never invent a type outside the official six — worth a linter check if we
  see drift in real outputs.
- **Ref2VA length** (350–500 words) is a floor only: **length is no longer limited anywhere in the app**
  (see the length-policy note below); dialogue-dense clips still prioritise the spoken timeline.
- The repo also ships eight **style-specific skills** — see §5 for what was mined from them.

---

## 5 · Style-skill templates — MINED AND SHIPPED

The eight Hub-native style skills were checked against our 92-template library; five had no
equivalent and were built as **dynamic (beat-flow) templates** from the skills' craft, the other
three were already covered.

| Official skill | Verdict | Template |
|---|---|---|
| `papercraft-stop-motion-explainer` + `paper-collage-explainer` | **new** | ✂️ **Papercraft cut-out explainer — adaptive beats** (tag `papercraft`, 16:9, collage foley only, `N/A` score) |
| `minimalist-product-ad-generator` | **new** | 🧊 **Minimalist product ad — copy-beat film** (tag `minimalist`, copy beats verbatim in quotes, seamless sweep + one soft key) |
| `music-video-subtitle-generator` | **new** | 🔤 **Kinetic lyric type — beat-locked subtitles** (tag `lyric`, verbatim lines as on-screen typography, cuts on the downbeat) |
| `handdrawn-live-video-generator` | **new** | 📜 **Reveal scroll — one continuous take** (tag `scroll`, one take, contact + morph chain + escape, camera reacts a beat late, non-horror) |
| `co-op-game-intro-generator` | **new** | 🎮 **Co-op game intro — player cards & menu** (tag `game`, fixed menu framework, two identity-locked characters, UI copy verbatim) |
| `brand-promo-video-generator` | covered | Brand film · Campaign film · Campaign showcase · DTC founder story |
| `3d-animation-short-generator` | covered | Animation character beat (+ any stylised medium via the chip list) |
| `h3-prompt-writing` | covered | the whole system-prompt/pipeline alignment in §3 |

Craft folded in from the skills (kept as model instructions, not UI prose): paper texture control
(clean fibre + torn deckles, never distressed), the stop-motion motion law (pop-in, slide, bounce,
press-flat, lock — never spin/flip/cross-fade/digital drift); seamless-backdrop commerce lighting
with copy in the negative space and a mark-safe hero ending; lyric-line-per-beat typography with
type *reactions* to kick/snare/riser; hand-drawn stroke physics (uneven pressure, glow landing on
real geometry, contact shadows) with the delayed hand-held chase; and a fixed game-menu framework
with two coordinated character cards.

Library now **97 blocks · 18 dynamic · 0 parse skips**, tags `papercraft / minimalist / lyric /
scroll / game` claimed by the animation, product, music and cinematic packs so routing is explicit.

---

## 6 · Length policy — nothing is capped (user directive, current)

Prompt length is **not limited** at any stage:

| Was | Now |
|---|---|
| `scoreH3` failed a card over 7,000 chars ("under the 7,000-char limit") | size is reported as information only — never a pass/fail |
| description word check `60 ≤ words ≤ 1500` | floor only (`words ≥ 60`), no upper bound |
| Ref2VA body had a 350–500-word *target* that read as a cap | stated everywhere as the official **floor**: keep writing while any shot, beat or reference role is undescribed |
| builder showed `N / 7000` and turned red past it | plain `N chars` count |
| Tips listed "7,000 characters per text item" as a limit | removed — the row now states the real platform specs only |
| linter nudged "Long — consider trimming prose" past 4,200 chars | no ceiling; the line reads "N chars of skeleton — no ceiling" |
| chain hand-off truncated the ending beat at 300 chars | the whole final beat is passed to the next scene |
| Ollama answered with its default output cap | `num_predict: -1` sent on every generation — the answer can't be cut mid-sentence |
| system prompts said nothing about length | explicit rule in both H3 prompts (and both fallbacks): *no character or word limit — never compress, summarise or drop detail to fit a budget; a longer prompt that states more is the correct answer* |

The only remaining bound is physical: how much context the local model holds. The Guide says so and points
at `OLLAMA_CONTEXT_LENGTH` / `num_ctx` on the user's own Ollama server.

---

## 7 · Ad-recreation template (Jan 2026 film-set hair spot)

`💇 Film-set meta hair spot — 20s chain (2 × 10s)` — see roadmap Q1e. Notable because it is our first
template built for a **20-second** deliverable: the app's clip ceiling is 15 s, so the format is
expressed as a two-scene chain (2 × 10 s) rather than a longer single prompt. Same official contract as
everything else: three fields, `[Shot N]` cuts, `<d>[Language]` dialogue verbatim, on-screen claim in
double quotes once, soundscape without music (the score drops for the dialogue beat).

## 8 · Animation-ad template set

Six more templates in the same official contract (see roadmap Q1f): 🐮 topical mascot cartoon ·
🧸 CG character short · 🪆 claymation mascot product spot · 📺 retro cel jingle · 🎌 anime-style
spot · 🍬 anthropomorphic product characters. Each maps an advertising format rather than a brand, and
each teaches its own medium law to the model — limited-animation holds for the cartoon, miniature
scale + real mass for CG, two-frame cadence and thumbprints for claymation, cel registration wobble
and graphic wipes for the retro spot, painted light change for anime, and product-scale tabletop
comedy for the toons.

## ENFORCED IN CODE (v2.40)

The rules above are not advice in this pack — they are checks.

| Where | What it does |
| --- | --- |
| `src/lib/contracts.js` | `checkH3(v, inp)` — 21 checks: three fields present and in order · `[Shot 1]` opens the description with no timestamp · every later shot timecoded `At MM:SS.mmm`, strictly increasing, inside the runtime, tail ≥1.5 s, numbers unique · runtime inside the 4–15 s window, and past 15 s the prompt must name its own chain of segments · no unfilled `{TOKEN}`, no director instruction, no markdown, no legacy bracket camera · style/lens/light declared in `[Shot 1]` · amplitude **and** speed in plain words · soundscape present, ≤4 sentences, no dialogue, no timestamps · music field = instrumentation and tempo, never a mood. |
| | `checkLtx(v, inp)` — 19 checks: one paragraph, no line breaks · no numbered shots, protocol labels or timecodes · no doubled word · present tense · emotion as a physical cue, never a label · a motivated camera move with a named end-state · the audio dimension lives inside the paragraph · sentence count inside the duration band · `negative_prompt` ≥3 items. |
| `src/components/OutputPanel.jsx` | every H3 card shows **H3 contract ✓** (or ✗ with the count), every LTX card shows **LTX contract ✓**; the tooltip lists the breaks. |
| `src/lib/scoring.js` | the contract rows are folded into the Audit score, so a card cannot look clean and break its engine; `scoreLtx` judges the LTX target by the LTX contract. |
| `src/lib/lint.js` | a template block is warned before it is saved when it would carry a director instruction, a protocol label, a numbered shot, a timecode, a doubled word or an emotion label. |
| `src/lib/convert.js` | converting an H3 prompt to LTX strips `[Shot N]`, timecodes and field labels before the paragraph is written. |
| `scripts/selftest.mjs` §27 | generates from **every shipped block** (159 today) and requires 21/21 H3 and 19/19 LTX checks — a break fails the build. |

Measured when this landed: **159/159 blocks pass both contracts, repeated runs.** Before the generator fixes the same probe measured H3 19/21 · 19/21 · 20/21 and LTX 16/19 ×3 on the outfit tours, from four faults: choreography pool text reaching the shots as director instructions, a camera entry that ignored amplitude and speed, an LTX camera sentence that doubled "the camera the camera", and H3 protocol labels inside an LTX paragraph.
