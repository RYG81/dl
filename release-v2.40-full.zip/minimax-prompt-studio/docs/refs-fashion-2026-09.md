# Fashion reference study — 22 clips (2026-09)

The owner's Pinterest set, downloaded and sheeted (4 frames each) and read frame-by-frame. Big files live outside the
workspace; the sheets and the contact-sheet index are in `refs/fashion/` (`sheets/`, `study/`, `index.json`).

| ref | what it is | the craft worth stealing |
|---|---|---|
| 01 | bridal jewellery — layered gold haars + polki choker, hand turning the pendant | ornament macro as its own beat; warm window key, dark fall; jewellery read against cloth |
| 02 | Chaashni black tulle lehenga | front → back → skirt sweep; net back + sequins as the "second look"; studio with a chiffon drape; brand still as the last frame |
| 04 | Mykonos black dress + stripe hat | real location, hand-on-hat pose, drink at the bar, walk down steps; locked camera, the world moves |
| 05 | quiet-luxury cream/sand studio (textured shirt, hand in pocket) | raking light so every fold has a lit edge; close detail of seam/placket; mono-palette held to three tones |
| 06 | Studio F e-commerce 4-up | four isolated cuts (front/back/side/detail) on one seamless — a product page that animates as a live layout |
| 07–10 | garden/ethnic float, denim + shadow play, sari in a ruined haveli window | "INTRODUCING"-style single overlay line; fabric flown by wind; hard sun through architecture |
| 11–13 | VCJ / Reliance bridal jewellery set on a red lehenga | macro hand+ring, mirror-walk, back-of-neck clasp, earring against the jaw, dark corridor; brand end cards |
| 14 | Shyamal & Bhumika — carved dark door into daylight | silhouette first, then the light takes over; drape sweep; scale beat with her small inside the doorway |
| 16–18 | PATBO swim (Camila) | waist-deep water walk, sand recline, sun-on-face close-up; water as the co-star; believable wet skin |
| 20–23 | whites/stripes + "NEW FOR SPRING" collage | cut-out collage panels with per-panel crops; brown/blue accents stopping an all-cream frame from reading blank |

## What was built from it

`public/prompts/templates/fashion-campaign.md` — six dynamic templates, all 9:16, all with a beat flow library:

1. 📱 E-commerce 4-up — cut-isolation collage (`CUTS ARRIVE | SWAP ONE PANEL | ZOOM ONE PANEL | DETAIL TO FULL`)
2. 📱 Jewellery macro ladder — ornament by ornament (`FULL THEN LADDER | SEATED SET | LADDER DOWN | LADDER UP` — rebuilt in v2.14: the film opens on the wearer and every insert stays anchored on her body, see docs/customization-guide.md)
3. 📱 Resort swim — water to sand (`WATER THEN SAND | WALK THEN TURN | SAND THEN SKIN | SPLASH AND HOLD`)
4. 📱 Quiet-luxury studio — cream palette, real texture (`STILL THEN TURN | DETAIL THEN FULL | HAND IN POCKET | SIT AND SETTLE`)
5. 📱 Heritage doorway reveal — drape sweep (`DARK THEN LIGHT | MIRROR WALK | DRAPE SWEEP | ARRIVE AND HOLD`)
6. 📱 Breeze float — garden / ethnic drape (`WALK THEN TURN | WIND THEN FABRIC | TITLE THEN FLOAT | TURN AND HOLD`)

House rules the whole pack obeys: colour always stated by name on the garment (the quiet-luxury template names its pale
base deliberately, so "cream" is a choice and not a default); silhouette/scale beats; one quoted on-screen line at most;
no logo or brand mark unless the request names one; and a stated pacing contract with cut timecodes inside the duration.

## Addendum — the two intimates clips (2026-09-27)

| ref | what it is | the craft worth stealing |
|---|---|---|
| 24 (40s) | Ilusión — lingerie collection launch, warm slatted-wood interior + a magenta studded-neck top in a garden | the overlay system: "NUEVA COLECCIÓN INVIERNO 25" as a launch card, then macro lace/detail, then the face and personality, then a second colourway; the script wordmark appears once, on the closing card; gestures are mirror-gestures (adjusting a strap, hand through the hair) |
| 25 (17.6s) | Ilusión — shapewear demo, even studio on a warm-neutral wall | turn front → side → back in one locked framing, then hands-on proof: the waistband drawn out and snapped back, the hem smoothed, a sit/bend for comfort; benefit copy as one quoted line per beat ("CONTROLA EL ABDOMEN BAJO…", "AFINA TUS CADERAS…") with copy that names the construction, not the body |

Both are **shop-window** clips: product-first, warm light, no boudoir staging. Folded into `templates/intimates-reels.md`:

3. 📱 **Intimates collection launch — overlay cards + lace macro** (`CARD THEN MACRO | MACRO THEN FACE | COLOURWAY SWAP | FACE THEN CARD`)
4. 📱 **Intimates demo — proof by turning** (`TURN THEN STRETCH | STRETCH THEN COMFORT | SMOOTH THEN TURN | DETAIL THEN TURN`)

House rules added for this pair, because the references carry claims: one quoted overlay line per shot, the wordmark only when the
request names a brand, no price or discount, and in the demo no weight/inches/before-after/testimonial or medical claim — the
benefit line may only describe what the construction does (double panel, bonded edge, four-way stretch, seamless knit). Framing is
held to the garment's own coverage and neutral, factual body language: no zoom on a "problem" area, no pinching to exaggerate,
no comparison against another body. Music and overlays in the refs are Spanish; the templates keep the same structure and let the
request choose the language of the quoted line.

## Video fetch notes (reusable)

* `savepin.app` `force-save.php?url=<urlencoded>` → decode the `url=` parameter; `stream.kapadiya.net/temp-dl?token=<base64>`
  → base64-decode the token. Both give the real `v1.pinimg.com` URL.
* **m3u8/HLS below the `iht/hls/…` path is dead** (`AccessDenied`, and the local ffmpeg 7 build segfaults on it) — resolve the
  same hash to an MP4 instead: `iht/expMp4/<aa>/<bb>/<cc>/<hash>_720w.mp4`, `iht/hevcMp4V3/…_720w.mp4`, `iht/720p/<aa>/<bb>/<cc>/<hash>.mp4`,
  `mc/720p/<aa>/<bb>/<cc>/<hash>.mp4`. Try all four in that order; 4 of 5 resolved this way, 1 clip was unavailable in every form.
* Needs a browser `User-Agent` and `-e https://www.pinterest.com/`; a range request (`-r 0-1000`) is the fast way to test a
  candidate URL for 206 before downloading the whole file.
* In this sandbox there is no `ffmpeg` by default — `pip install imageio-ffmpeg` gives a working 7.0.2 binary to copy onto `PATH`.
