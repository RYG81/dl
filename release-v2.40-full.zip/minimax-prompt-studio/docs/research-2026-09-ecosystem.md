# Research — video-gen ecosystem snapshot (2026-09-20)

Web-researched facts that should feed app guidance (add-on 35 policy). Sources cited inline.

## MiniMax H3 (Hailuo 3.0) — released 2026-07-31, open weights 2026-08-03
- 33B omni-modal: text/image/video/audio in → video + **native 32 kHz stereo audio** out, single pass.
  (https://www.orcarouter.ai/blog/minimax-h3-hailuo-3-explained)
- **Omni-reference**: up to **9 images + 3 video clips + 3 audio clips** (12 files max) as references for
  style, character, motion AND voice consistency. (orcarouter)
- Modes: T2V, I2V, first/last-frame, multimodal reference-to-video, **instruction-based editing**.
  (https://anikuku.com/blog/minimax-h3-video-model-guide-2026)
- 4–15 s clips (extendable ~30 s), 24 fps, native 768p local / 2K hosted-only via H3-Regenerate-2K.
  H3-Context-IR (instruction refinement) is hosted-only. (anikuku)
- Open weights: FL2VA + Ref2VA checkpoints; Community License **excludes US/EU/UK/KR local deployment**.
  (https://explainx.ai/blog/minimax-h3-open-video-model-hailuo-july-2026)
- fal post-trained "H3 Max" — better prompt adherence, 5–15 s, 768p, native stereo audio.
  (https://morphic.com/resources/models/minimax-h3-max)
- Self-hosting: vLLM-Omni + FastVideo FastH3 → 10.1 s clip with audio in ~8.7 s. (orcarouter)
- API pricing: $0.08/s @768p, $0.13/s @2K (official, verified 2026-09-11). (anikuku)

## LTX-2.5 (Lightricks) — released 2026-08
Official facts page: https://ltx.io/llm-info (designed for LLM ingestion — fetch full page when updating guidance).
- 22B asymmetric dual-stream DiT; **synchronized 24 kHz stereo audio + video in one pass**.
- **Custom Gemma 4 12B text encoder** (up from Gemma 3 12B in LTX-2.3); ~1000-token effective context (~750 words).
- **Native Multishot**: one generation = multiple connected shots holding character/environment/lighting/voice/style across cuts.
- **Dedicated Prompt Enhancer**: lightweight model expands short prompts into cinematic instructions near-free.
- **Retake** (regenerate a time region), **Extend** (continue past last frame), Reframe, LipDub, SDR→HDR (IC-LoRA Beta).
- **Video Editing IC-LoRA (Beta)**: edit real footage — object/rig removal, continuity fixes, env replacement.
- **Audio-to-video**: audio input drives generation. Auto Duration (model predicts length from action).
- 1080p/1440p/4K native, 24/25/48/50 fps, up to 20 s; Fast + Pro tiers; EXR/ACES pro workflow.
- Improved **distilled model** — near-full quality for local/high-volume. Deep fine-tune checkpoint released.
- License: free under $10M ARR.
- fal pricing: $0.09/s 720p → $0.30/s 4K, audio included. (https://fal.ai/ltx-2.5)

## Prompt-tooling market (what competitors ship)
- Scoring: 0–100 effectiveness across Clarity / Specificity / Context / Goal / Structure / Constraints;
  optimized variations + reverse-engineering from media. (https://quasa.io/video/promptessor-score-refine-prompts-for-50-better-ai-outputs-overview)
- Adobe Firefly "Enhance prompt": one-click expansion of user's text before generation.
  (https://helpx.adobe.com/firefly/web/work-with-audio-and-video/work-with-video/enhance-your-prompt-for-video-generation.html)
- LLM-as-judge eval loops, A/B on datasets, version control w/ rollback are now standard in prompt platforms.
  (https://www.braintrust.dev/articles/best-prompt-engineering-tools-2026)
- Video-to-prompt services exist as standalone tools — none integrated with a builder. (https://videotoprompt.org/)

## Character-consistency consensus (2026 best practice)
- **Separate identity from scene**: a character bible (age, build, hair, skin, face shape, signature items) +
  ONE canonical reference image; never re-describe the character per shot — reference carries identity,
  prompt carries only action/camera. (https://astorie.ai/workflows/character-consistency)
- Models reliably follow only **3–5 anchor attributes**; pick the 2–3 most distinctive and repeat them verbatim.
  (https://www.mindstudio.ai/blog/storyboards-character-sheets-ai-video-generation)
- **Anchor shots first** (establishing + key moments); later shots inherit frames from earlier outputs.
- **Batch by location** (all kitchen shots together) maximizes environment consistency. (https://www.aimagicx.com/blog/ai-multi-shot-video-character-consistency-2026)
- Transition craft: cut on motion, whip-pan hides seams, dissolve needs +1 s padding each side,
  match cuts need matched composition. (aimagicx long-form guide)
- Style LoRAs trained on 15–30 character images at 0.7–0.9 weight for long projects. (aimagicx)
