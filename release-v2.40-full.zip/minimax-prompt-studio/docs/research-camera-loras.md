# Camera, Cuts & Transitions + LoRA Field Guide
### MiniMax H3 × LTX-Video — deep research (compiled 2026-09-17)

---

## PART 1 — MiniMax H3: the camera is a timeline, not a label

H3 reads a prompt as a **production brief**: style contract → timed timeline → camera → audio → constraints. The camera grammar below is consistent across the edited community guide, the failure-fix tables, and MiniMax's own 45 official prompts [3][5][8][9].

### Shot & cut syntax (what actually works)
- `[Shot 1]` opens **without a timestamp**. Every later shot is introduced at an exact, strictly-increasing cut time: `[Shot 2] At 00:04.500, the camera cuts to …` [1][8][9].
- Ranges must be **sequential: no gaps, no overlaps**; the first shot starts at 00:00.000 and the last shot ends exactly at the clip duration [4].
- **2–5 s per shot.** Shorter than ~1.5 s doesn't give the model enough frames; the first beat otherwise eats the whole clip [1][4].
- **A cut must add new information** (new angle, height, shot size, subject focus, or time jump). If only distance/slight angle changes, use camera motion inside ONE shot — writing minor angle changes as separate shots is the #1 cause of random-looking cuts [8][9].
- More shots = more continuity risk. Official examples budget **max ~4 shots in 15 s** ("SHOT BUDGET: maximum four shots") [2].
- One primary camera movement per shot [2].

### Transition vocabulary
- Ordinary cuts: `the camera cuts to`, `the shot cuts to`, `the shot transitions to`, `the shot changes to`, `the shot switches to` [9].
- Dissolve / fade / wipe only **when explicitly requested** — otherwise H3 defaults to hard cuts, and "soft dissolves" is the most-negated cliché in official prompts [2][9].
- **Stylized transitions are physical events**, not effect names. Official patterns: whip movement + motion blur + optical smearing + exposure flicker, *cut at peak blur, then snap back into focus*; match cuts (eye reflection → space); liquid morph; paper rip; glitch; beat-synced slash cuts / panel snaps / mask wipes for music-driven edits [2][6].
- Negate what you don't want in prose: "No soft dissolves, no fluid morphs, no random scene cuts" [2][3][6].

### Writing camera movement
- Natural English sentence with **type + amplitude + speed**: "The camera pushes in with small amplitude at slow speed toward the folded letter." Omit amplitude for medium, speed for normal. Stacked labels ("cinematic camera, dynamic movement") produce the default slow dolly you didn't ask for [3][8][9].
- **Say static out loud**: "locked off, static wide shot, no push in, no cuts" — otherwise H3 drifts [3].
- Moves with proven adherence: slow dolly in/out, tracking, orbit/360, crane up/down, pan, zoom, crash zoom, dolly zoom (Vertigo), whip pan, steadicam follow, rack focus, bird's-eye [4].
- End every move with an end-state ("…settling tight on her face").
- Vertical 9:16: dolly in/out + tilt work great; pan left/right has limited room; close/medium > wide [4].

### Mode-specific camera behavior
- **T2VA**: free rein; three-field contract carries the timeline [5][8].
- **I2VA**: "At 0.00 seconds, Picture 1 is fully referenced." Do NOT re-describe the frame — restate anchors, then describe the NEXT action. H3 jumps to a new composition if you don't [1][5][8].
- **FL2VA (first+last frame)**: H3 **will not invent camera cuts in this mode** — the manual's example is "…flowing naturally, no cuts." Describe ONE continuous path with observable intermediate pose/object/light changes; repeating two static descriptions makes it jump/morph [7][8].
- **L2VA (last frame only)**: put the landing instruction first, add a gradual approach, converge only at the end [5][8].
- Official prompts often add a **PRODUCTION CONTROL** block: `MODE / TIMELINE (0–3s …; 3–7s …) / CAMERA: one primary movement per shot / TEXT LOCK / AUDIO / END FRAME / AVOID` — a compact QA layer on top of the prose [2].

---

## PART 2 — LTX-Video: prose, literal Gemma encoder, cuts named in sentences

LTX-2.x runs the prompt through a Gemma-based encoder that renders almost everything literally — tag lists die, prose lives [7-sd2][10].

### Single continuous take
- ONE flowing present-tense paragraph, **4–8 sentences** (~≤200 words for 6–10 s); match detail to shot scale (close-ups need more) [1][2][10].
- Camera described **relative to the subject**, with an **end-state**: "pushes in, settling on…", "comes to rest at…", "holds on…" [8][10].
- Transitions inside a single take = camera moves only (pan, push-in, orbit, handheld, over-the-shoulder) [1].
- Length reality: ≤10 s on most variants; **20 s only on Fast at 720p/1080p**; ltx-2.3-pro + audio-to-video reaches 20 s and is the only model with retake/extend/reframe [6].

### Multi-shot (LTX-2.5 native)
- **2–4 shots** per generation; more cuts need shorter, clearer beats [1][4].
- Write ONE chronological paragraph — **never a numbered shot list or bare sluglines**; a list reads as a list, not an edit, and is the #1 cause of broken-looking cuts [1][4][7].
- At EVERY cut do four things [1][2][4]:
  1. **Name the transition in prose**: "A hard cut transitions to…", "The view cuts to a close-up of…", "A match cut connects…", "The image dissolves into…".
  2. **Re-establish the new shot**: scale, angle, who/what is in frame, lighting if it changed.
  3. **Re-identify recurring subjects** by their visual details.
  4. **State audio continuity**: whether music/dialogue/ambience continues or changes.
- Keep one named light source and chronological time cues ("Initially…", "A moment later…", "Simultaneously…") [1][8].
- Screenplay format (INT./EXT. headers + character cues) is acceptable for 12–20 s or dialogue scenes; the slugline warning applies to multi-shot where cuts go undescribed [6].

### I2V / FLF2V
- I2V: prompt ONLY what changes — motion, camera, audio. Re-describing the image causes drift/morph [7][10].
- FLF2V: too-different frames + no connecting motion = jarring; name the intermediate changes [7].

### Adherence knobs
- Main action first, precise motion second, character/environment third, camera+lighting last; one main action per 2–3 s; `cfg_scale` = prompt grip, `stg_scale` = temporal coherence; when prose isn't enough, camera/IC-LoRAs provide structural anchoring [5].

---

## PART 3 — Head-to-head

| Concern | MiniMax H3 | LTX-Video 2.x |
|---|---|---|
| Cut syntax | `[Shot N] At 00:0X.000, the camera cuts to…` (timestamps, increasing) | Prose: "A hard cut transitions to…" (no lists) |
| Default transition | Hard cut; others only on request | Camera moves only; cuts must be named |
| Max shots | ~4 per 15 s (2–5 s each) | 2–4 per generation |
| Static shots | Must be stated explicitly ("no push in, no cuts") | "static frame", "locked-off" read well |
| First+last frame | No invented cuts; continuous path | FLF2V; name intermediate changes |
| Length | 5–15 s/clip, 7000 chars | ≤10 s typical, 20 s Fast; 5000-char API cap |
| Camera language | type + amplitude + speed in one sentence | cinematography terms + end-state |
| Audio across cuts | overall_soundscape bridges; per-shot sounds inline | must be stated at each cut |

---

## PART 4 — LoRAs

### MiniMax H3: open-weight with a real LoRA scene (corrected)
H3 weights ship publicly (MiniMaxAI/MiniMax-H3) with ComfyUI support (ComfyUI-MiniMaxH3, official LoraLoader PR #15353) — and Civitai hosts a growing H3 LoRA library:
- **Authentic Cinematic Texture** (TuTu_1018) — style, trigger `DY`, strength 0.7 (0.5 for high motion); kills the plastic AI look [1].
- **CinemaGrade** / **KreaLand** (hoodtronik) — style grades, trigger first (`cinemagradestyle` / `krealandstyle`), strength 1.0, ep35 softer / ep50 stronger [7][10].
- **Better Motion** (AdaptiveVision) — dual LTX+H3 motion LoRA, 0.4–0.8, no trigger; keep sentences short to avoid prompt bleeding [5].
- **Turbo LoRA** (larryvrh / LightX2V) — 4-step acceleration; pruned FL2VA-adapted variants for first+last-frame; combinable fixed-table math for multi-adapter stacks [4][6].
- **H3 Photoreal Image Gen** (JonXL) — trigger `ph0t0r34l`, 1.0 (1.5 Cicaloo workflow); H3 as a ≤3840×2176 still-image generator [3].
- Long-form: **H3 Continuum** chunked latent continuation (not a LoRA but the H3 answer to >15s films) [6].
Prompt compilers (NyckM's plan→compile_camera→subject_box) remain the camera-control layer on top.

### LTX-Video: three LoRA families [2-lora][9-lora][4-ic][5-ic]
| Family | Teaches | Dataset | Strength |
|---|---|---|---|
| **Style** | grade, texture, lighting mood, aesthetic | images fine | **0.6–0.8** (higher oversaturates) |
| **Motion / effect** | dolly-ins, rotations, transforms, fps feel | short coherent clips | **0.5–0.7** (>0.8 bleeds into unrelated content) |
| **IC-LoRA** | structural control: canny / depth / pose / union / inpainting / motion-track | paired video + control signal | **0.7–1.0** (default 1.0; 0.5–0.8 to soften; <1.0 can cause reference "pop") |

**IC-LoRA is the camera/motion answer for LTX** — ControlNet-for-video:
- **Depth** = camera movement & 3D geometry (pans, dollies, cranes, parallax) [5-ic].
- **Pose** (DWPose) = human performance transfer [5-ic].
- **Canny** = composition/silhouette preservation for stylized looks [5-ic].
- **CrossView** (Cseti) = re-shoot a scene from a new angle; fixed vocabulary: `crossview. new camera angle: {to the right|to the left|same angle}, {higher|lower|same height}, {closer|further}.` — strength 1.2–1.5 on distilled models [3-lora].
- **Rule of thumb**: when an IC-LoRA carries motion, the text prompt controls **style only** — writing "camera pans left" on top of a depth-IC reference creates conflicting instructions [5-ic]. One IC group at a time; match reference fps/res (25 fps standard); trigger phrases (DEBLUR, COLORIZE, ADD WATER…) go first [4-ic].

### Notable community LoRAs (Civitai / Lightricks hub) with triggers
| LoRA | Type | Trigger / usage |
|---|---|---|
| **H3** Authentic Cinematic Texture | style | `DY`, 0.7 (0.5 high motion) |
| **H3** CinemaGrade / KreaLand | style | `cinemagradestyle` / `krealandstyle` first, 1.0 |
| **H3** Better Motion (also LTX) | motion | none, 0.4–0.8 |
| **H3** Turbo (larryvrh/LightX2V) | accel | 4-step, pruned-FL2VA variants |
| **H3** Photoreal Image Gen | image | `ph0t0r34l`, 1.0–1.5 |
| LTX-2 Camera Control — Dolly In | motion | smooth cinematic push-in |
| 360-degree panoramic shot (LTX-2.3) | motion | panoramic sweep |
| 360 Equirectangular (burgstall) | motion | `360-equirectangular` |
| Bullet Time (melmass) | motion | `bullet-time` |
| Through Object (melmass) | motion | `through-object` (1000–2500 steps rec.) |
| Snorricam (Nebsh) | motion | `snorricam` (face-locked rig) |
| 60 FPS Buttery Smooth Motion (MisticRain69) | motion/fps | smoother temporal feel |
| PhysLTX — Better Physics (MisticRain69) | motion | physical plausibility |
| VBVR video-reasoning "H3 for LTX" (MisticRain69) | quality | I2V/T2V reasoning boost (58k downloads) |
| Cozy Felt / Fantasy Puppet / Pixar Toon / Claymation / Fantasy Anime / 90s Animation / Wild West / Cyberpunk | style | style phrases; 0.6–0.8 |
| Cinematic Post-Apocalyptic | style | `P0st4p0c0` + supporting phrases, 0.5–1.0 |
| Wallace & Gromit style (Cseti) | style | `walgro style`, 0.9–1.0 |
| Arcane Jinx (Cseti) | style | `csetiarcane, Nfj1nx, blue hair`, 0.6–0.9 |
| Whisper & Soft-Spoken Audio | audio | strength 1.0, natural-language manner "(woman, whispering)" |

Training defaults if you make your own: **rank 32**, images-only OK for style, short clips for motion, paired signals for IC [9-lora].

---

## PART 5 — encoded in this app
- `public/prompts/system-prompt.md` → H3 shot/cut/transition/camera rules (this doc, condensed).
- `public/prompts/ltx-system-prompt.md` → LTX single-take + 4-rule multi-shot cut grammar.
- Learn → 💡 Tips → cheat-cards for both + LoRA strength table.

## Sources
[1] https://minimaxh3.org/minimax-h3-prompt-guide · [2] https://minimax3.org/minimax-h3-prompt-guide · [3] https://www.atlascloud.ai/blog/tips/minimax-h3-prompt-guide · [4] https://www.inreels.ai/blog/minimax-h3-prompt-guide · [5] https://hackernoon.com/minimax-h3-prompt-guide-how-to-write-better-hailuo-30-video-prompts · [6] https://minimax3.com/prompts · [7] https://pixo.video/blog/minimax-h3-prompt-guide · [8] https://domoai.app/blog/minimax-h3-prompt-guide · [9] https://www.reddit.com/r/StableDiffusion/comments/1vfnby5/edited_guide_for_minimax_h3_prompt_structure/
LTX: [1] https://docs.ltx.io/api-documentation/implementation-guides/prompting-guide · [2] https://ltx.io/blog/ai-video-prompt-guide · [3] https://ltx.io/blog/prompting-guide-for-ltx-2 · [4] https://www.dreampixelforge.com/blog/ltx-prompts · [5] https://ltx.io/blog/how-to-improve-ltx-2-3-prompt-adherence · [6] https://prompt-architects.com/blog/262-ltx-2-3-prompt-templates-20-second-generations · [7] https://www.earngenix.com/tutorials/ltx-2-5-prompt-fix-comfyui · [8] https://www.film.fun/articles/ltx-2-prompting-guide · [10] https://ltx.io/blog/ltx-2-3-prompt-guide
LoRA: [2-lora] https://ltxworkflow.com/blog/ltx-2-3-lora-training-deep-dive-style-motion-ic-lora · [3-lora] https://huggingface.co/Cseti/LTX2.3-22B_IC-LoRA-CrossView-Prompt · [4-ic] https://docs.ltx.io/open-source-model/usage-guides/ic-lo-ra · [5-ic] https://ltx.io/blog/how-to-use-ic-lora-in-ltx-2 · [9-lora] https://wavespeed.ai/blog/posts/ltx-2-3-lora-training-guide-2026/ · hub https://huggingface.co/Lightricks/LTXV-LoRAs · https://civitai.com/ecosystems/ltxv

## PART 5 — IC-LoRA prompt contracts (the "very specific prompting" layer)
Each adapter trained on ONE caption convention; off-convention prompts degrade output. Compiled from official model cards:
- **Ingredients** (2.3 & 2.5): two labeled parts — `Reference sheet:` describing ONLY panels present with `**Top Row Left (Character):**` markers, then `Generated video:` driving the action. Sheet as static video ≥121 frames; 768×448×121@24 bucket; strength 1.0 (2.3: 1.4/guid 4.0/30 steps); neg "worst quality, inconsistent motion, blurry, jittery, distorted". Only sheet elements can appear.
- **Colorization**: `Reference shows {gray}. Edited shows the same scene with natural colors restored. COLORIZE {color}. Subject identity, framing, and background geometry are identical to the reference; only color information differs between reference and edited.` Same scene both halves.
- **Decompression**: same Reference/Edited scaffold with "heavily compressed with visible macroblocking, chroma bleed, and ringing artifacts" + `ENHANCE QUALITY {scene}` + "…only compression artifacts and image quality differ…". Compression only — not blur/noise/low-res.
- **Clean Plate**: prompt describes the DESIRED EMPTY scene ("An empty clean plate of the exact same location: … No people, no humans…"); named occluders as "no X anywhere in the frame" in BOTH positive and negative; partial/edge occluders work, center-fillers → masked inpainting.
- **In/Outpainting**: empty/minimal prompt suffices; guide ONLY the masked region; full-scene descriptions duplicate objects.
- **Relight**: `relight the video to match the light-direction ball. {look + direction}` — nothing else; exteriors only; caption must agree with the ball; single-stage at 2× target with skip-stage-2.
- **ReStyle** (Cseti): `Make it {style} style.` template; style still as frame 0; CFG 1.1–2.0 on non-distilled.
- **CrossView**: `crossview. new camera angle: {az}, {el}, {dist}.` — fixed vocabulary, synonyms unreliable; 1.2–1.5 on distilled.
- **Depth/Pose/Canny/Motion-track**: style-only prose; NO motion/camera verbs; attention_strength 0.6 = soft depth; spatial masks for foreground-only or 8-frame fade-ins; one IC group at a time; 25 fps reference standard.
The app's 🎛 IC protocol panel encodes every contract above as structured forms.
