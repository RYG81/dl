# The ornament-show refs — what two jewellery films taught the templates

_Two Pinterest refs studied 2026-09-28 · both analysed frame by frame, cut times measured with
`ffmpeg` scene detection. Source files kept in `refs/study-2026-09-28/` (the two clips + contact sheets)._

## The two refs

**Ref A — the yellow bridal show** (28.9s · 720×1280 · 25fps). A marigold/haldi-yellow silk lehenga
with dense gold-thread and crystal embroidery, gold jhumkas, a nath, stacked bangles, blush-gold
makeup, and a **ground that is a single wall of repeating carved medallions** (dark wood ovals with
hand-painted rose, ochre and ivory discs). The dupatta is drawn overhead as a **hood** for the
full-length beats. Cut times: `5.92 · 6.84 · 10.04 · 10.92 · 20.20 · 23.80 · 24.24 · 24.64 · 25.00 ·
25.56 · 26.08 · 26.48` — i.e. **long held stretches** (0–5.9s, 11–20.2s) and then a fast tail of
~0.5s cuts. The two full-length beats (≈8.4s and ≈22.0s) are **the same shot**: the same walk, the
same wall, the same held frame repeated — a deliberate bookend. At 10.4s the transition **dissolves
through the sheer veil**, the net going translucent over a double exposure.

**Ref B — the fine-jewellery campaign** (20.1s · 720×1280 · 25fps). Ivory-white embroidered blouse
with pearl and sequin band work, grey-silver skirt, **uncut polki with rose-pink drops over pearl
strands**. Cut times: `3.08 · 5.52 · 7.12 · 8.92 · 11.12 · 13.04 · 14.80 · 16.12` — **eight cuts,
most of them exactly 1.0s apart**, with the opening and closing shots longer. One piece per cut:
choker → jhumkas + midriff → bangle stack → ring (hand up, face behind) → neck and pendant → jhumka
profile → ring at the temple → the look and the wordmark.

## What the refs prove (and what our old jewellery templates did instead)

**1 · The cut changes the scale, not the camera.** In ref B the frame size moves four times — from a
mid shot to a ring close-up, back to the jewellery line, in to the neck, back out — and **the camera
never travels inside a shot**. Every scale change arrives *with a cut*. The proof is the cut rhythm:
eight cuts at almost exactly a second. Our ref-derived jewellery templates did the opposite — the
`Bridal jewellery show` measured **11 camera moves, 0 by the subject** — a travelling lens over a
standing woman, which is why it read as a slideshow of framings.

**2 · A tight beat is still a shot of her.** Ref B's ring close-up has her **face in frame and softly
out of focus** behind the hand; the earring beat carries the jaw, the hand and the line of the neck;
the choker beat carries the chin and the collarbone. There is **no frame in the entire film with an
ornament and nobody in it** — which is exactly the law we had already written library-wide (no
bare-ornament macros) and the thing the old macro ladder kept violating.

**3 · The hand does the work.** Every jewellery beat in ref B has her own hand in it — fingers at the
earring, the hand rising in front of the face for the ring, a hand crossing to the opposite wrist.
The hand is what gives the piece context and the beat its motion; without it a close-up is a still.

**4 · The wide reset.** Ref B never runs more than three tight beats in a row: after the ring and the
bangles, a mid shot of her face and midriff brings the whole look back before the film goes tight
again. That reset is the reason the tight beats stay legible instead of becoming a texture.

**5 · Held frames are allowed — if they are alive.** Ref A holds full-length stillness against the
wall for six seconds at a time, and it works because the frame is never dead: breath, a blink, the
veil edge moving, the light travelling on the gold, the jewellery settling. Ref A's bookend (the same
walk shot at the top and the end) and its veil-dissolve are its two structural devices.

**6 · Two registers, one grammar.** A: yellow silk, a repeating carved wall, held frames, the veil as
a hood. B: ivory and pearl, polki and rose, flat one-second cuts, the hand at the piece. Different
looks, same four laws.

## What shipped

`public/prompts/templates/ornament-shows.md` — two templates:

- **💎 Heirloom jewellery show — one piece per cut, her face in every frame** (20s · 9:16 · 2K · auto ·
  6 flows · 7 varying dimensions). The ref-B register as a template: the camera locked inside every
  shot with the scale changed only by the cut, one presentation per cut at about a second, the hand on
  the piece in every beat, the wide reset after three tight beats, and a close that comes back to a
  **mid-close of the whole look rather than the tightest macro**. A **brand wordmark is optional** —
  named exactly as it must be spelled, held once over the close, with no other lettering anywhere.
- **🧵 Palette-wall bridal show — she holds the frame, the cut changes the scale** (16s · 9:16 · 768P ·
  auto · 6 flows · 7 varying dimensions). The ref-A register: one carved repeating wall as the whole
  world, marigold-yellow lehenga, the veil hooded, full-length held frames that carry one second of
  visible life each, the walk frame as the reset, and the **veil-by** — the sheer net drawn across the
  light so the frame reads through it, which is the ref's own dissolve.

Both carry the tour-grammar fundamentals (locked lens, live-clock timing, flow libraries that re-order
named beats and never add one, closed stack, innerwear-where-seen, colour always stated) plus the two
new laws this study produced: **scale by cut** and **the wide reset**.

**Pools:** `ORNAMENT SET` gained option 10 (**polki and rose** — the campaign's exact set: broad
uncut-polki choker with rose drops over two pearl strands, tiered polki-and-pearl jhumkas, a rose-stone
statement ring), and `STUDIO GROUND` gained option 9 (**the carved-medallion wall**).

**Audit:** 145 templates · **0 ERROR · 2 WARN** — and for the first time both remaining warnings are
formats where camera travel is the format itself (a 4-up e-commerce collage and a labelled 3D classroom
explainer). The audit now demotes a superseded template's camera-travel note from WARN to INFO once its
description names the rebuild, so the WARN list keeps meaning "nobody has looked at this yet".

**Judging the next output:** if the jewellery film ever pushes in, or shows a piece with nobody in the
frame, or runs four tight shots without a reset — say so, and that flow gets tightened.

## Field report — the first outputs, and the three defects they exposed

The first generations from these templates came back with three faults, reported verbatim as:
**"walking is like jumping"**, **"mostly showing back view"**, **"beats are not as the ref"**. All three
were in our instructions, not in the model, and all three are now laws.

**1 · "Walking is like jumping."** Our entrances asked her to cross a distance inside one beat —
*"she walks in from the ground's depth"*, *"she crosses the wall at full length"*, *"walks in from the
room's depth"*. A distance the model cannot animate smoothly inside 1–2 seconds is rendered as a hop,
a glide or a teleport, and there is no ground language to hold it: no floor, no step count, no weight.
**The law now:** a walk is **two to four steps**, named as steps, at about one step a second — never a
crossing. Name the floor, the **heel-then-toe** contact and the weight passing foot to foot; **both
feet are never off the floor at once**; keep the **floor and her feet in frame**; give the walk **its
own beat of at least two seconds**; and let **the cut land on her stop, never mid-stride**.

**2 · She was relocating between cuts.** With the camera pinned, a subject who appears somewhere new
after every cut reads as a jump *even when each shot is perfect* — the cut becomes a teleport instead
of a change of scale. **The law now: the mark is continuous.** The walk happens once, in the opening
beat; every later shot finds her on the same mark, and the cuts change scale, angle and action only.
A second position has to be earned by showing the steps, or by cutting to her already settled.

**3 · "Mostly showing back view."** Two causes: every back beat was written as *"she turns through a
full back view"* — an open-ended turn is an invitation to finish the film behind her — and two flow
libraries literally opened on her back (`BACK FIRST = she enters already turned away`). **The law now:
the film is face-forward.** At most **one** beat shows her from behind, about a second, and only when
the idea names what is read there (the ties, the nape, the veil's drape, the low bun); it is written as
**three-quarters away and back inside the same beat**; and the first and last shots are toward the lens.
`BACK FIRST` is gone from the library — replaced by `SHOULDER FIRST`, which enters at three-quarters
and turns full-face inside the first beat.

**Two more culprits found by the new audit check.** The **ACTION pool** — drawn by every varying fashion
template — was offering *"walking a straight line toward the lens"* (a distance) and *"turning away and
walking out of frame, then glancing back over the far shoulder"* (both faults in one option). Both were
rewritten to the grounded form. And the older **beach walk-in**, **room-showcase**, **mirror walk** and
**heritage doorway threshold** entrances carried the same distance phrasing; all four were corrected.
**Room outfit tour was not touched** — it is the benchmark, and its walk and its single back beat are
the ones that work; the law caps the back view rather than banning it.

**4 · "Beats are not as the ref."** Correct: the bridal show was missing the ref's two signature beats
and had invented three it does not contain. Rebuilt to the ref's actual inventory: the walk · the hold ·
**the veil drawn down across her face so the whole frame reads through the net** · **the veil spread
overhead as a canopy** · the face · **the hand on the cuff (the detail insert, never a bare ornament)** ·
the bangle · the waist · the three-quarter turn · the look — plus a **BOOKEND** flow that repeats the
opening full-length frame near the end, which is what the reference itself does.

**Where the fix lives:** the doctrine went into `public/prompts/packs/fashion.md` (**"Motion — the walk
is a walk, and the mark is continuous"**), so every fashion and bridal generation inherits it rather
than nine templates repeating it. The audit gained a **WALK RISK** check — any entrance in a film with
a wearer in it that asks her to cross a distance — and a count of back-view beats; suite section 19
pins all of it, including that the counter that measures "who causes the scale change" understands the
new phrasing.
