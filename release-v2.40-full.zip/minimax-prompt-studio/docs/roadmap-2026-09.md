# Roadmap — what to build next (planned 2026-09-20)

Research basis: `docs/research-2026-09-ecosystem.md`. Add-on numbers continue from 59.
Each entry: what → why (research hook) → rough effort. Priority P0 = build next.

---

## P0 — high leverage, extends what we already have

### Add-on 60 · 👤 Character Bibles (identity cards) — ✅ SHIPPED 2026-09-20
A **Characters** section in the builder + a character registry for chains.
- Card fields: name, canonical reference image (attach to refs), 5–7 attributes,
  **2–3 signature anchors** (repeated verbatim in every prompt), wardrobe variants, voice notes.
- Chain integration: bible injects the identity block into every scene; scenes describe ONLY
  action/camera (research: re-describing identity is the #1 drift cause).
- Anchor-shot planner: flag establishing shots, generate-first order, frame-inheritance reminders.
- Batch-by-location suggestion when auto-planning.
- Why: consistency is THE unsolved pain point in 2026 tooling; our chain already carries a
  world-bible — identity cards are the missing layer.
- Effort: M (new section + chain injection + guide section).

### Add-on 61 · 🔊 Audio-native sound design — ✅ SHIPPED 2026-09-20
Both H3 and LTX now generate **synchronized audio in one pass** — our Sound section is under-using it.
- Upgrade Sound to per-beat audio design: dialogue lines with delivery, foley cues per action,
  music beats aligned to shot boundaries, ambient bed.
- H3 **audio references** (voice/music clips) as a new ref job type.
- LTX **Audio-to-video** workflow type: attach an audio track as the driver.
- System-prompt grammar addition: `audio:` spec inside [Shot N] blocks.
- Effort: M (form + two system prompts + offline composer).

### Add-on 62 · 🖼️ Omni-reference upgrade
Match H3's exact reference schema: up to 9 images + 3 videos + 3 audio clips (12 total).
- Role picker per asset: style / character / motion / voice / first-frame / last-frame / location.
- Budget meter (9/3/3/12) with warnings; role-aware captioning from vision reads.
- Ref2VA vs FL2VA checkpoint guidance in tips.
- Effort: S–M.

### Add-on 63 · 🧪 Prompt Critic — score & enhance — ✅ SHIPPED 2026-09-20
Market standard (Promptessor, Adobe Enhance) adapted to OUR grammar.
- Score each generated card 0–100 across: clarity, camera grammar, continuity, audio direction,
  placeholder hygiene, duration-pacing fit, corpus conformance — via our own local LLM.
- One-click **✨ Enhance** pass that rewrites weak spots while preserving structure.
- Works offline: heuristic score (cheap) + optional LLM critique (deep).
- Effort: M.

## P1 — strong value, slightly bigger

### Add-on 64 · 🔗 Chain → LTX native multishot — ✅ SHIPPED 2026-09-20 as CONVERTER (per user direction: per-scene chain stays the default, 🎞️ button collapses a planned chain into one LTX-2.5 multishot prompt; offline sketch fallback)
LTX-2.5 can emit multiple connected shots in ONE generation. Offer a chain output mode:
"separate clips" (today) vs "native multishot" (one 10–20 s prompt with per-shot lines,
identity/lighting continuity clauses). Shot-budget rules update per target.
Effort: M.

### Add-on 65 · 🎞️ Video-to-prompt
Upload a clip → sample frames (we have the ffmpeg recipe) → vision describes per-frame →
rebuild as H3 or LTX prompt (with shot detection heuristics). Natural sibling of add-on 43.
Effort: M.

### Add-on 66 · ♻️ Retake / Extend workflows
New workflow types for LTX-2.5: RETAKE (describe the time region + what changes, everything
else preserved) and EXTEND (continue from last frame). Prompt grammar + form switch.
Effort: S.

### Add-on 67 · 🎬 Transition planner
Per-cut transition field in chains: hard cut / cut-on-motion / whip pan / dissolve (+1 s padding
advice) / match cut. Planner auto-suggests transitions from beat types; guidance travels into prompts.
Effort: S.

## P2 — polish & expansion

### Add-on 68 · ⚖️ Variant A/B lab — LLM-as-judge scoring of variants, diff view, pick-a-winner
flow, judged against our quality bar. Version history per idea. Effort: M.
### Add-on 69 · 💰 Cost estimator — hosted render estimate in Format section (H3 $0.08–0.13/s,
LTX $0.09–0.30/s by resolution). Effort: XS.
### Add-on 70 · ⏱️ Auto Duration — "let the model decide" duration option emitting LTX
auto-duration phrasing instead of fixed seconds. Effort: XS.
### Add-on 71 · ✂️ Instruction-editing mode — H3's edit grammar: source video + instruction
prompt ("remove the rig", "make it golden hour"). Effort: S.
### Add-on 72 · 📚 Grammar updates — LTX guidance to Gemma 4 encoder facts + prompt-enhancer
awareness + distilled-model recommendation; guide & tips refresh from llm-info page. Effort: S.
### Add-on 73 · 📜 License footnotes — H3 open-weights territory exclusions (US/EU/UK/KR) and
LTX $10M-ARR note in the guide's files section. Effort: XS.

---

## Explicitly NOT proposed (checked & parked)
- ComfyUI execution/submit from the app — user declined (2026-09-20).
- Cloud render orchestration — outside local-first mission.

## Suggested build order
60 (characters) → 61 (audio) → 63 (critic) → 62 (omni-refs) → 64 (multishot) → 67 (transitions)…
60+61 together make chains produce genuinely film-grade prompt packages; 63 closes the loop by
measuring them.
