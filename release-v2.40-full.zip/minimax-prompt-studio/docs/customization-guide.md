# Customization guide — system prompts, templates, presets, LoRAs

Everything the generator knows lives in **external Markdown files** under
`public/prompts/`. Edit them in any text editor — **no code changes, no rebuild**.
The app re-reads them on every page load (in dev, just refresh the tab).

| File | What it controls |
|---|---|
| `prompts/system-prompt.md` | SFW system message for **H3 (MiniMax)** |
| `prompts/ltx-system-prompt.md` | SFW system message for **LTX-Video** |
| `prompts/system-prompt-mature.md` | 18+ system message for H3 (used only when mature is enabled) |
| `prompts/ltx-system-prompt-mature.md` | 18+ system message for LTX (used only when mature is enabled) |
| `prompts/templates.md` | 📐 Template guides **and** ⚡ presets |
| `prompts/loras.md` | 🧬 LoRA library (builder chips + Learn tab) |
| `prompts/chain-planner.md` | The auto-planner that writes story-chain bibles/scenes |

---

## 1. Your own system prompt

Open `prompts/system-prompt.md` (H3) or `prompts/ltx-system-prompt.md` (LTX) and
edit freely. The whole file becomes the `system` message. Rules of thumb that keep
output quality high:

- Keep the **output contract** intact: H3 returns the three labeled fields
  (`integrated_multimodal_description:` / `overall_soundscape:` / `non_diegetic_music:`);
  LTX returns one JSON object `{"title","prompt","negative_prompt","tags"}`.
- Add your own sections anywhere — brand voice, banned words, house style, lighting
  vocabulary. The app appends its own request details (idea, duration, camera…) after it.
- If the file is missing or empty the app falls back to a built-in prompt, so you can't brick it.

## 1b. Blocking mature content (kill switch)

Mature prompts are **completely separate files** and nothing mature ever flows through the SFW prompts.
- **Soft block**: delete or empty `prompts/system-prompt-mature.md` and `prompts/ltx-system-prompt-mature.md` — the app falls back to the SFW prompts automatically (blocked by omission).
- **Hard block**: run `cpsNsfw.block()` in the browser console (or set localStorage `cps_nsfw_blocked` = `"1"`): the 🔞 toggle is disabled, the mature directive is stripped, and every generation uses the SFW prompts. `cpsNsfw.allow()` reverses it; `cpsNsfw.status()` reports the state.

## 1c. Domain craft packs (🧠 one brain per video type)

The system prompt is **two layers**: the base prompt above (universal grammar — output contract,
shot design, consistency, timing, audio) plus **at most two domain craft packs** appended at
generation time. A pack holds the craft that only applies to one kind of video, so garment
vocabulary can no longer leak into a product, portrait or animation prompt.

- Files live in **`public/prompts/packs/`** and are scanned live, exactly like templates: drop a
  `.md` in, refresh, it appears in the picker. `user-*.md` overrides a built-in with the same
  `pack:` id. Shipped: fashion · ethnic/bridal · social/UGC · product · dialogue · cinematic ·
  documentary · nature · food · animals · vehicles · spaces · animation · music · portrait · sport.
- **Routing order:** picker pick (`Auto` by default) → template tag → category → idea keywords
  (each pack declares its own `keywords:` list). Mode tags (`person`, `preset`, `vertical`,
  `longvideo`, `multi`, `mature`) never vote. Two packs stack only when one declares
  `stack-with:` the other — e.g. a phone-shot try-on gets 👗 fashion + 📱 social.
- **Picker:** Scene section → `🧠 Prompt pack` (Auto / one pack / Base prompt only). The line under
  it shows the live resolution and the reason. Generated cards badge the packs used; the console
  logs `prompt packs: … — template tag "fashion" (+3900 chars)`.
- **Story chain:** every scene resolves against *its own* 📐 template, so a chain can mix domains.
- **Mode blocks:** wrap mode-specific craft in `[[MODE perform]] … [[MODE camplay]] … [[/MODE]]`
  and only the active block is sent — that is how the 🧍/🎥 fashion camera modes work now.
- Pack format, header keys and a template are documented in `public/prompts/packs/README.md`.

### 2 · Template craft rules (advisory, enforced softly)

1. **A beat grammar, not a shot list** — the beat order should lift other ideas too.
2. **Placeholders are decisions, with guidance.** Write them as `{TOKEN — what to name}`.
   The builder labels the field with `TOKEN`, shows the guidance as the field hint, and passes it
   to ✨ Suggest values. *(Tokens longer than 120 characters stop being fields — the linter warns.)*
3. **A pacing contract** — `TIMING: 8s total — …` or a beat budget ("one beat per second").
4. **Conditional beats** — *"use this beat only if X is named; never invent one"* — the beat list
   then adapts to the idea instead of replaying the same order.
5. **Flows** where the architecture can vary (see 2a).
6. **≤8 placeholders is the soft target.** 9–12 is fine; 12+ means merge tokens that are always
   decided together, or split the template. *Nothing is ever blocked by this* — `npm run audit`
   and the 🧪 linter just tell you where merging pays off.

**The 🧪 linter** runs on every forged and edited block (Forge + Template Manager) and prints the
same checks as `npm run audit`: format labels · pacing · placeholder count and guidance coverage ·
conditional beats · flows · description · near-duplicate vs your library (word-overlap ≥72% warns).
It is advisory: the parser alone decides whether a block is valid.

**Saving a template permanently:** ⬇️ **Save as user-*.md** in the Forge, or 📤 Export in the
Manager. Drop the file into `public/prompts/templates/` — that folder is scanned live and
`user-*.md` files are never overwritten by app updates.

### 2a. Dynamic templates — adaptive beats + beat flows

Two things can be dynamic inside one template:

- **Beats** — write them conditionally: *"use this beat only if the detail is named in the idea;
  skip it otherwise and never invent a feature."* The beat list then composes itself from the user's
  own words. This is how `Room outfit tour — adaptive beats` works.
- **Flow** — the beat *architecture*. Declare named flows in the block header:

  ```
  flows: TOP-DOWN TOUR | REVERSE REVEAL | DETAIL CASCADE
  ```

  and describe each one inside the skeleton in a `FLOW LIBRARY` paragraph (obey a named
  `BEAT FLOW` first, otherwise choose from the subject). The app then rotates flows: **variant 1/2/3
  → flow 1/2/3**, **chain scene N → flow N**, and repeated single-variant generations walk the list.
  The request carries `BEAT FLOW: "<name>"`, the card shows `🎼 <name>`, the template card shows
  `🎼 N flows`.

Cut-shot templates (💎 jewellery set, UGC demo, dish story, space reveal) build their inserts the
same way: **one cut per named piece/feature**, cut on the glint, the click or the beat — unnamed
ones get no cut. See `docs/dynamic-templates.md` for the full shipped list and the authoring recipe.

## 2. Templates (📐 Template guides)

Append blocks to `prompts/templates.md`. Exact format the parser requires:

```markdown
## My template name
tag: fashion
description: One line shown in the picker.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 6
music: beat
structure: single
camera: Auto
idea: One-line idea with {PLACEHOLDERS} the user fills in.

```
integrated_multimodal_description: The beat skeleton — {PLACEHOLDERS} here too…

overall_soundscape: …

non_diegetic_music: …
```
```

Hard requirements:
- Block starts with `## ` — the title becomes the picker label.
- The fenced skeleton **must contain `integrated_multimodal_description`** or the block is skipped.
- `{PLACEHOLDER}` tokens (2–48 chars, no braces inside) become fillable 🧩 fields in the builder.

Optional meta keys (all `key: value` lines): `tag` (fashion / person / product / landscape /
animation / dialogue / multi / vertical / music / longvideo), `loop: true`,
`keyframes: true`, `dialogue: a default line`, `workflow: t2v|i2v|fflf|multiref`,
`music: auto|none|subtle|full|beat`, `structure: single|multi2|multi3`,
`amp`, `speed`, `palette`.

## 3. Presets (⚡ one-click bundles)

Same file — add a template block and mark it a preset:

```markdown
## ☀️ Morning routine vlog
preset: true
tag: vertical
tip: Shown as the toast when loaded.
idea: …
ratio: 9:16
…same keys as above…
```

Presets appear in the ⚡ Presets menu with their idea + settings + tip.

## 4. LoRAs (🧬 library)

Append to `prompts/loras.md`:

```markdown
## My LoRA name
model: ltx
type: style
trigger: mytriggerword
strength: 0.8
description: What it does and how to use it.
```

`model:` = `h3` or `ltx` (controls which target's chip list shows it). Armed LoRAs
stamp their trigger line onto generated prompts automatically.

## 5. Testing your edits

1. Save the file → refresh the app tab (dev server serves `public/` fresh each load).
2. Learn → Templates/LoRAs tabs show the new entries immediately.
3. For system prompts: generate one variant and watch the **CPS OLLAMA ↑** console
   group — your text should be the `[0] SYSTEM` message.

## Wardrobe lines: `prompts/fashion-outfit-expander.md`

The one-line outfit expander (originally the user's own fashion prompt, rebuilt in the studio's style).
It keeps the contract that matters — **exactly one line, nothing else**, no angle brackets, 100% of the
user's brief preserved and never reinterpreted — and adds what a line usually lacks:

- construction vocabulary in place of adjectives (`flowy` → *bias-cut silk crepe, 22-momme, hem swinging
  15 cm past the hip*), with a banished-word table;
- legal labels by structure: `Main:` for one-piece, `Top:`/`Bottom:` for two-piece, `Inner:`/`Outer:` for
  layering, `Bodice:`/`Skirt:`, `Base:`/`Overlay:`, `Harness:`/`Lingerie:`; traditional dress keeps its
  own names (`Choli:`/`Ghagra:`/`Dupatta:`, sari with drape logic);
- a three-colour palette discipline (60/30/10 + one metal), an executable era table (1920s → 2030s with
  construction markers, not moods), seven-part footwear, intimate wear kept true to category;
- a byte-stable re-call name per outfit ("the ivory slub-silk column") so the same garment survives a
  whole shoot or chain, variation by axis rather than randomness, and a ten-point self-check the model
  must pass before it emits.

Three ways to use it: **👗 Expand outfit** in the 🧩 Fill-the-blanks dialog (fills `{OUTFIT DESIGN}`
directly), a routing slot pointed at it in ⚙️ Settings, or 🧩 attach it to any generation.

## Colour: how the accidental-white bug worked, and what replaced it

The garment placeholder used to read *"the garment: silhouette, fabric, construction detail"*. No colour was ever
requested, so the model fell back to its own default — white — and four of the fashion exemplars used as few-shot
knowledge reinforced it. Four fixes now stand between a brief and a white outfit:

1. **A live field.** `{OUTFIT COLOUR}` sits on every fashion template (all 15 of them), and it is a 🔀 varying
   dimension in the showcase templates — so variants rotate colour families, not just silhouettes.
2. **A pool of 12 families** in `public/prompts/fashion-variation.md` (`## OUTFIT COLOUR`), each naming its colours
   *and* its finish — oxblood with ivory trim on matte wool, cobalt with a liquid satin face, mustard ochre on
   handloom texture, and so on.
3. **A doctrine** in `public/prompts/packs/fashion.md` (`## Colour — the garment carries one, always`): name colour
   and finish together; **never** default to white, ivory, cream or beige; three colours maximum with 60/30/10 areas
   and one metal family; state where each colour sits (body, trim, lining, hardware, footwear); say how the room's
   light changes it; prefer saturated mid-tones at 2K and give white texture if white is genuinely wanted; rotate
   colour across variants.
4. **Rebalanced exemplars.** The ivory knit and the ivory coat are now tobacco-brown and tomato-red; two
   white-anchored exemplars remain (an explicitly requested white sundress and a white-tee layering shot), which is
   the right level of white for a library that teaches by example.

The outfit expander already carried a 60/30/10 palette rule; it now also refuses to emit a colourless line.

## Immersive templates: the two 360/VR180 LoRAs

`public/prompts/templates/immersive.md` (tag `immersive`, routed to `packs/medical.md`, which carries the projection
rules) ships two templates, each written around its LoRA's own evaluated settings — **21:9 · 768P · 5s, prompt
expansion off**:

- **Equirectangular 360 — sphere tour** — `shamanic/minimax-h3-equi360-lora` (reviewed v2), trigger `equirect360`
  followed by the official layout sentence, which the template writes verbatim. The craft is all about the
  projection: nothing may straddle the wrap seam, detail stays out of the polar bands (zenith and nadir) where the
  sphere stretches hardest, light must come from more than one direction, the horizon never tilts, and there are no
  cuts. Post: resize the 21:9 frame to 2:1 and add mono-360 spherical metadata — resize only, never crop.
- **VR180 stereo pair — immersive walk** — `EllipsesMark/minimax-h3-vr180-sbs-lora` (on fal:
  `rehan-fal/minimax-h3-vr180-sbs-lora`), trigger `vr180sbs` + layout sentence. Stereo discipline: one continuous
  take, slow moves only (fast pans drift between the eyes), subject held roughly 1.5–4 m away, nothing crossing the
  half-metre in front of the lens, one subject rather than a crowd, a deliberate near/mid/far depth stack, and **no
  on-screen text at all** because the two eyes disagree on it. Stay on the `minimax/h3` route — the 8-step
  `h3-max` LoRA route degrades the pair. Post: the ffmpeg + `spatialmedia -s left-right` command is in the template's
  tip line, ready to copy.

Both LoRAs are in `public/prompts/loras.md` with their trigger words, so selecting them in the builder prepends the
trigger for a local run.

## Medical & science animation

`public/prompts/templates/medical-education.md` (tag `medical`) with `public/prompts/packs/medical.md`:

| template | what it is for |
|---|---|
| **MOA film — mechanism of action** | pharmaceutical-grade cinematic explainer: target → contact → cascade → outcome, one scale logic, no gore, no text |
| **Disease-state journey — inside the body** | one anchor view returned to honestly, states distinguishable by more than colour, patient-safe |
| **Classroom concept explainer — labelled 3D** | the Designmate / Eureka.in teaching format: bright even studio light, one idea per beat, exploded or part-by-part moves, at most three short labels |
| **Hybrid explainer — real footage + 3D inserts** | the evidence-backed format: real hands and real light, cut against 3D inserts that match angle, light direction and distance across the cut |

The pack enforces the rules that make or break this genre: a mechanism written as a **physical event** (what touches
what, in what order, what visibly changes), plausible anatomy at a declared scale, no invented named structures, no
gore, consistent flow direction, plausible sound (no library whooshes), text allowed only in the labelled classroom
format and capped at three labels, and an explicit note that medical content is illustration, not advice.

## Rearranging a chain

| where | controls |
|---|---|
| **Templates page → 🔗 Chain mode** | `◀` `▶` move a picked scene one step · `⇤` `⇥` send it to the front or the back · `✕` remove · `⇅` reverse the whole chain |
| **Builder → chain planner** | `↑` `↓` on every scene row (ends disabled); the scene you were Directing stays selected after a move |

Both use the same splice-move operation, so scene numbering, the per-scene template column and the
*previous scene's end state* hand-off all follow the new order — before or after generating.

## Colour, completed (v2.5)

The first pass only fixed `{OUTFIT DESIGN}`; the library also names garments through `{GARMENT}`,
`{DRESS}`, `{SKIRT}`, `{TOP}`, `{BOTTOM}`, `{LEHENGA}`, `{ETHNIC SET}`, `{OUTFIT}` and bare `{GARMENT}`
in **30+ templates** — all of which asked for fabric and cut and never a colour. Now:

- every garment-named placeholder carries **colour and finish** (or sits in a block that names a colour),
  and the selftest sweeps the whole library for it with a 30-word colour vocabulary;
- the **instant engine** (no LLM) has a 12-family wardrobe bank: a fashion idea with no colour word gets a
  named colour family, a fashion idea that *does* name one is untouched, and non-wardrobe scenes never get one.

## Medical & science animation — six templates

MOA film · disease-state journey · classroom labelled explainer (Designmate/Eureka.in) · hybrid
real-footage + 3D inserts (Hybrid Medical Animation) · **physiology cycle loop** (last frame = first frame,
every displacement returns, one-way flow forbidden) · **patient-education short** (9:16, calm by
instruction, one takeaway, phone-safe framing, one caption at most, narration declared as on-camera or
off-screen voiceover).

## Changing template — what happens to the form (v2.6)

Attaching a template runs **one** function (`switchTemplate` in `src/lib/templates.js`), used by the picker, the Templates page,
a chain scene's Direct button and every imported bundle:

| the template brings | the previous template's leftovers |
|---|---|
| its pinned `ratio · resolution · duration · structure · camera · music` land in the Studio immediately | 🧩 field values are pruned: a value survives only if its token still exists in the new skeleton or in your idea |
| its own idea line is adopted **only when the idea box is empty** | everything else is cleared and counted in the toast — never silently re-used |
| the toast says what changed: `📐 … attached — 16:9 · 2K · 10s · 3 shots · 3 🧩 field(s) kept · 🧹 cleared 4 field(s)` | your written idea is never wiped |

## Duration — the clock (v2.6)

`src/lib/duration.js` is the single source of runtime truth. `shotClock(duration, structure, loop)` returns the shot count, every cut
time and every window; `clockLineH3` / `clockLineLtx` turn that into the contract inside the user message. Every other path uses the
same helper — the instant engine, the linter, the audit and the self-test — so they cannot disagree.

* **Structure decides the shots** — 1 / 2 / 3, and a `loop: true` template is always one take. Shots are spread evenly and can never
  fall below **1.5s** (5s × 3 shots = 1.67s each).
* **The runtime is stated in the prompt text** — the opening sentence must carry it, so the text and the generator's duration agree.
* **Skeletons are examples, the clock wins** — a template pinned at 10s cannot force 10s cuts into a 6s clip; the Duration row offers
  **📐 use 10s** to match the template in one click instead.
* **The audit checks the prompt back**: timecodes inside the window, last shot ≥ 1.5s, shot count matching the structure, each spoken
  line short enough for its own shot at ~4 words/s, the runtime stated, and a wardrobe that does not contradict itself
  ("wearing a wool coat" + "fully nude" is flagged).
* **Linting a template** warns when its hardcoded example cut times leave less than 1.5s of its own pinned runtime.

## Templates in subfolders (v2.7)

The template library is scanned **recursively** — `public/prompts/templates/` and every folder inside it:

```
public/prompts/templates/
  core.md                        ← built-ins (replaced by updates)
  starter/subfolder-demo.md      ← shipped proof that nesting works
  bridal-2026/sangeet.md         ← your folder tree
  client-acme/looks/hero.md      ← up to 4 folder levels
```

* The scan (`scripts/templatescan.mjs`, one implementation shared by the dev server, the build, the audit and the self-test)
  returns **relative paths**; the app fetches `prompts/templates/<folder>/<file>.md` and stamps
  `file / folder / src` on every parsed block.
* `_index.json` (dev server **and** `dist/`) now lists nested paths, `_folders.json` lists the folders, and each folder gets
  its own `_index.json` so a plain static host can resolve a tree without a rebuild.
* The picker and the Templates page gain a **folder filter** (`📁 All folders (3)`), every card shows `📁 folder`, and the
  folder name is searchable. `README.md` and files starting with `_` are skipped at every depth.
* **Subfolders are yours.** `DEFAULT_PROTECTED` carries `public/prompts/templates/*/*` (one level) and
  `public/prompts/templates/*/*/**` (anything deeper) plus `**/user-*.md`, so an update can never replace, move or flatten
  a tree you built — it only ever writes files into the **root** of that folder.
* Depth cap: 4 folder levels. A file deeper than that is ignored (and logged by the audit, which prints
  `Subfolders scanned: N`).

## The studio family, rebuilt to the room-tour standard (v2.17)

The report: *"not happy with the templates for studio, my video were much better. we did not reach the same level we had with room clothing tour template."*

The comparison was fair. Measured against **Room outfit tour — adaptive beats**, the studio block was thin:

| | Room outfit tour | Quiet-luxury studio (before) |
|---|---|---|
| beats | adaptive — every garment detail you name becomes a beat, `OPEN` first, `CLOSE` last, skip what is not named, never invent a detail | three prose options: standing, a close detail, a seat/turn |
| flows | 6, each defined in the skeleton | 4, named but not defined |
| vary dimensions | dynamic details, room, footwear | 5 |
| palette | whatever the idea names | the template *forced* cream, which is why the two saturated refs never fitted it |

**What v2.17 ships**

| block | what changed |
|---|---|
| **📱 Quiet-luxury studio — every detail a beat** | rebuilt on the room-tour engine: *never a fixed sequence*, composed only from the details actually named (`CUFF AND SLEEVE · PLACKET AND FRONT · SEAM AND STITCHING · WAISTBAND AND BELT · POCKET AND HAND · SHOULDER AND COLLAR · HEM · RIB OR WEAVE · LINING AND BACK`), with `OPEN` first, `CLOSE` last, one act of 1–1.5s per beat, the two-details rule and the never-invent ban. Six flows, each defined: `STILL THEN DETAIL · DETAIL THEN FULL · HAND IN POCKET · SIT AND SETTLE · SEAM CASCADE · LIGHT RAKE`. **Nine live dimensions** (garment set, tone family, texture, model, light, set surface, movement, outfit interaction, camera) and **the palette is a live field** — cream/sand is one option now, so the saturated refs belong here too. 2K. |
| **📱 Hard-sun studio — shadow play, saturated palette** | new, for the two refs that had been shoehorned into the cream template (the denim bralette in hard sun with terracotta pots, and the block-print dress on concrete). Same adaptive engine, its own details (`PRINT AND REPEAT · LACE AND EDGE · STRAP AND SHOULDER · WAISTBAND · POCKET AND HAND · HEM AND FALL · HARDWARE · WALL BEAT · SHADOW BEAT`), six flows (`SUN THEN SHADE · WALL WORK · SHADOW CROSSING · DETAIL IN SUN · WALK THE SHAFT · HOLD IN SHADE`), nine dimensions, and the sun written as a character: the bars it draws are part of the composition, and she stands inside the light or inside the shadow, never half and half. |
| **📱 E-commerce 4-up** | its flows were **declared in the header but never written in the skeleton** — the model was told to obey a flow it was never given. It now defines all four (`CUTS ARRIVE · SWAP ONE PANEL · ZOOM ONE PANEL · DETAIL TO FULL`), derives the panel set from what the request names ("never a fixed set"), gains `DETAIL CROP` and `LIGHT` as dimensions (7 live dimensions), and moves to 2K so the crops keep the face. |

Everything else in the pack keeps its laws; the studio family now uses the same engine as the template you liked, which is the point.

## Two bridal registers — heritage and modern glamour (v2.23)

The heritage register was still the app's default, so a request for *modern bridal* came back looking desi and old — the vocabulary (heirloom, polki, mehendi, haveli, gota patti) pulled it there. There are now **two bridal registers, each with its own template**, and the app states which is which:

- **Heritage** → *📱 Bridal jewellery show — five spots, one closing orbit* (v2.19–v2.22): ritual, heirloom craft, five spots at one heritage location.
- **Modern glamour** → **📱 Modern bridal glamour tour — couture, not costume** (new): this decade's couture, in its own file `bridal-glamour.md`.

**What the modern template is.** A tour of the look the way a fashion house films a piece — **OPEN** at full length in the architecture, then one named element per beat: bodice and bust, drape and train, the sparkle, the neck, the head, the hands, the waist, the back, hem and shoes, and the glamour close — with **CLOSE** last (held close on her face, one small real smile). Beats are conditional: only what your idea names, nothing invented. Six flows re-order them (`SILHOUETTE THEN GLAMOUR` · `FACE FIRST` · `WALK AND TURN` · `SEATED GLAMOUR` · `TRAIN SWEEP` · `TERRACE ORBIT`), and nine live dimensions mean every variant is a different film.

**"Expensive" is defined as specific, not as adjectives.** The template says it plainly: state the fabric and its weight (duchess satin, silk gazar, satin lamé, tulle), the construction (boned corsetry, horsehair hem, hand-set crystal, a cut-out closed by a gold bar, a train and how it pools) and the one hand-finished detail that carries the look — because *stated construction reads as couture and unnamed "heavy embroidery" reads as costume*.

**The register is enforced, not hoped for.** The heritage traps are named as forbidden defaults — no haveli, no jharokha, no marigold, no mirror work, no heirloom banarasi, no polki-kundan-jhumka parure — and the grade refuses nostalgia (no warm wash, no soft-focus glow, no vignette). The jewellery is **high jewellery worn as styling**: a diamond rivière choker alone, three layered fine diamond chains, a body chain across a bare back, an ear cuff climbing the helix, layered with one dominant piece and the rest fine and quiet. Beauty is the modern language — glass-skin base with real texture, sculpted contour, an eye with a point of view, a lip with colour, hair styled to show the jewellery.

**Seven new pools** back it in `fashion-variation.md` — `GLAM GARMENT` (10 couture looks), `LUXE JEWELS` (10 high-jewellery stylings), `GLAM BEAUTY` (8), `MODERN SET` (8 architectural rooms), `JEWEL METAL` (6), `GLAM PALETTE` (6) and `GLAM LIGHT` (8) — so a variant can never drift back to heritage on its own. The fashion pack names both registers and tells the model to choose by what the request asks for, never to default to heritage.

## The 2026 bridal register — designs, not categories (v2.22)

The bridal film's garments and jewellery were reading generic because the fields asked for *a* lehenga and *a* ornament set, and "a red lehenga with zari work" is what came back. The fix is design vocabulary, researched from this season's bridal market and written into the app in three places:

**A pool for every design decision.** `fashion-variation.md` gained the pools the bridal film varies on — **BRIDAL GARMENT**, **ORNAMENT SET**, **METAL AND STONE**, **STONE PALETTE**, **METAL**, **GARMENT**, **VEIL**, **MEHENDI** and **LIGHT** — so every variant of every bridal generation draws a real, specific design instead of a category. Every option names what makes it couture: the fabric and its weight, the silhouette, the blouse cut, the hem, and the embroidery **technique** (gota patti vines, zardozi border, bandhani dots, meenakari, jaali) with its motif.

**The register itself, stated as law.** The film's body now opens with a `DESIGN REGISTER — 2026 BRIDAL, NAMED` paragraph and the fashion pack carries the same section, so any bridal or occasion request benefits: light fabric over ten-kilo velvet, the **blouse as the hero piece**, colour from this season's palette (oxblood, old rose, ivory-and-gold, champagne antique metallic, emerald, sage/pistachio, butter yellow, ombré, contrast blouse), **jewellery styled rather than listed** — one dominant piece with everything else answering it, a close choker with *one* long haar, polki kept raw, temple gold for the traditional register, pastel stones against pastel fabric — and the balance rule that stops a look becoming a shop window: an oversized tikka or matha patti runs with **medium** earrings and a quiet choker, never full jhumkas as well. The "over" list is named too, so the model stops reaching for it: all-over mirror work, the disco-ball lehenga, and "zari work" with no technique.

**The ground beat replaces the anklet beat.** You were right that the anklet shot was hurting the look — a low orbit across her feet shows a foot, not a design, and it takes the wearer out of frame. That beat is now `THE GROUND`: a low **three-quarter** angle (never from below, never a foot-only crop) in which the embroidered border, the juttis and the anklets read *together* while she takes one slow step, her hand or the veil edge staying in the top of the frame. It is conditional (no named anklets or footwear → the beat is dropped, not invented), it is a reading hold like every other beat, and it is the **lowest priority beat** — never first, never the longest, and the first to go when the runtime is tight. The design lives in the full body, the blouse, the neck stack and the face.

**And the instant engine** (no LLM) draws from a modern bridal bank now: a bridal idea gets a named silhouette — raw-silk lehenga with a scalloped hem and corset blouse, pre-draped tissue saree-gown, fish-cut metallic, cape-lehenga, heirloom re-cut — plus a styled ornament set, instead of the earlier generic midi-skirt stack.

## The bridal show's camera — slow enough to read (v2.21)

The bridal film was moving too fast, jumping from the face to the ankles, and the closing orbit went straight to a wide without ever letting the head and the jewellery be looked at. Three real causes, three fixes:

**The camera had no governor.** With `Camera: Auto`, the app never passed amplitude or speed to the model, so it picked its own sweep. A template can now pin **`amp:`** and **`speed:`** in its header (only real values are accepted — a typo can't reach the model), the toast reads back *"small amplitude · slow speed"*, and `Auto` obeys the pin instead of choosing freely. The bridal show ships pinned **small + slow**.

**Nothing required a still frame for a detail.** The engine-wide doctrine now carries a **READING BEAT** rule: when a beat exists to *show* something — a jewel, an ornament, embroidery, a product face — the frame holds still for about 1.5s while only breath, fabric or light move underneath. Movement never carries a detail: a detail travelling through frame is *passed*, not shown, and the camera makes its move **between** details rather than across them. The ornament ladder (`ladder` presentation kind) says the same in its own law, so every jewellery template inherits it.

**The rise had to do everything at once.** 15s with auto cuts is five shots for a six-beat arc, so the closing orbit had to climb from her ankles to a full-body wide in one 3s window — that is the "straight to full body" jump. The film is now **18s (six shots, one beat each)** and the rise is its own beat that **climbs her body**: hem and skirt border, waist and kamar bandh, neck stack on her collarbone, then — closest and longest — her face with the tikka and the nath, held until it is read; only after that does the frame finish opening to full body. `THE RISE NEVER SKIPS A STEP`. The camera damping slider and the template parser both now allow up to **20s** (the clock's own ceiling), so longer films are reachable.

**The beat count follows the ornaments, never a faster camera:** one named family per beat when the runtime allows, two families merged into one beat when it doesn't, and if the runtime gives more beats the face and the neck stack each earn a second one.

## Innerwear only where it is seen (v2.20)

The closed-stack rule landed in v2.13 for a good reason — renders were coming back with a jacket and nothing under or below it — but it over-corrected: **every** outfit then carried a camisole, a bodysuit or a bralette-and-brief, including looks nothing can be seen through, and the renderer drew the underwear it had been told about. A lehenga also collected a separate skirt on top of its own lower half.

The law is now **coverage follows exposure**:

- **The stack stays closed.** An outer piece (jacket, coat, corset, kaftan, sheer overlay) never appears alone — it goes over a named inner *garment* (a shirt, a blouse, a knit). A bottom is stated, or the garment's own lower half when the piece is a whole garment (a lehenga, a dress, a sari, a jumpsuit). Footwear is named.
- **Innerwear is named only where the cut shows it** — sheer, translucent, net, plunged, open-backed, cut out, slit, or bare midriff — and then it says exactly what is there (a camisole, a bodysuit, a bralette-and-brief, a petticoat).
- **A closed, lined look names no base layer at all.** A camisole that nobody can see is a layer the prompt invented, and the renderer will draw it. A cropped jacket over high-waist trousers shows nothing; a lined blouse and a knit sweater show nothing.
- **Intimate wear is the outfit itself** — a lingerie set or a bikini gets nothing added under it and nothing draped over it.
- **A bottom you already named is never invented twice** — "tailored trousers" stays tailored trousers, not trousers plus a midi skirt.

This holds everywhere: the instant engine (`stackSentence` now reads the idea and decides), the LLM ✨ filler, both system-prompt targets, the fashion pack, the placeholder filler, the variation pool and every template's `LAYER STACK` line. The linter adds an advisory note — *innerwear named though nothing is exposed to cover* — so a stray camisole in a closed look is visible before you generate, while a deliberate camisole-under-blazer stays a clean pass.

## The bridal show — the arc is the format, the beats are the idea (v2.19)

Your brief, built as one template: **📱 Bridal jewellery show — five spots, one closing orbit** (15s · 9:16 · 2K · beat-driven).

**The arc you described is the format's shape**, kept in your order — full body, then the torso with the neck stack and the kamar bandh, then the face with the maang tikka and the nath, then the hands with the mehendi and the veil, then the ankles and the footwear on a left-to-right orbit, closing on that same orbit rising and pulling back until she is full body again and smiling down the lens. Like `OPEN first / CLOSE last` in the room tour, a jewellery show needs a skeleton to read as a show.

**What is dynamic is everything inside it.** Every beat is keyed to an ornament the idea actually names — tikka, nath, choker, rani haar, haar, kamar bandh, bangles, haath phool, rings, anklets, mehendi, veil. Skip any beat whose ornament is not named; never invent a piece, a spot or a gemstone; if only two families are named, run those two at two different scales. The **five spots come from the location field** (carved door, jaali window, marble steps, mirror hall, colonnade — name the ones you want, and it never invents another), so the background changes on every beat while the bride, the light logic and the ornament set stay identical. **Six flows** re-order the same beats — `LADDER UP` (your arc) · `LADDER DOWN` (opens on the face and widens) · `WALK THE SPOTS` (the walk carries it) · `ORBIT CLOSE` (the orbit is the reward) · `HANDS AND VEIL` (the hands beat is the spine) · `SEATED SET` — and **nine live dimensions** (ornament set, location, bridal garment, mehendi, metal and stone, veil, light, movement, camera) mean filling a field changes the film.

**The craft laws that make it look expensive:** the first frame is her head to toe with the whole set legible at real scale, and every macro after that keeps her in it — the tikka with her hairline, the nath with cheek and jaw, the neck stack on her collarbone and throat, the kamar bandh with the waist and the skirt's top edge, the haath phool with hand, wrist and forearm, the anklets with the foot and the hem — never an ornament alone on black. **The last two beats are one orbit seen twice:** it continues across the cut, same direction and speed, no re-set and no cut back to a stock wide, rising as it pulls back, and the smile belongs to the final second rather than being a pose held from the start. Materials separate (gold as metal, polki as uncut stone, pearls as pearl, mehendi as stain on skin, never a flat brown), nothing appears or vanishes between beats, and cuts come from the live clock — one ornament family per beat, the closing orbit taking the last stretch uninterrupted.

## The template is a shoot, not a shot (v2.18)

Three things were quietly capping every fashion template — the door reveal included — and all three are fixed.

**The runtime decides the cuts.** A look film of 12s was being told it was *exactly three shots with timed cuts*, so its beats (which run at 1–1.5s) got stretched to fill three long windows. That is why the door film felt slow and stiff next to the ref. Now there is a **Structure → `Auto cuts`** option, and every fashion block in the library pins it — the studio and doorway blocks plus the older editorial, sari, bridal, jewellery, intimates and outfit-reveal films (18 blocks): the runtime earns the shots (about one per 3s, 1–6 — a 6s clip is 2 shots, a 12s clip is 4, a 20s clip is 6). The clock then states the rule out loud: **a shot is not a beat** — the beats keep their ~1.5s rhythm *inside* a shot and run straight through the cuts, and no beat is ever stretched to fill one. The explicit `2 cuts` / `3 cuts` choices still mean exactly what they always meant.

**Silence is the default.** With no line written in the box, the app used to invite the model to "include dialogue where it elevates the scene" — which is how a silence-first draping film ended up with an invented greeting to camera. Now the default is a **wordless clip**: the soundscape, her breath and the fabric carry it. A line is written only when *your idea* asks for speech, or the format is a dialogue/ad read. When a line does belong, the old hard rule is unchanged — she says it on camera, face in frame, lips moving, nothing over the mouth, never an off-screen voice.

**No ledger lists.** The prose may not stack parenthetical production notes ("(her lips move, voice warm)", "(secondary beats: …)", "(all concealed in silhouette)") onto a sentence, and a label may never contradict the sentence it sits in — naming a colour and calling it concealed in the same breath is now forbidden outright. Secondary beats are written as prose with connectors.

**And the door template itself was wrong.** The ref (Shyamal & Bhumika, the carved teak door) does *not* hold her in an unlit silhouette — the fabric is the brightest thing in the frame and the dark carving is what it plays against. The template now says so: **the fabric is the light**; plus an **in-context macro pass** (fabric fills the frame with her still in it — never a bare fabric swatch) and the **veil portrait** closing beat the refs end on.

## Beats are derived, not hard-coded (v2.16)

The report, after trying the templates built from the reference videos: *"we hard code requirements, however we need to understand the flow and make things dynamic … learn how model moves, how she represents her cloths how camera moves and cuts not to hard code everything."*

That was exactly right, and it was measurable: every block in `fashion-campaign.md` and `intimates-reels.md` carried `TIMING: 12s total — 3 stamped shots of 4s, cuts at 00:04.000 and 00:08.000`, plus a fixed `BEAT ENGINE, three shots:` list. Three consequences: the same clip came out whatever the idea was; the fixed timecodes fought the runtime the moment you changed the duration; and a garment the beat list did not anticipate (a heavy brocade, an oversized hoodie) got choreography that did not belong to it.

**What the references actually contain is a grammar, not a shot list.** Four things are re-decided per idea:

| derived from | the law |
|---|---|
| the garment's physics | chiffon and tulle fly, trail and settle a beat late · tailoring turns a quarter and stops dead · knit moves in small familiar gestures · satin and sequin carry the light across the surface · denim, leather, brocade move as one piece and stay where they land · a lehenga's pleats swing and restack with the ornaments a half-beat behind |
| the presentation | an ornament is a **ladder** (her — whole look — set in context — macro still on her body) · a dressing sequence is the order she puts things on, and the fastening is the action · a walk is an approach where the frame grows by her walking, never by a zoom · a turn gives the back its own beat |
| the camera | establish at the scale that holds the whole look, then tighten by **cutting**; a rack focus or a push-in inside one shot is a beat, not a cut |
| the cut | the peak of a movement — the widest point of a flare, a footfall, the settle after a turn, a glint, a clasp click; never mid-gesture, never mid-sentence |

**What v2.16 ships**

| layer | what changed |
|---|---|
| **`src/lib/choreography.js`** (new) | the grammar in code. `garmentFamily(idea)` reads the garment and returns its movement verbs, presentation options, camera behaviour and cut triggers; `presentationKind()` classifies the job (ladder / dressing / walk / turn / craft / scene); `motionPlan()` fits it to the live clock and to the variant; `motionPlanText()` writes the injected block. Deterministic for an idea, different between variants of one run — and the plan never repeats a movement verb twice in a clip. |
| **`src/lib/prompts.js`** | every H3 and LTX request whose scene has a person now carries a **MOTION PLAN** block: garment behaviour, the movement verb for each shot, the presentation rule, the camera ladder, the cut triggers, the hold, and "skip, never invent". It states that a template's own beats are grammar — keep the laws, rebuild the beats. |
| **`src/lib/offline.js`** | the instant engine (no LLM) uses the same module, so its shots are derived per idea too — a chiffon turn and a wool coat no longer receive the same two generic beat lines. |
| **The 8 video-derived templates** | `fashion-campaign.md` (6) and `intimates-reels.md` (2): every fixed cut time and every `three shots:` list is gone. The reference grammar survives as the option set, under `BEAT ENGINE — THE GRAMMAR, NOT A SHOT LIST`, and each block's timing now reads *derive every cut from the live CLOCK — one beat per 1.5–2s*. |
| **Doctrine** | a new bullet in `shared/craft-detail-and-cast.md` (so all four system prompts carry it), the derivation table in `packs/fashion.md`, and a **write laws, not shot lists** rule in the Forge. |
| **Linter** | **🧭 Beat derivation** flags any block that stamps cut times and a fixed shot count with no flow library and no derivation rule — the shape that always renders the same clip. |

## When a file of yours is older than the build (v2.15)

The report: *`Uncaught SyntaxError: The requested module '/src/lib/filler.js' does not provide an export named 'readColourMemory'`* — the app would not load at all.

**Why it happened.** `src/lib/filler.js` and `src/lib/colourbank.js` are the two library files owners edit most, and the patch engine will never overwrite a copy it cannot prove is ours: a differing copy is left exactly as it is and the incoming version is parked beside it as `<file>.new`, listed in `PATCH-REPORT.md`. That is the protection working as designed — but the *other* files in the same patch were written against the new version. A later `offline.js` then did `import { readColourMemory } from './filler.js'`, the older copy did not export it, and an ES module that imports a missing **name** fails at link time, before any of your code runs. One parked file, whole app down.

**What v2.15 changes**

| layer | what it does |
|---|---|
| **`src/lib/colourlink.js`** (new) | the tolerant link. `colourbankBridge(mod)` and `fillerBridge(mod)` ask the module for each function they need: if it is there, behaviour is byte-for-byte what it always was; if it is not, the **feature** degrades and one console note names the file to take (the wheel runs from a small stand-in instead of throwing). It also carries `openColourWheel()`. |
| **`src/lib/offline.js`** | links `filler.js` and `colourbank.js` by **namespace**, never by name — the instant engine still produces a full prompt on an older copy, and skips the wardrobe line rather than dying when the colourbank is too old to build one. |
| **`src/components/StudioForm.jsx`** | the same treatment for ✨ Suggest: an older filler.js can no longer take the builder down with it. |
| **`PATCH-REPORT.md`** | when a file lands as a conflict, the report now lists the other files in that patch which **import** it, with the one-line fix. The next time a parked file is the reason something breaks, the report says so instead of leaving you to find it. |
| **The patch itself** | ships the current `src/lib/filler.js` (it is unchanged since v2.11, so a routine diff would have skipped it). If your copy is the old one, take it once — `node apply.mjs --accept-new` — and the remembered colour wheel works again. Until then the app runs. |

Rule of thumb: a `.new` file is not just "a file you may want" — if it is a `src/lib/` module, the rest of the patch may already be calling into it. The report now tells you which ones.

## The wearer is in frame — jewellery beats (v2.14)

The complaint, after trying the bridal-jewellery template: *"i just tried Jewellery macro ladder — ornament by ornament, its not even 1% of what i have seen in video i shared. we should start with full model framing and then show jwelley but in a way that we have model in context."*

The block had been written around the refs' *macro* language and its first flow was literally `MACRO FIRST` — so a fresh generation opened on a floating piece of gold with the wearer's face "entering the frame only at the edge". The reference films say the opposite, in every clip:

| rung | the reference frame | what it is for |
|---|---|---|
| **1 — on her, whole look** | the model standing or seated in the room, full-length, the complete set legible (sheet-01 frame 1, sheet-11 frame 1, sheet-12 frame 1, sheet-13 frame 1) | the measuring stick — after this frame every macro reads as *worn* |
| **2 — the set in context** | head-and-shoulders or waist-up with two pieces reading together: the choker with the earring against the jaw, the haar over the neckline (sheet-11 frame 2, sheet-12 frame 3) | scale and material truth, skin, hair and fabric still in frame |
| **3 — true macro, still on her** | the ring on a hand resting at the waist with the skirt border and the midriff around it, the necklace lying on shoulder skin (sheet-11 frame 3, sheet-12 frame 2) | the ornament as an object, grounded on a body |

What v2.14 ships:

| layer | what changed |
|---|---|
| **`public/prompts/templates/fashion-campaign.md`** | *Jewellery macro ladder* rewritten end to end. The `description`, `tip` and `idea` now say it opens ON HER; the beats are the three rungs above with an explicit **NO ORPHAN MACRO** ban ("never the piece alone on black, on velvet, on a tray or floating with no wearer"); the closing beat is a held close on her face, or — only when the request names a brand — a wordmark still with the piece still visible on her, the way the refs close. Flows became `FULL THEN LADDER \| SEATED SET \| LADDER DOWN \| LADDER UP`, with the establishing frame first so a fresh generation opens on the woman. Resolution moved `768P → 2K` because the opening frame is now a wide, and a face in a wide is the first thing 768P loses. It also carries its own `LAYER STACK:` clause for the neckline the set exposes. |
| **`public/prompts/shared/craft-detail-and-cast.md`** | new doctrine bullet **JEWELLERY, ACCESSORIES & DETAIL BEATS — THE WEARER IS IN FRAME**: she is established first, every insert keeps her body as its ground, no cut ever shows the piece alone on a surface, on velvet or on black, and the film ends on her. Included by all four system prompts — H3 + LTX, SFW + mature. |
| **`public/prompts/packs/fashion.md`** | the operating procedure: **On her first → In context next → True macro only after that, and still on her**, plus the closing-frame rule and the ban on the floating ornament macro. |
| **`public/prompts/templates/core.md`** | the try-on template's `PIECE-FIRST` flow no longer opens on "the piece alone on the tray" — it opens on the piece lifted **in her hand**, and its `[Shot 1]` now establishes her at the counter (waist-up, tray and mirror in frame) before the clasp beat. |
| **`public/prompts/packs/ethnic.md`**, **`public/prompts/template-forge.md`** | the ornament section and the Forge's house rules state it, so a forged or LLM-written jewellery template is born with the rule. |
| **Linter** | new advisory check **📸 Wearer in frame** for jewellery / ornament / accessory templates: warns when nothing establishes the wearer at full, three-quarter or waist-up scale, when no insert is anchored on her body, or when an orphan macro is described (the negated doctrine "never the piece alone…" is stripped before judging, so stating the ban is not a gap). |
| **Audit** | a new line prints the library-wide count: `Wearer in frame (jewellery / ornament blocks): 5 / 5 open on her and keep every insert anchored on her body`. |

The three laws, if you remember nothing else: **she opens the film, every rung is on her body, the film ends on her rather than on a product.**

## Missing layers — the closed stack (v2.13)

The complaint: *"top jacket is there and no pants, or even undergarments."* Root cause: a template can name **one** piece, and
the renderer fills the silence with its own default — usually nothing. The check found **30 of 131 blocks** describing a
fashion look that way (a jacket with no trousers, a corset with nothing under it, a sheer dress with no base layer).

The fix runs through every layer of the pipeline:

| layer | what it does |
|---|---|
| **`public/prompts/shared/craft-detail-and-cast.md`** | the OUTFIT DETAIL rule now opens with **"THE STACK IS ALWAYS CLOSED"** — base layer, main piece, a bottom or the garment's own lower half, outer layer only if there is one, then footwear. A jacket, blazer, coat, corset, kaftan or sheer overlay is **never** worn alone; anything sheer, plunged, open-backed or slit says what sits beneath it. This file is included by all four system prompts, so it applies to H3 + LTX, SFW + mature. |
| **`public/prompts/packs/fashion.md`** | a six-point checklist (base → main → bottom → outer → footwear → continuity) plus the special cases: swim and lingerie are described as the complete piece set, a dress/sari/jumpsuit is whole, a body-con piece still names what is under it. |
| **`public/prompts/fashion-outfit-expander.md`** | the expander now has a **LAYER COMPLETENESS** section and a self-check item (4b): an `Outer:` only exists over a named `Inner:`/`Base:`, a `Top:` never stands without a `Bottom:`, sheer exposes demand the base piece. The one-line output contract and the 100% preservation rule are untouched. |
| **`public/prompts/placeholder-filler.md`** | rule 7: filling a garment token means writing the closed stack, never "and the rest of the outfit". |
| **Templates** | 30 blocks got a tailored `LAYER STACK:` clause — a generic one, an exposed-garment one, an outer-layer one, or the swim two-piece one — placed inside the skeleton so the model is told in the same breath as the look. |
| **Linter** | a new **🧵 Layering completeness** check flags an outer layer with no bottom, a top with no bottom, something sheer with nothing named under it, and the words "garment/outfit" standing in for a full look. Warn-only, shown in the Forge and the manager. |
| **Instant engine** | the `WARDROBE` line now ends with a closed stack ("a light knitted camisole under it, a bottom in the same slate grey …, suede mules"). If your idea already names a colour, the engine echoes it into those layers instead of imposing a family — and if the scene has no wardrobe at all, no stack is added. |

Audit prints `Layer stack (fashion looks described as a complete outfit): 57 / 57 blocks carry the closed stack`, and the
self-test pins all of it (suite 11o) so a future template cannot quietly reopen the gap.

## Intimates reels — the two shop-window formats (v2.12)

`templates/intimates-reels.md` adds the pair the new references are cut from:

| block | shape |
|---|---|
| **Intimates collection launch** (12s) | launch card with one quoted line → true macro on the lace and the elastic edge → the face and personality beat → the second colourway in the same framing → closing card with the wordmark once |
| **Intimates demo — proof by turning** (12s) | front → side → back in one locked framing, then hands-on proof (waistband drawn out and snapping back, seam smoothed, a sit or a bend for comfort), then macro on the construction and one benefit line held |

Both are product-first and commercial, not boudoir: framing is limited to the garment's own coverage, the body language is neutral
and factual, and the demo may only claim what the construction does — no weight, inches, before/after, testimonial or medical
claim, no price or discount, and the brand wordmark only when the request names the brand.

## Colour wheel: why it kept landing on terracotta (v2.11)

Two defects, both mine, in the v2.8 wheel:

1. **The step was 3 and the wheel has 12 families.** gcd(3, 12) = 3, so repeated presses only ever reached
   **four** families (oxblood · terracotta · deep plum · tomato red) — and because every mount started the wheel at
   position 0, the *first* press of every session landed on family #4, which is **terracotta**.
2. **The position was thrown away on every page load**, so nothing ever moved the wheel off that spot for a
   single-press workflow.

Now: the step is `COLOUR_STEP = 5` (coprime with 12 → twelve presses visit all twelve families), the position and the
family last handed out are **remembered** in `localStorage` under `cps_colour_wheel` so a new visit continues the
wheel instead of restarting it, a new answer never opens on the family the previous answer used, drawing two tokens
inside one answer no longer eats into the next press's step, and the LLM brief now names the previous family
("your previous answer used the terracotta family — do not reuse it"). The instant engine reads the same memory, so
regenerating one idea in a sitting gives a different family each time.

Forget the memory any time with `forgetColourWheel()` from the console (`import('../src/lib/filler.js')`), or in the
UI by pressing ✨ a few times — it is meant to carry on, not to park.

## Two new template packs (v2.10)

**`templates/medical-reels.md` — three medical reels (9:16).** The old patient short was one calm 10s block; a reel needs a
hook, a spine and an action, so it was replaced by a proper pack:

| block | shape |
|---|---|
| **Symptom hook to one action** (15s) | HOOK inside 2s → NAME IT → SHOW WHY (one mechanism insert) → ONE ACTION held still, plus a loop back to the hook |
| **Myth vs fact, on camera** (12s) | the myth said out loud as the speaker's own words → the fact, held → why it is true; speaker on camera the whole time, face in frame, mouth clear, dialogue verbatim |
| **The day of the procedure** (15s) | the room before the clinic, the person before the equipment, step by step, then the aftercare line held a full second — no needle entering skin, no blood, no wound, ever |

All three carry a hard claims rule (never a diagnosis, never "cures/treats/prevents", no dose, no percentage, no before/after
promise), one quoted on-screen line per shot at most, and a stated timecode budget.

**`templates/fashion-campaign.md` — six fashion campaign templates (9:16)**, built by studying 22 of your reference clips
(the study is written up in `docs/refs-fashion-2026-09.md`): e-commerce 4-up cut collage, jewellery macro ladder, resort swim,
quiet-luxury studio, heritage doorway reveal, breeze float. Each keeps the house rules — the garment's colour always named,
one overlay line at most, scale beats, and cut timecodes inside the requested duration.

## “A file of mine is not listed” — the check order (v2.9)

A file you drop into `public/prompts/templates/` (or any folder inside it) has to clear four gates. Check them in order —
the app now tells you which one it failed.

1. **Name and place.** `.md`, under `public/prompts/templates/`, up to 4 folders deep. `README.md` and anything starting
   with `_` is skipped on purpose, at every depth.
2. **A `## Title` line and a skeleton.** H3 blocks need
   `integrated_multimodal_description:` (with `overall_soundscape:` and `non_diegetic_music:`);
   LTX blocks need `prompt:`. Fences are optional — the parser looks for the labels, so an outer ```` ```markdown ```` wrapper
   around the whole file (and inner fences inside it) is fine.
3. **A refresh.** The folder is read live on every reload, no rebuild. If you added a whole new *folder* and still see
   nothing, your `vite.config.js` may be an older copy that only indexes the root — an update that touches it leaves the new
   one beside it as `vite.config.js.new`. Accept it and restart `npm run dev`.
4. **Read what the app says.** Two places now speak up instead of dropping your file silently:
   * the picker (📐 Templates → pick) and the Templates page show a red
     **“⚠ N file(s) in `prompts/templates/` gave no templates”** panel, naming the file and the reason;
   * the source line above the list reads `prompts/templates/ (7 files scanned · 1 with templates · 1 subfolder: starter · ⚠ 1 gave no templates)`.

**The folder scan.** The loader unions three sources, so a file is found whichever one your install has:
`prompts/templates/_index.json` (dev server **and** `dist/`) → `prompts/_tree.json` (written by every config version, which is
why a subfolder file is listed even on an install whose `vite.config.js` is an old flat-index copy) → `prompts/templates/_folders.json`
+ each folder's own `_index.json` (for hand-built static hosts). If nothing is readable, the header says so in words:
*“⚠ subfolders unreadable in this copy”* — copy in the current `vite.config.js.new` to fix it.

**Notes in your prompt files (v2.9 fix).** `<!-- … -->` comments are stripped before the prompt is assembled, and a directive
written inside one is never treated as an `@include`. One-line notes used to make the resolver re-scan the same line forever —
your app could freeze on a file that contained one. Fixed; a note like `<!-- my own direction -->` is now safe anywhere, and the
self-test pins it.

**One-line diagnosis.** In the browser console:

```js
await window.cpsTplDiag()
```

It prints a table of every file the loader can see — its folder, whether it was fetched, how many blocks it parsed and their
titles — plus the `nestedSupported` flag, and returns the same object. If your file is in that table with 0 blocks, gate 2 is
your problem. If it is not in the table at all, gate 1 or 3 is.

## Colour — the wheel (v2.8)

White/ivory is what anything falls back to when nothing asks for a colour. Three layers now prevent it, all reading from **`src/lib/colourbank.js`**:

| layer | what it does |
|---|---|
| **`COLOUR_FAMILIES`** (bank) | twelve families — oxblood · cobalt · bottle green · terracotta · ink navy · mustard ochre · deep plum · burnished copper · powder blue · tomato red · slate grey · black with one colour — each with a `base`, a `look`, a `finish`, a `fabric` and `hardware`. Exactly **one** is flagged `pale`. |
| **`src/lib/filler.js`** | the ✨ Suggest / blank filler. Colour-bearing tokens walk the wheel (`rot` advances with every value), so twelve presses give twelve families. An idea that already names a colour is **echoed, never rivalled** (`crimson` → `crimson with antique gold, matte wool crepe`); an idea that names `ivory` is respected as-is. |
| **`public/prompts/placeholder-filler.md`** | the LLM filler's own rules: never answer white/ivory/cream/ecru/pearl/chalk/bone unless the IDEA or TEMPLATE asks by name, take the family named in the `COLOUR ROTATION` line, give each colour-bearing token a **different** family, keep one palette per answer. |

The Studio sends the rotation with the ask (`rotationBrief(filler.rot)`, advanced by 3 each press), so consecutive ✨ fills never repeat a palette. The instant engine's `WARDROBE` line is derived from the same families and now rotates with the **variant index** — six variants of one idea wear six different colour families.

