# 🎼 Dynamic templates — adaptive beats + beat flows

Two independent layers decide what a dynamic template writes:

| Layer | Comes from | Changes with |
|---|---|---|
| **Beats** (what is shown) | the details you actually name in the idea | your idea text — unnamed details get no beat and are never invented |
| **Flow** (the order/architecture of those beats) | the template's `flows:` header + the app's rotation | variant number · chain scene · consecutive generations |

So the same template with the same idea produces a **different edit**, not a re-worded one.

## How rotation works (no clicks needed)

* **Variants = 3** → the three cards run flow 1, flow 2, flow 3.
* **Story chain** → scene 1 runs flow 1, scene 2 flow 2, scene 3 flow 3 … (per-scene, so chains mixed with other templates still rotate inside each template).
* **Single variant runs** → each new generation walks to the next flow in the list, so pressing Generate three times gives three architectures.
* The chosen flow goes into the request as `BEAT FLOW: "<name>"`, appears on the finished card (`🎼 REVERSE REVEAL`), in the console (`beat flow: 🎼 …`), and on the template card as `🎼 6 flows`.

## The dynamic set

| Template | Format | Flows | Cut-shots | Adaptive beats come from |
|---|---|---|---|---|
| Room outfit tour — adaptive beats | H3, single, locked camera | 6 — TOP-DOWN TOUR · REVERSE REVEAL · DETAIL CASCADE · BOOKEND DETAIL · ARRIVAL-HOLD · TWIRL-CENTRE | no (size changes come from her approach) | named garment details: neckline, waist, hem/footwear, sleeves, back, hair |
| 💎 Jewellery glint cut montage — adaptive inserts | H3, multi3 | 4 — PIECE-BY-PIECE · GLINT TO EYES · ASCEND · HERO SINGLE | **yes** — one macro insert per named piece, cut on the glint | named pieces: earrings, necklace, ring, bangles, watch, tikka |
| 💎 Jewellery try-on — counter to mirror cuts | H3, multi3 | 4 — DRESSING ORDER · PIECE-FIRST · MIRROR DIALOGUE · BOX REVEAL | **yes** — clasp/closure macro per piece | named pieces, put on in human order (ears → neck → wrist → hand) |
| 💎 Bridal jewel cascade — one insert per ornament | H3, multi3 | 4 — ASCENT · DESCENT · SET COUNT · HERO ORNAMENT | **yes** — one insert per named ornament | named ornaments: tikka, jhumkas, choker, rani haar, bangles, hand-chain, rings |
| 🎼 Product tour — adaptive beats | H3, single | 5 — SURFACE FIRST · MECHANISM FIRST · SCALE REVEAL · BOOKEND MACRO · IN-USE SANDWICH | no | named features: finish, texture, mechanism, scale, contents, label, in-use |
| 🎼 UGC demo — adaptive beats | H3, multi2 | 4 — PROBLEM FIRST · RESULT FIRST · THREE STEP LADDER · DAY-IN-LIFE SANDWICH | yes (2 shots) | named problem, named demo steps, named result, named ask |
| 🎼 Dish story — adaptive beats | H3, multi2 | 4 — BUILD-UP · TABLE FIRST · ONE-TAKE KITCHEN · STEAM FIRST | yes (2 shots) | named techniques: pour, sizzle, steam, pull, crust, garnish, cold |
| 🎼 Space reveal — adaptive beats | H3, multi2 | 4 — ENTER AND ASCEND · DETAIL FIRST · LIGHT CHASE · SYMMETRY AXIS | yes (2 shots) | named elements: window, staircase, artwork, floor, ceiling, furniture, view |
| ⚡ LTX adaptive flow — beats by the beat | LTX, one paragraph | 4 — RISE · FALL · PIVOT · REVEAL | n/a (no cut language) | named details → one sentence each, count matched to duration |

## Authoring your own dynamic template

Add one header line to any block in `public/prompts/templates/*.md`:

```
flows: FIRST FLOW | SECOND FLOW | THIRD FLOW
```

Then, inside the skeleton, write a **FLOW LIBRARY** paragraph that (a) obeys a named `BEAT FLOW`
first, (b) otherwise chooses a flow from the subject, and (c) spells out each flow's beat order.
Keep the beats themselves conditional — *"use this beat only if the detail is named; never invent
one"* — and the duration budget honest (~1 beat per second). That is the whole pattern; the app
takes care of rotating, injecting and displaying the flow.
