import { useCallback, useEffect, useRef, useState } from 'react'
import Header from './components/Header.jsx'
import SettingsModal from './components/SettingsModal.jsx'
import ErrorBoundary from './components/ErrorBoundary.jsx'
import StudioForm from './components/StudioForm.jsx'
import CameraDirector from './components/CameraDirector.jsx'
import OutputPanel from './components/OutputPanel.jsx'
import HistorySection from './components/HistorySection.jsx'
import TemplateForge from './components/TemplateForge.jsx'
import GuideSection from './components/GuideSection.jsx'
import LearnSection from './components/LearnSection.jsx'
import { tryBase } from './lib/ollama.js'
import { fetchProviderModels, providerConfig, PROVIDERS } from './lib/providers.js'
import { logger } from './lib/logger.js'
import TemplateManager from './components/TemplateManager.jsx'
import { ENV } from './lib/providers.js'
import { loadTemplates, loadExamplePrompts, templateDiagnostics } from './lib/templates.js'
import { loadLoras } from './lib/loras.js'
import { loadPacks } from './lib/packs.js'
import { SYS_FALLBACK, LTX_SYS_FALLBACK } from './lib/prompts.js'
import { resolveIncludes } from './lib/sysfiles.js'
import { loadEngineSettings, saveEngineSettings, loadMature, saveMature } from './lib/enginesettings.js'

export default function App() {
  const [view, setView] = useState('studio')
  const [studioMode, setStudioMode] = useState('builder')
  const [tplHub, setTplHub] = useState('library')
  const [settingsOpen, setSettingsOpen] = useState(false)
  /* ⚙️ Settings opens on a named tab — the Studio form's summary links straight to it. */
  const [settingsTab, setSettingsTab] = useState('engine')
  const openSettings = (tab) => { if (tab) setSettingsTab(tab); setSettingsOpen(true) }
  /* 🎛 Engine settings live here (persisted) — the Studio form hydrates from them and
     follows any change made in Settings, so there is one home for the engine controls. */
  const [engSet, setEngSetState] = useState(() => loadEngineSettings())
  const setEngSet = (patch) => setEngSetState((s) => saveEngineSettings({ ...s, ...(patch || {}) }))
  const [matureOn, setMatureOnState] = useState(() => loadMature())
  const setMatureOn = (v) => { saveMature(!!v); setMatureOnState(!!v) }
  const [mgrOpen, setMgrOpen] = useState(false)
  const [guideFocus, setGuideFocus] = useState('')
  const [conn, setConn] = useState({ status: 'checking', base: null, models: [], model: '' })
  const [sysPrompt, setSysPrompt] = useState({ text: SYS_FALLBACK, status: 'loading' })
  const [ltxSysPrompt, setLtxSysPrompt] = useState({ text: '', status: 'loading' })
  const [sysMature, setSysMature] = useState({ text: '', status: 'none' })
  /* Which system prompt each generation uses. '' = automatic (per target + 18+).
     universal: one file for everything; h3/ltx/h3m/ltxm: per-slot override. */
  const [sysRoute, setSysRoute] = useState(() => {
    try { return JSON.parse(localStorage.getItem('cps_sysroute') || '{}') || {} } catch (e) { return {} }
  })
  const [sysFiles, setSysFiles] = useState({})   /* path → resolved {text, file, deps, missing} */
  const [sysCustom, setSysCustom] = useState(() => {
    try { const j = JSON.parse(localStorage.getItem('cps_syscustom') || 'null'); return j && j.text ? j : null } catch (e) { return null }
  })
  useEffect(() => { try { localStorage.setItem('cps_sysroute', JSON.stringify(sysRoute || {})) } catch (e) {} }, [sysRoute])
  useEffect(() => {
    try {
      if (sysCustom && sysCustom.text) localStorage.setItem('cps_syscustom', JSON.stringify({ name: sysCustom.name, text: sysCustom.text }))
      else localStorage.removeItem('cps_syscustom')
    } catch (e) {}
  }, [sysCustom])
  const [ltxMature, setLtxMature] = useState({ text: '', status: 'none' })
  const [cards, setCards] = useState([])
  /* Add-on 63 switch: Prompt Critic is an extra LLM call per card — default OFF */
  const [critOn, setCritOnState] = useState(() => { try { return localStorage.getItem('cps_crit_on') === '1' } catch (e) { return false } })
  const setCritOn = (v) => { setCritOnState(v); try { localStorage.setItem('cps_crit_on', v ? '1' : '0') } catch (e) {} }
  const [status, setStatus] = useState('')
  const [history, setHistory] = useState(() => {
    try { return JSON.parse(localStorage.getItem('cps_hist') || '[]') } catch { return [] }
  })
  const [tpl, setTpl] = useState({ list: [], source: 'loading' })
  /* Domain craft packs — one brain per video type (prompts/packs/*.md) */
  const [packs, setPacks] = useState({ list: [], source: 'loading' })
  /* Forged templates persist in localStorage — they survive reloads and restarts */
  const [forged, setForged] = useState(() => {
    try { const x = JSON.parse(localStorage.getItem('cps_forged') || '[]'); return Array.isArray(x) ? x : [] } catch (e) { return [] }
  })
  const persistForged = (list) => { try { localStorage.setItem('cps_forged', JSON.stringify(list)) } catch (e) {} }
  const [pendingForge, setPendingForge] = useState(null) /* templatize hand-off from output cards */
  const [corpus, setCorpus] = useState({ list: [], source: '' })
  const [loras, setLoras] = useState({ list: [], source: '' })

  /* ---------- toast ---------- */
  const [toasts, setToasts] = useState([])
  const toastId = useRef(0)
  const toast = useCallback((m) => {
    const id = ++toastId.current
    setToasts((t) => [...t.slice(-3), { id, m }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3800)
  }, [])
  useEffect(() => {
    const h = (e) => toast(e.detail)
    window.addEventListener('cps-toast', h)
    return () => window.removeEventListener('cps-toast', h)
  }, [toast])
  useEffect(() => {
    const h = () => setMgrOpen(true)
    window.addEventListener('cps-open-manager', h)
    return () => window.removeEventListener('cps-open-manager', h)
  }, [])
  useEffect(() => {
    const h = (e) => { setGuideFocus(e.detail || ''); setView('guide') }
    window.addEventListener('cps-open-guide', h)
    return () => window.removeEventListener('cps-open-guide', h)
  }, [])

  /* ---------- settings modal ---------- */
  useEffect(() => {
    const h = () => setSettingsOpen(true)
    window.addEventListener('cps-open-settings', h)
    return () => window.removeEventListener('cps-open-settings', h)
  }, [])
  useEffect(() => {
    if (conn.status === 'bad' && !sessionStorage.getItem('cps_settings_shown')) {
      sessionStorage.setItem('cps_settings_shown', '1')
      setSettingsOpen(true)
    }
  }, [conn.status])

  /* ---------- ollama detection (fully dynamic, nothing hardcoded) ---------- */
  const detect = useCallback(async (custom) => {
    const provider = localStorage.getItem('cps_provider') || 'ollama'
    setConn((c) => ({ ...c, status: 'checking', provider }))
    const prev = localStorage.getItem('cps_model') || ''
    /* cloud providers: fetch model list from their OpenAI-compatible /models */
    if (provider !== 'ollama') {
      const cfg = providerConfig(provider)
      if (cfg.needsKey && !cfg.key) {
        setConn({ status: 'nokey', provider, base: cfg.base, models: [], model: prev, error: 'API key missing — add it in ⚙️ Settings' })
        return
      }
      try {
        const names = await fetchProviderModels(provider)
        const model = prev || names[0] || ''
        setConn({ status: 'ok', provider, base: cfg.base, models: names.map((n) => ({ name: n })), model, key: cfg.key })
        logger.info('provider', provider + ' connected · ' + names.length + ' model(s) · using ' + model)
      } catch (e) {
        setConn({ status: 'bad', provider, base: cfg.base, models: [], model: prev, error: e.message })
        logger.error('provider', provider + ' connect failed: ' + e.message)
      }
      return
    }
    /* Ollama: local/proxy detection as before (typed model names are always kept) */
    const saved = (custom || localStorage.getItem('cps_ollama_base') || ENV.ollamaUrl || '').trim().replace(/\/$/, '')
    const cands = []
    if (saved) cands.push(saved)
    if (location.protocol.startsWith('http')) cands.push(location.origin + '/ollama') // Vite proxy → 127.0.0.1:11434
    cands.push('http://localhost:11434', 'http://127.0.0.1:11434')
    for (const b of cands) {
      const m = await tryBase(b)
      if (m) {
        const model = prev || [...m.map((x) => x.name)].sort()[0] || ''
        setConn({ status: 'ok', provider, base: b, models: m, model })
        return
      }
    }
    setConn({ status: 'bad', provider, base: null, models: [], model: prev })
  }, [])
  useEffect(() => { detect() }, [detect])
  useEffect(() => {
    const h = () => detect()
    window.addEventListener('cps-provider-changed', h)
    return () => window.removeEventListener('cps-provider-changed', h)
  }, [detect])

  const setModel = useCallback((name) => {
    try { localStorage.setItem('cps_model', name) } catch (e) {}
    setConn((c) => ({ ...c, model: name }))
  }, [])

  /* ---------- external system prompts (H3 + LTX) ---------- */
  const readSysFile = useCallback(async (p) => {
    const r = await fetch(p, { cache: 'no-store' })
    if (!r.ok) throw new Error('HTTP ' + r.status)
    const t = await r.text()
    if (!t.trim()) throw new Error('file is empty')
    return t
  }, [])
  /* a system prompt may depend on other .md files (@include) — every dependency
     is resolved here, so the text the model receives is one complete document */
  const fetchSys = useCallback(async (file, fallback) => {
    try {
      const raw = await readSysFile(file)
      const res = await resolveIncludes(raw, file, readSysFile)
      return { text: res.text, status: 'ok', deps: res.deps, missing: res.missing, cycles: res.cycles }
    } catch (e) {
      return { text: fallback, status: 'fallback', error: e.message, deps: [], missing: [], cycles: [] }
    }
  }, [readSysFile])
  const loadSys = useCallback(async () => {
    setSysPrompt(await fetchSys('prompts/system-prompt.md', SYS_FALLBACK))
    setLtxSysPrompt(await fetchSys('prompts/ltx-system-prompt.md', LTX_SYS_FALLBACK))
    /* Mature prompts are separate files; empty fallback = blocked by omission */
    setSysMature(await fetchSys('prompts/system-prompt-mature.md', ''))
    setLtxMature(await fetchSys('prompts/ltx-system-prompt-mature.md', ''))
  }, [fetchSys])
  /* Resolve each routed system-prompt file once, so generation stays synchronous. */
  useEffect(() => {
    const at = (sysRoute && sysRoute.attach) || {}
    const attached = ['all', 'h3', 'ltx', 'h3m', 'ltxm'].flatMap((k) => at[k] || [])
    const paths = [...new Set([
      ...[sysRoute.universal, sysRoute.h3, sysRoute.ltx, sysRoute.h3m, sysRoute.ltxm].filter((p) => p && p !== 'custom'),
      ...attached,
    ])]
    if (!paths.length) { setSysFiles({}); return }
    let dead = false
    ;(async () => {
      const out = {}
      for (const p of paths) {
        try {
          const raw = await readSysFile(p)
          const res = await resolveIncludes(raw, p, readSysFile)
          out[p] = { text: res.text, file: p, deps: res.deps, missing: res.missing, cycles: res.cycles, status: 'ok' }
        } catch (e) {
          out[p] = { text: '', file: p, deps: [], missing: [{ path: p, from: 'route' }], status: 'fallback', error: e.message }
        }
      }
      if (!dead) setSysFiles(out)
    })()
    return () => { dead = true }
  }, [sysRoute, readSysFile])

  /* One lookup used by the generator: routed path → resolved prompt (or the
     uploaded custom prompt for the special value 'custom'). */
  /* Same routing rules, reduced to plain text for the tools that take text only
     (template → native conversion in 📖 Learn). */
  const effSysText = useCallback((isLtx) => {
    const r = sysRoute || {}
    const slot = isLtx ? 'ltx' : 'h3'
    const key = (r.universal && r.universal !== '') ? r.universal : ((r[slot] && r[slot] !== '') ? r[slot] : '')
    if (key) {
      const got = key === 'custom'
        ? (sysCustom && sysCustom.text ? { text: sysCustom.text } : null)
        : sysFiles[key]
      if (got && got.text) return got.text
    }
    return (isLtx ? (ltxSysPrompt.text || LTX_SYS_FALLBACK) : (sysPrompt.text || SYS_FALLBACK))
  }, [sysRoute, sysFiles, sysCustom, sysPrompt, ltxSysPrompt])

  const sysLookup = useCallback((key) => {
    if (key === 'custom') return sysCustom && sysCustom.text ? { text: sysCustom.text, file: sysCustom.name || 'custom upload', deps: sysCustom.deps || [] } : null
    return sysFiles[key] || null
  }, [sysFiles, sysCustom])

  useEffect(() => {
    loadSys()
    loadTemplates().then(setTpl)
    /* 🩺 console helper: await window.cpsTplDiag() prints every template file the loader can see,
       its folder, its blocks and whether subfolders are readable in THIS copy of the app. */
    window.cpsTplDiag = async () => {
      const d = await templateDiagnostics()
      try { console.table(d.files.map((f) => ({ file: f.file, folder: f.folder || '(root)', fetched: f.fetched, blocks: f.blocks.length, titles: f.blocks.join(' | ') }))) } catch (e) {}
      console.log('templates: ' + d.files.length + ' file(s) · subfolders readable: ' + d.nestedSupported + ' · folders: ' + (d.folders.filter(Boolean).join(', ') || '(none)'), d)
      return d
    }
    loadExamplePrompts().then(setCorpus)
    loadLoras().then(setLoras)
    loadPacks().then(setPacks)
    const h = () => { loadSys(); loadTemplates().then(setTpl); loadExamplePrompts().then(setCorpus); loadLoras().then(setLoras); loadPacks().then(setPacks) }
    window.addEventListener('cps-reload-sysprompt', h)
    return () => window.removeEventListener('cps-reload-sysprompt', h)
  }, [loadSys])

  /* ---------- output cards + history ---------- */
  const pushCard = useCallback((c) => setCards((prev) => [c, ...prev]), [])
  const updateCard = useCallback((id, patch) =>
    setCards((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c))), [])
  const pushHistory = useCallback((v, inp, mode) => {
    setHistory((prev) => {
      const next = [{ ts: Date.now(), idea: ((inp && inp.idea) || '').slice(0, 140), mode: mode || 'studio', inp: inp || null, v }, ...prev].slice(0, 50)
      try { localStorage.setItem('cps_hist', JSON.stringify(next)) } catch (e) {}
      return next
    })
  }, [])
  const deleteHistory = useCallback((i) => setHistory((prev) => {
    const next = prev.filter((_, j) => j !== i)
    try { localStorage.setItem('cps_hist', JSON.stringify(next)) } catch (e) {}
    return next
  }), [])
  const clearHistory = useCallback(() => {
    setHistory([])
    try { localStorage.removeItem('cps_hist') } catch (e) {}
  }, [])
  const reuseHistory = useCallback((h) => {
    window.dispatchEvent(new CustomEvent('cps-restore-entry', { detail: h }))
    setView('studio')
  }, [])

  /* loading an example / restoring a history entry jumps to Studio.
     StudioForm is UNMOUNTED on the learn/history views, so the payload is
     latched here and applied once the form mounts. */
  const [pendingLoad, setPendingLoad] = useState(null)
  useEffect(() => {
    const h = (e) => { setPendingLoad({ kind: 'example', data: e.detail }); setView('studio') }
    const r = (e) => { setPendingLoad({ kind: 'restore', data: e.detail }); setView('studio') }
    /* 🔗 a chain built on the Templates page (ticked templates, or a chain recipe) */
    const ch = (e) => { setPendingLoad({ kind: 'chain', data: e.detail }); setView('studio') }
    window.addEventListener('cps-load-example', h)
    window.addEventListener('cps-restore-entry', r)
    window.addEventListener('cps-load-chain', ch)
    return () => {
      window.removeEventListener('cps-load-example', h)
      window.removeEventListener('cps-restore-entry', r)
      window.removeEventListener('cps-load-chain', ch)
    }
  }, [])

  /* output cards hand a finished prompt to the Forge to be templatized */
  useEffect(() => {
    const fg = (e) => { setPendingForge(e.detail); setTplHub('forge'); setView('templates') }
    window.addEventListener('cps-forge-from', fg)
    return () => window.removeEventListener('cps-forge-from', fg)
  }, [])

  const allTemplates = (() => {
    const seen = new Set()
    return [...forged, ...(tpl.list || [])].filter((t) => (seen.has(t.t) ? false : (seen.add(t.t), true)))
  })()
  const addForged = (t) => setForged((prev) => { const next = prev.some((x) => x.t === t.t) ? prev.map((x) => (x.t === t.t ? t : x)) : [t, ...prev]; persistForged(next); return next })

  const NAV = [
    ['studio', '🎬 Studio'],
    ['templates', '📐 Templates', allTemplates.length],
    ['learn', '📚 Learn'],
    ['history', '🕘 History', history.length],
    ['guide', '📖 Guide'],
  ]

  return (
    <>
      <Header conn={conn} onRecheck={() => detect()} onSettings={() => openSettings('engine')} />

      <nav className="appnav">
        {NAV.map(([id, label, count]) => (
          <button key={id} className={'ntab' + (view === id ? ' on' : '')} onClick={() => setView(id)}>
            {label}
            {count > 0 && <span className="n">{count}</span>}
          </button>
        ))}
      </nav>

      {view === 'studio' && (
        <ErrorBoundary label="The Studio panels" toast={toast}>
        <main>
          <div className="studiowrap">
          <div className="chips" style={{ margin: '0 0 10px' }}>
            <span className={'chip' + (studioMode === 'builder' ? ' on' : '')} onClick={() => setStudioMode('builder')}>🛠️ Prompt Builder</span>
            <span className={'chip' + (studioMode === 'camera' ? ' on' : '')} onClick={() => setStudioMode('camera')}>🛰️ Camera Director</span>
          </div>
          <section className="panel" id="inputPanel" style={{ display: studioMode === 'builder' ? '' : 'none' }}>
              <StudioForm
                conn={conn} setModel={setModel} sysPrompt={sysPrompt} ltxSysPrompt={ltxSysPrompt}
                sysMature={sysMature} ltxMature={ltxMature}
                sysRoute={sysRoute} sysLookup={sysLookup}
                pushCard={pushCard} updateCard={updateCard} pushHistory={pushHistory}
                setStatus={setStatus} toast={toast}
                onRecheck={() => detect()}
                loras={loras.list}
                presets={allTemplates.filter((t) => t.p)}
                templates={allTemplates}
                userReport={tpl.userReport}
                fileNotes={tpl.fileNotes}
                pendingLoad={pendingLoad}
                onPendingConsumed={() => setPendingLoad(null)}
                critOn={critOn} setCritOn={setCritOn}
                packs={packs.list}
                engSet={engSet} matureOn={matureOn} onOpenSettings={openSettings}
              />
          </section>
          <section className="panel" id="cameraPanel" style={{ display: studioMode === 'camera' ? '' : 'none' }}>
              <CameraDirector pushCard={pushCard} pushHistory={pushHistory} toast={toast} />
          </section>
          </div>

          <OutputPanel cards={cards} status={status} updateCard={updateCard} critOn={critOn} />
        </main>
        </ErrorBoundary>
      )}

      {view === 'templates' && (
        <ErrorBoundary label="The Templates page" toast={toast}>
        <div className="page-scroll">
          <div className="chips" style={{ margin: '0 0 12px' }}>
            <span className={'chip' + (tplHub === 'library' ? ' on' : '')} onClick={() => setTplHub('library')}>📐 Library</span>
            <span className={'chip' + (tplHub === 'forge' ? ' on' : '')} onClick={() => setTplHub('forge')}>🔥 Forge{forged.length ? ' (' + forged.length + ')' : ''}</span>
            <span className="vmeta" style={{ marginLeft: 8 }}>browse & attach · create & manage — one home for templates</span>
          </div>
          {tplHub === 'library' ? (
            <LearnSection hub="templates" templates={allTemplates} tplNotes={tpl.fileNotes} tplSource={tpl.source + (forged.length ? ' + ' + forged.length + ' forged' : '')} corpus={corpus.list} corpusSource={corpus.source} loras={loras.list}
              conn={conn} sysText={effSysText(false)} ltxText={effSysText(true)} toast={toast} />
          ) : (
            <TemplateForge conn={conn} toast={toast} onAdd={addForged} loras={loras.list} forgedList={forged}
              library={allTemplates}
              userTitles={new Set((tpl.list || []).filter((t) => t.src === 'user').map((t) => t.t))}
              pendingFrom={pendingForge} onPendingConsumed={() => setPendingForge(null)} />
          )}
        </div>
        </ErrorBoundary>
      )}

      {view === 'guide' && (
        <div className="page-scroll">
          <GuideSection focus={guideFocus} />
        </div>
      )}

      {view === 'history' && (
        <div className="page-scroll">
          <HistorySection history={history} onReuse={reuseHistory} onDelete={deleteHistory} onClear={clearHistory} toast={toast} />
        </div>
      )}

      {view === 'learn' && (
        <ErrorBoundary label="The Learn page" toast={toast}>
        <div className="page-scroll">
          <LearnSection hub="rest" templates={allTemplates} tplSource={tpl.source + (forged.length ? ' + ' + forged.length + ' forged' : '')} corpus={corpus.list} corpusSource={corpus.source} loras={loras.list}
            conn={conn} sysText={effSysText(false)} ltxText={effSysText(true)} toast={toast} />
        </div>
        </ErrorBoundary>
      )}

      <footer>
        CinePrompt Studio · runs 100% locally · pairs with{' '}
        <a href="https://ollama.com" target="_blank" rel="noopener">Ollama</a> · prompts follow MiniMax's published
        H3 prompt-writing guides · React + Vite edition
      </footer>

      <TemplateManager open={mgrOpen} onClose={() => setMgrOpen(false)} toast={toast} />

      <SettingsModal
        open={settingsOpen} onClose={() => setSettingsOpen(false)}
        tab={settingsTab} onTab={setSettingsTab}
        engSet={engSet} setEngSet={setEngSet} mature={matureOn} setMature={setMatureOn}
        critOn={critOn} setCritOn={setCritOn}
        conn={conn} setModel={setModel} detect={detect}
        sysPrompt={sysPrompt} setSysPrompt={setSysPrompt} sysMature={sysMature} ltxMature={ltxMature} ltxPrompt={ltxSysPrompt}
        sysRoute={sysRoute} setSysRoute={setSysRoute} sysFiles={sysFiles} sysCustom={sysCustom} setSysCustom={setSysCustom} toast={toast}
        packs={packs.list}
      />

      <div id="toasts" role="status">{toasts.map((t) => <div className="toast-item" key={t.id}>{t.m}</div>)}</div>
    </>
  )
}
