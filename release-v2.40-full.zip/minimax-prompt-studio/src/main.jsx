import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import { installLogCapture } from './lib/logger.js'
import './styles.css'

installLogCapture()

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
