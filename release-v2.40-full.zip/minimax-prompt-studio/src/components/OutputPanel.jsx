import { useState } from 'react'
import { scoreH3 } from '../lib/scoring.js'
import { checkLtx, checkH3 as checkH3Contract } from '../lib/contracts.js'
import { fmtTC } from '../lib/duration.js'
import { liveClock } from '../lib/prompts.js'
import { esc, highlight, fullPromptText, copyText, downloadText } from '../lib/format.js'

const WF_LABEL = { i2v: '🖼️ I2V', fflf: '🎞️ First→Last', multiref: '🔗 Multi-ref' }
const wfBadge = (inp) => (inp && inp.workflow && inp.workflow !== 't2v' ? ' · ' + WF_LABEL[inp.workflow] : '')
const loraInfo = (inp) => (inp && Array.isArray(inp.loras) && inp.loras.length ? inp.loras : null)
/* Domain craft packs riding on this generation — icons on the card, full names on hover */
/* Prompt size is shown as information only — nothing in the app caps it. */
const charBadge = (v) => {
  const t = fullPromptText(v || {}) || ''
  return t.length ? <span title="Prompt size — reported, never capped"> · {t.length.toLocaleString()} chars</span> : null
}
const refBadge = (v) => (v && v.refMode ? <span title="Full-reference (Ref2VA) — official six-section output"> · 🧩 Ref2VA</span> : null)
const flowBadge = (v) => (v && v.flow ? <span title={'Dynamic beat flow used for this variant: ' + v.flow}> · 🎼 {v.flow}</span> : null)
const packBadge = (inp) => (inp && inp.packs && inp.packs.length
  ? <span title={'Domain craft packs: ' + inp.packs.join(' + ')}> · 🧠 {inp.packs.map((p) => (p.match(/^[^\w\s]+/) || [''])[0]).join('')}</span>
  : null)
const loraPrefix = (ls) => [...new Set(ls.map((l) => (l.trigger || '').split(' (')[0].trim()).filter((w) => w && w !== 'none'))].join(', ')
const LoraRow = ({ inp }) => {
  const ls = loraInfo(inp)
  if (!ls) return null
  return (
    <div className="hint" style={{ margin: '0 0 8px' }}>
      🧬 Local LoRAs: {ls.map((l) => l.t + (l.strength ? ' (' + l.strength.split(' (')[0] + ')' : '')).join(' · ')}
    </div>
  )
}

const dispatchCrit = (card) => window.dispatchEvent(new CustomEvent('cps-critique', { detail: { card } }))

function CritPanel({ card, updateCard, toast }) {
  const crit = card.crit
  if (!crit) return null
  const v = card.v || {}
  const isLtx = v.target === 'ltx' || (card.inp && card.inp.target === 'ltx')
  const applyFix = () => {
    if (!crit.fix || !updateCard) return
    const patch = isLtx ? { prompt: crit.fix } : { integrated_multimodal_description: crit.fix }
    updateCard(card.id, { v: { ...v, ...patch }, crit: { ...crit, applied: true } })
    toast('✨ Critic fix applied — ' + (isLtx ? 'LTX paragraph' : 'H3 description') + ' rewritten')
  }
  const col = crit.score >= 80 ? 'var(--green)' : crit.score >= 60 ? '#fbbf24' : 'var(--red)'
  const dims = crit.dims && Object.keys(crit.dims).length ? Object.entries(crit.dims) : null
  return (
    <div className="crit">
      <div className="crit-head">
        <span className="crit-score" style={{ color: col }}>🧪 {crit.score}/100</span>
        <span className="vmeta">{crit.src === 'llm' ? 'LLM critique' : 'heuristic (offline)'}</span>
        {crit.fix && !crit.applied ? <button className="btn tiny primary" onClick={applyFix}>✨ Apply fix</button> : null}
        {crit.applied ? <span className="vmeta">✓ fix applied</span> : null}
      </div>
      {dims ? (
        <div className="crit-dims">
          {dims.map(([k, n]) => (
            <span key={k} className="crit-dim" title={k + ': ' + n + '/100'}>{k}{' '}
              <b style={{ color: n >= 80 ? 'var(--green)' : n >= 60 ? '#fbbf24' : 'var(--red)' }}>{Math.round(n)}</b>
            </span>
          ))}
        </div>
      ) : null}
      {crit.issues && crit.issues.length
        ? <ul className="crit-issues">{crit.issues.map((x, i) => <li key={i}>{x}</li>)}</ul>
        : <div className="vmeta">no issues flagged</div>}
    </div>
  )
}

const CritBtn = ({ card, on }) => {
  if (!on) return null
  return (
  <button className="btn tiny" disabled={!!card.critBusy}
    onClick={() => dispatchCrit(card)}
    title="Score this prompt across clarity/camera/continuity/audio/pacing/conformance and get an optional fix">
    {card.critBusy ? '🧪 scoring…' : card.crit ? '🧪 Re-score' : '🧪 Critique'}
  </button>
  )
}

function LtxCard({ card, toast, updateCard, critOn }) {
  const { v, inp } = card
  const words = (v.prompt || '').split(/\s+/).filter(Boolean).length
  const ltxc = checkLtx(v, inp || {})
  const meta = v.engine === 'ollama' ? `${v.model} · ${v.secs}s` : 'instant engine'
  return (
    <div className="variant">
      <div className="vhead">
        <span className="vtitle">⚡ {v.title}</span>
        <span className={'vmeta'} title={ltxc.violations.map((c) => c.label).join(' · ') || 'Every LTX requirement met'}>{ltxc.ok ? '🎬 LTX contract ✓' : '🎬 LTX contract ✗ ' + ltxc.violations.length + '/' + ltxc.checks.length}</span>
        <span className="vmeta">LTX-Video{v.multishot ? ' · 🎞️ native multishot (' + (v.shots || 'multi') + ' shots)' : ''} · {meta} · {esc(inp.ratio)} · {inp.duration}s{wfBadge(inp)}{packBadge(inp)}{flowBadge(v)}{refBadge(v)}{charBadge(v)}{v.promptSet ? (v.promptSet.startsWith('mature') ? <span title={v.promptSet}> · 🔞 mature</span> : v.promptSet.startsWith('routed') ? <span title={v.promptSet}> · 🎯 routed prompt</span> : <span title={v.promptSet}> · 🛡️ SFW</span>) : null}</span>
      </div>
      <div className="vbody">
        <LoraRow inp={inp} />
        <div className="promptbox" dangerouslySetInnerHTML={{
          __html: (loraInfo(inp) && loraPrefix(loraInfo(inp))
            ? '<span class="sec">🧬 LoRA triggers:</span> ' + esc(loraPrefix(loraInfo(inp))) + '\n\n' : '') +
            '<span class="sec">prompt:</span> ' + esc(v.prompt) +
            '\n\n<span class="sec">negative_prompt:</span> ' + esc(v.negative_prompt || ''),
        }} />
        {(v.tags || []).length > 0 && (
          <div style={{ marginTop: 8 }}>{v.tags.map((t) => <span key={t} className="tagpill">{t}</span>)}</div>
        )}
      </div>
      <CritPanel card={card} updateCard={updateCard} toast={toast} />
      <div className="vfoot">
        <button className="btn tiny primary" onClick={async () => {
          const ls = loraInfo(inp); const p = ls ? loraPrefix(ls) : ''
          await copyText((p ? p + ', ' : '') + v.prompt)
          toast(p ? 'Prompt copied WITH LoRA triggers' : 'LTX prompt copied')
        }}>📋 Copy prompt</button>
        {loraInfo(inp) ? (
          <button className="btn tiny" onClick={async () => { await copyText(v.prompt); toast('Platform clean prompt copied (no triggers)') }}>Platform clean</button>
        ) : null}
        <button className="btn tiny" onClick={async () => { await copyText(v.negative_prompt || ''); toast('Negative prompt copied') }}>Copy negative</button>
        <button className="btn tiny" onClick={() => window.dispatchEvent(new CustomEvent('cps-forge-from', { detail: { prompt: 'prompt: ' + v.prompt + '\n\nnegative_prompt: ' + (v.negative_prompt || ''), target: 'ltx' } }))} title="Turn this prompt into a reusable template in the Forge">🧩 Templatize</button>
        <button className="btn tiny" onClick={async () => { await copyText(fullPromptText(v)); toast('Full block copied') }}>Copy full</button>
        <button className="btn tiny" onClick={() => downloadText(
          'ltx-prompt-' + (v.title || '').toLowerCase().replace(/\W+/g, '-').slice(0, 40) + '.txt',
          fullPromptText(v) + '\n\n— CinePrompt Studio · LTX-Video 2.x\nTitle: ' + v.title)}>⬇ .txt</button>
        <CritBtn card={card} on={critOn} />
        <span className="score">{words} words · one flowing paragraph</span>
      </div>
    </div>
  )
}

function useTabs(initial) {
  const [tab, setTab] = useState(initial)
  return [tab, setTab]
}

function VariantCard({ card, toast, updateCard, critOn }) {
  const [tab, setTab] = useTabs('prompt')
  const { v, streaming, streamText, inp } = card

  if (streaming) {
    return (
      <div className="variant">
        <div className="vhead">
          <span className="vtitle">🎬 Directing…</span>
          <span className="vmeta">{esc(inp.ratio)} · {esc(inp.resolution)} · {inp.duration}s</span>
        </div>
        <div className="vbody">
          <div className={'promptbox' + (streamText ? '' : ' shimmer')}>
            {streamText || 'Directing your shot…'}
          </div>
        </div>
      </div>
    )
  }
  if (!v) return null
  if (v.target === 'ltx') return <LtxCard card={card} toast={toast} updateCard={updateCard} critOn={critOn} />

  const sc = scoreH3(v, inp)
  const h3c = checkH3Contract(v, inp || {})
  const meta = v.engine === 'ollama' ? `${v.model} · ${v.secs}s` : 'instant engine'
  const tabs = [
    ['prompt', 'Prompt'], ['breakdown', 'Breakdown'], ['checks', `Audit ${sc.pct}%`], ['json', 'JSON'],
  ]
  return (
    <div className="variant">
      <div className="vhead">
        <span className="vtitle">🎬 {v.title}</span>
        <span className="vmeta" title={h3c.violations.map((c) => c.label).join(' · ') || 'Every H3 requirement met'}>{h3c.ok ? '🎬 H3 contract ✓' : '🎬 H3 contract ✗ ' + h3c.violations.length + '/' + h3c.checks.length}</span>
        <span className="vmeta">{meta} · {esc(inp.ratio)} · {esc(inp.resolution)} · {inp.duration}s{wfBadge(inp)}{packBadge(inp)}{flowBadge(v)}{refBadge(v)}{charBadge(v)}{v.promptSet ? (v.promptSet.startsWith('mature') ? <span title={v.promptSet}> · 🔞 mature</span> : v.promptSet.startsWith('routed') ? <span title={v.promptSet}> · 🎯 routed prompt</span> : <span title={v.promptSet}> · 🛡️ SFW</span>) : null}</span>
      </div>
      <div className="tabs">
        {tabs.map(([id, label]) => (
          <button key={id} className={'tab' + (tab === id ? ' on' : '')} onClick={() => setTab(id)}>{label}</button>
        ))}
        <span className="durchip" title={'Clip length — set your generator to this duration. The prompt is written against this clock: ' + (() => { const c = liveClock(inp); return c.shots === 1 ? 'one continuous shot, no cuts' : c.shots + ' shots, cuts at ' + c.cuts.map(fmtTC).join(' / ') + ' (' + c.envelopeLabel + ')' })()}>⏱ {inp.duration}s{inp.structure === 'single' || inp.loop ? '' : ' · ' + liveClock(inp).shots + ' shots'}</span>
      </div>
      <div className="vbody" style={{ paddingTop: 8 }}>
        <LoraRow inp={inp} />
        {tab === 'prompt' && !v.integrated_multimodal_description && (
          <div className="promptbox" style={{ color: 'var(--red)' }}>
            ⚠ The model returned no usable description (raw output, if any, is in the JSON tab).
            Open the devtools console — the <b>CPS OLLAMA ↓</b> group shows exactly what came back;{' '}
            <code>window.cpsLogs.text()</code> copies the full session. Usually fixed by a bigger/instruction-tuned model
            (qwen2.5:7b or larger works well) or by regenerating.
          </div>
        )}
        {tab === 'prompt' && v.integrated_multimodal_description && !(v.overall_soundscape || '').trim() && !(v.non_diegetic_music || '').trim() && (
          <div className="hint" style={{ color: 'var(--accent)', marginBottom: 8 }}>
            ⚠ The model only returned the description — the soundscape/music fields came back empty. A bigger model
            usually returns all three fields; you can still copy the description as-is.
          </div>
        )}
        {tab === 'prompt' && v.alignment ? (
          <div className="promptbox" style={{ marginBottom: 8 }} dangerouslySetInnerHTML={{
            __html: '<span class="sec">🔗 keyframe alignment (official H3 line):</span> ' + esc(v.alignment),
          }} />
        ) : null}
        {tab === 'prompt' && v.refMode && v.integrated_multimodal_description && (
          <div className="promptbox" dangerouslySetInnerHTML={{
            __html: (loraInfo(inp) && loraPrefix(loraInfo(inp))
              ? '<span class="sec">🧬 LoRA triggers:</span> ' + esc(loraPrefix(loraInfo(inp))) + '\n\n' : '') +
              '<span class="sec">subject_definitions:</span> ' + highlight(v.subject_definitions) +
              '\n\n<span class="sec">summary:</span> ' + esc(v.summary) +
              '\n\n<span class="sec">retention_analysis:</span> ' + highlight(v.retention_analysis) +
              '\n\n<span class="sec">detailed_description:</span> ' + highlight(v.detailed_description || v.integrated_multimodal_description) +
              '\n\n<span class="sec">overall_soundscape:</span> ' + esc(v.overall_soundscape) +
              '\n\n<span class="sec">non_diegetic_music:</span> ' + esc(v.non_diegetic_music || 'N/A'),
          }} />
        )}
        {tab === 'prompt' && !v.refMode && v.integrated_multimodal_description && (
          <div className="promptbox" dangerouslySetInnerHTML={{
            __html: (loraInfo(inp) && loraPrefix(loraInfo(inp))
              ? '<span class="sec">🧬 LoRA triggers:</span> ' + esc(loraPrefix(loraInfo(inp))) + '\n\n' : '') +
              '<span class="sec">integrated_multimodal_description:</span> ' +
              highlight(v.integrated_multimodal_description) +
              '\n\n<span class="sec">overall_soundscape:</span> ' + esc(v.overall_soundscape) +
              '\n\n<span class="sec">non_diegetic_music:</span> ' + esc(v.non_diegetic_music || 'N/A'),
          }} />
        )}
        {tab === 'breakdown' && (
          <div className="kv">
            <b>Shot plan</b>
            <span>{(v.shot_plan || []).map((s, i) => <span key={i}>• {s}<br /></span>)}</span>
            <b>Full soundscape</b><span>{v.overall_soundscape}</span>
            <b>Score</b><span>{v.non_diegetic_music || 'N/A'}</span>
            <b>Tags</b>
            <span>{(v.tags || []).map((t) => <span key={t} className="tagpill">{t}</span>)}</span>
          </div>
        )}
        {tab === 'checks' && (
          <div className="checks">
            {sc.checks.map((c, i) => (
              <div key={i}><span className={c[0] ? 'y' : 'n'}>{c[0] ? '✔' : '✘'}</span>{c[1]}</div>
            ))}
          </div>
        )}
        {tab === 'json' && <div className="promptbox">{JSON.stringify(v, null, 2)}</div>}
      </div>
      <CritPanel card={card} updateCard={updateCard} toast={toast} />
      <div className="vfoot">
        <button className="btn tiny primary" onClick={async () => {
          const ls = loraInfo(inp); const p = ls ? loraPrefix(ls) : ''
          await copyText((p ? p + '\n\n' : '') + fullPromptText(v))
          toast(p ? 'H3 prompt copied WITH LoRA triggers' : 'Full H3 prompt copied')
        }}>📋 Copy full prompt</button>
        {loraInfo(inp) ? (
          <button className="btn tiny" onClick={async () => { await copyText(fullPromptText(v)); toast('Platform clean prompt copied (no triggers)') }}>Platform clean</button>
        ) : null}
        <button className="btn tiny" onClick={async () => { await copyText(v.integrated_multimodal_description); toast('Visual description copied') }}>Copy visual only</button>
        <button className="btn tiny" onClick={() => window.dispatchEvent(new CustomEvent('cps-forge-from', { detail: { prompt: fullPromptText(v), target: 'h3' } }))} title="Turn this prompt into a reusable template in the Forge">🧩 Templatize</button>
        <button className="btn tiny" onClick={() => downloadText(
          'h3-prompt-' + v.title.toLowerCase().replace(/\W+/g, '-').slice(0, 40) + '.txt',
          fullPromptText(v) + '\n\n— CinePrompt Studio · MiniMax H3\nTitle: ' + v.title + '\nTags: ' + (v.tags || []).join(', '))}>⬇ .txt</button>
        <CritBtn card={card} on={critOn} />
        <span className="score">{sc.pct}% H3-compliant<span className="meter"><i style={{ width: sc.pct + '%' }}></i></span></span>
      </div>
    </div>
  )
}

function CameraCard({ card, toast }) {
  const [tab, setTab] = useTabs('p')
  const { res, opts } = card
  const netTxt = (res.net >= 0 ? '+' : '') + res.net.toFixed(0) + '°'
  return (
    <div className="variant">
      <div className="vhead">
        <span className="vtitle">🛰️ Camera path · {netTxt} over {opts.duration}s</span>
        <span className="vmeta">
          {res.segments.length} segment{res.segments.length > 1 ? 's' : ''} · {opts.interp} · {opts.detail}
          {res.closes ? ' · loop closed' : ''} · {opts.frame}
        </span>
      </div>
      <div className="tabs">
        <button className={'tab' + (tab === 'p' ? ' on' : '')} onClick={() => setTab('p')}>Prompt</button>
        <button className={'tab' + (tab === 'c' ? ' on' : '')} onClick={() => setTab('c')}>Choreography</button>
        <button className={'tab' + (tab === 'j' ? ' on' : '')} onClick={() => setTab('j')}>JSON plan</button>
        <span className="durchip" title="Clip length — set your generator to this duration">⏱ {opts.duration}s</span>
      </div>
      <div className="vbody">
        {tab === 'p' && <div className="promptbox">{res.sections}</div>}
        {tab === 'c' && <div className="promptbox">{res.choreo}</div>}
        {tab === 'j' && <div className="promptbox">{JSON.stringify(res.plan, null, 2)}</div>}
      </div>
      <div className="vfoot">
        <button className="btn tiny primary" onClick={async () => { await copyText(res.sections); toast('Camera-path prompt copied') }}>📋 Copy full prompt</button>
        <button className="btn tiny" onClick={async () => { await copyText(res.choreo); toast('Choreography copied') }}>Copy choreography</button>
        <button className="btn tiny" onClick={() => downloadText('h3-camera-path.txt',
          res.sections + '\n\n— CinePrompt Studio · 3D camera path\nNet ' + netTxt + ' · ' + opts.duration + 's')}>⬇ .txt</button>
        <span className="score">{res.travel.toFixed(0)}° travelled · avg {(res.travel / opts.duration).toFixed(0)}°/s</span>
      </div>
    </div>
  )
}

export default function OutputPanel({ cards, status, updateCard, critOn }) {
  const toastRef = (m) => window.dispatchEvent(new CustomEvent('cps-toast', { detail: m }))
  return (
    <section className="panel">
      <h2><span className="step">✦</span> Generated prompts</h2>
      <div className="sub">Copy straight into the MiniMax platform, Hailuo AI, fal or ComfyUI.</div>
      <div className="statusbar">{status}</div>
      <div>
        {cards.length === 0 && (
          <div className="empty">
            <svg viewBox="0 0 24 24" fill="none" stroke="#8e97ab" strokeWidth="1.4">
              <rect x="2" y="7" width="20" height="13" rx="2" />
              <path d="M3 4l18-2.5V6L3 8.5z" />
              <path d="M7 11h6M7 15h10" />
            </svg>
            <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--dim)' }}>No prompts yet</div>
            <div style={{ marginTop: 6, fontSize: 13 }}>
              Describe a shot on the left and hit <b>Generate</b>.<br />
              Works instantly offline — or with your local Ollama model for richer results.
            </div>
          </div>
        )}
        {cards.map((c) => {
          if (c.kind === 'variant') return <VariantCard key={c.id} card={c} toast={toastRef} updateCard={updateCard} critOn={critOn} />
          if (c.kind === 'camera') return <CameraCard key={c.id} card={c} toast={toastRef} />
          if (c.kind === 'error') return (
            <div key={c.id} className="variant">
              <div className="vbody" style={{ color: 'var(--red)' }}>
                ⚠ {c.message}
                <div className="hint" style={{ marginTop: 8 }}>
                  If this is a CORS error, run the app with <code>npm run dev</code> (the Vite proxy removes CORS entirely).
                </div>
              </div>
            </div>
          )
          return null
        })}
      </div>
    </section>
  )
}
