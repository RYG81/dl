import { useEffect, useState } from 'react'

/* ── Guide primitives ─────────────────────────────────────────────────────── */

function Steps({ items }) {
  return (
    <ol className="gsteps">
      {items.map((s, i) => (
        <li key={i}><b>{i + 1}.</b> {s}</li>
      ))}
    </ol>
  )
}

function Tip({ children, warn }) {
  return <div className={'gtip' + (warn ? ' gwarn' : '')}>{warn ? '⚠️ ' : '💡 '}<b>{warn ? 'Pitfall: ' : 'Pro tip: '}</b>{children}</div>
}

/* Mock window — a faithful recreation of an app panel using the real CSS,
   standing in for a screenshot, with numbered callouts. */
function Mock({ title, children, calls }) {
  return (
    <div className="gmock">
      <div className="gmock-head"><span className="gmock-dot r"></span><span className="gmock-dot y"></span><span className="gmock-dot g"></span><span className="gmock-title">{title}</span></div>
      <div className="gmock-body">{children}</div>
      {calls && calls.length ? (
        <div className="gcalls">
          {calls.map(([n, txt], i) => <div key={i} className="gcall"><span className="gcall-n">{n}</span>{txt}</div>)}
        </div>
      ) : null}
    </div>
  )
}

const Sec = ({ id, icon, title, children }) => (
  <section className="gsec" id={'g-' + id}>
    <h2>{icon} {title}</h2>
    {children}
  </section>
)

/* ── The guide ────────────────────────────────────────────────────────────── */

const TOC = [
  ['start', '🚀 Quick start'],
  ['builder', '🛠️ Input Builder tour'],
  ['templates', '📐 Templates & placeholders'],
  ['packs', '🧠 Prompt packs'],
  ['chain', '🔗 Story chain & long videos'],
  ['refs', '📷 References & vision reading'],
  ['loras', '🧬 LoRAs'],
  ['ic', '🎛️ IC-LoRA protocols'],
  ['forge', '🧩 Template Forge'],
  ['filmcraft', '🎬 Characters · audio · Critic'],
  ['camera', '🛰️ Camera Director'],
  ['learn', '📚 Learn tab'],
  ['history', '🕘 History'],
  ['engine', '⚙️ Engines & providers'],
  ['mature', '🔞 SFW / mature routing'],
  ['logs', '🪵 Console logs & troubleshooting'],
  ['files', '📁 Customization files'],
]

export default function GuideSection({ focus }) {
  useEffect(() => {
    if (!focus) return
    const t = setTimeout(() => {
      const el = document.getElementById('g-' + focus)
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }, 60)
    return () => clearTimeout(t)
  }, [focus])
  const [open, setOpen] = useState('start')
  return (
    <div className="guide">
      <nav className="gtoc">
        <div className="gtoc-head">📖 Guide</div>
        {TOC.map(([id, label]) => (
          <a key={id} href={'#g-' + id} className={'gtoc-item' + (open === id ? ' on' : '')}
            onClick={() => setOpen(id)}>{label}</a>
        ))}
      </nav>

      <div className="gcontent">

        <Sec id="start" icon="🚀" title="Quick start — your first prompt in 60 seconds">
          <p>Everything runs 100% locally against your own Ollama (or any OpenAI-compatible provider). The app never sends your ideas anywhere else.</p>
          <Steps items={[
            <>Open <b>⚙️ Settings</b> → confirm Ollama is connected (green dot) and pick a model — <code>qwen2.5:7b-instruct</code> or bigger is recommended.</>,
            <>Stay on the default <b>Engine: Auto</b> (uses the provider when reachable, falls back to the instant offline engine otherwise).</>,
            <>In <b>🛠️ Input Builder → 1 Scene</b>, type one line: <i>"A baker opens the shutters of a tiny street bakery before sunrise"</i>.</>,
            <>Leave Camera/Format/Sound on Auto — the defaults are already dialed.</>,
            <>Press <b>🎬 Generate</b>. The prompt streams in as a card in the right panel; copy it to the MiniMax platform or your ComfyUI workflow.</>,
          ]} />
          <Tip>Watch the status line under the Generate button — it tells you model, ratio, duration and whether the 🛡️ SFW or 🔞 mature prompt set ran.</Tip>
        </Sec>

        <Sec id="builder" icon="🛠️" title="Input Builder — section by section">
          <p>Each <b>details</b> group is optional; collapsed sections simply use their Auto defaults. Order of sections:</p>
          <Mock title="Input Builder — section stack" calls={[
            ['1', 'Scene: idea + 📐 template + 🧩 placeholders + 🎲 Surprise me'],
            ['2', 'Camera / Format / Sound: locked, sane defaults — open only to override'],
            ['3', 'Reference assets → Story chain: multi-image workflows & chained clips'],
            ['4', 'Engine options → 🧬 LoRAs → 🎛️ IC protocol → sticky Generate bar'],
          ]}>
            <details className="grp" open>
              <summary><span className="step">1</span> Scene <span className="opt">what happens</span></summary>
              <div className="secbody">
                <div className="fwide"><label>Your idea</label><input type="text" defaultValue="A baker opens the shutters before sunrise…" /></div>
              </div>
            </details>
            <details className="grp"><summary><span className="step">2</span> Camera <span className="opt">Auto</span></summary></details>
            <details className="grp"><summary><span className="step">3</span> Format <span className="opt">16:9 · 2K · 8s</span></summary></details>
            <details className="grp"><summary><span className="step">🖼</span> Reference assets <span className="opt">optional</span></summary></details>
            <details className="grp"><summary><span className="step">🔗</span> Story chain <span className="opt">longer video</span></summary></details>
            <details className="grp"><summary><span className="step">🧬</span> LoRAs <span className="opt">local ComfyUI runs</span></summary></details>
            <div className="genbar"><button className="btn primary big">🎬 Generate H3 Prompt</button></div>
          </Mock>
          <ul className="glist">
            <li><b>1 Scene</b> — your idea, workflow (T2V / I2V / FFLF / Refs / A2V), 🗣 dialogue switch (🔇 none hard-bans all speech), template attach, surprise-me.</li>
            <li><b>2 Camera</b> — move type + amplitude + speed; <i>Auto</i> picks one motivated move with an end-state.</li>
            <li><b>3 Format</b> — ratio, resolution, duration, target (🎬 H3 or ⚡ LTX).</li>
            <li><b>🖼 Reference assets</b> — attach images/videos/audio with jobs; vision models can read frames for you.</li>
            <li><b>🔗 Story chain</b> — multi-clip films: bible, scenes, per-scene templates, batch generation.</li>
            <li><b>4 Sound / 5 Engine</b> — music level, ambience, dialogue line, variants, temperature, few-shot.</li>
            <li><b>👤 Characters</b> — identity bibles: 2–3 signature anchors repeated verbatim; prompts then carry only action and camera (the #1 consistency rule).</li>
            <li><b>🧬 LoRAs / 🎛️ IC protocol</b> — for local ComfyUI rendering (see dedicated sections).</li>
          </ul>
        </Sec>

        <Sec id="templates" icon="📐" title="Templates, presets & placeholders">
          <h4 className="gsub">🎼 Adaptive beat flows (dynamic templates)</h4>
          <p>
            A template can carry <b>named beat flows</b> — declared in its header as
            <code>flows: A | B | C</code>. The flow is the <i>architecture</i> of the beat chain (which
            beat comes when), while the beats themselves come from the details you name in the idea.
            It costs nothing to use: with Variants = 3 the three cards each run a different flow, a
            story chain walks the list scene by scene, and repeated single generations rotate too, so
            the same template keeps producing new edits instead of the same order. The card shows the
            flow used (<code>🎼 REVERSE REVEAL</code>), the template card shows <code>🎼 6 flows</code>,
            and the Scene section lists them under the template picker.
          </p>
          <p>
            Shipped dynamic set: <b>Room outfit tour</b> (6 flows — top-down, reverse reveal, detail
            cascade, bookend, arrival-hold, twirl-centre), <b>💎 Jewellery glint cut montage</b>,
            <b>💎 Jewellery try-on</b>, <b>💎 Bridal jewel cascade</b> (cut-shot films: one macro insert
            per piece you name, cut on the glint), <b>🎼 Product tour</b>, <b>🎼 UGC demo</b>,
            <b>🎼 Dish story</b>, <b>🎼 Space reveal</b> and <b>⚡ LTX adaptive flow</b>. In every one of
            them, an unnamed detail gets no beat — and is never invented.
          </p>
          <p>Templates are reusable beat skeletons with <code>{'{PLACEHOLDERS}'}</code>. They live in <code>the prompts/templates/ folder</code> (built-ins — 45+ H3 blocks AND a full ⚡ LTX set: fashion walk-in/twirl, product orbit, loop, street, food, wildlife, portrait, neon, performance, sports, interior) and <code>the prompts/templates/ folder — drop any .md in (name yours user-*.md)</code> (yours — never overwritten by app updates). The picker filters by 🎬 H3 / ⚡ LTX format and badges each block.</p>
          <Mock title="Template picker + placeholder box" calls={[
            ['1', '📐 Templates button → browse by tag chips, category dropdown and search'],
            ['2', 'Use attaches the skeleton; 🧩 fields appear for every placeholder'],
            ['3', '✨ Suggest values — your LLM proposes concrete values, you confirm'],
            ['4', 'Live preview: amber = unfilled token, cyan = your value; edit the idea and fields update instantly'],
          ]}>
            <div className="chips" style={{ marginBottom: 8 }}>
              <span className="chip on">All</span><span className="chip">👗 Fashion</span><span className="chip">📦 Product</span><span className="chip">🔞 Mature</span>
              <select style={{ marginLeft: 'auto', width: 'auto' }} defaultValue="All categories"><option>All categories</option><option>👗 Fashion / Lifestyle</option></select>
            </div>
            <div className="phbox" style={{ marginBottom: 0 }}>
              <div className="phgrid">
                <div className="phitem"><label>GARMENT</label><input type="text" defaultValue="flowing sage chiffon midi dress" /></div>
                <div className="phitem"><label>LOCATION</label><input type="text" placeholder="value for LOCATION" /></div>
                <div className="phitem phnew"><label>FINAL_POSE · <span className="vmeta">new</span></label><input type="text" placeholder="value for FINAL_POSE" /></div>
              </div>
              <div className="splabel">Your idea, processed <span className="vmeta">amber = unfilled · cyan = your value</span></div>
              <div className="sptext">A model wearing <mark className="hl-fill">flowing sage chiffon midi dress</mark> at <mark className="hl-tok">LOCATION</mark></div>
            </div>
          </Mock>
          <h4 className="gsub">🩺 “A file of mine is not listed” — check it in this order</h4>
          <ol className="glist">
            <li><b>Is it a <code>.md</code> file inside <code>public/prompts/templates/</code></b> (or any subfolder of it, 4 levels deep)?
              Files named <code>README.md</code> or starting with <code>_</code> are skipped on purpose, at every depth.</li>
            <li><b>Does it have a <code>## Title</code> line and a skeleton?</b> H3 wants the three labeled fields
              (<code>integrated_multimodal_description:</code> + <code>overall_soundscape:</code> + <code>non_diegetic_music:</code>);
              LTX wants <code>prompt:</code> (plus <code>negative_prompt:</code>/<code>tags:</code> if you like). The fences
              (```) are optional, and an accidental ```markdown wrapper around the whole file does no harm — the parser looks for the labels, not the fences.</li>
            <li><b>Just refresh.</b> The folder is read live on every reload — no rebuild. If you added a whole new <i>folder</i> and
              still see nothing, make sure the dev server is running the current <code>vite.config.js</code> (an update may have left the new
              one as <code>vite.config.js.new</code>): accept it and restart <code>npm run dev</code>.</li>
            <li><b>Read the app's own answer.</b> When a scanned file yields no blocks, the picker and the Templates page now show it by name —
              “<i>⚠ 1 file in prompts/templates/ gave no templates</i>” — with the reason, and the console logs the same line. A file that is
              never mentioned was never scanned.</li>
            <li><b>Still nothing?</b> Open the console and run <code>await window.cpsTplDiag()</code> — it prints every file the loader found, the
              folder each came from, which source found it (index / tree / folders) and whether subfolders are readable in this copy.</li>
          </ol>

          <h4 className="gsub">🎨 Colour — the filler walks a wheel, never a default</h4>
          <p>
            A blank colour used to come back as <b>ivory or white</b>, because that is what a model reaches for when nothing asks.
            Now every path that proposes a colour draws from <b>twelve families</b> (oxblood · cobalt · bottle green · terracotta ·
            ink navy · mustard ochre · deep plum · burnished copper · powder blue · tomato red · slate grey · black with one colour);
            exactly one of the twelve is deliberately pale.
          </p>
          <ul className="glist">
            <li><b>Press ✨ Suggest twice and you get two palettes.</b> The wheel advances on every ask, and when one answer fills several
              colour-bearing tokens, each gets a <i>different</i> family. Each value is a family plus its finish and hardware
              (<i>“deep oxblood with antique gold, matte wool crepe”</i>), never a bare shade and never a colourless garment.</li>
            <li><b>A colour you already wrote is kept exactly</b> — <code>crimson</code> in your idea comes back as <code>crimson</code> with a finish
              added around it. If you asked for <b>ivory</b>, you get ivory: the rule bans it as a <i>default</i>, not as a choice.</li>
            <li><b>No model connected?</b> The offline filler obeys the same wheel (its old list, which contained “ivory white”, is gone).</li>
            <li><b>Variants and chains spread too.</b> The instant engine's wardrobe line rotates with the variant index — six variants of one
              idea wear six different families instead of six versions of the same beige.</li>
          </ul>

          <Steps items={[
            <>Click <b>📐 Templates</b> in the Scene section → search or filter → <b>Use</b>.</>,
            <>Fill the <b>🧩 fields</b> — or press <b>✨ Suggest values</b> to let the LLM propose them.</>,
            <>Press Generate. <b>Left a field blank on purpose?</b> A confirm-and-fill modal appears: the LLM proposes values, you edit/accept (<b>✅ Fill & Generate</b>), or choose <b>🎲 Skip — model invents</b>.</>,
          ]} />
          <Mock title="How a template feeds each target" calls={[
            ['1', 'H3 skeleton = three labeled fields with [Shot N] blocks; LTX skeleton = ONE flowing paragraph (prompt: + negative_prompt: + tags:)'],
            ['2', 'Use attaches the skeleton as TEMPLATE GUIDELINE — beats, camera language, tone, audio treatment'],
            ['3', 'H3 target: the LLM writes the three fields following the skeleton. LTX target: the SAME skeleton is folded into one paragraph'],
            ['4', 'Mixed formats are fine: an H3 template on LTX collapses to a paragraph; an LTX template on H3 expands to shots. Guide, not cage'],
            ['5', '⚠ The instant offline engine ignores templates — it composes from idea + settings. Templates need any LLM (Ollama / OpenRouter / 🖥️ local)'],
          ]}>
            <div className="hint" style={{ margin: 0 }}>YOUR VALUES → fill {'{PLACEHOLDERS}'} in the skeleton → skeleton + values + idea travel as guidance → the target's system prompt supplies the GRAMMAR → final prompt in that target's exact format.</div>
          </Mock>
          <h4 className="gsub">📁 Subfolder templates — organise the library your way</h4>
          <ul className="glist">
            <li><b>Any folder inside <code>public/prompts/templates/</code> is scanned</b> (4 levels deep) — drop
              <code> bridal-2026/sangeet.md</code> in and it appears in the picker exactly like a root file, with a
              <b>📁 bridal-2026</b> pill. <code>README.md</code> and files starting with <code>_</code> are skipped.</li>
            <li><b>Folder filter</b> — the picker and this Templates page get a <code>📁 All folders (3)</code> dropdown next to the
              tag chips, and the folder name is searchable, so a big library stays navigable (one folder per client or campaign).</li>
            <li><b>Everything in a subfolder is yours.</b> Updates only ever write files into the root of the templates folder, so a
              tree you build is never replaced, moved or flattened (protected: one level, anything deeper, and any
              <code> user-*.md</code>).</li>
            <li><b>Works on a plain static host too</b> — the build writes a recursive <code>_index.json</code>, a
              <code> _folders.json</code> and one index per folder into <code>dist/</code>.</li>
          </ul>

          <h4 className="gsub">📐 Switching template replaces the inputs — it never inherits them</h4>
          <p>
            Attaching a template (picker, a Templates-page load, or Directing a chain scene) now <b>replaces</b>
            what the previous template put there instead of quietly carrying it over:
          </p>
          <ul className="glist">
            <li><b>Settings follow the template</b> — its pinned <code>ratio / resolution / duration / structure / camera / music</code>
              land in the Studio the moment you attach it, and the toast tells you exactly what changed
              (<i>📐 Outfit reveal — attached — 16:9 · 2K · 10s · 3 shots</i>).</li>
            <li><b>🧩 field values are pruned to the new template</b> — a value survives only if its token still exists in the
              new skeleton (or in your idea); everything that belonged to the previous template is cleared, with a count in the
              toast (<i>🧹 cleared 4 field(s) from the previous template: MODEL, LOCATION…</i>). Your idea text is never wiped.</li>
            <li><b>A blank idea adopts the template's own idea line</b> (the one with <code>&#123;PLACEHOLDERS&#125;</code>); a written idea is kept as-is.</li>
            <li><b>One switch, every path</b> — picker, Templates page, chain scene, loaded example and imported bundle all run the
              same pure function, so the old template cannot leave a value behind on any route.</li>
          </ul>

          <h4 className="gsub">⏱ Prompt duration — one clock, checked back</h4>
          <ul className="glist">
            <li><b>The clock is computed, not improvised.</b> Format section shows a live <b>⏱ CLOCK</b> line — e.g.
              <i>3 shots — cuts at 00:03.333 / 00:06.667, last shot 3.33s</i>. That exact budget goes into the user message, so the
              model no longer invents its own cut times.</li>
            <li><b>Structure decides the shots</b> — 1 / 2 / 3 shots follow the Shot structure chip, a seamless loop is always one take,
              and shots can never be shorter than 1.5s (a 5s three-shot clip is cut 1.67s each, never 2/2/1).</li>
            <li><b>The runtime must appear in the prompt.</b> The engine is required to state it in the opening sentence
              (<i>"…, 24fps, a 10-second three-shot sequence"</i>), so the text and the generator's duration setting agree.</li>
            <li><b>Template clocks cannot override yours.</b> If a skeleton pins 10s and you pick 6s, the CLOCK wins and every example
              timecode in the skeleton is recomputed; the Duration row offers a one-click <b>📐 use 10s</b> to match the template instead.</li>
            <li><b>The audit checks it back</b> (Audit tab): cut times inside the window, a last shot of at least 1.5s, the shot count
              matching your structure, every spoken line short enough to fit its own shot at ~4 words/s, and the runtime actually stated.
              A prompt that says "wearing a wool coat" and later "fully nude" is flagged as a self-contradicting wardrobe.</li>
          </ul>
          <Tip>Presets (⚡ Presets button) are one-click bundles: idea + settings + tip. Templates guide the writing; presets load a whole setup.</Tip>
        </Sec>

        <Sec id="chain" icon="🔗" title="Story chain — longer videos & 10-shot films">
          <p>One generation carries ≤4 cuts reliably, so longer films are <b>chained clips</b>: the chain writes a consistency bible, one beat per scene, and bridges scenes with end states.</p>
          <Mock title="Story chain — auto-plan, per-scene templates, batch" calls={[
            ['1', '✨ Auto-plan: one line of idea → bible + every scene beat, automatically'],
            ['2', '📐 per-scene template: chain different templates (e.g. three fashion looks)'],
            ['3', '⎗ Direct loads a scene; ⚡ generates ALL scenes in one click'],
            ['4', 'End states auto-capture and travel into the next scene as continuity'],
          ]}>
            <div className="chain-row">
              <div className="chain-top">
                <span className="chain-n on">1</span>
                <input type="text" defaultValue="HOOK — open on the chiffon dress in the atrium…" />
                <select style={{ width: 'auto', maxWidth: 170 }} defaultValue="Twirl reveal"><option>Twirl reveal</option></select>
                <button className="btn tiny">⎗ Direct</button>
              </div>
              <input type="text" className="chain-end" defaultValue="end state — she holds the lens, fabric settling…" />
            </div>
            <div className="chain-row">
              <div className="chain-top">
                <span className="chain-n">2</span>
                <input type="text" defaultValue="TURN — wind picks up, she walks the colonnade…" />
                <select style={{ width: 'auto', maxWidth: 170 }} defaultValue="Walk-in approach"><option>Walk-in approach</option></select>
                <button className="btn tiny">⎗ Direct</button>
              </div>
            </div>
            <div className="frow chain-foot" style={{ marginTop: 6 }}>
              <button className="btn sm primary">⚡ Generate all 2 scenes</button>
            </div>
          </Mock>
          <Steps items={[
            <>Write one line of idea → set <b>⏱ Plan length</b> → <b>✨ Auto-plan chain</b> (writes bible + beats; empty inputs are all optional).</>,
            <>Optionally pick a <b>📐 template per scene</b> — e.g. three fashion templates for looks 1–3.</>,
            <>Hit <b>⚡ Generate all N scenes</b> — one prompt card per scene, bible + end states travel forward.</>,
            <>Render in order, feeding each clip's <b>last frame</b> as the next scene's first frame (⎗ Direct auto-arms I2V).</>,
          ]} />
          <Tip warn>One clip carries ≤4 cuts (H3) — a 10-shot film is 3–4 chained clips of 2–4 shots, or 10 one-shot clips. The planner row shows the math live.</Tip>
          <Tip>Different templates per scene stay coherent because the bible locks identity/set/grade — templates vary choreography, the bible locks the world.</Tip>
          <Tip>🎬 <b>Every card carries its engine's contract.</b> H3 cards show <b>H3 contract ✓</b> and LTX cards <b>LTX contract ✓</b> — hovering lists any break. The check is the engine's own rule set: H3 (three fields in order, [Shot 1] untimestamped, later shots timecoded and strictly increasing, 4–15 s per generation with anything longer declared as a chain, camera amplitude and speed in plain words, no director instructions, music = instrumentation and tempo) and LTX (one present-tense paragraph, no labels or numbered shots, emotion as a physical cue, one motivated camera move with a named end-state, sentences spaced to the duration, a real negative_prompt). A break lands in the Audit tab as <b>H3/LTX contract · …</b>. The template linter carries the same law: a block that would force a break warns before it is saved.</Tip>
          <Tip>🎞️ <b>→ native multishot</b>: instead of N separate prompts, collapse the whole chain into ONE LTX-2.5 multishot generation — connected shots holding character, light and voice across cuts in a single ≤20 s paragraph. Your per-scene chain stays untouched; it's an extra output mode.</Tip>
        </Sec>

        <Sec id="refs" icon="📷" title="Reference assets & vision frame reading">
          <p>Attach images/videos/audio with a <b>job</b> (what each reference is for). With 3+ images from one photoshoot, the app tiles them into numbered <b>contact sheets</b> and asks your vision model to read them — captions enter the prompt as ground truth.</p>
          <Steps items={[
            <>In <b>🖼 Reference assets</b>: add images → write a job ("wardrobe ref", "first frame", "location plate").</>,
            <>Keep <b>Send references</b> checked; choose workflow <b>I2V</b> / <b>First→Last</b> / <b>Refs</b> as needed.</>,
            <>Generate — the status line shows <b>👁 Reading sheet 1/2…</b>; read frames get "Seen in frame: …" captions.</>,
            <>For the LTX target the captions arrive as a <b>REFERENCE FRAME SEQUENCE</b> directive: recreate these frames, motion = the movement between them.</>,
          ]} />
          <Tip>Vision quality depends on your model — <code>gemma3</code> / <code>qwen2.5-vl</code> read sheets best; moondream and llava-7b can miss detail (the app falls back to one-by-one reading automatically). Vision is NOT Ollama-only: with the 🖥️ Local inference provider, any OpenAI-compatible server running a VLM (e.g. Qwen3-VL-32B GGUF with mmproj — the same family H3 uses internally) reads frames too.</Tip>
                  <ul className="glist">
            <li><b>🎯 L2V (last-frame → video)</b> — the official H3 L2VA mode: your image is the <i>final</i> frame, so the prompt invents a plausible earlier state and converges on it. The answer opens with the official alignment line ("…aligns with the 8.00-second mark of the target video"), which the app computes from your duration and shot count.</li>
            <li><b>🖼️ I2V / 🎞️ FFLF</b> also open with their official instruction lines now, and FFLF is steered to a single shot so the model interpolates continuously between the two frames.</li>
            <li><b>🔗 Refs (Ref2VA)</b> — full-reference mode outputs the official <b>six sections</b>: <code>subject_definitions → summary → retention_analysis → detailed_description → overall_soundscape → non_diegetic_music</code>, with the label vocabulary in the answer.</li>
          </ul>
        </Sec>

        <Sec id="loras" icon="🧬" title="LoRAs — local ComfyUI add-ons">
          <p>A LoRA is a small add-on model your <b>local ComfyUI</b> loads next to H3/LTX. It only fires when its <b>trigger word is in the prompt</b> — that's what the app manages.</p>
          <Steps items={[
            <>Open <b>🧬 LoRAs</b> → select LoRAs for your target (H3 or LTX list).</>,
            <>Generate — the trigger line is <b>stamped on top of the prompt card</b> (🧬 LoRA triggers: …).</>,
            <>Copy the card → paste into ComfyUI with the shown <b>strength</b>. Rendering on the hosted cloud instead? Use the <b>Platform clean</b> button (no triggers).</>,
            <>Add your own LoRAs anytime: append a block to <code>prompts/loras.md</code>.</>,
          ]} />
          <Tip>Learn → 🧬 LoRAs tab lists the whole library with ➜ Arm in builder. For multi-reference looks see <b>Licon MSR V1</b> (label refs "Image 1/2/3" in the prompt).</Tip>
        </Sec>

        <Sec id="ic" icon="🎛️" title="IC-LoRA protocols (Ingredients, COLORIZE, CrossView…)">
          <p>IC-LoRAs condition on a reference signal and each demands an <b>exact prompt contract</b>. The 🎛 panel assembles them field-by-field so you can't drift off-protocol.</p>
          <Steps items={[
            <>Open <b>🎛 IC-LoRA protocol</b> → pick a protocol (Ingredients, COLORIZE, ENHANCE QUALITY, Clean Plate, Relight, CrossView, Depth/Pose…).</>,
            <>Fill the fields → watch the <b>exact contract prompt</b> assemble live.</>,
            <>Press <b>🎛 Emit IC prompt card</b> → it lands in Outputs with its negative prompt, ready for the ComfyUI IC workflow.</>,
            <>Depth/pose/canny protocols also switch the LLM into <b>style-only mode</b> (no motion verbs — the reference carries motion).</>,
          ]} />
          <Tip warn>IC adapters were trained on ONE caption convention each — free-form text degrades them. Always emit through the builder, never hand-edit the contract.</Tip>
        </Sec>

        <Sec id="forge" icon="🧩" title="Template Forge — create, templatize, edit">
          <p>Your local model writes new template blocks for you — H3 and LTX formats, with LoRA triggers woven in.</p>
          <Mock title="🧩 Forge — three directions" calls={[
            ['1', '✍️ Describe it → 🔥 Forge writes a full block (idea + skeleton + sound fields)'],
            ['2', '♻️ From a finished prompt — any output card has a 🧩 Templatize button'],
            ['3', '✏️ Edit — every Learn card has an Edit button; live re-parse as you type'],
            ['4', '💾 saves to browser storage; ⬇️ Export all → append to a user-*.md file in prompts/templates/ for permanence'],
          ]}>
            <div className="chips" style={{ marginBottom: 8 }}>
              <span className="chip on">✍️ Describe it</span><span className="chip">♻️ From a finished prompt</span><span className="chip">✏️ Edit block</span>
              <span className="chip on" style={{ marginLeft: 'auto' }}>🎬 H3</span><span className="chip">⚡ LTX</span>
            </div>
            <div className="fcol"><label>What should the template be?</label><input type="text" defaultValue="Vertical reel for skincare reveals — macro open, slow spin, whispered benefit line" /></div>
            <div className="hint" style={{ marginTop: 6 }}>🧬 Integrate LoRAs: <span className="chip on">🧬 Cinemagrade</span> <span className="chip">🧬 DY</span></div>
          </Mock>
          <Steps items={[
            <>Pick target (<b>H3</b> or <b>LTX</b>) + optional tag/category/ratio/duration/music.</>,
            <>Describe the reusable video (or paste a finished prompt, or arm LoRAs to weave their triggers in).</>,
            <>🔥 Forge → review the streamed block with its <b>✅ parser accepts</b> badge.</>,
            <><b>💾 Add to library</b> (persists in this browser) or <b>⬇️ Export all to .md</b> → append to <code>the prompts/templates/ folder — drop any .md in (name yours user-*.md)</code> so updates never erase them.</>,
          ]} />
          <Tip warn>localStorage survives restarts but not “Clear browsing data” — export batches you love into a user-*.md file in prompts/templates/.</Tip>
          <Tip>Hand-written blocks in a user-*.md file in prompts/templates/ don't even need fences — a <code>## Title</code> + meta lines + <code>prompt:</code>/<code>negative_prompt:</code> (LTX) or the three H3 fields are enough; <code>target: ltx</code> meta marks LTX. Blocks that can't be parsed are counted and reported (“⚠ N malformed blocks skipped”) instead of vanishing silently.</Tip>
                  <ul className="glist">
            <li><b>🧪 Template lint</b> — every forged or edited block is checked before it is saved: format labels, a pacing contract, placeholder hygiene (soft target ≤8, 12+ means merging pays), how many tokens carry guidance, conditional beats, flows, and near-duplicates against your whole library. Advisory only — nothing is ever blocked.</li>
            <li><b>💾 Add to library</b> keeps it in this browser; <b>⬇️ Save as user-*.md</b> downloads it as a drop-in file for <code>public/prompts/templates/</code> so it lives in your local copy and is never touched by app updates.</li>
            <li><b>Token guidance</b> — write placeholders as <code>{'{TOKEN — what to name}'}</code>. The builder then labels the field with the short token, shows the guidance as the field hint, and passes it to ✨ Suggest values, so proposed values land on-brief instead of generic.</li>
          </ul>
        </Sec>

        <Sec id="filmcraft" icon="🎬" title="Characters, native audio & the Critic">
          <ul className="glist">
            <li><b>Detail is the consistency engine.</b> Every concrete thing a prompt states becomes a lock — a named location (type of place, era, materials, light source, what is in frame), a named subject (age range, build, hair, skin, one distinguishing feature, what the face is doing) and a named outfit (garment, cut, fabric, colour, footwear) cannot drift between shots or between takes. Category words — "a room", "a woman", "a dress" — hand the decision back to the model and the result changes every run. Both system prompts now push detail on location, subject and outfit by default, the builder restates it on every generation, and the 🔨 Forge teaches it to new templates.</li>
            <li><b>Fashion is cast with women only.</b> Every fashion, styling, lookbook, try-on, beauty, hair, jewellery and ethnic/bridal generation is cast as an adult woman — no men, boys or male-presenting models, no male face, hands, silhouette, background figure or voice (a crowd, a companion or a partner is a woman too). The rule lives in all four system prompts, in the built-in fallbacks, in the 🎨 Fashion pack, in the 🔀 variation pools, and it is injected into every fashion request at generation time — so it still holds if you override the system prompt with your own file. A non-visual off-screen voice is the only exception, and only when your own text puts it there.</li>
            <li><b>👤 New: the model is 20–32 unless you say otherwise — young, beautiful, fashion-model quality.</b> Your standing rule, now a law in the engine rather than a habit. The <b>cast lock</b> that rides in every fashion generation states it: cast her between 20 and 32 and write <b>ONE age</b>, not a range — a stated age is a lock the renderer cannot drift from, an age range is a guess. The register is the current <b>editorial/runway</b> one: clear skin with real texture, defined bone structure, even features, healthy and camera-ready, presence rather than a pageant smile. An age <b>you</b> name always wins, and it then becomes the lock. Two floors sit under it: <b>never a teenager, a child or a child-like face or body</b> — and if a brief asks for under-20, she is an adult of 20 or over — and every background person, hand, reflection and companion is an adult too. Across variants of one run it is the <b>same woman</b>: the age, the face and the body repeat exactly while the clothes, the room and the acts change. It lives in <b>five places</b> so nothing can miss it: the cast lock (injected at generation time, so it still holds if you override the system prompt with your own file), the shared craft file all four system prompts include, the 🎨 Fashion pack, the template forge (so every new template you make carries it), and <b>all 138 person fields</b> in the templates — every <code>&#123;MODEL&#125;</code>, <code>&#123;CREATOR&#125;</code>, <code>&#123;WEARER&#125;</code> and <code>&#123;SUBJECT&#125;</code> now states the band. The instant engine states a concrete age too — drawn from the <b>idea</b>, never the variant, so a batch keeps one woman — and an age written in your own idea (a 38-year-old, a 45-year-old) overrides the band and is carried through. The audit measures both directions: any age outside the band warns, and a cast that never states the band is reported.</li>
            <li><b>👗 New: nine outfit tours — one for every wear type.</b> The tours only knew bridal, jewellery, quiet-luxury and hard-sun, so a denim look, a saree, a suit or a gym set had no tour of its own. There is now a second tour file, <b>Outfit tours</b>, with nine registers: <b>👖 Denim</b> (the wash, the fade, the stack at the ankle) · <b>🧥 Coat</b> (the outer layer and the act of taking it off) · <b>🧶 Knit</b> (soft, close, the stitch in the light) · <b>👟 Athleisure</b> (gym to street, fabric under load) · <b>👗 Evening</b> (the gown: the drag, the turn, the back) · <b>✨ Festive ethnic</b> (kurta, co-ord, anarkali — a festival, never a wedding) · <b>🧣 Saree</b> (pleat fan, pallu, border) · <b>🧕 Modest</b> (abaya, kimono, modest co-ord — drape, sleeve, belt, hem) · <b>👔 Tailoring</b> (line, posture, the quarter turn). Each is 12s vertical, <b>Static shot</b>, with four beat flows and full vary dims, and each holds the room-tour laws: the lens is bolted down so every change of frame size is <b>hers</b>, OPEN is a two-to-four-step entrance, CLOSE is the last beat with her eyes on the lens, the beats are <b>her acts</b> — one per beat, hands, gaze and fabric each doing their own thing — and a feature beat fires only when your idea names that element. Name a tour as your idea, and one of its flows to fix the order. Two new garment pools back it: <code>&#123;DENIM AND WASH&#125;</code> and <code>&#123;WEAVE AND TEXTILE&#125;</code>. Nothing in the bridal or jewellery tours was changed.</li>
            <li><b>🏛 New: the room is a place now — never a bare sweep.</b> The tours used to forbid dressing ("nothing in frame but the room, no prop, no set dressing"), which flattened every film onto an empty ground with one light on it. The law is now the opposite, and it lives in the engine as well as in all fifteen tours: the space is built in <b>three planes</b> — a <b>near</b> plane just inside the frame (a doorway or counter edge, a rail, a curtain, a chair back, a plant), the <b>middle</b> where she stands and the beat happens, and a <b>far</b> plane that recedes with its own architecture, material and light (a window, a corridor, panelling, a courtyard, a lit opening, a shaft across the floor). The materials are named, two or three real objects give the place life — a lamp that is on, a chair with a throw, books, a mirror, a bowl, a rug — and one practical source lights it. The dress never performs: nothing moves on its own, nothing takes a beat, nothing blocks her mark or sits hard behind her head, and a minimal set is a choice you can make, never the default. <b>SPACE AND DRESS</b> is a new varying dimension (8 options), so the room changes between variants while she stays the same woman. Your culture guards stay intact: no mandap, no idol, no ritual prop unless you name one, and no religious object in the festive tour.</li>
            <li><b>🩱 New: six more outfit tours — swimwear, bohemian, nightwear, lingerie, ski and streetwear.</b> The tour family now covers <b>fifteen wear types</b>. Each is 12s vertical, <b>Static shot</b>, four flows, full vary dims, and each brings its own garment dimension and pool: <b>🩱 Swimwear and resort</b> (the strap, the tie, the cover-up on and off the shoulders) · <b>🧿 Bohemian</b> (the print, the fringe, the coin belt, the open road) · <b>🌙 Nightwear</b> (the slow morning — silk or brushed cotton under one window) · <b>🖤 Lingerie</b> (the dressing-room film) · <b>🎿 Ski and apres-ski</b> (the long zip, the hood, the cuff over the glove, breath in the air) · <b>🛹 Streetwear</b> (proportions and hardware, the hero sneaker). Two registers carry a restraint guard written into the block: the <b>lingerie</b> tour is a dressing room and not a boudoir — she is dressed throughout, nothing is removed or unfastened, no beat is a reveal, and the camera sits at chest height or above with no low angle — and the <b>swimwear</b> tour keeps the cover-up <i>arranged rather than removed</i>, at the same camera height. Say the tour by name, and a flow ("SNEAKER AND CUFF") if you want the order fixed.</li>
            <li><b>🎭 Every tour now has its own vocabulary, its own mood and grade — and a realism law.</b> A census found the fifteen tours were sharing names: ten of them had a beat called <b>THE WALK</b>, seven had <b>THE BACK</b>, six had <b>THE TURN</b>, and three shared a flow called <b>LAYERS FIRST</b>. All replaced with register-owned names — THE WALL WALK · THE ARRIVAL · THE WALK IN · THE SIX-YARD WALK · THE QUIET WALK · THE CROSSING · THE DECK WALK · THE ROAD WALK · THE BOARDWALK · THE KERB WALK, and the same for the back, the turn, the cuff, the sleeve, the pocket, the strap, the seam, the belt, the hem, the foot, the hood, the layer, the sneaker, the boot, the collar and the robe. Result: <b>119 beat names, every one belonging to a single tour</b> (except <b>THE FACE</b>, which is the close in all fifteen because the law says the last beat is her face), and every flow name owned by one tour except CLOSE FIRST. <b>Every tour now states five fields</b> — MODEL, MOOD, LOCATION, PRESENTATION and AESTHETIC — with <b>MOOD</b> and <b>AESTHETIC AND GRADE</b> as new varying dimensions (8 options each), and no two tours share a mood or a grade. And every tour carries a <b>REALISM FIRST</b> law — the frame is a capture, not a render: skin keeps its texture and fine hair, fabric keeps its weave and the marks of a day, surfaces keep their wear, micro-imperfection is welcome and never takes a beat, with no smoothing, plastic sheen, beauty filter, morphing, floating objects or text in frame — each register naming <b>its own material proof</b> (salt drying on skin, breath vapour in the cold, the yarn's fuzz, lace as thread, dye bleeding at the selvedge, the press of a crease). The law also lives in the engine: the Fashion pack, the shared craft file, the detail-density block pushed into every generation, and both fallback system prompts.</li>
            <li><b>🥁 New: the actions are drawn too — two bridal films can no longer do the same things.</b> You caught the other half of the problem: changing the rhythm is not enough if both films still <b>walk, turn, sit and present identically</b>. The measurement backed you up — the engine drew each shot's act by <b>rotating one fixed list</b>, so two variants got the <b>same four acts in a new order, 100% overlap</b> — and none of the bridal templates declared ACTION, MOVEMENT or PRESENTATION at all, so the contract could not vary what she does even in principle. Fixed at both ends. The act banks were expanded to <b>14–21 acts per motion family</b> (bridal/ethnic holds 21) plus 6 presenting gestures, and each variant now takes <b>its own block of the shuffled bank</b> instead of a rotation: the bank is shuffled once per idea, variant 1 takes the first block, variant 2 the next. Two or three variants of one bridal run now share <b>zero</b> acts — measured — and a wrapped pass is re-shuffled so it can never repeat an earlier variant exactly. The rhythms got the same guarantee: envelopes are <b>stepped by the variant index</b> rather than drawn by hash, so seven generations get seven different shapes (a hash collision had variants 1 and 3 sharing one). Posture is respected too — a seated act never lands inside a flow that walks the ground. On the instruction side the motion plan now states what the acts are <b>and that they are exclusive</b>: <i>&ldquo;this variant&rsquo;s act set — and these acts only … Do NOT stage an act outside this set, not even one the template lists as an example beat.&rdquo;</i> <b>34 templates</b> now vary ACTION · MOVEMENT · PRESENTATION (every bridal tour, both ornament shows, bridal editorial, bridal glamour, photo shoot, the core family, outfit reveal, fashion campaign, intimates, adaptive films), the pools deepened to <b>14 ACTION · 12 MOVEMENT · 12 PRESENTATION</b> options — including the bridal acts from your refs: the veil drawn across and spread overhead, the hand insert, the seated presentation beat, the bangle stack, the gajra, the anklet beat — and the <b>never-share rule now covers the acts</b>: two variants may share a model, a room or a garment, never an edit signature and never an act set. The audit reports a template that varies nothing about what she does. So two bridal variants of one template now differ like this: variant 1 does the hand-to-cuff, the pleats, the embroidery turn and the pallu lift on a <b>clustered</b> rhythm, variant 2 does the veil across the face, the veil overhead, the skirt pooling as she sits and the bangle stack on <b>stutter-then-pop</b> — same woman, same lehenga, two films.</li>
            <li><b>🥁 New: the beats are no longer cut evenly — every variant now draws its own rhythm.</b> You asked for more variation in the beats, and the diagnosis was uncomfortable: the runtime was split into <b>equal windows on every single run</b>, and every 🔀 dimension we offered changed <i>what is in the frame</i>, never <i>how the film is cut</i>. Two variants of one template, different model and different room, still had <b>identical cut times</b> — one film twice. The research says the same thing from the other side: measured across hundreds of films, real shot lengths are neither even nor random — they cluster, long with long and short with short, a <b>1/f &ldquo;pink noise&rdquo; signature</b> (Cutting, DeLong &amp; Nothelfer) — and evenly-cut footage is what reads as machine-made. So the clock now carries <b>seven named rhythm envelopes</b> — flat · <b>slow burn</b> (long opening, accelerating) · <b>decelerating</b> (quick start, lengthening) · <b>bookend</b> (long, tight middle, long) · <b>clustered</b> (the 1/f grouping) · <b>stutter then pop</b> (a burst, then one long hold) · <b>one held opening</b> — and the envelope is drawn from the <b>same seed as the choreography</b>, so variant 1 and variant 3 of one template never share a shape: at 12 seconds variant 1 cuts at 5.2 / 7.9 / 9.9s while variant 3 cuts at 2.5 / 5.0 / 7.9s. Every window keeps the <b>1.5s floor</b> and the windows sum to the runtime <b>exactly</b>; a film with fewer than three shots has no rhythm to shape and falls back to the even split; with no envelope drawn at all, the old timings are reproduced to the millisecond. The model is told the shape in words it can act on: <i>&ldquo;the shot lengths follow a bookend — 5.2s / 2.6s / 2.1s / 2.1s. Write the beats to that shape … Never even out the cut lengths.&rdquo;</i> And the edit is now a first-class varying dimension: <b>eight new FORM pools</b> — RHYTHM ENVELOPE · SCALE LADDER · CUT MOTIVATION · FRAMING DEVICE · OPEN DEVICE · CLOSE DEVICE · TRANSITION · SOUND FORMAT, 45 new options — sit above the content pools in <code>fashion-variation.md</code>, and the variation contract carries a hard rule: <b>two variants may share a model or a location, they may never share an edit signature</b> (rhythm + scale ladder + framing + cut motivation), with the test spelled out — if two variants would cut at similar times, at the same scale order or on the same trigger, they are the same film twice. <b>27 templates</b> now declare the form axes. Two more laws from the AI-video practice research went in with them: <b>every beat carries one micro-gesture</b>, never &ldquo;still&rdquo; (a beat with nothing moving is what makes the model return the same frozen pose every run), and the <b>coverage grid</b> — one beat shot as a 3&times;3 of three distances and three heights, then cut from the nine. One real bug fell out of the work: a 12-second auto film is <b>four</b> shots, but the instant engine only ever wrote the first two — a 20-second film silently lost two of six. The research, with the measured cut times this library now produces, is in <code>docs/beat-variation-2026-09.md</code>.</li>
            <li><b>🚶 Field report: the walk was jumping, the film kept turning its back — and both were our instructions.</b> You tested the bridal outputs and reported exactly that. Three faults were in the words, not the model. <b>1 · The walk was asked to cross a distance.</b> &ldquo;She walks in from the ground&rsquo;s depth&rdquo; asks her to cover metres inside a one-second beat, and a distance the model cannot animate is rendered as a hop, a glide or a teleport — so a walk is now <b>two to four grounded steps</b>, named as steps, at about one step a second, with <b>the floor and her feet in frame</b>, the heel-then-toe contact and the weight passing foot to foot spelled out, its <b>own beat of at least two seconds</b>, and the cut landing on her stop, never mid-stride. <b>2 · She was relocating between cuts.</b> With a locked camera, a subject who reappears somewhere new after every cut reads as a jump even when each shot is perfect, so the law is now <b>the mark is continuous</b>: the walk happens once, in the opening beat, and every later shot finds her in the same spot — cuts change scale and angle, never position. <b>3 · The turns were open-ended.</b> &ldquo;She turns through a full back view&rdquo; is an invitation to finish the film behind her, and two flows literally opened on her back — so the film is now <b>face-forward</b>: at most <b>one</b> beat shows her from behind, about a second and only if the idea names what is read there, written as <b>three-quarters away and back inside the same beat</b>, never the first or last shot. This went into <b>the fashion pack</b>, so every fashion and bridal generation inherits it, and into the templates that contradicted it — while <b>Room outfit tour was left exactly as it is</b>, since it is the one that works. Two more culprits turned up: the <b>ACTION pool</b> was offering &ldquo;walking a straight line toward the lens&rdquo; and &ldquo;turning away and walking out of frame, then glancing back over the far shoulder&rdquo; — both removed — and the older beach, room-showcase, mirror-walk and threshold entrances were corrected too. And the <b>palette-wall bridal show now carries the ref&rsquo;s own beats</b>, which it was missing: the veil drawn down across her face so the frame reads through the net, the veil spread overhead as a canopy, and the hand-on-the-cuff detail insert — plus a <b>BOOKEND</b> flow that repeats the opening frame near the end, the way the reference does. The audit now measures it: a <b>WALK RISK</b> warning fires on any entrance that asks her to cross a distance.</li>
            <li><b>💎 New: two ornament shows built from the refs&rsquo; own grammar — the frame size changes by CUTTING, never by moving the lens.</b> Two jewellery refs came in and were measured frame by frame, and both do the same thing: <b>the camera is locked inside every shot and every scale change arrives with a cut</b>. The fine-jewellery film cuts <b>eight times at almost exactly 1.0s</b> — one piece per cut — and never once shows an ornament without its wearer: the ring close-up keeps her <b>face in frame and softly out of focus behind the hand</b>, the earring beat keeps the jaw and the neck, the choker beat keeps the chin and the collarbone. The yellow bridal film goes the other way: <b>six-second held frames</b> against a wall of repeating carved medallions, the dupatta drawn overhead as a hood, and one transition that dissolves through the sheer veil. So <b>💎 Heirloom jewellery show — one piece per cut, her face in every frame</b> (20s, 9:16, 2K) and <b>🧵 Palette-wall bridal show — she holds the frame, the cut changes the scale</b> (16s, 9:16) ship in a new pack, <code>ornament-shows.md</code>. The two laws the study produced: <b>the hand does the work</b> — her own hand is on the piece in every jewellery beat, which is what gives a close-up its context — and <b>the wide reset</b>, so no more than three tight (or held) frames run before a wider frame brings her whole look back. The jewellery show also closes on the <b>mid-close of the whole look rather than the tightest macro</b>, and takes an optional <b>brand wordmark</b>, spelled exactly and held once over the close — nothing else in the frame is ever lettered. Two origins of those refs are kept and now point at their rebuilds, and the audit stops flagging a superseded template once its description names its successor: <b>0 errors, 2 warnings left in the whole library</b> — an e-commerce 4-up collage and a labelled 3D classroom explainer, where the travelling camera <i>is</i> the format. The study, with the measured cut times, is in <code>docs/refs-ornament-shows-2026-09.md</code>.</li>
            <li><b>📸 New: <i>Photo shoot — the set is in the film</i>, where the crew is an option you name.</b> A model shoot filmed as a shoot. The woman, the place, her complete look, her movement, her action and the camera all draw from the pools per generation — <b>run three variants and nothing repeats</b> — and one new dimension sits beside them: <b>CREW</b>. Name a crew and the film cuts to them, once, about a second long: the photographer at the shutter, an assistant turning the reflector with her still lit in frame, a stylist&rsquo;s hand at the hem, the two of them over the back of the camera, or a wider frame showing the room as a set. Write <b>NONE</b> and no crew member, hand, stand or shadow ever enters the frame — the shoot reads in the shutter click and the light alone. The laws that keep it a shoot rather than a behind-the-scenes clip: the crew cutaway is <b>never the first or the last shot</b>, it never breaks the one light design, the crew never speak (their voices stay muffled under the picture), and it is capped by the runtime — <b>one crew beat per three seconds, two at most in four shots</b>. The film opens and closes on her whatever the crew does, the lens stays locked inside every shot with every scale change caused by her walking or stepping in, and the beat flow library (six flows: ARRIVE TO SHUTTER · CUT ON THE SHUTTER · SETUP TO SETUP · HER FIRST CREW LATE · RESET RHYTHM · ONE FRAME TOO) re-orders her beats and never adds one. <b>RESET RHYTHM</b> is the beat that makes it read as a shoot at all — she breaks the pose on purpose, breathes, and re-enters. For an identity that survives every cut, the tip names the reference route: attach your character reference / reference sheet, the <code>.char</code> way, so the same face, body and clothes hold across all the framings.</li>
            <li><b>🎬 The templates we built from the video refs were rebuilt — and we now know exactly why they underperformed.</b> You said none of them was as good as <b>Room outfit tour</b>, so the difference was measured instead of guessed. In the ref-derived films <b>the camera did the travelling and she stood still</b>: the bridal jewellery show changed frame size <b>11 times, not once because she moved</b>; the macro ladder, one camera move, none by her. The room tour is the exact inverse — <b>0 camera moves, 5 scale changes caused by her</b> — and that is most of the difference between a film and a slideshow of framings. The refs also spent their brief on all-caps law (1,455–2,062 words against 807) and asked for up to 3.3 beats a second, which cannot be filmed. So six rebuilds ship in a new pack, <code>tour-grammar.md</code> — <b>🧵 Bridal tour · 💎 Jewellery tour · 🧵 Quiet-luxury tour · ☀️ Hard-sun tour · 👑 Bridal glamour tour · 💎 Bridal jewellery tour</b> — each keeping its parent's register and taking the room tour's mechanics: a locked camera, beats written as <i>her</i> acts, one act per second, a flow library that re-orders named beats and never adds one, OPEN walk-in first, CLOSE gaze-hold last. <b>Nothing was overwritten</b> — the six originals are untouched and each points at its rebuild. And the audit now measures it on every file: <code>npm run audit:templates</code> warns on <b>slideshow risk</b> (camera-tasks outnumbering her acts) and on a camera doing the travelling in any film with a person in it. The measurements and the five reasons are written up in <code>docs/why-the-room-tour-works.md</code>.</li>
            <li><b>📸 The studio templates now work the way Room outfit tour does.</b> The studio look shoot used to carry three fixed beats and five fields; it now runs the same adaptive engine as the room tour — <b>every garment detail you name becomes its own beat</b> (cuff, placket, seam, waistband, pocket, shoulder, hem, rib, lining), <b>OPEN first, CLOSE last</b>, one act of 1–1.5s per beat, skip any detail you did not name and never invent one, with <b>six defined flows</b> (<code>STILL THEN DETAIL · DETAIL THEN FULL · HAND IN POCKET · SIT AND SETTLE · SEAM CASCADE · LIGHT RAKE</code>) and <b>nine live dimensions</b>. The palette became a live field — cream is one option, not the rule — and there is a second studio template now, <b>Hard-sun studio — shadow play</b>, for the saturated references (the denim bralette in hard sun, the block-print dress on concrete) where the sun writes the composition. The <b>E-commerce 4-up</b> collage also finally defines the four flows it had only named.</li>
            <li><b>🛠️ The template is a shoot, not a shot.</b> A 12s look film was being told it was "exactly three shots with timed cuts", so its beats got stretched to fill three long windows — that is why the doorway film crawled next to the ref. The Structure row now offers <b>Auto cuts</b>: the runtime earns the shots (~one per 3s, 1–6) and the beats keep their ~1.5s rhythm <i>inside</i> each shot, running straight through the cuts. With no line written, clips are <b>wordless by default</b> (a line only when your idea asks for speech or the format is a dialogue/ad read), and the prose may no longer stack parenthetical production notes or contradict itself. The <b>Heritage doorway</b> block was corrected against its own ref too: the fabric is the light at the threshold (never an unlit silhouette), one macro pass with her still in frame, and the veil portrait to close.</li>
            <li><b>👰 New: the dynamic bridal jewellery show.</b> <b>Bridal jewellery show — five spots, one closing orbit</b> takes your arc and makes everything inside it yours: full body, then the torso with the neck stack and the <code>kamar bandh</code>, then the face with the maang tikka and the nath, then the hands with the mehendi and the veil, then the ankles and footwear on a left-to-right orbit — and that same orbit rises and pulls back until she is full body again, smiling down the lens. The five spots come from your location field, every beat is keyed to an ornament you actually name (skip it and the beat is not shot, never an invented piece or spot), six flows re-order the beats, nine fields set the look, and every macro keeps her in frame — never the ornament alone on black.</li>
            <li><b>🩲 Innerwear only where it is seen.</b> The closed-stack fix (v2.13) had over-corrected: every outfit was getting a camisole, bodysuit or bralette-and-brief, even looks nothing can be seen through — and a lehenga collected a second bottom. Now <b>coverage follows exposure</b>: an outer piece goes over a named inner <i>garment</i>, a bottom or the garment's own lower half is stated, footwear is named — and a base layer is named <b>only where the cut shows it</b> (sheer, net, plunged, open-backed, cut out, slit, bare midriff). A closed, lined look names no innerwear at all; intimate wear gets nothing added under it or over it; and a bottom you already named is never invented twice. The linter gives an advisory note when a covered look names underwear anyway.</li>
            <li><b>🎥 The bridal show's camera, calmed down.</b> Auto camera used to ignore amplitude and speed, so the sweep was the model's choice — templates can now pin <code>amp:</code> and <code>speed:</code> (only real values pass) and the bridal film ships <b>small + slow</b>. New engine law: a <b>reading beat</b> — when a beat exists to show something, the frame holds still ~1.5s and the camera moves <i>between</i> details, never across them. And the film is now <b>18s / six shots, one beat each</b> (the duration ceiling moved 15 → 20 to match the clock): the closing orbit <b>climbs her body</b> — hem, waist and kamar bandh, neck stack, then her face closest and longest — before it settles wide, so the head and the jewellery are actually viewed. If the runtime gives fewer shots than ornament families, two families merge into one beat rather than the camera speeding up.</li>
            <li><b>👰 2026 bridal design register.</b> The bridal film now asks for <i>design decisions</i>, not categories: fabric and weight (raw silk, tissue, organza, dupion, brocade), silhouette (cape lehenga, pre-draped saree-gown, fish-cut, mermaid, jacket lehenga, heirloom re-cut), the <b>blouse as the hero piece</b>, one embroidery <b>technique with its motif</b> (gota patti, zardozi, bandhani, meenakari, jaali) — and jewellery <b>styled</b> rather than listed: one dominant piece with everything answering it, a choker with one long haar, polki raw, temple gold for the traditional register, pastel stones on pastel fabric, with the balance rule (an oversized tikka runs with medium earrings, never full jhumkas as well). The pools in <code>fashion-variation.md</code> carry ~70 specific options for the bridal dimensions, and the &#34;over for 2026&#34; list is named so it stops defaulting to it: mirror-work disco-ball lehengas, ten-kilo velvet and vague &#34;zari work&#34;. The anklet beat became <b>THE GROUND</b> — border, juttis and anklets read together in one low three-quarter frame with her still in shot — and it is the first beat dropped when the runtime is tight. The no-LLM engine draws modern bridal silhouettes too.</li>
            <li><b>🛟 Fixed: a crash on the Templates and Learn pages — and that class of crash is now impossible to ship.</b> Two components touched in the last pass died at first paint: the templates library referenced its own list before that list existed, and the template card called an imported helper through a local variable of the same name. The production build compiled both happily — <b>a build cannot see this kind of fault, only running the component can</b> — so the app now ships a <b>render smoke test</b> (<code>npm run smoke</code>) that compiles each component with the real JSX and renders them all, catching exactly this. Both crashes are fixed, and a new <b>error boundary</b> wraps the Studio, Templates and Learn views: if anything ever throws again you get a card naming the message and the component, with <b>↺ Try again</b>, <b>⟳ Reload</b> and <b>📋 Copy the error</b> — never a blank page.</li>
            <li><b>🔎 The whole library went through an audit — and the category bug is fixed.</b> Every one of the 136 templates was checked against everything we have built since the first ones shipped: closed stack, colour always stated, innerwear only where seen, wearer-in-frame, calm camera, derived cuts, token budget, tags that the picker can actually group. <b>Fashion/Lifestyle templates can no longer appear under 👤 Person</b> — that was a real bug: the picker grouped by the <code>tag:</code> line, so a template whose tag said <code>person</code> vanished into Person even when its category said Fashion. The tag vocabulary now lives in <b>one file</b> (<code>src/lib/tags.js</code>) instead of three drifting copies, three tags that had no label anywhere (<code>preset</code>, <code>immersive</code>, <code>medical</code> — 25 templates that could not be filtered) now have one, and <b>the category decides the group</b>, so a misfiled tag can never hide a template again. Stamped cut times are gone from every skeleton — <b>a cut is never stated in seconds</b>, it is derived from the live clock, so changing the duration can no longer leave a template describing a cut that no longer happens there — and 129 timing lines now say their budget is a proportion of the runtime. Five over-long placeholder tokens were brought back under budget. Nothing was overwritten: <b>three new adaptive templates</b> (🎬 UGC ad · 👗 Fashion preset film · 🧥 Lookbook film) ship as the 2026 versions of eleven older presets, and each of those presets now points to its successor. Run <code>npm run audit:templates</code> any time — it reports only what is actually wrong, and says which laws the engine and the packs already carry.</li>
            <li><b>⚙️ The Engine card moved into Settings — and Settings became a real panel.</b> Engine, model, model name, variant count, temperature and the generation switches (🎨 detail, 📚 few-shot, 🧪 critic, ✨ enhance, 🔞 18+) used to sit in a big card in the Studio form, two screens away from the provider and model list they depend on. They now live in <b>⚙️ Settings → 🎛 Engine</b>, which opens with a <b>&#34;next generation runs…&#34;</b> strip so you can see the mode, model, variants and switches before you touch anything. The panel is now four tabs instead of one long scroll — <b>🎛 Engine</b> · <b>🤖 Provider</b> (keys, Ollama/local endpoints, the live model list) · <b>📄 System prompts</b> (routing, dependencies, attachments) · <b>📂 Templates</b> (paste, scan, import) — with a connection pill in the tab bar. The Studio form keeps a one-line summary and two buttons that jump straight to the right tab, and it follows any change you make there immediately, so the two can never disagree. Settings persist in the browser, a corrupt stored value falls back to the defaults instead of breaking the app, and <b>↺ Reset defaults</b> restores the shipping engine. The 18+ switch moved with the rest — it keeps its original storage key, so the prompt-routing gate reads exactly what it always read.</li>
            <li><b>🇮🇳 Indian bridal is now a branch, not a coincidence.</b> The modern bridal glamour tour used to describe a Western couture film — a corset, a sapphire choker, a concrete atrium — and could hand that back for a plain &#34;Indian bridal glamour&#34; request. It now reads the request first: the moment the idea names an Indian bride or wedding (bride, shaadi, lehenga, choli, dupatta, saree, mehendi, sangeet, tikka), <b>every element stays Indian and modern at once</b> — an Indian silhouette built like couture (corseted lehenga, pre-draped concept saree, saree-gown, cape lehenga), <b>Indian high jewellery</b> (a choker with its maang tikka, a nath when you name one, stacked bangles, a kamar bandh), Indian glam beauty, and an Indian contemporary set — never a ballgown, never ear architecture where a tikka belongs, never a Western room. In that branch the coordinated set is <i>correct</i> rather than banned. The pools were rewritten to match (<code>GLAM GARMENT</code>, <code>LUXE JEWELS</code>, <code>GLAM BEAUTY</code>, <code>MODERN SET</code>), the fashion pack says it for every fashion request, and a new <b>TOKEN DISCIPLINE</b> rule stops a field name like <code>&#123;GLAM LIGHT&#125;</code> from ever reaching the finished prompt as text.</li>
            <li><b>🧵 Template: Bridal editorial — veil, border and bodice ladder.</b> The register the refs actually show, and not the same film as the other two bridal templates. <b>One ground, no tour</b>: a single seamless sweep (a deep-green paper sweep is the house look), the camera locked off, and scale changed by <b>cutting</b> — never by zooming or walking her through rooms. The <b>veil is the device</b>: over the head, then drawn <b>across the face</b> in the film&#39;s signature beat, then held. Then the <b>ladder on her body</b> — bodice and neckline with the choker on her collarbone, a true macro on the worked hem or veil border with her hand in frame, the waist and the <code>kamar bandh</code>, the sleeve and bangle stack, a <b>back beat</b> where the blouse ties, the face close with the maang tikka and the nath, and the hem with the footwear as a three-quarter frame. Six flows, nine live fields. Two laws keep it expensive: <b>the embroidery must name its technique and motif</b> (zardozi with dabka, resham, marori, pearl-and-bead fringe, kiron — machine mirror sparkle is named as <i>out</i>) and <b>materials must separate</b> — metal as metal, thread as matte thread, pearls as pearl, no one gloss over everything. Three new pools back it (<code>EMBROIDERY</code>, <code>HEIRLOOM PALETTE</code>, <code>STUDIO GROUND</code>), and the garment pool now says outright that <b>heavy hand work is wanted</b> — the earlier &#34;light beats heavy&#34; line was pulling the model away from exactly this look.</li>
            <li><b>✨ Modern bridal glamour tour — couture, not costume.</b> A second bridal register, kept in its own file so the heritage one stays intact. This decade's couture instead of the catalogue: sculptural corsetry, liquid metallics, crystal, architectural rooms and <b>high jewellery worn as styling</b> — a diamond rivière choker alone, three layered fine chains, a body chain across a bare back, an ear cuff climbing the helix. The tour runs the way the room tour does — <b>OPEN at full length, one named element per beat</b> (bodice, train, sparkle, neck, head, hands, waist, back, hem and shoes, the glamour close), <b>CLOSE last</b>, six flows, nine live fields. Two laws make it land: <b>&#34;expensive is specific&#34;</b> (state the fabric, the boning, the hand-set crystal, the horsehair hem — construction reads as couture, vague embroidery reads as costume) and <b>the register is enforced</b> (no haveli, jharokha, marigold, mirror work or polki-kundan parure unless you write those words; no warm nostalgic grade). Seven new pools back it, and the fashion pack now says <i>pick one of the three bridal registers and commit — never default to heritage</i>.</li>
            <li><b>🎬 The beats are derived now, not hard-coded.</b> The templates built from the reference videos used to carry a fixed shot list and fixed cut times (<code>3 stamped shots of 4s, cuts at 00:04.000 and 00:08.000</code>) — so every idea rendered the same clip and the beats fought whatever runtime you picked. Now a <b>choreography engine</b> (<code>src/lib/choreography.js</code>) reads each idea at generation time and derives four things: <b>how she moves</b> (the garment's physics — chiffon flies and settles late, tailoring turns and stops dead, satin carries the light, lehenga pleats swing and restack), <b>how she presents the piece</b> (an ornament is a ladder, a dressing sequence is the act of putting things on, a walk is an approach), <b>how the camera behaves</b> (establish wide, then tighten by cutting — never zoom), and <b>where the cuts land</b> (on a movement's peak, a footfall, a settle, a glint — never mid-gesture). The plan rides into every H3 and LTX request with the phrase <i>keep the template's laws, rebuild its beats</i>, the instant engine uses the same grammar, and a new linter check <b>🧭 Beat derivation</b> flags any block that stamps cuts and a fixed shot count with no flow library and no derivation rule.</li>
            <li><b>🧩 A file of yours that is older than the build can no longer stop the app loading.</b> Patch safety means your edited <code>src/lib/filler.js</code> or <code>colourbank.js</code> is never overwritten — the new version is parked beside it as <code>&lt;file&gt;.new</code>. The sharp edge was that the rest of the patch was written against the new version, and an ES module that imports a missing <i>name</i> fails at link time before any code runs (<code>does not provide an export named …</code>). Now the app links those two files by namespace (<code>src/lib/colourlink.js</code>): if a function is missing the <b>feature</b> degrades and the console names the file to take, instead of the whole bundle dying. And <code>PATCH-REPORT.md</code> now lists, under every conflict, the other files in that patch which import it.</li>
            <li><b>💎 A jewellery beat is shot on her, never on the piece alone.</b> The reference films all open on the model — the whole look in the room with the complete set legible at real scale — and only then move closer, and every insert after that stays anchored on her body: the necklace on the collarbone, the earring against the jaw, the ring on a hand at the waist with the skirt and the midriff in frame. That is now the <b>Jewellery macro ladder</b> template (its first flow is <code>FULL THEN LADDER</code>, its default runtime 2K so the opening wide keeps the face), a rule in the shared craft doctrine that all four system prompts include, in the 🎨 Fashion pack, in the Forge's house rules — and a new advisory linter check <b>📸 Wearer in frame</b> that flags any jewellery template which opens on a macro or floats the piece with no wearer.</li>
            <li><b>Your own banks — attach them instead of editing prompts.</b> Drop any <code>.md</code> into <code>public/prompts/banks/</code> (dialogue bank, secondary-action bank, examples, wardrobe bible). Then either add one line to a prompt file — <code>@include banks/dialogue-bank.md</code> — or attach it in the app: ⚙️ <b>Settings → System prompt routing → 🧩</b>, per row (🌐 all generations, H3/LTX, SFW/18+). Attached files are appended to the system prompt for those generations only, their own <code>@include</code>s are resolved, they show as removable chips, and every generation logs <code>🧩 attached context: …</code>. <b>A <code>📎 0</code> in the routing panel simply means that prompt file includes nothing of its own</b> — the row now says so in words.</li>
            <li><b>Updates can't overwrite your work.</b> Replace the old "download everything and merge by hand" routine with the <code>apply.mjs</code> that rides inside every patch (<code>node apply.mjs --into your-project</code> — plain Node, nothing to install), or <code>npm run patch -- patch.zip</code> once it is in. A file of yours is only replaced when it is <i>byte-identical</i> to the version we shipped; otherwise your copy stays and the incoming one is written beside it as <code>&lt;file&gt;.new</code>, listed in <code>PATCH-REPORT.md</code>. Nothing is ever deleted, and these are never touched at all: <code>banks/**</code>, <code>user/**</code>, <code>mature-addendum.md</code>, <code>*mature*.md</code>, <code>templates/user-*.md</code>, <code>.env</code> — add more in <code>patch.config.json</code>. To publish a patch yourself: <code>npm run snapshot</code> → edit → <code>npm run make-patch -- v1.2</code>. Full procedure: <code>docs/YOUR-FILES-AND-UPDATES.md</code>.</li>
            <li><b>🗣️ Dialogue that comes out of her mouth, not out of the air.</b> A line written as speech must be <i>spoken on camera</i> — her face in frame, lips moving with every word, nothing over her mouth — and that rule now lives in <code>prompts/shared/on-camera-speech.md</code>, included by both SFW system prompts and enforced in the request builder. A voiceover is a different thing and is only used when you ask for one (it must say <i>off-screen voiceover</i> and that her lips stay closed). Words are budgeted against the clock: 5-8 words ≈ 1.5-2s, 9-15 words ≈ 2.5-3s, so a 10s clip holds three short spoken beats at most. Intelligible speech is never written into <code>overall_soundscape</code> — that field is ambience and non-verbal sound only, which is exactly how a scripted line turns into background chatter.</li>
            <li><b>👗🎤 Outfit reveal — the spoken detail tour.</b> A look-book where she presents the outfit herself: the first field is the <b>STYLE TYPE</b> (tradition, office wear, swimwear, evening, bridal, resort, streetwear, athleisure, cocktail, winter, lingerie — each with its own pool option), and from it follow the garment family, the room, the footwear and the register of her voice. Then one garment detail per shot: <b>a hand laid on the neckline plus one short line about it</b>, then the waist, then the back, then the hem or the shoe, then a closing attitude line. She also works the room — a chair back, a doorframe, a parted curtain, a ledge, a table — one contact per shot. Her lines carry her own taste and self-possession, never a sales pitch, and the camera serves her rather than appraising her. Four flows ship with it (TOUCH AND TELL · MIRROR CONFESSION · FEET FIRST · WORLD FIRST), and its chain recipe <i>Wardrobe series — one woman, many style types</i> runs the same woman through five style types with a spoken line in each scene.</li>
            <li><b>🔀 Rearranging a chain.</b> Chain order is editable in both places. On the <b>Templates page</b> in 🔗 Chain mode each pick carries <b>◀ ▶</b> (move one scene earlier/later), <b>⇤ ⇥</b> (send it to the front or the back), <b>✕</b> (remove) and <b>⇅</b> (reverse the whole chain). In the <b>builder's chain planner</b> every scene row now has <b>↑ ↓</b>, and the scene you were Directing stays selected after a move (numbering and the previous-scene end-state hand-off follow the new order). Reorder any time — before or after generating.</li>
            <li><b>🎨 Garment colour is a field now, not a hope.</b> The reason outfits kept rendering white: the garment placeholders asked for <i>silhouette, fabric, construction detail</i> and never a colour — across <b>30+ templates</b>, under many token names (<code>&#123;GARMENT&#125;</code>, <code>&#123;DRESS&#125;</code>, <code>&#123;SKIRT&#125;</code>, <code>&#123;TOP&#125;</code>, <code>&#123;ETHNIC SET&#125;</code>…), so the model fell back to its own default (white) — and four of the fashion exemplars did the same. Fixed in four places: <code>&#123;OUTFIT COLOUR&#125;</code> is a live field on every fashion template and a 🔀 varying dimension (12 colour families with finishes in <code>fashion-variation.md</code>), the fashion pack carries a <b>Colour</b> doctrine (name colour + finish together; never default to white/ivory/cream; 60/30/10 areas plus one metal family; place each colour against the room's light), the white-anchored exemplars were rebalanced, and the instant engine (no LLM) got a wardrobe bank that names a colour whenever a fashion idea arrives without one, and every <code>&#123;OUTFIT DESIGN&#125;</code> pool option now names its colour. If you <i>want</i> white, ask for white with texture — it is a choice, not the default.</li>
            <li><b>🕶️ Immersive: 360° and VR180 templates.</b> Two templates in <code>prompts/templates/immersive.md</code> for the two H3 LoRAs: <i>Equirectangular 360 — sphere tour</i> (trigger <code>equirect360</code> + the official layout sentence, 21:9 · 768P · 5s, wrap-seam and polar-band rules, resize to 2:1 never crop) and <i>VR180 stereo pair — immersive walk</i> (trigger <code>vr180sbs</code> + layout sentence, one continuous take, subject held 1.5–4 m away, no fast pans, no text anywhere, plus the ffmpeg + <code>spatialmedia</code> packaging command). Both are in the LoRA library with their settings, so the picker prepends the trigger words for local runs.</li>
            <li><b>🩺 Medical &amp; science animation.</b> Six templates in <code>prompts/templates/medical-education.md</code> with a new <code>packs/medical.md</code> domain pack behind them: <i>MOA film</i> (mechanism as a physical event — target, contact, cascade, outcome), <i>Disease-state journey</i> (one anchor view returned to, patient-safe), <i>Classroom concept explainer</i> (the Designmate / Eureka.in teaching format — bright even light, one idea per beat, at most three on-screen labels), and <i>Hybrid explainer</i> (real footage cut against 3D inserts that match angle, light and distance — the format that measurably beats either half alone), <i>Physiology cycle — seamless teaching loop</i> (last frame = first frame by contract, every displacement returns), and <i>Patient-education short — vertical</i> (9:16, calm, one takeaway, phone-safe framing, honest narration). The pack enforces plausible anatomy, no gore, no invented labels, scale continuity and plausible sound; medical content is written as illustration, never as advice.</li>
            <li><b>👗 Expand outfit — the wardrobe line, engineered.</b> Fashion templates ask for an <code>&#123;OUTFIT DESIGN&#125;</code> value: the 🧩 Fill-the-blanks dialog now offers <b>👗 Expand outfit</b>, which runs <code>prompts/fashion-outfit-expander.md</code> and drops one expert garment line straight into that field. The file keeps your rule (exactly one line, 100% of your brief preserved verbatim, no angle brackets) and adds what a line usually lacks: construction vocabulary that replaces adjectives ("flowy" → <i>bias-cut silk crepe, 22-momme</i>), legal garment labels by structure (<code>Main:</code> for one-piece, <code>Top:/Bottom:</code> for two-piece, <code>Choli:/Ghagra:/Dupatta:</code> for a lehenga, full draping for a sari), a three-colour 60/30/10 palette rule, an executable era table, seven-part footwear, true-to-category intimate wear, a byte-stable re-call name so the same outfit survives a shoot, variation by axis, and a ten-point self-check the model must pass before it emits. Edit it like any other prompt file, or point a routing slot at it when the job is a wardrobe line rather than a shot.</li>
            <li><b>🔗 Chaining templates (one shoot, many looks).</b> On the Templates page, <b>🔗 Chain mode</b> turns the cards into ticks: pick templates <i>in the order you want the scenes</i>, then <b>➜ Send chain to Builder</b>. The builder opens with one scene per template (each keeping its own skeleton and 🧩 fields) and asks the planner to write the consistency bible in <b>TEMPLATE CHAIN mode</b> — the person stays identical (face, hair, skin, build, sole subject) while every scene gets its own room, its own named light and its own garment, with one directable action per scene. No provider? A rule-based bible is written anyway. A template that declares <code>chain: 4</code> is a <b>chain recipe</b>: its card shows a 🔗 pill and its button sends all four scenes in one click — the shipped example is <i>Photo-shoot tour chain — same model, many rooms</i>, which pairs with <i>Room photo shoot — every dimension dynamic</i> (one template = one room = one photo shoot, with EIGHT live dimensions — location, model, clothing, movement, presentation, action, interaction and camera — so nothing about the shoot is fixed except the format). Then hit <b>⚡ Generate all scenes</b>, render scene 1, and feed each clip's last frame into the next scene (Direct arms I2V for you). To author your own recipe, the 🔨 Forge has a <b>chain recipe</b> toggle that asks for <code>chain:</code> and <code>chainrule:</code> lines.</li>
            <li><b>System prompts can depend on other files — step by step.</b> A system prompt may pull in as many extra files as you like; each one is inlined where its line sits.
              <ol style={{ margin: '6px 0 0', paddingLeft: 20 }}>
                <li>Put your file in <code>public/prompts/</code> — e.g. <code>public/prompts/my-rules.md</code> (a subfolder also works: <code>public/prompts/shared/my-rules.md</code>).</li>
                <li>Open the prompt you want it appended to and add ONE line where you want the text to appear — <code>@include my-rules.md</code> (same folder), <code>@include shared/my-rules.md</code> (subfolder file included from the prompt file), or <code>@include packs/ugc.md</code> (root-relative, works from any depth). <code>@import …</code> and <code>[[include: …]]</code> do the same thing. The line must be alone on its own line.</li>
                <li>Reload: ⚙️ Settings → <b>↻ Reload from file</b>, or just refresh the page.</li>
                <li>Confirm: ⚙️ Settings → System prompt shows a row per prompt file (H3 · SFW, LTX · SFW, <b>H3 · 18+</b>, LTX · 18+) with its size, <code>📎 n</code> and the paths it pulled in. A wrong path shows <b>⚠ missing …</b> there instead of breaking the prompt, and the <code>ollama</code> console line names the files inlined on every generation.</li>
              </ol>
              <b>Choosing which prompt is used (⚙️ Settings → System prompt routing):</b> <b>🌐 Universal</b> = one file for every generation (H3 + LTX, SFW + 18+); the four slot rows (<code>H3 · SFW</code>, <code>LTX · SFW</code>, <code>H3 · 18+</code>, <code>LTX · 18+</code>) each pick their own file and stay independent — a slot left on <i>Auto</i> keeps the default fourth-file behaviour, so mixing (own file for 18+, defaults for SFW) works. <b>📂 Upload .md → universal</b> makes any local file the universal prompt immediately, resolves its <code>@include</code>s and remembers it in this browser. Routing is per generation and the console line always names the source: <code>🌐 universal prompts/my-file.md</code>, <code>🎯 routed …</code>, <code>🔞 mature file system-prompt-mature.md</code> or <code>⚠ SFW fallback</code>. A routed file that goes missing is reported, never silently swapped. <b>Mature craft is one file too:</b> <code>public/prompts/shared/mature-craft.md</code> is included by both mature prompts (<code>@include shared/mature-craft.md</code>), so H3 and LTX 18+ never drift apart — edit it once and both change. It carries the guardrails (fictional adults only, consent readable), the explicitness ladder, mature cinematography, and the official H3 split applied to mature scenes: <code>&lt;d&gt;[Language] …&lt;/d&gt;</code> for intelligible speech only while breath, gasps and moans go to <code>overall_soundscape</code> as non-verbal human sound, the exact voiceover phrasing, and the soundscape/music sentence budgets. Your own direction still lives in <code>mature-addendum.md</code>, included after it. <code>&lt;!-- HTML comments --&gt;</code> in any prompt file are the author's notes: they are stripped before the prompt reaches the model and a directive written inside one is never treated as an include.<br /><b>For 18+ work specifically:</b> edit <code>public/prompts/system-prompt-mature.md</code> (H3) or <code>public/prompts/ltx-system-prompt-mature.md</code> (LTX). Both already depend on two files — <code>@include shared/craft-detail-and-cast.md</code> (the shared craft rule) and <code>@include mature-addendum.md</code> (a second file made for exactly this). Write your own direction into <code>public/prompts/mature-addendum.md</code>, or point that line at a file of your own. Mature prompts are only used while the 18+ switch is on, so the addendum only reaches the model on mature generations — and because it lives in its own file, nothing you write there can be overwritten by an app update to the base prompt.</li>
            <li><b>Characters are fictional — by design.</b> Never write a real actor, celebrity or public figure into a prompt and never ask for a named likeness: the model has no licensed face, so you get either a vague approximation or mush, and the platforms block it. Name the role, era, wardrobe, light and performance instead — that is what actually makes the scene read. If you need a specific face, attach <i>your own</i> talent's photo under 🖼️ Reference assets with the job "talent — preserve identity" and let the identity reference do that work.</li>
          </ul>
          <p>Three add-ons that turn prompts into film-grade packages:</p>
          <ul className="glist">
            <li><b>👤 Characters</b> — add a card per character: name, <b>2–3 signature anchors</b> (repeated VERBATIM in every prompt), attributes, wardrobe, voice notes. Attach one canonical portrait under 🖼 Reference assets (job: identity). Cards travel into every generation and every chain scene — and per the research, prompts then describe only action and camera, because re-describing identity is the #1 drift cause.</li>
            <li><b>🔊 Native audio</b> — H3 and LTX generate synchronized audio in one pass. The Sound section now has <b>Foley & cues</b> (sounds landing on matching beats) and <b>Audio design</b> (music dips, room tone, accents on cuts), plus the <b>🔊 A2V</b> workflow where an attached audio track drives the visuals.</li>
            <li><b>🧪 Critique</b> — a <b>switch</b> in Engine → Options (default OFF, because each critique costs an LLM call): armed, every output card shows a Critique button — your LLM scores it 0–100 across clarity / camera / continuity / audio / pacing / conformance, lists concrete issues, and offers <b>✨ Apply fix</b> to rewrite the prompt in place. With no provider connected, a heuristic grammar check stands in.</li>
          </ul>
          <Tip>Best loop: Auto-plan → 🧪 Critique the weakest card → ✨ Apply fix → render. The Critic is deliberately strict — a 90+ is genuinely film-ready.</Tip>
        </Sec>

        <Sec id="camera" icon="🛰️" title="Camera Director">
          <p>A focused workbench for converting prompts between the two platforms: paste any H3 prompt → get the LTX paragraph equivalent (and vice-versa), via your connected model or the instant offline converter.</p>
          <Steps items={[
            <>Open <b>🛰️ Camera Director</b> → paste a prompt → choose direction (H3 → LTX or LTX → H3).</>,
            <>Convert — with a provider connected you get a true LLM rewrite; offline you get the instant structural converter.</>,
            <>Send the result to the Input Builder or copy it directly.</>,
          ]} />
        </Sec>

        <Sec id="learn" icon="📚" title="Learn tab">
          <ul className="glist">
            <li><b>📐 Templates</b> — browse all blocks with tag + category filters; ➜ Send to Input Builder, ✏️ Edit.</li>
            <li><b>🎬 Real example prompts</b> — the curated exemplar corpus (also used as few-shot teaching when enabled).</li>
            <li><b>🧬 LoRAs</b> — full library, filter by target, ➜ Arm in builder, 📋 Copy trigger.</li>
            <li><b>💡 Tips</b> — cheat-cards: shot budgets, garment intelligence, IC contracts, frame reading, mature craft…</li>
            <li><b>System prompts</b> — view exactly what the SFW/mature system messages contain.</li>
          </ul>
        </Sec>

        <Sec id="history" icon="🕘" title="History">
          <p>Every generation is stored locally (localStorage). Reuse restores the full setup — idea, settings, chain context — back into the builder; delete or clear anytime. Nothing leaves your machine.</p>
        </Sec>

        <Sec id="engine" icon="⚙️" title="Engines & providers">
          <ul className="glist">
            <li><b>Engine: Auto</b> — provider when reachable, instant offline engine otherwise (offline never leaves you stranded).</li>
            <li><b>Engine: Ollama</b> — strict local mode; failures stay visible (good for testing).</li>
            <li><b>Engine: Instant offline</b> — deterministic template composer, zero latency.</li>
            <li><b>Providers</b> — Ollama native, 🖥️ Local inference (llama.cpp / vLLM / LM Studio for int8/Q8 models), OpenRouter (one key, 100+ hosted models, live model list), Groq, Gemini, or any OpenAI-compatible endpoint via ⚙️ Settings.</li>
            <li><b>🖥️ Local inference</b> — run small quantized models without Ollama: <code>llama-server -m qwen2.5-7b-instruct-q8_0.gguf</code> and pick the 🖥️ preset in Settings. Q8/int8 builds are smaller, faster, and stay offline.</li>
            <li><b>No length limit anywhere.</b> The app never caps, trims or truncates a prompt — not the description, not the six Ref2VA sections, not the chain hand-off. the app asks Ollama for a generous positive output cap instead of a negative one (see <b>Token caps</b> below), so the answer is never cut off mid-sentence. The output card shows the size purely as information. The only real bound is how much context your local model holds: if you write very long prompts, raise it on your Ollama server (e.g. <code>OLLAMA_CONTEXT_LENGTH=32768</code>, or a larger <code>num_ctx</code>) so the system prompt, the domain packs and your answer all fit together. <br /><b>Token caps:</b> the app asks Ollama for a generous output cap (16,384 tokens). Some newer or hosted builds reject any explicit cap — if yours does, the app steps down automatically (4096 → 2048 → no cap) and remembers what worked, so you never see a failed call or a truncated prompt.</li>
            <li><b>Variants 1–3</b> with rising temperature; <b>few-shot exemplars</b> teach the model format; <b>keep_alive:0</b> unloads the model after each generation to free RAM/VRAM.</li>
          </ul>
          <Tip>Models: qwen2.5:7b-instruct is the sweet spot for contracts; qwen2.5:14b or gemma3:12b if you have 12 GB+. gemma3 doubles as your frame-reading vision model.</Tip>
        </Sec>

        <Sec id="mature" icon="🔞" title="SFW / mature routing & kill switch">
          <p>SFW and mature use <b>completely separate system prompt files</b> — nothing conflicts, and mature can be blocked instantly.</p>
          <ul className="glist">
            <li><b>Toggle OFF</b> → always the SFW prompts (explicit content policy).</li>
            <li><b>Toggle ON</b> (after 18+ consent) → <b>your mature prompt file is the one that runs</b>, for every generation, whatever the idea reads like. The switch is the decision; the keyword detector only <i>advises</i> (write a mature idea with the switch off and the app tells you). Under the switch the builder prints which file will run — <code>prompts/system-prompt-mature.md</code> (or <code>ltx-system-prompt-mature.md</code> for LTX), its size and its 📎 count — before you generate, and every card carries 🔞 or 🛡️. If that path is empty or unreachable you get a warning and a loud SFW fallback, never a quiet one.</li>
            <li><b>Kill switch</b> → console: <code>cpsNsfw.block()</code> disables the toggle and forces SFW everywhere; <code>cpsNsfw.allow()</code> reverses; deleting the mature files also blocks by omission.</li>
          </ul>
        </Sec>

        <Sec id="logs" icon="🪵" title="Console logs & troubleshooting">
          <p>Every provider interaction is logged in full — requests, responses, tokens, timings. Open devtools → Console:</p>
          <ul className="glist">
            <li><b>CPS {'{PROVIDER}'} ↑ / ↓</b> — identical full request/response groups for EVERY provider (Ollama, OpenRouter, Groq, Gemini, OpenAI-compat, 🖥️ local), including token counts when the server reports usage.</li>
            <li><b>provider / model-list</b> lines — connection outcomes and fetched model counts.</li>
            <li><b>[fetch]</b> lines — every network call with status and duration.</li>
            <li><code>window.cpsLogs.text()</code> — the whole session as text; <code>cpsLogs.download()</code> saves a .txt for hand-over.</li>
          </ul>
          <p><b>Common fixes:</b> "Ollama isn't reachable" → is <code>ollama serve</code> running and the port right in Settings? Empty descriptions → check the ↓ group for what came back; usually a bigger model. CORS errors from a preview origin → run <code>OLLAMA_ORIGINS=* ollama serve</code>.</p>
        </Sec>

        <Sec id="packs" icon="🧠" title="Prompt packs — one craft brain per video type">
          <p>
            The system prompt is now two layers: a <b>base prompt</b> with the universal grammar
            (output format, shot design, consistency, audio, timing) and a <b>domain pack</b> with the
            craft that only applies to one kind of video — garment physics and runway beats for
            fashion, material macros and spec beats for product, phone-real delivery and the
            hook→demo→CTA arc for social/UGC, and so on.
          </p>
          <ul className="glist">
            <li><b>Why:</b> fashion craft used to be inside every system prompt, so a product, portrait or
              animation clip was written with garment vocabulary. Now a pack is appended <i>only</i> when the
              generation is actually about that domain.</li>
            <li><b>Auto routing</b> (in order): the picked template's tag → the category chip → the words in
              your idea (each pack declares its own keyword list). Mode tags like <code>person</code>,
              <code> preset</code>, <code>vertical</code>, <code>longvideo</code> never vote — they let the
              category and idea decide. At most two packs stack, and only pairs that declare
              <code> stack-with</code> (e.g. fashion + social).</li>
            <li><b>🧠 Prompt pack picker</b> (Scene section, under Category): <b>Auto</b>, any single pack, or
              <b> Base prompt only</b>. The line under it always shows what Auto resolved and why.</li>
            <li><b>Story chain:</b> each scene resolves against <i>its own</i> 📐 template — a chain can mix
              fashion, product and dialogue scenes and each scene gets the right brain. An explicit picker
              choice applies to every scene.</li>
            <li><b>Evidence:</b> generated cards badge the packs used (🧠 + icons, hover for names) and the
              console logs <code>prompt packs: … — template tag “fashion” …</code> with the char count.</li>
            <li><b>Fashion camera mode:</b> the 🧍 she performs / 🎥 camera plays chips now appear whenever the
              fashion pack is loaded — they pick which camera block inside the pack is sent.</li>
            <li><b>Add your own pack:</b> drop a <code>.md</code> into <code>public/prompts/packs/</code> with
              <code> pack / label / tags / categories / keywords</code> header lines; name it
              <code> user-*.md</code> to override a built-in with the same id. Full format in that folder's
              README.</li>
          </ul>
          <Tip>The packs are plain text — tune them like the system prompt. Deleting a pack file just removes it from the picker; the base prompt always works alone.</Tip>
        </Sec>

        <Sec id="files" icon="📁" title="Customization files (public/prompts/)">
          <ul className="glist">
            <li><code>system-prompt.md</code> / <code>ltx-system-prompt.md</code> — SFW system messages.</li>
            <li><code>system-prompt-mature.md</code> / <code>ltx-system-prompt-mature.md</code> — 18+ system messages.</li>
            <li><code>prompts/templates/</code> — folder scanned live: <code>core.md</code> built-ins (replaced by updates) + any <code>.md</code> you drop in; your <code>user-*.md</code> files are never touched.</li>
            <li><code>a user-*.md file in prompts/templates/</code> — <b>your</b> templates; updates never touch it; same title overrides built-ins.</li>
            <li><code>prompts/packs/</code> — domain craft packs (fashion, ethnic/bridal, product, social/UGC, dialogue, cinematic, documentary, nature, food, animals, vehicles, spaces, animation, music, portrait, sport) — scanned live, drop in your own.</li>
            <li><code>loras.md</code> — the LoRA library.</li>
            <li><code>chain-planner.md</code> — the auto-planner's instructions.</li>
            <li><code>template-forge.md</code> — the Forge's system prompt.</li>
            <li><code>placeholder-filler.md</code> — the suggest-values instructions.</li>
            <li><code>docs/official-h3-spec-review.md</code> — line-by-line diff of the official MiniMax H3 prompt-writing skill against our prompts (what matched, what changed).</li>
          </ul>
          <Tip>Edit any of these and refresh the tab — no rebuild needed. Full format specs in <code>docs/customization-guide.md</code>.</Tip>
        </Sec>

      </div>
    </div>
  )
}
