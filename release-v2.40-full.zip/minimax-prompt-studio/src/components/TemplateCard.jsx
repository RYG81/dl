import { uniqueTokens } from '../lib/tokens.js'
import { useState } from 'react'
import { tagLabel, groupOf } from '../lib/tags.js'


const hl = (text) => String(text).split(/(\{[^{}\n]{2,120}\})/g).map((p, i) =>
  /^\{[^{}\n]{2,120}\}$/.test(p) ? <b key={i} style={{ color: '#fbbf24' }}>{p}</b> : p)

/* The one template card used everywhere (picker + library).
   Calm layout: badges + quiet icon actions on top, readable wrapped title,
   dim meta pills (deduped), ONE subtle full-width call-to-action. */
export default function TemplateCard({ t, current, primaryLabel, onPrimary, extra }) {
  const [x, setX] = useState(false)
  const toks = uniqueTokens([t.b || '', t.idea || ''])
  const st = t.settings || {}
  const tagTxt = tagLabel(t.tag)
  const cat = String(st.category || '').trim()
  const dupCat = !cat || cat === t.tag || tagTxt.toLowerCase().indexOf(cat.toLowerCase()) >= 0
  const isCur = current === t.t
  return (
    <div className={'tcard' + (isCur ? ' cur' : '')}>
      <div className="tcard-head">
        <span className="fbadge" data-f={t.fmt === 'ltx' ? 'ltx' : 'h3'}>{t.fmt === 'ltx' ? '⚡ LTX' : '🎬 H3'}</span>
        {(t.src === 'user' || t.src === 'forged') ? <span className="fbadge" data-f="user" title="Created by you — LLM flows never overwrite user templates">👤</span> : null}
        <span className="tcard-actions">
          <button type="button" className="btn tiny" title={x ? 'Hide preview' : 'Preview what attaches'} onClick={(e) => { e.stopPropagation(); setX(!x) }}>{x ? '🔼' : '👁'}</button>
          {extra || null}
        </span>
      </div>
      <div className="tcard-title" title={t.t}>{t.t}</div>
      {t.d ? <div className="tcard-desc">{t.d}</div> : null}
      <div className="tcard-meta">
        <span className="mpill">{tagTxt}</span>
        {t.folder ? <span className="mpill" title={'Subfolder: public/prompts/templates/' + t.folder + '/'}>📁 {t.folder}</span> : null}
        {!dupCat ? <span className="mpill">{cat}</span> : null}
        {st.ratio ? <span className="mpill">{st.ratio}</span> : null}
        {st.duration ? <span className="mpill">{st.duration}s</span> : null}
        {toks.length ? <span className="mpill" title="placeholders become 🧩 fields">🧩 {toks.length}</span> : null}
        {st.structure && st.structure !== 'single' ? <span className="mpill">🎞 {st.structure}</span> : null}
        {t.flows && t.flows.length ? <span className="mpill" title={'Dynamic beat flows — variants rotate: ' + t.flows.join(' · ')}>🎼 {t.flows.length} flows</span> : null}
        {t.vary && t.vary.length ? <span className="mpill" title={'Everything varies — every variant draws a different option from each pool: ' + t.vary.join(' · ')}>🔀 {t.vary.length} vary</span> : null}
        {t.chain ? <span className="mpill" title={'Chain recipe — sends to the builder as ' + t.chain + ' linked scenes' + (t.chainRule ? ': ' + t.chainRule : '')}>🔗 {t.chain}-scene chain</span> : null}
      </div>
      <button type="button" className={'tcard-cta' + (isCur ? ' on' : '')} onClick={(e) => { e.stopPropagation(); onPrimary(t) }}>
        {isCur ? '✓ ' + (primaryLabel || 'Attached') : (primaryLabel || '➜ Attach')}
      </button>
      {x ? (
        <div className="tcard-prev" onClick={(e) => e.stopPropagation()}>
          {t.idea ? <div className="sptext" style={{ marginBottom: 6 }}>{hl(t.idea)}</div> : null}
          <div className="sptext">{hl(t.b)}</div>
          <div className="vmeta" style={{ marginTop: 6, fontSize: 11 }}>amber = 🧩 field you fill in the builder{t.tip ? ' · ' + t.tip : ''}</div>
        </div>
      ) : null}
    </div>
  )
}
