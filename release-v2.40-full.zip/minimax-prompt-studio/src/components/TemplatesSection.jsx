import { useState } from 'react'
import { TEMPLATES } from '../lib/templates.js'
import { copyText } from '../lib/format.js'

const TAG_LABELS = {
  person: '👤 Person', product: '📦 Product', landscape: '🏔 Landscape',
  animation: '🎨 Animation', dialogue: '💬 Dialogue', fashion: '👗 Fashion', multi: '🎞 Multi-shot',
  vertical: '📱 Vertical', music: '🎵 Music',
  food: '🍽 Food', animal: '🐾 Animal', vehicle: '🚗 Vehicle', space: '🏛 Space',
  portrait: '👤 Portrait', sports: '🏃 Sport', documentary: '🎥 Documentary', ethnic: '👰 Ethnic / Bridal',
  mascot: '🐮 Mascot',
  cg: '🧸 CG story',
  claymation: '🧆 Claymation',
  retro: '📺 Retro cel',
  anime: '🎌 Anime',
  toon: '🍬 Product toons',
  artist: '🎨 Artist',
  beauty: '💇 Beauty',
  papercraft: '✂️ Papercraft', minimalist: '🧊 Minimalist', lyric: '🔤 Lyric type', scroll: '📜 Reveal scroll', game: '🎮 Game intro',
}

export default function TemplatesSection({ templates, source, notes, toast }) {
  const [filter, setFilter] = useState('All')
  const [fold, setFold] = useState('All')
  const LIB = templates && templates.length ? templates : TEMPLATES
  const tags = ['All', ...Object.keys(TAG_LABELS)]
  /* 📁 Subfolders of public/prompts/templates/ are first-class here too. */
  const folders = [...new Set(LIB.filter((tp) => !tp.p).map((tp) => tp.folder || ''))].sort((a, b) => (a === '' ? -1 : b === '' ? 1 : a.localeCompare(b)))
  const list = LIB.filter((tp) => !tp.p)
    .filter((tp) => filter === 'All' || tp.tag === filter)
    .filter((tp) => fold === 'All' || (tp.folder || '') === fold)

  return (
    <section className="block">
      <h2>
        📋 Prompt templates
        <span className="vmeta">one per video type · {list.length} shown</span>
      </h2>
      <div style={{ color: 'var(--dim)', fontSize: 12.5, margin: '-4px 0 10px' }}>
        Fill-in skeletons in the exact three-field MiniMax format. <b>⤴ Load into Studio</b> prefills the idea and
        every setting — replace the <code>{'{PLACEHOLDERS}'}</code> and hit Generate.{' '}
        <span className="vmeta">
          {source === 'loading' ? 'loading templates…' : 'loaded from ' + source + ' — edit that file to add your own (↻ Reload from settings)'}
        </span>
      </div>
      {notes && notes.length ? (
        <details style={{ marginBottom: 10, fontSize: 12.5 }}>
          <summary style={{ cursor: 'pointer', color: '#fca5a5' }}>
            ⚠ {notes.length} file{notes.length > 1 ? 's' : ''} in <code>prompts/templates/</code> gave no templates — click for the reason
          </summary>
          <div style={{ lineHeight: 1.8, marginTop: 4 }}>
            {notes.map((n, i) => (<div key={i}>✗ <b>{n.file}</b> — {n.note}</div>))}
            <div className="vmeta" style={{ marginTop: 4 }}>
              A file only needs a <code>## Title</code> line and a skeleton: <code>integrated_multimodal_description:</code> for H3
              (with <code>overall_soundscape:</code> and <code>non_diegetic_music:</code>) or <code>prompt:</code> for LTX. Fences are optional.
              <code> README.md</code> and files starting with <code>_</code> are skipped on purpose.
            </div>
          </div>
        </details>
      ) : null}
      <div className="chips" style={{ marginBottom: 12, alignItems: 'center' }}>
        {tags.map((tg) => (
          <span key={tg} className={'chip' + (filter === tg ? ' on' : '')} onClick={() => setFilter(tg)}>
            {tg === 'All' ? 'All' : TAG_LABELS[tg]}
          </span>
        ))}
        {folders.length > 1 ? (
          <select value={fold} onChange={(e) => setFold(e.target.value)} style={{ width: 'auto', minWidth: 160, marginLeft: 'auto' }} title="Subfolder inside public/prompts/templates/ — drop a folder in and it appears here">
            <option value="All">📁 All folders ({folders.length})</option>
            {folders.map((f) => <option key={f || '(root)'} value={f}>{f === '' ? '📄 (root)' : '📁 ' + f}</option>)}
          </select>
        ) : null}
      </div>
      <div className="cards">
        {list.map((tp) => (
          <div key={tp.t} className="tpl">
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
              <span className="t" style={{ margin: 0 }}>{tp.t}</span>
              <span className="badge">{TAG_LABELS[tp.tag] || tp.tag}</span>
              <span className="vmeta" style={{ marginLeft: 'auto' }}>
                {tp.folder ? '📁 ' + tp.folder + ' · ' : ''}{tp.settings.ratio} · {tp.settings.duration}s · {tp.settings.structure === 'single' ? '1 shot' : 'multi'}
              </span>
            </div>
            <div className="d">{tp.d}</div>
            <pre style={{ maxHeight: 200, overflow: 'auto' }}>{tp.b}</pre>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <button className="btn tiny primary"
                onClick={() => {
                  window.dispatchEvent(new CustomEvent('cps-load-example', { detail: { idea: tp.idea, settings: { ...tp.settings, template: tp.t } } }))
                  toast('📐 ' + tp.t + ' loaded — settings applied, replace the {PLACEHOLDERS}, then Generate')
                }}>
                ⤴ Load into Studio
              </button>
              <button className="btn tiny" onClick={async () => { await copyText(tp.b); toast('Template copied') }}>
                📋 Copy skeleton
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
