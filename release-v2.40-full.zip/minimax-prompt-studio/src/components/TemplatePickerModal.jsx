import { useState } from 'react'
import { CATEGORIES } from '../lib/templates.js'
import TemplateCard from './TemplateCard.jsx'
import { tagLabel, groupOf, tagFilters } from '../lib/tags.js'


function readRecent() { try { return JSON.parse(localStorage.getItem('cps_recent_tpls') || '[]') } catch (e) { return [] } }

/* Visual template browser: search + filters, recents on top, tap-to-preview,
   one-click attach. Cards come from the shared TemplateCard. */
export default function TemplatePickerModal({ open, onClose, templates, current, onUse, userReport, fileNotes }) {
  const [q, setQ] = useState('')
  const [tag, setTag] = useState('All')
  const [cat, setCat] = useState('All')
  const [fmt, setFmt] = useState(() => { try { return localStorage.getItem('cps_pick_fmt') || 'All' } catch (e) { return 'All' } })
  const [fold, setFold] = useState('All')
  if (!open) return null
  const LIB = (templates || []).filter((t) => !t.p && t.b)
  const recent = readRecent()
  const tags = tagFilters(LIB)
  /* 📁 Subfolders of public/prompts/templates/ are first-class: filter by folder, and the
     folder name is searchable too. '' (a file in the root) is shown as “(root)”. */
  const folders = [...new Set(LIB.map((t) => t.folder || ''))].sort((a, b) => (a === '' ? -1 : b === '' ? 1 : a.localeCompare(b)))
  const folderLabel = (f) => (f === '' ? '(root)' : f)
  const list = LIB.filter((t) =>
    (tag === 'All' || groupOf(t) === tag) &&
    (cat === 'All' || ((t.settings || {}).category || '') === cat) &&
    (fmt === 'All' || t.fmt === fmt) &&
    (fold === 'All' || (t.folder || '') === fold) &&
    (!q.trim() || (t.t + ' ' + t.d + ' ' + (t.folder || '')).toLowerCase().includes(q.trim().toLowerCase())))
    .sort((a, b) => {
      const ka = recent.indexOf(a.t) === -1 ? 99 : recent.indexOf(a.t)
      const kb = recent.indexOf(b.t) === -1 ? 99 : recent.indexOf(b.t)
      if (ka !== kb) return ka - kb
      return String(a.t).localeCompare(String(b.t))
    })
  const clearFilters = () => { setQ(''); setTag('All'); setCat('All'); setFmt('All'); setFold('All'); try { localStorage.setItem('cps_pick_fmt', 'All') } catch (e) {} }
  const attach = (t) => {
    try { localStorage.setItem('cps_recent_tpls', JSON.stringify([t.t, ...readRecent().filter((x2) => x2 !== t.t)].slice(0, 4))) } catch (e) {}
    onUse(t)
  }
  return (
    <div className="modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="modal" style={{ width: 'min(780px,100%)' }}>
        <div className="modal-head">
          <h3>📐 Template picker</h3>
          <span className="vmeta">{list.length} of {LIB.length}{fold !== 'All' ? ' · 📁 ' + folderLabel(fold) : ''}</span>
          <button type="button" className="qbtn" style={{ marginLeft: 8 }} title="How templates feed the builder — opens Guide" onClick={() => window.dispatchEvent(new CustomEvent('cps-open-guide', { detail: 'templates' }))}>?</button>
          <button type="button" className="btn tiny" style={{ marginLeft: 'auto' }} title="Add / edit / export your own blocks" onClick={() => window.dispatchEvent(new Event('cps-open-manager'))}>📦 Manage</button>
          <button type="button" className="btn tiny" onClick={onClose}>✕ Close</button>
        </div>
        <div className="modal-body">
          <div style={{ display: 'flex', gap: 8, marginBottom: 10, flexWrap: 'wrap' }}>
            <input type="text" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search… (loop, fashion, drone)"
              style={{ flex: 1, minWidth: 180 }} autoFocus />
            <select value={cat} onChange={(e) => setCat(e.target.value)} style={{ width: 'auto', minWidth: 170 }} title="Category">
              <option value="All">All categories</option>
              {Object.entries(CATEGORIES).map(([id, label]) => <option key={id} value={id}>{label}</option>)}
            </select>
            <select value={fmt} onChange={(e) => { setFmt(e.target.value); try { localStorage.setItem('cps_pick_fmt', e.target.value) } catch (err) {} }} style={{ width: 'auto' }} title="Target format (remembered)">
              <option value="All">All formats</option>
              <option value="h3">🎬 H3</option>
              <option value="ltx">⚡ LTX</option>
            </select>
            {folders.length > 1 ? (
              <select value={fold} onChange={(e) => setFold(e.target.value)} style={{ width: 'auto', minWidth: 150 }} title="Subfolder inside public/prompts/templates/">
                <option value="All">All folders ({folders.length})</option>
                {folders.map((f) => (
                  <option key={f || '(root)'} value={f}>{f === '' ? '📄 (root)' : '📁 ' + f}</option>
                ))}
              </select>
            ) : null}
          </div>
          <div className="chips" style={{ marginBottom: 10 }}>
            {tags.map((tg) => (
              <span key={tg} className={'chip' + (tag === tg ? ' on' : '')} onClick={() => setTag(tg)}>
                {tg === 'All' ? 'All' : tagLabel(tg)}
              </span>
            ))}
          </div>
          {fileNotes && fileNotes.length ? (
            <details style={{ marginBottom: 10, fontSize: 12.5 }}>
              <summary style={{ cursor: 'pointer', color: '#fca5a5' }}>
                ⚠ {fileNotes.length} file{fileNotes.length > 1 ? 's' : ''} in prompts/templates/ gave no templates
              </summary>
              <div style={{ lineHeight: 1.8, marginTop: 4 }}>
                {fileNotes.map((n, i) => (<div key={i}>✗ <b>{n.file}</b> — {n.note}</div>))}
                <div className="vmeta">Fences are optional; the title line and the skeleton label are what matter.</div>
              </div>
            </details>
          ) : null}
          {userReport && userReport.length ? (
            <details style={{ marginBottom: 10, fontSize: 12.5 }}>
              <summary style={{ cursor: 'pointer' }} className="vmeta">🔍 your blocks (user-*.md / imported) — {userReport.length} block(s): {userReport.filter((r) => r.error).length ? <b style={{ color: '#fca5a5' }}>{userReport.filter((r) => r.error).length} skipped</b> : <b style={{ color: '#86efac' }}>all loaded ✓</b>}</summary>
              <div style={{ lineHeight: 1.8, marginTop: 4 }}>
                {userReport.map((r, i) => (
                  <div key={i}>{r.error ? <span style={{ color: '#fca5a5' }}>✗ SKIPPED — <b>{r.t || '(untitled)'}</b> · {r.error}</span> : <span>✓ {r.fmt === 'ltx' ? '⚡ LTX' : '🎬 H3'} — <b>{r.t}</b>{r.note ? <span className="vmeta"> · {r.note}</span> : null}</span>}</div>
                ))}
              </div>
            </details>
          ) : null}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxHeight: '52vh', overflow: 'auto', paddingRight: 4 }}>
            {list.length === 0 ? (
              <div style={{ padding: 18, textAlign: 'center', border: '1px dashed var(--border)', borderRadius: 12 }}>
                <div style={{ marginBottom: 8 }}>Nothing matches.</div>
                <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
                  <button type="button" className="btn tiny" onClick={clearFilters}>↺ Clear filters</button>
                  <button type="button" className="btn tiny primary" onClick={() => window.dispatchEvent(new Event('cps-open-manager'))}>📦 Add my own</button>
                </div>
              </div>
            ) : list.map((t) => (
              <TemplateCard key={t.t} t={t} current={current} primaryLabel="➜ Attach" onPrimary={attach} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
