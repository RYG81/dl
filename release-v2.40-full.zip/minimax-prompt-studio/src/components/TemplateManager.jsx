import { useEffect, useState } from 'react'
import { parseTemplatesMd, templateToMd, upsertBlockInDoc, removeBlockFromDoc, CATEGORIES } from '../lib/templates.js'
import { copyText } from '../lib/format.js'
import { lintTemplate } from '../lib/lint.js'
import { LintPanel } from './TemplateForge.jsx'

const TAGS = [['person', '👤 Person'], ['product', '📦 Product'], ['landscape', '🏔 Landscape'], ['animation', '🎨 Animation'], ['dialogue', '💬 Dialogue'], ['fashion', '👗 Fashion'], ['multi', '🎞 Multi-shot'], ['vertical', '📱 Vertical'], ['music', '🎵 Music'], ['mature', '🔞 Mature'], ['longvideo', '🎬 Long-form'], ['food', '🍽 Food'], ['animal', '🐾 Animal'], ['vehicle', '🚗 Vehicle'], ['space', '🏛 Space'], ['portrait', '👤 Portrait'], ['sports', '🏃 Sport'], ['documentary', '🎥 Documentary'], ['ethnic', '👰 Ethnic / Bridal']]

const BLANK = { t: '', fmt: 'h3', tag: 'person', cat: 'Cinematic Film Scene', ratio: '16:9', res: '2K', dur: 6, music: 'auto', structure: 'single', camera: 'Auto', idea: '', d: '', b: '' }

/* 📦 Template Manager — full CRUD over YOUR library.
   The source of truth is one markdown document stored in this browser
   (localStorage cps_user_tpl); every save re-parses through the same
   loader the whole app uses, so what you see is exactly what loads. */
export default function TemplateManager({ open, onClose, toast }) {
  const [doc, setDoc] = useState('')
  const [edit, setEdit] = useState(null) /* null | { oldTitle, F } */
  const [q, setQ] = useState('')
  useEffect(() => {
    if (open) {
      try { setDoc(localStorage.getItem('cps_user_tpl') || '') } catch (e) {}
      setEdit(null); setQ('')
    }
  }, [open])
  if (!open) return null

  const persist = (d, msg) => {
    try { localStorage.setItem('cps_user_tpl', d) } catch (e) {}
    setDoc(d)
    window.dispatchEvent(new Event('cps-reload-sysprompt'))
    if (msg) toast(msg)
  }

  const blocks = parseTemplatesMd(doc)
  const report = (parseTemplatesMd.report || [])
  const skipped = report.filter((r) => r.error)
  const list = blocks.filter((b) => !q.trim() || b.t.toLowerCase().includes(q.trim().toLowerCase()))

  const startNew = () => setEdit({ oldTitle: null, F: { ...BLANK } })
  const startEdit = (b) => setEdit({
    oldTitle: b.t,
    F: {
      t: b.t, fmt: b.fmt, tag: b.tag || 'person',
      cat: (b.settings || {}).category || 'Cinematic Film Scene',
      ratio: (b.settings || {}).ratio || '16:9',
      res: (b.settings || {}).resolution || '2K',
      dur: (b.settings || {}).duration || 6,
      music: (b.settings || {}).music || 'auto',
      structure: (b.settings || {}).structure || 'single',
      camera: (b.settings || {}).camera || 'Auto',
      idea: b.idea || '', d: b.d || '', b: b.b || '',
    },
  })

  const F = edit && edit.F
  const preview = F ? templateToMd({ t: F.t || 'Untitled', tag: F.tag, d: F.d, fmt: F.fmt, idea: F.idea, b: F.b, settings: { category: F.cat, ratio: F.ratio, resolution: F.res, duration: F.dur, music: F.music, structure: F.structure, camera: F.camera } }) : ''
  const check = F ? parseTemplatesMd(preview) : []
  const checkFmt = check.length ? check[0].fmt : null
  const toks = F ? [...new Set((F.b.match(/\{([^{}\n]+)\}/g) || []).map((x) => x.slice(1, -1)))] : []
  const lint = (F && check.length === 1) ? lintTemplate(check[0], blocks.filter((b) => b.t !== edit.oldTitle)) : null
  const valid = F && F.t.trim() && F.b.trim() && check.length === 1 && checkFmt === F.fmt

  const save = () => {
    if (!valid) { toast('⚠ Fix the editor issues first — title, skeleton and format must check out'); return }
    const dup = blocks.find((b) => b.t === F.t.trim() && b.t !== edit.oldTitle)
    if (dup) { toast('⚠ A block titled “' + F.t.trim() + '” already exists — rename yours or edit that one'); return }
    persist(upsertBlockInDoc(doc, preview, edit.oldTitle), '💾 “' + F.t.trim() + '” saved — live everywhere instantly')
    setEdit(null)
  }

  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="modal" role="dialog" aria-modal="true" style={{ width: 'min(980px,100%)' }}>
        <div className="modal-head">
          <h3>📦 Template Manager — your library</h3>
          <span className="vmeta">{blocks.length} block(s){skipped.length ? ' · ⚠ ' + skipped.length + ' skipped' : ''} · stored in this browser only</span>
          <button type="button" className="btn tiny" style={{ marginLeft: 'auto' }} onClick={onClose}>✕ Close</button>
        </div>
        <div className="modal-body">
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', marginBottom: 10 }}>
            <button type="button" className="btn tiny primary" onClick={startNew}>➕ New template</button>
            <input type="text" value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔎 filter…" style={{ width: 150 }} />
            <span className="spacer" style={{ flex: 1 }}></span>
            <button type="button" className="btn tiny" onClick={async () => {
              let txt = ''
              try {
                const ri = await fetch('prompts/templates/_index.json', { cache: 'no-store' })
                if (ri.ok) for (const f of (await ri.json())) {
                  if (!/^user/i.test(f)) continue
                  const r = await fetch('prompts/templates/' + encodeURIComponent(f), { cache: 'no-store' })
                  if (r.ok) txt += (txt ? '\n\n' : '') + (await r.text())
                }
              } catch (e) {}
              if (!txt) {
                const r = await fetch('prompts/user-templates.md', { cache: 'no-store' }).catch(() => null)
                if (r && r.ok) txt = await r.text()
              }
              if (txt) persist(txt, '📥 Served examples loaded as your starting document')
              else toast('⚠ No served user-*.md files found in prompts/templates/')
            }}>📥 Start from examples</button>
            <button type="button" className="btn tiny" onClick={() => {
              const a = document.createElement('a')
              a.href = URL.createObjectURL(new Blob([doc], { type: 'text/markdown' }))
              a.download = 'user-templates.md'
              a.click()
              toast('📤 user-templates.md downloaded — drop it into public/prompts/templates/ of any local copy')
            }}>📤 Export .md</button>
            <button type="button" className="btn tiny" onClick={async () => { await copyText(doc); toast('📋 Document copied') }}>📋 Copy</button>
            {doc ? <button type="button" className="btn tiny ghost" onClick={() => persist('', '🗑 Your library document cleared — served file active again')}>🗑 Clear all</button> : null}
          </div>

          {skipped.length ? (
            <div style={{ marginBottom: 10, fontSize: 12, color: '#fca5a5', lineHeight: 1.7 }}>
              {skipped.map((r, i) => <div key={i}>✗ <b>{r.t || '(untitled)'}</b> — {r.error}</div>)}
            </div>
          ) : null}

          {edit ? (
            <div style={{ display: 'grid', gap: 8 }}>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                <b>{edit.oldTitle ? '✏️ Editing “' + edit.oldTitle + '”' : '➕ New template'}</b>
                <span className="spacer" style={{ flex: 1 }}></span>
                <button type="button" className="btn tiny" onClick={() => setEdit(null)}>← Back to list</button>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <label style={{ fontSize: 11 }}>Title<input type="text" value={F.t} onChange={(e) => setEdit((p) => ({ ...p, F: { ...p.F, t: e.target.value } }))} placeholder="👤 My template" /></label>
                <label style={{ fontSize: 11 }}>Description<input type="text" value={F.d} onChange={(e) => setEdit((p) => ({ ...p, F: { ...p.F, d: e.target.value } }))} placeholder="one line shown on cards" /></label>
                <label style={{ fontSize: 11 }}>Tag<select value={F.tag} onChange={(e) => setEdit((p) => ({ ...p, F: { ...p.F, tag: e.target.value } }))}>{TAGS.map(([id, l]) => <option key={id} value={id}>{l}</option>)}</select></label>
                <label style={{ fontSize: 11 }}>Category<select value={F.cat} onChange={(e) => setEdit((p) => ({ ...p, F: { ...p.F, cat: e.target.value } }))}>{Object.entries(CATEGORIES).map(([id, l]) => <option key={id} value={l}>{l}</option>)}</select></label>
                <label style={{ fontSize: 11 }}>Ratio<select value={F.ratio} onChange={(e) => setEdit((p) => ({ ...p, F: { ...p.F, ratio: e.target.value } }))}>{['16:9', '9:16', '1:1', '4:3', '21:9'].map((r) => <option key={r}>{r}</option>)}</select></label>
                <label style={{ fontSize: 11 }}>Duration (s)<input type="number" min="4" max="15" value={F.dur} onChange={(e) => setEdit((p) => ({ ...p, F: { ...p.F, dur: parseInt(e.target.value, 10) || 6 } }))} /></label>
                <label style={{ fontSize: 11 }}>Music<select value={F.music} onChange={(e) => setEdit((p) => ({ ...p, F: { ...p.F, music: e.target.value } }))}>{['auto', 'none', 'subtle', 'beat'].map((r) => <option key={r}>{r}</option>)}</select></label>
                <label style={{ fontSize: 11 }}>Structure<select value={F.structure} onChange={(e) => setEdit((p) => ({ ...p, F: { ...p.F, structure: e.target.value } }))}>{['single', 'auto', 'multi2', 'multi3'].map((r) => <option key={r}>{r}</option>)}</select></label>
                <label style={{ fontSize: 11, gridColumn: '1 / -1' }}>Idea (becomes the default scene idea)<input type="text" value={F.idea} onChange={(e) => setEdit((p) => ({ ...p, F: { ...p.F, idea: e.target.value } }))} placeholder="one sentence with {PLACEHOLDERS}" /></label>
              </div>
              <div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                  <span className={'chip' + (F.fmt === 'h3' ? ' on' : '')} onClick={() => setEdit((p) => ({ ...p, F: { ...p.F, fmt: 'h3' } }))}>🎬 H3</span>
                  <span className={'chip' + (F.fmt === 'ltx' ? ' on' : '')} onClick={() => setEdit((p) => ({ ...p, F: { ...p.F, fmt: 'ltx' } }))}>⚡ LTX</span>
                  <span className="vmeta">{F.fmt === 'ltx' ? 'skeleton = prompt: … (+negative_prompt/tags)' : 'skeleton = integrated_multimodal_description / overall_soundscape / non_diegetic_music'}</span>
                </div>
                <textarea rows={9} value={F.b} onChange={(e) => setEdit((p) => ({ ...p, F: { ...p.F, b: e.target.value } }))}
                  placeholder={F.fmt === 'ltx' ? 'prompt: your one-paragraph LTX prompt with {PLACEHOLDERS}…\n\nnegative_prompt: text, watermark\n\ntags: fashion, ltx' : 'integrated_multimodal_description: …\n\noverall_soundscape: …\n\nnon_diegetic_music: …'}
                  style={{ width: '100%', fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', fontSize: 11.5, lineHeight: 1.5, background: 'var(--bg)', color: 'var(--text)', border: '1px solid var(--border)', borderRadius: 8, padding: 8 }} />
              </div>
              <div style={{ fontSize: 12, lineHeight: 1.7, border: '1px dashed var(--border)', borderRadius: 8, padding: '6px 10px' }}>
                {F.b.trim() ? (check.length === 1
                  ? <span style={{ color: checkFmt === F.fmt ? '#86efac' : '#fca5a5' }}>{checkFmt === F.fmt ? '✓ parses as ' : '⚠ parses as ' + (checkFmt === 'ltx' ? '⚡ LTX' : '🎬 H3') + ' but you selected '}{checkFmt === F.fmt ? (F.fmt === 'ltx' ? '⚡ LTX' : '🎬 H3') : (F.fmt === 'ltx' ? '⚡ LTX' : '🎬 H3') + ' — adjust the skeleton or the format chip'}</span>
                  : <span style={{ color: '#fca5a5' }}>✗ skeleton does not parse yet — {F.fmt === 'ltx' ? 'needs a prompt: line (or a long unlabeled paragraph)' : 'needs the three labeled fields'}</span>)
                  : <span className="vmeta">skeleton empty</span>}
                {toks.length ? <span className="vmeta"> · 🧩 {toks.length} placeholder(s): {toks.join(', ')}</span> : null}
              </div>
              {lint ? <LintPanel L={lint} compact /> : null}
              <div style={{ display: 'flex', gap: 8 }}>
                <button type="button" className="btn tiny primary" disabled={!valid} onClick={save}>💾 Save to my library</button>
                {edit.oldTitle ? <button type="button" className="btn tiny ghost" onClick={() => { persist(removeBlockFromDoc(doc, edit.oldTitle), '🗑 “' + edit.oldTitle + '” deleted'); setEdit(null) }}>🗑 Delete</button> : null}
              </div>
            </div>
          ) : (
            <div style={{ display: 'grid', gap: 6 }}>
              {list.length === 0 ? <div className="hint">{doc ? 'Nothing matches — create one with ➕ New template.' : 'Your library is empty. ➕ New template, or 📥 start from the served examples and edit them.'}</div> : null}
              {list.map((b) => (
                <div key={b.t} style={{ display: 'flex', gap: 8, alignItems: 'center', border: '1px solid var(--border)', borderRadius: 8, padding: '7px 10px', flexWrap: 'wrap' }}>
                  <span className="badge" style={{ background: b.fmt === 'ltx' ? '#0e3a4d' : '#3b2f12', color: b.fmt === 'ltx' ? '#a5f3fc' : '#fde68a' }}>{b.fmt === 'ltx' ? '⚡ LTX' : '🎬 H3'}</span>
                  <b style={{ fontSize: 13 }}>{b.t}</b>
                  <span className="vmeta">{(b.settings || {}).category} · {(b.settings || {}).ratio} · {(b.settings || {}).duration}s</span>
                  <span className="spacer" style={{ flex: 1 }}></span>
                  <button type="button" className="btn tiny" onClick={() => startEdit(b)}>✏️ Edit</button>
                  <button type="button" className="btn tiny ghost" onClick={() => persist(removeBlockFromDoc(doc, b.t), '🗑 “' + b.t + '” deleted')}>🗑</button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
