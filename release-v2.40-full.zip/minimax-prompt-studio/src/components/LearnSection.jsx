import { useState } from 'react'
import { TEMPLATES, templateToMd, CATEGORIES } from '../lib/templates.js'
import { tagLabel, groupOf, tagFilters } from '../lib/tags.js'
import { EXAMPLES } from '../lib/examples.js'
import { copyText } from '../lib/format.js'
import { convertPrompt } from '../lib/convert.js'
import TipsSection from './TipsSection.jsx'
import TemplateCard from './TemplateCard.jsx'


/* One card, one vocabulary: view in either format (H3 ⇄ LTX, converted on demand),
   copy it, or send it to the Input Builder. */
function LearnCard({ title, badge, meta, desc, native, getNative, idea, settings, sendTip, extra, conn, sysText, ltxText, toast, nativeOnly }) {
  const home = native || 'h3'
  const [fmt, setFmt] = useState(home)
  const [cache, setCache] = useState({})
  const [busy, setBusy] = useState(false)
  const shown = fmt === home ? getNative() : (cache[fmt] || '')
  const pick = async (f2) => {
    if (nativeOnly) { toast('ℹ️ This is a ' + (home === 'ltx' ? '⚡ LTX' : '🎬 H3') + ' template — its authored skeleton only exists in this format. Use a native ' + (home === 'ltx' ? '🎬 H3' : '⚡ LTX') + ' template for the other target.'); return }
    setFmt(f2)
    if (f2 === home || cache[f2]) return
    setBusy(true)
    try {
      // Format switching here NEVER calls the LLM — local engine only (user policy: view conversions stay offline)
      const r = await convertPrompt({ conn: null, sysText, ltxText }, getNative(), f2, (acc) => setCache((c) => ({ ...c, [f2]: acc })))
      setCache((c) => ({ ...c, [f2]: r.text }))
      toast((f2 === 'ltx' ? '⚡ LTX' : '🎬 H3') + ' view ready (instant local engine — no LLM call)')
    } catch (e) {
      toast('❌ Conversion failed: ' + ((e && e.message) || e))
    }
    setBusy(false)
  }
  return (
    <div className="tpl">
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <span className="t" style={{ margin: 0 }}>{title}</span>
        {badge ? <span className="badge">{badge}</span> : null}
        {meta ? <span className="vmeta" style={{ marginLeft: 'auto' }}>{meta}</span> : null}
      </div>
      {desc ? <div className="d">{desc}</div> : null}
      <div className="fmtrow">
        {nativeOnly ? (
          <span className="badge" style={{ fontSize: 12 }} title="Authored skeleton — exists only in this format; nothing to switch or convert">{home === 'ltx' ? '⚡ LTX-native · authored skeleton' : '🎬 H3-native · authored skeleton'}</span>
        ) : (
          <>
            <span className={'chip' + (fmt === 'h3' ? ' on' : '')} onClick={() => pick('h3')}>🎬 H3</span>
            <span className={'chip' + (fmt === 'ltx' ? ' on' : '')} onClick={() => pick('ltx')}>⚡ LTX</span>
          </>
        )}
        <span className="vmeta">{busy ? 'converting…' : nativeOnly ? 'one format only — use a native ' + (home === 'ltx' ? '🎬 H3' : '⚡ LTX') + ' template for the other target' : fmt === home ? 'original format' : 'local conversion — no LLM call'}</span>
      </div>
      <pre style={{ maxHeight: 200, overflow: 'auto' }}>{shown || '…'}</pre>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <button className="btn tiny primary" onClick={() => {
          window.dispatchEvent(new CustomEvent('cps-load-example', { detail: { idea, settings, tip: sendTip } }))
        }}>➜ Send to Input Builder</button>
        {extra || null}
        <button className="btn tiny" onClick={async () => { await copyText(shown || getNative()); toast('Copied (' + (fmt === 'ltx' ? 'LTX' : 'H3') + ' format)') }}>📋 Copy</button>
      </div>
    </div>
  )
}

export default function LearnSection({ templates, corpus, corpusSource, tplSource, tplNotes, conn, sysText, ltxText, toast, loras, hub }) {
  const [tab, setTab] = useState('corpus')
  const [tFilter, setTFilter] = useState('All')
  const [tCat, setTCat] = useState('All')
  const [tQ, setTQ] = useState('')
  /* 🔗 Chain mode: tick several templates, send them to the builder as one chain */
  const [chainMode, setChainMode] = useState(false)
  const [chainPick, setChainPick] = useState([])
  const [tFmt, setTFmtRaw] = useState(() => { try { return localStorage.getItem('cps_learn_fmt') === 'ltx' ? 'ltx' : 'h3' } catch (e) { return 'h3' } }) /* top-level: show ONE format group at a time */
  const setTFmt = (v) => { setTFmtRaw(v); try { localStorage.setItem('cps_learn_fmt', v) } catch (e) {} }
  const [eFilter, setEFilter] = useState('All')
  const [lFilter, setLFilter] = useState('all')
  const lList = (loras || []).filter((l) => lFilter === 'all' || l.model === lFilter)
  const LIB = templates && templates.length ? templates : TEMPLATES
  const tAll = LIB.filter((tp) => !tp.p)
  /* the filter list is built from what is actually loaded, so a brand-new tag always shows */
  const tTags = tagFilters(tAll)
  const nH3 = tAll.filter((tp) => tp.fmt !== 'ltx').length
  const nLtx = tAll.filter((tp) => tp.fmt === 'ltx').length
  const tList = tAll.filter((tp) => (tFmt === 'ltx' ? tp.fmt === 'ltx' : tp.fmt !== 'ltx')).filter((tp) => tFilter === 'All' || groupOf(tp) === tFilter).filter((tp) => tCat === 'All' || ((tp.settings || {}).category || '') === tCat).filter((tp) => !tQ.trim() || ((tp.t || '') + ' ' + (tp.d || '') + ' ' + (tp.idea || '') + ' ' + (tp.tag || '')).toLowerCase().includes(tQ.trim().toLowerCase()))
  const eCats = [...new Set(EXAMPLES.map((e) => e.cat))]
  const pickToggle = (name) => setChainPick((p) => (p.includes(name) ? p.filter((x) => x !== name) : [...p, name]))
  /* The chain runs top to bottom, so the order must be editable — move any pick one step,
     or jump it straight to the front/back. */
  const movePick = (i, dir) => setChainPick((p) => {
    const j = i + dir
    if (j < 0 || j >= p.length) return p
    const q = p.slice()
    const [m] = q.splice(i, 1)
    q.splice(j, 0, m)
    return q
  })
  const jumpPick = (i, to) => setChainPick((p) => {
    const q = p.slice()
    const [m] = q.splice(i, 1)
    q.splice(to === 'end' ? q.length : 0, 0, m)
    return q
  })
  const sendChain = () => {
    const chosen = chainPick.map((n) => (tAll.find((x) => x.t === n) || {})).filter((x) => x.t)
    if (!chosen.length) { toast('Tick at least two templates first'); return }
    if (chosen.length < 2) { toast('🔗 A chain wants two or more templates — tick one more'); return }
    window.dispatchEvent(new CustomEvent('cps-load-chain', {
      detail: {
        scenes: chosen.map((x) => ({ tpl: x.t, idea: x.idea || '' })),
        rule: 'same person in every scene — a new look and a new location per scene',
      },
    }))
    toast('🔗 Chain of ' + chosen.length + ' sent to the builder — the planner writes the consistency bible')
  }
  const eList = EXAMPLES.filter((e) => eFilter === 'All' || e.cat === eFilter)
  const cardProps = { conn, sysText, ltxText, toast }
  return (
    <div>
      {hub !== 'templates' && (
        <div className="subtabs">
          {[['corpus', '🎬 Real examples'], ['library', '📚 Exemplars'], ['loras', '🧬 LoRAs'], ['tips', '💡 Tips']].map(([id, label]) => (
            <button key={id} className={'subtab' + (tab === id ? ' on' : '')} onClick={() => setTab(id)}>{label}</button>
          ))}
        </div>
      )}

      {(hub === 'templates' || tab === 'templates') ? (
        <section className="block">
          <h2>📐 Prompt templates <span className="vmeta">{tList.length} shown · {tplSource}</span>
            <span className="qmark" title="Fill-in skeletons in the exact MiniMax format — send one to the Input Builder to fill its 🧩 placeholders there. Add your own via Forge or the prompts/templates/ folder (tag blocks model: h3 / model: ltx). See Guide → Templates.">?</span>
            <span className="spacer" style={{ flex: 1 }}></span>
            <button type="button" className={'btn tiny' + (chainMode ? ' primary' : '')}
              onClick={() => { setChainMode((m) => !m); setChainPick([]) }}
              title="Tick several templates, then send them to the builder as ONE chain — scene per template, same person, new look and location each scene">🔗 Chain mode</button>
            <button type="button" className="btn tiny primary" onClick={() => window.dispatchEvent(new Event('cps-open-manager'))}>📦 Manage my templates</button>
          </h2>
          {tplNotes && tplNotes.length ? (
            <details style={{ marginBottom: 10, fontSize: 12.5 }}>
              <summary style={{ cursor: 'pointer', color: '#fca5a5' }}>
                ⚠ {tplNotes.length} file{tplNotes.length > 1 ? 's' : ''} in <code>prompts/templates/</code> gave no templates — click for the reason
              </summary>
              <div style={{ lineHeight: 1.8, marginTop: 4 }}>
                {tplNotes.map((n, i) => (<div key={i}>✗ <b>{n.file}</b> — {n.note}</div>))}
                <div className="vmeta" style={{ marginTop: 4 }}>
                  A block is a <code>## Title</code> line plus a skeleton — <code>integrated_multimodal_description:</code> for H3
                  (with <code>overall_soundscape:</code> and <code>non_diegetic_music:</code>) or <code>prompt:</code> for LTX. Fences are optional;
                  <code> README.md</code> and <code>_</code>-prefixed files are skipped on purpose. Nested folders are scanned live — if one of
                  your subfolders is missing entirely, see Guide → Templates → “a file of mine is not listed”.
                </div>
              </div>
            </details>
          ) : null}
          <div className="chips" style={{ marginBottom: 10 }}>
            <span className={'chip' + (tFmt === 'h3' ? ' on' : '')} onClick={() => setTFmt('h3')}>🎬 H3 / MiniMax ({nH3})</span>
            <span className={'chip' + (tFmt === 'ltx' ? ' on' : '')} onClick={() => setTFmt('ltx')}>⚡ LTX-Video ({nLtx})</span>
            <span className="vmeta" style={{ marginLeft: 8 }}>{tFmt === 'ltx' ? 'one-paragraph prompt + negative + tags skeletons' : 'three-field integrated_multimodal_description skeletons'}</span>
          </div>
          <div className="chips" style={{ marginBottom: 12 }}>
            {tTags.map((tg) => (
              <span key={tg} className={'chip' + (tFilter === tg ? ' on' : '')} onClick={() => setTFilter(tg)}>
                {tg === 'All' ? 'All' : tagLabel(tg)}
              </span>
            ))}
            <input type="text" value={tQ} onChange={(e) => setTQ(e.target.value)} placeholder="🔎 search templates…" title="Filter by title, description, idea or tag" style={{ width: 190, marginLeft: 'auto' }} />
            <select value={tCat} onChange={(e) => setTCat(e.target.value)} style={{ width: 'auto', minWidth: 170, marginLeft: 8 }}>
              <option value="All">All categories</option>
              {Object.entries(CATEGORIES).map(([id, label]) => <option key={id} value={id}>{label}</option>)}
            </select>
          </div>
          {chainMode ? (
            <div className="chainbar" style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', border: '1px dashed var(--border)', borderRadius: 9, padding: '7px 9px', marginBottom: 10 }}>
              <b style={{ fontSize: 12.5 }}>🔗 Chain mode</b>
              <span className="vmeta">tick templates in any order, then arrange them here — ◀ ▶ move a scene one step, ⇤ ⇥ send it to the front or the back, ✕ removes it. Each scene keeps its own skeleton and 🧩 fields.</span>
              <span className="spacer" style={{ flex: 1 }}></span>
              {chainPick.length ? (
                <>
                  <span className="vmeta" style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                    {chainPick.map((n, i) => (
                      <span key={n} className="mpill" style={{ display: 'inline-flex', alignItems: 'center', gap: 3 }}>
                        <b style={{ opacity: 0.75 }}>{i + 1}.</b>
                        <span>{n}</span>
                        <button type="button" className="qbtn" style={{ padding: '0 3px' }} disabled={i === 0}
                          title="Move one scene earlier" onClick={() => movePick(i, -1)}>◀</button>
                        <button type="button" className="qbtn" style={{ padding: '0 3px' }} disabled={i === chainPick.length - 1}
                          title="Move one scene later" onClick={() => movePick(i, 1)}>▶</button>
                        <button type="button" className="qbtn" style={{ padding: '0 3px' }} disabled={i === 0}
                          title="Make this the first scene" onClick={() => jumpPick(i, 'start')}>⇤</button>
                        <button type="button" className="qbtn" style={{ padding: '0 3px' }} disabled={i === chainPick.length - 1}
                          title="Make this the last scene" onClick={() => jumpPick(i, 'end')}>⇥</button>
                        <button type="button" className="qbtn" style={{ padding: '0 3px' }} title="Remove from the chain"
                          onClick={() => pickToggle(n)}>✕</button>
                      </span>
                    ))}
                  </span>
                  <button type="button" className="btn tiny" onClick={() => setChainPick((p) => [...p].reverse())} title="Reverse the scene order">⇅</button>
                  <button type="button" className="btn tiny" onClick={() => setChainPick([])}>✕ Clear</button>
                  <button type="button" className="btn tiny primary" onClick={sendChain}>
                    ➜ Send chain to Builder ({chainPick.length})
                  </button>
                </>
              ) : <span className="vmeta">nothing ticked yet</span>}
            </div>
          ) : null}
          <div className="tgrid">
            {tList.length === 0 ? <div className="hint">No {tFmt === 'ltx' ? '⚡ LTX' : '🎬 H3'} templates match — switch to the other format group above, clear the tag/category filters, or add blocks tagged <code>{'model: ' + tFmt}</code> in <code>the prompts/templates/ folder — drop any .md in (name yours user-*.md)</code>.</div> : null}
            {tList.map((tp) => (
              <TemplateCard key={tp.t} t={tp} current={''}
                primaryLabel={chainMode ? (chainPick.includes(tp.t) ? '✓ In the chain (' + (chainPick.indexOf(tp.t) + 1) + ')' : '➕ Add to chain')
                  : tp.chain ? '🔗 Chain ' + tp.chain + ' scenes' : '➜ Send to Builder'}
                onPrimary={(t2) => {
                  if (chainMode) { pickToggle(t2.t); return }
                  if (t2.chain) {
                    /* a chain recipe: the builder gets N scenes of THIS template, with the
                       recipe rule handed to the planner so the bible locks consistency */
                    window.dispatchEvent(new CustomEvent('cps-load-chain', {
                      detail: { scenes: Array.from({ length: t2.chain }, () => ({ tpl: t2.t, idea: t2.idea || '' })), rule: t2.chainRule || '' },
                    }))
                    return
                  }
                  window.dispatchEvent(new CustomEvent('cps-load-example', { detail: { idea: t2.idea, settings: { ...t2.settings, template: t2.t }, tip: 'Template loaded into Input Builder — its skeleton is attached and the 🧩 placeholders are ready to fill' } }))
                }}
                extra={<button type="button" className="btn tiny" title="Edit the raw block" onClick={(e) => { e.stopPropagation(); window.dispatchEvent(new CustomEvent('cps-forge-from', { detail: { mode: 'edit', raw: templateToMd(tp), target: tp.fmt === 'ltx' ? 'ltx' : 'h3' } })) }}>✏️</button>} />
            ))}
          </div>
        </section>
      ) : null}

      {hub !== 'templates' && tab === 'corpus' ? (
        <section className="block">
          <h2>🎬 Real example prompts <span className="vmeta">{(corpus || []).length} · {corpusSource}</span></h2>
          <div style={{ color: 'var(--dim)', fontSize: 12.5, margin: '-4px 0 10px' }}>
            Real-world prompts in the exact three-field contract, curated from the{' '}
            <a href="https://huggingface.co/datasets/ostris/minimax_h3_1k" target="_blank" rel="noopener">ostris/minimax_h3_1k</a>{' '}
            corpus. Send one to the Input Builder (it arrives with ✨ Enhance on, so the model rewrites it fresh) — or flip it to ⚡ LTX.
          </div>
          <div className="cards">
            {(corpus || []).map((p) => (
              <LearnCard key={p.t} title={p.t} badge={(p.genre || '').slice(0, 40)}
                getNative={() => p.b}
                idea={p.b} settings={{ enhance: true }}
                sendTip="Loaded with ✨ Enhance on — Generate rewrites it into a fresh perfect prompt"
                {...cardProps} />
            ))}
          </div>
        </section>
      ) : null}

      {hub !== 'templates' && tab === 'library' ? (
        <section className="block">
          <h2>📚 Hand-written exemplars <span className="vmeta">{eList.length} of {EXAMPLES.length}</span>
            <select value={eFilter} onChange={(e) => setEFilter(e.target.value)}
              style={{ float: 'right', width: 'auto', minWidth: 220, fontSize: 13 }}>
              <option>All</option>
              {eCats.map((c) => <option key={c}>{c}</option>)}
            </select>
          </h2>
          <div style={{ color: 'var(--dim)', fontSize: 13, margin: '-4px 0 14px' }}>
            H3-correct exemplars, one per category — the same ones auto-injected as few-shot knowledge when you generate.
          </div>
          <div className="cards">
            {eList.map((ex) => (
              <LearnCard key={ex.title} title={ex.title} badge={ex.cat} meta={ex.prompt.length + ' chars'}
                desc={ex.blurb} getNative={() => ex.prompt}
                idea={ex.idea} settings={ex.settings || {}}
                sendTip="Exemplar loaded into Input Builder"
                {...cardProps} />
            ))}
          </div>
        </section>
      ) : null}

      {hub !== 'templates' && tab === 'loras' ? (
        <section className="block">
          <h2>🧬 LoRA library <span className="vmeta">{lList.length} shown · extend in prompts/loras.md</span>
            <select value={lFilter} onChange={(e) => setLFilter(e.target.value)}
              style={{ float: 'right', width: 'auto', minWidth: 180, fontSize: 13 }}>
              <option value="all">All models</option>
              <option value="h3">MiniMax H3</option>
              <option value="ltx">LTX-Video</option>
              <option value="both">Both</option>
            </select>
          </h2>
          <div style={{ color: 'var(--dim)', fontSize: 12.5, margin: '-4px 0 12px' }}>
            Strengths + triggers for your local ComfyUI runs on BOTH ecosystems. <b>➜ Arm in builder</b> adds it to the
            🧬 LoRAs section so output cards carry it and <b>Copy w/ triggers</b> prepends the trigger words.
          </div>
          <div className="cards">
            {lList.map((l) => (
              <div className="tpl" key={l.t}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                  <span className="t" style={{ margin: 0 }}>{l.t}</span>
                  <span className="badge">{l.type}</span>
                  <span className="vmeta" style={{ marginLeft: 'auto' }}>
                    {l.model === 'h3' ? 'MiniMax H3' : l.model === 'ltx' ? 'LTX-Video' : 'H3 + LTX'} · {l.strength ? l.strength.split(' (')[0] : '—'}
                  </span>
                </div>
                <div className="d">{l.d}</div>
                <div className="hint" style={{ margin: '6px 0 8px' }}>
                  {l.trigger !== 'none' ? <>Trigger: <code>{l.trigger}</code></> : 'No trigger word — pattern / reference-video based.'}
                </div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  <button className="btn tiny primary" onClick={() => {
                    window.dispatchEvent(new CustomEvent('cps-lora-add', { detail: l.t }))
                    toast('🧬 ' + l.t + ' armed in the builder’s LoRAs section')
                  }}>➜ Arm in builder</button>
                  {l.trigger !== 'none' ? (
                    <button className="btn tiny" onClick={async () => { await copyText(l.trigger.split(' (')[0]); toast('Trigger copied') }}>📋 Copy trigger</button>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      {hub !== 'templates' && tab === 'tips' ? <TipsSection /> : null}
    </div>
  )
}
