import { useEffect, useState } from 'react'
import { fmtBytes, fmtAgo } from '../lib/ollama.js'
import { PROVIDERS, LOCAL_PRESETS, ENV } from '../lib/providers.js'
import { parseTemplatesMd } from '../lib/templates.js'
import { resolveIncludes } from '../lib/sysfiles.js'
import { ENGINE_MODES, ENGINE_OPTIONS, engineSummary, resetEngineSettings } from '../lib/enginesettings.js'

const KNOWN_PROMPTS = ['system-prompt.md', 'ltx-system-prompt.md', 'system-prompt-mature.md', 'ltx-system-prompt-mature.md']
const SLOTS = [
  ['h3', 'H3 · SFW'],
  ['ltx', 'LTX · SFW'],
  ['h3m', 'H3 · 18+'],
  ['ltxm', 'LTX · 18+'],
]

const KEYMAP = { gemini: 'cps_gemini_key', groq: 'cps_groq_key', openai: 'cps_oai_key', openrouter: 'cps_openrouter_key' }

/* ⚙️ Four tabs instead of one long scroll: the engine controls used to live in the Studio
   form, the keys and models here, and the routing further down the same page. */
const TABS = [
  ['engine', '🎛 Engine'],
  ['provider', '🤖 Provider'],
  ['prompts', '📄 System prompts'],
  ['templates', '📂 Templates'],
]

export default function SettingsModal({ open, onClose, tab, onTab, engSet, setEngSet, mature, setMature, critOn, setCritOn, conn, setModel, detect, sysPrompt, setSysPrompt, sysMature, ltxMature, ltxPrompt, sysRoute, setSysRoute, sysFiles, sysCustom, setSysCustom, toast, packs }) {
  const NOW = tab || 'engine'
  const [customBase, setCustomBase] = useState(() => localStorage.getItem('cps_ollama_base') || ENV.ollamaUrl || '')
  const provider = conn.provider || 'ollama'
  const [apiKey, setApiKey] = useState('')
  const [oaiBase, setOaiBase] = useState('')
  const selStyle = { fontSize: 12, background: 'var(--bg)', color: 'var(--text)', border: '1px solid var(--border)', borderRadius: 7, padding: '5px 7px', maxWidth: 360 }
  const [promptFiles, setPromptFiles] = useState(KNOWN_PROMPTS)
  const [tree, setTree] = useState([])
  useEffect(() => {
    if (!open) return
    let dead = false
    ;(async () => {
      const get = async (u) => { try { const r = await fetch(u, { cache: 'no-store' }); if (!r.ok) return null; const j = await r.json(); return Array.isArray(j) ? j : null } catch (e) { return null } }
      const top = await get('prompts/_index.json')
      const all = await get('prompts/_tree.json')
      const list = [...(top || KNOWN_PROMPTS).filter((x) => x.endsWith('.md')), ...((all || []).filter((x) => x.includes('/')))]
      if (!dead) {
        setPromptFiles([...new Set([...KNOWN_PROMPTS.filter((k) => list.includes(k)), ...list])])
        setTree(all || [])
      }
    })()
    return () => { dead = true }
  }, [open])
  const [localBase, setLocalBase] = useState('')
  const [localKey, setLocalKey] = useState('')
  const [imp, setImp] = useState(() => { try { return !!localStorage.getItem('cps_user_tpl') } catch (e) { return false } })
  const [tplTxt, setTplTxt] = useState(() => { try { return localStorage.getItem('cps_user_tpl') || '' } catch (e) { return '' } })
  const [scanRes, setScanRes] = useState(null)
  const impReady = (() => { try { return parseTemplatesMd(tplTxt).length } catch (e) { return 0 } })()
  useEffect(() => {
    if (open) {
      setApiKey(localStorage.getItem(KEYMAP[provider]) || ({ openrouter: ENV.openrouterKey, openai: ENV.openaiKey, gemini: ENV.geminiKey, groq: ENV.groqKey }[provider]) || '')
      setOaiBase(localStorage.getItem('cps_oai_base') || ENV.openaiBase || 'https://api.openai.com/v1')
      setLocalBase(localStorage.getItem('cps_local_base') || ENV.localUrl || LOCAL_PRESETS['llama.cpp'])
      setLocalKey(localStorage.getItem('cps_local_key') || ENV.localKey || '')
    }
  }, [open, provider])
  const switchProvider = (id) => {
    try { localStorage.setItem('cps_provider', id) } catch (e) {}
    window.dispatchEvent(new Event('cps-provider-changed'))
  }
  const saveCloud = () => {
    try {
      if (KEYMAP[provider]) localStorage.setItem(KEYMAP[provider], apiKey.trim())
      if (provider === 'openai') localStorage.setItem('cps_oai_base', oaiBase.trim().replace(/\/$/, '') || 'https://api.openai.com/v1')
    } catch (e) {}
    window.dispatchEvent(new Event('cps-provider-changed'))
    toast('Saved — connecting to ' + PROVIDERS[provider].label + '…')
  }
  const saveLocal = () => {
    try {
      localStorage.setItem('cps_local_base', localBase.trim().replace(/\/$/, '') || LOCAL_PRESETS['llama.cpp'])
      localStorage.setItem('cps_local_key', localKey.trim())
    } catch (e) {}
    window.dispatchEvent(new Event('cps-provider-changed'))
    toast('Saved — connecting to your local server…')
  }

  useEffect(() => { if (open) setCustomBase(localStorage.getItem('cps_ollama_base') || ENV.ollamaUrl || '') }, [open])

  // Esc closes
  useEffect(() => {
    if (!open) return
    const h = (e) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [open, onClose])

  if (!open) return null

  const useBase = () => {
    const v = customBase.trim().replace(/\/$/, '')
    if (v) localStorage.setItem('cps_ollama_base', v)
    else localStorage.removeItem('cps_ollama_base')
    detect(v || undefined)
  }

  const onFile = (e) => {
    const f = e.target.files[0]
    if (!f) return
    f.text().then(async (t) => {
      const txt = t.trim()
      if (!txt) { toast('That file is empty'); return }
      const read = async (p) => {
        const r = await fetch(p, { cache: 'no-store' })
        if (!r.ok) throw new Error('HTTP ' + r.status)
        return await r.text()
      }
      const res = await resolveIncludes(txt, 'prompts/' + f.name, read)
      setSysCustom({ name: f.name, text: res.text, deps: res.deps, missing: res.missing, cycles: res.cycles })
      setSysRoute((r) => ({ ...(r || {}), universal: 'custom' }))
      toast(res.missing.length
        ? '⚠ ' + f.name + ' is now the UNIVERSAL system prompt — ' + res.missing.length + ' dependency file(s) not found'
        : res.deps.length
          ? f.name + ' is now the UNIVERSAL system prompt — used for H3 + LTX, SFW + 18+ · ' + res.deps.length + ' dependency file(s) inlined'
          : f.name + ' is now the UNIVERSAL system prompt — used for H3 + LTX, SFW + 18+' + (String(res.text).length < 800 ? ' (⚠ only ' + res.text.length + ' chars — is that the whole file?)' : ''))
    })
  }

  const reload = () => {
    window.dispatchEvent(new Event('cps-reload-sysprompt'))
    toast('Reloading system prompt…')
  }

  const statusTxt =
    sysPrompt.status === 'loading' ? 'loading…'
      : sysPrompt.status === 'ok' ? <>✓ prompts/system-prompt.md · {sysPrompt.text.length} chars{(sysPrompt.deps || []).length ? <> + {(sysPrompt.deps || []).length} dependency file{(sysPrompt.deps || []).length === 1 ? '' : 's'}</> : null}</>
      : <>⚠ system-prompt.md unreachable — built-in fallback active</>

  /* what each generation will actually use, given the route */
  const routeNow = (slot) => {
    const r = sysRoute || {}
    if (r.universal === 'custom') return '📂 ' + ((sysCustom && sysCustom.name) || 'uploaded')
    if (r.universal) return '🌐 ' + r.universal.replace(/^prompts\//, '')
    const v = r[slot]
    if (v === 'custom') return '📂 ' + ((sysCustom && sysCustom.name) || 'uploaded')
    if (v) return '🎯 ' + v.replace(/^prompts\//, '')
    return ''
  }
  /* every system prompt file, its size and the files it pulled in itself */
  const promptRows = [
    ['H3 · SFW', sysPrompt],
    ['LTX · SFW', ltxPrompt],
    ['H3 · 18+', sysMature],
    ['LTX · 18+', ltxMature],
  ].filter(([, o]) => o && o.status && o.status !== 'none')
  const depPanel = (
    <div style={{ marginTop: 8, border: '1px solid var(--border)', borderRadius: 8, padding: '7px 9px' }}>
      {promptRows.map(([label, o]) => {
        const deps = o.deps || [], miss = o.missing || [], cyc = o.cycles || []
        return (
          <div key={label} style={{ display: 'flex', gap: 8, alignItems: 'baseline', flexWrap: 'wrap', fontSize: 12, lineHeight: 1.7 }}>
            <b style={{ minWidth: 62, color: 'var(--text)' }}>{label}</b>
            <span style={{ color: o.status === 'ok' || o.status === 'override' ? 'var(--dim)' : '#e0a34a' }}>
              {o.status === 'loading' ? 'loading…' : o.status === 'ok' ? (o.text || '').length + ' chars' : o.status === 'override' ? 'override · ' + (o.text || '').length + ' chars' : 'fallback'}
            </span>
            <span>{routeNow(({ 'H3 · SFW': 'h3', 'LTX · SFW': 'ltx', 'H3 · 18+': 'h3m', 'LTX · 18+': 'ltxm' })[label] || '') || (o.status === 'ok' ? 'auto' : '')}</span>
            <span>📎 {deps.length}</span>
            {deps.map((d) => <code key={d}>{d}</code>)}
            {miss.map((m) => <span key={'m' + m.path} style={{ color: '#e0a34a' }}>⚠ missing {m.path}</span>)}
            {cyc.map((c) => <span key={'c' + c} style={{ color: '#e0a34a' }}>⚠ circular {c}</span>)}
            {!deps.length && !miss.length ? <span style={{ color: 'var(--faint)' }}>no dependencies of its own</span> : null}
          </div>
        )
      })}
      {/* 🧩 attach your own files to a slot — no prompt file is edited */}
      {[['all', '🌐 all generations'], ['h3', 'H3 · SFW'], ['ltx', 'LTX · SFW'], ['h3m', 'H3 · 18+'], ['ltxm', 'LTX · 18+']].map(([key, label]) => {
        const list = ((sysRoute || {}).attach || {})[key] || []
        return (
          <div key={'att' + key} style={{ display: 'flex', gap: 8, alignItems: 'baseline', flexWrap: 'wrap', fontSize: 12, lineHeight: 1.9, marginTop: key === 'all' ? 8 : 2 }}>
            <b style={{ minWidth: 62, color: 'var(--text)' }}>{label}</b>
            <span style={{ color: 'var(--faint)' }}>🧩</span>
            {list.map((p) => (
              <span key={p} className="mpill" style={{ cursor: 'pointer' }} title="Remove — click"
                onClick={() => setSysRoute((r) => { const a = { ...((r || {}).attach || {}) }; a[key] = (a[key] || []).filter((x) => x !== p); return { ...(r || {}), attach: a } })}>{p} ✕</span>
            ))}
            <select value="" style={selStyle} title="Attach a .md file to these generations — appended to the system prompt, includes resolved, nothing edited"
              onChange={(e) => {
                const v = e.target.value
                if (!v) return
                setSysRoute((r) => { const a = { ...((r || {}).attach || {}) }; a[key] = [...new Set([...(a[key] || []), v])]; return { ...(r || {}), attach: a } })
                toast('🧩 ' + v + ' attached to ' + label)
              }}>
              <option value="">➕ attach file…</option>
              {(tree.length ? tree : promptFiles.map((p) => (p.startsWith('prompts/') ? p.slice(8) : p))).map((p) => <option key={key + p} value={'prompts/' + p}>{p}</option>)}
            </select>
          </div>
        )
      })}
    </div>
  )

  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="modal" role="dialog" aria-modal="true">
        <div className="modal-head">
          <h3>⚙️ Settings — engine, provider, prompts &amp; templates</h3>
          <div className="spacer"></div>
          <button className="btn tiny" onClick={onClose} title="Close (Esc)">✕ Close</button>
        </div>
        <div className="modal-body">
          <div className="hint" style={{ margin: '0 0 10px' }}>🔐 Keys persist in this browser — or put them in the project <code>.env</code> to survive cache clears (<code>.env.example</code>). Restart <code>npm run dev</code> after editing it.</div>

          <div className="tabbar">
            {TABS.map(([id, label]) => (
              <button key={id} type="button" className={'tab' + (NOW === id ? ' on' : '')} onClick={() => onTab && onTab(id)}>{label}</button>
            ))}
            <div className="spacer"></div>
            <span className="vmeta">{conn.status === 'ok' ? '✓ ' + (conn.model || 'connected') : conn.status === 'nokey' ? '⚠ key required' : conn.status === 'checking' ? '· checking…' : '· offline engine'}</span>
          </div>

          {NOW === 'engine' && (() => {
            const S = engineSummary(engSet, conn, critOn)
            const mat = sysMature
            const n = ((mat && mat.text) || '').trim().length
            const blocked = (() => { try { return localStorage.getItem('cps_nsfw_blocked') === '1' } catch (e) { return false } })()
            return (
              <>
                <div className="connbox">
                  <b style={{ color: 'var(--text)' }}>🎛 Engine — what writes your prompts</b>
                  <div className="nowstrip">
                    <span className="vmeta">Next generation runs</span>
                    <b>{S.mode}</b>
                    {S.model ? <code>{S.model}</code> : null}
                    <span className="vmeta">· {S.chips.join(' · ')} · temp {S.temperature}</span>
                  </div>
                  <div className="frow">
                    <label>Engine</label>
                    <select value={engSet.engine} onChange={(e) => setEngSet({ engine: e.target.value })} style={selStyle}>
                      {ENGINE_MODES.map(([id, label]) => <option key={id} value={id}>{label}</option>)}
                    </select>
                  </div>
                  <div className="frow">
                    <label>Model</label>
                    <select value={conn.model} onChange={(e) => setModel(e.target.value)} style={selStyle}>
                      {conn.models.length === 0 && <option value="">{conn.status === 'checking' ? '— detecting… —' : conn.status === 'nokey' ? '— add an API key in 🤖 Provider —' : 'No models detected'}</option>}
                      {conn.model && ![...conn.models].some((x) => x.name === conn.model) && (
                        <option value={conn.model}>✍️ {conn.model} (typed)</option>
                      )}
                      {[...conn.models].sort((x, y) => x.name.localeCompare(y.name)).map((x) => (
                        <option key={x.name} value={x.name}>{x.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="frow">
                    <label>Model name<span className="opt">type anything — cloud or uninstalled</span></label>
                    <input type="text" value={conn.model} onChange={(e) => setModel(e.target.value)}
                      placeholder={conn.provider === 'ollama' ? 'e.g. qwen3:32b, llama3.3:70b or an Ollama-cloud model name' : 'e.g. gemini-2.5-pro, llama-3.3-70b-versatile…'} />
                  </div>
                  <div className="frow">
                    <label>Variants<span className="opt">cards per generation</span></label>
                    <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
                      <div className="chips">
                        {['1', '2', '3'].map((v) => (
                          <button key={v} type="button" className={'chip' + (String(engSet.variants) === v ? ' on' : '')}
                            onClick={() => setEngSet({ variants: v })}>{v}</button>
                        ))}
                      </div>
                      <span style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1, minWidth: 150 }}>
                        <input type="range" min="0.2" max="1.2" step="0.05" value={engSet.temperature}
                          onChange={(e) => setEngSet({ temperature: +e.target.value })} />
                        <span className="rangeval" title="Temperature — how far the model wanders">{Number(engSet.temperature).toFixed(2)}</span>
                      </span>
                    </div>
                  </div>
                  <div className="frow" style={{ alignItems: 'start' }}>
                    <label style={{ paddingTop: 3 }}>Options</label>
                    <div>
                      {ENGINE_OPTIONS.map((o) => {
                        if (o.key === 'mature') {
                          return (
                            <label className="checkboxrow" key={o.key}>
                              <input type="checkbox" checked={!!mature && !blocked} disabled={blocked} onChange={(e) => {
                                if (blocked) return
                                setMature(e.target.checked)
                                toast(e.target.checked ? '🔞 18+ on — your mature system prompt file now runs' : '🛡️ 18+ off — the SFW system prompt runs')
                              }} />
                              {o.icon} <b>{o.label}</b>{blocked ? ' · 🚫 BLOCKED by operator' : ' · ' + o.hint}
                            </label>
                          )
                        }
                        if (o.app) {
                          return (
                            <label className="checkboxrow" key={o.key}>
                              <input type="checkbox" checked={!!critOn} onChange={(e) => { setCritOn(e.target.checked); toast(e.target.checked ? '🧪 Critic armed — every output card gets a Critique button (one small LLM call each)' : '🧪 Critic off — no critique LLM calls') }} />
                              {o.icon} <b>{o.label}</b> — {o.hint}
                            </label>
                          )
                        }
                        return (
                          <label className="checkboxrow" key={o.key}>
                            <input type="checkbox" checked={!!engSet[o.key]} onChange={(e) => setEngSet({ [o.key]: e.target.checked })} />
                            {o.icon} <b>{o.label}</b> — {o.hint}
                          </label>
                        )
                      })}
                      {!blocked && (!mature
                        ? <div className="hint" style={{ margin: '-2px 0 6px' }}>🛡️ 18+ off — generations run <b>prompts/system-prompt.md</b> (H3) and <b>prompts/ltx-system-prompt.md</b> (LTX).</div>
                        : (!n
                          ? <div className="hint" style={{ margin: '-2px 0 6px', color: 'var(--warn, #e0a14a)' }}>⚠️ 18+ on, but <b>prompts/system-prompt-mature.md</b> is {(mat && mat.status) === 'fallback' ? 'unreachable' : 'empty'} — the run would fall back to the SFW file. Edit it and hit ↻ Reload from file in 📄 System prompts.</div>
                          : <div className="hint" style={{ margin: '-2px 0 6px' }}>🔞 18+ on — generations run <b>prompts/system-prompt-mature.md</b> ({n.toLocaleString()} chars{(mat && mat.deps && mat.deps.length) ? ' · 📎 ' + mat.deps.length + ' dependencies' : ' · 📎 0 — no @include in that file'}).</div>))}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap', alignItems: 'center' }}>
                    <button type="button" className="btn tiny ghost" onClick={() => { resetEngineSettings(); toast('↺ Engine settings reset — reopen ⚙️ Settings to see the defaults') }}>↺ Reset defaults</button>
                    <span className="vmeta">These sat in the Studio form's Engine card until v2.26 — the form now shows this summary and links back here.</span>
                  </div>
                </div>
                <div className="connbox">
                  <b style={{ color: 'var(--text)' }}>Where the rest lives</b>
                  <div style={{ marginTop: 6, lineHeight: 1.9 }}>
                    <b>🤖 Provider</b> — Ollama / local inference / cloud keys, the live model list and ↻ Re-check.<br />
                    <b>📄 System prompts</b> — which prompt file each generation runs, its dependencies and your attachments.<br />
                    <b>📂 Templates</b> — paste, scan and import your own template files.
                  </div>
                </div>
              </>
            )
          })()}
          {NOW === 'templates' && (<>
          <div className="connbox">
            <b style={{ color: 'var(--text)' }}>📂 Your templates — paste, scan, import</b>
            <div className="hint" style={{ margin: '6px 0 8px' }}>Paste the contents of your own <code>a user-*.md file in prompts/templates/</code>. Scan first; if anything is wrong it says exactly what. Stored <b>only in this browser</b> and wins over the served copy — private content never leaves your machine. Blocks: <code>## Title</code> + skeleton (<code>prompt:</code> … for LTX / <code>integrated_multimodal_description:</code> … for H3) — or tag blocks <code>model: ltx</code> / <code>model: h3</code>.</div>
            <textarea value={tplTxt} onChange={(e) => { setTplTxt(e.target.value); setScanRes(null) }} rows={7}
              placeholder={'## My template\nmodel: ltx\ntag: fashion\n\n```\nprompt: your one-paragraph LTX prompt…\n\nnegative_prompt: text, watermark\n```'}
              style={{ width: '100%', fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', fontSize: 11.5, lineHeight: 1.5, background: 'var(--bg)', color: 'var(--text)', border: '1px solid var(--border)', borderRadius: 8, padding: 8 }} />
            <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }}>
              <button type="button" className="btn tiny" onClick={() => {
                const blocks = parseTemplatesMd(tplTxt)
                const rows = (parseTemplatesMd.report || []).slice()
                setScanRes({ ok: blocks.length, bad: rows.filter((r) => r.error).length, rows })
                if (!tplTxt.trim()) toast('Paste your template text first');
                else if (!blocks.length) toast('⚠ Nothing parses yet — the ✗ lines below say exactly why')
                else toast('🔍 ' + blocks.length + ' block(s) OK — press 💾 Import to save them in this browser')
              }}>🔍 Scan</button>
              <button type="button" className="btn tiny primary" disabled={!impReady} onClick={() => {
                localStorage.setItem('cps_user_tpl', tplTxt)
                window.dispatchEvent(new Event('cps-reload-sysprompt'))
                setImp(true)
                toast('📂 Imported — ' + impReady + ' template block(s) now live in 📐 Templates and the picker (browser storage only)')
              }}>💾 Import{impReady ? ' ' + impReady + ' block(s)' : ''}</button>
              {imp ? <button type="button" className="btn tiny" onClick={() => { localStorage.removeItem('cps_user_tpl'); window.dispatchEvent(new Event('cps-reload-sysprompt')); setImp(false); toast('Import cleared — using the served a user-*.md file in prompts/templates/ again') }}>✕ Clear import</button> : null}
              <button type="button" className="btn tiny" onClick={() => window.dispatchEvent(new Event('cps-open-manager'))}>📦 Open manager</button>
              <span className="vmeta">{imp ? 'imported version active (browser)' : 'served file active'}</span>
            </div>
            {scanRes && scanRes.rows.length ? (
              <div style={{ marginTop: 8, fontSize: 12, lineHeight: 1.7, maxHeight: 150, overflow: 'auto', borderTop: '1px dashed var(--border)', paddingTop: 6 }}>
                <div className="vmeta" style={{ marginBottom: 2 }}>scan: {scanRes.ok} ok · {scanRes.bad} skipped</div>
                {scanRes.rows.map((r, i) => r.error
                  ? <div key={i} style={{ color: '#fca5a5' }}>✗ <b>{r.t || '(untitled)'}</b> — {r.error}</div>
                  : <div key={i}>✓ {r.fmt === 'ltx' ? '⚡ LTX' : '🎬 H3'} — <b>{r.t}</b>{r.note ? <span className="vmeta"> · {r.note}</span> : null}</div>)}
              </div>
            ) : null}
          </div>
          </>)}
          {NOW === 'provider' && (<>
          <div className="connbox">
            <b style={{ color: 'var(--text)' }}>AI provider</b>
            <div className="chips" style={{ marginTop: 7 }}>
              {Object.entries(PROVIDERS).map(([id, def]) => (
                <button key={id} type="button" className={'chip' + (provider === id ? ' on' : '')} onClick={() => switchProvider(id)}>{def.label}</button>
              ))}
            </div>
            <div style={{ margin: '7px 0', fontSize: 11.5, color: 'var(--faint)' }}>{PROVIDERS[provider].hint}</div>
            {provider === 'local' && (
              <div style={{ display: 'grid', gap: 7 }}>
                <div style={{ fontSize: 11.5, color: 'var(--faint)' }}>
                  Point this at any self-hosted inference server running your quantized models — no Ollama needed:
                </div>
                <div className="chips">
                  {Object.entries(LOCAL_PRESETS).map(([name, url]) => (
                    <button key={name} type="button" className={'chip' + (localBase.replace(/\/$/, '') === url ? ' on' : '')}
                      onClick={() => setLocalBase(url)}>{name}</button>
                  ))}
                </div>
                <pre style={{ margin: 0 }}>{`# llama.cpp with an int8/Q8 model (fast, tiny RAM):
llama-server -m qwen2.5-7b-instruct-q8_0.gguf --port 8080 -c 8192

# vLLM with safetensors weights:
vllm serve Qwen/Qwen2.5-7B-Instruct --port 8000

# Already downloaded ComfyUI captioning models work too:
# Only have gemma_3_12B_it_fp4_mixed.safetensors? Same model, but chat
# servers need GGUF packaging — official QAT GGUF, same size class:
#   hf.co/google/gemma-3-12b-it-qat  (or: ollama pull gemma3:12b)
llama-server -m gemma-3-12b-it-qat-q4_0.gguf --port 8080 -c 8192
# Qwen3-VL-32B (H3's encoder family) writes prompts AND reads frames —
llama-server -m qwen3-vl-32b-q8.gguf --mmproj qwen3-vl-mmproj.gguf --port 8080`}</pre>
                <input type="text" value={localBase} onChange={(e) => setLocalBase(e.target.value)}
                  placeholder="Base URL — e.g. http://localhost:8080/v1" />
                <input type="password" value={localKey} onChange={(e) => setLocalKey(e.target.value)}
                  placeholder="API key (optional — most local servers don't need one)" autoComplete="off" />
                <div>
                  <button className="btn tiny primary" onClick={saveLocal}>💾 Save &amp; connect</button>{' '}
                  <span style={{ fontSize: 11, color: conn.status === 'ok' ? 'var(--green)' : conn.status === 'checking' ? 'var(--accent)' : 'var(--red)' }}>
                    {conn.status === 'ok' ? '✓ connected · ' + conn.models.length + ' models' : conn.status === 'checking' ? '· connecting…' : conn.error ? '· ' + conn.error : ''}
                  </span>
                </div>
                <div style={{ fontSize: 11, color: 'var(--faint)' }}>
                  Model list comes live from the server's <code>/v1/models</code>. GGUF Q8_0/int8 builds give you the
                  small-and-fast profile — e.g. a 7B Q8 fits in ~8 GB RAM and streams much quicker than fp16.
                  With a vision-capable model (Qwen3-VL + mmproj), frame reading for 🖼 references also runs
                  through this server — no Ollama needed.
                </div>
              </div>
            )}
            {provider !== 'ollama' && provider !== 'local' && (
              <div style={{ display: 'grid', gap: 7 }}>
                <input type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)}
                  placeholder="API key — stored only in this browser's localStorage" autoComplete="off" />
                {provider === 'openai' && (
                  <input type="text" value={oaiBase} onChange={(e) => setOaiBase(e.target.value)}
                    placeholder="Base URL — e.g. https://openrouter.ai/api/v1 or https://api.openai.com/v1" />
                )}
                <div>
                  <button className="btn tiny primary" onClick={saveCloud}>💾 Save &amp; connect</button>{' '}
                  <span style={{ fontSize: 11, color: conn.status === 'ok' ? 'var(--green)' : conn.status === 'nokey' ? 'var(--accent)' : 'var(--red)' }}>
                    {conn.status === 'ok' ? '✓ connected · ' + conn.models.length + ' models' : conn.status === 'nokey' ? '· key required' : conn.status === 'checking' ? '· connecting…' : conn.error ? '· ' + conn.error : ''}
                  </span>
                </div>
                <div style={{ fontSize: 11, color: 'var(--faint)' }}>Model lists are fetched live from the provider — nothing hardcoded. You can also type any model name directly in the Studio.</div>
              </div>
            )}
          </div>
          <div className="connbox">
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap', alignItems: 'baseline' }}>
              <b style={{ color: 'var(--text)' }}>{provider === 'ollama' ? 'Ollama endpoint' : PROVIDERS[provider].label + ' · models fetched live'}</b>
              <span>
                {conn.status === 'checking' && <span style={{ color: 'var(--dim)' }}>checking…</span>}
                {conn.status === 'ok' && (
                  <span style={{ color: 'var(--green)' }}>
                    ✓ connected · {conn.base === location.origin + '/ollama' ? 'local proxy (Vite)' : conn.base}
                  </span>
                )}
                {conn.status === 'bad' && <span style={{ color: 'var(--red)' }}>✗ {conn.error || 'not reachable'}</span>}
                {conn.status === 'nokey' && <span style={{ color: 'var(--accent)' }}>⚠ API key required</span>}
              </span>
            </div>
            {provider === 'ollama' && (<>
            <div style={{ margin: '4px 0 8px', fontSize: 11.5, color: 'var(--faint)' }}>
              Auto-detection order: saved/custom endpoint → same-origin <code>/ollama/*</code> (Vite dev proxy →{' '}
              <code>127.0.0.1:11434</code>, no CORS needed) → direct <code>http://localhost:11434</code> →{' '}
              <code>http://127.0.0.1:11434</code>. Whatever Ollama reports via <code>/api/tags</code> is listed — no
              model names are hardcoded.
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                type="text"
                value={customBase}
                onChange={(e) => setCustomBase(e.target.value)}
                placeholder="http://localhost:11434 or a LAN box like http://192.168.1.5:11434"
              />
              <button className="btn tiny" onClick={useBase}>Use &amp; re-check</button>
            </div>
            </>)}

            <div style={{ marginTop: 13, borderTop: '1px dashed var(--border)', paddingTop: 10 }}>
              <b style={{ color: 'var(--text)' }}>Detected models</b>{' '}
              <span style={{ fontSize: 11, color: 'var(--faint)' }}>
                {conn.models.length ? `· ${conn.models.length} found on ${conn.base}` : ''}
              </span>
              <div style={{ marginTop: 8, display: 'grid', gap: 6 }}>
                {conn.models.length === 0 && (
                  <div style={{ fontSize: 12, color: 'var(--faint)' }}>
                    {provider === 'local'
                      ? <>Nothing detected yet. Start your server (e.g. <code>llama-server -m your-model-q8_0.gguf</code>), then hit ↻ Re-check.</>
                      : <>Nothing detected yet. Start Ollama (<code>ollama serve</code>), pull any model (<code>ollama pull &lt;name&gt;</code>), then hit ↻ Re-check.</>}
                  </div>
                )}
                {[...conn.models]
                  .sort((a, b) => a.name.localeCompare(b.name))
                  .map((m) => {
                    const d = m.details || {}
                    const meta = [
                      d.family,
                      d.parameter_size ? d.parameter_size.replace(/\.0B/, 'B') : '',
                      d.quantization_level,
                      m.size ? fmtBytes(m.size) : '',
                      m.modified_at ? fmtAgo(m.modified_at) : '',
                    ].filter(Boolean).join(' · ')
                    const inUse = m.name === conn.model
                    return (
                      <div key={m.name} style={{
                        display: 'flex', gap: 8, alignItems: 'center', background: '#0a0e15',
                        border: '1px solid var(--border)', borderRadius: 8, padding: '6px 10px',
                      }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--text)', wordBreak: 'break-all' }}>
                            {m.name}
                          </div>
                          {meta && <div style={{ fontSize: 10.5, color: 'var(--faint)' }}>{meta}</div>}
                        </div>
                        <button className={'btn tiny' + (inUse ? ' primary' : '')}
                          onClick={() => { setModel(m.name); toast('Using ' + m.name) }}>
                          {inUse ? '✓ in use' : 'Use'}
                        </button>
                      </div>
                    )
                  })}
              </div>
              {provider === 'ollama' && (
              <div style={{ marginTop: 8, fontSize: 11.5, color: 'var(--faint)' }}>
                No models? Install Ollama from{' '}
                <a href="https://ollama.com" target="_blank" rel="noopener">ollama.com</a>, then add any chat model
                with <code>ollama pull &lt;model-name&gt;</code> — bigger models (7B and up) follow the H3 format more
                faithfully. Hit ↻ Re-check afterwards.
              </div>
              )}
            </div>

            {provider === 'ollama' && (
            <div style={{ marginTop: 13, borderTop: '1px dashed var(--border)', paddingTop: 10 }}>
              <b style={{ color: 'var(--text)' }}>Browser can't reach Ollama?</b>
              <div style={{ marginTop: 6 }}>
                With <code>npm run dev</code> the Vite proxy handles everything — nothing to configure. Only if you
                serve the built/static app from another origin, allow the browser to talk to Ollama once:
              </div>
              <pre>{`# Windows (PowerShell, before starting Ollama)
$env:OLLAMA_ORIGINS="*"; ollama serve

# macOS / Linux
OLLAMA_ORIGINS=* ollama serve`}</pre>
            </div>
            )}

            </div>
          </>)}

          {NOW === 'prompts' && (<>
          <div className="connbox">
            <div>
              <b style={{ color: 'var(--text)' }}>System prompt routing</b>{' '}
              <span style={{ color: 'var(--dim)' }}>{statusTxt}</span>
              <div style={{ marginTop: 8 }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', fontSize: 12 }}>
                  <b style={{ minWidth: 96, color: 'var(--text)' }}>🌐 Universal</b>
                  <select value={(sysRoute || {}).universal || ''} onChange={(e) => setSysRoute((r) => ({ ...(r || {}), universal: e.target.value }))}
                    style={selStyle}>
                    <option value="">Auto — per target &amp; 18+ (the four files below)</option>
                    {sysCustom && sysCustom.text ? <option value="custom">📂 {sysCustom.name} (uploaded)</option> : null}
                    {promptFiles.map((p) => <option key={p} value={'prompts/' + p}>{p}</option>)}
                  </select>
                  <span style={{ color: 'var(--faint)' }}>one file for every generation — H3 + LTX, SFW + 18+</span>
                </div>
                {SLOTS.map(([id, label]) => {
                  const v = (sysRoute || {})[id] || ''
                  const uni = (sysRoute || {}).universal
                  const f = sysFiles && sysFiles[v]
                  const bad = v && (!f || !f.text)
                  return (
                    <div key={id} style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', fontSize: 12, marginTop: 5, opacity: uni ? 0.55 : 1 }}>
                      <b style={{ minWidth: 96, color: 'var(--text)' }}>{label}</b>
                      <select value={v} onChange={(e) => setSysRoute((r) => ({ ...(r || {}), [id]: e.target.value }))} disabled={!!uni} style={selStyle}>
                        <option value="">Auto — {id === 'h3' ? 'system-prompt.md' : id === 'ltx' ? 'ltx-system-prompt.md' : id === 'h3m' ? 'system-prompt-mature.md' : 'ltx-system-prompt-mature.md'}</option>
                        {sysCustom && sysCustom.text ? <option value="custom">📂 {sysCustom.name} (uploaded)</option> : null}
                        {promptFiles.map((p) => <option key={p} value={'prompts/' + p}>{p}</option>)}
                      </select>
                      {bad ? <span style={{ color: '#e0a34a' }}>⚠ missing {v}</span> : null}
                    </div>
                  )
                })}
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                <label className="btn tiny" style={{ cursor: 'pointer' }}>
                  📂 Upload .md → universal
                  <input type="file" accept=".md,.txt" style={{ display: 'none' }} onChange={onFile} />
                </label>
                {(sysRoute || {}).universal || Object.keys(sysRoute || {}).some((k) => sysRoute[k]) ?
                  <button className="btn tiny ghost" onClick={() => { setSysRoute({}); toast('Routing reset — Auto (per target & 18+), attachments cleared') }}>↺ All Auto</button> : null}
                {sysCustom && sysCustom.text ?
                  <button className="btn tiny ghost" onClick={() => { setSysCustom(null); setSysRoute((r) => { const n = { ...(r || {}) }; if (n.universal === 'custom') n.universal = ''; for (const [k] of SLOTS) if (n[k] === 'custom') n[k] = ''; return n }); toast('Uploaded prompt removed') }}>✕ Remove upload</button> : null}
                <button className="btn tiny ghost" onClick={reload}>↻ Reload from file</button>
              </div>
              <div style={{ marginTop: 6 }}>
                Edit <code>public/prompts/system-prompt.md</code> to re-tune how the LLM writes H3 prompts —{' '}
                <code>public/prompts/system-prompt-mature.md</code> for 18+ work. No code changes needed.{' '}
                <span title="A prompt can depend on other files (@include on its own line). Steps are in 📖 Guide → Templates & system prompts." style={{ cursor: 'help', opacity: 0.7 }}>ⓘ dependencies</span>
              </div>
              {depPanel}
              <div style={{ marginTop: 6 }}>
                🧠 <b>{(packs || []).length}</b> domain craft pack{(packs || []).length === 1 ? '' : 's'} loaded from{' '}
                <code>public/prompts/packs/</code> — {(packs || []).map((p) => p.id).join(', ') || 'none found'}.
                Fashion craft now loads only for fashion clips; the pack picker sits under Category in the Scene section.
              </div>
            </div>
          </div>
          </>)}
        </div>
      </div>
    </div>
  )
}
