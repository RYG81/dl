import { useEffect, useRef, useState } from 'react'
import { Chips } from './ui.jsx'
import MatureModal from './MatureModal.jsx'
import TemplatePickerModal from './TemplatePickerModal.jsx'
import { streamChat, extractPartial, extractLabeled, finalizeOutput, modelLabel } from '../lib/ollama.js'
import { buildUserMessage } from '../lib/prompts.js'
import { genVariantOffline, genVariantLtxOffline, SURPRISE } from '../lib/offline.js'
import { IC_PROTOCOLS, icBuild } from '../lib/icprotocols.js'
import { logger } from '../lib/logger.js'
import { endStateOf } from '../lib/format.js'
import { unloadModel, detectVision, readImage, readImageGroup, chunkFrames, readImageCompat, readImageGroupCompat } from '../lib/ollama.js'
import { providerConfig, streamOpenAIChat } from '../lib/providers.js'
import { buildUserMessageLtx } from '../lib/prompts.js'
import { EXAMPLES, pickExemplar } from '../lib/examples.js'
import { scoreH3, scoreLtx } from '../lib/scoring.js'
import { tokenName, tokenHint, fillText, uniqueTokens, normalizePhValues } from '../lib/tokens.js'
import { readLS, writeLS } from '../lib/persist.js'
import { resolvePacks, packBlock } from '../lib/packs.js'
import { chooseBase, composeSystem, promptReport, promptSetLabel, slotOf } from '../lib/syscompose.js'
import { matureRouting, looksMature } from '../lib/maturegate.js'
import { switchTemplate, describeSettings } from '../lib/templates.js'
import { engineSummary, ENGINE_DEFAULTS } from '../lib/enginesettings.js'
import { liveClock as liveClockFor } from '../lib/prompts.js'
import { fmtTC } from '../lib/duration.js'
import { COLOUR_FAMILIES, FAMILY_COUNT, rotationBrief } from '../lib/colourbank.js'
/* Also namespace-linked (v2.15): an older local filler.js must not be able to kill the app —
   it degrades ✨ Suggest to a small built-in wheel and names the file to take in the console. */
import * as fillerMod from '../lib/filler.js'
import { fillerBridge } from '../lib/colourlink.js'
const FILLER = fillerBridge(fillerMod)
const COLOUR_STEP = FILLER.step
const colourTokensOf = FILLER.colourTokensOf

const CATEGORIES = [
  'Cinematic Film Scene', 'Multi-Shot Sequence', 'Dialogue Scene', 'Commercial / Brand Film',
  'Short Drama (vertical)', 'Social Media Content', 'Music Video', 'Documentary',
  'Product Showcase', 'Nature / Landscape', 'Sci-Fi / Fantasy', 'Animation', 'Fashion / Lifestyle',
  '— reference tasks —',
  'Video Editing (reference)', 'Video Continuation (reference)', 'Motion Transfer (reference)',
  'Keyframe Completion (reference)', 'Audio Reuse (reference)', 'Auto',
]
const STYLES = ['Auto', 'Cinematic', 'Live-Action', '2D Animated', '3D CG', 'Claymation', 'Watercolor',
  'Vintage Film', 'Documentary / Handheld', 'Film Noir', 'Anime', 'High Fashion', 'Neon / Cyberpunk',
  'Slow Motion', 'Timelapse']
const CAMERAS = ['Auto', 'Static shot', 'Push in', 'Pull out', 'Zoom in', 'Zoom out', 'Pan left', 'Pan right',
  'Truck left', 'Truck right', 'Tilt up', 'Tilt down', 'Pedestal up', 'Pedestal down', 'Arc shot',
  'Tracking shot', 'Shake slightly', 'Shake strongly', 'POV', 'Roll clockwise', 'Roll counterclockwise']
const RATIOS = ['16:9', '9:16', '1:1', '4:3', '3:4', '21:9']
const DLANGS = ['English', 'Chinese', 'Spanish', 'French', 'German', 'Italian', 'Japanese', 'Korean',
  'Portuguese', 'Russian', 'Arabic']
const PALETTES = ['Auto', 'Dawn Bakery', 'Teal and Orange', 'Neon Night', 'High Fashion Mono',
  'Desert Highway', 'Cold Noir', 'Vintage Film', 'Rain Window']
const PALETTE_LABELS = { 'Teal and Orange': 'Teal & Orange', 'High Fashion Mono': 'Mono' }
const MUSIC = { auto: 'Auto', none: 'None (N/A)', subtle: 'Subtle underscore', full: 'Full score', beat: 'Beat-driven' }

function deriveTitle(idea) {
  const t = ((idea || '').split(/[,.\n]/)[0] || '').trim().split(/\s+/).slice(0, 5).join(' ')
  return t ? t.charAt(0).toUpperCase() + t.slice(1) : 'Generated shot'
}

const PRESET_GROUPS = [
  ['🔁 Loops', (t) => /loop/i.test(t.t)],
  ['🖼️ Reference workflows', (t) => /recreate|first|identity|relight/i.test(t.t)],
  ['📈 Marketing', (t) => /cross-post|ugc|seasonal/i.test(t.t)],
  ['🎬 Format specialists', () => true],
]

const PLANNER_FALLBACK = 'You are a short-film story planner. Return ONLY JSON {"bible":"...","scenes":[{"idea":"..."}]} - bible locks identity/wardrobe/location/light/grade across clips; scenes form hook-develop-turn-resolve, one directable action sentence each, no repeated beats.'

function offlinePlan(idea, scenesN, dur) {
  const clean = idea.replace(/[.\s]+$/, '')
  const n = Math.max(2, scenesN)
  const arcs = [
    'HOOK - establish the world and open on: ' + clean + ' - the first gesture lands inside one second.',
    'DEVELOP - the action deepens: a secondary beat and a closer angle reveal detail and reaction.',
    'TURN - the shift: an obstacle, a reveal or a change of energy redirects the moment.',
    'CLIMAX - the decisive beat: fullest motion, tightest framing, strongest light.',
    'RESOLVE - the landing: a closing image with forward momentum, held long enough to bridge to the next clip.',
  ]
  const scenes = []
  for (let i = 0; i < n; i++) {
    const a = arcs[Math.min(arcs.length - 1, Math.round(i * (arcs.length - 1) / Math.max(1, n - 1)))]
    scenes.push({ idea: a, end: '' })
  }
  const beats = Math.max(2, Math.round(dur / 2.5))
  const bible = 'Locked across every clip: ' + clean + ' - identical subject identity and wardrobe, same location logic and time of day, one coherent lighting design and color grade, consistent lens language; ~' + beats + ' beats per ' + dur + 's clip.'
  return { bible, scenes }
}
const WORKFLOWS = { t2v: '🎬 T2V', i2v: '🖼️ I2V', fflf: '🎞️ FFLF', l2v: '🎯 L2V', multiref: '🔗 Refs', a2v: '🔊 A2V' }
const WF_HINT = {
  t2v: 'Pure text prompt — the model invents world, subject and framing from scratch.',
  i2v: 'Image-to-video: your image IS frame 1. The prompt stops describing the scene and spends everything on motion from that exact frame. Attach the image under 🖼️ Reference assets (job: “first frame”) so it can be vision-read, or describe it below.',
  fflf: 'First-frame → last-frame: two images define the ends; the prompt writes only the journey between them. Attach both under 🖼️ Reference assets (jobs: “first frame” / “last frame”).',
  multiref: 'Multi-reference video (H3 Ref2VA / LTX multi-frame): every reference gets an explicit job cited by number — add them under 🖼️ Reference assets.',
  a2v: 'Audio-driven video (LTX-2.5 audio-to-video): attach an audio track under 🖼️ Reference assets (job: “driver audio”) — visuals are composed to land on its rhythm, speech and accents.',
  l2v: 'Last-frame → video (H3 L2VA): your image IS the final frame — the prompt infers a plausible earlier state and converges on it, ending exactly on that frame. The official alignment line is emitted first.',
}

/* The builder form is persisted (cps_form_v1) — switching tabs unmounts this panel,
   and losing a half-written brief to a tab click is never acceptable. Transient runs
   (busy, streaming text, modal state) stay in memory only. */
const FORM_KEY = 'cps_form_v1'

/* Reference thumbnails are base64 image bytes — keep them in memory only (the panel
   promises files never leave this machine, and they would blow the storage quota). */
const slimForm = (form) => ({
  ...form,
  refs: (form.refs || []).map(({ type, job, name }) => ({ type, job: job || '', name: name || '', thumb: '' })),
})

const F0 = {
  idea: '', category: 'Cinematic Film Scene', style: 'Auto', structure: 'single', camera: 'Auto', loop: false,
  amp: 'medium', speed: 'normal', ratio: '16:9', resolution: '768P', duration: 6, music: 'auto',
  ambience: '', dialogue: '', dlang: 'English', foley: '', audioNotes: '', palette: 'Auto', negation: '', extra: '',
  workflow: 't2v', dialogueOn: true, frameStart: '', frameEnd: '', ph: {}, loras: [], ic: { proto: '', vals: {} },
  refs: [], keyframes: false, sendRefs: true, template: '', engine: 'auto', variants: '1', temperature: 0.8, enhance: false, fewshot: true, detail: true, pack: 'auto',
  target: (typeof localStorage !== 'undefined' && localStorage.getItem('cps_target')) || 'h3',
  mature: (typeof localStorage !== 'undefined' && localStorage.getItem('cps_nsfw') === 'on'),
}

const nsfwBlocked = () => { try { return localStorage.getItem('cps_nsfw_blocked') === '1' } catch (e) { return false } }
/* The 18+ switch is the consent AND the routing decision — see lib/maturegate.js.
   The keyword list only produces advice, never a silent downgrade to the SFW prompt. */

/* Compact help affordance: hover = tip, click = jump to the matching Guide section */
function Q({ sec, tip }) {
  return <button type="button" className="qbtn" title={tip} onClick={() => window.dispatchEvent(new CustomEvent('cps-open-guide', { detail: sec }))}>?</button>
}

export default function StudioForm({ conn, setModel, sysPrompt, ltxSysPrompt, sysMature, ltxMature, sysRoute, sysLookup, pushCard, updateCard, pushHistory, setStatus, toast, presets, templates, userReport, fileNotes, onRecheck, loras, pendingLoad, onPendingConsumed, critOn, setCritOn, packs, engSet, matureOn, onOpenSettings }) {
  const [f, setF] = useState(() => {
    const s = readLS(FORM_KEY, null)
    const v = s && typeof s === 'object' ? { ...F0, ...s } : F0
    /* Consent never restores itself: the 18+ box only comes back ticked when the
       18+ switch is still on — the kill switch can always revoke it. */
    try { if (v.mature && localStorage.getItem('cps_nsfw') !== 'on') v.mature = false } catch (e) {}
    /* placeholders are keyed by NAME now — migrate anything saved under a full token text */
    v.ph = normalizePhValues(v.ph)
    return v
  })
  useEffect(() => { writeLS(FORM_KEY, slimForm(f)) }, [f])
  /* Vision routing: Ollama stays native; any OpenAI-compatible server
     (llama-server + --mmproj, vLLM, LM Studio — e.g. the Qwen3-VL-32B GGUF
     used for H3 captioning) reads frames via the chat-completions transport. */
  const visionRead = (dataUrl, note) => (conn.provider && conn.provider !== 'ollama')
    ? readImageCompat(providerConfig(conn.provider), conn.model, dataUrl, note)
    : readImage(conn.base, conn.model, dataUrl, note)
  const visionGroup = (sheet, labels, notes) => (conn.provider && conn.provider !== 'ollama')
    ? readImageGroupCompat(providerConfig(conn.provider), conn.model, sheet, labels, notes)
    : readImageGroup(conn.base, conn.model, sheet, labels, notes)
  const [busy, setBusy] = useState(false)
  const [variationPools, setVariationPools] = useState('')
  const [presetOpen, setPresetOpen] = useState(false)
  const [chain, setChain] = useState({ bible: '', scenes: [], active: 0 })
  /* The variation pools are an external md file (like the packs) — loaded on first need. */
  useEffect(() => {
    const tp = (templates || []).find((x) => x.t === f.template)
    if (!tp || !(tp.vary || []).length || variationPools) return
    let dead = false
    fetch('prompts/fashion-variation.md', { cache: 'no-store' })
      .then((r) => (r.ok ? r.text() : ''))
      .then((tx) => { if (!dead && tx) setVariationPools(tx.trim()) })
      .catch(() => {})
    return () => { dead = true }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [f.template])
  /* A chain built from several templates (🔗 on the Templates page, or a chain recipe).
     The person is the constant; the room, the light and the look move per scene. */
  const offlineChainBible = (scenes, rule) => {
    const names = scenes.map((s) => s.tpl).filter(Boolean)
    return 'SAME WOMAN IN EVERY SCENE — identical face, hair (length, colour, texture), skin tone and build; she is the only person on camera, no other face enters the frame. ' +
      'CONSTANT ACROSS THE CHAIN: colour grade, lens language, frame rate and her identity. ' +
      'CHANGES PER SCENE: her room, its light and her complete look — each scene gets its own location with its own named key light and one legible landmark, and its own garment (cut, fabric, colour, footwear). ' +
      'Never re-describe her face from scratch: refer to the locked identity and spend the words on the new room and the new garment. ' +
      'Scene templates: ' + names.map((n, i) => (i + 1) + '. ' + n).join(' · ') +
      (rule ? '. Chain rule from the template: ' + rule : '.')
  }
  /* The planner writes the bible (and a fresh action per scene) so consistency is handled
     for the user — offline the rule-based bible above is used instead. */
  const planTemplateChain = async (payload) => {
    const scenes = (payload && payload.scenes || []).filter((x) => x && x.tpl)
    if (!scenes.length) return
    const rule = (payload && payload.rule) || ''
    setChain({ bible: '', scenes: scenes.map((s) => ({ tpl: s.tpl, idea: s.idea || '', end: '' })), active: 0 })
    const tpl0 = (templates || []).find((x) => x.t === scenes[0].tpl) || null
    const dur0 = (tpl0 && tpl0.settings && tpl0.settings.duration) || f.duration || 8
    setF((p) => (tpl0
      ? { ...p, ...switchTemplate({ ...p, idea: scenes[0].idea || p.idea }, tpl0).patch }
      : { ...p, template: scenes[0].tpl, idea: scenes[0].idea || p.idea }))
    setPlanTotal(Math.max(10, scenes.length * dur0))
    let bible = offlineChainBible(scenes, rule)
    let ideas = scenes.map((s) => s.idea || '')
    if (useOllama) {
      setBusyPlan(true)
      try {
        let sys = PLANNER_FALLBACK
        try { const r = await fetch('prompts/chain-planner.md'); if (r.ok) sys = (await r.text()) || sys } catch (e) {}
        const list = scenes.map((s, i) => {
          const tp = (templates || []).find((x) => x.t === s.tpl) || {}
          return (i + 1) + '. ' + s.tpl + ' — ' + (tp.d || tp.tip || '').replace(/\s+/g, ' ').slice(0, 180)
        }).join('\n')
        const messages = [
          { role: 'system', content: sys },
          { role: 'user', content: 'TEMPLATE CHAIN: ' + scenes.length + ' scenes, one template per scene.\nCLIP SECONDS: ' + dur0 + '\nCHAIN RULE: ' + (rule || 'same model, a different look and location in every scene') + '\nTEMPLATES (one per scene, in order):\n' + list + '\nWrite the consistency bible so the chain reads as one shoot with one woman, and write ONE directable action line per scene that suits that scene\u2019s template. Return only the JSON object.' },
        ]
        const streamer = conn.provider && conn.provider !== 'ollama'
          ? streamOpenAIChat(providerConfig(conn.provider), conn.model, messages, 0.7, { json: true })
          : streamChat(conn.base, conn.model, messages, 0.7, { json: true })
        let acc = ''
        for await (const p of streamer) acc += p
        const j = JSON.parse(acc.slice(acc.indexOf('{'), acc.lastIndexOf('}') + 1))
        if (j && j.bible) bible = String(j.bible).trim()
        if (j && Array.isArray(j.scenes)) ideas = scenes.map((s, i) => ((j.scenes[i] && j.scenes[i].idea) || s.idea || '').trim())
      } catch (e) {}
      setBusyPlan(false)
    }
    setChain({
      bible,
      scenes: scenes.map((s, i) => ({ tpl: s.tpl, idea: ideas[i] || s.idea || '', end: '' })),
      active: 0,
    })
    toast('🔗 Chain ready — ' + scenes.length + ' scenes, one template each, and the consistency bible is written (same woman, new room and new look per scene). Hit ⚡ Generate all ' + scenes.length + ' scenes.')
  }
  const addScene = () => setChain((c) => ({ ...c, scenes: [...c.scenes, { idea: '', end: '' }] }))
  const rmScene = (i) => setChain((c) => {
    const scenes = c.scenes.filter((_, j) => j !== i)
    return { ...c, scenes, active: c.active > i ? c.active - 1 : Math.min(c.active, scenes.length) }
  })
  const setScene = (i, patch) => setChain((c) => ({ ...c, scenes: c.scenes.map((s, j) => (j === i ? { ...s, ...patch } : s)) }))
  /* Re-order scenes: a chain is a sequence, so the sequence must be editable after the fact.
     `active` follows the scene it was pointing at, not the slot number. */
  const moveScene = (i, dir) => setChain((c) => {
    const j = i + dir
    if (j < 0 || j >= c.scenes.length) return c
    const scenes = c.scenes.slice()
    const [moved] = scenes.splice(i, 1)
    scenes.splice(j, 0, moved)
    let active = c.active
    if (c.active === i + 1) active = j + 1
    else if (c.active === j + 1) active = i + 1
    return { ...c, scenes, active }
  })
  const directScene = (i) => {
    const sc = chain.scenes[i]
    let ideaTxt = (sc.idea || '').trim()
    if (!ideaTxt) {
      /* optional inputs: empty scenes get an auto beat from the arc */
      const plan = offlinePlan(f.idea.trim() || 'this story', Math.max(chain.scenes.length, i + 1), f.duration).scenes
      ideaTxt = (plan[Math.min(i, plan.length - 1)] || plan[0]).idea
      setScene(i, { idea: ideaTxt })
    }
    const scTpl = sc.tpl ? ((templates || []).find((x) => x.t === sc.tpl) || null) : null
    setF((pf) => (scTpl
      ? { ...pf, ...switchTemplate({ ...pf, idea: ideaTxt }, scTpl).patch }
      : { ...pf, idea: ideaTxt }))
    const pinNote = scTpl && scTpl.settings && scTpl.settings.duration
      ? ' · 📐 ' + sc.tpl + ' pins ' + scTpl.settings.duration + 's per clip (' + chain.scenes.length + ' clips ≈ ' + (chain.scenes.length * scTpl.settings.duration) + 's total)'
      : ''
    setChain((c) => ({ ...c, active: i + 1 }))
    if (i >= 1) {
      setF((pf) => ({ ...pf, workflow: 'i2v' }))
      toast('🔗 Scene ' + (i + 1) + '/' + chain.scenes.length + ' armed as IMAGE-TO-VIDEO — first RENDER scene ' + i + ', then attach its LAST FRAME as an Image ref (job “first frame”); the prompt continues from it exactly' + (chain.bible.trim() ? '' : ' · add the consistency bible so identity survives')) + pinNote
    } else {
      toast('🔗 Opening scene armed' + (chain.bible.trim() ? '' : ' — add the consistency bible so identity survives every clip')) + pinNote
    }
  }
  const planScenes = () => {
    const n = Math.max(1, Math.ceil(Math.max(5, planTotal) / Math.max(5, f.duration)))
    setChain((c) => {
      const add = Math.max(0, n - c.scenes.length)
      return { ...c, scenes: [...c.scenes, ...Array.from({ length: add }, () => ({ idea: '', end: '' }))] }
    })
    toast('⏱ Planned ' + n + ' clips × ' + f.duration + 's ≈ ' + n * f.duration + 's of final video')
  }
  /* The chain is self-driving: one line of idea → the planner writes the bible and
     every scene beat (LLM when connected, narrative-arc engine offline). All chain
     inputs stay optional overrides. */
  const autoPlan = async () => {
    const idea = f.idea.trim()
    if (!idea) { toast('✍️ Write one line of idea first — Auto-plan does the rest'); return }
    const n = Math.max(2, Math.ceil(Math.max(10, planTotal) / Math.max(5, f.duration)))
    setBusyPlan(true)
    try {
      let bible = '', scenes = []
      if (useOllama) {
        let sys = PLANNER_FALLBACK
        try { const r = await fetch('prompts/chain-planner.md'); if (r.ok) sys = (await r.text()) || sys } catch (e) {}
        const messages = [
          { role: 'system', content: sys },
          { role: 'user', content: 'IDEA: ' + idea + '\nSCENES: ' + n + '\nCLIP SECONDS: ' + f.duration + '\nReturn only the JSON object.' },
        ]
        const streamer = conn.provider && conn.provider !== 'ollama'
          ? streamOpenAIChat(providerConfig(conn.provider), conn.model, messages, 0.7, { json: true })
          : streamChat(conn.base, conn.model, messages, 0.7, { json: true })
        let acc = ''
        for await (const p of streamer) acc += p
        const obj = JSON.parse(acc.slice(acc.indexOf('{'), acc.lastIndexOf('}') + 1))
        bible = String(obj.bible || '')
        scenes = (Array.isArray(obj.scenes) ? obj.scenes : []).slice(0, n).map((x) => ({ idea: String((x && x.idea) || ''), end: '' }))
      }
      if (!scenes.length) { const r = offlinePlan(idea, n, f.duration); bible = bible || r.bible; scenes = r.scenes }
      setChain((c) => ({ bible: bible || c.bible, scenes, active: 0 }))
      toast('✨ Auto-planned ' + scenes.length + ' scenes × ' + f.duration + 's ≈ ' + scenes.length * f.duration + 's + consistency bible — Direct scene 1 when ready')
    } catch (e) {
      const r = offlinePlan(idea, n, f.duration)
      setChain((c) => ({ bible: r.bible, scenes: r.scenes, active: 0 }))
      toast('⚠ LLM planner unavailable (' + String((e && e.message) || e).slice(0, 80) + ') — offline arc planner used')
    }
    setBusyPlan(false)
  }
  /* Ask the LLM to propose concrete values for unfilled placeholders. */
  const PH_FALLBACK = 'Answer ONLY a JSON object mapping each {TOKEN} to one concrete, specific, filmable value (2-12 words). One coherent world. Keys without braces. JSON only. ' +
    'COLOUR: never answer a colour with white, ivory, cream, ecru, pearl, chalk or bone unless the IDEA asks for it by name — that is a silent default, not a decision. Take the family named in the COLOUR ROTATION line and walk forward through the wheel (' +
    COLOUR_FAMILIES.map((f) => f.name).join(' · ') + '); when one answer fills several colour-bearing tokens, each gets a DIFFERENT family, and a garment always gets a colour family plus its finish and hardware.'
  /* Offline fallback: concrete values per token family when no model answers. */
  /* ✨ The offline filler + its rotation live in src/lib/filler.js — one implementation,
     shared with the LLM path (which receives rotationBrief) and covered by the self-test. */
  const filler = FILLER.create()
  /* Robustly pull token values out of whatever JSON shape the model returned. */
  function pullVals(raw, tokens) {
    let obj = null
    try { obj = JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1)) } catch (e) { obj = null }
    if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
      const flat = tokens.some((t) => obj[t] != null || obj[t.toLowerCase()] != null || obj['{' + t + '}'] != null)
      if (!flat) {
        const nested = Object.values(obj).filter((v) => v && typeof v === 'object' && !Array.isArray(v))
        if (nested.length) obj = nested[0] /* model wrapped the map under "values"/"result" */
      }
    }
    const lower = {}
    if (obj && typeof obj === 'object') Object.keys(obj).forEach((k) => { lower[String(k).toLowerCase().replace(/[{}]/g, '').trim()] = obj[k] })
    const out = {}
    tokens.forEach((t) => {
      const v = lower[String(t).toLowerCase().replace(/[{}]/g, '').trim()]
      out[t] = v != null ? String(Array.isArray(v) ? v.join(' ') : v).trim() : ''
    })
    return out
  }
  /* 👗 Outfit expander — public/prompts/fashion-outfit-expander.md turns a garment brief into ONE
     expert line, which is exactly the value a fashion template's OUTFIT DESIGN field wants. */
  async function expandOutfit(tokenNames) {
    const target = (tokenNames || []).find((n) => /OUTFIT|GARMENT|WARDROBE/i.test(n)) || (tokenNames || [])[0]
    if (!target) return
    const hasLLM = (conn.provider && conn.provider !== 'ollama') ? true : !!(conn.status === 'ok' && conn.model)
    if (!hasLLM) { toast('👗 Outfit expander needs a connected model (⚙️ Settings)'); return }
    const tpl = (templates || []).find((x) => x.t === f.template)
    const brief = [
      'BRIEF: ' + (f.idea || '').trim(),
      tpl ? 'TEMPLATE CONTEXT: ' + tpl.t + ' — ' + (tpl.d || '') : '',
      tokenHint(target) ? 'FIELD TO FILL: {' + tokenName(target) + '} = ' + tokenHint(target) : 'FIELD TO FILL: {' + tokenName(target) + '}',
      (f.palette || '').trim() ? 'PALETTE ALREADY CHOSEN (keep it): ' + String(f.palette).trim() : '',
      (f.extra || '').trim() ? 'MUST INCLUDE (verbatim): ' + String(f.extra).trim().slice(0, 600) : '',
      'Return the single line only.',
    ].filter(Boolean).join('\n')
    setPhModal((m) => (m ? { ...m, busy: true, err: '' } : m))
    try {
      let sys = 'You expand an outfit brief into exactly one expert line. Output the line only.'
      try { const r = await fetch('prompts/fashion-outfit-expander.md', { cache: 'no-store' }); if (r.ok) sys = ((await r.text()) || '').trim() || sys } catch (e) {}
      const messages = [{ role: 'system', content: sys }, { role: 'user', content: brief }]
      logger.info('outfit', 'expanding {' + tokenName(target) + '} with ' + (conn.provider && conn.provider !== 'ollama' ? conn.provider : 'ollama') + ' ' + conn.model)
      const streamer = conn.provider && conn.provider !== 'ollama'
        ? streamOpenAIChat(providerConfig(conn.provider), conn.model, messages, 0.75)
        : streamChat(conn.base, conn.model, messages, 0.75)
      let acc = ''
      for await (const pc of streamer) acc += pc
      /* one line, stripped of any markdown the model wrapped it in */
      let line = acc.split('\n').map((x) => x.trim()).filter(Boolean)
        .map((x) => x.replace(/^[*`>\s]+/, '').replace(/[*`\s]+$/, ''))
        .sort((a, b) => b.length - a.length)[0] || ''
      line = line.replace(/^["'“”]|["'“”]$/g, '').replace(/\s{2,}/g, ' ').trim()
      if (!line) throw new Error('empty reply')
      logger.info('outfit', 'expander returned ' + line.length + ' chars: ' + line.slice(0, 120))
      setPhModal((m) => (m ? { ...m, values: { ...m.values, [target]: line }, busy: false } : m))
      toast('👗 Outfit line ready in {' + tokenName(target) + '} — edit it or hit Fill & Generate')
    } catch (e) {
      logger.error('llm', 'outfit expander failed: ' + String((e && e.message) || e).slice(0, 160))
      setPhModal((m) => (m ? { ...m, busy: false, err: 'Outfit expander failed: ' + String((e && e.message) || e).slice(0, 120) } : m))
    }
  }

  async function suggestFill(tokens) {
    const hasLLM = (conn.provider && conn.provider !== 'ollama') ? true : !!(conn.status === 'ok' && conn.model)
    if (!hasLLM) {
      logger.info('suggest', 'no connected model — offline filler used for ' + tokens.length + ' token(s)')
      setPhModal((m) => (m ? { ...m, values: filler.fill(tokens, f.idea), busy: false, err: 'No model connected — offline filler proposed these (edit freely, or 🎲 let the model invent).' } : m))
      return
    }
    try {
      let sys = PH_FALLBACK
      try { const r = await fetch('prompts/placeholder-filler.md', { cache: 'no-store' }); if (r.ok) sys = (await r.text()).trim() || sys } catch (e) {}
      const tpl = (templates || []).find((t) => t.t === f.template)
      /* The rotation advances on every ask (a step coprime with the wheel's 12 families, so
         twelve presses visit all twelve) and the position is remembered between sessions. */
      filler.rotate(COLOUR_STEP)
      const colourTokens = colourTokensOf(tokens)
      const ctx = [
        'IDEA: ' + (f.idea || '').slice(0, 700),
        tpl ? 'TEMPLATE: ' + tpl.t + ' — ' + (tpl.d || '') : '',
        colourTokens.length ? rotationBrief(filler.rot, filler.lastFamily) + (colourTokens.length > 1 ? ' (' + colourTokens.length + ' colour-bearing tokens in this ask — that many different families.)' : '') : '',
        'TOKENS TO FILL: ' + tokens.map((t) => '{' + t + '}' + (tokenHint(t) ? ' (= ' + tokenHint(t) + ')' : '')).join(', '),
      ].filter(Boolean).join('\n')
      const messages = [{ role: 'system', content: sys }, { role: 'user', content: ctx + '\nReturn only the JSON object.' }]
      logger.info('suggest', 'asking ' + (conn.provider && conn.provider !== 'ollama' ? conn.provider : 'ollama') + ' ' + conn.model + ' for ' + tokens.length + ' value(s): ' + tokens.join(', '))
      const streamer = conn.provider && conn.provider !== 'ollama'
        ? streamOpenAIChat(providerConfig(conn.provider), conn.model, messages, 0.7, { json: true })
        : streamChat(conn.base, conn.model, messages, 0.7, { json: true })
      let acc = ''
      for await (const pc of streamer) acc += pc
      logger.info('suggest', 'raw reply ' + acc.length + ' chars: ' + acc.slice(0, 120).replace(/\n/g, ' '))
      const out = pullVals(acc, tokens)
      const got = Object.values(out).filter(Boolean).length
      if (got) {
        logger.info('suggest', 'parsed ' + got + '/' + tokens.length + ' values from model JSON')
        setPhModal((m) => (m ? { ...m, values: out, busy: false } : m))
      } else {
        logger.error('llm', 'suggest: model reply had no usable values — raw: ' + acc.slice(0, 200))
        setPhModal((m) => (m ? { ...m, values: filler.fill(tokens, f.idea), busy: false, err: 'Model reply had no usable values (raw: ' + acc.slice(0, 80).replace(/\n/g, ' ') + '…) — offline filler used, edit freely.' } : m))
      }
    } catch (e) {
      logger.error('llm', 'suggest failed: ' + String((e && e.message) || e).slice(0, 200))
      setPhModal((m) => (m ? { ...m, values: filler.fill(tokens, f.idea), busy: false, err: 'Suggestion failed: ' + String((e && e.message) || e).slice(0, 140) + ' — offline filler used instead.' } : m))
    }
  }
  /* Add-on 64-lite: convert the planned chain into ONE LTX-2.5 native multishot prompt.
     The per-scene chain flow above stays untouched — this is an additional output mode. */
  function offlineMultishot(scenes, bible) {
    const parts = []
    if (bible.trim()) parts.push(bible.trim() + '.')
    scenes.forEach((sc, i) => {
      const beat = (sc.idea || '').trim() || ('scene ' + (i + 1) + ' continues the arc')
      parts.push((i ? 'Cut to ' : '') + beat + (sc.end ? ', ending with ' + sc.end.trim() : ''))
    })
    return parts.join(' ')
  }
  async function toNativeMultishot() {
    const scenes = chain.scenes
    if (!scenes.length) { toast('No scenes yet — plan the chain first'); return }
    if (busy || chainBusy) return
    setChainBusy(true)
    const id = 'ms' + Math.random().toString(36).slice(2)
    const inpMs = { target: 'ltx', ratio: f.ratio, duration: Math.min(20, Math.max(8, scenes.length * 5)), workflow: 't2v', idea: 'native multishot — ' + chain.scenes.length + ' connected shots' }
    pushCard({ id, kind: 'variant', v: null, streaming: true, inp: inpMs })
    try {
      let sys = ''
      try { const r = await fetch('prompts/multishot-convert.md', { cache: 'no-store' }); if (r.ok) sys = (await r.text()).trim() } catch (e) {}
      if (!sys) sys = 'Convert the chain into ONE LTX-2.5 native multishot paragraph: single flowing present-tense paragraph, <=200 words, <=20s total, connected shots with cut language inside the paragraph, identity worded identically across shots. Return ONLY JSON {"title","prompt","negative_prompt","shots"}.'
      const scTxt = scenes.map((sc, i) => 'SCENE ' + (i + 1) + (sc.tpl ? ' (template: ' + sc.tpl + ')' : '') + ': ' + ((sc.idea || '').trim() || '(no beat given — invent one that continues the arc)') + (sc.end ? ' | END STATE: ' + sc.end : '')).join('\n')
      const user = 'CHAIN BIBLE:\n' + (chain.bible.trim() || '(none — invent a tight identity/world lock)') + '\n\n' + scTxt
      const messages = [{ role: 'system', content: sys }, { role: 'user', content: user }]
      let acc = ''
      const streamer = conn.provider && conn.provider !== 'ollama'
        ? streamOpenAIChat(providerConfig(conn.provider), conn.model, messages, 0.6, { json: true })
        : streamChat(conn.base, conn.model, messages, 0.6, { json: true })
      for await (const pc of streamer) { acc += pc; const pp = extractPartial(acc, 'prompt'); if (pp) updateCard(id, { streamText: pp }) }
      const v = finalizeOutput(acc, 'ltx')
      v.target = 'ltx'; v.multishot = true; v.engine = 'ollama'; v.model = conn.model
      v.promptSet = (matureRouting({ consent: !!f.mature, blocked: nsfwBlocked(), wants: looksMature(scTxt + ' ' + (chain.bible || '')) }).matureOn ? 'mature-ltx' : 'sfw-ltx') + ' (native multishot)'
      if (!v.title) v.title = deriveTitle(chain.scenes[0].idea || 'native multishot')
      if (!v.prompt) { v.prompt = offlineMultishot(scenes, chain.bible); v.engine = 'offline-fallback'; toast('⚠ LLM unavailable — offline multishot sketch used') }
      updateCard(id, { v, streaming: false })
      setStatus('🎞️ Native multishot prompt built from ' + scenes.length + ' scenes — one LTX-2.5 generation, continuity held across cuts')
    } catch (err) {
      const v = { title: deriveTitle('native multishot'), prompt: offlineMultishot(scenes, chain.bible), negative_prompt: 'drift, changing faces, extra limbs, watermark', target: 'ltx', multishot: true, engine: 'offline-fallback', promptSet: 'sfw-ltx (native multishot, offline)' }
      updateCard(id, { v, streaming: false })
      toast('⚠ ' + String((err && err.message) || err).slice(0, 100) + ' — offline multishot sketch used')
    }
    setChainBusy(false)
  }

  /* Add-on 63: Prompt Critic — deep LLM scoring of a generated card, with
     heuristic fallback. Invoked via 'cps-critique' event from OutputPanel. */
  async function critiqueCard(card) {
    if (!critOn) return
    if (!card || !card.v || card.critBusy) return
    updateCard(card.id, { critBusy: true })
    const isLtx = card.v.target === 'ltx' || (card.inp && card.inp.target === 'ltx')
    const ptxt = isLtx ? (card.v.prompt || '') : (card.v.integrated_multimodal_description || '')
    try {
      let sys = ''
      try { const r = await fetch('prompts/prompt-critic.md', { cache: 'no-store' }); if (r.ok) sys = (await r.text()).trim() } catch (e) {}
      if (!sys) sys = 'Score the video prompt. Return ONLY JSON {"score":0-100,"dims":{"clarity":0,"camera":0,"continuity":0,"audio":0,"pacing":0,"conformance":0},"issues":["..."],"fix":"<upgraded prompt or empty string>"}.'
      const dur = (card.inp && card.inp.duration) || f.duration
      const rat = (card.inp && card.inp.ratio) || f.ratio
      const messages = [
        { role: 'system', content: sys },
        { role: 'user', content: 'TARGET: ' + (isLtx ? 'ltx' : 'h3') + '\nDURATION: ' + dur + 's · RATIO: ' + rat + '\nPROMPT:\n' + ptxt },
      ]
      const streamer = conn.provider && conn.provider !== 'ollama'
        ? streamOpenAIChat(providerConfig(conn.provider), conn.model, messages, 0.2, { json: true })
        : streamChat(conn.base, conn.model, messages, 0.2, { json: true })
      let acc = ''
      for await (const pc of streamer) acc += pc
      let obj = null
      try { obj = JSON.parse(acc.slice(acc.indexOf('{'), acc.lastIndexOf('}') + 1)) } catch (e) {}
      if (!obj || typeof obj.score !== 'number') throw new Error('critic JSON unparseable')
      updateCard(card.id, { crit: { score: Math.max(0, Math.min(100, Math.round(obj.score))), dims: obj.dims || {}, issues: Array.isArray(obj.issues) ? obj.issues.slice(0, 4) : [], fix: String(obj.fix || ''), src: 'llm' }, critBusy: false })
    } catch (e) {
      /* heuristic fallback — the ENGINE'S OWN contract, checked on the finished card.
         v2.40: LTX was judged by an H3-shaped rule ("over the ~200-word LTX ceiling") that its own
         system prompt contradicts — the LTX contract now scores it instead. */
      const sc = isLtx ? scoreLtx(card.v, card.inp) : scoreH3(card.v, card.inp)
      updateCard(card.id, { crit: { score: sc.pct, dims: {}, issues: sc.checks.filter((c) => !c[0]).map((c) => c[1]).slice(0, 4), fix: '', src: 'heuristic', engine: isLtx ? 'ltx' : 'h3' }, critBusy: false })
    }
  }
  const critFnRef = useRef(null)
  critFnRef.current = critiqueCard
  useEffect(() => {
    const onCrit = (e) => critFnRef.current && critFnRef.current(e.detail && e.detail.card)
    window.addEventListener('cps-critique', onCrit)
    return () => window.removeEventListener('cps-critique', onCrit)
  }, [])

  /* Batch mode: run the whole chain through the generator in one click.
     One prompt card per scene (single variant each), bible + captured end
     states travel forward, template stays applied to every scene. */
  async function generateChain() {
    if (busy || chainBusy) return
    const scenes = chain.scenes
    if (!scenes.length) { toast('No scenes yet — hit ✨ Auto-plan chain first'); return }
    setChainBusy(true)
    let ok = 0
    for (let i = 0; i < scenes.length; i++) {
      setChainProg(i + 1)
      let ideaTxt = (scenes[i].idea || '').trim()
      if (!ideaTxt) {
        const plan = offlinePlan(f.idea.trim() || 'this story', scenes.length, f.duration).scenes
        ideaTxt = (plan[Math.min(i, plan.length - 1)] || plan[0]).idea
      }
      setScene(i, { idea: ideaTxt })
      setChain((c) => ({ ...c, active: i + 1 }))
      const made = await generate({
        idea: ideaTxt, variants: 1, flowIdx: i,
        template: scenes[i].tpl || undefined,
        chain: {
          index: i + 1, total: scenes.length,
          bible: chain.bible.trim(),
          prev: i > 0 ? (endsRef.current[i - 1] || (scenes[i - 1].end || '').trim()) : '',
        },
      })
      if (made > 0) ok++
      else break
    }
    setChainBusy(false)
    setChainProg(0)
    if (ok === scenes.length) setStatus('⚡ Chain complete: ' + ok + '/' + scenes.length + ' scene prompts generated — when rendering, feed each clip\'s LAST FRAME into the next scene (Direct auto-arms I2V).')
    else if (ok > 0) setStatus('⚠ Chain stopped at scene ' + ok + '/' + scenes.length + ' — fix the provider or switch engine, then Direct the remaining scenes.')
  }
  /* 🎼 Beat-flow rotation: templates that declare `flows:` get a different flow per
     variant, per chain scene, or per generation (single-variant runs walk the list). */
  const flowRot = useRef(0)
  const presetRef = useRef(null)
  useEffect(() => {
    if (!presetOpen) return
    const h = (e) => { if (presetRef.current && !presetRef.current.contains(e.target)) setPresetOpen(false) }
    const k = (e) => { if (e.key === 'Escape') setPresetOpen(false) }
    document.addEventListener('mousedown', h)
    document.addEventListener('keydown', k)
    return () => { document.removeEventListener('mousedown', h); document.removeEventListener('keydown', k) }
  }, [presetOpen])
  const [gateOpen, setGateOpen] = useState(false)
  const [tplOpen, setTplOpen] = useState(false)
  const genRef = useRef(null)
  const [planTotal, setPlanTotal] = useState(60)
  const [busyPlan, setBusyPlan] = useState(false)
  const [chainBusy, setChainBusy] = useState(false)
  /* Add-on 60: character bibles — identity travels by reference + verbatim anchors */
  const [chars, setChars] = useState(() => { try { return JSON.parse(localStorage.getItem('cps_chars')) || [] } catch (e) { return [] } })
  const setChar = (i, patch) => setChars((cs) => cs.map((c, j) => (j === i ? { ...c, ...patch } : c)))
  useEffect(() => { try { localStorage.setItem('cps_chars', JSON.stringify(chars)) } catch (e) {} }, [chars])
  const CHAR_EMPTY = { name: '', anchors: '', attrs: '', wardrobe: '', voice: '' }
  const [chainProg, setChainProg] = useState(0)
  const endsRef = useRef({})
  const [phModal, setPhModal] = useState(null)
  /* Heavy templates carry many tokens — the modal shows the strongest 8 first and
     unfolds the rest on demand, so filling never feels like a form. */
  const [phAll, setPhAll] = useState(false)
  const prevToksRef = useRef(null)
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }))
  /* 🎛 Engine settings have ONE home (⚙️ Settings → 🎛 Engine). The form hydrates from
     them and follows any change made there, so the two can never disagree. */
  useEffect(() => {
    const e = engSet || ENGINE_DEFAULTS
    setF((p) => {
      const n = {
        ...p,
        engine: e.engine, variants: e.variants, temperature: e.temperature,
        detail: e.detail, fewshot: e.fewshot, enhance: e.enhance,
        mature: matureOn === undefined ? p.mature : !!matureOn,
      }
      const same = ['engine', 'variants', 'temperature', 'detail', 'fewshot', 'enhance', 'mature'].every((k) => p[k] === n[k])
      return same ? p : n
    })
  }, [engSet, matureOn])

  // load-example events from the library + history restore
  const applyExample = (ex) => {
    if (!ex) return
    const st = ex.settings || {}
    const tp = st.template ? (templates || []).find((x) => x.t === st.template) : null
    if (tp) {
      /* a template load: its pinned settings land and stale 🧩 fields go with it */
      const sw = switchTemplate({ ...f, idea: ex.idea != null ? ex.idea : f.idea }, tp)
      setF((p) => ({ ...p, ...switchTemplate({ ...p, idea: ex.idea != null ? ex.idea : p.idea }, tp).patch, ...st }))
      toast('📐 ' + tp.t + ' loaded — ' + (describeSettings(st) || 'settings applied') + (sw.kept.length ? ' · ' + sw.kept.length + ' field(s) kept' : '') + (sw.dropped.length ? ' · 🧹 ' + sw.dropped.length + ' stale field(s) cleared' : ''))
      return
    }
    setF((p) => ({ ...p, idea: ex.idea != null ? ex.idea : p.idea, ...st }))
    toast(ex.tip || 'Example loaded — press Generate 🎬')
  }
  useEffect(() => {
    const onLoad = (e) => applyExample(e.detail)
    const onIdea = (e) => {
      setF((p) => ({ ...p, idea: e.detail }))
      toast('Idea loaded — tweak & Generate')
    }
    const onRestore = (e) => {
      const h = e.detail || {}
      const inp = h.inp || {}
      setF((p) => ({
        ...p,
        idea: h.idea || inp.idea || '',
        category: inp.category || p.category, style: inp.style || p.style,
        structure: inp.structure || p.structure, camera: inp.camera || p.camera,
        amp: inp.amp || p.amp, speed: inp.speed || p.speed,
        ratio: inp.ratio || p.ratio, resolution: inp.resolution || p.resolution,
        duration: inp.duration || p.duration, music: inp.music || p.music,
        ambience: inp.ambience || '', dialogue: inp.dialogue || '', dlang: inp.dlang || p.dlang,
        foley: inp.foley || '', audioNotes: inp.audioNotes || '', dialogueOn: inp.dialogueOn !== false,
        palette: inp.palette || p.palette, negation: inp.negation || '', extra: inp.extra || '',
        workflow: inp.workflow || 't2v', frameStart: inp.frameStart || '', frameEnd: inp.frameEnd || '',
        ph: inp.phValues || inp.ph || {},
        loras: Array.isArray(inp.loras) ? inp.loras.map((l) => l.t) : [],
        enhance: !!inp.enhance,
        detail: inp.detail !== false,
        target: inp.target || p.target,
        mature: !!inp.mature,
      }))
      toast('History entry restored — tweak & Generate')
    }
    window.addEventListener('cps-load-example', onLoad)
    window.addEventListener('cps-load-idea', onIdea)
    window.addEventListener('cps-restore-entry', onRestore)
    return () => {
      window.removeEventListener('cps-load-example', onLoad)
      window.removeEventListener('cps-load-idea', onIdea)
      window.removeEventListener('cps-restore-entry', onRestore)
    }
  }, [toast])

  /* payloads latched by App while this form was unmounted (Learn/History views) */
  useEffect(() => {
    if (!pendingLoad) return
    if (pendingLoad.kind === 'example') applyExample(pendingLoad.data)
    if (pendingLoad.kind === 'chain') planTemplateChain(pendingLoad.data)
    if (pendingLoad.kind === 'restore') {
      const h = pendingLoad.data || {}
      const inp = h.inp || {}
      setF((p) => ({
        ...p,
        idea: h.idea || inp.idea || '',
        category: inp.category || p.category, style: inp.style || p.style,
        structure: inp.structure || p.structure, camera: inp.camera || p.camera,
        amp: inp.amp || p.amp, speed: inp.speed || p.speed,
        ratio: inp.ratio || p.ratio, resolution: inp.resolution || p.resolution,
        duration: inp.duration || p.duration, music: inp.music || p.music,
        workflow: inp.workflow || p.workflow,
        target: inp.target || p.target,
      }))
      toast('History entry restored — tweak & Generate')
    }
    if (onPendingConsumed) onPendingConsumed()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingLoad])

  // NSFW kill switch: window.cpsNsfw.block() / allow() / status()
  useEffect(() => {
    window.cpsNsfw = {
      block: () => {
        try { localStorage.setItem('cps_nsfw_blocked', '1'); localStorage.setItem('cps_nsfw', 'off') } catch (e) {}
        setF((p) => ({ ...p, mature: false }))
        toast('🚫 Mature themes BLOCKED — all generation now uses the SFW system prompts')
      },
      allow: () => { try { localStorage.removeItem('cps_nsfw_blocked') } catch (e) {} toast('Mature themes unblocked (still needs the 18+ consent checkbox to activate)') },
      status: () => { try { return { blocked: localStorage.getItem('cps_nsfw_blocked') === '1', enabled: localStorage.getItem('cps_nsfw') === 'on' } } catch (e) { return {} } },
    }
  }, [])

  // LoRAs armed from the Learn library
  useEffect(() => {
    const h = (e) => {
      const t = e.detail
      setF((p) => ({ ...p, loras: (p.loras || []).includes(t) ? p.loras : [...(p.loras || []), t] }))
    }
    window.addEventListener('cps-lora-add', h)
    return () => window.removeEventListener('cps-lora-add', h)
  }, [])

  // Ctrl+Enter generates
  useEffect(() => {
    const h = (e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') generate() }
    document.addEventListener('keydown', h)
    return () => document.removeEventListener('keydown', h)
  })

  /* Prompt-pack routing shown live next to the picker (and used by genOllama).
     Chain mode resolves against the ACTIVE scene's own 📐 template. */
  const tagOfTpl = (name) => (((templates || []).find((x) => x.t === name) || {}).tag || '')
  const activeScene = chain.active >= 1 ? chain.scenes[chain.active - 1] : null
  const uiTag = tagOfTpl(((activeScene && activeScene.tpl) ? activeScene.tpl : f.template) || '')
  const packRes = resolvePacks(packs || [], { pick: f.pack || 'auto', tag: uiTag, category: f.category, idea: f.idea, mode: f.fashCam || 'perform' })
  const fashionPack = packRes.chosen.some((p) => p.id === 'fashion' || p.id === 'ethnic')

  /* ⏱ Live clock: the same helper the prompt is built from, so what you see here
     is exactly the runtime budget the engine is handed. */
  const liveClock = liveClockFor(f)
  const tplPinned = (templates || []).find((x) => x.t === f.template) || null
  const tplPin = tplPinned && tplPinned.settings ? tplPinned.settings.duration : 0
  const clockText = liveClock.shots === 1
    ? 'one continuous shot, ' + liveClock.dur + 's — no cuts, no timecodes'
    : liveClock.shots + ' shots — cuts at ' + liveClock.cuts.map(fmtTC).join(' / ') + ', last shot ' + liveClock.windows[liveClock.windows.length - 1] + 's' +
      (liveClock.envelope && liveClock.envelope !== 'flat' ? ' · ' + liveClock.envelopeLabel : '')
  const cost = (f.duration * (f.resolution === '2K' ? 0.13 : 0.08)).toFixed(2)
  const useOllama = f.engine === 'ollama' || (f.engine === 'auto' && conn.status === 'ok' && conn.model)
  const provName = conn.provider && conn.provider !== 'ollama' ? (conn.provider === 'gemini' ? 'Gemini' : conn.provider === 'groq' ? 'Groq' : 'the API provider') : 'Ollama'
  const engNow = engineSummary({ engine: (engSet && engSet.engine) || f.engine, variants: (engSet && engSet.variants) || f.variants, temperature: (engSet && engSet.temperature) != null ? engSet.temperature : f.temperature, detail: (engSet && engSet.detail) !== undefined ? engSet.detail : f.detail, fewshot: (engSet && engSet.fewshot) !== undefined ? engSet.fewshot : f.fewshot, enhance: (engSet && engSet.enhance) !== undefined ? engSet.enhance : f.enhance }, conn, critOn)
  const engineNote = conn.status === 'ok'
    ? (f.engine === 'offline'
        ? 'Using the built-in instant engine.'
        : (conn.model
            ? 'Ready with ' + conn.model + ' via ' + provName + (conn.provider === 'ollama' ? ' — fully private, no cloud.' : '.')
            : provName + ' connected but no model selected.'))
    : conn.status === 'nokey'
        ? '⚠ ' + provName + ' needs an API key — add it in ⚙️ Settings.'
        : (f.engine === 'ollama'
            ? '⚠ ' + provName + ' not reachable — check ⚙️ Settings.'
            : 'No provider connected — the built-in instant engine will be used.') + (f.target === 'ltx' ? ' · ⚡ LTX mode: one flowing paragraph, no labels.' : '')

  async function generate(ovr) {
    if (busy) return
    if (ovr && ovr.ph) setF((p) => ({ ...p, ph: { ...(p.ph || {}), ...ovr.ph } }))
    const tplSel = (ovr && ovr.template !== undefined) ? ovr.template : f.template
    const phBase = { ...(f.ph || {}), ...((ovr && ovr.ph) || {}) }
    const phVals = Object.fromEntries(Object.entries(phBase).filter(([, v]) => v && v.trim()))
    const fill = (t) => fillText(t, phVals)
    const inp = {
      idea: fill(((ovr && ovr.idea != null) ? ovr.idea : f.idea).trim()), category: f.category, style: f.style, structure: f.structure,
      camera: f.camera, amp: f.amp, speed: f.speed, loop: !!f.loop, ratio: f.ratio, resolution: f.resolution,
      duration: f.duration, music: f.music, ambience: f.ambience.trim(), dialogue: f.dialogueOn ? f.dialogue.trim() : '',
      foley: f.foley.trim(), audioNotes: f.audioNotes.trim(),
      dialogueOn: f.dialogueOn, dialogueRaw: f.dialogue.trim(),
      chars: (chars || []).filter((c) => (c.name || '').trim() || (c.anchors || '').trim()),
      dlang: f.dlang, palette: f.palette, negation: f.negation.trim(), extra: f.extra.trim(),
      refs: (f.refs || []).map((r) => ({ type: r.type, job: (r.job || '').trim(), name: r.name || '' })),
      keyframes: !!f.keyframes, sendRefs: !!f.sendRefs,
      workflow: f.workflow, frameStart: f.frameStart.trim(), frameEnd: f.frameEnd.trim(),
      phValues: phVals,
      loras: (f.loras || []).map((t) => (loras || []).find((l) => l.t === t)).filter(Boolean),
      icStyleOnly: f.target === 'ltx' && (f.ic || {}).proto === 'control',
      templateGuide: ((templates || []).find((t) => t.t === tplSel) || null) && { t: tplSel, b: (templates || []).find((t) => t.t === tplSel).b },
      templateFlows: ((templates || []).find((t) => t.t === tplSel) || {}).flows || [],
      templateVary: ((templates || []).find((t) => t.t === tplSel) || {}).vary || [],
      flowBase: (ovr && ovr.flowIdx != null) ? ovr.flowIdx : flowRot.current++,
      templateTag: ((templates || []).find((t) => t.t === tplSel) || {}).tag || '',
      unfilled: [],
      enhance: f.enhance, detail: f.detail, target: f.target, mature: (() => {
        const wants = looksMature((f.idea || '') + ' ' + (((templates || []).find((t) => t.t === tplSel) || {}).b || ''))
        const gate = matureRouting({ consent: !!f.mature, blocked: nsfwBlocked(), wants })
        try { logger.info('mature', 'routing: 18+ switch ' + (gate.matureOn ? 'ON → 🔞 mature system prompt' : 'OFF → 🛡️ SFW system prompt') + ' · idea ' + (wants ? 'reads 18+ (advisory only)' : 'reads SFW')) } catch (e) {}
        if (gate.advisory) toast('🔞 This idea reads 18+ but the 18+ opt-in is off — tick it in the Mature card to run your mature system prompt (staying 🛡️ SFW for now)')
        return gate.matureOn
      })(),
    }
    {
      /* Placeholders nobody filled stay as tokens on purpose - the model is
         instructed to invent concrete values for them. Count them for the UI. */
      const src = (inp.idea || '') + ' ' + ((inp.templateGuide && inp.templateGuide.b) || '')
      const seen = {}
      uniqueTokens([src]).forEach((x) => { seen[x.name] = 1 })
      Object.keys(phVals).forEach((k) => { delete seen[k] })
      inp.unfilled = Object.keys(seen)
      if (inp.unfilled.length && useOllama && !(ovr && (ovr.invent || ovr.ph))) {
        /* CONFIRM & FILL: pause, let the LLM propose values, user edits/accepts,
           then generation continues with the filled values. */
        setPhModal({ tokens: inp.unfilled, values: Object.fromEntries(inp.unfilled.map((t) => [t, ''])), busy: true, err: '', autoGen: true }); setPhAll(false)
        suggestFill(inp.unfilled)
        return
      }
      if (inp.unfilled.length) toast('🧩 ' + inp.unfilled.length + ' placeholder' + (inp.unfilled.length > 1 ? 's' : '') + ' unfilled — the model will invent concrete values (' + inp.unfilled.slice(0, 3).join(', ') + (inp.unfilled.length > 3 ? '…' : '') + ')')
    }
    if (f.engine === 'ollama' && conn.status !== 'ok') { toast('⚠ Ollama isn’t reachable — see ⚙️ Settings'); return }
    if (!inp.idea && !inp.enhance) { toast('Describe your shot first ✍️'); return }
    if (inp.workflow === 'multiref' && !inp.refs.length) toast('ℹ️ Multi-ref workflow: no references attached yet — the prompt will assign jobs by number; attach files under 🖼️ Reference assets')
    if ((inp.workflow === 'i2v' || inp.workflow === 'fflf') && !inp.refs.some((r) => r.type === 'image')) toast('ℹ️ ' + (inp.workflow === 'i2v' ? 'I2V' : 'First→Last') + ': attach the frame image(s) under 🖼️ Reference assets on this machine too if you want them vision-read')
    const nVariants = (ovr && ovr.variants) ? ovr.variants : +f.variants
    /* Story chain: consistency bible + previous end state travel with every scene */
    const chainCtx = (ovr && ovr.chain) ? ovr.chain
      : (chain.active >= 1 && chain.scenes.length ? {
          index: chain.active, total: chain.scenes.length,
          bible: chain.bible.trim(),
          prev: chain.active - 1 > 0 ? (chain.scenes[chain.active - 2].end || '').trim() : '',
        } : null)
    if (chainCtx) inp.chain = chainCtx
    /* Vision frame reading: ONE 512px image per small request; only the resulting
       captions enter the main generation call, so every request stays within the
       model's context budget. Runs for BOTH targets whenever a local model is in use. */
    if (useOllama && f.sendRefs &&
        (f.refs || []).some((r) => r.type === 'image' && r.thumb)) {
      let canSee = conn.provider === 'ollama' && await detectVision(conn.base, conn.model)
      if (!canSee && conn.provider === 'ollama') {
        /* Optimistic probe: many Ollama builds don't advertise vision capabilities -
           try one frame; a real caption means the model can see. */
        const firstImg = (f.refs || []).find((r) => r.type === 'image' && r.thumb)
        if (firstImg) {
          const probe = await visionRead(firstImg.thumb, (firstImg.job || '').trim())
          if (probe && probe.length > 20) { canSee = true; window.__cpsProbeCaption = { job: firstImg.job, cap: probe } }
        }
      }
      if (conn.provider !== 'ollama') toast('ℹ Frame reading currently runs on Ollama vision models — your captions will be used')
      if (canSee) {
        const idx = (f.refs || []).map((r, i) => (r.type === 'image' && r.thumb ? i : -1)).filter((i) => i >= 0)
        const seen = {}
        const motionTo = {} // frame label -> transition text arriving into it
        if (idx.length >= 3) {
          /* Contact sheets: 3 frames per request, numbered 384px tiles */
          const groups = chunkFrames(idx.length)
          for (let g = 0; g < groups.length; g++) {
            const grp = groups[g]
            const gLabels = grp.map((k) => k + 1)
            setStatus('👁 Reading sheet ' + (g + 1) + '/' + groups.length + ' (frames ' + gLabels[0] + '–' + gLabels[gLabels.length - 1] + ') with ' + conn.model + '…')
            const items = grp.map((k) => ({ thumb: f.refs[idx[k]].thumb, label: k + 1 }))
            const notes = grp.map((k) => (f.refs[idx[k]].job || '').trim())
            let sheet = null
            try { sheet = await makeContactSheet(items) } catch (e) { sheet = null }
            if (sheet) {
              const res = await visionGroup(sheet, gLabels, notes)
              for (const k of grp) {
                const cap = res.frames[k + 1] || ''
                if (cap) seen[idx[k]] = cap
              }
              if (!Object.keys(res.frames).length || (res.frames._raw && Object.keys(res.frames).length === 1)) {
                if (res.frames._raw && !seen[idx[grp[0]]]) seen[idx[grp[0]]] = res.frames._raw
              }
              for (const lbl of Object.keys(res.motions)) motionTo[+lbl] = res.motions[lbl]
            } else {
              for (const k of grp) {
                const cap = await visionRead(f.refs[idx[k]].thumb, (f.refs[idx[k]].job || '').trim())
                if (cap) seen[idx[k]] = cap
              }
            }
          }
        } else {
          for (let n = 0; n < idx.length; n++) {
            const i = idx[n]
            setStatus('👁 Reading frame ' + (n + 1) + '/' + idx.length + ' with ' + conn.model + '…')
            const cap = await visionRead(f.refs[i].thumb, (f.refs[i].job || '').trim())
            if (cap) seen[i] = cap
          }
        }
        if (window.__cpsProbeCaption) {
          const pi = (f.refs || []).findIndex((r) => r.type === 'image' && r.thumb)
          if (pi >= 0 && !seen[pi]) seen[pi] = window.__cpsProbeCaption.cap
          window.__cpsProbeCaption = null
        }
        const nSeen = Object.keys(seen).length
        if (nSeen) {
          let imgNo = 0
          inp.refs = (f.refs || []).map((r, i) => {
            const out = { type: r.type, name: r.name || '' }
            if (r.type === 'image' && r.thumb) imgNo++
            if (seen[i]) {
              const u = (r.job || '').trim()
              let cap = seen[i]
              const mt = motionTo[imgNo]
              if (mt) cap += ' | Transition into this frame: ' + mt
              out.job = 'Seen in frame: ' + cap + (u ? ' — Director’s note: ' + u : '')
            } else out.job = (r.job || '').trim()
            return out
          })
          inp.seesImages = true
          toast('👁 ' + nSeen + ' frame' + (nSeen > 1 ? 's' : '') + ' read by ' + conn.model + ' — descriptions feed the prompt')
        }
      } else toast('ℹ ' + conn.model + ' is text-only — captions only (try llava, qwen2.5vl or gemma3 for frame reading)')
    }
    setBusy(true)
    setStatus('')
    const t0 = performance.now()
    let made = 0
    for (let k = 1; k <= nVariants; k++) {
      setStatus('Generating variant ' + k + ' of ' + nVariants + '…')
      try {
        let v
        if (useOllama) {
          v = await genOllama(inp, k, nVariants)
          if (!v) {
            /* Provider failed mid-run: on the AUTO engine degrade to the offline
               engine instead of producing nothing. Explicit Ollama stays strict
               so misconfiguration stays visible. Full failure detail is already
               in the console via the logger (CPS OLLAMA groups). */
            if (f.engine === 'auto') {
              toast('⚠ Provider failed — falling back to the instant offline engine (see console logs for the Ollama error)')
              v = inp.target === 'ltx' ? await genVariantLtxOffline(inp, k, nVariants) : await genVariantOffline(inp, k, nVariants)
              if (v && !v.title) v.title = deriveTitle(inp.idea)
              if (v) { v.engine = 'offline-fallback'; v.promptSet = 'sfw-' + (inp.target === 'ltx' ? 'ltx' : 'h3') + ' (offline)' }
              if (!v) break
            } else break
          }
        } else {
          const id = 'c' + Math.random().toString(36).slice(2)
          pushCard({ id, kind: 'variant', v: null, streaming: true, inp })
          await new Promise((r) => setTimeout(r, 280))
          v = inp.target === 'ltx'
            ? await genVariantLtxOffline(inp, k, nVariants)
            : await genVariantOffline(inp, k, nVariants)
          if (!v.title) v.title = deriveTitle(inp.idea)
          if (!v.promptSet) v.promptSet = 'sfw-' + (inp.target === 'ltx' ? 'ltx' : 'h3') + ' (offline)'
          updateCard(id, { v, streaming: false })
        }
        pushHistory(v, inp, 'studio')
        if (chainCtx && (v.integrated_multimodal_description || v.prompt)) {
          const ci = chainCtx.index - 1
          const endTxt = endStateOf(v.integrated_multimodal_description || v.prompt)
          if (endTxt) {
            endsRef.current[ci] = endTxt
            setChain((c) => ({ ...c, scenes: c.scenes.map((s, j) => (j === ci ? { ...s, end: endTxt } : s)) }))
          }
        }
        made++
      } catch (err) {
        pushCard({ id: 'e' + Math.random().toString(36).slice(2), kind: 'error', message: err.message })
      }
    }
    const dt = ((performance.now() - t0) / 1000).toFixed(1)
    let unloadNote = ''
    if (useOllama && made > 0 && conn.provider === 'ollama') {
      const ok = await unloadModel(conn.base, conn.model)
      unloadNote = ok ? ' · 🧹 model unloaded (RAM/VRAM freed)' : ''
    }
    let exNote = ''
    if (useOllama && f.fewshot && inp.target === 'h3' && EXAMPLES.length) exNote = ' · 📚 taught by example: ' + pickExemplar(inp).title
    if (made === 0) {
      setStatus('❌ No variants produced — see the error card above. Switch Engine to “Instant offline engine”, or fix the provider in ⚙️ Settings and retry.')
    } else {
      setStatus('✅ ' + made + ' variant' + (made === 1 ? '' : 's') + ' in ' + dt + 's · ' +
        (useOllama ? conn.model : 'instant offline engine') + ' · ' + inp.ratio + ' · ' + inp.resolution + ' · ' + inp.duration + 's' + (inp.promptSetUsed === 'universal' ? ' · 🌐 universal prompt: ' + (inp.promptSetFile || '') : inp.promptSetUsed === 'slot' ? ' · 🎯 prompt: ' + (inp.promptSetFile || '') : inp.mature && !inp.matureFallback ? ' · 🔞 mature prompt set' : inp.matureFallback ? ' · ⚠ 18+ unavailable — SFW prompt used' : ' · 🛡️ SFW prompt set') + exNote + unloadNote)
    }
    setBusy(false)
    return made
  }

  async function genOllama(inp, k, nVariants) {
    const id = 'c' + Math.random().toString(36).slice(2)
    const packMode = f.fashCam || 'perform'
    const packRes = resolvePacks(packs || [], { pick: f.pack || 'auto', tag: inp.templateTag || '', category: f.category, idea: inp.idea, mode: packMode })
    inp.packs = packRes.chosen.map((p) => p.label)
    inp.packIds = packRes.chosen.map((p) => p.id)
    /* 🔀 Everything-varies templates: the variation contract travels with the request and the
       pools ride in as extra system craft, so variant 2 cannot repeat variant 1's outfit. */
    if ((inp.templateVary || []).length) {
      inp.vary = inp.templateVary
      inp.variantIndex = k
      inp.variantTotal = nVariants
      try { logger.info('engine', '🔀 variation contract: ' + inp.vary.length + ' dimensions · variant ' + k + ' of ' + nVariants + ' → ' + inp.vary.join(' · ')) } catch (e) {}
    }
    const fl = inp.templateFlows || []
    if (fl.length) {
      const fb = nVariants > 1 ? (k - 1) : (inp.flowBase || 0)
      const fi = ((fb % fl.length) + fl.length) % fl.length
      inp.flow = { name: fl[fi], index: fi + 1, total: fl.length }
      try { logger.info('engine', 'beat flow: 🎼 ' + fl[fi] + ' (' + (fi + 1) + '/' + fl.length + ') — variant ' + k + ' of ' + nVariants) } catch (e) {}
    }
    pushCard({ id, kind: 'variant', v: null, streaming: true, inp })
    try {
    const isLtx = inp.target === 'ltx'
    const matureOn = !!inp.mature
    /* Base first — the mature file IS the base of a mature run, and craft can only
       ever be appended to it (see src/lib/syscompose.js). */
    const baseInfo = chooseBase({
      isLtx, matureOn,
      sfw: isLtx ? ltxSysPrompt : sysPrompt,
      mature: isLtx ? ltxMature : sysMature,
      route: sysRoute || {},
      lookup: sysLookup,
    })
    if (baseInfo.fellBack) {
      inp.matureFallback = true
      try { logger.warn('mature', '⚠ 18+ run has NO mature system prompt: ' + baseInfo.reason + ' — this generation runs on ' + baseInfo.file) } catch (e) {}
      toast('⚠ 18+ prompt set unavailable (' + baseInfo.reason + ') — this generation uses the SFW prompt. Check ⚙️ Settings → System prompt.')
    }
    /* Domain craft packs: only the verticals this generation is actually about
       (template tag → category → idea words, or the explicit picker). */
    const craftBlocks = []
    for (const p of packRes.chosen) {
      const blk = packBlock(p, packMode)
      if (blk) craftBlocks.push({ label: '📦 ' + p.id, text: blk })
    }
    /* 🧩 Attached context files (⚙️ Settings → routing): the user's own banks (dialogues,
       secondary actions, examples) appended to the system prompt for the slots they chose —
       no prompt file has to be edited for this to work. */
    const slotNow = baseInfo.slot || slotOf(isLtx, matureOn)
    const attachedPaths = [...new Set([
      ...(((sysRoute || {}).attach || {}).all || []),
      ...(((sysRoute || {}).attach || {})[slotNow] || []),
    ])]
    const attachedUsed = []
    for (const p of attachedPaths) {
      const got = sysLookup ? sysLookup(p) : null
      if (!got || !got.text) continue
      craftBlocks.push({ label: '🧩 ' + p.split('/').pop(), text: '\n\n# CONTEXT FILE — ' + p + '\n' + got.text })
      attachedUsed.push(p)
    }
    /* Variation pools — only loaded for templates that declare `vary:`. */
    if ((inp.templateVary || []).length && variationPools) {
      craftBlocks.push({ label: '🔀 variation pools', text: '\n\n# VARIATION POOLS — draw this variant\u2019s option from each pool exactly as the VARIATION CONTRACT instructs\n' + variationPools })
    }
    const composed = composeSystem({ base: baseInfo.text, blocks: craftBlocks })
    let sys = composed.text
    const packChars = composed.applied.reduce((n2, a) => n2 + a.chars, 0)
    if (!composed.baseIntact) {
      try { logger.error('engine', '⚠ system-prompt base was modified by craft — packs must only append'); } catch (e) {}
    }
    try {
      logger.info('engine', 'prompt packs: ' + (packRes.chosen.length
        ? packRes.chosen.map((p) => p.icon + ' ' + p.id).join(' + ') + ' — ' + packRes.why + (packChars ? ' (+' + packChars + ' chars)' : '')
        : 'none — ' + packRes.why))
    } catch (e) {}
    inp.promptSetFile = baseInfo.file
    inp.promptSetUsed = baseInfo.used
    /* The label the output card shows. 'mature' / 'sfw' follow the prompt file actually used;
       a routed file says so, and a silent downgrade is never labelled as mature. */
    const promptSet = promptSetLabel({ ...baseInfo, wasMature: matureOn }, isLtx)
    const routedObj = (baseInfo.routed && sysLookup) ? sysLookup(baseInfo.used === 'universal' ? (sysRoute || {}).universal : (sysRoute || {})[baseInfo.slot]) : null
    const sysObj = routedObj || (isLtx ? (matureOn ? ltxMature : ltxSysPrompt) : (matureOn ? sysMature : sysPrompt))
    const sysDeps = (baseInfo.used === 'sfw-fallback' && !baseInfo.routed ? null : (sysObj && sysObj.deps)) || []
    const sysMissing = (baseInfo.used === 'sfw-fallback' && !baseInfo.routed ? null : (sysObj && sysObj.missing)) || []
    logger.info('ollama', 'system prompt set: ' + (matureOn ? 'MATURE-' : 'SFW-') + (isLtx ? 'LTX' : 'H3')
      + (baseInfo.used === 'universal' ? ' · 🌐 UNIVERSAL ROUTE' : baseInfo.used === 'slot' ? ' · 🎯 ROUTED FILE' : '')
      + (baseInfo.fellBack ? ' (FALLBACK → SFW BASE)' : '')
      + ' · ' + promptReport(baseInfo, composed)
      + (sysDeps.length ? ' · 📎 dependencies: ' + sysDeps.join(', ') : '')
      + (attachedUsed.length ? ' · 🧩 attached context: ' + attachedUsed.join(', ') : '')
      + (sysMissing.length ? ' · ⚠ missing: ' + sysMissing.map((m) => m.path).join(', ') : ''))
    let exUsed = null
    if (!isLtx && f.fewshot && EXAMPLES.length) {
      exUsed = pickExemplar(inp)
      sys += '\n\nEXEMPLAR — ' + exUsed.cat + ' (' + exUsed.title + '). Match its format and grammar exactly. Its detail level is a floor, not a ceiling — write as fully as the scene deserves:\n' + exUsed.prompt
    }
    const temp = Math.min(1.2, f.temperature + 0.12 * (k - 1))
    const messages = [
      { role: 'system', content: sys },
      { role: 'user', content: isLtx ? buildUserMessageLtx(inp, k, nVariants) : buildUserMessage(inp, k, nVariants) },
    ]
    let acc = ''
    const t0 = performance.now()
    const streamer = conn.provider && conn.provider !== 'ollama'
      ? streamOpenAIChat(providerConfig(conn.provider), conn.model, messages, temp, { json: isLtx })
      : streamChat(conn.base, conn.model, messages, temp, { json: isLtx })
    for await (const piece of streamer) {
      acc += piece
      /* Ref2VA streams its body under detailed_description; base modes stream the description field. */
      const p = isLtx
        ? extractPartial(acc, 'prompt')
        : (f.workflow === 'multiref'
            ? (extractPartial(acc, 'detailed_description') || extractPartial(acc, 'integrated_multimodal_description'))
            : (extractLabeled(acc, 'integrated_multimodal_description') || extractPartial(acc, 'integrated_multimodal_description')))
      if (p) updateCard(id, { streamText: p })
    }
    const dt = ((performance.now() - t0) / 1000).toFixed(1)
    const v = finalizeOutput(acc, isLtx ? 'ltx' : 'h3')
    v.engine = 'ollama'; v.model = conn.model; v.secs = dt; v.promptSet = promptSet
    if (isLtx) v.target = 'ltx'
    if (exUsed) v.exemplar = exUsed.title
    if (inp.flow) v.flow = inp.flow.name
    if (!v.title) v.title = deriveTitle(inp.idea)
    updateCard(id, { v, streaming: false })
    return v
    } catch (err) {
      /* a provider failure must kill the spinner and say WHY — no ghost activity */
      updateCard(id, { v: null, streaming: false, streamText: '' })
      const msg = ((err && err.message) || String(err)).slice(0, 240)
      pushCard({ id: 'e' + Math.random().toString(36).slice(2), kind: 'error', message: msg })
      setStatus('❌ ' + (conn.model || 'model') + ' (' + (conn.provider || 'ollama') + ') failed: ' + msg)
      toast(conn.provider && conn.provider !== 'ollama'
        ? '❌ ' + (conn.provider === 'gemini' ? 'Gemini' : conn.provider === 'groq' ? 'Groq' : 'Provider') + ' error — check key/quota in ⚙️ Settings, or use the Instant offline engine.'
        : '❌ Ollama error — is the server running & model pulled? The Instant offline engine always works.')
      if (onRecheck) onRecheck()
      return null
    }
  }

  /* ---------- reference assets (ref2video) ---------- */
  const REF_CAP = { image: 9, video: 3, audio: 3 }
  const REF_ICON = { image: '🖼️', video: '🎞️', audio: '🎵' }
  const refCount = (type) => (f.refs || []).filter((r) => r.type === type).length
  const refLabel = (r, i) => {
    const n = (f.refs || []).slice(0, i + 1).filter((x) => x.type === r.type).length
    return (r.type === 'image' ? 'Image ' : r.type === 'video' ? 'Video ' : 'Audio ') + n
  }
  function addRef(type) {
    if (refCount(type) >= REF_CAP[type]) { toast('⚠️ H3 ref2video allows max ' + REF_CAP[type] + ' ' + type + ' file' + (REF_CAP[type] > 1 ? 's' : '')); return }
    if ((f.refs || []).length >= 12) { toast('⚠️ Max 12 reference files per request'); return }
    set('refs', [...(f.refs || []), { type, job: '', name: '', thumb: '' }])
  }
  function rmRef(i) { set('refs', f.refs.filter((_, j) => j !== i)) }
  function setRef(i, patch) { set('refs', f.refs.map((r, j) => (j === i ? { ...r, ...patch } : r))) }
  function refFile(i, file) {
    if (!file) return
    const r = f.refs[i]
    if (r.type === 'image' && file.size <= 12 * 1024 * 1024) {
      const url = URL.createObjectURL(file)
      const img = new Image()
      img.onload = () => {
        const M = 512
        let w = img.width, h = img.height
        if (Math.max(w, h) > M) { const s = M / Math.max(w, h); w = Math.round(w * s); h = Math.round(h * s) }
        try {
          const cv = document.createElement('canvas')
          cv.width = w; cv.height = h
          cv.getContext('2d').drawImage(img, 0, 0, w, h)
          URL.revokeObjectURL(url)
          setRef(i, { name: file.name, thumb: cv.toDataURL('image/jpeg', 0.85) })
        } catch (e) { URL.revokeObjectURL(url); setRef(i, { name: file.name }) }
      }
      img.onerror = () => { URL.revokeObjectURL(url); setRef(i, { name: file.name }) }
      img.src = url
    } else setRef(i, { name: file.name })
  }

  /* Tile up to 4 keyframes into ONE numbered contact sheet (384px cells,
     2 columns, letterboxed) so a small vision model reads several frames
     in a single request - and can compare neighbours to infer motion. */
  async function makeContactSheet(items) {
    /* Big cells + oversized high-contrast badges: local vision models
       downscale the sheet internally (~336-672px), so badges must survive
       a ~50% shrink and still be readable by small models. */
    const CELL = 512, COLS = 2
    const rows = Math.ceil(items.length / COLS)
    const cv = document.createElement('canvas')
    cv.width = COLS * CELL
    cv.height = rows * CELL
    const ctx = cv.getContext('2d')
    ctx.fillStyle = '#111'
    ctx.fillRect(0, 0, cv.width, cv.height)
    for (let i = 0; i < items.length; i++) {
      const img = await new Promise((res, rej) => {
        const im = new Image()
        im.onload = () => res(im)
        im.onerror = () => rej(new Error('load'))
        im.src = items[i].thumb
      })
      const x = (i % COLS) * CELL, y = Math.floor(i / COLS) * CELL
      const s = Math.min(CELL / img.width, CELL / img.height)
      const w = img.width * s, h = img.height * s
      ctx.drawImage(img, x + (CELL - w) / 2, y + (CELL - h) / 2, w, h)
      /* tile border so the grid survives downscaling */
      ctx.strokeStyle = '#ffd400'
      ctx.lineWidth = 4
      ctx.strokeRect(x + 2, y + 2, CELL - 4, CELL - 4)
      /* oversized badge: yellow field, black digit, white ring */
      ctx.fillStyle = '#ffd400'
      ctx.beginPath()
      ctx.roundRect ? ctx.roundRect(x + 14, y + 14, 96, 84, 14) : ctx.rect(x + 14, y + 14, 96, 84)
      ctx.fill()
      ctx.strokeStyle = '#000'
      ctx.lineWidth = 6
      ctx.stroke()
      ctx.fillStyle = '#000'
      ctx.font = 'bold 64px sans-serif'
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillText(String(items[i].label), x + 62, y + 58)
      ctx.textAlign = 'left'
    }
    return cv.toDataURL('image/jpeg', 0.88)
  }

  /* Live placeholder tracking: tokens in idea + skeleton, new/unused detection */
  const tplSkel = ((templates || []).find((t) => t.t === f.template) || {}).b || ''
  /* One 🧩 field per token NAME — the same token may appear in the idea and again in the
     skeleton with fuller guidance; that is still one field, with the richest hint shown. */
  const phFields = uniqueTokens([f.idea || '', tplSkel])
  const phToks = phFields.map((x) => x.name)
  const phHint = Object.fromEntries(phFields.map((x) => [x.name, x.hint]))
  const newToks = prevToksRef.current ? phToks.filter((t) => !prevToksRef.current.includes(t)) : []
  useEffect(() => { prevToksRef.current = phToks }, [phToks.join('|')])
  const unusedPh = Object.entries(f.ph || {}).filter(([k, v]) => v && v.trim() && !phToks.includes(k))

  const ideaLen = f.idea.length
  const seenP = new Set()
  const groupedPresets = (presets || []).length ? PRESET_GROUPS.map(([gname, test]) => {
    const list = presets.filter((pp) => !seenP.has(pp.t) && test(pp))
    list.forEach((pp) => seenP.add(pp.t))
    return [gname, list]
  }).filter(([, list]) => list.length) : []
  genRef.current = generate
  useEffect(() => {
    const h = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); if (genRef.current) genRef.current() }
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); setTplOpen(true) }
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [])

  return (
    <div>
      {presets && presets.length ? (
        <div className="preset-wrap" ref={presetRef}>
          <button type="button" className={'preset-btn' + (presetOpen ? ' on' : '')} onClick={() => setPresetOpen((o) => !o)}>
            ⚡ Presets <span className="chev">{presetOpen ? '▴' : '▾'}</span>
          </button>
          <span className="preset-hint" title="one-click bundles that set workflow + settings for you">bundles</span>
          {presetOpen ? (
            <div className="preset-menu" role="menu">
              {groupedPresets.map(([gname, list]) => {
                return (
                  <div key={gname}>
                    <div className="preset-group">{gname}</div>
                    {list.map((pp) => (
                      <button key={pp.t} type="button" className="preset-item" role="menuitem"
                        onClick={() => {
                          window.dispatchEvent(new CustomEvent('cps-load-example', { detail: { idea: pp.idea, settings: pp.settings, tip: pp.tip } }))
                          setPresetOpen(false)
                        }}>
                        <span className="pi-t">{pp.t}</span>
                        <span className="pi-d">{pp.d}</span>
                      </button>
                    ))}
                  </div>
                )
              })}
            </div>
          ) : null}
        </div>
      ) : null}
      <details className="grp" open>
        <summary><span className="step">1</span> Scene</summary>
        <div className="secbody">
        <div className="frow">
          <label>Target <Q sec="builder" tip="H3 = three-field MiniMax skeleton · LTX = one-paragraph prompt. Details in Guide →" /></label>
          <Chips values={['h3', 'ltx']} value={f.target}
            onChange={(v) => { set('target', v); try { localStorage.setItem('cps_target', v) } catch (e) {} }}
            labels={{ h3: '🎬 MiniMax H3', ltx: '⚡ LTX-Video 2.x' }} />
        </div>
        <div className="frow">
          <label>Workflow <Q sec="refs" tip={Object.entries(WF_HINT).map(([k, v]) => k.toUpperCase() + ': ' + v).join('  ·  ')} /></label>
          <Chips values={Object.keys(WORKFLOWS)} value={f.workflow} onChange={(v) => set('workflow', v)} labels={WORKFLOWS} />
        </div>
        <div className="frow">
          <label>Dialogue <Q sec="filmcraft" tip="on = model may write spoken lines with tone · off = hard-bans ALL speech in the prompt. Guide →" /></label>
          <Chips values={['on', 'off']} value={f.dialogueOn ? 'on' : 'off'}
            onChange={(v) => set('dialogueOn', v === 'on')}
            labels={{ on: '🗣 on — spoken lines welcome', off: '🔇 none — fully silent scene' }} />

        </div>
        {f.workflow !== 't2v' ? (
          <div className="fwide">
            <div className="hint" style={{ marginTop: -2 }} title={WF_HINT[f.workflow]}>
              {f.workflow === 'multiref' ? (
                <a href="#refs" onClick={(e) => {
                  e.preventDefault()
                  const el = document.getElementById('refs-grp')
                  if (el) { el.open = true; el.scrollIntoView({ behavior: 'smooth', block: 'nearest' }) }
                }}>➜ Open Reference assets</a>
              ) : (
                <a href="#refs" onClick={(e) => {
                  e.preventDefault()
                  const el = document.getElementById('refs-grp')
                  if (el) { el.open = true; el.scrollIntoView({ behavior: 'smooth', block: 'nearest' }) }
                }}>➜ Attach the image{f.workflow === 'fflf' ? 's' : ''} here</a>
              )}
            </div>
          </div>
        ) : null}
        {f.workflow === 'i2v' ? (
          <div className="fwide">
            <label>Start frame<span className="opt">optional</span></label>
            <textarea rows={2} value={f.frameStart} onChange={(e) => set('frameStart', e.target.value)}
              placeholder="e.g. A red bicycle leaning against a sunlit brick wall, morning shadows, shallow depth of field…" />
          </div>
        ) : null}
        {f.workflow === 'l2v' ? (
          <div className="fwide">
            <label>Last frame<span className="opt">optional</span></label>
            <textarea rows={2} value={f.frameEnd} onChange={(e) => set('frameEnd', e.target.value)}
              placeholder="e.g. The open doorway flooded with golden light, dust motes in the beam — the clip must land exactly here…" />
          </div>
        ) : null}
        {f.workflow === 'fflf' ? (
          <>
            <div className="fwide">
              <label>First frame<span className="opt">optional</span></label>
              <textarea rows={2} value={f.frameStart} onChange={(e) => set('frameStart', e.target.value)}
                placeholder="e.g. A closed wooden door at the end of a dark hallway, single practical lamp…" />
            </div>
            <div className="fwide">
              <label>Last frame<span className="opt">optional</span></label>
              <textarea rows={2} value={f.frameEnd} onChange={(e) => set('frameEnd', e.target.value)}
                placeholder="e.g. The same door wide open, golden light flooding the hallway, dust motes in the beam…" />
            </div>
          </>
        ) : null}
        <div className="fwide">
          <label style={{ display: 'flex', gap: 8, fontSize: 10.5, fontWeight: 700, color: 'var(--dim)', textTransform: 'uppercase', letterSpacing: '.7px', marginBottom: 4 }}>
            Idea / scene
            <button type="button" className="qbtn" title="Load a random sample idea" style={{ marginLeft: 6 }} onClick={() => { set('idea', SURPRISE[Math.floor(Math.random() * SURPRISE.length)]); toast('Idea loaded — hit Generate 🎬') }}>🎲</button>
            <span className="count" style={{ marginLeft: 'auto' }} title="Character count — there is no limit">{ideaLen} chars</span>
          </label>
          <textarea rows={10} value={f.idea} onChange={(e) => set('idea', e.target.value)}
            placeholder="e.g. A street baker opens the shutters of a tiny bakery before sunrise and places the first loaf on the counter, steam rising in the cold air…" />

          {(() => {
            const skel = tplSkel
            const toks = phToks
            if (!toks.length && !unusedPh.length) return null
            const hl = (text) => String(text).split(/(\{[^{}\n]{2,120}\})/g).map((p, i) => {
              const m = p.match(/^\{([^{}\n]{2,120})\}$/)
              if (!m) return <span key={i}>{p}</span>
              const v = ((f.ph || {})[m[1]] || '').trim()
              return v
                ? <mark key={i} className="hl-fill" title={'{' + m[1] + '}'}>{v}</mark>
                : <mark key={i} className="hl-tok">{m[1]}</mark>
            })
            return (
              <details className="phbox" open>
                <summary>🧩 Placeholders ({toks.length}) <span className="badge" style={{ marginLeft: 6, background: toks.filter((tk) => (((f.ph || {})[tk] || '').trim())).length === toks.length ? '#14532d' : '#7c2d12', color: toks.filter((tk) => (((f.ph || {})[tk] || '').trim())).length === toks.length ? '#bbf7d0' : '#fed7aa' }}>{toks.filter((tk) => (((f.ph || {})[tk] || '').trim())).length}/{toks.length} filled</span>
                  <button type="button" className="btn tiny" style={{ marginLeft: 8 }} onClick={(e) => {
                    e.preventDefault()
                    const filled = Object.entries(f.ph || {}).filter(([, v]) => v && v.trim()).map(([k]) => k)
                    const un = toks.filter((t) => !filled.includes(t))
                    if (!un.length) { toast('✓ All placeholders already filled'); return }
                    setPhModal({ tokens: un, values: Object.fromEntries(un.map((t) => [t, ''])), busy: true, err: '', autoGen: false }); setPhAll(false)
                    suggestFill(un)
                  }} title="Ask the connected model to propose values for the unfilled placeholders">✨ Suggest</button>
                  <button type="button" className="btn tiny" style={{ marginLeft: 6 }} title="Clear every filled placeholder value" onClick={(e) => {
                    e.preventDefault()
                    const n = Object.entries(f.ph || {}).filter(([, v]) => v && v.trim()).length
                    if (!n) { toast('Nothing to reset — no placeholder values filled'); return }
                    set('ph', {})
                    toast('♻️ Reset — ' + n + ' placeholder value' + (n > 1 ? 's' : '') + ' cleared')
                  }}>♻️ Reset</button>
                </summary>
                <div className="phgrid">
                  {toks.map((tk) => (
                    <div className={'phitem' + (newToks.includes(tk) ? ' phnew' : '')} key={tk}>
                      <label title={tk}>{tk}{newToks.includes(tk) ? <span className="vmeta"> · new</span> : null}</label>
                      <input type="text" value={(f.ph || {})[tk] || ''}
                        onChange={(e) => set('ph', { ...(f.ph || {}), [tk]: e.target.value })}
                        placeholder={(phHint && phHint[tk]) || ('value for ' + tk)} />
                    </div>
                  ))}
                  {unusedPh.map(([k, v]) => (
                    <div className="phitem phunused" key={'unused-' + k}>
                      <label title={k}>{tokenName(k)} <span className="vmeta">no longer in idea</span></label>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <input type="text" value={v} readOnly />
                        <button type="button" className="btn tiny" title="Discard this value" onClick={() => {
                          const n = { ...(f.ph || {}) }; delete n[k]; set('ph', n)
                        }}>✕</button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="skelprev">
                  <div className="splabel" title="amber = unfilled token · cyan = your value">Processed idea</div>
                  <div className="sptext">{hl(f.idea)}</div>
                  {skel ? (
                    <>
                      <div className="splabel" title="the template skeleton with your values substituted">Template skeleton</div>
                      <div className="sptext tall">{hl(skel)}</div>
                    </>
                  ) : null}
                </div>
              </details>
            )
          })()}
        </div>
        <div className="frow">
          <label>Category</label>
          <select value={f.category} onChange={(e) => set('category', e.target.value)}>
            {CATEGORIES.map((c) => c.startsWith('—')
              ? <option key={c} disabled>{c}</option>
              : <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="frow">
          <label>Prompt pack <Q sec="packs" tip="Domain craft appended to the system prompt. Auto matches the picked template's tag, then your category, then the words in your idea — so fashion craft only loads for fashion clips. Guide →" /></label>
          <select value={f.pack || 'auto'} onChange={(e) => set('pack', e.target.value)} title="Craft brain for this generation">
            <option value="auto">🧠 Auto — match template &amp; idea</option>
            {(packs || []).map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
            <option value="none">🚫 Base prompt only</option>
          </select>
        </div>
        <div className="hint" style={{ margin: '0 0 6px' }}>
          {(!f.pack || f.pack === 'auto')
            ? (packRes.chosen.length
                ? '🧠 ' + packRes.chosen.map((p) => p.label).join(' + ') + ' · ' + packRes.why + (activeScene ? ' · scene ' + chain.active + "'s template" : '')
                : '🧠 base prompt only · ' + packRes.why)
            : f.pack === 'none'
              ? '🧠 base prompt only — pack picker set to none'
              : '🧠 ' + (packRes.chosen.map((p) => p.label).join(' + ') || f.pack) + ' — manual pick'}
        </div>
        {fashionPack ? (
          <div className="frow">
            <label>Fashion cam <Q sec="builder" tip="🧍 she performs = locked elegant frame, she creates every reveal (your reference style) · 🎥 camera plays = motivated camera moves per beat. Both keep her in frame." /></label>
            <Chips values={['perform', 'camplay']} value={f.fashCam || 'perform'} onChange={(v) => set('fashCam', v)}
              labels={{ perform: '🧍 she performs', camplay: '🎥 camera plays' }} />
          </div>
        ) : null}
        <div className="frow">
          <label>Visual style</label>
          <select value={f.style} onChange={(e) => set('style', e.target.value)}>
            {STYLES.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div className="frow">
          <label>Palette</label>
          <select value={f.palette} onChange={(e) => set('palette', e.target.value)}>
            {PALETTES.map((pl) => <option key={pl} value={pl}>{PALETTE_LABELS[pl] || pl}</option>)}
          </select>
        </div>
        <div className="frow">
          <label>Extra notes<span className="opt">optional</span></label>
          <input type="text" value={f.extra} onChange={(e) => set('extra', e.target.value)}
            placeholder="e.g. shallow depth of field, lens flares, rain, embers" />
        </div>
        <div className="fcol">
          <label>Template <Q sec="templates" tip="The attached skeleton is injected under your idea — the LLM follows its shot grammar and placeholders. Guide →" /></label>
          <div style={{ display: 'flex', gap: 6 }}>
            <button type="button" className="btn sm" title="Open template picker (Ctrl/⌘+K)" onClick={() => setTplOpen(true)}
              style={{ flex: 1, textAlign: 'left', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {f.template ? '📐 ' + f.template : '📐 Pick a template…'}
            </button>
            {f.template ? <button type="button" className="btn sm" title="Clear template" onClick={() => set('template', '')}>✕</button> : null}
          </div>
          {f.template ? (
            <div className="hint">📐 The template's skeleton is attached under your idea with highlighted placeholders — fill the 🧩 fields and both your idea and the skeleton are processed with your values.
              {(() => {
                const tp = (templates || []).find((x) => x.t === f.template) || {}
                return (
                  <>
                    {(tp.flows || []).length
                      ? <><br />🎼 <b>{tp.flows.length} beat flows</b> — variants and chain scenes rotate through them: {tp.flows.join(' · ')}</>
                      : null}
                    {(tp.vary || []).length
                      ? <><br />🔀 <b>{tp.vary.length} dimensions vary</b> — every variant draws a different option from each pool: {tp.vary.join(' · ')}</>
                      : null}
                  </>
                )
              })()}
            </div>
          ) : (
            <div className="hint">Browse visually by category — the skeleton attaches with 🧩 placeholder fields and a live processed preview.</div>
          )}
        </div>
      </div>
      </details>

      <details className="grp" open>
        <summary><span className="step">2</span> Camera</summary>
        <div className="secbody">
        <div className="frow">
          <label>Structure</label>
          <Chips values={['single', 'auto', 'multi2', 'multi3']} value={f.structure}
            onChange={(v) => { if (f.loop && v !== 'single') { toast('🔁 Loop clips are single-shot — turn Loop off for cuts'); return } set('structure', v) }}
            labels={{ single: 'Single shot', auto: 'Auto cuts', multi2: '2 cuts', multi3: '3 cuts' }} />
        </div>
        <div className="frow">
          <label>Loop</label>
          <div>
            <label className="checkboxrow">
              <input type="checkbox" checked={!!f.loop}
                onChange={(e) => { set('loop', e.target.checked); if (e.target.checked) set('structure', 'single') }} />
              🔁 Seamless loop — final frame matches the first
            </label>
            {f.loop ? (
              <div className="hint">The prompt forces a closed camera path (Orbit 360° is the classic pick) and forbids cuts, fades and end-beats, so the clip loops with no visible seam.</div>
            ) : null}
          </div>
        </div>
        <div className="frow">
          <label>Motion</label>
          <select value={f.camera} onChange={(e) => set('camera', e.target.value)}>
            {CAMERAS.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="frow">
          <label>Amp / speed</label>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <Chips values={['small', 'medium', 'large']} value={f.amp} onChange={(v) => set('amp', v)}
              labels={{ small: 'S', medium: 'M', large: 'L' }} />
            <Chips values={['slow', 'normal', 'fast']} value={f.speed} onChange={(v) => set('speed', v)}
              labels={{ slow: 'Slow', normal: 'Normal', fast: 'Fast' }} />
          </div>
        </div>
        <div className="hint">Locked-off frame? Pick <b>Static shot</b> — H3 drifts unless you say it holds a static shot. Auto = engine picks the best move.</div>
      </div>
      </details>

      <details className="grp" open>
        <summary><span className="step">3</span> Format</summary>
        <div className="secbody">
        <div className="frow">
          <label>Output</label>
          <div className="row" style={{ gridTemplateColumns: '1fr 1fr 1.2fr' }}>
            <select value={f.ratio} onChange={(e) => set('ratio', e.target.value)}>
              {RATIOS.map((r) => <option key={r}>{r}</option>)}
            </select>
            <select value={f.resolution} onChange={(e) => set('resolution', e.target.value)}>
              <option>768P</option><option>2K</option>
            </select>
            <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <input type="range" min="5" max="20" step="1" value={f.duration}
                onChange={(e) => set('duration', +e.target.value)} />
              <span className="rangeval">{f.duration}s</span>
              {tplPin && tplPin !== f.duration ? (
                <button type="button" className="btn tiny"
                  title={'The attached template pins ' + tplPin + 's — match it in one click, or keep your clock: the engine recomputes the template’s own cut times against YOUR runtime either way'}
                  onClick={() => { set('duration', tplPin); toast('⏱ Duration matched to ' + f.template + ' — ' + tplPin + 's per clip') }}>📐 use {tplPin}s</button>
              ) : null}
            </span>
          </div>
        </div>
        <div className="hint">Draft at <b>768P</b> (~$0.08/s), re-roll the winner at <b>2K</b> (~$0.13/s). Current pick: <b>${cost}</b> · 24 fps fixed.
          <br />⏱ <b>CLOCK</b> — {clockText}. The prompt is built against this clock and the audit checks it back: a cut at or past {f.duration}s, a last shot under 1.5s, or a line too long for its shot all get flagged.
          {tplPin && tplPin !== f.duration ? <> This template was written for <b>{tplPin}s</b> — your clock wins, and every one of its example timecodes is recomputed against {f.duration}s.</> : null}</div>
      </div>
      </details>

      <details className="grp" id="refs-grp">
        <summary><span className="step">🖼</span> Reference assets <span className="opt">ref2video · optional</span></summary>
        <div className="secbody">
        <div className="frow ref-add">
          <button type="button" className="btn sm" onClick={() => addRef('image')}>+ Image ({refCount('image')}/9)</button>
          <button type="button" className="btn sm" onClick={() => addRef('video')}>+ Video clip ({refCount('video')}/3)</button>
          <button type="button" className="btn sm" onClick={() => addRef('audio')}>+ Audio ({refCount('audio')}/3)</button>
          {(f.refs || []).some((r) => r.type === 'image') ? (
            <label className="checkboxrow" title="Treat the images as ordered keyframes of one video: the prompt describes the motion between consecutive frames">
              <input type="checkbox" checked={!!f.keyframes} onChange={(e) => set('keyframes', e.target.checked)} />
              🎞️ Sequential keyframes
            </label>
          ) : null}
        </div>
        {(f.refs || []).some((r) => r.type === 'image' && r.thumb) ? (
          <div className="frow">
            <label className="checkboxrow" title="3+ frames are tiled into numbered 384px contact sheets — one request per 3 frames, so the model sees neighbours together and infers the motion between them. 1-2 frames are read individually at 512px. Falls back to your captions for text-only models.">
              <input type="checkbox" checked={!!f.sendRefs} onChange={(e) => set('sendRefs', e.target.checked)} />
              👁️ Read frames with the model — contact sheets of 3, 384px tiles (works with small 9B vision models too)
            </label>
          </div>
        ) : null}
        {(f.refs || []).length === 0 ? (
          <div className="hint">Attach references for Reference-to-Video: up to 9 images + 3 video clips + 3 audio clips (12 total). The prompt will give each one an explicit job — "Use Image 1 for the talent, Image 2 for the mood and location…". For first/last-frame shots, write "first frame" or "last frame" in the job.</div>
        ) : (f.refs || []).map((r, i) => (
          <div className="frow ref-row" key={i}>
            <span className="ref-label">{REF_ICON[r.type]} {refLabel(r, i)}</span>
            {r.thumb ? <img className="ref-thumb" src={r.thumb} alt="" /> : null}
            <input type="text" className="ref-job" value={r.job} onChange={(e) => setRef(i, { job: e.target.value })}
              placeholder={r.type === 'image' ? (f.keyframes ? 'what happens in this frame — action, composition, what changes from the previous frame' : 'its job — e.g. talent face (preserve identity) / product / mood + location / first frame')
                : r.type === 'video' ? 'its job — e.g. motion reference / camera language / sing-along performance'
                : 'its job — e.g. voice to clone / music to sync cuts to'} />
            {r.type === 'image' ? (
              <label className="btn sm ref-attach" title="Attach a local image (preview only, stays on this machine)">
                📎<input type="file" accept="image/*" style={{ display: 'none' }} onChange={(e) => refFile(i, e.target.files && e.target.files[0])} />
              </label>
            ) : null}
            <button type="button" className="btn sm" onClick={() => rmRef(i)} title="Remove">✕</button>
          </div>
        ))}
        {(f.refs || []).length > 0 ? (
          <div className="hint">Jobs flow into the prompt{ (f.refs || []).some((r) => r.thumb) ? ' · previews are session-only (files never leave this machine)' : '' }.</div>
        ) : null}
      </div>
      </details>

      <details className="grp">
        <summary><span className="step">👤</span> Characters <span className="opt">identity bibles · {chars.filter((c) => (c.name || '').trim()).length || 'none'}</span></summary>
        <div className="secbody">
          <div className="hint">Research-backed consistency: identity travels by <b>reference image + 2–3 signature anchors repeated verbatim</b> — prompts describe ONLY action and camera. Cards attach automatically to every generation and chain scene.</div>
          {chars.map((c, i) => (
            <div className="chain-row" key={i}>
              <div className="chain-top">
                <span className="chain-n">{i + 1}</span>
                <input type="text" value={c.name} placeholder="name / role — e.g. Mara, the baker" onChange={(e) => setChar(i, { name: e.target.value })} />
                <button type="button" className="btn tiny" onClick={() => setChars((cs) => cs.filter((_, j) => j !== i))} title="Remove character">✕</button>
              </div>
              <input type="text" value={c.anchors} placeholder="signature anchors (2–3, repeated VERBATIM in every prompt) — e.g. silver undercut, olive field jacket, chipped red nails" onChange={(e) => setChar(i, { anchors: e.target.value })} />
              <div className="row" style={{ gridTemplateColumns: '1fr 1fr', marginTop: 6 }}>
                <input type="text" value={c.attrs} placeholder="attributes (5–7) — age, build, hair, skin, face shape…" onChange={(e) => setChar(i, { attrs: e.target.value })} />
                <input type="text" value={c.wardrobe} placeholder="wardrobe for this film" onChange={(e) => setChar(i, { wardrobe: e.target.value })} />
              </div>
              <input type="text" value={c.voice} placeholder="voice — e.g. low and wry, slight rasp (drives native audio)" onChange={(e) => setChar(i, { voice: e.target.value })} style={{ marginTop: 6 }} />
            </div>
          ))}
          <div className="frow">
            <button type="button" className="btn sm" onClick={() => setChars((cs) => [...cs, { ...CHAR_EMPTY }])}>➕ Add character</button>
            <span className="hint">Attach each character's canonical portrait under 🖼️ Reference assets (job: “{'character identity' || ''}”) — one master image per character, never competing versions.</span>
          </div>
        </div>
      </details>

      <details className="grp">
        <summary><span className="step">🔗</span> Story chain <span className="opt">longer video · scene-to-scene consistency</span></summary>
        <div className="secbody">
          <div className="chain-steps">
            <Q sec="chain" tip="① write the bible once → ②  plan scenes → ③ Direct each scene & Generate (bible + end-state travel automatically) → ④ feed each clip's last frame as the next first frame. Full recipe in Guide →" /> <span className="vmeta">scene-to-scene consistency</span>
          </div>
          <div className="frow">
            <label>⏱ Plan length</label>
            <div className="row" style={{ gridTemplateColumns: '1fr auto auto', alignItems: 'center' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <input type="range" min={15} max={180} step={5} value={planTotal} onChange={(e) => setPlanTotal(+e.target.value)} />
                <span className="rangeval">~{planTotal}s final</span>
              </span>
              <button type="button" className="btn sm primary" disabled={busyPlan} onClick={autoPlan}>
                {busyPlan ? '✨ Planning…' : '✨ Auto-plan chain'}
              </button>
              <button type="button" className="btn sm" onClick={planScenes} title="Just create empty scene slots">
                +{Math.max(1, Math.ceil(Math.max(5, planTotal) / Math.max(5, f.duration)))} slots
              </button>
            </div>
          </div>
          {chain.scenes.length > 1 ? (
            <div className="frow">
              <label>⚡ Batch</label>
              <div className="row" style={{ gridTemplateColumns: 'auto 1fr', alignItems: 'center' }}>
                <button type="button" className="btn sm primary" disabled={busy || chainBusy} onClick={generateChain}>
                  {chainProg ? '⚡ Generating scene ' + chainProg + '/' + chain.scenes.length + '…'
                    : '⚡ Generate all ' + chain.scenes.length + ' scenes'}
                </button>
                <button type="button" className="btn sm" disabled={busy || chainBusy} onClick={toNativeMultishot}
                  title="Convert this chain into ONE LTX-2.5 native multishot prompt (connected shots in a single generation)">
                  🎞️ → native multishot
                </button>
                <span className="hint">⚡ = one prompt per scene (per-scene templates apply) · 🎞️ = the same chain collapsed into ONE LTX-2.5 multishot generation</span>
              </div>
            </div>
          ) : null}
          <div className="hint" style={{ marginTop: -4, marginBottom: 8 }}>
            One line of idea is enough — <b>Auto-plan</b> writes the consistency bible and every scene beat for you
            (LLM when a provider is connected, story-arc engine offline). Everything below stays <b>optional</b>: edit only what you want to override.
            <br />
            <b>Shot budget:</b> one clip carries ≤4 cuts (H3: ≤4 shots/15s; LTX prefers single takes) — so{' '}
            <b>{Math.max(3, Math.ceil(10 / Math.max(1, Math.min(4, Math.round(f.duration / 3)))))}–4 chained clips ≈ 10 shots</b>,
            6+ clips ≈ a 20-shot montage. The selected template stays applied to <i>every</i> scene you Direct; the bible keeps them one film.
          </div>
          <div className="fcol">
            <label>Consistency bible<span className="opt">optional — Auto-plan writes it; edit to override</span></label>
            <textarea rows={3} value={chain.bible} onChange={(e) => setChain((c) => ({ ...c, bible: e.target.value }))}
              placeholder="Character (face, hair, build) · wardrobe · location · lighting · grade · lens language — the details that must NEVER drift between clips" />
          </div>
          {chain.scenes.map((sc, i) => (
            <div className="chain-row" key={i}>
              <div className="chain-top">
                <span className={'chain-n' + (chain.active === i + 1 ? ' on' : '')}>{i + 1}</span>
                <input type="text" value={sc.idea} placeholder={'Scene ' + (i + 1) + ' — optional, auto-planned on Direct'}
                  onChange={(e) => setScene(i, { idea: e.target.value })} />
                <select value={sc.tpl || ''} onChange={(e) => setScene(i, { tpl: e.target.value })}
                  title="Template for this scene only" style={{ width: 'auto', maxWidth: 170, fontSize: 11.5 }}>
                  <option value="">📐 builder's template</option>
                  {(templates || []).filter((t) => !t.p && t.b).map((t) => <option key={t.t} value={t.t}>{t.t}</option>)}
                </select>
                <button type="button" className="btn tiny" disabled={i === 0} onClick={() => moveScene(i, -1)}
                  title="Move this scene one step earlier — the chain runs top to bottom">↑</button>
                <button type="button" className="btn tiny" disabled={i === chain.scenes.length - 1} onClick={() => moveScene(i, 1)}
                  title="Move this scene one step later">↓</button>
                <button type="button" className="btn tiny" onClick={() => directScene(i)} title="Load this scene into the form with chain context">⎗ Direct</button>
                <button type="button" className="btn tiny" onClick={() => rmScene(i)} title="Remove scene">✕</button>
              </div>
              <input type="text" className="chain-end" value={sc.end || ''} placeholder="end state — auto-captured after generation, editable"
                onChange={(e) => setScene(i, { end: e.target.value })} />
            </div>
          ))}
          <div className="frow chain-foot">
            <button type="button" className="btn sm" onClick={addScene}>➕ Add scene</button>
            {chain.scenes.length ? (
              <span className="hint">
                <b>{chain.scenes.length} clip{chain.scenes.length > 1 ? 's' : ''} × {f.duration}s ≈ {chain.scenes.length * f.duration}s of final video.</b>{' '}
                {chain.active >= 1
                  ? 'Directing scene ' + chain.active + '/' + chain.scenes.length + ' — bible + previous end state travel with the prompt. Bridge on the platform: each rendered clip’s LAST FRAME becomes the next scene’s first-frame image (the Direct button arms I2V for you).'
                  : 'Direct each scene in order — each prompt picks up exactly where the last ended.'}{' '}Every scene can carry its OWN template (📐 select per row) — e.g. three different fashion templates for looks 1–3.
              </span>
            ) : (
              <span className="hint">Plan the clip sequence, fill the bible, then Direct each scene in order — each prompt picks up exactly where the last ended.</span>
            )}
          </div>
        </div>
      </details>

      <details className="grp">
        <summary><span className="step">4</span> Sound</summary>
        <div className="secbody">
        <div className="frow">
          <label>Music</label>
          <Chips values={Object.keys(MUSIC)} value={f.music} onChange={(v) => set('music', v)} labels={MUSIC} />
        </div>
        <div className="frow">
          <label>Ambience<span className="opt">optional</span></label>
          <input type="text" value={f.ambience} onChange={(e) => set('ambience', e.target.value)}
            placeholder="e.g. distant traffic, rain on glass, trays clinking" />
        </div>
        <div className="frow">
          <label>Spoken line<span className="opt">optional</span></label>
          <div className="row" style={{ gridTemplateColumns: '2fr 1fr' }}>
            <input type="text" value={f.dialogue} onChange={(e) => set('dialogue', e.target.value)} disabled={!f.dialogueOn}
              placeholder={f.dialogueOn ? 'e.g. First batch of the morning.' : 'dialogue switched OFF in the workflow row'} />
            <select value={f.dlang} onChange={(e) => set('dlang', e.target.value)}>
              {DLANGS.map((l) => <option key={l}>{l}</option>)}
            </select>
          </div>
        </div>
        <div className="frow">
          <label>Foley &amp; cues<span className="opt">native audio</span></label>
          <input type="text" value={f.foley} onChange={(e) => set('foley', e.target.value)}
            placeholder="e.g. boots on gravel, fabric swish on the turn, cup set-down — lands on the matching beats" />
        </div>
        <div className="frow">
          <label>Audio design<span className="opt">native audio</span></label>
          <input type="text" value={f.audioNotes} onChange={(e) => set('audioNotes', e.target.value)}
            placeholder="e.g. music dips under the spoken line · room tone continuous · accent hits with the cut" />
        </div>
        <div className="frow">
          <label>Negation<span className="opt">prose only</span></label>
          <input type="text" value={f.negation} onChange={(e) => set('negation', e.target.value)}
            placeholder="e.g. no soft dissolves or fluid morphs" />
        </div>
      </div>
      </details>

      <details className="grp">
        <summary><span className="step">5</span> Engine<span className="opt">{engNow.line}</span></summary>
        <div className="secbody">
          <div className="engnow">
            <span className="vmeta">Next generation</span>
            <b>{engNow.mode}</b>
            {engNow.model ? <code>{engNow.model}</code> : null}
            <span className="vmeta">· {engNow.chips.join(' · ')} · temp {engNow.temperature}</span>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', marginTop: 9 }}>
            <button type="button" className="btn tiny primary" onClick={() => onOpenSettings && onOpenSettings('engine')}>⚙️ Change in Settings</button>
            <button type="button" className="btn tiny ghost" onClick={() => onOpenSettings && onOpenSettings('provider')}>🤖 Provider &amp; model list</button>
            {f.engine !== 'offline' && conn.status !== 'ok' ? <span className="hint" style={{ margin: 0 }}>⚠️ no provider connected — this run uses the built-in instant engine</span> : null}
          </div>
          <div className="hint" style={{ marginTop: 7 }}>
            The engine, the model, the variant count, temperature and the generation switches now live in
            <b> ⚙️ Settings → 🎛 Engine</b>, beside the provider they depend on. This panel just shows what the
            next generation will use — change it there and it applies here immediately.
          </div>
          <div className="hint enginenote">{engineNote}</div>
          {(() => {
            /* Show, right here, which system prompt the 18+ switch will actually run. */
            const ltx = f.target === 'ltx'
            const mat = ltx ? ltxMature : sysMature
            const file = ltx ? 'prompts/ltx-system-prompt-mature.md' : 'prompts/system-prompt-mature.md'
            const n = ((mat && mat.text) || '').trim().length
            if (nsfwBlocked()) return null
            if (!f.mature) return <div className="hint" style={{ margin: '-2px 0 6px' }}>🛡️ 18+ off — this generation runs <b>prompts/{ltx ? 'ltx-system-prompt.md' : 'system-prompt.md'}</b> (SFW).{' '}
              Build your mature look with that switch in ⚙️ Settings → 🎛 Engine.</div>
            if (!n) return <div className="hint" style={{ margin: '-2px 0 6px', color: 'var(--warn, #e0a14a)' }}>⚠️ 18+ on, but <b>{file}</b> is {(mat && mat.status) === 'fallback' ? 'unreachable' : 'empty'} — the run would fall back to the SFW file. Edit that file and hit ↻ Reload from file in ⚙️ Settings.</div>
            return <div className="hint" style={{ margin: '-2px 0 6px' }}>🔞 18+ on — this generation runs <b>{file}</b> ({n.toLocaleString()} chars{(mat && mat.deps && mat.deps.length) ? ' · 📎 ' + mat.deps.length + ' dependencies' : ' · 📎 0 — no @include in that file'}).</div>
          })()}
        </div>
      </details>

      {(() => {
        const avail = (loras || []).filter((l) => l.model === f.target || l.model === 'both')
        const sel = f.loras || []
        return (
          <details className="grp">
            <summary><span className="step">🧬</span> LoRAs <span className="opt">local ComfyUI runs · {avail.length} for this target · {sel.length} selected</span></summary>
            <div className="secbody">
              <div className="chips">
                {avail.map((l) => (
                  <span key={l.t} className={'chip' + (sel.includes(l.t) ? ' on' : '')} title={l.d}
                    onClick={() => set('loras', sel.includes(l.t) ? sel.filter((x) => x !== l.t) : [...sel, l.t])}>
                    {l.t}
                  </span>
                ))}
              </div>
              <div className="hint">
                <b>What's a LoRA?</b> A small add-on model your <b>local ComfyUI</b> loads next to H3/LTX for a look,
                motion or control. <b>How this tool uses it:</b> a LoRA only fires when its trigger word is IN the prompt —
                so armed LoRAs get their triggers <b>stamped on top of every generated prompt</b> (you'll see the 🧬 line on
                cards), and the strength shown is what to dial in ComfyUI. Rendering on the hosted cloud (no LoRAs there)?
                Use the <b>Platform clean</b> copy. Add more in <code>public/prompts/loras.md</code>.
              </div>
            </div>
          </details>
        )
      })()}

      {(() => {
        const proto = IC_PROTOCOLS.find((p) => p.id === (f.ic || {}).proto)
        const vals = (f.ic || {}).vals || {}
        const setIcVal = (k, v) => setF((p) => ({ ...p, ic: { ...(p.ic || {}), vals: { ...((p.ic || {}).vals || {}), [k]: v } } }))
        const pushIcCard = () => {
          const built = icBuild((f.ic || {}).proto, vals)
          if (!built) { toast(' Fill the protocol fields first'); return }
          const v = {
            title: 'IC · ' + proto.name.split(' —')[0], prompt: built, negative_prompt: proto.neg || '',
            target: 'ltx', engine: 'ic-protocol', secs: '0.0', tags: [proto.id],
          }
          const inp = {
            ratio: f.ratio, duration: f.duration, workflow: f.workflow,
            loras: (f.loras || []).map((t) => (loras || []).find((l) => l.t === t)).filter(Boolean),
          }
          pushCard({ id: 'c' + Math.random().toString(36).slice(2), kind: 'variant', v, inp })
          pushHistory(v, inp, 'ic')
          toast('🎛 IC protocol prompt emitted — copy it into the IC-LoRA ComfyUI workflow')
        }
        return (
          <details className="grp">
            <summary><span className="step">🎛</span> IC-LoRA protocol <span className="opt">LTX-Video · exact prompt contracts · {proto ? proto.name.split(' —')[0] : 'none'}</span></summary>
            <div className="secbody">
              <div className="frow">
                <label>Protocol</label>
                <select value={(f.ic || {}).proto || ''} onChange={(e) => set('ic', { proto: e.target.value, vals: {} })}>
                  <option value="">— none —</option>
                  {IC_PROTOCOLS.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              {proto ? (
                <>
                  <div className="hint">{proto.blurb} · strength {proto.strength}</div>
                  <ul className="icrules">
                    {proto.rules.map((r, i) => <li key={i}>{r}</li>)}
                  </ul>
                  {proto.fields.map((fd) => fd.kind === 'select' ? (
                    <div className="frow" key={fd.k}>
                      <label>{fd.label}</label>
                      <select value={vals[fd.k] || fd.opts[0]} onChange={(e) => setIcVal(fd.k, e.target.value)}>
                        {fd.opts.map((o) => <option key={o}>{o}</option>)}
                      </select>
                    </div>
                  ) : fd.kind === 'area' ? (
                    <div className="fwide" key={fd.k}>
                      <label>{fd.label}</label>
                      <textarea rows={2} value={vals[fd.k] || ''} onChange={(e) => setIcVal(fd.k, e.target.value)} placeholder={fd.ph} />
                    </div>
                  ) : (
                    <div className="frow" key={fd.k}>
                      <label>{fd.label}</label>
                      <input type="text" value={vals[fd.k] || ''} onChange={(e) => setIcVal(fd.k, e.target.value)} placeholder={fd.ph} />
                    </div>
                  ))}
                  <div className="splabel">Assembled protocol prompt — exact contract</div>
                  <pre className="icprev">{icBuild(proto.id, vals) || '…'}</pre>
                  <div className="frow" style={{ alignItems: 'center' }}>
                    <button type="button" className="btn primary sm" onClick={pushIcCard}>🎛 Emit IC prompt card</button>
                    {proto.neg ? <span className="hint">Negative: {proto.neg}</span> : null}
                  </div>
                </>
              ) : (
                <div className="hint">
                  IC-LoRAs (Ingredients, COLORIZE, ENHANCE QUALITY, clean plate, relight, CrossView, depth/pose…) condition on a
                  reference video or control signal in ComfyUI and each demands an EXACT prompt contract — pick one and the builder
                  assembles it field-by-field so you can't drift off-protocol. LTX-only.
                </div>
              )}
            </div>
          </details>
        )
      })()}

      <div className="genbar">
        <button className="btn primary big" title="Ctrl/⌘+Enter" disabled={busy} onClick={generate}>
          {busy ? <><span className="spin"></span> Directing…</> : '🎬 Generate H3 Prompt'}
        </button>
        <div className="hint enginenote">{engineNote}</div>
      </div>

      {phModal ? (
        <div className="modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) setPhModal(null) }}>
          <div className="modal" style={{ width: 'min(600px,100%)' }}>
            <div className="modal-head">
              <h3>🧩 Fill the blanks</h3>
              <span className="vmeta">{phModal.tokens.length} placeholder{phModal.tokens.length > 1 ? 's' : ''} · {conn.model}</span>
              <button type="button" className="btn tiny" style={{ marginLeft: 'auto' }} onClick={() => setPhModal(null)}>✕ Close</button>
            </div>
            <div className="modal-body">
              {phModal.busy ? <div className="hint"><span className="spin"></span> {conn.model} is proposing concrete values…</div> : null}
              {phModal.err ? <div className="hint" style={{ color: '#fca5a5' }}>{phModal.err}</div> : null}
              {(phAll ? phModal.tokens : phModal.tokens.slice(0, 8)).map((t) => (
                <div className="frow" key={t}>
                  <label title={t}>{'{' + tokenName(t) + '}'}{tokenHint(t) ? <span className="vmeta"> {tokenHint(t)}</span> : null}</label>
                  <input type="text" value={phModal.values[t] || ''} placeholder="type a value or keep the suggestion"
                    onChange={(e) => setPhModal((m) => ({ ...m, values: { ...m.values, [t]: e.target.value } }))} />
                </div>
              ))}
              {phModal.tokens.length > 8 ? (
                <button type="button" className="btn tiny ghost" style={{ marginTop: 6 }}
                  onClick={() => setPhAll((v) => !v)}>
                  {phAll ? '▾ Show the first 8 only' : '▸ Show the other ' + (phModal.tokens.length - 8) + ' placeholder' + (phModal.tokens.length - 8 > 1 ? 's' : '')}
                </button>
              ) : null}
              <div className="row" style={{ marginTop: 10, gridTemplateColumns: 'auto auto auto auto 1fr' }}>
                <button className="btn sm" disabled={phModal.busy} onClick={() => { setPhModal((m) => ({ ...m, busy: true, err: '' })); suggestFill(phModal.tokens) }}>🔄 Re-suggest</button>
                {phModal.tokens.some((x) => /OUTFIT|GARMENT|WARDROBE/i.test(x)) ? (
                  <button className="btn sm" disabled={phModal.busy} title="Runs prompts/fashion-outfit-expander.md — one expert garment line, built from your brief"
                    onClick={() => expandOutfit(phModal.tokens)}>👗 Expand outfit</button>
                ) : null}
                <button className="btn sm" onClick={() => {
                  const vals = {}; Object.entries(phModal.values).forEach(([k, v]) => { if (String(v).trim()) vals[k] = String(v).trim() })
                  setF((p) => ({ ...p, ph: { ...(p.ph || {}), ...vals } })); setPhModal(null); toast('🧩 Placeholders filled — Generate when ready')
                }}>💾 Fill only</button>
                <button className="btn sm primary" onClick={() => {
                  const vals = {}; Object.entries(phModal.values).forEach(([k, v]) => { if (String(v).trim()) vals[k] = String(v).trim() })
                  setPhModal(null); generate(Object.keys(vals).length ? { ph: vals } : { invent: true })
                }}>✅ Fill & Generate</button>
                <button className="btn sm" style={{ justifySelf: 'end' }} onClick={() => { setPhModal(null); generate({ invent: true }) }}>🎲 Skip — model invents</button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      <TemplatePickerModal
        open={tplOpen}
        onClose={() => setTplOpen(false)}
        templates={templates}
        userReport={userReport}
        fileNotes={fileNotes}
        current={f.template}
        onUse={(t) => {
          const sw = switchTemplate(f, t)
          setF((pf) => ({ ...pf, ...switchTemplate(pf, t).patch, ...(t.fmt === 'ltx' ? { target: 'ltx' } : {}) }))
          setTplOpen(false)
          toast('📐 ' + t.t + ' attached — ' + (describeSettings(t.settings) || 'no pinned settings') +
            (sw.kept.length ? ' · ' + sw.kept.length + ' 🧩 field(s) kept' : '') +
            (sw.dropped.length ? ' · 🧹 cleared ' + sw.dropped.length + ' field(s) from the previous template: ' + sw.dropped.slice(0, 4).join(', ') + (sw.dropped.length > 4 ? '…' : '') : ''))
        }}
      />

      <MatureModal
        open={gateOpen}
        onCancel={() => setGateOpen(false)}
        onConfirm={() => {
          try { localStorage.setItem('cps_nsfw_consent', '1'); localStorage.setItem('cps_nsfw', 'on') } catch (e) {}
          set('mature', true)
          setGateOpen(false)
          toast('Mature themes enabled (18+)')
        }}
      />
    </div>
  )
}
