import { useEffect, useRef, useState } from 'react'
import { streamChat } from '../lib/ollama.js'
import { providerConfig, streamOpenAIChat } from '../lib/providers.js'
import { parseTemplatesMd } from '../lib/templates.js'
import { copyText, downloadText } from '../lib/format.js'
import { lintTemplate } from '../lib/lint.js'
import { triggerPrefix } from '../lib/loras.js'
import { CATEGORIES } from '../lib/templates.js'
import { loadForge, saveForge, clearForge } from '../lib/persist.js'

const FORGE_FALLBACK = 'You are a template smith. Answer with ONE template block (## Title, meta keys, fenced skeleton). H3 skeletons start with integrated_multimodal_description: and carry `model: h3`; LTX blocks carry `model: ltx` and use prompt:/negative_prompt:/tags: skeletons. 3-6 {PLACEHOLDER} tokens shared by idea and skeleton. If LoRAs are listed, weave their triggers into the skeleton and add a loras: meta line. Output ONLY the block.'

const TAGS = ['fashion', 'ethnic', 'person', 'portrait', 'sports', 'documentary', 'product', 'landscape', 'animation', 'dialogue', 'multi', 'vertical', 'music', 'longvideo', 'mature', 'animal', 'vehicle', 'space', 'food', 'artist', 'beauty', 'mascot', 'cg', 'claymation', 'retro', 'anime', 'toon', 'papercraft', 'minimalist', 'lyric', 'scroll', 'game']

/* Deterministically stamp armed LoRA triggers into a forged skeleton —
   the same contract as the builder's 🧬 Copy w/ triggers. */
/* Guarantee the block carries the chosen target's model: tag — the library uses it
   to file the template under the right format group. LLM output is never trusted here. */
function stampModel(block, target) {
  const lines = String(block).split('\n')
  let fenceIdx = lines.findIndex((l) => l.trim().startsWith('```'))
  if (fenceIdx === -1) fenceIdx = lines.length
  const head = lines.slice(0, fenceIdx).filter((l) => !/^model\s*:/i.test(l.trim()))
  const rest = lines.slice(fenceIdx)
  const titlePos = head.findIndex((l) => /^##\s+/.test(l))
  head.splice(titlePos === -1 ? 0 : titlePos + 1, 0, 'model: ' + target)
  return head.concat(rest).join('\n')
}

function stampLoras(block, selLoras) {
  const p = triggerPrefix(selLoras)
  if (!p) return block
  const lines = block.split('\n')
  for (let i = 0; i < lines.length; i++) {
    if (/^\s*integrated_multimodal_description\s*:/.test(lines[i])) {
      lines[i] = lines[i].replace(/^(\s*integrated_multimodal_description\s*:\s*)/, '$1' + p + ', ')
      return lines.join('\n')
    }
    if (/^\s*prompt\s*:/.test(lines[i])) {
      lines[i] = lines[i].replace(/^(\s*prompt\s*:\s*)/, '$1' + p + ', ')
      return lines.join('\n')
    }
  }
  return block
}

/* 🧪 Linter panel — the same checks as `npm run audit`, shown before the block is saved.
   Advisory only: a failing soft check never blocks saving (the parser decides validity). */
export function LintPanel({ L, compact }) {
  if (!L) return null
  const icon = (lv) => lv === 'ok' ? '✔' : lv === 'warn' ? '✖' : '•'
  const col = (lv) => lv === 'ok' ? 'var(--green)' : lv === 'warn' ? '#fca5a5' : 'var(--dim)'
  return (
    <div style={{ marginTop: compact ? 6 : 10, border: '1px dashed var(--border)', borderRadius: 10, padding: '8px 10px' }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <b style={{ fontSize: 12.5 }}>🧪 Template lint</b>
        <span className="badge" style={{ background: L.warn ? '#7f1d1d' : '#065f46' }}>
          {L.warn ? L.warn + ' to fix · ' + L.score + '/100' : '✅ ' + L.score + '/100'}
        </span>
        <span className="vmeta">{L.tokens.length} placeholders · {L.guided.length} guided {L.flows ? '· 🎼 ' + L.flows : ''}</span>
      </div>
      <div style={{ marginTop: 6, display: 'grid', gap: 3, fontSize: 12 }}>
        {L.checks.map((c, i) => (
          <div key={i} style={{ display: 'flex', gap: 7, alignItems: 'baseline' }}>
            <span style={{ color: col(c.level), width: 12, flex: '0 0 12px' }}>{icon(c.level)}</span>
            <span style={{ color: c.level === 'info' ? 'var(--dim)' : 'var(--text)' }}>{c.label}</span>
            {c.hint ? <span className="vmeta" style={{ fontSize: 11 }}>{c.hint}</span> : null}
          </div>
        ))}
      </div>
    </div>
  )
}

/* Live preview of EXACTLY what attaches to the Input Builder when this template is
   used: idea + skeleton with its 🧩 tokens, test-filled with your own values. */
function BuilderPreview({ t }) {
  const [vals, setVals] = useState({})
  const toks = [...new Set([
    ...((t.b || '').match(/\{[^{}\n]{2,120}\}/g) || []),
    ...((t.idea || '').match(/\{[^{}\n]{2,120}\}/g) || []),
  ])]
  const fill = (text) => String(text).split(/(\{[^{}\n]{2,120}\})/g).map((p, i) => {
    const m = p.match(/^\{([^{}\n]+)\}$/)
    if (!m) return p
    const v = (vals[m[1]] || '').trim()
    return <b key={i} style={{ color: v ? '#67e8f9' : '#fbbf24' }}>{v || p}</b>
  })
  return (
    <div style={{ marginTop: 10, border: '1px dashed var(--border)', borderRadius: 10, padding: 10 }}>
      <div className="splabel" title="exactly what attaches to the Input Builder when you use this template">🔒 Locks into Input Builder — test the 🧩 fields</div>
      {toks.length ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(170px,1fr))', gap: 6, margin: '8px 0' }}>
          {toks.map((tk) => (
            <div key={tk}>
              <label style={{ fontSize: 10 }}>{tk.slice(1, -1)}</label>
              <input type="text" value={vals[tk.slice(1, -1)] || ''} style={{ width: '100%' }}
                onChange={(e) => setVals((v) => ({ ...v, [tk.slice(1, -1)]: e.target.value }))}
                placeholder={'value for ' + tk.slice(1, -1)} />
            </div>
          ))}
        </div>
      ) : <div className="vmeta" style={{ margin: '6px 0' }}>no placeholders — fixed skeleton</div>}
      {t.idea ? <div className="sptext" style={{ marginBottom: 6 }}>{fill(t.idea)}</div> : null}
      <div className="sptext">{fill(t.b)}</div>
    </div>
  )
}

export default function TemplateForge({ conn, toast, onAdd, loras, forgedList, pendingFrom, onPendingConsumed, userTitles, library }) {
  /* Restored once, at mount: switching tabs must never empty this panel. */
  const saved = useRef(loadForge()).current
  const [mode, setMode] = useState(saved.mode || 'describe') // describe | fromPrompt | edit
  const [desc, setDesc] = useState(saved.desc || '')
  const [editRaw, setEditRaw] = useState(saved.editRaw || '')
  const [srcPrompt, setSrcPrompt] = useState(saved.srcPrompt || '')
  const [target, setTarget] = useState(saved.target === 'ltx' ? 'ltx' : 'h3')
  const [tag, setTag] = useState(saved.tag || 'Auto')
  const [category, setCategory] = useState(saved.category || 'Auto')
  const [ratio, setRatio] = useState(saved.ratio || 'Auto')
  const [dur, setDur] = useState(saved.dur || 'Auto')
  const [music, setMusic] = useState(saved.music || 'Auto')
  const [chainOn, setChainOn] = useState(!!saved.chainOn)
  const [chainN, setChainN] = useState(saved.chainN || 4)
  const [selLoras, setSelLoras] = useState(Array.isArray(saved.selLoras) ? saved.selLoras : [])
  const [busy, setBusy] = useState(false)
  const [acc, setAcc] = useState(saved.acc || '')
  const [parsed, setParsed] = useState(saved.parsed || null)
  const [err, setErr] = useState('')
  const [sys, setSys] = useState(saved.sys || '')
  const [kept, setKept] = useState(!!(saved.desc || saved.srcPrompt || saved.acc || saved.editRaw))
  const firstPass = useRef(true)
  /* A live snapshot, so a tab switch mid-flight still lands what was on screen. */
  const snap = useRef({})

  /* Persist on every change — cheap, and it also survives a reload or a crash. */
  const snapshot = { mode, desc, editRaw, srcPrompt, target, tag, category, ratio, dur, music, selLoras, acc, sys, parsed }
  snap.current = snapshot
  useEffect(() => {
    saveForge({ ...snapshot, savedAt: Date.now() })
    if (firstPass.current) firstPass.current = false
    else setKept(false)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, desc, editRaw, srcPrompt, target, tag, category, ratio, dur, music, selLoras, acc, sys, parsed])

  /* Leaving the panel (tab switch, hub switch, unmount) flushes the latest state. */
  useEffect(() => () => { saveForge(snap.current || {}) }, [])

  const connected = conn && conn.status === 'ok'

  /* Templatize / edit hand-offs from output cards and Learn cards */
  useEffect(() => {
    if (!pendingFrom) return
    if (pendingFrom.mode === 'edit') {
      setMode('edit')
      setEditRaw(pendingFrom.raw || '')
    } else {
      setMode('fromPrompt')
      setSrcPrompt(pendingFrom.prompt || '')
      setTarget(pendingFrom.target === 'ltx' ? 'ltx' : 'h3')
    }
    setDesc('')
    setAcc(''); setParsed(null); setErr('')
    onPendingConsumed()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingFrom])

  const editBlocks = mode === 'edit' ? parseTemplatesMd(editRaw) : []

  const availLoras = (loras || []).filter((l) => l.model === target || l.model === 'both')

  async function forge() {
    if (busy) return
    if (mode === 'describe' && !desc.trim()) { toast('✍️ Describe the template first — one sentence is enough'); return }
    if (mode === 'fromPrompt' && !srcPrompt.trim()) { toast('✍️ Paste the finished prompt you want to templatize'); return }
    if (!connected) { toast('⚠ Connect Ollama (or a provider) in ⚙️ Settings — the forge needs a local model'); return }
    setBusy(true); setAcc(''); setParsed(null); setErr('')
    try {
      let sysTxt = sys
      if (!sysTxt) {
        try {
          const r = await fetch('prompts/template-forge.md', { cache: 'no-store' })
          sysTxt = r.ok ? ((await r.text()).trim() || FORGE_FALLBACK) : FORGE_FALLBACK
        } catch (e) { sysTxt = FORGE_FALLBACK }
        setSys(sysTxt)
      }
      let wants
      if (mode === 'fromPrompt') {
        wants = 'MODE B - TEMPLATE FROM A FINISHED PROMPT.\nSource prompt:\n' + srcPrompt.trim() + '\nTARGET: ' + target.toUpperCase()
      } else {
        wants = [
          'Description of the template I need: ' + desc.trim(),
          'TARGET: ' + target.toUpperCase(),
          tag !== 'Auto' ? 'tag: ' + tag : '',
          category !== 'Auto' ? 'category: ' + category : '',
          ratio !== 'Auto' ? 'ratio: ' + ratio : '',
          dur !== 'Auto' ? 'duration: ' + dur : '',
          music !== 'Auto' ? 'music: ' + music : '',
          chainOn ? 'CHAIN RECIPE: this template is meant to run as a chain of linked scenes — include a metadata line `chain: ' + chainN + '` and a `chainrule:` line stating what stays constant (the person, the grade, the lens language) and what changes per scene (location, light, garment, action). Write the skeleton so ONE scene per generation is complete on its own.' : '',
        ].filter(Boolean).join('\n')
      }
      if (selLoras.length) {
        const ls = selLoras.map((t) => {
          const l = (loras || []).find((x) => x.t === t)
          return l ? l.t + ' (trigger: ' + (l.trigger || 'none') + (l.strength ? ', strength ' + l.strength : '') + ')' : t
        })
        wants += '\nLORAS TO INTEGRATE: ' + ls.join(' | ') + ' — weave each trigger into the skeleton exactly as given.'
      }
      const messages = [
        { role: 'system', content: sysTxt },
        { role: 'user', content: wants + '\nReturn only the template block.' },
      ]
      const streamer = conn.provider && conn.provider !== 'ollama'
        ? streamOpenAIChat(providerConfig(conn.provider), conn.model, messages, 0.9, {})
        : streamChat(conn.base, conn.model, messages, 0.9, {})
      let out = ''
      let lastWrite = 0
      for await (const p of streamer) {
        out += p; setAcc(out)
        const now = Date.now()
        if (now - lastWrite > 700) { lastWrite = now; saveForge({ ...snapshot, acc: out, parsed: null, savedAt: now }) }
      }
      let stamped = stampLoras(out, selLoras.map((t) => (loras || []).find((x) => x.t === t)).filter(Boolean))
      stamped = stampModel(stamped, target) /* model: tag = the chip you picked, always */
      setAcc(stamped)
      const blocks = parseTemplatesMd(stamped)
      if (blocks.length) setParsed(blocks[0])
      else setErr('The model answered, but the block did not parse (it needs a fenced skeleton starting with integrated_multimodal_description: for H3 or prompt: for LTX). Tweak and forge again.')
    } catch (e) {
      setErr('Forge failed: ' + String((e && e.message) || e).slice(0, 200) + ' — check the console (CPS groups) for the full exchange.')
    }
    setBusy(false)
  }

  const block = acc.trim()

  return (
    <div className="block forge">
      <h2>🧩 Template Forge <span className="vmeta">your Ollama writes template blocks (.md files in prompts/templates/) — H3 and LTX, with LoRAs</span></h2>
      <div className="hint" style={{ margin: '-4px 0 10px' }}>
        Two directions: <b>describe → template</b>, or send any generated prompt here with <b>🧩 Templatize</b> to turn it into a reusable block.
        Armed LoRAs get their trigger words woven into the skeleton. <b>💾 Add to library</b> saves into this browser (localStorage — survives reloads and restarts);
        for permanent storage, export below and append the blocks to <code>public/prompts/templates/ — just drop a .md file (name yours user-*.md)</code> (app updates never touch that file).
      </div>
      {(forgedList || []).length ? (
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 10, flexWrap: 'wrap' }}>
          <span className="badge" style={{ background: '#1e3a5f' }}>📦 {(forgedList || []).length} forged template{(forgedList || []).length > 1 ? 's' : ''} saved in this browser</span>
          <button className="btn tiny" onClick={() => {
            const raws = (forgedList || []).map((t) => t._raw).filter(Boolean)
            if (!raws.length) { toast('No raw blocks stored — re-forge to capture them'); return }
            const a = document.createElement('a')
            a.href = URL.createObjectURL(new Blob([raws.join('\n\n') + '\n'], { type: 'text/markdown' }))
            a.download = 'forged-templates-all.md'
            a.click()
            toast('⬇️ Exported all forged templates — append them to public/prompts/templates/ — just drop a .md file (name yours user-*.md) to keep them forever')
          }}>⬇️ Export all to .md</button>
          <span className="hint">⚠ clearing browser data removes localStorage saves — export to the .md library to be safe</span>
        </div>
      ) : null}

      <div className="row" style={{ gridTemplateColumns: 'auto auto 1fr', alignItems: 'center', marginBottom: 8 }}>
        <div className="chips">
          <span className={'chip' + (mode === 'describe' ? ' on' : '')} onClick={() => setMode('describe')}>✍️ Describe it</span>
          <span className={'chip' + (mode === 'fromPrompt' ? ' on' : '')} onClick={() => setMode('fromPrompt')}>♻️ From a finished prompt</span>
          {mode === 'edit' ? <span className="chip on">✏️ Edit block</span> : null}
        </div>
        <div className="chips">
          <span className={'chip' + (target === 'h3' ? ' on' : '')} onClick={() => { setTarget('h3'); setAcc(''); setParsed(null); setErr('') }}>🎬 H3 / MiniMax</span>
          <span className={'chip' + (target === 'ltx' ? ' on' : '')} onClick={() => { setTarget('ltx'); setAcc(''); setParsed(null); setErr('') }}>⚡ LTX-Video</span>
        </div>
        <div className="chips" style={{ justifyContent: 'flex-end' }}>
          {kept ? <span className="vmeta" title="Restored from your last session — the Forge keeps its work across tabs and reloads">♻️ kept</span> : null}
          <span className="chip" title="Clear the description, the pasted prompt and the forged output — the saved templates are untouched"
            onClick={() => {
              const had = !!(desc || srcPrompt || acc || editRaw)
              setDesc(''); setSrcPrompt(''); setEditRaw(''); setAcc(''); setParsed(null); setErr(''); setMode('describe')
              clearForge()
              toast(had ? '🗑 Forge cleared — saved templates are untouched' : 'Nothing to clear')
            }}>🗑 Start over</span>
        </div>
      </div>
      <div className="row" style={{ gridTemplateColumns: '1fr', marginBottom: 8 }}>
        <span className="hint">{target === 'h3' ? 'three-field skeleton (integrated_multimodal_description / soundscape / music)' : 'one-paragraph prompt + negative + tags skeleton'} · saved blocks are ALWAYS stamped <code>model: {target}</code> so they file under the right group · switching targets clears stale output and NEVER auto-generates</span>
      </div>

      {mode === 'describe' ? (
        <div className="fcol">
          <label>What should the template be?<span className="opt">genre, subject, platform, vibe — one sentence is enough</span></label>
          <textarea rows={3} value={desc} onChange={(e) => setDesc(e.target.value)}
            placeholder="e.g. A vertical reel template for skincare product reveals — macro texture open, slow spin on a stone pedestal, morning window light, one whispered benefit line" />
        </div>
      ) : mode === 'fromPrompt' ? (
        <div className="fcol">
          <label>Finished prompt to templatize<span className="opt">concrete specifics become placeholders; the craft stays fixed</span></label>
          <textarea rows={6} value={srcPrompt} onChange={(e) => setSrcPrompt(e.target.value)}
            placeholder="Paste a generated prompt (or use 🧩 Templatize on any output card)…" />
        </div>
      ) : (
        <div className="fcol">
          <label>Raw template block<span className="opt">edit freely — it re-parses live; 💾 saves over the same title</span></label>
          <textarea rows={12} style={{ fontFamily: 'ui-monospace,monospace', fontSize: 12 }} value={editRaw} onChange={(e) => setEditRaw(e.target.value)} />
          <div className="hint" style={{ marginTop: 4 }}>
            {editBlocks.length
              ? <>✅ parses as <b>“{editBlocks[0].t}”</b> · {editBlocks[0].fmt === 'ltx' ? '⚡ LTX' : '🎬 H3'} · {(editBlocks[0].idea.match(/\{[^{}\n]{2,120}\}/g) || []).length} placeholders</>
              : '⚠ not a valid block yet — needs ## Title, meta lines and a fenced skeleton (integrated_multimodal_description: or prompt:)'}
          </div>
          {editBlocks.length ? <BuilderPreview t={editBlocks[0]} /> : null}
          <div className="row" style={{ marginTop: 8, gridTemplateColumns: 'auto auto 1fr' }}>
            <button className="btn sm primary" disabled={!editBlocks.length} onClick={() => {
              const t = editBlocks[0]
              onAdd({ ...t, _raw: editRaw })
              toast('💾 “' + t.t + '” saved to this browser — it overrides any template with the same title')
            }}>💾 Save edit</button>
            <button className="btn sm" disabled={!editBlocks.length} onClick={() => {
              const a = document.createElement('a')
              a.href = URL.createObjectURL(new Blob([editRaw + '\n'], { type: 'text/markdown' }))
              a.download = 'template-' + (editBlocks[0] ? editBlocks[0].t : 'edited').toLowerCase().replace(/\W+/g, '-').slice(0, 40) + '.md'
              a.click(); toast('⬇️ Saved as a user-*.md — drop it into public/prompts/templates/ to keep it permanently')
            }}>⬇️ Download block</button>
          </div>
        </div>
      )}

      <div className="row" style={{ gridTemplateColumns: 'repeat(5, 1fr) auto', alignItems: 'end', marginTop: 8 }}>
        <div className="fcol"><label>tag</label>
          <select value={tag} onChange={(e) => setTag(e.target.value)}>
            <option>Auto</option>{TAGS.map((t) => <option key={t}>{t}</option>)}
          </select></div>
        <div className="fcol"><label>category</label>
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            <option>Auto</option>{Object.keys(CATEGORIES).map((c) => <option key={c}>{c}</option>)}
          </select></div>
        <div className="fcol"><label>ratio</label>
          <select value={ratio} onChange={(e) => setRatio(e.target.value)}>
            <option>Auto</option><option>9:16</option><option>16:9</option><option>1:1</option>
          </select></div>
        <div className="fcol"><label>duration</label>
          <select value={dur} onChange={(e) => setDur(e.target.value)}>
            <option>Auto</option>{[5, 6, 8, 10, 12, 15].map((d) => <option key={d}>{d}</option>)}
          </select></div>
        <div className="fcol"><label>music</label>
          <select value={music} onChange={(e) => setMusic(e.target.value)}>
            <option>Auto</option><option>none</option><option>subtle</option><option>full</option><option>beat</option>
          </select></div>
        <div className="fcol"><label>chain recipe</label>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <input type="checkbox" checked={chainOn} onChange={(e) => setChainOn(e.target.checked)} title="Make this a chain recipe: one template that runs as several linked scenes (same person, a new location and look per scene)" />
            {chainOn ? (
              <select value={chainN} onChange={(e) => setChainN(+e.target.value)} title="How many linked scenes">
                {[2, 3, 4, 5, 6, 8].map((n) => <option key={n} value={n}>{n} scenes</option>)}
              </select>
            ) : <span className="vmeta">one clip</span>}
          </div></div>
        <button className="btn primary" disabled={busy || !connected} onClick={forge}>
          {busy ? <><span className="spin"></span> Forging…</> : '🔥 Forge template'}
        </button>
      </div>

      <div className="fwide" style={{ marginTop: 8 }}>
        <label>🧬 Integrate LoRAs<span className="opt">their trigger words get woven into the skeleton ({availLoras.length} for {target === 'h3' ? 'H3' : 'LTX'})</span></label>
        {availLoras.length ? (
          <div className="chips">
            {availLoras.map((l) => (
              <span key={l.t} className={'chip' + (selLoras.includes(l.t) ? ' on' : '')}
                onClick={() => setSelLoras((s) => s.includes(l.t) ? s.filter((x) => x !== l.t) : [...s, l.t])}>
                🧬 {l.t}
              </span>
            ))}
          </div>
        ) : <div className="hint">No LoRAs registered for this target yet — add them in <code>public/prompts/loras.md</code>.</div>}
      </div>
      {!connected ? <div className="hint" style={{ marginTop: 6 }}>⚠ No provider connected — plug Ollama in via ⚙️ Settings to forge.</div> : null}

      {(block || err) ? (
        <div style={{ marginTop: 12 }}>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 6 }}>
            {err ? <span className="badge" style={{ background: '#7f1d1d' }}>⚠ parse problem</span>
              : parsed ? <span className="badge" style={{ background: '#065f46' }}>✅ parser accepts · {parsed.fmt === 'ltx' ? '⚡ LTX' : '🎬 H3'}</span>
              : <span className="badge">streaming…</span>}
            {parsed ? <span className="vmeta">“{parsed.t}” · {parsed.tag} · {parsed.settings.ratio} · {parsed.settings.duration}s · {(parsed.idea.match(/\{[^{}\n]{2,120}\}/g) || []).length} placeholders{selLoras.length ? ' · 🧬 ' + selLoras.length + ' LoRA' + (selLoras.length > 1 ? 's' : '') : ''}</span> : null}
            <span style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
              {parsed ? <button className="btn tiny primary" onClick={() => {
                if (mode !== 'edit' && userTitles && userTitles.has(parsed.t)) { toast('🔒 “' + parsed.t + '” is a USER template — LLM flows never generate or overwrite it. Rename the block or use ✏️ Edit.'); return }
                onAdd({ ...parsed, _raw: block }); toast('💾 “' + parsed.t + '” saved — persisted in this browser (localStorage) and live in 📐 Templates and Learn')
              }}>💾 Add to library</button> : null}
              {block ? <button className="btn tiny" onClick={async () => { await copyText(block); toast('📋 Block copied — paste it into a .md in public/prompts/templates/ (name yours user-*.md)') }}>📋 Copy</button> : null}
              {block ? <button className="btn tiny" onClick={() => {
                const a = document.createElement('a')
                a.href = URL.createObjectURL(new Blob([block + '\n'], { type: 'text/markdown' }))
                a.download = 'user-' + ((parsed && parsed.t) || 'forged').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) + '.md'
                a.click(); toast('⬇️ Saved as a user-*.md — drop it into public/prompts/templates/ to keep it permanently')
              }} title="Downloads as a user-*.md drop-in for public/prompts/templates/ — your file, never overwritten by app updates">⬇️ Save as user-*.md</button> : null}
            </span>
          </div>
          {err ? <div className="hint" style={{ color: '#fca5a5' }}>{err}</div> : null}
          <pre className="forgeprev">{block || '…'}</pre>
          {parsed ? <LintPanel L={lintTemplate(parsed, library || [])} /> : null}
          {parsed ? <BuilderPreview t={parsed} /> : null}
        </div>
      ) : null}
    </div>
  )
}
