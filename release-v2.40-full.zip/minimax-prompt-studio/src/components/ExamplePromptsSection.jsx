import { useState } from 'react'
import { copyText } from '../lib/format.js'

/* Real-world H3 prompts from the community corpus — copy or load into the idea box. */
export default function ExamplePromptsSection({ prompts, source, toast }) {
  const [open, setOpen] = useState(-1)
  if (!prompts || !prompts.length) return null
  return (
    <section className="panel">
      <h2><span className="step">🎬</span> Real H3 prompts <span className="count">{prompts.length} · {source}</span></h2>
      <div className="sub">
        Real-world prompts in the exact three-field contract, curated from the{' '}
        <a href="https://huggingface.co/datasets/ostris/minimax_h3_1k" target="_blank" rel="noopener">ostris/minimax_h3_1k corpus</a>.
        Copy one as a starting point — or load it into the Studio idea with <b>✨ Enhance</b> mode to have the model rewrite it into a fresh perfect-H3 version.
      </div>
      <div className="cards">
        {prompts.map((p, i) => (
          <div className="tpl" key={p.t}>
            <div className="tplhead">
              <span className="t" style={{ margin: 0 }}>{p.t}</span>
              {p.genre ? <span className="badge">{p.genre.slice(0, 48)}</span> : null}
            </div>
            {open === i ? <div className="promptbox" style={{ maxHeight: 220 }}>{p.b}</div> : <div className="d">{(p.b.split('\n')[0] || '').slice(0, 150)}…</div>}
            <div className="tplbtns" style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
              <button className="btn tiny" onClick={() => setOpen(open === i ? -1 : i)}>{open === i ? '▴ Hide' : '▾ Read'}</button>
              <button className="btn tiny" onClick={async () => { await copyText(p.b); toast('Prompt copied') }}>📋 Copy</button>
              <button className="btn tiny" onClick={() => {
                window.dispatchEvent(new CustomEvent('cps-load-idea', { detail: p.b }))
                toast('Loaded into Studio idea — try ✨ Enhance mode to rewrite it fresh')
              }}>⤴ Load as idea</button>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
