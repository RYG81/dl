import { Component } from 'react'

/* 🛟 Error boundary — a crash in one panel must never take the whole app down.
 *
 * Written after a real crash: a component referenced a const declared below it (a
 * temporal-dead-zone error), the production build compiled happily, and the browser showed
 * a blank page with a console trace. An error boundary turns that into a readable card with
 * the message, the component, and a way back — and the rest of the app keeps working.
 *
 * Used twice in App: once around the Studio panels (so a failing panel leaves the output
 * cards and the nav alive) and once around the whole view area (so the shell always paints).
 */
export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { err: null, info: '' }
  }

  static getDerivedStateFromError(err) {
    return { err }
  }

  componentDidCatch(err, info) {
    this.setState({ info: (info && info.componentStack) || '' })
    /* Keep it visible in the console for a bug report, without a logger dependency. */
    try { console.error('[cps] panel crashed:', err, info) } catch (e) {}
    /* Say so in the app's own log ring, when the logger is reachable. */
    try {
      const l = globalThis.__cpsLogger
      if (l && l.error) l.error('ui', 'panel crashed: ' + ((err && err.message) || err))
    } catch (e) {}
  }

  reset = () => this.setState({ err: null, info: '' })

  render() {
    const { err, info } = this.state
    if (!err) return this.props.children
    const msg = (err && err.message) || String(err)
    const where = (info || '').split('\n').map((s) => s.trim()).filter(Boolean).slice(0, 3).join(' → ')
    return (
      <div className="panel" style={{ margin: '10px 0' }}>
        <div className="connbox" style={{ borderColor: 'var(--red, #ef5350)' }}>
          <b style={{ color: 'var(--text)' }}>🛟 {this.props.label || 'This panel'} hit an error — the rest of the app is still running</b>
          <div style={{ marginTop: 6, fontSize: 12.5 }}>
            <div><b>message:</b> <code>{msg}</code></div>
            {where ? <div style={{ color: 'var(--faint)', marginTop: 4 }}><b>where:</b> <code>{where}</code></div> : null}
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
            <button type="button" className="btn tiny primary" onClick={this.reset}>↺ Try again</button>
            <button type="button" className="btn tiny" onClick={() => { try { location.reload() } catch (e) {} }}>⟳ Reload the page</button>
            <button type="button" className="btn tiny ghost" onClick={() => {
              const txt = 'Panel: ' + (this.props.label || 'unknown') + '\nMessage: ' + msg + '\nWhere: ' + where
              try { navigator.clipboard.writeText(txt); (this.props.toast || (() => {}))('📋 Copied the error — paste it to report it') } catch (e) {}
            }}>📋 Copy the error</button>
          </div>
          <div className="hint" style={{ marginTop: 8 }}>
            Nothing you typed is lost — your brief is kept in this browser. A panel error is usually
            one bad line in a component; the rebuilt version of this app fixes the two we found
            (a template card and the templates library) and this card is why you will never get a
            blank screen for one again.
          </div>
        </div>
      </div>
    )
  }
}
