```markdown
## New Room outfit tour — adaptive beats_old

model: h3
tag: fashion
description: Locked-camera room showcase whose beats AND beat order are dynamic.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 8
music: beat
structure: single
camera: Static shot
flows: TOP-DOWN TOUR | REVERSE REVEAL | DETAIL CASCADE | BOOKEND DETAIL | ARRIVAL-HOLD | TWIRL-CENTRE
tip: Dynamic beats + 6 flows.
idea: {MODEL — shoulder-length hair} in {OUTFIT — name the real pieces AND their details: neckline, waist detail, hem length, back, sleeves, print} with {FOOTWEAR} presents it in {ROOM — bright interior with layered depth}: she walks in and tours the garment feature-by-feature.

```
integrated_multimodal_description: Shot on a smartphone, {35mm-equivalent} at f/2.0, vertical 9:16, 30fps, LOCKED handheld at chest height. OPEN is always first: {MODEL} enters from the room's depth. CLOSE is always last: she settles facing the lens. DURATION BUDGET — about one beat per second.

overall_soundscape: bare heel-steps on {FLOOR — tile / rug}, quiet bright room tone{VOICEOVER — optional: her line}.

non_diegetic_music: {breezy minimal groove} at medium tempo.
```

## Any Location outfit tour — adaptive beats all dynamic

model: h3
tag: fashion
description: Locked-camera room showcase whose beats AND beat order are dynamic.
category: Fashion / Lifestyle
ratio: 9:16
resolution: 768P
duration: 8
music: beat
structure: single
camera: Static shot
flows: TOP-DOWN TOUR | REVERSE REVEAL
tip: Dynamic beats.
idea: {MODEL_DESCRIPTION} in {OUTFIT_DETAILED_DESCRIPTION} with {FOOTWEAR_DETAILS} presents it in {LOCATION_DETAILED_DESCRIPTION}.

```
integrated_multimodal_description: Shot on a smartphone, vertical 9:16. OPEN is always first.

overall_soundscape: heel-steps on {FLOOR}.

non_diegetic_music: N/A
```
```
