/* 🧪 Render smoke — compile the REAL JSX and RENDER the components, so a runtime crash
 * (a temporal-dead-zone reference, a self-referencing const, a bad hook order) is caught
 * here instead of in the browser. The build cannot catch these: `vite build` compiles
 * happily with `tagFilters(tAll)` above `const tAll`, and the app dies at first paint.
 * Both of the crashes this test was written for were exactly that shape.
 *
 * How: esbuild (already a Vite dependency) bundles each component with react external,
 * we import the bundle, and render it with react-dom/server under stub props and a minimal
 * browser stub. The point is to execute the render function, not to be a browser.
 *
 *   node scripts/rendersmoke.mjs          → render every component we ship
 *   node scripts/rendersmoke.mjs --json   → machine-readable
 */
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import esbuild from 'esbuild'

/* Minimal, boring props per component: no data, empty arrays, no-op functions.
   A crash here is a code fault, not a data-shape fault. */
export const SMOKE_PROPS = {
  'TemplateCard.jsx': ['default', { t: { t: 'Smoke template', tag: 'fashion', settings: { category: 'Fashion / Lifestyle', duration: 8 }, b: '', idea: '' }, current: false, primaryLabel: 'Use', onPrimary: () => {} }],
  'TemplatePickerModal.jsx': ['default', { open: true, onClose: () => {}, templates: [], userReport: [], fileNotes: [] }],
  'LearnSection.jsx': ['default', {
    templates: [], loras: [], conn: { status: 'ok', models: [], model: 'm' }, toast: () => {},
    sysText: '', ltxText: '', packs: [], onSend: () => {}, sendTip: '', onChain: () => {},
  }],
  'SettingsModal.jsx': ['default', {
    open: true, onClose: () => {}, tab: 'engine', onTab: () => {},
    engSet: { engine: 'auto', variants: '1', temperature: 0.8, detail: true, fewshot: true, enhance: false },
    setEngSet: () => {}, mature: false, setMature: () => {}, critOn: false, setCritOn: () => {},
    conn: { status: 'ok', models: [], model: 'm', provider: 'ollama' }, setModel: () => {}, detect: () => {},
    sysPrompt: { text: '', status: 'ok' }, setSysPrompt: () => {}, sysMature: { text: '', status: 'ok' },
    ltxMature: { text: '', status: 'ok' }, ltxPrompt: { text: '', status: 'ok' },
    sysRoute: {}, setSysRoute: () => {}, sysFiles: {}, sysCustom: null, setSysCustom: () => {}, packs: [],
  }],
  'GuideSection.jsx': ['default', {}],
  'TemplateManager.jsx': ['default', { open: true, onClose: () => {}, toast: () => {} }],
  'MatureModal.jsx': ['default', { open: true, onCancel: () => {}, onAccept: () => {} }],
  'ui.jsx': ['Chips', { values: ['1', '2'], value: '1', onChange: () => {} }],
  /* the boundary renders its children when nothing is wrong — give it one to render */
  'ErrorBoundary.jsx': ['default', { __smokeChildren: true }],
}

function stubBrowser() {
  const store = {}
  globalThis.localStorage = globalThis.localStorage || {
    getItem: (k) => (k in store ? store[k] : null),
    setItem: (k, v) => { store[k] = String(v) },
    removeItem: (k) => { delete store[k] },
    clear: () => { for (const k of Object.keys(store)) delete store[k] },
  }
  globalThis.window = globalThis.window || globalThis
  const noop = () => {}
  globalThis.window.addEventListener = globalThis.window.addEventListener || noop
  globalThis.window.removeEventListener = globalThis.window.removeEventListener || noop
  globalThis.window.dispatchEvent = globalThis.window.dispatchEvent || noop
  globalThis.CustomEvent = globalThis.CustomEvent || class { constructor(t, o) { this.type = t; this.detail = o && o.detail } }
  globalThis.Event = globalThis.Event || class { constructor(t) { this.type = t } }
  globalThis.fetch = globalThis.fetch || (async () => ({ ok: false, status: 404, json: async () => null, text: async () => '' }))
}

/* Bundle ONE component (following its .jsx imports) and render it. */
export async function renderComponent(root, file, [exportName, props]) {
  stubBrowser()
  const src = path.join(root, 'src/components', file)
  const entry = path.join(root, 'src/components', '.smoke-entry.jsx')
  const outfile = path.join(root, 'src/components', '.smoke-bundle.mjs')
  if (!fs.existsSync(src)) return { file, ok: true, skipped: true }
  fs.writeFileSync(entry, "export * as NS from './" + file + "'\n")
  try {
    await esbuild.build({
      entryPoints: [entry], bundle: true, format: 'esm', platform: 'node', target: 'es2022',
      jsx: 'automatic', outfile, external: ['react', 'react-dom', 'react/jsx-runtime'],
      logLevel: 'silent', absWorkingDir: root,
    })
    const mod = await import(pathToFileURL(outfile).href + '?t=' + Date.now())
    const React = (await import('react')).default
    const { renderToString } = await import('react-dom/server')
    const NS = mod.NS || {}
    const Comp = exportName === 'default' ? NS.default : (NS[exportName] || mod[exportName])
    if (typeof Comp !== 'function') return { file, ok: false, err: 'no component found for export "' + exportName + '"' }
    const P = { ...(props || {}) }
    if (P.__smokeChildren) { delete P.__smokeChildren; P.children = React.createElement('div', { id: 'smoke-child' }, 'smoke child') }
    const html = renderToString(React.createElement(Comp, P))
    return { file, ok: true, bytes: html.length }
  } catch (e) {
    const msg = (e && e.message) || String(e)
    return { file, ok: false, err: msg.split('\n')[0] }
  } finally {
    try { fs.unlinkSync(entry) } catch (e) {}
    try { fs.unlinkSync(outfile) } catch (e) {}
  }
}

export async function renderSmoke(root) {
  const out = []
  for (const [file, spec] of Object.entries(SMOKE_PROPS)) out.push(await renderComponent(root, file, spec))
  return out
}

/* CLI */
if (process.argv[1] && /rendersmoke\.mjs$/.test(process.argv[1])) {
  const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..')
  const res = await renderSmoke(root)
  if (process.argv.includes('--json')) console.log(JSON.stringify(res, null, 1))
  else {
    for (const r of res) console.log('  ' + (r.ok ? '✔' : '✘') + ' ' + r.file.padEnd(26) + (r.ok ? (r.skipped ? 'not present' : 'rendered ' + r.bytes + ' chars') : 'CRASH: ' + r.err))
    const bad = res.filter((r) => !r.ok).length
    console.log(bad ? '\n❌ ' + bad + ' component(s) crash on first render' : '\n✅ every component renders')
    process.exit(bad ? 1 : 0)
  }
}
