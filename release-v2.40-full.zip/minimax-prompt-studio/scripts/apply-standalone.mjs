/* Standalone applier — the CLI that ends up as `apply.mjs` inside every patch archive.
 *
 * It is not run from the repo. `npm run make-patch` inlines ziplib.mjs + patchcore.mjs +
 * this file into a single dependency-free script that the receiver runs with
 * `node apply.mjs [--into <project>]` — so a patch can be applied by someone who has never
 * installed the patcher, or has an old copy of it.
 *
 * Import lines below are stripped during bundling (the bundle has one shared preamble).
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

/* These come from the bundle this file is inlined into (patchcore.mjs) — declared here so
   the linter can check this file on its own. */
/* global loadPatch, applyPatch, patchReport, protectListFor, planPatch, sha, DEFAULT_PROTECTED, globToRe, isProtected, hashTree, readZip, writeZip */

const HERE = path.dirname(fileURLToPath(import.meta.url))

function usage(payload) {
  console.log(`CinePrompt Studio — safe patch applier
(this file came inside ${payload})

  node apply.mjs                       apply into the project in the current folder
  node apply.mjs --into ~/cineprompt-studio
  node apply.mjs --list                show what the patch contains, change nothing
  node apply.mjs --dry-run             show what would happen, change nothing
  node apply.mjs --accept-new          also take the new version of files that differ,
                                       saving your current copy under .patch-backup/ first
  node apply.mjs --clean               delete this applier + manifest.json + files/ when done

Nothing is ever deleted from your project. A file of yours is only replaced when it is
byte-identical to the version this patch was built from.`)
}

const argValue = (argv, name) => {
  const i = argv.indexOf(name)
  if (i < 0) return null
  const v = argv[i + 1]
  return v && !v.startsWith('--') ? v : true
}

const selfPath = (() => {
  const rel = path.relative(process.cwd(), path.join(HERE, 'apply.mjs')).replace(/\\/g, '/')
  return rel && !rel.startsWith('..') && !path.isAbsolute(rel) ? rel : path.join(HERE, 'apply.mjs')
})()
const quote = (s) => (/\s/.test(s) ? '"' + s + '"' : s)
const looksLikeProject = (dir) => {
  if (!dir) return false
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'))
    if (pkg && pkg.name === 'cineprompt-studio') return true
  } catch (e) { /* keep looking */ }
  return fs.existsSync(path.join(dir, 'public/prompts/system-prompt.md')) && fs.existsSync(path.join(dir, 'src/App.jsx'))
}

async function main() {
  const argv = process.argv.slice(2)
  if (argv.includes('-h') || argv.includes('--help')) return usage(HERE)

  const payload = (() => {
    const z = argValue(argv, '--zip')
    return typeof z === 'string' ? path.resolve(z) : HERE
  })()
  if (!fs.existsSync(path.join(payload, 'manifest.json')) && payload === HERE) {
    console.error('✖ manifest.json is not next to apply.mjs — unzip the whole archive first, or point at it:')
    console.error('  node apply.mjs --zip /path/to/patch.zip --into /path/to/your/project')
    process.exit(1)
  }

  const intoArg = argValue(argv, '--into')
  const root = (typeof intoArg === 'string' ? path.resolve(intoArg)
    : looksLikeProject(process.cwd()) ? process.cwd()
      : looksLikeProject(HERE) ? HERE
        : null)

  if (argv.includes('--list') || argv.includes('--dry-run')) {
    if (!root) {
      /* listing needs no project at all */
      const { manifest, files } = loadPatch(payload)
      console.log('patch ' + manifest.version + ' · ' + Object.keys(files).length + ' file(s)')
      for (const p of Object.keys(files).sort()) console.log('  ' + (manifest.files && manifest.files[p] ? '~' : '+') + ' ' + p)
      return
    }
    const res = await applyPatch(payload, { root, dryRun: true, quiet: true })
    console.log(patchReport({ version: res.manifest.version, actions: res.actions, notes: res.manifest.notes, root, cmd: 'node ' + quote(selfPath) + ' --accept-new --into ' + quote(root) }))
    console.log('(dry run — nothing was written)')
    return
  }

  if (!root) {
    console.error('✖ could not tell which project to patch. Run it from inside your project, or name the folder:')
    console.error('')
    console.error('    node ' + quote(selfPath) + ' --into /path/to/cineprompt-studio')
    console.error('')
    process.exit(1)
  }

  const res = await applyPatch(payload, {
    root,
    quiet: argv.includes('--quiet'),
    acceptNew: argv.includes('--accept-new'),
    dryRun: false,
    cmd: 'node ' + quote(selfPath) + ' --accept-new --into ' + quote(root),
  })

  if (argv.includes('--clean')) {
    const man = res.manifest
    const stray = fs.existsSync(path.join(HERE, 'files'))
      ? fs.readdirSync(path.join(HERE, 'files'), { recursive: true }).filter((n) => fs.statSync(path.join(HERE, 'files', n)).isFile())
      : []
    if (stray.some((n) => !man.files || !(String(n).replace(/\\/g, '/') in man.files))) {
      console.log('· left the scaffolding alone: files/ holds something this patch did not put there')
    } else {
      const removed = []
      for (const n of ['apply.mjs', 'manifest.json', 'files']) {
        const abs = path.join(HERE, n)
        if (fs.existsSync(abs)) { fs.rmSync(abs, { recursive: true, force: true }); removed.push(n) }
      }
      console.log('· cleaned up: ' + removed.join(', '))
    }
  } else {
    console.log('· the applier can tidy itself away when you are done:  node ' + quote(selfPath) + ' --clean')
  }
}

await main()
