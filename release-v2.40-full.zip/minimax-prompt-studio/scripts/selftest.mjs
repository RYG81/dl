/* Self-test — run with `npm run selftest`.
   Three suites, no dependencies, no server needed:
     1 · H3 compliance   — official prompt contract per workflow mode + Ref2VA round-trip
     2 · Template hygiene — every template lints clean, flows declared, pacing contract present
     3 · Pack routing     — tag / category / idea keywords resolve the expected domain packs
*/
import { readFileSync, readdirSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

import { buildUserMessage, buildUserMessageLtx, alignmentLine, liveClock } from '../src/lib/prompts.js'
import { finalizeOutput } from '../src/lib/ollama.js'
import { fullPromptText } from '../src/lib/format.js'
import { scoreH3 } from '../src/lib/scoring.js'
import { splitDims, FORM_DIMS } from '../src/lib/formdims.js'
import { pickEnvelopeFor } from '../src/lib/duration.js'
import { lintTemplate, similarity, tokensOf, guidanceOf } from '../src/lib/lint.js'
import { ENGINE_DEFAULTS, ENGINE_MODES, ENGINE_OPTIONS, engineSummary, loadEngineSettings, saveEngineSettings, loadMature, saveMature } from '../src/lib/enginesettings.js'
import { TAG_LABELS, tagLabel, groupOf, tagFilters, misgroups } from '../src/lib/tags.js'
import { renderSmoke } from './rendersmoke.mjs'
import { parseTemplatesMd, templateToMd, switchTemplate, describeSettings, loadTemplates, listTemplateFiles, listTemplateSources, templateDiagnostics } from '../src/lib/templates.js'
import { fillText, normalizePhValues } from '../src/lib/tokens.js'
import { parsePackMd, resolvePacks, packBlock } from '../src/lib/packs.js'
import { parseLorasMd } from '../src/lib/loras.js'
import { genVariantOffline, genVariantLtxOffline, wardrobeLine, modelLine, scrubDirectives } from '../src/lib/offline.js'
import { checkH3, checkLtx, contractLine, H3_MAX_SECS } from '../src/lib/contracts.js'
import { resolveIncludes } from '../src/lib/sysfiles.js'
import { planPatch, patchReport, globToRe, isProtected, DEFAULT_PROTECTED, applyPatch, buildStandalone, MATURE_EXCLUDES, importersOf } from './patch.mjs'
import { spawnSync } from 'node:child_process'
import { writeZip, readZip, crc32 } from './ziplib.mjs'
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync as rf, existsSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { tmpdir } from 'node:os'
import { chooseBase, composeSystem, promptReport, slotOf, promptSetLabel } from '../src/lib/syscompose.js'
import { matureRouting, looksMature, MATURE_RE } from '../src/lib/maturegate.js'
import { stackSentence, bridalPieces } from '../src/lib/colourbank.js'
import { womenOnlyCast, CAST_LOCK, DETAIL_DENSITY } from '../src/lib/prompts.js'
import { shotClock, clockLineH3, clockLineLtx, fmtTC, timecodes, runtimeStated, speechWords, pickEnvelope, ENVELOPES, MIN_SHOT } from '../src/lib/duration.js'
import { motionPlan, motionPlanText, garmentFamily, presentationKind, MOTION_FAMILIES } from '../src/lib/choreography.js'
import { scanTemplates, templateIndex, templateFolders } from './templatescan.mjs'
import { templateUrl, withFileMeta, folderOf, isUserTemplate } from '../src/lib/templatepaths.js'
/* Namespace-linked (v2.15): the suite must still run, and say why, when the src/lib/filler.js in
   this project is an older copy — the same rule the app itself now follows. */
import * as fillerNs from '../src/lib/filler.js'
const createFiller = fillerNs.createFiller
const colourTokensOf = fillerNs.colourTokensOf || ((tokens) => (tokens || []).filter((t) => /colou?r|fabric|garment|outfit|dress/i.test(t)))
const rotationBrief = fillerNs.rotationBrief || (() => '')
const COLOUR_STEP = Number.isFinite(fillerNs.COLOUR_STEP) ? fillerNs.COLOUR_STEP : 5
const forgetColourWheel = fillerNs.forgetColourWheel || (() => {})
const COLOUR_MEMORY_KEY = fillerNs.COLOUR_MEMORY_KEY || 'cps_colour_wheel'
/* true unless this install carries an older filler.js — the pins that prove the wheel REMEMBERS
   are then skipped with a note instead of failing, because the file, not the build, is behind. */
const FILLER_CURRENT = typeof fillerNs.readColourMemory === 'function' && typeof fillerNs.writeColourMemory === 'function'
import { COLOUR_FAMILIES, FAMILY_COUNT, familyAt, namedColourOf, WHITE_WORDS, COLOUR_NAMES, isPaleLed } from '../src/lib/colourbank.js'
import { colourbankBridge, fillerBridge, openColourWheel } from '../src/lib/colourlink.js'
import * as fillerMod from '../src/lib/filler.js'
import * as colourbankMod from '../src/lib/colourbank.js'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const read = (p) => readFileSync(join(ROOT, p), 'utf8')

let fails = 0
const t = (name, cond) => { console.log((cond ? '  ✔ ' : '  ✘ ') + name); if (!cond) fails++ }
/* Same for pins that assert the SHIPPED filler.js is the current one: they are a statement about
   our file, so an install carrying an older copy reports the skip rather than a failure (v2.15). */
const tF = (name, cond) => FILLER_CURRENT
  ? t(name, cond)
  : console.log('  ◦ ' + name + ' — skipped: your src/lib/filler.js is older than this build (take the .new beside it)')

/* A pin about the wheel remembering is a statement about OUR filler.js: when the project carries
   an older copy of it, say so and skip instead of failing the whole suite (v2.15). */
const tW = (name, cond) => FILLER_CURRENT
  ? t(name, cond)
  : console.log('  ◦ ' + name + ' — skipped: your src/lib/filler.js is older than this build (take the .new beside it)')
const H = (s) => console.log('\n' + s)
/* The owner is allowed to replace a mature system prompt with their own file. When they do, the
   checks that describe the SHIPPED 18+ prompts are skipped (and say so) instead of failing — they
   are a statement about our files, not about a working install. */
const OWN_MATURE = ['public/prompts/system-prompt-mature.md', 'public/prompts/ltx-system-prompt-mature.md']
const isOurs = (p) => /^@include /m.test(read(p))
const ownMature = () => OWN_MATURE.filter((p) => !isOurs(p))
const tM = (name, cond, files = OWN_MATURE) => {
  const mine = ownMature().filter((p) => files.includes(p))
  if (!mine.length) return t(name, cond)
  console.log('  ◦ ' + name + ' — skipped: you own ' + mine.map((p) => p.replace('public/prompts/', '')).join(' + '))
}

/* ---------- 1 · H3 compliance ---------- */
H('1 · H3 official prompt contract')
const base = { category: 'Auto', idea: 'a woman walks through a market at dusk', duration: 8, structure: 'multi3', target: 'h3', refs: [{ type: 'image', job: 'identity' }, { type: 'video', job: 'camera' }] }

for (const wf of ['t2v', 'i2v', 'fflf', 'l2v', 'multiref', 'a2v']) {
  const msg = buildUserMessage({ ...base, workflow: wf })
  const keyframe = wf === 'i2v' || wf === 'fflf' || wf === 'l2v'
  t(wf + ': instruction line ' + (keyframe ? 'demanded' : 'not demanded'), /OUTPUT STARTS WITH THIS EXACT/.test(msg) === keyframe)
  if (wf === 'multiref') {
    t('multiref: six sections named', ['subject_definitions', 'summary', 'retention_analysis', 'detailed_description'].every((k) => msg.includes(k)))
    t('multiref: task-type prefixes listed', msg.includes('[keyframe completion]') && msg.includes('[audio reference]'))
    t('multiref: retention markers listed', msg.includes('attribute_transfer') && msg.includes('partially_copy'))
    t('multiref: session refs mapped to labels', msg.includes('image1') && msg.includes('video2'))
    t('multiref: three-field tail replaced', !/overall_soundscape: <synchronized diegetic audio>/.test(msg))
  } else {
    t(wf + ': three-field tail present', msg.includes('non_diegetic_music: <1-3 sentences'))
  }
}
t('l2v: last-frame box fed to the model', buildUserMessage({ ...base, workflow: 'l2v', frameEnd: 'the open doorway flooded with golden light' }).includes('the open doorway flooded with golden light'))
const d = buildUserMessage({ ...base, workflow: 't2v', dialogueOn: true, dialogue: 'I get off at the next station.', dlang: 'English' })
t('dialogue: <d>[Language] markup taught', d.includes('<d>[English] I get off at the next station.</d>'))
t('dialogue: scenetrans / cutoff rules', d.includes('<scenetrans>') && d.includes('<cutoff>'))
const ltx = buildUserMessageLtx({ ...base, workflow: 't2v', dialogueOn: true, dialogue: 'Two sugars, please.', dlang: 'English' })
t('LTX keeps plain verbatim quotes', ltx.includes('"Two sugars, please."') && !ltx.includes('<d>'))
t('alignmentLine: i2v exact wording', alignmentLine({ workflow: 'i2v' }) === 'For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.')
t('alignmentLine: duration to two decimals + final shot', alignmentLine({ workflow: 'l2v', duration: 8, structure: 'multi3' }).includes('8.00-second mark') && alignmentLine({ workflow: 'l2v', duration: 8, structure: 'multi3' }).includes('[Shot 3]'))

const refAnswer = 'How the reference pictures align with the target video — <Picture 1> (from [Shot 1]) aligns with the 8.00-second mark of the target video.\n\nsubject_definitions: <Subject 1> is the woman from <Picture 1>.\nsummary: [reference generation + audio reuse] She crosses the market.\nretention_analysis: <Subject 1> (appears in [Shot 1]): fully_preserved - face kept.\ndetailed_description: Warm dusk palette, practicals, wet stone. [Shot 1] She steps into frame.\noverall_soundscape: Market chatter and a scooter.\nnon_diegetic_music: N/A'
const v = { ...finalizeOutput(refAnswer, 'h3'), target: 'h3' }
t('parse: Ref2VA detected, sections filled', v.refMode === true && ['subject_definitions', 'summary', 'retention_analysis', 'detailed_description', 'overall_soundscape', 'non_diegetic_music'].every((k) => v[k]))
t('parse: detailed_description aliased for the base flows', !!v.integrated_multimodal_description)
const copy = fullPromptText(v)
t('copy: alignment line is the first line', copy.startsWith('How the reference pictures align with the target video'))
t('copy: six sections in official order', (() => { const o = ['subject_definitions:', 'summary:', 'retention_analysis:', 'detailed_description:', 'overall_soundscape:', 'non_diegetic_music:'].map((k) => copy.indexOf(k)); return o.every((x, i) => x >= 0 && (i === 0 || x > o[i - 1])) })())
const i2v = finalizeOutput('For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.\n\nintegrated_multimodal_description: [Shot 1] Cinematic live-action.\noverall_soundscape: Rain.\nnon_diegetic_music: N/A', 'h3')
t('copy: i2v keeps the official line above the fields', fullPromptText({ ...i2v, target: 'h3' }).startsWith('For the target video, at 0.00 seconds'))
t('ref audit: scores the six-section card', scoreH3({ ...v, alignment: 'For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.' }, { duration: 8 }).ref === true)

/* ---------- 2 · template hygiene ---------- */
H('2 · Template hygiene')
const coreMd = read('public/prompts/templates/core.md')
const blocks = coreMd.split(/\n(?=## )/).filter((s) => /^## /.test(s)).map((s) => {
  const meta = {}
  for (const m of s.split('```')[0].matchAll(/^([a-z]+):\s*(.*)$/gmi)) meta[m[1].toLowerCase()] = m[2].trim()
  return {
    t: s.match(/^## (.+)$/m)[1].trim(),
    b: (s.match(/```\n([\s\S]*?)```/) || [])[1] || '',
    idea: meta.idea || '',
    fmt: meta.model === 'ltx' ? 'ltx' : 'h3',
    tag: meta.tag || '',
    p: meta.tag === 'preset',   /* presets carry settings, not a skeleton — lintTemplate early-returns */
    flows: meta.flows ? meta.flows.split('|').map((x) => x.trim()).filter(Boolean) : null,
    vary: meta.vary ? meta.vary.split('|').map((x) => x.trim().toUpperCase()).filter(Boolean) : null,
    chain: /^\d+$/.test(String(meta.chain || '').trim()) ? Math.max(2, Math.min(12, parseInt(meta.chain, 10))) : undefined,
    chainRule: meta.chainrule ? meta.chainrule.trim() : undefined,
    category: meta.category || '',
    duration: meta.duration || '',
    settings: { structure: meta.structure || '', resolution: meta.resolution || '' },
  }
})
console.log('  blocks: ' + blocks.length + ' · dynamic: ' + blocks.filter((x) => x.flows).length)
const warnAll = []
let maxSim = 0
for (const b of blocks) {
  const L = lintTemplate(b, blocks)
  for (const c of L.checks) if (c.level === 'warn') warnAll.push(b.t + ' → ' + c.label)
}
for (let i = 0; i < blocks.length; i++) for (let j = i + 1; j < blocks.length; j++) maxSim = Math.max(maxSim, similarity(blocks[i].b, blocks[j].b))
t('no pacing gap (every block declares TIMING / budget)', !warnAll.some((w) => /Pacing contract/.test(w)))
t('no >120-char invisible placeholders', !warnAll.some((w) => /longer than 120/.test(w)) || warnAll.filter((w) => /longer than 120/.test(w)).length === 1)
t('near-duplicate warning threshold never trips (max sim ' + maxSim.toFixed(2) + ' < 0.72)', maxSim < 0.72)
if (warnAll.length) console.log('  advisory warnings: ' + warnAll.join(' | '))

/* ---------- 3 · pack routing ---------- */
H('3 · Pack routing')
const packDir = join(ROOT, 'public/prompts/packs/')
const packs = readdirSync(packDir).filter((f) => f.endsWith('.md') && f !== 'README.md').map((f) => parsePackMd(readFileSync(packDir + f, 'utf8'), f))
console.log('  packs: ' + packs.length)
const cases = [
  ['fashion tag', { tag: 'fashion', category: 'Fashion / Lifestyle', idea: 'a model walks' }, ['fashion']],
  ['ethnic tag + sari idea', { tag: 'ethnic', category: 'Fashion / Lifestyle', idea: 'a bride in a sari and lehenga' }, ['ethnic']],
  ['ugc tag', { tag: 'ugc', category: 'Social Media Content', idea: 'a creator films a testimonial' }, ['ugc']],
  ['papercraft', { tag: 'papercraft', category: 'Animation', idea: 'a cut-paper model of the water cycle' }, ['animation']],
  ['minimalist', { tag: 'minimalist', category: 'Product Showcase', idea: 'a watch on a seamless grey backdrop' }, ['product']],
  ['lyric', { tag: 'lyric', category: 'Music Video', idea: 'a singer performs the chorus' }, ['music']],
  ['scroll', { tag: 'scroll', category: 'Cinematic Film Scene', idea: 'a chalk drawing runs along a wall' }, ['cinematic']],
  ['game', { tag: 'game', category: 'Animation', idea: 'a co-op dungeon title screen' }, ['animation']],
  ['base only', { tag: 'person', category: 'Multi-Shot Sequence', idea: 'three beats with no domain keywords' }, []],
]
for (const [label, inp, want] of cases) {
  const r = resolvePacks(packs, inp)
  const ids = r.chosen.map((p) => p.id)
  t(label + ' → ' + (ids.join(' + ') || 'base only'), want.every((w) => ids.includes(w)) && (want.length ? true : ids.length === 0))
}

/* ---------- 4b · the linter catches the classic forge mistakes ---------- */
H('4b · Linter catches the classic bad-block mistakes')
const BAD = {
  t: 'Titanic Drawing Scene',
  fmt: 'h3',
  settings: { structure: 'single', duration: 8 },
  idea: '{ARTIST} sketches {SUBJECT} wearing only {JEWELRY} in {SETTING} using {MEDIUM}, capturing {POSE}.',
  b: `integrated_multimodal_description: [Shot 1] opens on {ARTIST} seated at a worn wooden easel in {SETTING}, warm amber lamplight pooling on {SUBJECT} reclining on crushed velvet, {JEWELRY} glinting at her throat. Camera pushes in slow 15% over 3s, settling on {ARTIST}'s hand guiding {MEDIUM} across paper. At 00:04.000 focus racks to the rendered curve of {JEWELRY} on the page, then back to {SUBJECT}'s eyes holding the gaze. At 00:07.000 {ARTIST} lowers {MEDIUM}, the drawing complete, silence stretching.

overall_soundscape: Scratch of {MEDIUM} on paper, ship's distant engine hum, {SUBJECT}'s shallow breathing, {ARTIST}'s quiet "Hold still."

non_diegetic_music: Subtle strings swelling at 00:03.000, solo piano motif at 00:06.000, fading with final stroke.`,
}
const BL = lintTemplate(BAD, [])
const blabels = BL.checks.filter((c) => c.level === 'warn').map((c) => c.label).join(' | ')
t('dialogue in soundscape flagged', /Dialogue written into overall_soundscape/.test(blabels))
t('music timestamps flagged', /Timestamps in non_diegetic_music/.test(blabels))
t('timecodes without [Shot N] flagged', /Timecodes without \[Shot N\]/.test(blabels))
t('single-take with cuts flagged', /Declared single-take but 2 cuts/.test(blabels))
t('missing pacing contract flagged', /Pacing contract/.test(blabels))
t('no medium declaration hinted', BL.checks.some((c) => /No medium \/ camera declaration/.test(c.label)))
const clean = lintTemplate(blocks.find((x) => x.t.startsWith('\uD83C\uDFA8 Artist & muse')), blocks)
t('the replacement template is clean (0 warnings)', clean.checks.filter((c) => c.level === 'warn').length === 0)

/* ---------- 4 · length policy (no caps anywhere) ---------- */
H('4 · Length policy — nothing is capped')
const longDesc = 'A wide anamorphic street at dawn with practical sodium bleed and wet asphalt reflections. ' + '[Shot 1] The courier steps off the kerb and the camera trucks with her, rain beading on the lens as she crosses into the market. '.repeat(60)
const longV = { integrated_multimodal_description: longDesc, overall_soundscape: 'Rain on the awning. A scooter passes.', non_diegetic_music: 'N/A' }
const longS = scoreH3(longV, { duration: 8 })
t('an ' + longDesc.length.toLocaleString() + '-char description still scores (no ceiling)', longS.pct > 0 && longS.checks.length > 0)
t('no check label mentions the old 7,000-char cap', !longS.checks.some((c) => /7,000|7000/.test(c[1])))
t('no check label caps word count', !longS.checks.some((c) => /keep under 1,?500|under 1,?500/.test(c[1])))
const longRef = { ...v, detailed_description: longDesc + ' ' + longDesc }
const longRefS = scoreH3({ ...longRef, alignment: 'For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.' }, { duration: 8 })
t('Ref2VA long body passes (floor only, no ceiling)', longRefS.pct > 0 && !longRefS.checks.some((c) => /7,000|7000/.test(c[1])))
for (const p of ['public/prompts/system-prompt.md', 'public/prompts/system-prompt-mature.md']) {
  const s = read(p)
  tM(p.replace('public/prompts/', '') + ': states the no-limit rule', /no character or word limit/.test(s), [p])
  t(p.replace('public/prompts/', '') + ': no 7,000-char cap stated', !/7,?000/.test(s))
}
t('fallbacks carry the no-limit clause', (read('src/lib/prompts.js').match(/no length limit/g) || []).length >= 2)
t('ollama stream disables the output cap (num_predict: -1)', /num_predict: -1/.test(read('src/lib/ollama.js')))
t('linter has no skeleton ceiling', !/4200/.test(read('src/lib/lint.js')))
t('chain hand-off is not truncated', !/slice\(0, 300\)/.test(read('src/lib/format.js')))
t('UI shows a plain char count, no "/ 7000"', !/\/ 7000/.test(read('src/components/StudioForm.jsx')))

/* ---------- 5 · persistence (tab switches must not empty anything) ---------- */
H('5 · Persistence — nothing empties on a tab switch')
const store = new Map()
globalThis.localStorage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: (k) => store.delete(k),
}
const P = await import('../src/lib/persist.js')
t('readLS falls back when empty', P.readLS('none', { a: 1 }).a === 1)
P.writeLS('x', { b: 2 })
t('writeLS/readLS round-trip', P.readLS('x', null).b === 2)
store.set('broken', '{not json')
t('corrupt JSON never throws (falls back)', P.readLS('broken', 'safe') === 'safe')
P.saveForge({ mode: 'fromPrompt', desc: 'skincare reel', srcPrompt: 'PASTED', acc: '## Title', target: 'h3', tag: 'beauty', parsed: { t: 'X' }, busy: true, err: 'no' })
const fb = P.loadForge()
t('forge: description + pasted prompt + output all restored', fb.desc === 'skincare reel' && fb.srcPrompt === 'PASTED' && fb.acc === '## Title')
t('forge: parsed block restored (save button stays live)', !!fb.parsed)
t('forge: transient state (busy/err) not persisted', fb.busy === undefined && fb.err === undefined)
t('forge: only whitelisted keys stored', Object.keys(JSON.parse(store.get(P.FORGE_KEY))).every((k) => P.FORGE_FIELDS.includes(k)))
const strict = globalThis.localStorage.setItem
globalThis.localStorage.setItem = () => { throw new Error('QuotaExceeded') }
let threw = false
try { P.saveForge({ desc: 'x' }) } catch (e) { threw = true }
globalThis.localStorage.setItem = strict
t('storage failure can never break the app', !threw)
const studioSrc = read('src/components/StudioForm.jsx')
const camSrc = read('src/components/CameraDirector.jsx')
const forgeSrc = read('src/components/TemplateForge.jsx')
t('builder form restores + persists', /readLS\(FORM_KEY/.test(studioSrc) && /writeLS\(FORM_KEY, slimForm\(f\)\)/.test(studioSrc))
t('builder thumbnails stay out of storage', /thumb: ''/.test(studioSrc))
t('18+ consent never restores itself', /cps_nsfw'\) !== 'on'/.test(studioSrc))
t('camera shot list restores + persists', /readLS\('cps_cam_kfs_v1'/.test(camSrc) && /writeLS\('cps_cam_kfs_v1'/.test(camSrc))
t('forge flushes on unmount', /saveForge\(snap\.current \|\| \{\}\)/.test(forgeSrc))
t('forge writes while streaming (throttled)', /lastWrite > 700/.test(forgeSrc))
t('forge has a deliberate start-over', /Start over/.test(forgeSrc))

/* ---------- 6 · token cap (the "max_tokens must be positive" 400) ---------- */
H('6 · Token cap — positive ladder, automatic retry')
{
  const store6 = new Map()
  globalThis.localStorage = {
    getItem: (k) => (store6.has(k) ? store6.get(k) : null),
    setItem: (k, v) => store6.set(k, String(v)),
    removeItem: (k) => store6.delete(k),
  }
  const quiet = { log: console.log.bind(console) }
  console.log = (...a) => {}
  const O = await import('../src/lib/ollama.js')
  console.log = quiet.log
  const reply = (obj, status = 200) => Object.assign({
    ok: status < 400, status,
    text: async () => JSON.stringify(obj),
    json: async () => obj,
    clone() { return reply(obj, status) },
  }, status < 400 ? {
    body: new ReadableStream({
      start(c) {
        const enc = new TextEncoder()
        c.enqueue(enc.encode(JSON.stringify({ message: { content: 'ok' }, done: false }) + '\n'))
        c.enqueue(enc.encode(JSON.stringify({ done: true, done_reason: 'stop' }) + '\n'))
        c.close()
      },
    }),
  } : {})
  const REJECT = { error: 'max_tokens must be positive, got: -1 (ref: ab0d09af)' }
  let sent = []
  const run = async (responder) => {
    sent = []
    globalThis.fetch = async (url, init) => { const s = JSON.parse(init.body); sent.push(s); return responder(s) }
    console.log = (...a) => {}
    let out = ''
    try {
      for await (const p of O.streamChat('/ollama', 'qwen2.5:7b', [{ role: 'user', content: 'x' }], 0.8, { json: true })) out += p
    } finally {
      console.log = quiet.log   /* never leave assertions muted, even when the call throws */
    }
    return out
  }
  const caps = () => sent.map((c) => (c.options && 'num_predict' in c.options ? c.options.num_predict : 'omitted'))
  const noNegatives = () => caps().every((c) => c === 'omitted' || c > 0)

  store6.clear()
  t('positive cap sent by default (never -1)', (await run(() => reply({}))) === 'ok' && sent[0].options.num_predict === O.PREDICT_LADDER[0] && noNegatives())
  store6.clear()
  t('server rejecting the big cap: retried to 4096 on the same call', (await run((s) => (s.options.num_predict > 4096 ? reply(REJECT, 400) : reply({}))) === 'ok') && caps().join(' → ') === '16384 → 4096')
  t('the working cap is remembered for next time', O.predictMode() === 4096)
  store6.clear()
  t('cap-hostile server: ladder ends in "omit" and still succeeds', (await run((s) => ('num_predict' in s.options ? reply(REJECT, 400) : reply({}))) === 'ok') && caps().join(' → ') === '16384 → 4096 → 2048 → omitted')
  t('mode remembered as omit', O.predictMode() === 'omit')
  store6.clear()
  let msg = ''
  try { await run(() => reply({ error: 'model "nope" not found' }, 400)) } catch (e) { msg = e.message }
  t('an unrelated 400 still surfaces (not swallowed)', /not found/.test(msg) && sent.length === 1)
  t('an unrelated 400 does not change the stored mode', O.predictMode() === O.PREDICT_LADDER[0])
}

/* ---------- 7 · everything-varies (🔀 vary: dimensions) ---------- */
H('7 · Everything-varies templates (🔀)')
{
  const DIMS = ['OUTFIT DESIGN', 'OUTFIT COLOUR', 'MODEL', 'MOVEMENT', 'PRESENTATION', 'ACTION', 'OUTFIT INTERACTION', 'LOCATION', 'CAMERA']
  const varied = blocks.filter((x) => x.vary && x.vary.length)
  t('templates declaring vary: ' + varied.length, varied.length >= 8)
  for (const b of varied) {
    const L = lintTemplate(b, blocks)
    const warns = L.checks.filter((c) => c.level === 'warn').map((c) => c.label)
    const dead = L.checks.find((c) => /varying dimensions/.test(c.label) && c.level === 'warn')
    const cls = splitDims(b.vary)
    t('🔀 ' + b.t.slice(0, 34) + ' — ' + b.vary.length + ' dims (' + cls.content.length + ' content + ' + cls.form.length + ' form), 4 flows, no warnings',
      b.vary.length >= 7 && (b.flows || []).length === 4 && !warns.length && !dead && /TIMING:/.test(b.b) &&
      cls.content.every((d) => DIMS.includes(d)) && cls.form.every((d) => FORM_DIMS.includes(d)))
  }
  const pools = read('public/prompts/fashion-variation.md')
  t('pools file covers every dimension any template varies — content pools and form pools alike',
    [...DIMS, ...FORM_DIMS].every((d) => !varied.some((b) => b.vary.includes(d)) || new RegExp('^## ' + d + '$', 'm').test(pools)))
  t('a template does declare the new MOVEMENT dimension', varied.some((b) => b.vary.includes('MOVEMENT')))
  const room8 = blocks.find((b) => /^Room photo shoot/.test(b.t))
  t('the room-shoot template is the everything-dynamic one: 17 dimensions, all live', !!room8 && room8.vary.length === 17 &&
    DIMS.every((d) => room8.vary.includes(d)) && DIMS.every((d) => new RegExp('\\{' + d.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).test(room8.b)))
  t('pools carry multiple options per dimension', DIMS.every((d) => {
    const sec = pools.split(new RegExp('^## ' + d + '$', 'm'))[1] || ''
    const body = sec.split(/^## /m)[0]
    return (body.match(/^\d+\. /gm) || []).length >= 4
  }))
  const tp = blocks.find((x) => x.t === 'Editorial fashion film')
  const msg = (k) => buildUserMessage({ category: 'Fashion / Lifestyle', idea: 'a model in a long coat', duration: 10, structure: 'multi3', target: 'h3', workflow: 't2v', templateVary: tp.vary, variantIndex: k, variantTotal: 3, templateFlows: tp.flows })
  const m1 = msg(1), m2 = msg(2)
  t('variant 1 knows it is 1 of 3', /variant 1 of 3/.test(m1))
  t('each variant owns a different pool option', /option #1/.test(m1) && /option #2/.test(m2))
  t('repeating another variant is forbidden', /Do NOT reuse their outfit silhouette/.test(m2))
  t('the contract lists every dimension that template varies, form axes included', tp.vary.every((d) => m1.includes(d)) && tp.vary.length === 17 && tp.vary.includes('OUTFIT COLOUR') && tp.vary.includes('RHYTHM ENVELOPE'))
  t('the contract states the clone rule in the model\u2019s own instructions', /NEVER SHARE AXES/.test(m1) && /may never share an edit signature/.test(m1) && /FORM vs CONTENT/.test(m1))
  t('a non-varying template gets no contract', !/VARIATION CONTRACT/.test(buildUserMessage({ category: 'Fashion / Lifestyle', idea: 'x', duration: 6, structure: 'single', target: 'h3', workflow: 't2v' })))
  const studio = read('src/components/StudioForm.jsx')
  t('pools are loaded on demand (external md, not inlined)', /prompts\/fashion-variation\.md/.test(studio) && /variationPools/.test(studio))
  t('pools ride in as system craft for varying templates', /VARIATION POOLS — draw this variant/.test(studio))
  t('card shows the 🔀 pill', /🔀 \{t\.vary\.length\} vary/.test(read('src/components/TemplateCard.jsx')))
}

/* ---------- 8 · System-prompt dependencies + detail doctrine + women-only fashion ---------- */
H('8 · System-prompt dependencies, detail density, women-only fashion cast')
{
  /* --- @include resolution (pure, no network: a fake file tree) --- */
  const tree = {
    'prompts/system-prompt.md': 'BASE RULES\n@include packs/fashion.md\n@include packs/missing.md\nTAIL LINE\n@include packs/loop.md\n@include packs/uses-root.md',
    'prompts/packs/fashion.md': 'FASHION CRAFT\n[[include: ../shared/tokens.md]]',
    'prompts/shared/tokens.md': 'SHARED TOKENS',
    'prompts/packs/loop.md': 'LOOP BODY\n@include loop.md',
    'prompts/packs/deep1.md': '@include packs/deep2.md',
    'prompts/packs/deep2.md': '@include packs/deep3.md',
    'prompts/packs/deep3.md': '@include packs/deep4.md',
    'prompts/packs/deep4.md': '@include packs/deep5.md',
    'prompts/packs/deep5.md': '@include packs/deep6.md',
    'prompts/packs/deep6.md': 'TOO DEEP',
    'prompts/packs/uses-root.md': 'ROOT RELATIVE\n@include packs/extra.md',
    'prompts/packs/extra.md': 'EXTRA CONTENT',
  }
  const rd = (p) => { if (!(p in tree)) throw new Error('missing'); return tree[p] }
  const r = await resolveIncludes(tree['prompts/system-prompt.md'], 'prompts/system-prompt.md', rd)
  t('@include inlines a sibling file', r.text.includes('FASHION CRAFT'))
  t('@include nests ([[include: …]] inside an included file)', r.text.includes('SHARED TOKENS'))
  t('relative paths resolve against the including file', r.deps.includes('prompts/shared/tokens.md') && r.deps.includes('prompts/packs/fashion.md'))
  t('a missing dependency is reported, not fatal', r.missing.some((m) => m.path === 'prompts/packs/missing.md') && r.text.includes('BASE RULES') && r.text.includes('TAIL LINE'))
  t('a circular include is refused', r.cycles.includes('prompts/packs/loop.md') && r.text.includes('circular'))
  t('a nested file can include by root-relative path', r.text.includes('EXTRA CONTENT') && r.deps.includes('prompts/packs/extra.md'))
  t('the rest of the prompt still loads after a refusal', r.text.includes('── included: prompts/packs/fashion.md ──'))
  const deep = await resolveIncludes('@include packs/deep1.md', 'prompts/x.md', rd)
  t('nesting is depth-capped (no runaway)', deep.missing.length >= 1)
  const real = await resolveIncludes(read('public/prompts/system-prompt.md'), 'prompts/system-prompt.md', (p) => { const q = 'public/' + p; try { return read(q) } catch (e) { throw new Error('missing ' + p) } })
  t('the shipped system prompt resolves with zero missing dependencies', real.missing.length === 0 && real.cycles.length === 0)
  t('the shipped system prompt is one complete document', real.text.includes('FASHION, BEAUTY & ETHNIC CAST — WOMEN ONLY'))
  t('SettingsModal surfaces dependencies', /depPanel/.test(read('src/components/SettingsModal.jsx')) && /resolveIncludes/.test(read('src/components/SettingsModal.jsx')))
  t('App resolves includes for every system prompt', /resolveIncludes\(/.test(read('src/App.jsx')))
  t('every generation logs the dependencies it inlined', /📎 dependencies: /.test(read('src/components/StudioForm.jsx')))
  /* One-line notes: a note written as a single-line HTML comment used to make the resolver
     chew on the same line forever (v2.9). It is stripped, and the line carries on. */
  const oneLine = await resolveIncludes('keep me <!-- drop me --> and me <!-- x --> too', 'prompts/x.md', (pp) => { throw new Error('no ' + pp) })
  t('a one-line HTML comment is stripped, not re-scanned forever', oneLine.text === 'keep me  and me  too')
  const noteThenInclude = await resolveIncludes('<!-- my note -->\n@include packs/extra.md\n', 'prompts/x.md', rd)
  t('an include on the next line still resolves after a one-line note', noteThenInclude.deps.includes('prompts/packs/extra.md') && !/my note/.test(noteThenInclude.text))
  const multiComment = await resolveIncludes('a\n<!--\nnote line\n-->\nb', 'prompts/x.md', (pp) => { throw new Error('no ' + pp) })
  t('a multi-line comment block is still stripped whole', !/note line|<!--|-->/.test(multiComment.text) && /^a\n+\n?b$/.test(multiComment.text.trim()))

  /* --- detail doctrine in all four system prompts + both fallbacks --- */
  const spFiles = ['public/prompts/system-prompt.md', 'public/prompts/system-prompt-mature.md', 'public/prompts/ltx-system-prompt.md', 'public/prompts/ltx-system-prompt-mature.md']
  const spRead = (p) => read('public/' + p)
  const resolved = {}
  for (const p of spFiles) resolved[p] = (await resolveIncludes(spRead(p.replace('public/', '')), p.replace('public/', ''), spRead))
  tM('all four system prompts ship as a real dependency consumer (@include shared/…)', spFiles.every((p) => /^@include shared\/craft-detail-and-cast\.md$/m.test(read(p))))
  t('the doctrine lives in ONE file, not four copies', spFiles.every((p) => !/^- LOCATION DETAIL:/m.test(read(p))) && /^- LOCATION DETAIL:/m.test(read('public/prompts/shared/craft-detail-and-cast.md')))
  tM('all four system prompts resolve to the LOCATION / SUBJECT / OUTFIT doctrine', spFiles.every((p) => { const x = resolved[p].text; return x.includes('LOCATION DETAIL') && x.includes('SUBJECT DETAIL') && x.includes('OUTFIT DETAIL') && x.includes('MORE DETAIL = MORE CONSISTENCY') }))
  tM('all four system prompts resolve to the women-only cast rule', spFiles.every((p) => resolved[p].text.includes('CAST — WOMEN ONLY')))
  const isMature = (p) => /mature/.test(p)
  tM('every prompt resolves the shared doctrine file', spFiles.every((p) => resolved[p].deps.includes('prompts/shared/craft-detail-and-cast.md')))
  tM('the mature prompts depend on mature-craft + the user addendum', spFiles.filter(isMature).every((p) => resolved[p].deps.length === 3 && resolved[p].deps.includes('prompts/shared/mature-craft.md') && resolved[p].deps.includes('prompts/mature-addendum.md')))
  tM('the mature craft lives in ONE file shared by both targets', /Content policy — mature is permitted/.test(read('public/prompts/shared/mature-craft.md')) && spFiles.filter(isMature).every((p) => !/^### Mature themes/m.test(read(p))))
  t('SFW prompts never pull in the mature craft', spFiles.filter((p) => !isMature(p)).every((p) => !resolved[p].deps.includes('prompts/shared/mature-craft.md') && !/Content policy — mature is permitted/.test(resolved[p].text)))
  tM('the policy pointer sits at the top of both mature files', spFiles.filter(isMature).every((p) => /^Content policy \(18\+ build\): adult themes are PERMITTED/.test(read(p))))
  t('the shipped mature prompts resolve with zero cycles and zero missing', spFiles.filter((p) => /mature/.test(p)).every((p) => resolved[p].cycles.length === 0 && resolved[p].missing.length === 0))
  t('the addendum\'s own instructions stay out of the prompt', spFiles.filter((p) => /mature/.test(p)).every((p) => !/Write whatever you want in the space below/.test(resolved[p].text)))
  /* the official-skill logic, applied to mature */
  const mc = read('public/prompts/shared/mature-craft.md')
  t('mature craft keeps the official speech/markup split', /<d>\[Language\]/.test(mc) && /\(S1\)/.test(mc) && /<scenetrans>/.test(mc) && /<cutoff>/.test(mc))
  t('non-verbal sound is routed to the soundscape, never into <d>', /NON-VERBAL human sound/.test(mc) && /Never wrap it in `?<d>`?/.test(mc))
  t('the voiceover phrase is exact', /says in an off-screen voiceover/.test(mc) && /lips remain completely closed/.test(mc))
  t('sound budgets match the official spec', /1–4 sentences/.test(mc) && /1–3 sentences/.test(mc) && /exactly N\/A/.test(mc))
  t('mature craft refuses to loosen the grammar', /never its craft/.test(mc) && /apply unchanged/.test(mc))
  t('mature craft carries the continuity + resolution rules', /Continuity across a mature series/.test(mc) && /resolution, not upscaling/.test(mc))
  tM('both mature prompts receive the whole mature craft when resolved', spFiles.filter(isMature).every((p) => /NON-VERBAL human sound/.test(resolved[p].text) && /FICTIONAL ADULT/.test(resolved[p].text)))
  /* drift guard: SFW and mature must not diverge on shared sections */
  const SEC = (txt) => {
    const out = {}; let cur = 'HEAD'
    for (const ln of txt.split('\n')) { const m = /^#{2,3} (.+)$/.exec(ln); if (m) cur = m[1].trim(); out[cur] = (out[cur] || '') + ln + '\n' }
    return out
  }
  for (const [sfw, mat, label] of [['public/prompts/system-prompt.md', 'public/prompts/system-prompt-mature.md', 'H3'], ['public/prompts/ltx-system-prompt.md', 'public/prompts/ltx-system-prompt-mature.md', 'LTX']]) {
    const A = SEC(read(sfw)), B = SEC(read(mat))
    const sharedKeys = Object.keys(A).filter((k) => k in B && k !== 'HEAD')
    const drifted = sharedKeys.filter((k) => A[k].replace(/@include[^\n]*/g, '') !== B[k].replace(/@include[^\n]*/g, ''))
    if (!isOurs(mat)) console.log('  ◦ ' + label + ': SFW/mature drift — skipped: you own ' + mat.replace('public/prompts/', ''))
    else t(label + ': SFW and mature share ' + sharedKeys.length + ' sections, all identical (no drift)', drifted.length === 0)
  }
  t('the mature-only files never reach an SFW prompt', spFiles.filter((p) => !isMature(p)).every((p) =>
    !resolved[p].deps.includes('prompts/shared/mature-craft.md') && !resolved[p].deps.includes('prompts/mature-addendum.md')))
  t('the SFW prompts carry the shared doctrine + the on-camera speech rule', spFiles.filter((p) => !isMature(p)).every((p) =>
    resolved[p].deps.includes('prompts/shared/craft-detail-and-cast.md') && resolved[p].deps.includes('prompts/shared/on-camera-speech.md')))
  tM('the addendum body reaches the mature prompt in place', spFiles.filter(isMature).every((p) => /Mature treatment — house addendum/.test(resolved[p].text)) && spFiles.filter((p) => !isMature(p)).every((p) => !/Mature treatment — house addendum/.test(resolved[p].text)))
  t('the addendum file documents how it is wired', /@include mature-addendum\.md/.test(read('public/prompts/mature-addendum.md')))
  t('Settings shows a row per prompt file incl. the 18+ ones', /H3 · 18\+/.test(read('src/components/SettingsModal.jsx')) && /sysMature/.test(read('src/components/SettingsModal.jsx')))
  t('the guide documents the mature include path', /For 18\+ work specifically/.test(read('src/components/GuideSection.jsx')))
  const { SYS_FALLBACK, LTX_SYS_FALLBACK } = await import('../src/lib/prompts.js')
  t('both inline fallbacks push the same detail standard', [SYS_FALLBACK, LTX_SYS_FALLBACK].every((s) => /never leave a location, a subject or an outfit as a category word/.test(s)))
  t('both inline fallbacks carry the women-only cast rule', [SYS_FALLBACK, LTX_SYS_FALLBACK].every((s) => /always a woman/.test(s)))
  t('the forge teaches both rules to new templates', /women-only rule is also injected at generation time/.test(read('public/prompts/template-forge.md')) && /DETAIL/i.test(read('public/prompts/template-forge.md')))
  t('the guide documents both rules', /Detail is the consistency engine/.test(read('src/components/GuideSection.jsx')) && /Fashion is cast with women only/.test(read('src/components/GuideSection.jsx')))
  t('the guide no longer claims num_predict is -1', !/num_predict: -1` is sent/.test(read('src/components/GuideSection.jsx')))

  /* --- cast lock + detail density actually reach the model --- */
  const fash = buildUserMessage({ ...base, category: 'Fashion / Lifestyle', workflow: 't2v' })
  t('H3 fashion request carries the cast lock', fash.includes('CAST LOCK - WOMEN ONLY'))
  t('H3 fashion request carries the detail-density contract', fash.includes('DETAIL DENSITY'))
  const cinematic = buildUserMessage({ ...base, category: 'Cinematic Film Scene', idea: 'a man smokes in a bedroom', workflow: 't2v' })
  t('non-fashion request is not cast-locked', !cinematic.includes('CAST LOCK - WOMEN ONLY'))
  t('non-fashion request still gets detail density', cinematic.includes('DETAIL DENSITY'))
  const ideaOnly = buildUserMessage({ ...base, category: 'Auto', idea: 'a woman models a silk saree for a bridal lookbook', workflow: 't2v' })
  t('a fashion idea with category Auto is still locked', ideaOnly.includes('CAST LOCK - WOMEN ONLY'))
  const ltxF = buildUserMessageLtx({ ...base, category: 'Fashion / Lifestyle', templateTag: 'fashion', workflow: 't2v' }, 1, 1)
  t('LTX fashion request carries the cast lock', ltxF.includes('CAST LOCK - WOMEN ONLY'))
  const ltxC = buildUserMessageLtx({ ...base, category: 'Nature / Landscape', workflow: 't2v' }, 1, 1)
  t('LTX non-fashion request is not cast-locked', !ltxC.includes('CAST LOCK - WOMEN ONLY'))
  t('womenOnlyCast detects by template tag alone', womenOnlyCast({ category: 'Auto', templateTag: 'beauty' }) && !womenOnlyCast({ category: 'Auto', idea: 'a lighthouse in a storm' }))

  /* --- library: no male casting anywhere in fashion, pools all women --- */
  const masculine = /\b(man|men|male|males|boy|boys|guy|guys|groom|grooms|gentleman|husband|fianc[eé]|sherwani|dude)\b/i
  const strips = (s) => s.replace(/boyfriend\s+(jeans|blazer|shirt|coat|cardigan|sweater)/gi, ' ')
  const fashionish = (b) => /fashion|lifestyle|beaut|styling|lookbook|ootd|ethnic|bridal|jewel|garment|apparel|model|hair|makeup|swim|athleisure|streetwear/i.test((b.category || '') + ' ' + (b.tag || '') + ' ' + b.t)
  const bad = blocks.filter((b) => fashionish(b) && masculine.test(strips(b.b || '')))
  t('no fashion / beauty / ethnic template mentions a man (' + blocks.filter(fashionish).length + ' checked)', bad.length === 0)
  const poolMd = read('public/prompts/fashion-variation.md')
  const models = poolMd.split('## MODEL')[1].split(/^## /m)[0]
  t('the MODEL pool is all women', !masculine.test(strips(models)) && /woman/i.test(models))
  t('the ethnic pack no longer routes menswear keywords', !/groom|sherwani/.test(read('public/prompts/packs/ethnic.md').split('hint:')[0]))

  /* --- linter catches a regression --- */
  const synth = { t: 'Synthetic fashion block', tag: 'fashion', category: 'Fashion / Lifestyle', prompt: '', b: 'integrated_multimodal_description: Shot on a 50mm, 24fps. [Shot 1] A man in a linen shirt turns toward the window. TIMING: 5s total — one beat.', flows: null }
  const L = lintTemplate(synth, null)
  const cast = L.checks.find((c) => /Fashion cast/.test(c.label))
  t('linter warns when a fashion block casts a man', !!cast && cast.level === 'warn')
  const L2 = lintTemplate({ ...synth, b: 'integrated_multimodal_description: Shot on a 50mm, 24fps. [Shot 1] A woman in boyfriend jeans turns toward the window. TIMING: 5s total — one beat.' }, null)
  const cast2 = L2.checks.find((c) => /Fashion cast/.test(c.label))
  t('linter passes "boyfriend jeans" (a garment, not a person)', !!cast2 && cast2.level === 'ok')
}

/* ---------- 9 · System-prompt composition: the base can never be displaced ---------- */
H('9 · Mature prompt survives packs (composition invariants)')
{
  const sfw = { text: 'SFW BASE RULES', status: 'ok' }
  const mat = { text: 'MATURE BASE RULES', status: 'ok' }
  const matLtx = { text: 'MATURE LTX RULES', status: 'ok' }

  const a = chooseBase({ isLtx: false, matureOn: true, sfw, mature: mat })
  t('18+ run uses the mature file as its base', a.used === 'mature' && a.file === 'system-prompt-mature.md' && a.text === 'MATURE BASE RULES' && !a.fellBack)
  const b = chooseBase({ isLtx: true, matureOn: true, sfw, mature: matLtx })
  t('LTX 18+ run uses the LTX mature file', b.used === 'mature' && b.file === 'ltx-system-prompt-mature.md')
  const c = chooseBase({ isLtx: false, matureOn: true, sfw, mature: { text: '', status: 'fallback' } })
  t('a missing mature file is a REPORTED fallback, never silent', c.fellBack && c.used === 'sfw-fallback' && /unreachable/.test(c.reason) && c.text === 'SFW BASE RULES')
  const d = chooseBase({ isLtx: false, matureOn: true, sfw, mature: { text: '   ', status: 'ok' } })
  t('an empty mature file is reported too', d.fellBack && /empty/.test(d.reason))
  const e = chooseBase({ isLtx: false, matureOn: false, sfw, mature: mat })
  t('a non-mature run is never marked as a fallback', !e.fellBack && e.used === 'sfw' && e.text === 'SFW BASE RULES')

  const comp = composeSystem({ base: mat.text, blocks: [{ label: '📦 fashion', text: '\n\n# DOMAIN CRAFT — fashion\nFABRIC' }, { label: '🔀 pools', text: '\n\nPOOLS' }] })
  t('craft is appended after the base, in order', comp.text === 'MATURE BASE RULES\n\n# DOMAIN CRAFT — fashion\nFABRIC\n\nPOOLS')
  t('the base is byte-identical at the front (baseIntact)', comp.baseIntact && comp.text.startsWith(mat.text) && comp.baseChars === mat.text.length)
  t('applied blocks are reported with sizes', comp.applied.length === 2 && comp.applied[0].label === '📦 fashion' && comp.applied[1].chars === 7)
  t('empty blocks are skipped, base still intact', composeSystem({ base: 'X', blocks: [{ label: 'n', text: '   ' }] }).baseIntact && composeSystem({ base: 'X', blocks: [] }).text === 'X')
  const rep = promptReport({ file: 'system-prompt-mature.md', used: 'mature' }, comp)
  const wantTail = 'system-prompt-mature.md (' + comp.baseChars + ' chars) + ' + comp.applied.map((x) => x.label + ' +' + x.chars).join(' + ') + ' = ' + comp.chars + ' chars'
  t('the report names the file actually used + every block', rep.endsWith(wantTail) && /^🔞 mature file /.test(rep))

  /* real library: mature prompt + every pack in the app must keep the mature base */
  const spRead = (p) => read('public/' + p)
  const sysMat = await resolveIncludes(spRead('prompts/system-prompt-mature.md'), 'prompts/system-prompt-mature.md', spRead)
  const packFiles = readdirSync(join(ROOT, 'public/prompts/packs')).filter((x) => x.endsWith('.md') && !/^README|^_/.test(x))
  let allIntact = true, addendumKept = true
  for (const pf of packFiles) {
    const p = parsePackMd(read('public/prompts/packs/' + pf), pf)
    for (const mode of ['perform', 'camplay']) {
      const blk = packBlock(p, mode)
      const out = composeSystem({ base: sysMat.text, blocks: [{ label: '📦 ' + p.id, text: blk }] })
      if (!out.baseIntact || !out.text.startsWith(sysMat.text)) allIntact = false
      if (!/Mature treatment — house addendum/.test(out.text)) addendumKept = false
    }
  }
  t('mature base survives all ' + packFiles.length + ' packs × 2 modes', allIntact)
  tM('the mature-only addendum is still in the composed prompt with packs', addendumKept)
  t('no pack can supply mature rules (mature lives in the system-prompt files)', !packFiles.some((x) => /mature/i.test(x)))
  t('StudioForm composes instead of concatenating by hand', /composeSystem\(\{ base: baseInfo\.text/.test(read('src/components/StudioForm.jsx')) && /chooseBase\(\{/.test(read('src/components/StudioForm.jsx')))
  t('StudioForm reports the file actually used', /promptReport\(baseInfo, composed\)/.test(read('src/components/StudioForm.jsx')))
  t('a mature fallback is shouted, not swallowed', /logger\.warn\('mature'/.test(read('src/components/StudioForm.jsx')) && /matureFallback \? ' · ⚠ 18\+ unavailable/.test(read('src/components/StudioForm.jsx')))
  t('the base-intact invariant is checked at runtime', /baseIntact\b/.test(read('src/components/StudioForm.jsx')))

  /* --- routing: universal + per-slot, and the picker that drives it --- */
  const files = { 'prompts/my-universal.md': { text: 'MY UNIVERSAL', file: 'prompts/my-universal.md' }, 'prompts/ltx-special.md': { text: 'LTX SPECIAL', file: 'prompts/ltx-special.md' } }
  const lk = (k) => files[k] || null
  const uH3 = chooseBase({ isLtx: false, matureOn: false, sfw, route: { universal: 'prompts/my-universal.md' }, lookup: lk })
  const uMat = chooseBase({ isLtx: true, matureOn: true, sfw, mature: matLtx, route: { universal: 'prompts/my-universal.md' }, lookup: lk })
  t('🌐 universal wins for H3 SFW', uH3.used === 'universal' && uH3.text === 'MY UNIVERSAL' && uH3.file === 'prompts/my-universal.md')
  t('🌐 universal wins for LTX 18+ too (one file for everything)', uMat.used === 'universal' && uMat.text === 'MY UNIVERSAL')
  const sLtx = chooseBase({ isLtx: true, matureOn: false, sfw, route: { ltx: 'prompts/ltx-special.md' }, lookup: lk })
  t('🎯 a per-slot file is used only for its own slot', sLtx.used === 'slot' && sLtx.text === 'LTX SPECIAL')
  const sOther = chooseBase({ isLtx: false, matureOn: false, sfw, route: { ltx: 'prompts/ltx-special.md' }, lookup: lk })
  t('🎯 other slots stay automatic', sOther.used === 'sfw' && sOther.text === 'SFW BASE RULES' && sOther.file === 'system-prompt.md')
  const sMat = chooseBase({ isLtx: false, matureOn: true, sfw, mature: mat, route: { h3m: 'prompts/my-universal.md' }, lookup: lk })
  t('🎯 the 18+ slot can be routed to your own file', sMat.used === 'slot' && sMat.text === 'MY UNIVERSAL')
  t('universal beats a per-slot file', chooseBase({ isLtx: true, matureOn: false, sfw, route: { universal: 'prompts/my-universal.md', ltx: 'prompts/ltx-special.md' }, lookup: lk }).text === 'MY UNIVERSAL')
  const gone = chooseBase({ isLtx: false, matureOn: false, sfw, route: { universal: 'prompts/gone.md' }, lookup: lk })
  t('a routed file that no longer exists is a reported fallback', gone.fellBack && gone.used === 'sfw-fallback' && /gone\.md is unavailable/.test(gone.reason))
  t('empty route = EXACTLY the old automatic behaviour', chooseBase({ isLtx: false, matureOn: true, sfw, mature: mat, route: {}, lookup: lk }).used === 'mature' && chooseBase({ isLtx: true, matureOn: false, sfw, route: {}, lookup: lk }).used === 'sfw')
  t('slotOf maps every combination', slotOf(false, false) === 'h3' && slotOf(true, false) === 'ltx' && slotOf(false, true) === 'h3m' && slotOf(true, true) === 'ltxm')
  const repU = promptReport({ file: 'prompts/my-universal.md', used: 'universal' }, composeSystem({ base: 'X' }))
  t('the report labels a universal run', /^🌐 universal prompts\/my-universal\.md/.test(repU))
  t('HTML comments are stripped and never act as directives', (await (async () => {
    const treeC = { 'prompts/a.md': 'REAL LINE\n<!--\n   @include b.md\n-->\nTAIL', 'prompts/b.md': 'B BODY' }
    const rc = await resolveIncludes(treeC['prompts/a.md'], 'prompts/a.md', (p) => { if (!(p in treeC)) throw new Error('x'); return treeC[p] })
    return rc.deps.length === 0 && rc.cycles.length === 0 && rc.missing.length === 0 && !/B BODY/.test(rc.text) && /REAL LINE/.test(rc.text) && /TAIL/.test(rc.text)
  })()))

  /* picker wiring */
  const set = read('src/components/SettingsModal.jsx')
  t('Settings lists every available prompt file (live index)', /prompts\/_index\.json/.test(set) && /promptFiles/.test(set))
  t('Settings offers a Universal row + one row per slot', /🌐 Universal/.test(set) && /H3 · 18\+/.test(set) && /LTX · 18\+/.test(set))
  t('a routed file with no content is flagged in the UI', /⚠ missing \{v\}/.test(set))
  t('upload now routes the file in instead of being ignored', /setSysCustom\(/.test(set) && /universal: 'custom'/.test(set))
  t('the uploaded prompt is persisted (survives reload)', /cps_syscustom/.test(read('src/App.jsx')))
  t('the route is persisted', /cps_sysroute/.test(read('src/App.jsx')))
  {
    const viteCfg = read('vite.config.js')
    t('the vite index serves prompts/ and any nested folder of it, plus a folder list',
      viteCfg.includes('url.match(/^\\/prompts\\/(.*?)_(index|folders)\\.json$/)') &&
      viteCfg.includes("sub === 'templates' || sub.startsWith('templates/')") &&
      viteCfg.includes('templateIndex(dir)') && viteCfg.includes('_folders.json'))
  }
  t('template → native conversion follows the same route', /effSysText\(false\)/.test(read('src/App.jsx')) && /const effSysText/.test(read('src/App.jsx')))
}

/* ---------- 10 · Template chains (Templates page → builder → planner) ---------- */
H('10 · Template chains — many templates, one shoot')
{
  /* --- chain metadata round-trips --- */
  const recipe = blocks.find((b) => b.chain)
  t('a chain recipe exists in the library', !!recipe && recipe.chain >= 2 && !!recipe.chainRule)
  t('the chain recipe is also an everything-varies template, form axes included', recipe.vary.length === 17 && recipe.vary.includes('OUTFIT COLOUR') && recipe.vary.includes('RHYTHM ENVELOPE') && (recipe.flows || []).length >= 2)
  const md = templateToMd(recipe)
  t('`chain:` and `chainrule:` round-trip through markdown', /^chain: \d+$/m.test(md) && /^chainrule: /m.test(md))
  const LTX = 'prompt: A woman in a long coat walks through the lit room, the camera tracking her as the fabric swings and settles.\n\nnegative_prompt: blur, watermark'
  const reparsed = parseTemplatesMd('## R\nmodel: ltx\nchain: 3\nchainrule: same person\n\n```\n' + LTX + '\n```')
  t('the parser reads chain/chainrule', reparsed.length === 1 && reparsed[0].chain === 3 && reparsed[0].chainRule === 'same person')
  const bad = parseTemplatesMd('## R\nmodel: ltx\nchain: lots\n\n```\n' + LTX + '\n```')
  t('a non-numeric chain is ignored (not a crash)', bad.length === 1 && bad[0].chain === undefined)
  t('a chain recipe parses as a real template block', reparsed[0].fmt === 'ltx' && reparsed[0].chainRule === 'same person')
  const many = parseTemplatesMd('## R\nmodel: ltx\nchain: 99\n\n```\n' + LTX + '\n```')
  t('an absurd chain length is clamped', many[0].chain === 12)
  const unit = blocks.find((b) => /^Room photo shoot/.test(b.t))
  t('the one-room unit template carries no chain metadata', !!unit && !unit.chain)

  /* --- the Templates page builds the chain --- */
  const learn = read('src/components/LearnSection.jsx')
  t('Templates page has a 🔗 chain mode', /Chain mode/.test(learn) && /chainMode/.test(learn))
  t('ticking templates collects them in order', /const pickToggle/.test(learn) && /chainPick\.includes/.test(learn))
  t('a chain needs two or more templates', /A chain wants two or more templates/.test(learn))
  t('the chain is sent with one scene per template', /scenes: chosen\.map\(\(x\) => \(\{ tpl: x\.t/.test(learn))
  t('the chain carries the consistency rule', /same person in every scene/.test(learn))
  t('a chain recipe on a card sends N scenes of itself', /t2\.chain/.test(learn) && /Array\.from\(\{ length: t2\.chain \}/.test(learn))
  t('the card CTA names the chain action', /Chain ' \+ tp\.chain \+ ' scenes|Chain ' \+ t2\.chain/.test(learn) || /🔗 Chain /.test(learn))
  t('chain mode is off by default (no accidental multi-select)', /useState\(false\)[\s\S]{0,40}chainPick/.test(learn))

  /* --- the builder receives and plans it --- */
  const form = read('src/components/StudioForm.jsx')
  t('App latches the chain payload', /cps-load-chain/.test(read('src/App.jsx')) && /kind: 'chain'/.test(read('src/App.jsx')))
  t('the builder consumes kind "chain"', /pendingLoad\.kind === 'chain'/.test(form) && /planTemplateChain\(pendingLoad\.data\)/.test(form))
  t('every scene keeps its own template', /scenes\.map\(\(s, i\) => \(\{ tpl: s\.tpl/.test(form))
  t('the builder template switches to scene 1 (through the shared switch)',
    /tpl0[\s\S]{0,240}switchTemplate\(\{ \.\.\.p, idea: scenes\[0\]\.idea \|\| p\.idea \}, tpl0\)\.patch/.test(form))
  t('the plan length follows the scene count at the template\'s own clip length',
    /const dur0 = \(tpl0 && tpl0\.settings && tpl0\.settings\.duration\) \|\| f\.duration \|\| 8/.test(form) && /setPlanTotal\(Math\.max\(10, scenes\.length \* dur0\)\)/.test(form))
  t('an offline consistency bible is always available', /offlineChainBible/.test(form) && /SAME WOMAN IN EVERY SCENE/.test(form))
  t('the offline bible names the constant and the variable', /CONSTANT ACROSS THE CHAIN/.test(form) && /CHANGES PER SCENE/.test(form))
  t('the planner is asked in TEMPLATE CHAIN mode', /TEMPLATE CHAIN: '/.test(form) && /one template per scene/.test(form))
  t('planned actions replace the template example ideas per scene', /ideas = scenes\.map\(\(s, i\) => \(\(j\.scenes\[i\]/.test(form))
  t('the chain can always fall back to the rule-based bible', /let bible = offlineChainBible\(scenes, rule\)/.test(form))

  /* --- the planner knows the mode --- */
  const planner = read('public/prompts/chain-planner.md')
  t('chain-planner documents TEMPLATE CHAIN mode', /TEMPLATE CHAIN mode/.test(planner))
  t('the planner locks the person and frees the room', /PERSON IS THE CONSTANT/.test(planner) && /WHAT MOVES/.test(planner))
  t('the planner is told one entry per template, in order', /exactly one entry per TEMPLATE listed, in the same order/.test(planner))

  /* --- placeholder identity: one field per NAME (fixed with this batch) --- */
  const dup = { t: 'Dup field', tag: 'fashion', category: 'Fashion / Lifestyle', b: 'integrated_multimodal_description: [Shot 1] {MODEL — her age, build, hair length and colour, skin tone and one distinguishing feature} turns. TIMING: 5s total — one beat.', idea: '{MODEL — the woman} walks past.', flows: null, settings: { structure: 'single' } }
  const L = lintTemplate(dup, [])
  t('one token written twice with different guidance counts ONCE', L.tokens.length === 1)
  t('the field keeps the richest guidance', /one distinguishing feature/.test(L.tokens[0]))
  const filled = fillText('{MODEL — the same woman in every scene} and {MODEL — age, hair}', { MODEL: 'a woman in her late twenties' })
  t('filling by name fills BOTH occurrences', filled === 'a woman in her late twenties and a woman in her late twenties')
  const migrated = normalizePhValues({ 'MODEL — age, hair': 'older text', OTHER: 'x' })
  t('values saved under a full token text migrate to the name key', migrated.MODEL === 'older text' && migrated.OTHER === 'x')
  t('the Templates card counts fields per name', /uniqueTokens\(\[t\.b \|\| ''/.test(read('src/components/TemplateCard.jsx')))
  t('the builder counts fields per name', /uniqueTokens\(\[f\.idea \|\| ''/.test(form))
  t('the audit counts fields per name too', /uniqueTokens\(\[t\.b \|\| ''/.test(read('scripts/audit-prompts.mjs')))
  t('the forge can author a chain recipe', /chainOn/.test(read('src/components/TemplateForge.jsx')) && /CHAIN RECIPE: this template is meant to run as a chain/.test(read('src/components/TemplateForge.jsx')))
}

/* ---------- 11 · Static guard — undefined identifiers (the class of bug the build cannot see) ---------- */
H('11 · Static analysis — no undefined identifiers')
{
  /* esbuild proves JSX and imports; it does NOT prove that every name used exists.
     `promptSet is not defined` shipped that way once. ESLint's no-undef is the check.
     Skipped with a note when dev dependencies are not installed (node_modules is not
     part of the saved workspace). */
  let eslintOk = true, ran = false, findings = ''
  try {
    const { ESLint } = await import('eslint')
    const eslint = new ESLint({ cwd: ROOT })
    const results = await eslint.lintFiles(['src', 'scripts'])
    ran = true
    const errs = results.flatMap((r) => r.messages.filter((m) => m.severity === 2).map((m) => r.filePath.split('/').pop() + ':' + m.line + ' ' + m.ruleId + ' — ' + m.message))
    eslintOk = errs.length === 0
    findings = errs.slice(0, 5).join(' | ')
    await ESLint.outputFixes(results)
  } catch (e) {
    ran = false
  }
  t('lint ran' + (ran ? '' : ' — skipped (run npm install)'), true)
  t('every identifier used in src/ and scripts/ is defined (no-undef)' + (findings ? ' → ' + findings : ''), eslintOk)
  t('the eslint config keeps the react-hooks stub so disable comments stay valid', /reactHooksStub/.test(read('eslint.config.mjs')))
  t('no-dupe-keys and friends are enabled', /no-dupe-keys/.test(read('eslint.config.mjs')) && /no-const-assign/.test(read('eslint.config.mjs')))
  t('npm run lint exists for the same check', /"lint":\s*"eslint src scripts"/.test(read('package.json')))
  t('the regression that started this — promptSet — is defined before use', /const promptSet = promptSetLabel\(/.test(read('src/components/StudioForm.jsx')))
  /* the label is pure and tested: the card must never claim mature when it was not */
  t('a mature run is labelled mature', promptSetLabel({ used: 'mature', file: 'system-prompt-mature.md' }, false) === 'mature-h3')
  t('a routed file is labelled as routed, with its path', promptSetLabel({ used: 'slot', routed: true, file: 'prompts/x.md' }, true) === 'routed-ltx · prompts/x.md')
  t('a silent SFW downgrade is never labelled mature', promptSetLabel({ used: 'sfw-fallback', file: 'system-prompt.md', wasMature: true, reason: 'gone' }, false).startsWith('sfw-h3 · ⚠ mature unavailable'))
  t('a plain SFW run stays plain', promptSetLabel({ used: 'sfw', file: 'system-prompt.md' }, false) === 'sfw-h3')
  t('the camera-path card reads the duration from its own scope', /CameraCard[\s\S]{0,900}opts\.duration/.test(read('src/components/OutputPanel.jsx')))
}

/* ---------- 11c · the 18+ switch decides which prompt runs ---------- */
H('11c · Mature routing — the switch is the decision, keywords only advise')
{
  t('18+ ON, idea reads SFW → the mature prompt still runs', matureRouting({ consent: true, blocked: false, wants: false }).matureOn === true)
  t('18+ ON, idea reads 18+ → mature runs, nothing to advise', matureRouting({ consent: true, wants: true }).matureOn === true && matureRouting({ consent: true, wants: true }).advisory === false)
  t('18+ OFF, idea reads 18+ → SFW runs and the app SAYS SO', (() => { const g = matureRouting({ consent: false, wants: true }); return g.matureOn === false && g.advisory === true })())
  t('operator-blocked → never mature, never an advisory', (() => { const g = matureRouting({ consent: true, blocked: true, wants: true }); return g.matureOn === false && g.advisory === false })())
  /* the failure this replaced: a mature prompt the user maintains that quietly never runs */
  const src = read('src/components/StudioForm.jsx')
  t('the generation path no longer vetoes the switch on keywords', !/return consent && wants/.test(src) && /matureRouting\(\{ consent: !!f\.mature/.test(src))
  t('the keyword list lives in one tested module', MATURE_RE.test('she wears a black corset and stockings') && !/const MATURE_RE/.test(src))
  t('the builder shows which mature file will run, before you generate',
    /this generation runs <b>\{file\}<\/b>/.test(src) && /18\+ off — this generation runs/.test(src) && /is \{?\(?mat && mat\.status\) === 'fallback'/.test(src))
  t('the standard keywords still read as mature', ['a nudity study', 'boudoir', 'intimate', 'lingerie set', 'undressing slow'].every((s) => looksMature(s)))
}

/* ---------- 11d · Fashion outfit expander ---------- */
H('11d · Outfit expander (one line, garment-engineering grade)')
{
  const ex = read('public/prompts/fashion-outfit-expander.md')
  t('the expander ships as an external prompt file', ex.length > 6000)
  t('it keeps the one-line / no-angle-brackets contract', /Exactly one line/.test(ex) && /no angle brackets/i.test(ex))
  t('it keeps 100% preservation as the absolute rule', /ABSOLUTE RULE — 100% PRESERVATION/.test(ex) && /never omit, swap, lighten or\s*\n?contradict/.test(ex))
  t('labeling: Main: for one-piece, Top/Bottom for two-piece, never mixed', /`Main: \[…\]` only/.test(ex) && /Never mix `Main:` with `Top:`\/`Bottom:`/.test(ex))
  t('traditional dress keeps full draping logic', /Nivi/.test(ex) && /Lehenga choli/.test(ex) && /Choli: \[…\], Ghagra: \[…\], Dupatta: \[…\]/.test(ex))
  t('builders are banned: adjectives must name manufacture', /banished/.test(ex) && /480 gsm double-face wool/.test(ex) && /bias-cut silk crepe, 22-momme/.test(ex))
  t('palette discipline: 3 colours, 60/30/10, one metal', /60%/.test(ex) && /30%/.test(ex) && /10%/.test(ex) && /never both/.test(ex))
  t('era table is executable, not atmospheric', /2020s quiet luxury/.test(ex) && /2030s tech-organic/.test(ex) && /dropped waist, bias panel/.test(ex))
  t('footwear keeps all seven parts', /Seven parts|SEVEN PARTS/.test(ex) && /seven parts/.test(ex))
  t('intimate wear stays in-category (no slip dress for "lingerie")', /Never a slip dress/.test(ex) && /corset = boned/.test(ex))
  t('series continuity: byte-stable re-call of the same garment', /byte-stable/.test(ex) && /the ivory slub-silk column/.test(ex))
  t('a silent self-check gates the emit', /SELF-CHECK BEFORE EMITTING/.test(ex) && /Score below 8 = the line fails/.test(ex))
  t('13 labelled fields in every worked example', (() => {
    const lines = ex.split('\n').filter((l) => /^`Outfit Type – Subtype:/.test(l) && l.endsWith('`'))
    return lines.length === 3 && lines.every((l) => {
      const labels = (l.match(/(?:^|, )([A-Z][A-Za-z /]+):/g) || []).length
      return labels >= 13
    })
  })())
  const src = read('src/components/StudioForm.jsx')
  t('the app runs it from the placeholder dialog (👗 Expand outfit)', /fashion-outfit-expander\.md/.test(src) && /Expand outfit/.test(src) && /function expandOutfit/.test(src))
  t('the expander result is stripped to a single clean line', /sort\(\(a, b\) => b\.length - a\.length\)\[0\]/.test(src))
  t('it is reachable without editing anything (any .md under prompts/ is pickable)', /prompts\/fashion-outfit-expander\.md/.test(read('vite.config.js')) === false &&
    read('public/prompts/fashion-outfit-expander.md').length > 0)
}

/* ---------- 11e · On-camera speech (the "voice from nowhere" fix) ---------- */
H('11e · On-camera speech — she talks, she is not narrated')
{
  const sp = read('public/prompts/shared/on-camera-speech.md')
  t('the rule ships as a shared craft file', sp.length > 2500 && /ON-CAMERA SPEECH/.test(sp) && /VOICEOVER/.test(sp))
  t('it names the two modes and keeps them apart', /Never blur the two/.test(sp) && /lips remain completely closed/.test(sp))
  t('it demands the mouth is visible, moving and unobstructed', /lips move with every word/.test(sp) && /unobstructed/.test(sp) && /no hand, glass, hair, fan/.test(sp))
  t('it keeps speech out of the soundscape and the music field', /overall_soundscape` never carries speech/.test(sp) && /non_diegetic_music` never carries speech/.test(sp))
  t('it budgets words against seconds', /1\.5-2 s/.test(sp) && /2\.5-3 s/.test(sp) && /three short spoken beats at most/.test(sp))
  t('it keeps the tag verbatim with a stable speaker ID', /<d>\[Language\] …<\/d>/.test(sp) && /\(S1\)/.test(sp) && /\(S1,S2\)/.test(sp))
  const sp2 = ['public/prompts/system-prompt.md', 'public/prompts/ltx-system-prompt.md']
  t('both SFW prompts include it', sp2.every((p) => /^@include shared\/on-camera-speech\.md$/m.test(read(p))))
  const msg = buildUserMessage({ category: 'Fashion / Lifestyle', idea: 'x', duration: 10, structure: 'multi3', target: 'h3', workflow: 't2v', dialogueOn: true, dialogue: 'This is a sweetheart neckline.', dlang: 'English' })
  const line = msg.split('\n').find((l) => l.startsWith('- Dialogue:')) || ''
  t('a requested line is ordered ON CAMERA, not as a voice', /ON CAMERA/.test(line) && /lips move with every word/.test(line) && /Never resolve this line as an off-screen voice/.test(line))
  t('the line itself stays verbatim inside the tag', /<d>\[English\] This is a sweetheart neckline\.<\/d>/.test(line))
  const auto = buildUserMessage({ category: 'Fashion / Lifestyle', idea: 'x', duration: 10, structure: 'multi3', target: 'h3', workflow: 't2v' })
  t('even the unrequested-speech path defaults to on-camera', /ON-CAMERA speech/.test(auto) && /a voiceover ONLY when/.test(auto))
  const ltx = buildUserMessageLtx({ category: 'Fashion / Lifestyle', idea: 'x', duration: 10, target: 'ltx', workflow: 't2v', dialogueOn: true, dialogue: 'Line', dlang: 'English' })
  t('the LTX path carries the same rule', /ON CAMERA/.test(ltx) && /lips moving through every word/.test(ltx))
}

/* ---------- 11f · Spoken outfit-reveal templates + STYLE TYPE ---------- */
H('11f · Outfit reveal — spoken detail tour (+ style-type series)')
{
  const file = read('public/prompts/templates/outfit-reveal.md')
  const drops = parseTemplatesMd(file)
  t('the new templates ship as a drop-in file (add-only in a patch)', drops.length === 2)
  const [reveal, series] = drops
  t('the reveal template is the spoken one', !!reveal && /Outfit reveal/.test(reveal.t) && reveal.tag === 'fashion')
  const L = lintTemplate(reveal, [...blocks, ...drops])
  t('it lints clean', L.warn === 0)
  t('STYLE TYPE is the first field the user meets', reveal.idea.indexOf('{STYLE TYPE') >= 0 && reveal.idea.indexOf('{STYLE TYPE') < reveal.idea.indexOf('{OUTFIT DESIGN'))
  t('STYLE TYPE varies and has its own pool', reveal.vary.includes('STYLE TYPE') && /^## STYLE TYPE$/m.test(read('public/prompts/fashion-variation.md')))
  t('one spoken beat per garment detail, in order', /NECKLINE OR COLLAR/.test(reveal.b) && /WAIST/.test(reveal.b) && /BACK OR DRAPE/.test(reveal.b) && /HEM OR FOOTWEAR/.test(reveal.b) && /CLOSING/.test(reveal.b))
  t('each beat is a hand on the detail plus a line about it', /brings one hand to the neckline[\s\S]{0,120}says what it does/.test(reveal.b))
  t('it interacts with the room as well as the garment', /WORLD INTERACTION/.test(reveal.b) && /chair back/.test(reveal.b) && /parts a curtain/.test(reveal.b) && /Exactly ONE such world contact per shot/.test(reveal.b))
  t('the persona rules are written: attitude, her own voice, no sales pitch', /HER POINT OF VIEW IS THE SUBJECT/.test(reveal.b) && /self-possession/.test(reveal.b) && /Never a sales tagline/.test(reveal.b) && /glamour is her confidence/.test(reveal.b))
  t('it carries the on-camera speech rules itself', /ON-CAMERA SPEECH/.test(reveal.b) && /No off-screen narration/.test(reveal.b))
  t('words are budgeted against the clock', /SPOKEN TIMING/.test(reveal.b) && /1\.5-2 seconds/.test(reveal.b) && /five or six lines total is already too many/.test(reveal.b))
  t('four flows, includng a mirror and a feet-first option', (reveal.flows || []).length === 4 && /MIRROR CONFESSION/.test(reveal.b) && /FEET FIRST/.test(reveal.b))
  t('the series recipe is a real chain recipe', !!series && series.chain === 5 && /STYLE TYPE/.test(series.chainRule) && /same woman in every scene/.test(series.chainRule))
  t('the series rotates style types per scene', /different STYLE TYPE/.test(series.tip + series.d))
  const pools = read('public/prompts/fashion-variation.md')
  t('the STYLE TYPE pool carries the registers asked for', ['tradition', 'office wear', 'swimwear', 'bridal', 'resort', 'athleisure'].every((s) => new RegExp(s, 'i').test(pools)))
  t('the expander honours the style type before the garment', /STYLE TYPE FIRST/.test(read('public/prompts/fashion-outfit-expander.md')))
  t('no template placeholder exceeds the tokeniser ceiling', drops.every((x) => tokensOf(x).length >= 8) &&
    !/>120/.test(lintTemplate(reveal, [...blocks, ...drops]).checks.map((c) => c.label).join(' ')))
}

/* ---------- 11g · Garment colour is a decision, never a default ---------- */
H('11g · Garment colour — no more accidental white')
{
  /* the root cause: a token that asked for silhouette + fabric and never a colour */
  const everyToken = []
  for (const b of blocks) everyToken.push(...tokensOf(b))
  const drops2 = ['public/prompts/templates/outfit-reveal.md', 'public/prompts/templates/immersive.md', 'public/prompts/templates/medical-education.md']
    .flatMap((p) => parseTemplatesMd(read(p)))
  const allT = [...blocks, ...drops2]
  /* Every garment-named placeholder everywhere — OUTFIT DESIGN, GARMENT, DRESS, SKIRT, TOP/BOTTOM,
     LEHENGA, ETHNIC SET … — must sit in a block that names a colour somewhere. Action tokens
     (what her hands do) are exempt: they are not garment descriptions. */
  const COLOURWORD2 = /colour|color|palette|colourway|white|black|ivory|cream|ecru|beige|crimson|wine|oxblood|burgundy|cobalt|emerald|sage|salmon|mustard|ochre|navy|terracotta|bottle green|tomato|plum|blush|copper|tan|camel|oatmeal|rust|jade|charcoal|silver|gold|bronze|denim|indigo|saffron|lacquer|monochrome|two-tone/i
  const GARMENTTOK = /\b(GARMENT|DRESS|OUTFIT DESIGN|OUTFIT\b|SKIRT|LEHENGA|SARI|BLOUSE|SHIRT|COAT|SUIT|TROUSER|KURTA|ETHNIC|TOP|BOTTOM|BRA|PANTY)\b/
  const noColour = allT.filter((b) => {
    const toks = tokensOf(b).map(String).filter((x) => GARMENTTOK.test(x) && !/OUTFIT INTERACTION/.test(x))
    return toks.length && !COLOURWORD2.test(b.b + b.idea)
  })
  t('every garment placeholder carries a colour (' + allT.length + ' templates, 0 may go colourless)', noColour.length === 0)
  const pools = read('public/prompts/fashion-variation.md')
  const colourSec = (pools.split(/^## OUTFIT COLOUR$/m)[1] || '').split(/^## /m)[0]
  t('the OUTFIT COLOUR pool ships with 10+ families', (colourSec.match(/^\d+\. /gm) || []).length >= 10)
  t('each colour family names its colours AND its finish', /oxblood/i.test(colourSec) && /matte/i.test(colourSec) && /satin/i.test(colourSec))
  const designSec = (pools.split(/^## OUTFIT DESIGN$/m)[1] || '').split(/^## /m)[0]
  const designOpts = designSec.split('\n').filter((l) => /^\d+\. /.test(l))
  const colourWord = /(oxblood|cobalt|indigo|plum|mustard|ochre|oatmeal|camel|black|rust|ivory|emerald|navy|terracotta|bottle green|tomato)/i
  t('all ' + designOpts.length + ' OUTFIT DESIGN pool options now name a colour', designOpts.length >= 6 && designOpts.every((l) => colourWord.test(l)))
  const fashion = read('public/prompts/packs/fashion.md')
  t('the fashion pack carries the colour doctrine', /## Colour — the garment carries one, always/.test(fashion))
  t('and it bans the accidental white default by name', /NEVER default to white, ivory, cream/.test(fashion) && /white is the model's default, not a decision/.test(fashion))
  t('it also carries the 60/30/10 area rule and one-metal rule', /body 60%/.test(fashion) && /one metal family/.test(fashion))
  const sp = ['public/prompts/templates/core.md', 'public/prompts/templates/outfit-reveal.md']
  t('the four fashion showcase templates all vary colour', sp.every((p) => {
    const list = parseTemplatesMd(read(p)).filter((b) => /OUTFIT COLOUR/.test(b.b + b.idea))
    return list.length >= 2 && list.every((b) => b.vary.includes('OUTFIT COLOUR'))
  }))
  /* few-shot anchoring: the exemplar library must not teach "white garment" */
  const ex = read('src/lib/examples.js')
  const whites = (ex.match(/(white|ivory|cream)\s+(eyelet|knit|dress|shirt|coat|blouse|sundress|linen|silk|robe)/gi) || [])
  t('at most two exemplars still anchor on a white garment (was four) · ' + whites.length, whites.length <= 2)
  t('the rebalanced exemplars keep their strong colours', /tobacco-brown fine-gauge knit dress/.test(ex) && /tomato-red wool coat/.test(ex))
}

  /* --- the instant engine: same rule, no LLM needed --- */
  const off = (idea, structure) => genVariantOffline({ idea, duration: 8, structure, ratio: '16:9', resolution: '2K', palette: 'Auto', camera: 'Auto', style: 'Auto', music: 'subtle', detail: true }, 1, 3)
  const offShot = await off('a woman walks across a marble hall', 'multi3')
  const offSingle = await off('a dress spins in the light', 'single')
  t('the instant engine adds a wardrobe colour when the idea has none',
    /WARDROBE/.test(offShot.integrated_multimodal_description) && /WARDROBE/.test(offSingle.integrated_multimodal_description))
  const offNamed = await off('a woman in an oxblood silk dress crosses the room', 'multi3')
  /* v2.13: a named colour is never rivalled — but the missing LAYERS are still named, which is the
     whole point of the fix (a dress described alone is how a bare-shouldered render happens). */
  t('it never imposes a family on a colour the user named, and echoes that colour instead',
    /closed layer stack/.test(offNamed.integrated_multimodal_description) &&
    /the same oxblood/.test(offNamed.integrated_multimodal_description) &&
    !/COLOUR ROTATION|antique gold|brushed silver|bronze hardware/i.test(offNamed.integrated_multimodal_description))
  const offLand = await off('a mountain at dawn, mist over the ridge', 'single')
  t('it stays out of scenes with no wardrobe at all', !/WARDROBE/.test(offLand.integrated_multimodal_description))
  const offLtx = await genVariantLtxOffline({ idea: 'a model in a long coat walks by', duration: 8, ratio: '16:9', resolution: '2K', palette: 'Auto', camera: 'Auto', style: 'Auto', music: 'subtle', detail: true }, 1, 2)
  /* v2.40 — the LTX paragraph may not carry H3 protocol labels at all, so the law is checked as a
     law about the finished paragraph: the colour arrives as prose (or not at all), never as a label */
  t('the LTX instant path carries the wardrobe as prose, never as a protocol label', (() => {
    const p = String(offLtx.prompt || '')
    const withColour = String(genVariantLtxOffline({ idea: 'a model in a long coat walks by', duration: 8, ratio: '16:9', resolution: '2K',
      palette: 'Auto', camera: 'Auto', style: 'Auto', music: 'subtle', detail: true, phValues: { 'OUTFIT DESIGN': 'a long wool coat', 'OUTFIT COLOUR': 'oxblood' } }, 1, 2).prompt || '')
    return !/WARDROBE:|THE MODEL IS/.test(p) && !/WARDROBE:|THE MODEL IS/.test(withColour) && /oxblood/i.test(withColour)
  })())

/* ---------- 11h · Immersive (360 / VR180 LoRAs) + medical animation ---------- */
H('11h · Immersive LoRAs and medical/science animation')
{
  const imm = parseTemplatesMd(read('public/prompts/templates/immersive.md'))
  t('the immersive file ships two templates', imm.length === 2)
  const [e360, vr] = imm
  const iL = imm.map((x) => lintTemplate(x, [...blocks, ...imm]))
  t('both immersive templates lint clean', iL.every((L) => L.warn === 0))
  t('they use the LoRA settings (21:9 · 768P · 5s · single take)', imm.every((x) => x.settings.ratio === '21:9' && x.settings.resolution === '768P' && x.settings.duration === 5 && x.settings.structure === 'single'))
  t('the equi360 trigger carries the official layout sentence verbatim', /^integrated_multimodal_description: equirect360 Equirectangular 360-degree panoramic video: the frame is a full spherical projection, a complete environment wrapping around the viewer on all sides, with the horizon at the vertical middle of the frame\./.test(e360.b))
  t('the equi360 template teaches the wrap seam and the polar bands', /WRAP CONTINUITY/.test(e360.b) && /POLAR RULE/.test(e360.b) && /no horizon tilt|never tilts across the horizon|no roll/.test(e360.b))
  t('it tells you to resize to 2:1, never crop', /resize the rendered 21:9 frame to 2:1|Resize the rendered 21:9 frame to 2:1/i.test(e360.tip + e360.d))
  t('the vr180 trigger carries the official layout sentence verbatim', /^integrated_multimodal_description: vr180sbs Stereoscopic VR180 video shown side by side: the left half is the left-eye view and the right half is the right-eye view of the same 180-degree scene, nearly identical with a slight horizontal offset\./.test(vr.b))
  t('vr180 keeps the stereo comfort window and bans fast pans', /1\.5 m/.test(vr.b) && /4 m/.test(vr.b) && /fast pans drift between the eyes|fast pans can drift/i.test(vr.b))
  t('vr180 bans on-screen text outright (the eyes disagree on it)', /no on-screen text at all/i.test(vr.b) && /no on-screen text at all/.test(vr.b))
  t('vr180 ships the packaging command', /spatialmedia/.test(vr.tip) && /1536:768/.test(vr.tip) && /left-right/.test(vr.tip) && /spherical V2|-s left-right/.test(vr.d + vr.tip))
  const loras = read('public/prompts/loras.md')
  const parsed = parseLorasMd(loras)
  const e = parsed.find((x) => /Equi360/.test(x.t)), v = parsed.find((x) => /VR180/.test(x.t))
  t('both LoRAs are in the library with their trigger words', !!e && !!v && /^equirect360/.test(e.trigger) && /^vr180sbs/.test(v.trigger))
  t('the library records the evaluated settings', /21:9 · 768P · 5s/.test(e.strength + e.d) && /21:9 · 768P · 5s/.test(v.strength + v.d))
  t('the vr180 entry warns off the h3-max route', /h3-max/.test(v.d))

  const med = parseTemplatesMd(read('public/prompts/templates/medical-education.md'))
  const reels = parseTemplatesMd(read('public/prompts/templates/medical-reels.md'))
  t('the medical library ships 5 films + 3 reels', med.length === 5 && reels.length === 3)
  const mL = med.map((x) => lintTemplate(x, [...blocks, ...med]))
  t('all eight medical templates lint clean', [...med, ...reels].map((x) => lintTemplate(x, [...blocks, ...med, ...reels])).every((L) => L.warn === 0))
  const loop = med.find((x) => /Physiology cycle/.test(x.t))
  t('the physiology loop is a real loop (single take, last frame = first)',
    !!loop && loop.settings.loop === true && loop.settings.structure === 'single' && /THE LOOP CONTRACT/.test(loop.b) && /final frame must match the first frame exactly/.test(loop.b))
  t('the loop refuses one-way flow', /every displacement has its return/.test(loop.b))
  /* the reels: a hook that lands in two seconds, one action, honest speech, safe claims */
  const hook = reels.find((x) => /symptom hook/.test(x.t))
  const myth = reels.find((x) => /myth vs fact/.test(x.t))
  const proc = reels.find((x) => /day of the procedure/.test(x.t))
  t('all three reels are vertical, phone-first and phone-safe', reels.every((x) => x.settings.ratio === '9:16' && x.settings.duration <= 15 && /safe area|middle of the vertical frame/.test(x.b)))
  t('the symptom-hook reel earns the first two seconds', !!hook && /HOOK IS LAW/.test(hook.b) && /first two seconds/.test(hook.b) && /HOOK THEN NAME IT/.test(hook.flows.join(' ')))
  t('it closes on ONE action held still', /ONE ACTION — \{ACTION\} stated once and held/.test(hook.b) && /last stretch stays steady on the action|settling to stillness so it can be read twice/.test(hook.b))
  t('the myth reel keeps the speaker on camera with verbatim dialogue', !!myth && /face always in frame, mouth never covered/.test(myth.b) && /written verbatim as dialogue/.test(myth.b))
  t('the walkthrough reel never shows the clinical moment', !!proc && /Never show a needle entering skin/.test(proc.b) && /prepared tray/.test(proc.b))
  t('every reel caps on-screen text at one quoted line per shot',
    reels.every((x) => /at most one short quoted English line per shot/i.test(x.b)) && reels.every((x) => /written verbatim|exactly as written/.test(x.b)))
  t('the hook reel allows an off-screen voiceover only with the exact phrase and closed lips',
    /off-screen voiceover/.test(hook.b) && /lips remain closed/.test(hook.b))
  t('the on-camera reels require the face in frame and the mouth clear',
    /face always in frame, mouth never covered/.test(myth.b) && /face in frame/.test(hook.b) && /mouth unobstructed/.test(proc.b))
  t('every reel refuses claims it cannot stand behind',
    /never a diagnosis, never "cures\/treats\/prevents"/.test(hook.b) && /no cure, no guarantee, no diagnosis of the viewer/.test(myth.b) && /no success rate, no guarantee/.test(proc.b))
  t('every reel derives its pacing from the live clock instead of stamping cut times', reels.every((x) => /TIMING:/.test(x.b) && /live runtime|live clock|never at a stamped second/.test(x.b) && !/\d{1,2}:\d{2}\.\d{3}/.test(x.b)))
  t('they all route to the medical pack', [...med, ...reels].every((x) => x.tag === 'medical'))
  const moa = med.find((x) => /MOA/.test(x.t))
  t('the MOA film turns a claim into a physical event', /CONTACT \(the event itself/.test(moa.b) && /TARGET \(/.test(moa.b) && /CASCADE \(/.test(moa.b))
  t('the MOA film keeps scale continuous and bans gore', /SCALE IS THE LANGUAGE/.test(moa.b) && /no gore/i.test(moa.b))
  const cls = med.find((x) => /Classroom/.test(x.t))
  t('the classroom explainer allows exactly the labels and caps them at three', /never more than three labels on screen at once/.test(cls.b) && /LABELS: \{LABELS/.test(cls.b))
  t('the classroom explainer is deliberately un-cinematic', /bright, clean 3D educational render/.test(cls.b) && /no lens flares/.test(cls.b))
  const hyb = med.find((x) => /Hybrid/.test(x.t))
  t('the hybrid explainer makes the hand-off the craft', /THE HAND-OFF is the whole craft/.test(hyb.b) && /same ANGLE, the same LIGHT DIRECTION and the same DISTANCE/.test(hyb.b) && /cut on a movement/.test(hyb.b))
  t('the hybrid explainer bans text in both halves', /NO ON-SCREEN TEXT in either half/.test(hyb.b) && /no split screen/.test(hyb.b))
  const pack = parsePackMd(read('public/prompts/packs/medical.md'), 'medical.md')
  t('the medical pack parses and carries the science rules', pack.id === 'medical' && /mechanism is a physical event/.test(read('public/prompts/packs/medical.md')))
  t('the pack keeps medical content as illustration, not advice', /not a diagnosis|illustration, never as advice|never as advice or diagnosis/.test(read('public/prompts/packs/medical.md')))
  const chosen = resolvePacks([pack], { tag: 'medical', category: 'Medical / Science', idea: 'how a receptor binds' }).chosen
  t('a medical template selects the medical pack', chosen.length === 1 && chosen[0].id === 'medical')
  t('an immersive template reaches a pack too (no orphan verticals)', /^## Equirectangular 360/m.test(read('public/prompts/templates/immersive.md')) &&
    parsePackMd(read('public/prompts/packs/medical.md'), 'medical.md').tags.includes('immersive'))
}

/* ---------- 11i · Rearranging a chain ---------- */
H('11i · Chain scenes can be rearranged')
{
  const sf = read('src/components/StudioForm.jsx')
  const ls = read('src/components/LearnSection.jsx')
  t('the builder has a move operation that keeps the active scene pointed at the same scene',
    /const moveScene = \(i, dir\)/.test(sf) && /if \(c\.active === i \+ 1\) active = j \+ 1/.test(sf) && /else if \(c\.active === j \+ 1\) active = i \+ 1/.test(sf))
  t('every scene row carries ↑ ↓ controls with the ends disabled',
    /disabled=\{i === 0\} onClick=\{\(\) => moveScene\(i, -1\)\}/.test(sf) &&
    /disabled=\{i === chain\.scenes\.length - 1\} onClick=\{\(\) => moveScene\(i, 1\)\}/.test(sf))
  t('the Templates page arranges the picks before sending (◀ ▶ step, ⇤ ⇥ jump, ✕ remove)',
    /const movePick = \(i, dir\)/.test(ls) && /const jumpPick = \(i, to\)/.test(ls) && /movePick\(i, -1\)/.test(ls) && /movePick\(i, 1\)/.test(ls) && /jumpPick\(i, 'start'\)/.test(ls) && /jumpPick\(i, 'end'\)/.test(ls) && /pickToggle\(n\)/.test(ls))
  t('the pick list is the scene order that gets sent', /const chosen = chainPick\.map/.test(ls) && /scenes: chosen\.map/.test(ls))
  /* the two operations are the same algorithm — expressed as a pure helper and tested here */
  const move = (arr, i, dir) => { const j = i + dir; if (j < 0 || j >= arr.length) return arr.slice(); const q = arr.slice(); const [m] = q.splice(i, 1); q.splice(j, 0, m); return q }
  const jump = (arr, i, to) => { const q = arr.slice(); const [m] = q.splice(i, 1); q.splice(to === 'end' ? q.length : 0, 0, m); return q }
  t('moving one step up swaps with the neighbour', move(['a', 'b', 'c'], 2, -1).join('') === 'acb')
  t('moving at the edge is a no-op, never a lose', move(['a', 'b'], 0, -1).join('') === 'ab' && move(['a', 'b'], 1, 1).join('') === 'ab')
  t('jumping to the front and to the back work', jump(['a', 'b', 'c'], 2, 'start').join('') === 'cab' && jump(['a', 'b', 'c'], 0, 'end').join('') === 'bca')
  t('active-scene remapping keeps the same scene selected after a swap',
    (() => { const remap = (active, i, j) => (active === i + 1 ? j + 1 : active === j + 1 ? i + 1 : active); return remap(2, 1, 2) === 3 && remap(3, 1, 2) === 2 && remap(5, 1, 2) === 5 })())
}

/* ---------- 11j · Changing template replaces the inputs ---------- */
H('11j · Switching template replaces the previous template\'s inputs')
{
  const sf = read('src/components/StudioForm.jsx')
  const tsx = read('src/components/TemplatesSection.jsx')
  t('one pure switch decides what a template change does',
    typeof switchTemplate === 'function' && typeof describeSettings === 'function')
  t('the picker swaps through it (attach)',
    /const sw = switchTemplate\(f, t\)/.test(sf) && /switchTemplate\(pf, t\)\.patch/.test(sf))
  t('a Templates-page load swaps through it too',
    /const sw = switchTemplate\(\{ \.\.\.f, idea: ex\.idea != null \? ex\.idea : f\.idea \}, tp\)/.test(sf) &&
    /switchTemplate\(\{ \.\.\.p, idea: ex\.idea != null \? ex\.idea : p\.idea \}, tp\)\.patch/.test(sf))
  t('Directing a chain scene swaps to that scene\'s template',
    /switchTemplate\(\{ \.\.\.pf, idea: ideaTxt \}, scTpl\)\.patch/.test(sf))
  t('the Templates page sends its template with the load',
    /settings: \{ \.\.\.tp\.settings, template: tp\.t \}/.test(tsx))
  t('the pinned settings come along, and are described to the user',
    /toast\('📐 ' \+ t\.t \+ ' attached — ' \+ \(describeSettings\(t\.settings\)/.test(sf) &&
    describeSettings({ ratio: '16:9', resolution: '2K', duration: 10, structure: 'multi3' }) === '16:9 · 2K · 10s · 3 shots')

  /* behaviour — the user's exact complaint: old inputs must not survive the switch */
  const A = { t: 'Outfit reveal', b: '[Shot 1] {STYLE TYPE} in {OUTFIT COLOUR} at {LOCATION}', idea: 'STYLE TYPE: {STYLE TYPE}', settings: { ratio: '16:9', resolution: '2K', duration: 10, structure: 'multi3', music: 'subtle', camera: 'Auto' } }
  const B = { t: 'MOA film', b: '[Shot 1] {MOLECULE} enters {CELL TYPE}', idea: '{MOLECULE} binds {RECEPTOR}.', settings: { ratio: '16:9', resolution: '2K', duration: 10, structure: 'multi3', music: 'subtle', camera: 'Auto' } }
  const form = { idea: 'my own line', duration: 6, ratio: '9:16', structure: 'single', camera: 'Push in', ph: { 'STYLE TYPE': 'tradition', 'OUTFIT COLOUR': 'crimson', 'LOCATION': 'a bare studio', 'MODEL': 'a 24-year-old' } }
  const sw = switchTemplate(form, A)
  t('a field whose token lives in the new template is kept',
    sw.kept.includes('STYLE TYPE') && sw.kept.includes('OUTFIT COLOUR') && sw.kept.includes('LOCATION'))
  t('a field the new template does not have is dropped, not carried over',
    sw.dropped.includes('MODEL') && !('MODEL' in sw.patch.ph))
  t('the new template\'s pinned settings replace the old ones',
    sw.patch.duration === 10 && sw.patch.structure === 'multi3' && sw.patch.ratio === '16:9' && sw.applied.includes('duration'))
  t('a written idea is kept (the template does not wipe what you typed)', sw.patch.idea === 'my own line')
  t('a blank idea adopts the template\'s own idea', switchTemplate({ idea: '', ph: {} }, B).patch.idea === B.idea)
  const sw2 = switchTemplate({ ...form, ph: sw.patch.ph }, B)
  t('switching again clears everything that belonged to the previous template',
    sw2.kept.length === 0 && sw2.dropped.length === 3 && Object.keys(sw2.patch.ph).length === 0)
  t('the switch never touches the mature/system files', !/system-prompt/.test(JSON.stringify(sw.patch)))
}

/* ---------- 11k · Prompt duration done correctly ---------- */
H('11k · Duration — one clock for the whole pipeline')
{
  t('fmtTC writes official H3 timecodes', fmtTC(3.333) === '00:03.333' && fmtTC(6.667) === '00:06.667' && fmtTC(0) === '00:00.000')
  const c10 = shotClock(10, 'multi3')
  t('a 10s three-shot clip is cut in equal thirds', c10.shots === 3 && c10.cuts.join('|') === '3.333|6.667' && c10.windows.every((w) => Math.abs(w - 3.333) < 0.002))
  const c5 = shotClock(5, 'multi3')
  t('three shots always fit the runtime — a 5s clip never ends on a 1s shot',
    c5.shots === 3 && c5.cuts[1] + Math.min(...c5.windows) <= 5 && Math.min(...c5.windows) >= 1.5)
  t('every window is at least the 1.5s floor, for every runtime and structure',
    [4, 5, 6, 8, 10, 12, 15, 20].every((d) => ['single', 'multi2', 'multi3'].every((s) => {
      const c = shotClock(d, s)
      return c.windows.every((w) => w >= 1.5) && c.windows.reduce((a, b) => a + b, 0) === d
    })))
  t('the clock clamps a runtime into 4-20s and a loop is always one take',
    shotClock(1, 'multi3').dur === 4 && shotClock(99, 'multi3').dur === 20 && shotClock(10, 'multi3', true).shots === 1)
  t('structure decides the shot count', shotClock(10, 'single').shots === 1 && shotClock(10, 'multi2').shots === 2)
  t('spoken words are measured without the language tag',
    speechWords('[English] The hem sweeps the floor.') === 5 && speechWords('English: The collar frames the neck.') === 5)
  t('timecodes are read back out of a prompt',
    timecodes('[Shot 2] At 00:03.500 and [Shot 3] At 00:07.000').join('|') === '3.5|7')
  t('the runtime test accepts the ways a model states it',
    runtimeStated('a 10-second, three-shot sequence', 10) && runtimeStated('Duration: 10 seconds', 10) &&
    runtimeStated('the piece runs 10s in total', 10) && !runtimeStated('a 10-minute film', 10) &&
    !runtimeStated('a three-shot sequence', 10))

  /* the user message itself carries the clock */
  const base = { idea: 'a woman in a crimson silk lehenga', category: 'Fashion / Lifestyle', style: 'Auto', structure: 'multi3', camera: 'Auto', amp: 'small', speed: 'slow', ratio: '16:9', resolution: '2K', duration: 10, music: 'subtle', palette: 'Auto', dialogueOn: true, dialogue: 'Tradition and heritage in this coat.', dlang: 'English', detail: true, workflow: 't2v' }
  const um = buildUserMessage(base, 1, 1)
  const clk = (um.split('\n').find((l) => l.startsWith('CLOCK')) || '')
  t('the H3 message hands over the exact clock — the drawn rhythm, not an even split', (() => {
    const live = liveClock(base, 1)
    return /10 seconds, 3 shots/.test(clk) && live.shots === 3 &&
      live.cuts.every((c, i) => clk.includes('[Shot ' + (i + 2) + '] opens at ' + fmtTC(c))) &&
      live.envelope !== 'flat' && um.includes('RHYTHM: the shot lengths follow a ' + live.envelopeLabel.split(' — ')[0])
  })())
  t('it forbids a timecode at or past the runtime and a short tail',
    /no timecode may be 00:10\.000 or later/.test(clk) && /no shot shorter than 1\.5s/.test(clk))
  t('it requires the runtime to appear in the prompt text', /state the runtime inside the opening sentence/.test(clk))
  t('it budgets speech per shot and reports the requested line',
    /SPOKEN BUDGET/.test(clk) && /the requested line is 6 words/.test(clk))
  t('it neutralises a template skeleton whose clock disagrees', /an example, not an instruction: this CLOCK wins/.test(clk))
  t('a single-shot clip is told there are no cut timecodes', /no cuts, no cut timecodes anytime|no cuts, no cut timecodes anywhere/.test(buildUserMessage({ ...base, structure: 'single', duration: 8 }, 1, 1)))
  const umL = buildUserMessageLtx({ ...base, target: 'ltx' }, 1, 1)
  const clkL = (umL.split('\n').find((l) => l.startsWith('CLOCK')) || '')
  t('the LTX clock paces instead of stamping timecodes',
    /10 seconds, ONE continuous take/.test(clkL) && /no \[Shot N\] markers and no "00:00" stamps/.test(clkL) && /state the runtime inside the opening sentence/.test(clkL))

  /* the instant engine obeys the same clock */
  const off = await genVariantOffline({ ...base, duration: 5, structure: 'multi3' }, 1, 1)
  const od = off.integrated_multimodal_description
  const otc = timecodes(od)
  t('the instant engine never cuts past the runtime and never leaves a 1s tail',
    otc.every((x) => x < 5) && 5 - Math.max(...otc) >= 1.5)
  t('the instant engine states the runtime in the text', runtimeStated(od, 5) && /A 5-second, 3-shot sequence/.test(od))

  /* the audit — run on the prompt the user pasted, at two durations */
  const good = { integrated_multimodal_description: 'Shot on a 35mm lens, 24fps, a 10-second three-shot sequence. [Shot 1] She walks in, wearing a charcoal wool coat with black block heels, and says <d>English: Tradition and heritage in this coat.</d> [Shot 2] At 00:03.333 the camera cuts to the collar as her hand traces it. [Shot 3] At 00:06.667 the camera cuts wide as the hem settles, holding the last second.', overall_soundscape: 'room tone, footsteps, fabric.', non_diegetic_music: 'sparse percussive loop.' }
  const scGood = scoreH3(good, { duration: 10, structure: 'multi3' })
  t('a clock-correct prompt passes every duration check',
    scGood.checks.filter((c) => /Runtime stated|timecode inside|Last shot runs|Shot count|Spoken lines fit|Wardrobe reads/.test(c[1])).every((c) => c[0]))
  const noRuntime = scoreH3({ ...good, integrated_multimodal_description: good.integrated_multimodal_description.replace('a 10-second three-shot sequence', 'a short film') }, { duration: 10, structure: 'multi3' })
  t('the audit catches a prompt that never states its runtime',
    noRuntime.checks.some((c) => /Runtime stated/.test(c[1]) && !c[0]))
  const overrun = scoreH3({ ...good, integrated_multimodal_description: 'Shot on 35mm, a 10-second clip. [Shot 1] She walks. [Shot 2] At 00:03.333 the camera cuts closer. [Shot 3] At 00:10.500 the camera cuts wide, a moment past the end.' }, { duration: 10, structure: 'multi3' })
  t('the audit catches a cut at or past the runtime',
    overrun.checks.some((c) => /Every timecode inside the 10s window/.test(c[1]) && !c[0]))
  const shortTail = scoreH3({ ...good, integrated_multimodal_description: 'Shot on 35mm, a 10-second clip. [Shot 1] She walks. [Shot 2] At 00:03.333 the camera cuts closer. [Shot 3] At 00:09.200 the camera cuts wide for a beat.' }, { duration: 10, structure: 'multi3' })
  t('the audit catches a last shot too short to read',
    shortTail.checks.some((c) => /Last shot runs to the end/.test(c[1]) && !c[0]))
  const wrongCount = scoreH3(good, { duration: 10, structure: 'single' })
  t('the audit catches a shot count that fights the chosen structure',
    wrongCount.checks.some((c) => /Shot count matches the clock \(1 shot, found 3\)/.test(c[1]) && !c[0]))
  const gabby = scoreH3({ ...good, integrated_multimodal_description: 'Shot on 35mm, a 10-second three-shot sequence. [Shot 1] She walks in. [Shot 2] At 00:03.333 the camera cuts to the collar and she says <d>English: The oversized collar frames the neck and holds the shoulders beautifully from every single angle in this light.</d> [Shot 3] At 00:06.667 the camera cuts wide as the hem settles.' }, { duration: 10, structure: 'multi3' })
  t('the audit catches a line too long for the shot it sits in',
    gabby.checks.some((c) => /Spoken lines fit their shots/.test(c[1]) && !c[0]))
  const nude = scoreH3({ ...good, integrated_multimodal_description: 'Shot on 35mm, a 10-second clip. [Shot 1] She wears a wool coat and the clip ends with her fully nude beneath it.' }, { duration: 10, structure: 'single' })
  t('the audit catches a prompt that contradicts its own wardrobe',
    nude.checks.some((c) => /Wardrobe reads consistently/.test(c[1]) && !c[0]))

  /* the library keeps its own house rule: hardcoded example times must fit the pinned runtime */
  const bad = []
  for (const f of scanTemplates(join(ROOT, 'public/prompts/templates'))) {
    for (const tp of parseTemplatesMd(readFileSync(join(ROOT, 'public/prompts/templates', f.rel), 'utf8'))) {
      const tc = timecodes(tp.b)
      if (!tc.length) continue
      const d = (tp.settings && tp.settings.duration) || 0
      const last = Math.max(...tc)
      if (d && (last >= d || d - last < 1.4)) bad.push(tp.t)
    }
  }
  t('no template ships example cut times that overrun its own pinned duration', bad.length === 0)
  const lintBad = lintTemplate({ t: 'x', fmt: 'h3', b: 'integrated_multimodal_description: a 6-second clip. [Shot 1] One. [Shot 2] At 00:05.500 two.\\n\\noverall_soundscape: room.\\n\\nnon_diegetic_music: N/A', settings: { duration: 6 } })
  t('the linter warns when a skeleton\'s clock fights its pinned duration',
    lintBad.checks.some((c) => /leaves only/.test(c.label) && c.level === 'warn'))
}

/* ---------- 11l · Templates in subfolders ---------- */
H('11l · Subfolder templates')
{
  const TS = join(ROOT, 'public/prompts/templates')

  /* --- the one scanner every tool uses --- */
  const dir = mkdtempSync(join(tmpdir(), 'cps-tpl-'))
  const put = (rel, s) => { mkdirSync(join(dir, rel.split('/').slice(0, -1).join('/')), { recursive: true }); writeFileSync(join(dir, rel), s) }
  put('root.md', '# a')
  put('medical/moa.md', '# b')
  put('medical/deep/notes.md', '# c')
  put('a/b/c/d/e/f.md', '# too deep')
  put('medical/README.md', '# skip me')
  put('_draft.md', '# skip me too')
  put('.hidden.md', '# and me')
  const found = scanTemplates(dir).map((f) => f.rel)
  t('the scan is recursive (a nested .md is a template)', found.includes('medical/moa.md') && found.includes('medical/deep/notes.md'))
  t('README / _ / dotfiles are skipped at every depth', !found.some((f) => /README|^_|\.hidden/.test(f)))
  t('the depth cap stops a runaway tree', !found.includes('a/b/c/d/e/f.md') && found.includes('root.md'))
  t('the scan reports the folder of every file',
    scanTemplates(dir).every((f) => typeof f.folder === 'string') &&
    scanTemplates(dir).find((f) => f.rel === 'medical/deep/notes.md').folder === 'medical/deep')
  t('_folders.json lists root first, then folders alphabetically', (() => {
    const f = templateFolders(scanTemplates(dir))
    return f[0] === '' && f.indexOf('medical') > 0 && f.indexOf('medical/deep') > f.indexOf('medical')
  })())

  /* --- paths the browser can fetch --- */
  t('a nested path becomes a fetchable URL with the folder kept',
    templateUrl('medical/moa.md') === 'prompts/templates/medical/moa.md' &&
    templateUrl('my folder/a b.md') === 'prompts/templates/my%20folder/a%20b.md' &&
    templateUrl('core.md') === 'prompts/templates/core.md')
  t('yours = any file inside a subfolder, or named user*',
    !isUserTemplate('core.md') && isUserTemplate('medical/moa.md') &&
    isUserTemplate('starter/subfolder-demo.md') && isUserTemplate('user-x.md') && isUserTemplate('user/looks.md'))
  const meta = withFileMeta([{ t: 'A' }, { t: 'B' }], 'medical/moa.md')
  t('parsed blocks carry their file + folder on every block',
    meta.length === 2 && meta.every((x) => x.file === 'medical/moa.md' && x.folder === 'medical' && x.src === 'user'))
  t('a root file stays a built-in', withFileMeta([{ t: 'C' }], 'core.md')[0].src === 'builtin' && withFileMeta([{ t: 'C' }], 'core.md')[0].folder === '')

  /* --- the loader keeps the path (this is what used to flatten it) --- */
  const lib = read('src/lib/templates.js')
  t('the loader fetches by relative path, never by bare filename',
    /const rel = String\(f\)\.replace/.test(lib) && /fetch\(templateUrl\(rel\)/.test(lib) &&
    !/fetch\('prompts\/templates\/' \+ encodeURIComponent\(name\)/.test(lib))
  t('the loader stamps file + folder metadata on every block', /withFileMeta\(arr, rel\)/.test(lib))
  t('the source line names the subfolders it scanned', /subfolder' \+ \(folderList\.length === 1/.test(lib))
  t('subfolders are discovered even when the served index is flat (the tree route of every config version)',
    /listTemplateSources/.test(lib) && /prompts\/_tree\.json/.test(lib) && /nestedSupported/.test(lib) && /flatIndexWarning/.test(lib))

  /* --- updates can never eat a folder tree --- */
  t('anything inside a templates subfolder is protected from replacement',
    isProtected('public/prompts/templates/medical/moa.md') && isProtected('public/prompts/templates/starter/subfolder-demo.md') &&
    isProtected('public/prompts/templates/a/b/c.md'))
  t('root files and app code are still shippable', !isProtected('public/prompts/templates/core.md') && !isProtected('src/lib/templates.js'))

  /* --- the shipped library proves it end to end --- */
  const real = scanTemplates(TS)
  t('this repo ships a working subfolder example', real.some((f) => f.rel === 'starter/subfolder-demo.md'))
  t('the templates index carries the nested path', templateIndex(TS).includes('starter/subfolder-demo.md'))
  /* Built-ins must all parse; a notes file someone drops in a folder must simply be
     ignored (listed by the scan, zero blocks, no warning) — never a broken library. */
  t('every built-in file parses into blocks (no silent skips)',
    real.filter((f) => !isUserTemplate(f.rel)).every((f) => parseTemplatesMd(readFileSync(join(TS, f.rel), 'utf8')).length > 0))
  put('notes/plain.md', 'just some notes about this folder, no ## heading')
  const notes = scanTemplates(dir).find((f) => f.rel === 'notes/plain.md')
  t('a notes file in a subfolder yields no blocks — and the app says so instead of hiding it',
    !!notes && parseTemplatesMd(readFileSync(join(dir, 'notes/plain.md'), 'utf8')).length === 0 &&
    /fileNotes\.push\(\{ file: rel/.test(read('src/lib/templates.js')) &&
    /gave no templates/.test(read('src/lib/templates.js')))

  /* --- the tools that must agree about the folder --- */
  const audit = read('scripts/audit-prompts.mjs')
  t('the audit scans recursively too', /scanTemplates\(tplDir\)/.test(audit) && /Subfolders scanned/.test(audit))
  t('the build writes a recursive index and a folder list', (() => {
    const v = read('vite.config.js')
    return /templateIndex\(dir\)/.test(v) && /_folders\.json/.test(v) && /per-folder indexes/.test(v)
  })())

  /* --- the UI surfaces it --- */
  t('the picker filters by folder and searches the folder name',
    /const \[fold, setFold\] = useState\('All'\)/.test(read('src/components/TemplatePickerModal.jsx')) &&
    /fold === 'All' \|\| \(t\.folder \|\| ''\) === fold/.test(read('src/components/TemplatePickerModal.jsx')) &&
    /\+ \(t\.folder \|\| ''\)\)\.toLowerCase\(\)\.includes/.test(read('src/components/TemplatePickerModal.jsx')))
  t('the Templates page filters by folder as well',
    /All folders \(\{folders\.length\}\)/.test(read('src/components/TemplatesSection.jsx')) &&
    /tp\.folder \? '📁 ' \+ tp\.folder/.test(read('src/components/TemplatesSection.jsx')))
  t('every card shows which subfolder a template came from',
    /📁 \{t\.folder\}/.test(read('src/components/TemplateCard.jsx')))
  t('the templates README documents the folder layout', /## Subfolders \(v2\.7\)/.test(read('public/prompts/templates/README.md')))
}

/* ---------- 11m · The colour wheels — filler, instant engine, pools ---------- */
H('11m · Colour variety (no silent ivory)')
{
  /* --- the bank itself --- */
  t('the bank ships twelve families and exactly one deliberate pale look',
    FAMILY_COUNT === 12 && COLOUR_FAMILIES.filter((f) => f.pale).length === 1)
  t('no family opens on a pale base — ivory is only ever trim here',
    COLOUR_FAMILIES.every((f) => !isPaleLed(f.base)) &&
    COLOUR_FAMILIES.filter((f) => WHITE_WORDS.test(f.look)).length <= 2)
  t('every family carries a finish, a fabric and hardware (a colour alone is not a wardrobe)',
    COLOUR_FAMILIES.every((f) => f.finish && f.fabric && f.hardware && f.look))
  t('the wheel wraps both ways', familyAt(12).name === familyAt(0).name && familyAt(-1).name === familyAt(11).name)
  t('a colour the user already named is read back out of the idea',
    namedColourOf('a woman wearing a crimson lehenga') === 'crimson' &&
    namedColourOf('shot in a bottle green coat') === 'bottle green' &&
    namedColourOf('a bride in ivory silk') === 'ivory' && namedColourOf('no colour named here') === '')
  t('generic words are not colour names ("give the outfit colour" is a request, not a choice)',
    !COLOUR_NAMES.test('please give the outfit colour and a two-tone look') && !COLOUR_NAMES.test('a monochrome portrait'))

  /* --- the offline filler --- */
  const f = createFiller()
  const fills = []
  for (let i = 0; i < 12; i++) fills.push(f.fill(['OUTFIT COLOUR'], 'a woman walks through a studio')['OUTFIT COLOUR'])
  t('twelve presses give twelve different colour families',
    new Set(fills.map((v) => v.split(/[,]/)[0])).size === 12)
  t('only one of the twelve is pale — ivory never arrives as the default',
    fills.filter((v) => WHITE_WORDS.test(v.split(',')[0])).length === 1)
  t('every filled colour carries a finish (not just a shade)',
    fills.every((v) => /(finish|face|crepe|satin|flannel|poplin|weave|matte|lacquered)/i.test(v)))
  const two = f.fill(['OUTFIT COLOUR', 'GARMENT FABRIC'], 'a woman in a hall')
  t('two colour tokens in one ask get two different families',
    two['OUTFIT COLOUR'].split(' ').slice(0, 3).join(' ') !== two['GARMENT FABRIC'].split(' in ').pop().split(',')[0].split(' ').slice(0, 3).join(' '))
  t('an idea that names a colour is echoed, never rivalled',
    createFiller().fill(['OUTFIT COLOUR'], 'a woman in a crimson silk lehenga')['OUTFIT COLOUR'].startsWith('crimson'))
  t('an idea that names white is respected, not "fixed" into colour',
    createFiller().fill(['OUTFIT COLOUR'], 'a bride in ivory silk on her wedding day')['OUTFIT COLOUR'].startsWith('ivory'))
  t('the wheel advances between asks, so pressing ✨ Suggest again gives a new palette', (() => {
    const g = createFiller(0)
    const a = g.rotate(), b = g.rotate()
    return a !== b
  })())
  t('the rotation brief names the starting family, the whole wheel and the two hard rules', (() => {
    const b = rotationBrief(2)
    return /begin at family bottle green \(family #3 of 12\)/.test(b) &&
      FAMILY_COUNT === (b.match(/ · /g) || []).length + 1 &&
      /NEVER answer with white, ivory, cream/.test(b) && /each a DIFFERENT family/.test(b)
  })())

  /* --- 11m-bis · the wheel must be able to reach all twelve families, and must remember --------
     Two bugs made ✨ Suggest look stuck on terracotta (v2.11): the step was 3 against 12 families
     (gcd = 3 → only four families were ever reachable, and a fresh session's first press landed on
     family #4 = terracotta), and the position was reset on every mount. */
  const gcd = (a, b) => (b ? gcd(b, a % b) : a)
  t('the ask step is coprime with the wheel, so repeated presses reach every family',
    gcd(COLOUR_STEP, FAMILY_COUNT) === 1 && COLOUR_STEP > 1 && COLOUR_STEP < FAMILY_COUNT)
  t('the old step of 3 could only ever reach four of the twelve families (the reported symptom)',
    new Set([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((i) => familyAt(i * 3).name)).size === 4 &&
    familyAt(3).name === 'terracotta')
  t('twelve presses from one session visit all twelve families', (() => {
    const g = createFiller(0)
    const seen = new Set()
    for (let i = 0; i < FAMILY_COUNT; i++) {
      g.rotate(COLOUR_STEP)
      seen.add(g.fill(['OUTFIT COLOUR'], 'a woman in a bright room')['OUTFIT COLOUR'].split(' with ')[0].split(',')[0])
    }
    return seen.size === FAMILY_COUNT
  })())
  t('twelve presses from ANY start visit all twelve families (the step is a generator)', (() => {
    for (let s = 0; s < FAMILY_COUNT; s++) {
      const seen = new Set()
      for (let i = 0; i < FAMILY_COUNT; i++) seen.add(familyAt(s + i * COLOUR_STEP).name)
      if (seen.size !== FAMILY_COUNT) return false
    }
    return true
  })())
  t('drawing two tokens inside one answer does not eat into the next press\'s step', (() => {
    const g = createFiller(0)
    g.rotate(COLOUR_STEP)
    const a = g.fill(['OUTFIT COLOUR', 'GARMENT FABRIC'], 'a woman in a hall')
    const afterTwo = g.rot
    const g2 = createFiller(0)
    g2.rotate(COLOUR_STEP)
    g2.fill(['OUTFIT COLOUR'], 'a woman in a hall')
    return afterTwo === g2.rot && !!a['GARMENT FABRIC']
  })())
  /* the wheel remembers across mounts — this is what the app does on every page load */
  const memShim = (() => {
    const store = new Map()
    return {
      store,
      install() { globalThis.localStorage = { getItem: (k) => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)), removeItem: (k) => store.delete(k) } },
      restore() { delete globalThis.localStorage },
    }
  })()
  memShim.install()
  try {
    forgetColourWheel()
    const openings = []
    for (let session = 0; session < 6; session++) {
      const g = createFiller()               /* exactly what StudioForm does on mount */
      g.rotate(COLOUR_STEP)
      openings.push(g.fill(['OUTFIT COLOUR'], 'a woman walks into a bright room')['OUTFIT COLOUR'].split(' with ')[0].split(',')[0])
    }
    tW('six separate sessions open on six different families (the position is remembered)',
      new Set(openings).size === 6)
    tW('no session opens on the family the last one just used', openings.every((o, i) => i === 0 || o !== openings[i - 1]))
    const g = createFiller()
    const remembered = FILLER_CURRENT ? JSON.parse(memShim.store.get(COLOUR_MEMORY_KEY)) : { rot: null, last: null }
    tW('the remembered position is stored with the family it last handed out',
      typeof remembered.rot === 'number' && !!remembered.last && g.rot === remembered.rot)
    tW('a fresh install with no memory still starts somewhere clock-dependent, not at family #4',
      (() => {
        memShim.store.clear()
        const a = createFiller()
        memShim.store.clear()
        return typeof a.rot === 'number' && a.rot >= 0 && a.rot < FAMILY_COUNT
      })())
    tW('the wheel can be forgotten (console + tests)', (() => { forgetColourWheel(); return memShim.store.get(COLOUR_MEMORY_KEY) === undefined })())
    /* the instant engine draws from the same wheel and also remembers */
    memShim.store.clear()
    const engineFams = []
    for (let i = 0; i < 5; i++) {
      const v = await genVariantOffline({ style: 'Auto', camera: 'Auto', amp: 'small', speed: 'slow', ratio: '16:9', resolution: '2K', duration: 8, structure: 'single', music: 'subtle', palette: 'Auto', loop: false, detail: true, idea: 'a woman walks a marble hall' }, 1, 5)
      const m = v.integrated_multimodal_description.match(/WARDROBE: the garment reads ([^.]+?), (?:with|on)/)
      engineFams.push(m ? m[1] : '?')
    }
    tW('regenerating the same idea five times gives five different families in the engine',
      new Set(engineFams).size === 5)
  } finally { memShim.restore() }
  t('the rotation brief tells the model which family its last answer used',
    (() => {
      const b = rotationBrief(2, 'terracotta')
      return /Your PREVIOUS answer used the terracotta family/.test(b) && /do NOT reuse it/i.test(b)
    })())

  /* --- the LLM filler prompt says the same thing --- */
  const phf = read('public/prompts/placeholder-filler.md')
  t('the filler prompt bans the pale default in its own words',
    /Never answer with white, ivory, cream, ecru, pearl, chalk, bone/.test(phf) && /silent default, not a decision/.test(phf))
  t('it carries the wheel and the rotation rule',
    /oxblood/.test(phf) && /cobalt/.test(phf) && /burnished copper/.test(phf) && /Rotate, never repeat/.test(phf) && /DIFFERENT family/.test(phf))
  t('it keeps a colour the user already chose', /If the IDEA already names a colour, keep it exactly/.test(phf))
  t('it demands a finish and hardware, not a bare shade', /colour family and a finish/.test(phf) && /hardware/.test(phf))
  t('it keeps one palette per answer (warm with warm, cool with cool)', /One palette per answer/.test(phf))

  /* --- the app wires the wheel into both filler paths --- */
  const sf = read('src/components/StudioForm.jsx')
  t('the in-code filler fallback carries the same ban and wheel',
    /never answer a colour with white, ivory, cream, ecru, pearl, chalk or bone/.test(sf) &&
    /COLOUR_FAMILIES\.map\(\(f\) => f\.name\)/.test(sf))
  t('the offline path passes the idea, so a named colour survives',
    (sf.match(/filler\.fill\(tokens, f\.idea\)/g) || []).length === 3)
  t('the LLM path receives the rotation and advances it between asks',
    /filler\.rotate\(COLOUR_STEP\)/.test(sf) && /rotationBrief\(filler\.rot, filler\.lastFamily\)/.test(sf) && /colourTokensOf\(tokens\)/.test(sf))
  t('the filler holds no colour values of its own — every colour comes from the wheel', (() => {
    const src = read('src/lib/filler.js')
    const pool = src.slice(src.indexOf('export const OFF_POOL'), src.indexOf('export const OFF_GENERIC'))
    const codes = src.split('\n').filter((l) => !/^\s*(\/\*|\*|\/\/)/.test(l)).join('\n')
    /* "blue dusk" (a time of day) is fine in the time pool; no garment colour may live in a literal */
    return !/ivory|white|cream|oxblood|cobalt|terracotta|navy|ochre|plum|copper|tomato|slate|crimson/i.test(pool) &&
      /createFiller/.test(src) && !/'ivory'/.test(codes)
  })())

  /* --- the instant engine (no LLM) spreads the palette across a batch --- */
  const baseIdea = { style: 'Auto', camera: 'Auto', amp: 'small', speed: 'slow', ratio: '16:9', resolution: '2K', duration: 8, structure: 'single', music: 'subtle', palette: 'Auto', loop: false, detail: true, idea: 'a woman walks a marble hall' }
  const fams = []
  for (let k = 1; k <= 6; k++) {
    const v = await genVariantOffline(baseIdea, k, 6)
    const m = v.integrated_multimodal_description.match(/WARDROBE: the garment reads ([^.]+?), (?:with|on)/)
    fams.push(m ? m[1] : '?')
  }
  t('six variants of one idea wear six different colour families', new Set(fams).size === 6)
  t('at most one of the six can lean pale, and only because that family is flagged pale',
    fams.filter((x) => WHITE_WORDS.test(x)).length <= 1 &&
    fams.filter((x) => WHITE_WORDS.test(x)).every((x) => /powder blue/i.test(x)))
  const offNamed = await genVariantOffline({ ...baseIdea, idea: 'a woman in an ivory silk sari walks a marble hall' }, 1, 1)
  const namedLine = /WARDROBE:[^\n]*/.exec(offNamed.integrated_multimodal_description) || ['']
  t('a named pale colour is still respected — the engine names layers, never a rival colour',
    /the same ivory/.test(namedLine[0]) && /closed layer stack/.test(namedLine[0]) &&
    !/oxblood|cobalt|bottle green|terracotta|ink navy|deep plum|copper|tomato|slate|powder blue/i.test(namedLine[0]))

  /* --- the variation pool the batch rotates through --- */
  const pools = read('public/prompts/fashion-variation.md')
  const csec = (pools.split(/^## OUTFIT COLOUR$/m)[1] || '').split(/^## /m)[0]
  const opts = csec.split(/\n/).filter((l) => /^\d+\. /.test(l))
  t('the OUTFIT COLOUR pool ships 12 families and none opens pale',
    opts.length >= 12 && opts.filter((l) => isPaleLed(l)).length === 0)
  t('the pool states the rule in plain words',
    /White, ivory and cream are choices, never defaults/.test(csec) && /the base is always a colour/.test(csec))
}

/* ---------- 11n · Finding your file — index, tree, folders, diagnostics ---------- */
H('11n · "Why is my template not listed?"')
{
  const realFetch = globalThis.fetch
  /* A tiny fetch stub: { 'path': { json: … } | { text: … } | 'missing' } */
  const shim = (routes) => async (u) => {
    const key = String(u).replace(/^\//, '')
    const r = routes[key]
    if (r === undefined || r === 'missing') return new Response('nope', { status: 404 })
    if (r && r.json !== undefined) return new Response(JSON.stringify(r.json), { status: 200 })
    return new Response(String((r && r.text) || ''), { status: 200 })
  }
  const withShim = async (routes, fn) => { globalThis.fetch = shim(routes); try { return await fn() } finally { globalThis.fetch = realFetch } }

  /* A · an install whose vite.config.js predates the recursive index — the flat index, but the
        recursive prompts tree is there (it exists in every config version). */
  await withShim({
    'prompts/templates/_index.json': { json: ['core.md'] },
    'prompts/_tree.json': { json: ['templates/core.md', 'templates/starter/fashio_beat.md', 'banks/dialogue.md', 'templates/_hidden.md'] },
  }, async () => {
    const files = await listTemplateFiles()
    t('a flat index + the tree route still finds subfolder templates', files.includes('starter/fashio_beat.md'))
    t('the tree source is filtered to templates/ and to real files', !files.includes('banks/dialogue.md') && !files.includes('_hidden.md'))
  })

  /* B · a built copy: the recursive index alone is enough */
  await withShim({ 'prompts/templates/_index.json': { json: ['core.md', 'medical/moa.md'] } }, async () => {
    const files = await listTemplateFiles()
    t('a recursive index alone lists a nested file', files.includes('medical/moa.md'))
  })

  /* C · index named by hand: _folders.json + each folder's own _index.json */
  await withShim({
    'prompts/templates/_folders.json': { json: ['', 'bridal'] },
    'prompts/templates/bridal/_index.json': { json: ['sangeet.md'] },
  }, async () => {
    const files = await listTemplateFiles()
    t('a hand-written folder list works as the last resort', files.includes('bridal/sangeet.md'))
  })

  /* D · nothing served at all → the app must not pretend subfolders work */
  await withShim({}, async () => {
    const scan = await listTemplateSources()
    t('with no index at all the app reports nested folders as unreadable',
      scan.files.length === 0 && scan.indexSeen === false && scan.nestedSupported === false)
  })

  /* E · a file that is scanned but has no template in it is REPORTED, never silently ignored */
  await withShim({
    'prompts/templates/_index.json': { json: ['notes.md'] },
    'prompts/templates/notes.md': { text: 'just some notes about this shoot, no heading, no skeleton' },
  }, async () => {
    const res = await loadTemplates()
    t('a scanned file with no blocks comes back as a named note',
      res.list.length === 0 && res.fileNotes.length === 1 && res.fileNotes[0].file === 'notes.md' &&
      /needs a "## Title"/.test(res.fileNotes[0].note))
    t('the source line counts it, so the header never lies', /1 file gave no templates/.test(res.source))
  })

  /* F · the same file, written properly → listed, folder and all */
  await withShim({
    'prompts/templates/_index.json': { json: ['starter/my.md'] },
    'prompts/templates/starter/my.md': { text: '## My look\nmodel: h3\nduration: 8\n\n```\nintegrated_multimodal_description: a woman walks in\n\noverall_soundscape: room tone.\n\nnon_diegetic_music: N/A\n```\n' },
  }, async () => {
    const res = await loadTemplates()
    t('the same content with a title + skeleton is listed, in its folder',
      res.list.length === 1 && res.list[0].t === 'My look' && res.list[0].folder === 'starter' && res.fileNotes.length === 0)
  })

  /* G · diagnostics + UI surfacing */
  const lib = read('src/lib/templates.js')
  t('the browser exposes a diagnostic that names every file, its folder and its blocks',
    /export async function templateDiagnostics/.test(lib) && /window\.cpsTplDiag/.test(read('src/App.jsx')) &&
    /console\.table/.test(read('src/App.jsx')))
  t('the picker and the Templates page show the file notes',
    /fileNotes && fileNotes\.length/.test(read('src/components/TemplatePickerModal.jsx')) &&
    /tplNotes/.test(read('src/components/LearnSection.jsx')) && /notes && notes\.length/.test(read('src/components/TemplatesSection.jsx')))
  t('the guide explains the check order', /A file of mine is not listed/.test(read('src/components/GuideSection.jsx')))
  t('a flat index in a live copy warns instead of staying quiet',
    /flatIndexWarning/.test(lib) && /subfolders unreadable in this copy/.test(lib))

  /* H · the shape of a real user file (fences + an outer ```markdown wrapper + two blocks) */
  const fixture = read('scripts/fixtures/user-fashio-beat.md')
  const parsed = parseTemplatesMd(fixture)
  t('the owner\'s real file shape parses into its two blocks with nothing skipped',
    parsed.length === 2 && parseTemplatesMd.skipped === 0 &&
    parsed[0].t === 'New Room outfit tour — adaptive beats_old' &&
    parsed[1].t === 'Any Location outfit tour — adaptive beats all dynamic')
  t('its dynamic flows, placeholders and duration survive the trip',
    parsed.every((b) => b.settings.duration === 8 && b.fmt === 'h3') && parsed[0].flows.length === 6 &&
    /\{OUTFIT/.test(parsed[0].idea) && /integrated_multimodal_description:/.test(parsed[0].b))
}

/* ---------- 11o · Layer completeness — a garment is never alone ---------- */
H('11o · Layer stack — no missing bottoms, no missing under-layers')
{
  /* doctrine: every system prompt resolves the closed-stack rule (it lives in the shared file) */
  const craft = read('public/prompts/shared/craft-detail-and-cast.md')
  t('the shared doctrine states the closed stack in plain words',
    /THE STACK IS ALWAYS CLOSED/.test(craft) && /A jacket, blazer, coat, corset, kaftan or sheer overlay is NEVER worn alone/.test(craft) &&
    /an unstated layer is a missing layer/.test(craft))
  t('the four system prompts still pull that doctrine in (one file, no copies)',
    ['system-prompt', 'system-prompt-mature', 'ltx-system-prompt', 'ltx-system-prompt-mature']
      .every((n) => /^@include shared\/craft-detail-and-cast\.md$/m.test(read('public/prompts/' + n + '.md'))))
  const pack = read('public/prompts/packs/fashion.md')
  t('the fashion pack carries the six-layer checklist and the special cases',
    /Layer stack — an outfit is never one garment/.test(pack) && /Base layer/.test(pack) && /Main piece/.test(pack) &&
    /Bottom or lower half/.test(pack) && /Outer layer/.test(pack) && /swimwear and lingerie are described as the complete piece set/i.test(pack))
  const exp = read('public/prompts/fashion-outfit-expander.md')
  t('the expander closes the stack without touching its output contract',
    /LAYER COMPLETENESS — THE STACK IS CLOSED, ALWAYS/.test(exp) && /An outer never appears alone/.test(exp) &&
    /4b\. The stack is closed/.test(exp) && /OUTPUT CONTRACT — ONE LINE, NOTHING ELSE/.test(exp))
  t('the LLM filler is told a garment is never alone', /A garment is never alone/.test(read('public/prompts/placeholder-filler.md')))
  t('the OUTFIT DESIGN pool states the rule and its coat option carries its trousers',
    /Every option here is a complete stack/.test(read('public/prompts/fashion-variation.md')) &&
    /oversized double-breasted coat[^\n]*wide-leg oxblood trousers/.test(read('public/prompts/fashion-variation.md')))

  /* the linter: the three real failure modes, and silence when the stack is complete */
  const mk = (b, tag = 'fashion', category = 'Fashion / Lifestyle', title = 'Synthetic look') =>
    ({ t: title, tag, category, prompt: '', b, flows: null, settings: { category, structure: 'single', duration: 6 } })
  const lay = (x) => lintTemplate(x, null).checks.find((c) => /Layering completeness/.test(c.label))
  const jacket = lay(mk('integrated_multimodal_description: Shot on a 50mm. A woman in a structured wool jacket walks through the room, hands in the lapels. TIMING: 6s, one take.'))
  t('a jacket with nothing under or below it is flagged', !!jacket && jacket.level === 'warn' && /outer layer with no bottom/.test(jacket.hint))
  const blouse = lay(mk('integrated_multimodal_description: Shot on a 50mm. A woman in a silk blouse adjusts a cuff, the window light on the fabric. TIMING: 6s, one take.'))
  t('a top with no bottom is flagged', !!blouse && blouse.level === 'warn' && /a top with no bottom/.test(blouse.hint))
  const sheer = lay(mk('integrated_multimodal_description: Shot on a 50mm. A woman in a sheer organza dress turns in the light. TIMING: 6s, one take.'))
  t('something sheer with nothing named under it is flagged', !!sheer && sheer.level === 'warn' && /nothing named under it/.test(sheer.hint))
  const complete = lay(mk('integrated_multimodal_description: Shot on a 50mm. A woman in a silk camisole under a wool blazer, wide-leg trousers and leather loafers, turns in the light. TIMING: 6s, one take.'))
  t('a complete stack passes', !!complete && complete.level === 'ok')
  t('a non-fashion block never gets the check at all', (() => {
    const x = lintTemplate(mk('integrated_multimodal_description: Shot on a 200mm. A fishing boat crosses the swell at dawn, a green jacket on the rail. TIMING: 8s, one take.', 'documentary', 'Documentary', 'Harbour dawn'), null)
    return !x.checks.some((c) => /Layering completeness/.test(c.label))
  })())

  /* the whole shipped library must be clean — this is the pin that keeps it that way */
  const bad = []
  const allT = []
  for (const f of scanTemplates(join(ROOT, 'public/prompts/templates'))) for (const b of parseTemplatesMd(readFileSync(f.abs, 'utf8'))) allT.push(b)
  for (const b of allT) {
    const c = lintTemplate(b, allT).checks.find((c) => /Layering completeness/.test(c.label) && c.level === 'warn')
    if (c) bad.push(b.t + ' (' + c.hint.split('.')[0] + ')')
  }
  t('no shipped template leaves a layer to the renderer (' + allT.length + ' blocks checked)' + (bad.length ? ' → ' + bad.join(' | ') : ''), bad.length === 0)

  /* the instant engine: the wardrobe line states the whole stack, and a named colour is echoed */
  const store11o = new Map()
  globalThis.localStorage = { getItem: (k) => (store11o.has(k) ? store11o.get(k) : null), setItem: (k, v) => store11o.set(k, String(v)), removeItem: (k) => store11o.delete(k) }
  try {
    forgetColourWheel()
    const base = { style: 'Auto', camera: 'Auto', amp: 'small', speed: 'slow', ratio: '16:9', resolution: '2K', duration: 8, structure: 'single', music: 'subtle', palette: 'Auto', loop: false, detail: true }
    const plain = await genVariantOffline({ ...base, idea: 'a woman walks a marble hall' }, 1, 1)
    const line = (/WARDROBE:[^\n]*/.exec(plain.integrated_multimodal_description) || [''])[0]
    /* v2.20 — coverage follows exposure: a closed look gets the bottom and the shoes and NO
       innerwear at all, and only a look that actually shows skin gets a base layer named. */
    t('a closed look gets no innerwear from the engine — bottom and shoes only',
      /closed layer stack/.test(line) && !/under it/.test(line) &&
      !/camisole|bodysuit|bralette|brief|base layer/i.test(line) &&
      /(trousers|skirt|shorts)/.test(line) && /(heels|sandals|loafers|mules|juttis)/.test(line))
    const sheerV = await genVariantOffline({ ...base, idea: 'a woman in a sheer organza dress turns in the light' }, 1, 1)
    const sheerLine = (/WARDROBE:[^\n]*/.exec(sheerV.integrated_multimodal_description) || [''])[0]
    t('a look that shows skin does get its base layer named — and keeps its own lower half',
      /under it/.test(sheerLine) && /camisole|bodysuit|bralette|vest/i.test(sheerLine) && /its own lower half/.test(sheerLine))
    const intimateV = await genVariantOffline({ ...base, idea: 'a woman in a black lace lingerie set on the bed' }, 1, 1)
    const intimateLine = (/WARDROBE:[^\n]*/.exec(intimateV.integrated_multimodal_description) || [''])[0]
    t('intimate wear is the outfit itself — no base named and no bottom invented over it',
      /the set itself/.test(intimateLine) && !/camisole|bodysuit|bralette|brief|base layer/i.test(intimateLine) &&
      !/a bottom in|own lower half|skirt|trousers|shorts/i.test(intimateLine))
    const named = await genVariantOffline({ ...base, idea: 'a woman in a crimson silk lehenga crosses the hall' }, 1, 1)
    const nline = (/WARDROBE:[^\n]*/.exec(named.integrated_multimodal_description) || [''])[0]
    t('a colour the user wrote is echoed into the missing layers, never rivalled',
      /the same crimson/.test(nline) && !/oxblood|cobalt|bottle green|terracotta|ink navy|deep plum/i.test(nline))
    const land = await genVariantOffline({ ...base, idea: 'a lighthouse in a storm, waves on the rocks' }, 1, 1)
    t('scenes with no wardrobe get no stack at all', !/WARDROBE/.test(land.integrated_multimodal_description))
    const stacks = []
    for (const idea of ['a woman in a sheer organza dress turns in the light', 'a woman in a mesh top stands by the window', 'a woman in a backless satin gown walks in']) {
      const v = await genVariantOffline({ ...base, idea }, 1, 1)
      stacks.push((/closed layer stack — ([^,]+),/.exec(v.integrated_multimodal_description) || ['', ''])[1])
    }
    t('where a base layer is needed, the pieces still rotate look to look', new Set(stacks).size >= 2, stacks.join(' | '))
    const bottoms = []
    for (const idea of ['a woman walks a hall', 'a woman stands by a window', 'a woman turns in a studio']) {
      const v = await genVariantOffline({ ...base, idea }, 1, 1)
      bottoms.push((/closed layer stack — ([^,]+),/.exec(v.integrated_multimodal_description) || ['', ''])[1])
    }
    t('the bottoms rotate too, so consecutive closed looks differ', new Set(bottoms).size >= 2, bottoms.join(' | '))
  } finally { delete globalThis.localStorage }
  t('barefoot is a choice, never a filler default', !/barefoot by the request/.test(read('src/lib/colourbank.js')))
}

/* ---------- 11p · The wearer is in frame — jewellery beats open on her ---------- */
H('11p · Jewellery: the wearer is in frame')
{
  /* doctrine — one shared file, so all four system prompts carry it */
  const craft = read('public/prompts/shared/craft-detail-and-cast.md')
  t('the shared doctrine puts the wearer in frame for ornament beats',
    /JEWELLERY, ACCESSORIES & DETAIL BEATS — THE WEARER IS IN FRAME/.test(craft) &&
    /is shot ON the person/.test(craft) && /no cut ever shows the piece alone on a surface/.test(craft))
  t('the four system prompts still pull that file in (no copies to drift)',
    ['system-prompt', 'system-prompt-mature', 'ltx-system-prompt', 'ltx-system-prompt-mature']
      .every((n) => /^@include shared\/craft-detail-and-cast\.md$/m.test(read('public/prompts/' + n + '.md'))))
  const pack = read('public/prompts/packs/fashion.md')
  t('the fashion pack carries the three rungs and the ban on the orphan macro',
    /Jewelry and accessories — the wearer is in frame/.test(pack) && /On her first/.test(pack) &&
    /In context next/.test(pack) && /True macro only after that, and still on her/.test(pack) &&
    /a floating macro of an ornament has no size and no wearer/.test(pack))
  t('the Forge teaches new jewellery templates the same thing',
    /Jewellery, accessory and detail-led templates open ON the wearer/.test(read('public/prompts/template-forge.md')))
  t('the ethnic ornament section keeps the wearer first', /the wearer comes first/.test(read('public/prompts/packs/ethnic.md')))
  const core = read('public/prompts/templates/core.md')
  t('the try-on opens on her and its PIECE-FIRST flow no longer floats the piece',
    /The film opens ON HER/.test(core) && !/macro of the piece alone on the tray first/.test(core) &&
    /the piece lifted in her hand out of the tray, then the fastening on her, then her/.test(core))

  /* the template itself */
  const blocks = []
  for (const f of scanTemplates(join(ROOT, 'public/prompts/templates'))) for (const b of parseTemplatesMd(readFileSync(f.abs, 'utf8'))) blocks.push(b)
  const lad = blocks.find((b) => /Jewellery macro ladder/.test(b.t || ''))
  t('the ladder template opens the film on the wearer', !!lad && /opens ON HER/.test(lad.d || '') && /SHE OPENS THE FILM/.test(lad.b))
  t('its first flow is the establishing frame and the macro-first flow is gone',
    !!lad && lad.flows && lad.flows[0] === 'FULL THEN LADDER' && lad.flows.includes('LADDER DOWN') &&
    lad.flows.includes('LADDER UP') && !lad.flows.includes('MACRO FIRST'))
  t('the opening framing is a placeholder, not a hard-coded wide',
    !!lad && /FRAMING — the first frame: full-length in the room, seated three-quarter, or knee-up in the doorway/.test(lad.b) &&
    (lad.idea || '').includes('opened on {FRAMING'))
  t('the rungs, the ban and the closing frame are all in the skeleton',
    !!lad && /THE LADDER DESCENDS AND IT NEVER LEAVES HER/.test(lad.b) && /NO ORPHAN MACRO/.test(lad.b) &&
    /anchored on her body/.test(lad.b) && /THE FILM ENDS ON HER/.test(lad.b) && /LAYER STACK:/.test(lad.b))
  t('it renders at 2K — the opening wide is where 768P loses the face', !!lad && lad.settings.resolution === '2K')
  t('the ladder block passes its own check', (() => {
    const c = lintTemplate(lad, null).checks.find((c) => /Wearer in frame/.test(c.label))
    return !!c && c.level === 'ok'
  })())

  /* the linter: the two real failure modes, and silence when she leads */
  const mk = (b, title = 'Synthetic jewellery', tag = 'fashion', category = 'Fashion / Lifestyle') =>
    ({ t: title, tag, category, prompt: '', b, flows: null, settings: { category, structure: 'single', duration: 6 } })
  const wear = (x) => lintTemplate(x, null).checks.find((c) => /Wearer in frame/.test(c.label))
  const macroFirst = wear(mk('integrated_multimodal_description: Shot on a 100mm macro. A hand lifts a gold pendant, the clasp opens at the back of the neck, deep shadow behind. TIMING: 6s, one take.', 'Jewellery macro test'))
  t('a jewellery block that opens on the piece is flagged for not establishing the wearer',
    !!macroFirst && macroFirst.level === 'warn' && /nothing establishes the wearer/.test(macroFirst.hint))
  const floated = wear(mk('integrated_multimodal_description: Shot on a 100mm macro. A woman stands three-quarter in the room; then the necklace alone on a velvet tray, then the ring on her hand. TIMING: 6s, one take.', 'Ornament tray test'))
  t('an orphan product macro is flagged even when the rest is anchored on her',
    !!floated && floated.level === 'warn' && /orphan macro/.test(floated.hint))
  const goods = wear(mk('integrated_multimodal_description: Shot on a 50mm wide and a 100mm macro. She stands full-length in the room, the whole set legible; then the choker over the neckline with her collarbone in frame; then the earring against the jaw. TIMING: 6s, one take.', 'Necklace story test'))
  t('a wearer-first jewellery film passes', !!goods && goods.level === 'ok')
  t('a non-jewellery block never gets the check at all',
    !lintTemplate(mk('integrated_multimodal_description: Shot on a 50mm. A woman in a wool coat crosses the yard, the wind in the fabric. TIMING: 6s, one take.', 'Quiet yard', 'fashion'), null)
      .checks.some((c) => /Wearer in frame/.test(c.label)))

  /* the whole library — every jewellery / ornament block must keep the rule */
  const bad = []
  let judged = 0
  for (const b of blocks) {
    const c = lintTemplate(b, blocks).checks.find((c) => /Wearer in frame/.test(c.label))
    if (!c) continue
    judged++
    if (c.level === 'warn') bad.push(b.t + ' → ' + c.hint.split('.')[0])
  }
  t('every shipped jewellery / ornament block opens on the wearer (' + judged + ' judged)' + (bad.length ? ' → ' + bad.join(' | ') : ''),
    judged >= 5 && bad.length === 0)
}

/* ---------- 11q · An older local copy of filler.js / colourbank.js must not kill the app ---------- */
H('11q · Tolerant links — an older local colour file cannot stop the app loading')
{
  /* the bridges degrade instead of throwing */
  const emptyCb = colourbankBridge({})
  t('a colourbank without the newer helpers reports itself incomplete instead of throwing',
    emptyCb.families.length === 0 && emptyCb.complete === false && emptyCb.familyAt(3) === null && emptyCb.namedColour('a red dress') === '')
  const partCb = colourbankBridge({ COLOUR_FAMILIES: [{ name: 'one' }, { name: 'two' }] })
  t('the fallback wheel still wraps and indexes',
    partCb.familyAt(3).name === 'two' && partCb.familyAt(-1).name === 'two' && partCb.complete === false)
  const emptyFb = fillerBridge({})
  t('a filler without the memory API degrades: no memory, no throw, a usable wheel',
    emptyFb.memory === false && emptyFb.read() === null && emptyFb.write(3, 'x') === undefined && emptyFb.step === 5 &&
    typeof emptyFb.create === 'function')
  const w = emptyFb.create()
  t('the stand-in wheel rotates, remembers its last family and fills every token it is given',
    typeof w.rot === 'number' && (() => {
      const a = w.rot
      const b = w.rotate(5)
      const values = w.fill(['OUTFIT COLOUR', 'GARMENT', 'ROOM'])
      return b !== a && w.lastFamily !== '' && Object.keys(values).length === 3 &&
        Object.values(values).every((v) => typeof v === 'string' && v.length > 4)
    })())
  t('the fallback token filter still knows a colour / fabric token when it sees one',
    fillerBridge({}).colourTokensOf(['OUTFIT COLOUR', 'SILK FABRIC', 'LOCATION']).length === 2)
  tF('a current copy is used verbatim — the bridge never second-guesses it',
    fillerBridge(fillerMod).memory === true && fillerBridge(fillerMod).step === fillerMod.COLOUR_STEP &&
    typeof fillerBridge(fillerMod).create === 'function' && colourbankBridge(colourbankMod).complete === true)
  tF('the wheel helper hands back a working wheel', typeof openColourWheel().wheel.fill === 'function' && openColourWheel().memory === true)
  tF('the shipped filler.js still carries every name the bridge looks for',
    typeof fillerMod.readColourMemory === 'function' && typeof fillerMod.writeColourMemory === 'function' &&
    typeof fillerMod.createFiller === 'function' && typeof fillerMod.colourTokensOf === 'function')

  /* the consumers link by namespace — a bare named import is the bug being fixed */
  const off = read('src/lib/offline.js'), sf = read('src/components/StudioForm.jsx')
  t('offline.js never imports a name straight out of filler.js or colourbank.js again',
    /import \* as fillerMod from '\.\/filler\.js'/.test(off) && !/import \{[^}]*\} from '\.\/filler\.js'/.test(off) &&
    /import \* as colourbankMod from '\.\/colourbank\.js'/.test(off) && !/import \{[^}]*\} from '\.\/colourbank\.js'/.test(off) &&
    /from '\.\/colourlink\.js'/.test(off))
  t('StudioForm links the same way', /import \* as fillerMod from '\.\.\/lib\/filler\.js'/.test(sf) &&
    !/import \{[^}]*\} from '\.\.\/lib\/filler\.js'/.test(sf) && /fillerBridge/.test(sf))
  t('the engine guards on the bridge state before it promises a wardrobe',
    /if \(!CB\.complete\) return ''/.test(off) && /const f = CB\.familyAt\(base\)\n  if \(!f\) return ''/.test(off))

  /* the instant engine still runs when the memory API is absent — the actual reported crash */
  {
    const { genVariantOffline } = await import('../src/lib/offline.js')
    const inp = { style: 'Auto', camera: 'Auto', amp: 'small', speed: 'slow', ratio: '16:9', resolution: '2K', duration: 8, structure: 'single', music: 'subtle', palette: 'Auto', loop: false, detail: true, idea: 'a woman walks through a market at dusk in a long coat' }
    const out = await genVariantOffline(inp, 1, 1)
    t('the instant engine still generates a full prompt when the wheel has no memory',
      !!out && typeof out.integrated_multimodal_description === 'string' &&
      out.integrated_multimodal_description.length > 200 && typeof out.overall_soundscape === 'string' &&
      out.engine === 'offline')
  }

  /* the patch report now names the files that import a conflicted one */
  const d2 = mkdtempSync(join(tmpdir(), 'cps-dep-'))
  mkdirSync(join(d2, 'src/lib'), { recursive: true })
  writeFileSync(join(d2, 'src/lib/offline.js'), "import { x } from './b.js'\nexport const y = x\n")
  writeFileSync(join(d2, 'src/lib/b.js'), 'my older copy')
  const sha = (s) => createHash('sha256').update(s).digest('hex')
  const zp = join(d2, 'p.zip')
  writeFileSync(zp, writeZip([
    { name: 'manifest.json', data: Buffer.from(JSON.stringify({ version: 'v-dep', files: { 'src/lib/offline.js': null, 'src/lib/b.js': sha('what we shipped') } })) },
    { name: 'files/src/lib/offline.js', data: Buffer.from("import { x } from './b.js'\nexport const y = x\n") },
    { name: 'files/src/lib/b.js', data: Buffer.from('the new copy') },
  ]))
  const r2 = await applyPatch(zp, { root: d2, quiet: true })
  t('a conflict on a file other patch files import is called out in the report',
    /Needs your eye/.test(r2.report) && /src\/lib\/b\.js\.new/.test(r2.report) &&
    /src\/lib\/offline\.js/.test(r2.report) && /does not provide an export named/.test(r2.report))
  t('...and only real importers are named: the helper resolves relative specifiers and nothing else',
    importersOf(['src/lib/offline.js', 'src/lib/b.js'], 'src/lib/b.js', d2).join() === 'src/lib/offline.js' &&
    importersOf(['src/lib/offline.js'], 'src/lib/zz.js', d2).length === 0 &&
    importersOf(['docs/readme.md', 'src/lib/b.js'], 'src/lib/b.js', d2).length === 0)
  t('a conflict nothing imports stays a plain, quiet entry',
    (() => {
      const r3 = patchReport({ version: 'v-q', root: d2, actions: [{ path: 'notes.md', action: 'conflict', why: 'yours', sidecar: true }] })
      return /notes\.md\.new/.test(r3) && !/does not provide an export named/.test(r3)
    })())
}

/* ---------- 11r · Choreography — the beats are derived, not copied ---------- */
H('11r · Movement, presentation, camera and cuts are derived per generation')
{
  /* the family reads the garment, and two garments never share a choreography */
  const fam = (s) => garmentFamily(s).id
  t('a drape reads as flow, tailoring as structured',
    fam('a woman in a chiffon lehenga turns in a courtyard') !== fam('a woman in a structured wool coat walks in') &&
    ['flow', 'ethnic'].includes(fam('a woman in a chiffon lehenga turns in a courtyard')) &&
    fam('a woman in a structured wool coat walks in') === 'structured')
  t('every family is reachable from a plausible idea',
    [['flow', 'a silk chiffon dress floats in the breeze'], ['knit', 'a woman in a cream rib-knit sweater sits'],
     ['body', 'a woman in a satin slip dress turns'], ['heavy', 'a woman in a denim jacket walks'],
     ['ethnic', 'a bridal lehenga with zari work'], ['swim', 'a woman walks out of the sea in a bikini'],
     ['street', 'an oversized hoodie and sneakers'], ['structured', 'a tailored wool blazer and trousers']]
      .every(([id, idea]) => fam(idea) === id))
  t('a colour word is not a location: "warm sand tones" must not read as a beach',
    fam('a woman in a heavy linen shirt and wide trousers in warm sand tones') === 'structured' &&
    fam('a woman walks out of the sea in a bikini') === 'swim')
  t('an idea with no garment still plans a movement instead of crashing',
    !!garmentFamily('a lighthouse at dawn') && fam('a lighthouse at dawn') === garmentFamily('').id)

  /* the presentation kind: what is being shown decides how it is shown */
  const kind = (s, ti) => presentationKind(s, ti).id
  t('ornaments read as a ladder, dressing as a sequence, a walk as an approach, a material as a craft study',
    kind('a woman wears a polki choker and jhumkas') === 'ladder' &&
    kind('a GRWM try-on of two outfits') === 'dress' &&
    kind('she walks to the camera through the market') === 'walk' &&
    kind('a macro study of the fabric weave') === 'craft')
  t('a plan with no signal falls back to a worn look in a scene, not to a wrong kind',
    kind('a woman stands in a lit room', '') === 'scene')

  /* the plan obeys the clock, and varies between variants of one run */
  const base = { idea: 'a woman in a red chiffon lehenga turns in a haveli courtyard', title: 'Heritage doorway reveal', duration: 12, structure: 'multi3' }
  const p1 = motionPlan({ ...base, variantIndex: 1 })
  const p2 = motionPlan({ ...base, variantIndex: 1 })
  const p3 = motionPlan({ ...base, variantIndex: 2 })
  t('the plan fits the live clock exactly, on the shape it drew', (() => {
    const live = shotClock(12, 'multi3', false, p1.envIdx)
    return p1.shots === 3 && p1.cuts.length === 2 && p1.cuts[1] > p1.cuts[0] &&
      p1.shots === live.shots && p1.cuts.join() === live.cuts.join() && p1.windows.join() === live.windows.join() &&
      p1.windows.reduce((a, b) => a + b, 0) === 12
  })())
  t('a single-take request plans one shot and no cuts', (() => {
    const q = motionPlan({ ...base, structure: 'single', duration: 8 })
    return q.shots === 1 && q.cuts.length === 0 && q.moves.length === 1
  })())
  t('the same request always plans the same way (re-generating does not reshuffle)', p1.moves.join() === p2.moves.join() && p1.cuts2.join() === p2.cuts2.join())
  t('a second variant of the same run gets different verbs and a different cut trigger',
    p1.moves.join() !== p3.moves.join() || p1.cuts2.join() !== p3.cuts2.join())
  t('never the same movement verb twice inside one clip', new Set(p1.moves).size === p1.moves.length)
  t('a longer runtime earns more beats, from the same grammar',
    motionPlan({ ...base, duration: 15, structure: 'multi3' }).shots === 3 &&
    motionPlan({ ...base, structure: 'multi2', duration: 8 }).shots === 2)

  /* the injected block states the laws and the clock */
  const txt = motionPlanText(p1, { target: 'h3' })
  t('the block carries every law: garment behaviour, movement, presentation, camera, cut trigger, hold, skip',
    /MOTION PLAN/.test(txt) && /GARMENT BEHAVIOUR/.test(txt) && /SUBJECT MOVEMENT/.test(txt) &&
    /HOW SHE PRESENTS THE PIECE/.test(txt) && /CAMERA/.test(txt) && /CUT TRIGGER/.test(txt) &&
    /HOLD/.test(txt) && /SKIP, NEVER INVENT/.test(txt))
  t('it names the cut points it computed, not numbers from a template',
    txt.includes(fmtTC(p1.cuts[0])) && txt.includes(fmtTC(p1.cuts[1])))
  t('it tells the model to keep the template\'s laws and rebuild its beats',
    /those are grammar: keep its LAWS, then rebuild the beats/i.test(txt))
  t('the LTX form drops the cut language and keeps one take',
    !/CUT TRIGGER/.test(motionPlanText(motionPlan({ ...base, structure: 'single' }), { target: 'ltx' })) &&
    /One continuous take/.test(motionPlanText(motionPlan({ ...base, structure: 'single' }), { target: 'ltx' })))

  /* the builder injects it — H3 and LTX, person scenes only */
  const mk = (idea, extra) => buildUserMessage({ category: 'Fashion / Lifestyle', idea, duration: 10, structure: 'multi3', target: 'h3', workflow: 't2v', ...(extra || {}) }, 1, 1)
  t('the H3 user message carries the motion plan', /MOTION PLAN/.test(mk('a woman in a silk dress turns in a room')))
  t('the LTX user message carries it too', /MOTION PLAN/.test(buildUserMessageLtx({ category: 'Fashion / Lifestyle', idea: 'a woman in a silk dress turns', duration: 8, structure: 'single', target: 'ltx', workflow: 't2v' }, 1, 1)))
  t('a scene with no body in it is left alone', !/MOTION PLAN/.test(mk('a lighthouse stands on a rock at dawn', { category: 'Documentary' })))
  t('a body in a non-fashion scene still gets the plan', /MOTION PLAN/.test(mk('a surfer rides a wave at dawn')))
  t('the plan is built from the idea, so a different idea yields a different plan',
    mk('a woman in a chiffon dress floats in a garden') !== mk('a woman in a structured wool coat walks a corridor'))

  /* the instant engine: same grammar, no LLM */
  {
    const eng = async (idea) => (await genVariantOffline({ idea, duration: 12, structure: 'multi3', ratio: '9:16', resolution: '2K', palette: 'Auto', camera: 'Auto', style: 'Auto', music: 'subtle', detail: true }, 1, 3)).integrated_multimodal_description
    const drape = await eng('a woman in a red chiffon lehenga turns in a haveli courtyard')
    const coat = await eng('a woman in a structured wool coat crosses a marble corridor')
    t('the instant engine derives its beats from the garment, not from one fixed shot list',
      drape !== coat && /wedding|drape|fabric|chiffon|lehenga|flutter|float|swing|settle|pleat|hem/i.test(drape) &&
      /stop|square|stride|line|tailoring|shoulder|clean|settle|quarter/i.test(coat))
    t('its shots carry the derived camera and cut language too',
      /the cut lands/.test(drape) && /\[Shot 2\]/.test(drape) && /\[Shot 3\]/.test(drape))
  }

  /* the templates built from the videos: laws kept, beats derived */
  const camp = read('public/prompts/templates/fashion-campaign.md')
  const intim = read('public/prompts/templates/intimates-reels.md')
  t('no video-derived template pins its own cut times any more',
    !/\d{2}:\d{2}\.\d{3}/.test(camp) && !/\d{2}:\d{2}\.\d{3}/.test(intim))
  t('their beat engines say the structure is grammar, not a shot list',
    (camp.match(/THE GRAMMAR, NOT A SHOT LIST/g) || []).length === 3 &&
    (intim.match(/THE GRAMMAR, NOT A SHOT LIST/g) || []).length === 2)
  t('the studio family uses the adaptive engine instead — never a fixed sequence',
    (camp.match(/BEAT ENGINE — never a fixed sequence/g) || []).length === 3)
  t('every one of them derives its timing from the live clock',
    (camp.match(/TIMING: derive every cut from the live CLOCK/g) || []).length === 7 &&
    (intim.match(/TIMING: derive every cut from the live CLOCK/g) || []).length === 2)
  t('the doctrine sits in the file all four system prompts include',
    /MOVEMENT, PRESENTATION, CAMERA AND CUTS ARE DERIVED, NEVER COPIED/.test(read('public/prompts/shared/craft-detail-and-cast.md')))
  t('the fashion pack carries the derivation table', /the garment's physics/.test(read('public/prompts/packs/fashion.md')) &&
    /what makes a good cut point/.test(read('public/prompts/packs/fashion.md')))
  t('the Forge tells new templates to write laws, not shot lists', /Write LAWS, not shot lists/.test(read('public/prompts/template-forge.md')))

  /* the linter's three verdicts */
  const mkT = (b, t, flows) => ({ t, tag: 'fashion', category: 'Fashion / Lifestyle', prompt: '', b, flows: flows || null, settings: { category: 'Fashion / Lifestyle', structure: 'multi3', duration: 9 } })
  const beat = (x) => lintTemplate(x, null).checks.find((c) => /Beat derivation/.test(c.label))
  const fixed = beat(mkT('integrated_multimodal_description: Shot on a 50mm. A woman turns in a red dress. [Shot 2] At 00:03.000 close. [Shot 3] At 00:06.000 hold. TIMING: 9s total — 3 stamped shots of 3s. LAYER STACK: a bodysuit under it, a skirt, heels.', 'Fixed list test'))
  t('a stamped, fixed-count block with no flows and no derivation rule is flagged',
    !!fixed && fixed.level === 'warn' && /fixed list/.test(fixed.label))
  const derivedOne = beat(mkT('integrated_multimodal_description: Shot on a 50mm. A woman turns. TIMING: derive every cut from the live CLOCK — one beat per 1.5–2s. LAYER STACK: a bodysuit, a skirt, heels.', 'Derived test'))
  t('the same block with a derivation rule passes', !!derivedOne && derivedOne.level === 'ok')
  const flowed = beat(mkT('integrated_multimodal_description: Shot on a 50mm. A woman turns. [Shot 2] At 00:03.000 close. [Shot 3] At 00:06.000 hold. TIMING: 9s total — 3 stamped shots. LAYER STACK: a bodysuit, a skirt, heels.', 'Flowed test', ['A', 'B']))
  t('a block with a flow library passes — the beats re-order per variant', !!flowed && flowed.level === 'ok')
  t('the shipped library has no fixed-list warning left', (() => {
    const blocks2 = []
    for (const f of scanTemplates(join(ROOT, 'public/prompts/templates'))) for (const b of parseTemplatesMd(readFileSync(f.abs, 'utf8'))) blocks2.push(b)
    return blocks2.every((b) => {
      const c = lintTemplate(b, blocks2).checks.find((c) => /Beat derivation/.test(c.label))
      return !c || c.level !== 'warn'
    })
  })())
}

/* ---------- 11s · The studio family must stay at room-tour level ---------- */
H('11s · Studio look shoots — adaptive beats, live dimensions')
{
  const camp = read('public/prompts/templates/fashion-campaign.md')
  const blocks = parseTemplatesMd(camp)
  const byTitle = (re) => blocks.find((b) => re.test(b.t || ''))

  const studio = byTitle(/Quiet-luxury studio/)
  const sun = byTitle(/Hard-sun studio/)
  const four = byTitle(/E-commerce 4-up/)
  t('both studio blocks exist and both are 9:16 at 2K (the macro and the face need the pixels)',
    !!studio && !!sun && [studio, sun, four].every((b) => b && b.settings.ratio === '9:16' && b.settings.resolution === '2K'))

  /* the room-tour standard: adaptive beats keyed to named details, with invariants */
  const RT = read('public/prompts/templates/core.md')
  t('the benchmark template is still the adaptive one this family is measured against',
    /Room outfit tour — adaptive beats/.test(RT) && /BEAT ENGINE — never a fixed sequence/.test(RT) &&
    /Skip any beat whose detail is not named/.test(RT))
  t('the studio lookbook runs the same engine — never a fixed sequence, keyed to named details',
    !!studio && /BEAT ENGINE — never a fixed sequence/.test(studio.b) &&
    /composed ONLY from the details actually named/.test(studio.b) &&
    /Skip any beat whose detail is not named/.test(studio.b) &&
    /never invent a pocket, placket, belt, lining or cuff/.test(studio.b) &&
    /if only two details are named, use those two at two different scales/.test(studio.b))
  t('it carries the OPEN/CLOSE invariants the room tour has',
    !!studio && /OPEN is always first/.test(studio.b) && /CLOSE is always last/.test(studio.b) &&
    /ONE act of 1–1\.5s/.test(studio.b))
  t('its feature beats are the garment\'s real details, one per named detail',
    !!studio && ['CUFF AND SLEEVE', 'PLACKET AND FRONT', 'SEAM AND STITCHING', 'WAISTBAND AND BELT',
      'POCKET AND HAND', 'SHOULDER AND COLLAR', 'HEM', 'RIB OR WEAVE', 'LINING AND BACK']
      .every((k) => studio.b.includes(k)))
  t('the hard-sun block runs the same engine with its own details',
    !!sun && /BEAT ENGINE — never a fixed sequence/.test(sun.b) && /OPEN is always first/.test(sun.b) &&
    /the only light is the sun/.test(sun.b) &&
    ['PRINT AND REPEAT', 'LACE AND EDGE', 'STRAP AND SHOULDER', 'WAISTBAND', 'POCKET AND HAND',
      'HEM AND FALL', 'HARDWARE', 'WALL BEAT', 'SHADOW BEAT'].every((k) => sun.b.includes(k)))

  /* both carry a real flow library, with every declared flow defined in the skeleton */
  const flowLibraryCovers = (b) => {
    const lib = (b.b.match(/FLOW LIBRARY[\s\S]{0,2400}/) || [''])[0]
    return (b.flows || []).length >= 6 && b.flows.every((f) => lib.includes(f))
  }
  t('the studio lookbook defines all six of its flows in the skeleton', !!studio && flowLibraryCovers(studio))
  t('the hard-sun block defines all six of its flows in the skeleton', !!sun && flowLibraryCovers(sun))
  t('the e-commerce collage finally defines its flows too (they were declared but never written)',
    !!four && /FLOW LIBRARY — obey a BEAT FLOW named in the request/.test(four.b) &&
    (four.flows || []).every((f) => four.b.includes(f)))

  /* live dimensions — the room shoot's standard */
  t('the studio lookbook varies nineteen dimensions, the hard-sun block nineteen, the collage seven',
    !!studio && studio.vary.length === 19 && !!sun && sun.vary.length === 19 && !!four && four.vary.length === 7)
  t('every content dimension is carried by a token; every form axis has a pool (the two classes vary by different machinery)', (() => {
    const names = (b) => (tokensOf(b).map((tk) => (guidanceOf(tk) ? tk.split(/\s[—–-]\s/)[0] : tk).toUpperCase().replace(/[^A-Z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()))
    const head = (h) => new RegExp('^## ' + h + '$', 'm').test(read('public/prompts/fashion-variation.md'))
    return [studio, sun, four].every((b) => b && splitDims(b.vary).content.every((d) => names(b).some((n) => n === d || n.startsWith(d + ' ') || d.startsWith(n)))) &&
      [studio, sun].every((b) => splitDims(b.vary).form.length === 8 && splitDims(b.vary).form.every((d) => head(d)))
  })())
  t('the palette is a live field now — the cream studio is one option, not the rule',
    !!studio && /palette is a live field/.test(studio.d) && /TONE FAMILY/.test(studio.b) &&
    /a pale family is pale because the request chose it/.test(studio.b) &&
    !/The named pale base is deliberate in this template/.test(studio.b))

  /* no fixed shot list anywhere in the family */
  t('none of the three stamps its own cut times', [studio, sun, four].every((b) => b && !/\d{2}:\d{2}\.\d{3}/.test(b.b)))
  t('all three carry the derivation timing line', [studio, sun, four].some((b) => /derive every cut from the live CLOCK/.test(b.b)) &&
    (camp.match(/TIMING: derive every cut from the live CLOCK/g) || []).length === 7)
  t('the whole library still has no fixed-shot-list warning', (() => {
    const all = []
    for (const f of scanTemplates(join(ROOT, 'public/prompts/templates'))) for (const b of parseTemplatesMd(readFileSync(f.abs, 'utf8'))) all.push(b)
    return all.every((b) => {
      const c = lintTemplate(b, all).checks.find((c) => /Beat derivation/.test(c.label))
      return !c || c.level !== 'warn'
    })
  })())
  t('the studio blocks are not near-duplicates of each other or of the room tour',
    (() => {
      const sim = (a, b) => similarity(a.b, b.b)
      const room = parseTemplatesMd(RT).find((b) => /Room outfit tour/.test(b.t || ''))
      return sim(studio, sun) < 0.6 && sim(studio, room) < 0.6 && sim(sun, room) < 0.6
    })())
}

/* ---------- 11t · The template is a shoot, not a shot (shots, beats, speech) ---------- */
H('11t · The runtime decides the shots, the beats ride through the cuts, and silence is default')
{
  /* 1 · the shot count is computed from the runtime, not from a fixed 3 */
  const s12 = shotClock(12, 'auto', false)
  const s6 = shotClock(6, 'auto', false)
  const s20 = shotClock(20, 'auto', false)
  t('auto cuts: the runtime decides how many shots (12s → 4, 6s → 2, 20s → 6)',
    s12.shots === 4 && s6.shots === 2 && s20.shots === 6 && shotClock(4, 'auto', false).shots === 1)
  t('auto cuts land evenly and never below the 1.5s minimum',
    s12.cuts.join(',') === '3,6,9' && s12.windows.every((w) => w >= 1.5) && s20.windows.every((w) => w >= 1.5))
  t('a loop is always one take, whatever the structure says',
    shotClock(12, 'auto', true).shots === 1 && shotClock(12, 'multi3', true).shots === 1)
  t('the explicit counts still mean what they always meant',
    shotClock(12, 'multi3', false).shots === 3 && shotClock(12, 'multi2', false).shots === 2 && shotClock(12, 'single', false).shots === 1)

  /* 2 · beats are not shots — the clock says so out loud */
  const c12 = shotClock(12, 'auto', false)
  const line = clockLineH3(c12, {})
  t('the clock forbids stretching a beat to fill a shot',
    /SHOT vs BEAT/.test(line) && /never stretch one beat to fill a shot/.test(line) &&
    /a visible change every ~1\.5s/.test(line))
  t('in auto mode the clock says the count came from the runtime',
    /computed from this runtime/.test(line) && !/computed from this runtime/.test(clockLineH3(shotClock(12, 'multi3', false), {})))
  t('the clock bans ledger lists and the contradictions inside them',
    /NO LEDGER LISTS/.test(line) && /all concealed in silhouette/.test(line))

  /* 3 · speech: wordless by default */
  const fash = { category: 'Fashion / Lifestyle', idea: 'a woman in an embroidered lehenga steps through a carved door', duration: 12, structure: 'auto', target: 'h3', workflow: 't2v' }
  const h3 = buildUserMessage(fash)
  t('a visual template is wordless unless the idea asks for a line',
    /Speech: NONE REQUESTED/.test(h3) && !/elevates the scene/.test(h3) &&
    /never invent a greeting/.test(h3) && /stays wordless unless the user wrote speech into it/.test(h3))
  t('a requested line still gets the on-camera rules',
    (() => { const m = buildUserMessage({ ...fash, dialogue: 'This is my grandmother\u2019s craft.', dlang: 'English' })
      return /<d>\[English\] This is my grandmother\u2019s craft\.<\/d>/.test(m) && /lips move/.test(m) })())
  const ltx = buildUserMessageLtx(fash)
  t('LTX gets the same wordless default', /NONE REQUESTED/.test(ltx) && /never a posed remark/.test(ltx))
  t('the H3 message carries the no-ledger rule', /NO LEDGER LISTS/.test(h3) && /Secondary beats are written as prose/.test(h3))

  /* 4 · the doorway template matches ref 14 instead of contradicting it */
  const camp = parseTemplatesMd(readFileSync(join(ROOT, 'public/prompts/templates/fashion-campaign.md'), 'utf8'))
  const door = camp.find((b) => /Heritage doorway reveal/.test(b.t))
  t('the doorway film opens on a lit garment, never an unlit silhouette',
    !!door && /THE FABRIC IS THE LIGHT/.test(door.b) && !/unreadable/.test(door.b) &&
    /Never render her as an unlit silhouette/.test(door.b))
  t('the doorway film keeps the ornament seen ON her and closes on the veil portrait',
    /IN-CONTEXT MACRO PASS/.test(door.b) && /her still in it/.test(door.b) &&
    /VEIL PORTRAIT/.test(door.b) && /the face sits inside the fabric/.test(door.b))
  t('the doorway film hands its cuts to the clock and keeps the beats moving through them',
    door.settings.structure === 'auto' && /beats running through the cuts/.test(door.b))

  /* 5 · every beat-driven fashion block runs auto cuts; the locked collage stays single */
  const autoBlocks = camp.filter((b) => b.settings.structure === 'auto').map((b) => b.t.replace(/^[^A-Za-z]*/, '').split(' —')[0])
  t('the beat-driven fashion blocks run auto cuts',
    ['Jewellery macro ladder', 'Resort swim', 'Quiet-luxury studio', 'Hard-sun studio', 'Heritage doorway reveal', 'Breeze float']
      .every((n) => autoBlocks.includes(n)))
  t('the locked e-commerce collage keeps its single take',
    camp.some((b) => /E-commerce 4-up/.test(b.t) && b.settings.structure === 'single'))

  /* 6 · the UI offers the new mode and says what it means */
  t('describeSettings spells auto cuts for the toast',
    describeSettings({ structure: 'auto' }) === 'auto cuts' && describeSettings({ structure: 'multi3' }) === '3 shots')
  /* 5b · and the whole fashion family, not just this file */
  const fam = (f) => parseTemplatesMd(readFileSync(join(ROOT, 'public/prompts/templates/' + f), 'utf8'))
  const fashionStill3 = [
    ...fam('core.md').filter((b) => /fashion|lookbook|sari|bridal|jewel|jewellery/i.test(b.t)),
    ...fam('intimates-reels.md'), ...fam('outfit-reveal.md'),
  ].filter((b) => b.settings.structure === 'multi3' && (b.settings.duration || 0) >= 10)
  t('every fashion / jewellery / outfit block across the library lets the runtime decide its cuts',
    fashionStill3.length === 0)
  const form = readFileSync(join(ROOT, 'src/components/StudioForm.jsx'), 'utf8')
  const mgr = readFileSync(join(ROOT, 'src/components/TemplateManager.jsx'), 'utf8')
  t('both structure pickers offer auto cuts', /\['single', 'auto', 'multi2', 'multi3'\]/.test(form) && /'single', 'auto', 'multi2', 'multi3'/.test(mgr))
}

/* ---------- 11u · The bridal show — the arc is the format, the beats are the idea ---------- */
H('11u · Bridal jewellery show: six ornament beats, five spots, one unbroken closing orbit')
{
  const camp2 = parseTemplatesMd(readFileSync(join(ROOT, 'public/prompts/templates/fashion-campaign.md'), 'utf8'))
  const bridal = camp2.find((b) => /Bridal jewellery show/.test(b.t))
  t('the bridal show exists as an 18s vertical 2K film on the beat-driven clock',
    !!bridal && bridal.settings.ratio === '9:16' && bridal.settings.resolution === '2K' &&
    bridal.settings.duration === 18 && bridal.settings.structure === 'auto' && bridal.settings.music === 'beat')

  /* the arc the user described, in their order, from full body back to full body */
  const arc = ['THE FULL BODY', 'THE TORSO', 'THE FACE', 'THE HANDS', 'THE GROUND', 'THE CLOSE']
  t('the arc runs full body → torso → face → hands → ankles → the closing orbit, in that order',
    !!bridal && arc.every((k) => bridal.b.includes(k)) &&
    arc.map((k) => bridal.b.indexOf(k)).every((v, i, a) => i === 0 || v > a[i - 1]))

  /* every ornament family from the brief is a beat the idea can carry */
  t('the whole bridal set is reachable — tikka, nath, neck stack, kamar bandh, haath phool, anklets, mehendi',
    !!bridal && ['maang tikka', 'nath', 'choker', 'rani haar', 'kamar bandh', 'haath phool', 'anklet', 'mehendi']
      .every((k) => bridal.b.toLowerCase().includes(k)))

  /* five spots, one location — and the model never changes */
  t('five spots at one heritage location, walked beat by beat',
    !!bridal && /FIVE SPOTS, ONE LOCATION/.test(bridal.b) && /the background changes, she does not/.test(bridal.b) &&
    /never invent another/.test(bridal.b) && /the walk from one spot to the next carries the cut/.test(bridal.b))

  /* the closing orbit: one move seen twice, rising to full body, ending on her smile */
  t('the closing orbit continues across the cut and CLIMBS her body — never straight to a wide',
    !!bridal && /NEVER BREAK THE ORBIT/.test(bridal.b) && /one continuous move seen twice/.test(bridal.b) &&
    /same direction, same slow speed/.test(bridal.b) && /CLIMBS HER BODY/.test(bridal.b) &&
    /no cut back to a stock wide/.test(bridal.b) && /smile and her gaze straight down the lens/.test(bridal.b))
  t('the rise shows the ornaments on the way up and keeps her face last to leave the frame',
    !!bridal && /hem and its embroidered border first \(the technique and the motif readable\), then the waist and the kamar bandh/.test(bridal.b) &&
    /closest and longest — her face/.test(bridal.b) && /THE RISE NEVER SKIPS A STEP/.test(bridal.b) &&
    /widening is the LAST thing that happens/.test(bridal.b))
  t('the camera is pinned slow and every ornament gets a still hold',
    !!bridal && bridal.settings.amp === 'small' && bridal.settings.speed === 'slow' &&
    /CAMERA SPEED CONTRACT/.test(bridal.b) && /never a whip, a snap pan, a handheld jitter or a speed ramp/.test(bridal.b) &&
    /FOLLOWED BY A HOLD/.test(bridal.b) && /has not been shown/.test(bridal.b) &&
    /the move to the next ornament happens BETWEEN beats/.test(bridal.b))
  t('the beat count follows the ornaments, never a faster camera',
    !!bridal && /two families merged into one beat when it does not/.test(bridal.b) &&
    /never a faster camera to fit them in/.test(bridal.b) &&
    /the face and the neck stack each earn a second one/.test(bridal.b) &&
    bridal.settings.duration === 18 && /at 18s that is six beats/.test(bridal.b))

  /* the ornament is never alone: the wearer is the ground of every macro (the Q1ah law) */
  t('every ornament beat keeps the wearer in frame — the piece is never alone',
    !!bridal && ['hairline and ear', 'cheek and jaw', 'collarbone and throat', "the waist and the skirt's top edge",
      'hand, wrist and forearm', 'the foot, the hem and the stone'].every((k) => bridal.b.includes(k)))
  t('the linter agrees the wearer is in every frame and the beats are derived, not listed',
    (() => {
      const all = []
      for (const f of scanTemplates(join(ROOT, 'public/prompts/templates'))) for (const b of parseTemplatesMd(readFileSync(f.abs, 'utf8'))) all.push(b)
      const L = lintTemplate(bridal, all)
      const w = L.checks.find((c) => /Wearer in frame/.test(c.label))
      const bd = L.checks.find((c) => /Beat derivation/.test(c.label))
      return !!w && w.level === 'ok' && !!bd && bd.level === 'ok' && !L.checks.some((c) => /Wearer in frame|Beat derivation/.test(c.label) && c.level === 'warn')
    })())

  /* adaptive, not a shot list */
  t('the beats are built from the ornaments actually named — skip if not named, never invent',
    !!bridal && /BEAT ENGINE — never a fixed sequence/.test(bridal.b) &&
    /skip any beat whose ornament is missing/.test(bridal.b) &&
    /never invent a piece, a spot or a gemstone/.test(bridal.b) &&
    /run those two at two different scales/.test(bridal.b))
  t('no stamped cut times, and the timing line defers to the live clock',
    !!bridal && !/\d{2}:\d{2}\.\d{3}/.test(bridal.b) &&
    /TIMING: derive every cut from the live CLOCK/.test(bridal.b) &&
    /how many beats you write is what the runtime holds/.test(bridal.b))

  /* flows all defined, dimensions all live */
  t('all six bridal flows are defined in its own flow library',
    (() => {
      const lib = (bridal.b.match(/FLOW LIBRARY[\s\S]{0,2600}/) || [''])[0]
      return (bridal.flows || []).length === 6 && bridal.flows.every((f) => lib.includes(f))
    })())
  t('its nine content dimensions are each carried by a real token, and its eight form axes by their pools',
    (() => {
      const names = tokensOf(bridal).map((tk) => (guidanceOf(tk) ? tk.split(/\s[—–-]\s/)[0] : tk).toUpperCase().replace(/[^A-Z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim())
      const head = (h) => new RegExp('^## ' + h + '$', 'm').test(read('public/prompts/fashion-variation.md'))
      const { form, content } = splitDims(bridal.vary)
      return bridal.vary.length === 19 && content.length === 11 &&
        content.every((d) => names.some((n) => n === d || n.startsWith(d + ' ') || d.startsWith(n))) &&
        form.every((d) => head(d))
    })())
  t('the bridal show is its own film, not a re-cut of the jewellery macro ladder or the room tour',
    (() => {
      const ladder = camp2.find((b) => /Jewellery macro ladder/.test(b.t))
      const room = parseTemplatesMd(readFileSync(join(ROOT, 'public/prompts/templates/core.md'), 'utf8')).find((b) => /Room outfit tour/.test(b.t))
      return similarity(bridal.b, ladder.b) < 0.6 && similarity(bridal.b, room.b) < 0.6
    })())
}

/* ---------- 11v · Coverage follows exposure — innerwear only where it is seen ---------- */
H('11v · The stack stays closed, but innerwear is named only where the cut shows it')
{
  const inner = /\b(camisole|bodysuit|bralette|brief|petticoat|bodice|vest|base layer|inner layer)\b/i

  /* the rule, stated in the file all four system prompts include */
  const craft = read('public/prompts/shared/craft-detail-and-cast.md')
  t('the shared doctrine says innerwear is named only where it is seen',
    /THE STACK IS ALWAYS CLOSED, AND INNERWEAR IS NAMED ONLY WHERE IT IS SEEN/.test(craft) &&
    /A CLOSED, LINED LOOK NAMES NO BASE LAYER AT ALL/.test(craft) &&
    /never add underwear to a covered outfit/.test(craft))
  t('and it still keeps the rule the earlier versions were built on',
    /NEVER worn alone/.test(craft) && /an unstated layer is a missing layer/.test(craft))

  /* the engine: closed look → no innerwear, sheer look → innerwear, intimate → neither added */
  const closed = read('src/lib/colourbank.js')
  t('the engine decides the base layer from exposure, not by default',
    /export const needsBase/.test(closed) && /EXPOSED_RE/.test(closed) && /INTIMATE_RE/.test(closed) && /STATED_BOTTOM_RE/.test(closed))
  const stop = (k, colour, idea) => closed.includes('stackSentence') && stackSentence(k, colour, { idea })
  t('a covered look names no innerwear at all', !inner.test(stop(1, 'the same red', 'a woman in a lined wool coat')))
  t('a look that shows skin names exactly what sits under it',
    /under it/.test(stop(2, 'the same cobalt', 'a woman in a sheer organza dress')) &&
    inner.test(stop(2, 'the same cobalt', 'a woman in a sheer organza dress')))
  t('a plunge, a cut-out, a slit and a bare midriff all count as exposure',
    ['a woman in a plunging backless gown', 'a dress with a high slit', 'a bodysuit with cut-out sides', 'a top with a bare midriff']
      .every((i) => inner.test(stop(3, 'the same plum', i))))
  t('a cropped layer over a covered waist is not exposure (it shows nothing)',
    !inner.test(stop(3, 'the same plum', 'a woman in a cropped blazer and high-waist trousers')))
  t('a closed knit, a shirt under a jacket and a lined blouse do not',
    ['a woman in a cream rib-knit sweater', 'a silk shirt under a wool blazer', 'a lined brocade blouse']
      .every((i) => !inner.test(stop(4, 'the same cream', i))))
  t('intimate wear is the outfit itself — nothing added under it or over it',
    (() => { const t2 = stop(5, 'the same black', 'a woman in a black lace lingerie set')
      return /the set itself/.test(t2) && !inner.test(t2) && !/a bottom in|own lower half/i.test(t2) })())
  t('a whole garment keeps its own lower half — no skirt invented under a lehenga or a dress',
    /own lower half/.test(stop(6, 'the same red', 'a bride in a red silk lehenga')) &&
    /own lower half/.test(stop(6, 'the same plum', 'a woman in a midi dress')))
  t('a bottom the idea already names is never invented twice',
    /already names/.test(stop(7, 'the same cream', 'a woman in a sweater and tailored trousers')) &&
    !/bias-cut midi skirt/.test(stop(7, 'the same cream', 'a woman in a sweater and tailored trousers')))
  /* an outer still completes itself — the original Q1ag bug must stay fixed */
  t('a coat with nothing named under it still gets a bottom and shoes',
    (() => { const t3 = stop(8, 'the same camel', 'a woman in a long camel coat')
      return /(trousers|skirt|shorts)/.test(t3) && /(heels|sandals|loafers|mules|juttis)/.test(t3) })())

  /* the templates and the doctrine files: the old unconditional line is gone everywhere */
  const files = ['public/prompts/templates/core.md', 'public/prompts/templates/fashion-campaign.md',
    'public/prompts/templates/outfit-reveal.md', 'public/prompts/templates/intimates-reels.md',
    'public/prompts/shared/craft-detail-and-cast.md', 'public/prompts/packs/fashion.md',
    'public/prompts/placeholder-filler.md', 'public/prompts/fashion-variation.md']
  const src = files.map(read).join('\n')
  t('no shipped file still orders a base layer for every outfit',
    !/a named base layer \(a camisole, a bodysuit or a bralette-and-brief\) under the main piece/.test(src) &&
    !/goes over a named base layer/.test(src) && !/goes over a named inner layer/.test(src))
  t('the templates that speak of the stack all carry the exposure condition',
    (src.match(/NAME INNERWEAR ONLY WHERE IT IS SEEN|named ONLY when it is seen|only where it is seen|ONLY where the cut shows it|only where the cut shows it|only where the fabric is genuinely sheer/g) || []).length >= 6)

  /* the linter: closed look + innerwear = advisory, not a warning (a camisole under a blazer is a choice) */
  const mk = (b) => ({ t: 'Synthetic closed look', tag: 'fashion', category: 'Fashion / Lifestyle', prompt: '', b, flows: null, settings: { category: 'Fashion / Lifestyle', structure: 'single', duration: 6 } })
  const L = (b) => lintTemplate(mk(b), null)
  const closedLine = L('integrated_multimodal_description: Shot on a 50mm. A woman in a silk camisole under a wool blazer, wide-leg trousers and leather loafers, turns. TIMING: 6s, one take.')
  t('innerwear in a covered look is advisory, never a failure',
    closedLine.checks.some((c) => /Innerwear named though nothing is exposed/.test(c.label) && c.level === 'info') &&
    closedLine.checks.find((c) => /Layering completeness/.test(c.label)).level === 'ok')
  const sheerLine = L('integrated_multimodal_description: Shot on a 50mm. A woman in a sheer organza dress with a silk slip under it, midi hem and suede sandals, turns. TIMING: 6s, one take.')
  t('the same words in a look that shows them draw no note at all',
    !sheerLine.checks.some((c) => /Innerwear named though nothing is exposed/.test(c.label)))
  const coveredWithCrop = L('integrated_multimodal_description: Shot on a 50mm. A woman in a cropped knit and tailored trousers, a suede mule, turns. TIMING: 6s, one take.')
  t('a cropped top over trousers is not an exposure and does not demand a base layer',
    !coveredWithCrop.checks.some((c) => /Layering completeness/.test(c.label) && c.level === 'warn'))

  /* the library itself is clean of the over-correction */
  t('no block in the library names innerwear for a look nothing is exposed in',
    (() => {
      const all = []
      for (const f of scanTemplates(join(ROOT, 'public/prompts/templates'))) {
        if (isProtected('public/prompts/templates/' + f.rel)) continue   /* the user's own blocks are theirs to judge */
        for (const b of parseTemplatesMd(readFileSync(f.abs, 'utf8'))) all.push(b)
      }
      return all.every((b) => {
        const c = lintTemplate(b, all).checks.find((c) => /Innerwear named though nothing is exposed/.test(c.label))
        return !c
      })
    })())
}

/* ---------- 11w · The camera is damped and details are held to be read ---------- */
H('11w · A pinned amplitude/speed reaches the model, and a detail beat holds still')
{
  /* a template can pin amp/speed and they survive the round trip */
  const md = templateToMd({ t: 'Damped', d: 'x', b: 'integrated_multimodal_description: Shot on a 50mm. TIMING: 6s, one take.', settings: { ratio: '9:16', resolution: '2K', duration: 12, structure: 'auto', camera: 'Auto', amp: 'small', speed: 'slow' } })
  t('a template writes its pinned amp/speed back out', /^amp: small$/m.test(md) && /^speed: slow$/m.test(md))
  const back = parseTemplatesMd(md)[0]
  t('and reads them in again, so the pin survives the trip',
    back.settings.amp === 'small' && back.settings.speed === 'slow' && back.settings.duration === 12)
  t('only real values are accepted — a typo never reaches the model',
    parseTemplatesMd(md.replace('amp: small', 'amp: zippy').replace('speed: slow', 'speed: hyper'))[0].settings.amp === undefined &&
    parseTemplatesMd(md.replace('amp: small', 'amp: zippy').replace('speed: slow', 'speed: hyper'))[0].settings.speed === undefined)
  t('the toast names the damping when it is not the default',
    describeSettings({ structure: 'auto', amp: 'small', speed: 'slow' }).includes('small amplitude') &&
    describeSettings({ structure: 'auto', amp: 'small', speed: 'slow' }).includes('slow speed') &&
    describeSettings({ structure: 'auto', amp: 'medium', speed: 'normal' }) === 'auto cuts')
  t('the duration ceiling is what the clock supports, so an 18s film is reachable',
    parseTemplatesMd(md.replace('duration: 12', 'duration: 18').replace('duration: 12', 'duration: 18'))[0].settings.duration === 18 &&
    parseTemplatesMd(md.replace('duration: 12', 'duration: 99'))[0].settings.duration === 20)

  /* the message: Auto now carries the damping, and a missing camera never prints "undefined" */
  const full = { category: 'Fashion / Lifestyle', idea: 'a bride in a red lehenga', duration: 18, structure: 'auto', camera: 'Auto', amp: 'small', speed: 'slow', style: 'Auto', ratio: '9:16', resolution: '2K', palette: 'Auto', music: 'beat', target: 'h3', workflow: 't2v' }
  const damp = buildUserMessage(full)
  t('Auto camera obeys a pinned amplitude/speed instead of choosing its own sweep',
    /pinned to small amplitude at slow speed/.test(damp) && /drift rather than a sweep/.test(damp) && !/undefined/.test(damp))
  t('a sparse request never reaches the model as the word undefined',
    !/undefined/.test(buildUserMessage({ category: 'Fashion & Lifestyle', idea: 'a woman turns', duration: 8, structure: 'single', target: 'h3', workflow: 't2v' })) &&
    !/undefined/.test(buildUserMessageLtx({ category: 'Fashion / Lifestyle', idea: 'a woman turns', duration: 8, structure: 'single', target: 'ltx', workflow: 't2v' })) &&
    !/undefined/.test(damp))

  /* the reading-beat law is in both message builders */
  t('both targets are told a detail beat must hold still to be read',
    /READING BEAT/.test(damp) && /a detail travelling through frame is not shown, it is passed/.test(damp) &&
    /READING BEAT/.test(buildUserMessageLtx({ category: 'Fashion / Lifestyle', idea: 'a bridal jewellery film', duration: 18, structure: 'auto', target: 'ltx', workflow: 't2v' })) &&
    /the camera makes its move BETWEEN such details/.test(buildUserMessageLtx({ category: 'Fashion / Lifestyle', idea: 'a bridal jewellery film', duration: 18, structure: 'auto', target: 'ltx', workflow: 't2v' })))
  t('the ornament ladder itself carries the hold',
    /The rungs also HOLD/.test(motionPlanText(motionPlan({ idea: 'a bride in a lehenga wearing a maang tikka and a nath and anklets', duration: 18, structure: 'auto', workflow: 't2v', category: 'Fashion / Lifestyle', variantIndex: 1, variantTotal: 1 }), { target: 'h3' })))
}

/* ---------- 11x · The 2026 bridal register — designs, not categories ---------- */
H('11x · Bridal design vocabulary: fabric-forward, blouse-as-hero, jewellery styled around one piece')
{
  const pools = read('public/prompts/fashion-variation.md')
  const head = (h) => new RegExp('^## ' + h + '$', 'm').test(pools)

  /* every dimension the bridal film varies must have a real pool to draw from */
  const bridal = parseTemplatesMd(read('public/prompts/templates/fashion-campaign.md')).find((b) => /Bridal jewellery show/.test(b.t))
  t('every dimension the bridal film varies has its own pool',
    !!bridal && bridal.vary.every((d) => head(d)))
  t('the pools that carry the design are the modern ones, not a costume list',
    head('BRIDAL GARMENT') && head('ORNAMENT SET') && head('METAL AND STONE') && head('VEIL') && head('MEHENDI') && head('LIGHT'))

  /* the register: 2026 language, and the "over" list named so the model stops reaching for it */
  t('the bridal garment pool names hand work as the money and the blouse as the hero piece',
    /hand work is the money, and the blouse is the hero piece/.test(pools) &&
    /the LIGHT register \(raw silk, tissue, organza, dupion, brocade, chanderi/.test(pools) &&
    /the HEIRLOOM register \(deep red or marsala/.test(pools) &&
    /MACHINE sparkle/.test(pools) && /disco ball/.test(pools) && /Heavy hand work is wanted/.test(pools))
  t('the garment options are modern silhouettes with a named technique each',
    /organza CAPE replacing the dupatta/.test(pools) && /fish-cut lehenga/.test(pools) && /heirloom re-cut/.test(pools) &&
    /pre-draped tissue-silk saree-gown/.test(pools) && /jacket lehenga/.test(pools) &&
    /gota-patti vines/.test(pools) && /zardozi border/.test(pools) && /bandhani-draped/.test(pools))
  t('the ornament pool states the one-dominant-piece law and the balance rule',
    /One dominant piece, everything else answers it/.test(pools) &&
    /an oversized maang tikka or matha patti runs with MEDIUM earrings/.test(pools) &&
    /never full jhumkas as well/.test(pools) && /if the choker is wide, the long haar is single/.test(pools) &&
    /Pastel lehenga takes diamond or rose gold; red and deep colour take polki or kundan/.test(pools))
  t('the ornament options are modern stylings, not a shopping list',
    /double-layer diamond choker/.test(pools) && /polki choker worn alone/.test(pools) &&
    /temple gold/i.test(pools) && /rose-gold and aquamarine choker/.test(pools) &&
    /barely anything else on the neck|nothing else on the neck/.test(pools))
  t('the veil pool styles the veil rather than draping it',
    /The veil is styled, never draped/.test(pools) && /scalloped organza cape/.test(pools) &&
    /double dupatta/.test(pools) && /No veil at all/.test(pools))
  t('mehendi is named by tradition, coverage and line weight, and stays a stain on skin',
    /pattern TRADITION, the coverage and how fine the lines are/.test(pools) && /never as a brown flat shape/.test(pools))

  /* and all of it is compressed into the film itself */
  t('the bridal film carries the register in its own body',
    !!bridal && /DESIGN REGISTER — 2026 BRIDAL, NAMED/.test(bridal.b) &&
    /never "zari work" with nothing named/.test(bridal.b) && /THE ORNAMENTS ARE STYLED, NOT LISTED/.test(bridal.b) &&
    /BALANCE IS THE CRAFT/.test(bridal.b) && /never print these rules/.test(bridal.b))
  t('the garment and jewellery fields ask for design decisions, not categories',
    !!bridal && /BLOUSE cut, which is the hero piece/.test(bridal.b) && /one embroidery TECHNIQUE with its MOTIF/.test(bridal.b))

  /* the ground beat: the anklet stops being a bare-foot beat */
  t('the feet beat is a GROUND beat — border, footwear and anklets read together, wearer in frame',
    !!bridal && /THE GROUND — the hem, the footwear and the anklets read TOGETHER/.test(bridal.b) &&
    /never a foot-only crop/.test(bridal.b) && /never from below/.test(bridal.b) &&
    /her hand or the veil edge staying in the top of the frame/.test(bridal.b) &&
    !/THE ANKLES — a low angle in the fifth that orbits left to right across her feet/.test(bridal.b))
  t('the ground beat is conditional and the lowest priority beat',
    !!bridal && /If the idea names no anklets and no footwear, drop this beat entirely/.test(bridal.b) &&
    /if it names only a hem, shoot the hem and leave the feet out/.test(bridal.b) &&
    /THE GROUND BEAT IS THE LOWEST PRIORITY BEAT/.test(bridal.b) && /first beat to be dropped/.test(bridal.b))

  /* the pack carries the register, so any bridal request benefits */
  const pack = read('public/prompts/packs/fashion.md')
  t('the fashion pack carries the bridal register for every fashion request',
    /## Bridal and occasion — three registers, pick one and commit/.test(pack) &&
    /Heirloom editorial\*\* — one deep hand-embroidered bridal look/.test(pack) &&
    /## Bridal and occasion — the heritage register/.test(pack) && /One embroidery TECHNIQUE with its motif/.test(pack) &&
    /Jewellery is styled, not listed/.test(pack) && /one DOMINANT piece/.test(pack) && /The veil is styled, never just draped/.test(pack))

  /* the instant engine draws a modern bridal look instead of a midi-skirt stack */
  const led = (idea) => wardrobeLine(idea, 1)
  t('a bridal idea with no colour gets a modern silhouette and a styled set',
    /lehenga|saree-gown|jacket|organza|tissue|dupion|brocade|chanderi/i.test(led('a bride in a lehenga at a haveli with mehendi')) &&
    /one dominant piece/.test(led('a bride in a lehenga at a haveli with mehendi')) &&
    !/bias-cut midi skirt/.test(led('a bride in a lehenga at a haveli with mehendi')))
  t('a bridal idea that names its own colour keeps it and still gets the styled set',
    (() => { const l = led('a bride in a red silk lehenga')
      return /the same red/.test(l) && /one dominant piece/.test(l) && !/midi skirt/.test(l) })())
  t('the bridal bank never repeats itself across a batch',
    new Set([1, 2, 3, 4].map((k) => bridalPieces(k).silhouette)).size === 4 &&
    new Set([1, 2, 3, 4].map((k) => bridalPieces(k).ornaments)).size === 4)
  t('a non-bridal look is untouched by the bridal bank',
    !/lehenga|dominant piece/.test(led('a woman in a linen shirt and tailored trousers')))
}

/* ---------- 11y · Modern bridal glamour — the couture register ---------- */
H('11y · The modern bridal tour: couture construction, high jewellery, architectural rooms')
{
  const glam = parseTemplatesMd(read('public/prompts/templates/bridal-glamour.md'))
  const T = glam.find((b) => /Modern bridal glamour tour/.test(b.t))
  const pools = read('public/prompts/fashion-variation.md')
  const head = (h) => new RegExp('^## ' + h + '$', 'm').test(pools)

  t('the modern bridal tour exists as an 18s vertical 2K film, pinned small and slow like the couture camera it is',
    !!T && T.settings.ratio === '9:16' && T.settings.resolution === '2K' && T.settings.duration === 18 &&
    T.settings.structure === 'auto' && T.settings.amp === 'small' && T.settings.speed === 'slow' && T.settings.music === 'beat')

  /* it is a different register from the heritage film, and it says so out loud */
  t('the register is stated as modern and the heritage traps are named as forbidden defaults',
    !!T && /THE REGISTER IS NOW/.test(T.b) && /this decade's couture glamour/.test(T.b) &&
    /no haveli, no jharokha, no marigold, no mirror work, no heirloom banarasi/i.test(T.d + ' ' + T.tip + ' ' + T.b))
  t('expensive is defined as specific construction, not as adjectives',
    !!T && /EXPENSIVE IS SPECIFIC/.test(T.b) && /boning in the bodice/.test(T.b) &&
    /hand-set crystal/.test(T.b) && /horsehair in the hem/.test(T.b) &&
    /unnamed "heavy embroidery" reads as costume/.test(T.b))
  t('the jewellery is high jewellery worn one piece at a time',
    !!T && /high jewellery worn as styling/i.test(T.b) && /one dominant/i.test(read('public/prompts/fashion-variation.md')) &&
    /diamond rivière choker alone|body chain across a bare back|ear cuff climbing the helix/.test(T.tip))
  t('the beauty is the modern glamour language, not the bridal-catalogue face',
    !!T && /modern beauty language/.test(T.b) && head('GLAM BEAUTY') &&
    /glass-skin base|wet-look sleek middle-part bun|sculpted contour/i.test(pools))

  /* the tour machinery — same standard as the room tour */
  const beats = ['BODICE AND BUST', 'DRAPE AND TRAIN', 'THE SPARKLE', 'THE NECK', 'THE HEAD', 'THE HANDS', 'THE WAIST', 'THE BACK', 'THE HEM AND SHOES', 'THE FACE']
  t('the tour is built from named elements, OPEN first and CLOSE last',
    !!T && /OPEN is always first/.test(T.b) && /CLOSE is always last/.test(T.b) && beats.every((k) => T.b.includes(k)))
  t('the beats are derived, conditional and never invented',
    !!T && /BEAT ENGINE — never a fixed sequence/.test(T.b) && /skip any beat whose element is missing/.test(T.b) &&
    /never invent a detail the look does not have/.test(T.b) && !/\d{2}:\d{2}\.\d{3}/.test(T.b))
  t('the hem beat keeps the wearer in frame instead of cropping to a foot',
    !!T && /THE HEM AND SHOES — a low three-quarter frame, never a foot-only crop and never from below/.test(T.b) &&
    /drop the beat rather than inventing a foot/.test(T.b))
  t('all six flows are defined in its own library',
    (() => { const lib = (T.b.match(/FLOW LIBRARY[\s\S]{0,2400}/) || [''])[0]
      return (T.flows || []).length === 6 && T.flows.every((f) => lib.includes(f)) })())
  t('every dimension it varies has a pool of its own — content and form alike, acts included',
    !!T && T.vary.length === 19 && T.vary.every((d) => head(d)))
  t('the camera contract bans the wedding-video moves',
    !!T && /never a whip pan, never a handheld jitter, never a zoom, never a speed ramp/.test(T.b) &&
    /SPEED CONTRACT/.test(T.b) && /still hold of about 1.5s before the cut/.test(T.b) &&
    /TIMING: derive every cut from the live CLOCK/.test(T.b))
  t('the room is treated as architecture, and the grade refuses nostalgia',
    !!T && /THE ROOM IS A CHARACTER/.test(T.b) && /one wide beat where she is small against the architecture/.test(T.b) &&
    /no warm nostalgic wash, no soft-focus glow, no vignette/.test(T.b))
  t('the linter passes it: closed stack, derived beats, no warnings',
    (() => {
      const all = []
      for (const f of scanTemplates(join(ROOT, 'public/prompts/templates'))) {
        if (isProtected('public/prompts/templates/' + f.rel)) continue
        for (const b of parseTemplatesMd(readFileSync(f.abs, 'utf8'))) all.push(b)
      }
      const L = lintTemplate(T, all)
      return !L.checks.some((c) => c.level === 'warn')
    })())
  t('it is its own film — not a re-cut of the heritage bridal show or the room tour',
    (() => {
      const heritage = parseTemplatesMd(read('public/prompts/templates/fashion-campaign.md')).find((b) => /Bridal jewellery show/.test(b.t))
      const room = parseTemplatesMd(read('public/prompts/templates/core.md')).find((b) => /Room outfit tour/.test(b.t))
      return similarity(T.b, heritage.b) < 0.6 && similarity(T.b, room.b) < 0.6
    })())
  t('the pack names both registers so the model can choose instead of defaulting to heritage',
    /three registers, pick one and commit/.test(read('public/prompts/packs/fashion.md')) &&
    /never default to heritage/.test(read('public/prompts/packs/fashion.md')))
}

/* ---------- 12 · Updates that cannot eat the user's work ---------- */
H('12 · Safe patching (never overwrite your edits)')
{
  /* --- glob + protection --- */
  t('** spans folders, * does not', globToRe('public/prompts/banks/**').test('public/prompts/banks/a/b.md') && !globToRe('public/prompts/*mature*.md').test('public/prompts/banks/x.md'))
  t('mature prompts are protected', isProtected('public/prompts/system-prompt-mature.md') && isProtected('public/prompts/ltx-system-prompt-mature.md'))
  t('the addendum, banks, user templates and .env are protected',
    ['public/prompts/mature-addendum.md', 'public/prompts/banks/dialogue.md', 'public/prompts/templates/user-mine.md', '.env'].every((p) => isProtected(p)))
  t('ordinary app files are not protected', !isProtected('src/lib/prompts.js') && !isProtected('public/prompts/packs/fashion.md'))

  /* --- the decision table --- */
  const P = { path: 'src/lib/a.js', hash: 'new' }
  const acts = (o) => planPatch({ incoming: [P], ...o })[0].action
  t('unmodified file → updated', acts({ base: { 'src/lib/a.js': 'old' }, local: { 'src/lib/a.js': 'old' } }) === 'update')
  t('already current → left alone', acts({ base: { 'src/lib/a.js': 'new' }, local: { 'src/lib/a.js': 'new' } }) === 'same')
  t('missing locally → added', acts({ base: {}, local: {} }) === 'add')
  t('edited by the user → conflict, kept', acts({ base: { 'src/lib/a.js': 'old' }, local: { 'src/lib/a.js': 'mine' } }) === 'conflict')
  t('unknown provenance → conflict, kept', acts({ base: {}, local: { 'src/lib/a.js': 'mine' } }) === 'conflict')
  const protAct = planPatch({ incoming: [{ path: 'public/prompts/banks/d.md', hash: 'new' }], base: {}, local: { 'public/prompts/banks/d.md': 'mine' } })[0]
  t('protected path → keep, never replaced', protAct.action === 'keep' && protAct.sidecar === true)
  t('protection beats "unmodified" too', planPatch({ incoming: [{ path: 'public/prompts/mature-addendum.md', hash: 'new' }], base: { 'public/prompts/mature-addendum.md': 'old' }, local: { 'public/prompts/mature-addendum.md': 'old' } })[0].action === 'keep')
  t('a warning is only raised for real conflicts',
    planPatch({ incoming: [P], base: { 'src/lib/a.js': 'old' }, local: { 'src/lib/a.js': 'old' } })[0].sidecar === undefined &&
    planPatch({ incoming: [P], base: {}, local: { 'src/lib/a.js': 'mine' } })[0].sidecar === true)
  const rep = patchReport({ version: 'v9', actions: [{ path: 'a/b.js', action: 'conflict', why: 'you edited this file — your copy is kept', sidecar: true }, { path: 'src/x.js', action: 'update', why: '' }] })
  t('the report names the conflict, the .new path and the exact way to finish',
    /a\/b\.js/.test(rep) && /a\/b\.js\.new/.test(rep) && /nothing was deleted/.test(rep) && /--accept-new/.test(rep) && /saved first, nothing is lost/.test(rep))

  /* --- zip round-trip --- */
  const zip = writeZip([{ name: 'manifest.json', data: Buffer.from('{"v":1}') }, { name: 'files/a/b.txt', data: Buffer.from('hello '.repeat(400)) }])
  const back = readZip(zip)
  t('zip round-trips (deflate + names + sizes)', back.length === 2 && back[1].name === 'files/a/b.txt' && back[1].data.toString() === 'hello '.repeat(400))
  t('crc32 is the standard one', crc32(Buffer.from('123456789')) === 0xcbf43926)

  /* --- end to end on a throwaway tree --- */
  const dir = mkdtempSync(join(tmpdir(), 'cps-patch-'))
  const put = (rel, s) => { mkdirSync(join(dir, rel.split('/').slice(0, -1).join('/')), { recursive: true }); writeFileSync(join(dir, rel), s) }
  put('src/lib/a.js', 'OLD')                       /* untouched since we shipped → should update */
  put('src/lib/b.js', 'MINE ORIGINAL + my edits')  /* user edited → conflict */
  put('public/prompts/banks/mine.md', 'user bank') /* protected, edited → keep */
  put('notes-to-self.md', 'not in the patch')      /* user-created → must not be touched */
  const patchZip = writeZip([
    { name: 'manifest.json', data: Buffer.from(JSON.stringify({ version: 'v-test', files: { 'src/lib/a.js': (await import('node:crypto')).createHash('sha256').update('OLD').digest('hex'), 'src/lib/b.js': (await import('node:crypto')).createHash('sha256').update('ORIGINAL').digest('hex'), 'public/prompts/banks/mine.md': (await import('node:crypto')).createHash('sha256').update('user bank OLD').digest('hex'), 'src/lib/c.js': null } })) },
    { name: 'files/src/lib/a.js', data: Buffer.from('NEW') },
    { name: 'files/src/lib/b.js', data: Buffer.from('THEIRS') },
    { name: 'files/public/prompts/banks/mine.md', data: Buffer.from('their bank') },
    { name: 'files/src/lib/c.js', data: Buffer.from('BRAND NEW FILE') },
  ])
  const zipPath = join(dir, 'patch.zip')
  writeFileSync(zipPath, patchZip)
  const res = await applyPatch(zipPath, { root: dir, quiet: true })
  t('the unmodified file was updated', rf(join(dir, 'src/lib/a.js'), 'utf8') === 'NEW')
  t('the user-edited file was NOT overwritten', rf(join(dir, 'src/lib/b.js'), 'utf8') === 'MINE ORIGINAL + my edits')
  t('its new version sits beside it as .new', rf(join(dir, 'src/lib/b.js.new'), 'utf8') === 'THEIRS')
  t('the protected bank was not overwritten', rf(join(dir, 'public/prompts/banks/mine.md'), 'utf8') === 'user bank')
  t('a brand new file was added', rf(join(dir, 'src/lib/c.js'), 'utf8') === 'BRAND NEW FILE')
  t('a file the patch does not mention is untouched', rf(join(dir, 'notes-to-self.md'), 'utf8') === 'not in the patch')
  t('nothing was deleted', existsSync(join(dir, 'notes-to-self.md')) && existsSync(join(dir, 'public/prompts/banks/mine.md')))
  t('the run reported exactly one conflict', res.actions.filter((a) => a.action === 'conflict').length === 1 && res.wrote === 2)
  t('a report was written into the project', /PATCH REPORT/.test(rf(join(dir, 'PATCH-REPORT.md'), 'utf8')))

  /* --- the standalone applier that travels inside every patch --- */
  t('mature prompts stay out of every patch unless a release asks for them',
    MATURE_EXCLUDES.some((g) => globToRe(g).test('public/prompts/system-prompt-mature.md')) && MATURE_EXCLUDES.some((g) => globToRe(g).test('public/prompts/ltx-system-prompt-mature.md')))
  const sa = buildStandalone({ version: 'v-test' })
  t('the standalone applier is self-contained (no relative imports, engine inlined)',
    !/from '\.\//.test(sa) && /function planPatch/.test(sa) && /async function applyPatch/.test(sa) && /--accept-new/.test(sa))
  const saDir = mkdtempSync(join(tmpdir(), 'cps-apply-'))
  const saFile = join(saDir, 'apply.mjs')
  writeFileSync(saFile, sa)
  t('the generated applier is valid JS on plain Node', spawnSync(process.execPath, ['--check', saFile], { encoding: 'utf8' }).status === 0)

  const recvDir = mkdtempSync(join(tmpdir(), 'cps-recv-'))
  writeFileSync(join(recvDir, 'package.json'), JSON.stringify({ name: 'cineprompt-studio' }))
  writeFileSync(join(recvDir, 'old.js'), 'THEIR OLD VERSION')
  mkdirSync(join(recvDir, 'public/prompts/banks'), { recursive: true })
  writeFileSync(join(recvDir, 'public/prompts/banks/mine.md'), 'my bank')
  writeFileSync(join(recvDir, 'public/prompts/system-prompt-mature.md'), 'MY OWN MATURE PROMPT')
  writeFileSync(join(saDir, 'manifest.json'), JSON.stringify({ version: 'v-test', notes: ['a note'], files: { 'old.js': null, 'fresh.js': null } }))
  mkdirSync(join(saDir, 'files'), { recursive: true })
  writeFileSync(join(saDir, 'files/old.js'), 'NEW VERSION')
  writeFileSync(join(saDir, 'files/fresh.js'), 'BRAND NEW')
  const run = (...args) => spawnSync(process.execPath, [saFile, '--into', recvDir, ...args], { encoding: 'utf8' })

  t('the applier runs against a project folder with plain node', run('--quiet').status === 0)
  t('it adds what is missing', rf(join(recvDir, 'fresh.js'), 'utf8') === 'BRAND NEW')
  t('it does NOT overwrite a differing file, and parks the new one beside it',
    rf(join(recvDir, 'old.js'), 'utf8') === 'THEIR OLD VERSION' && rf(join(recvDir, 'old.js.new'), 'utf8') === 'NEW VERSION')
  t('the report tells you the exact command that finishes the job',
    /--accept-new/.test(rf(join(recvDir, 'PATCH-REPORT.md'), 'utf8')) && /a note/.test(rf(join(recvDir, 'PATCH-REPORT.md'), 'utf8')))
  t('--dry-run changes nothing', run('--dry-run').stdout.includes('dry run') && rf(join(recvDir, 'fresh.js'), 'utf8') === 'BRAND NEW')
  t('--accept-new takes the new version', run('--accept-new', '--quiet').status === 0 && rf(join(recvDir, 'old.js'), 'utf8') === 'NEW VERSION')
  t('--accept-new saves your previous copy first (nothing is lost)',
    rf(join(recvDir, '.patch-backup/v-test/old.js'), 'utf8') === 'THEIR OLD VERSION')
  t('--accept-new leaves no stale .new behind', !existsSync(join(recvDir, 'old.js.new')))
  t('the applier never touches your mature prompt or your banks',
    rf(join(recvDir, 'public/prompts/system-prompt-mature.md'), 'utf8') === 'MY OWN MATURE PROMPT' &&
    rf(join(recvDir, 'public/prompts/banks/mine.md'), 'utf8') === 'my bank')
  t('--clean removes its own scaffolding only', run('--clean', '--quiet').status === 0 &&
    !existsSync(saFile) && !existsSync(join(saDir, 'manifest.json')) && existsSync(join(recvDir, 'PATCH-REPORT.md')))

  /* --- shipped wiring --- */
  const pkg = JSON.parse(read('package.json'))
  t('npm run patch / snapshot / make-patch / standalone exist', !!pkg.scripts.patch && !!pkg.scripts.snapshot && !!pkg.scripts['make-patch'] && !!pkg.scripts.standalone)
  t('a patch.config.json lets the user protect more paths', /"protected"/.test(read('patch.config.json')))
  t('snapshot / make-patch are wired to patches/state.json (the base of the next patch)',
    /state\.json/.test(read('scripts/patch.mjs')) && /snapshot/.test(read('scripts/patch.mjs')) && /ensureSnapshotDir/.test(read('scripts/patch.mjs')))
  t('banks folder exists with a README', existsSync(join(ROOT, 'public/prompts/banks/README.md')))

  /* --- attach-your-own-files feature --- */
  t('the app lists every prompt file for the pickers', /_tree\.json/.test(read('vite.config.js')) && /_tree\.json/.test(read('src/components/SettingsModal.jsx')))
  t('you can attach files per slot without editing a prompt', /attach: a|attach\b/.test(read('src/components/SettingsModal.jsx')) && /attached context/.test(read('src/components/StudioForm.jsx')))
  t('attached files are resolved like any dependency', /attached\b[\s\S]{0,120}paths/.test(read('src/App.jsx')) && /CONTEXT FILE/.test(read('src/components/StudioForm.jsx')))
  t('zero dependencies says so instead of showing a blank', /no dependencies of its own/.test(read('src/components/SettingsModal.jsx')))
}

/* ---------- 11z · Bridal editorial — the heirloom studio register ---------- */
H('11z · Bridal editorial: one ground, the veil as the device, the macro ladder on her body')
{
  const src = read('public/prompts/templates/bridal-editorial.md')
  const b = parseTemplatesMd(src).find((x) => /Bridal editorial/i.test(x.t))
  const pools = read('public/prompts/fashion-variation.md')
  const head = (h) => new RegExp('^## ' + h + '$', 'm').test(pools)
  const sg = (h) => { const m = pools.match(new RegExp('^## ' + h + '\\n([\\s\\S]*?)(?=\\n## )', 'm')); return m ? m[1] : '' }
  const camp = parseTemplatesMd(read('public/prompts/templates/fashion-campaign.md'))
  const herb = camp.find((x) => /bridal/i.test(x.t)) || camp[0]
  const glam = parseTemplatesMd(read('public/prompts/templates/bridal-glamour.md'))[0]

  t('the bridal editorial ships as an 18s vertical 2K film on the calm bridal camera', !!b &&
    b.settings.ratio === '9:16' && String(b.settings.resolution).startsWith('2K') && b.settings.duration === 18 &&
    b.settings.structure === 'auto' && b.settings.amp === 'small' && b.settings.speed === 'slow')

  t('it declares the six heirloom-editorial flows', !!b && b.flows.length === 6 &&
    ['VEIL FIRST', 'FULL THEN LADDER', 'LADDER UP', 'BACK REVEAL', 'BODICE THEN FACE', 'HEIRLOOM CASCADE']
      .every((x) => b.flows.some((y) => String(y).includes(x))))
  t('it varies over the heirloom-editorial dimensions, and adds the eight form axes', !!b && b.vary.length === 19 &&
    ['BRIDAL GARMENT', 'EMBROIDERY', 'ORNAMENT SET', 'METAL AND STONE', 'VEIL', 'HEIRLOOM PALETTE', 'STUDIO GROUND', 'MOVEMENT', 'CAMERA']
      .every((x) => b.vary.some((y) => String(y).toUpperCase().includes(x))))

  t('it is the register of the refs: one seamless ground, never a location tour', !!b &&
    /ONE GROUND, NO TOUR/.test(b.b) && /never leaves the set/.test(b.b) && /scale changes by CUTTING/.test(b.b) &&
    /never by zooming/.test(b.b))
  t('the veil is a device with named states, not a drape', !!b &&
    /THE VEIL IS THE DEVICE/.test(b.b) && /OVER THE HEAD/.test(b.b) && /ACROSS THE FACE/.test(b.b) && /HELD \(/.test(b.b))
  t('the signature beat is the veil drawn across the eyes', !!b &&
    /signature beat/.test(b.b) && /draws the embroidered veil across her eyes/.test(b.b))
  t('the heirloom reach is enforced, so it cannot drift back to the light register', !!b &&
    /zardozi|resham|dabka|marori|pearl-and-bead fringe/.test(b.tip) &&
    /machine mirror\/sequin sparkle/i.test(b.tip) && /nothing named/.test(b.tip))
  t('the embroidery is the money and must name technique and motif', !!b &&
    /must be READABLE/.test(b.b) && /technique must be identifiable/.test(b.b) && /motif repeating consistently/.test(b.b))
  t('the macro ladder keeps her body in every ornament frame', !!b &&
    /BORDER MACRO/.test(b.b) && /the frame always carries skin/.test(b.b) && /BODICE AND NECKLINE/.test(b.b) &&
    /SLEEVE AND CUFF/.test(b.b) && /WAIST AND BELT/.test(b.b) && /BACK AND TIE/.test(b.b))
  t('the hem beat stays a three-quarter frame and never a foot crop', !!b &&
    /HEM AND FOOT/.test(b.b) && /never a foot-only crop and never from below/.test(b.b))

  t('the face close carries the tikka, the nath and the choker', !!b &&
    /THE FACE — the close/.test(b.b) && /maang tikka/.test(b.b) && /nath if one is named/.test(b.b) &&
    /choker under her jaw/.test(b.b))
  t('skin and midriff are part of the look on every ornament beat', !!b &&
    /midriff in frame/.test(b.b) && /fringe crossing the midriff/.test(b.b))
  t('materials must separate instead of one gloss over everything', !!b &&
    /MATERIALS MUST SEPARATE/.test(b.b) && /no single gloss over everything/.test(b.b) &&
    /skin matte with visible texture/.test(b.b))
  t('the closed stack and the innerwear rule still hold', !!b &&
    /closed stack/.test(b.b) && /never given a second bottom/.test(b.b) && /NAME INNERWEAR ONLY WHERE IT IS SEEN/.test(b.b))
  t('every cut comes from the live clock, never a stamped timecode', !!b &&
    /TIMING: derive every cut from the live CLOCK/.test(b.b) && !/\d{2}:\d{2}\.\d{3}/.test(b.b))

  t('the pools grew with the register: EMBROIDERY, HEIRLOOM PALETTE and STUDIO GROUND', head('EMBROIDERY') &&
    head('HEIRLOOM PALETTE') && head('STUDIO GROUND') && /zardozi with antique-gold dabka/i.test(pools) &&
    /a deep-green paper sweep/i.test(pools) && /expensive for it/.test(pools))
  t('the garment pool now admits heavy hand work and bans only machine sparkle',
    /hand work is the money/.test(sg('BRIDAL GARMENT')) && /HEIRLOOM register/.test(sg('BRIDAL GARMENT')) &&
    /MACHINE sparkle/.test(sg('BRIDAL GARMENT')) && /Heavy hand work is wanted/.test(sg('BRIDAL GARMENT')))
  t('the editorial is its own register, not a reskin of the heritage or couture films',
    !!b && !!herb && !!glam && similarity(b.b, herb.b) < 0.5 && similarity(b.b, glam.b) < 0.6)
}

/* ---------- 11aa · The Indian bridal branch — no Indian request lands on Western couture ---------- */
H('11aa · Indian bridal: the India branch, Indian-modern pools, and no leaked tokens')
{
  const glam = read('public/prompts/templates/bridal-glamour.md')
  const T = parseTemplatesMd(glam).find((b) => /Modern bridal glamour tour/.test(b.t))
  const pools = read('public/prompts/fashion-variation.md')
  const sg = (h) => { const m = pools.match(new RegExp('^## ' + h + '\\n([\\s\\S]*?)(?=\\n## )', 'm')); return m ? m[1] : '' }
  const pack = read('public/prompts/packs/fashion.md')
  const eng = read('src/lib/prompts.js')

  /* the bug this pass fixes: an Indian bridal request used to get a corset, a sapphire choker and an atrium */
  t('the glamour tour carries an INDIA BRANCH that fires on an Indian bridal request', !!T &&
    /INDIA BRANCH — READ THE REQUEST FIRST/.test(T.b) &&
    /when the idea names an Indian bride or an Indian wedding/.test(T.b) &&
    /lehenga, choli, dupatta, saree, mehendi, sangeet, tikka/.test(T.b))
  t('in that branch every element stays Indian, and the Western pieces are named as forbidden', !!T &&
    /the film is INDIAN contemporary bridal and every element stays inside that world/.test(T.b) &&
    /corseted lehenga, pre-draped concept saree, saree-gown, cape lehenga/.test(T.b) &&
    /a choker with its maang tikka/.test(T.b) && /kajal/.test(T.b) &&
    /never a Western gown, never a ballgown/.test(T.b) &&
    /never ear architecture where a maang tikka belongs/.test(T.b))
  t('the coordinated set is allowed in the India branch and banned only outside it', !!T &&
    /a coordinated set is correct rather than forbidden/.test(T.b) &&
    /the choker, the tikka and the studs answering each other IS the styling/.test(T.b))
  t('the tip tells the model when to use which branch', !!T &&
    /when the request IS an Indian bride, keep it Indian-modern/.test(T.tip) &&
    /belong to requests that name no Indian element/.test(T.tip))

  /* the pools were the direct cause — they offered a ballgown and a Western room to an Indian bride */
  t('GLAM GARMENT now opens Indian and bans the Western gown on an Indian bride', sg('GLAM GARMENT') &&
    /INDIAN contemporary couture/.test(sg('GLAM GARMENT')) && /Never a Western gown on an Indian bride/.test(sg('GLAM GARMENT')) &&
    /a corseted lehenga in oxblood raw silk/i.test(sg('GLAM GARMENT')) && /pre-draped concept saree/.test(sg('GLAM GARMENT')) &&
    /kept for requests that name no Indian element/.test(sg('GLAM GARMENT')))
  t('LUXE JEWELS offers the Indian high-jewellery set, choker + maang tikka + bangles', sg('LUXE JEWELS') &&
    /Indian high jewellery/.test(sg('LUXE JEWELS')) && /polished polki choker/.test(sg('LUXE JEWELS')) &&
    /emerald-and-gold choker with one wide maang tikka/.test(sg('LUXE JEWELS')) && /kamar bandh/.test(sg('LUXE JEWELS')) &&
    /one dominant piece/i.test(sg('LUXE JEWELS')) && /no jhumkas/.test(sg('LUXE JEWELS')))
  t('GLAM BEAUTY keeps the modern language and dresses the parting for the tikka', sg('GLAM BEAUTY') &&
    /glass-skin base/.test(sg('GLAM BEAUTY')) && /kajal through the waterline/.test(sg('GLAM BEAUTY')) &&
    /the maang tikka on the parting/.test(sg('GLAM BEAUTY')))
  t('MODERN SET offers Indian-modern rooms instead of only Western architecture', sg('MODERN SET') &&
    /palace-turned-hotel corridor/.test(sg('MODERN SET')) && /jali screens set into a glass wall/.test(sg('MODERN SET')) &&
    /water court/.test(sg('MODERN SET')) && /deep-green paper sweep/.test(sg('MODERN SET')) &&
    /never a rustic courtyard/.test(sg('MODERN SET')))
  t('the pack sends an Indian glamour request to the Indian-modern branch', /an Indian request stays Indian-modern/.test(pack) &&
    /never a Western gown, ballgown or atrium on an Indian bride/.test(pack))

  /* the second bug: {GLAM LIGHT} reached the finished prompt as text */
  t('both builders carry TOKEN DISCIPLINE so a token never reaches the output', (eng.match(/TOKEN DISCIPLINE/g) || []).length >= 2 &&
    /a \{TOKEN\} is an input field, never text/.test(eng) &&
    /the finished prompt carries no braces anywhere/.test(eng) &&
    /\{GLAM LIGHT\}/.test(eng) && /\{GLAM GARMENT\}/.test(eng))
  t('the token rule names the dimension case, not just braces', /or any other token name into the output is a failure/.test(eng) &&
    /every dimension named in the variation contract arrives as an invented, filmable, specific value/.test(eng))
}

/* ---------- 13 · The settings panel owns the engine ---------- */
H('13 · ⚙️ Settings panel: engine settings moved out of the form, into a tabbed panel')
{
  const form = read('src/components/StudioForm.jsx')
  const modal = read('src/components/SettingsModal.jsx')
  const app = read('src/App.jsx')
  const css = read('src/styles.css')

  /* --- the module --- */
  t('an engine-settings module exists with defaults, a pure summary and a reset', !!ENGINE_DEFAULTS && !!loadEngineSettings && !!saveEngineSettings && !!engineSummary)
  t('the defaults match what the form used to ship', ENGINE_DEFAULTS.engine === 'auto' && ENGINE_DEFAULTS.variants === '1' &&
    ENGINE_DEFAULTS.temperature === 0.8 && ENGINE_DEFAULTS.detail === true && ENGINE_DEFAULTS.fewshot === true && ENGINE_DEFAULTS.enhance === false)
  t('the three engine modes are the same three the form offered', ENGINE_MODES.map(([id]) => id).join(',') === 'auto,ollama,offline')
  t('every generation switch is declared once, for the panel and the summary both', ENGINE_OPTIONS.map((o) => o.key).join(',') === 'detail,fewshot,critique,enhance,mature')

  /* round-trip through storage (stubbed, since the suite runs without a browser) */
  const store = {}
  globalThis.localStorage = {
    getItem: (k) => (k in store ? store[k] : null),
    setItem: (k, v) => { store[k] = String(v) },
    removeItem: (k) => { delete store[k] },
  }
  saveEngineSettings({ ...ENGINE_DEFAULTS, engine: 'offline', variants: '3', temperature: 0.55, fewshot: false })
  const back = loadEngineSettings()
  t('settings survive a save/load round-trip', back.engine === 'offline' && back.variants === '3' && back.temperature === 0.55 && back.fewshot === false)
  t('a corrupt or hostile stored value falls back instead of breaking the app',
    (() => {
      store['cps_engine_v1'] = '{"engine":"nonsense","variants":"9","temperature":99}'
      const v = loadEngineSettings()
      return v.engine === 'auto' && v.variants === '1' && v.temperature === 0.8
    })())
  t('the 18+ switch keeps its original storage key, so the routing gate still reads it', (() => {
    saveMature(true); const on = store['cps_nsfw'] === 'on' && loadMature() === true
    saveMature(false); return on && store['cps_nsfw'] === 'off' && loadMature() === false
  })())
  const sum = engineSummary({ ...ENGINE_DEFAULTS, variants: '2', detail: true, fewshot: true }, { model: 'gpt-oss:120b-cloud' }, false)
  t('the summary names the mode, the model, the variant count and the active switches',
    sum.mode === 'Auto' && sum.model === 'gpt-oss:120b-cloud' && sum.line.includes('2 variants') &&
    sum.line.includes('🎨 detail') && sum.line.includes('📚 few-shot') && sum.line.includes('temp 0.80'))
  t('an offline run never advertises a model it will not call', engineSummary({ ...ENGINE_DEFAULTS, engine: 'offline' }, { model: 'x' }, false).model === '')

  /* --- the panel --- */
  t('the settings modal is tabbed: Engine · Provider · System prompts · Templates',
    /const TABS = \[/.test(modal) && ['engine', 'provider', 'prompts', 'templates'].every((id) => modal.includes("['" + id + "'")) &&
    /className=\{'tab'/.test(modal) && /className="tabbar"/.test(modal))
  t('the Engine tab carries the whole engine block — mode, model, model name, variants, temperature',
    /Engine — what writes your prompts/.test(modal) && /ENGINE_MODES\.map/.test(modal) &&
    /label>Variants/.test(modal) && /type="range" min="0\.2" max="1\.2"/.test(modal) &&
    /Model name<span className="opt">type anything/.test(modal))
  t('the switches are rendered from the shared declaration, never hand-copied', /ENGINE_OPTIONS\.map/.test(modal) && /o\.key === 'mature'/.test(modal))
  t('the panel shows what the next run will actually use, before you change anything',
    /className="nowstrip"/.test(modal) && /engineSummary\(engSet, conn, critOn\)/.test(modal) && /Next generation runs/.test(modal))
  t('the 18+ switch moved with the rest and still reports which prompt file runs',
    /Generations run <b>prompts\/system-prompt\.md/.test(modal) || /18\+ off — generations run/.test(modal))
  t('a reset button restores the defaults', /Reset defaults/.test(modal) && /resetEngineSettings/.test(modal))
  t('provider, prompts and templates each have their own tab, so nothing is one long scroll',
    /NOW === 'provider' &&/.test(modal) && /NOW === 'prompts' &&/.test(modal) && /NOW === 'templates' &&/.test(modal) &&
    /System prompt routing/.test(modal))

  /* --- the form keeps only the summary --- */
  t('the Studio form no longer renders the engine editors', !/<label>Engine<\/label>/.test(form) &&
    !/label>Variants/.test(form) && !/ENGINE_MODES/.test(form))
  t('it shows a read-only summary built by the same helper, so the two can never drift',
    /const engNow = engineSummary\(/.test(form) && /engNow\.line/.test(form) && /engNow\.chips\.join/.test(form))
  t('it links to the panel, on the right tab', /onOpenSettings\('engine'\)/.test(form) && /onOpenSettings\('provider'\)/.test(form) && /Change in Settings/.test(form))
  t('the form hydrates from the shared settings and follows changes made there',
    /useEffect\(\(\) => \{[\s\S]{0,400}engSet \|\| ENGINE_DEFAULTS/.test(form) && /\[engSet, matureOn\]\)/.test(form))
  t('the mature status stays in the form, because it is about THIS generation', /this generation runs <b>\{file\}<\/b>/.test(form))
  t('App owns the settings, persists them, and opens the panel on a named tab',
    /import \{ loadEngineSettings, saveEngineSettings, loadMature, saveMature \}/.test(app) &&
    /const openSettings = \(tab\) =>/.test(app) && /const \[settingsTab, setSettingsTab\]/.test(app) &&
    /engSet=\{engSet\} matureOn=\{matureOn\} onOpenSettings=\{openSettings\}/.test(app) &&
    /tab=\{settingsTab\} onTab=\{setSettingsTab\}/.test(app))
  t('the tab bar and the summary strip are styled', /\.tabbar\{/.test(css) && /\.engnow\{/.test(css) && /\.nowstrip\{/.test(css))

  /* --- the generation path is untouched --- */
  t('the generation path is untouched — the form still feeds the builders from its own state',
    /const nVariants = \(ovr && ovr\.variants\) \? ovr\.variants : \+f\.variants/.test(form) &&
    /f\.engine === 'ollama'/.test(form) && /f\.engine === 'auto'/.test(form) &&
    /detail: f\.detail/.test(form) && /enhance: f\.enhance/.test(form) && /fewshot/.test(form))
}

/* ---------- 14 · The library audit — one tag vocabulary, no misfiled templates ---------- */
H('14 · Library audit: tags that group correctly, and skeletons that never stamp a cut')
{
  /* --- one vocabulary, no drifting copies --- */
  const card = read('src/components/TemplateCard.jsx')
  const learn = read('src/components/LearnSection.jsx')
  const pick = read('src/components/TemplatePickerModal.jsx')
  t('the tag vocabulary lives in exactly one file', !/const TAG_LABELS/.test(card) && !/const TAG_LABELS/.test(learn) && !/const TAG_LABELS/.test(pick) &&
    !!tagLabel && !!groupOf)
  t('every tag the library uses has a label (preset · immersive · medical included)',
    ['preset', 'immersive', 'medical', 'fashion', 'person', 'product', 'ethnic', 'beauty'].every((x) => !!TAG_LABELS[x]))

  /* --- the reported bug: a Fashion/Lifestyle template filed under Person --- */
  t('a fashion-category template can never group as Person, whatever its tag says',
    groupOf({ tag: 'person', settings: { category: 'Fashion / Lifestyle' } }) === 'fashion' &&
    groupOf({ tag: 'preset', settings: { category: 'Fashion / Lifestyle' } }) === 'fashion' &&
    groupOf({ tag: 'mature', settings: { category: 'Fashion / Lifestyle' } }) === 'fashion')
  t('a genuinely non-fashion template keeps its own group',
    groupOf({ tag: 'product', settings: { category: 'Product Showcase' } }) === 'product' &&
    groupOf({ tag: 'immersive', settings: { category: 'Immersive / VR180' } }) === 'immersive' &&
    groupOf({ tag: 'medical', settings: { category: 'Medical / Science' } }) === 'medical')
  t('an unknown tag falls back to the category instead of an unlabelled bucket',
    groupOf({ tag: 'brandnew', settings: { category: 'Product Showcase' } }) === 'product' &&
    groupOf({ tag: 'brandnew', settings: { category: 'Medical / Education' } }) === 'medical')
  t('both pickers filter by the resolved group, not the raw tag',
    /groupOf\(t\) === tag/.test(pick) && /groupOf\(tp\) === tFilter/.test(learn))
  t('the filter list is built from what is actually loaded', /tagFilters\(/.test(pick) && /tagFilters\(tAll\)/.test(learn))

  /* --- the library itself --- */
  const all = []
  for (const f of scanTemplates(join(ROOT, 'public/prompts/templates'))) {
    if (isProtected('public/prompts/templates/' + f.rel)) continue
    for (const b of parseTemplatesMd(readFileSync(f.abs, 'utf8'))) all.push(b)
  }
  const bad = misgroups(all)
  t('no template in the shipped library is misfiled by its tag', bad.length === 0 &&
    all.filter((b) => (b.settings || {}).category === 'Fashion / Lifestyle' && b.tag === 'person').length === 0)
  t('every template groups into a labelled bucket',
    all.every((b) => { const g = groupOf(b); return g !== 'other' && !!TAG_LABELS[g] }))
  const stamped = all.filter((b) => /\b\d{1,2}:\d{2}\.\d{3}\b/.test((b.b || '') + ' ' + (b.idea || '')))
  t('no skeleton stamps when its own cuts happen', stamped.length === 0)
  const overTok = all.filter((b) => /\{[^{}\n]{121,500}\}/.test((b.b || '') + ' ' + (b.idea || '')))
  t('no placeholder token is over the 120-char budget', overTok.length === 0)

  /* --- the audit tool ships and agrees --- */
  t('the layered audit tool ships with an npm script', existsSync(join(ROOT, 'scripts/audit-templates.mjs')) &&
    /"audit:templates"/.test(read('package.json')))
  const aSrc = read('scripts/audit-templates.mjs')
  t('it states the layers, so a missing law is not mistaken for a defect',
    /the ENGINE \(src\/lib\/prompts\.js\) injects/.test(aSrc) && /the PACKS/.test(aSrc) &&
    /Only the gaps above are real/.test(aSrc))
  t('it reads the skeleton AND the idea line — both reach the model',
    /const body = \(b\.b \|\| ''\) \+ /.test(aSrc) && /b\.idea/.test(aSrc))
  t('a ban on a camera move is not read as a request for it', /a ban is not a request/.test(aSrc))

  /* --- the 2026 adaptive refreshes, old versions kept --- */
  const ad = parseTemplatesMd(read('public/prompts/templates/adaptive-films.md'))
  t('three adaptive successors ship, each with flows and live dimensions',
    ad.length === 3 && ad.every((b) => (b.flows || []).length >= 4 && (b.vary || []).length >= 6 && b.settings.structure === 'auto'))
  t('they are derived, not fixed: element-per-beat and a flow library in each',
    ad.every((b) => /BEAT ENGINE/.test(b.b) || /ARC IS DERIVED/.test(b.b)) &&
    ad.every((b) => /FLOW LIBRARY/.test(b.b)) && ad.every((b) => /TIMING: derive every cut from the live CLOCK/.test(b.b)))
  t('the UGC successor carries speech-on-camera and the closed stack',
    /face in frame with the mouth never covered/.test(ad[0].b) && /closed stack/.test(ad[0].b))
  t('the fashion successor carries fabric behaviour and the closed stack',
    /FABRIC BEHAVIOUR IS PART OF THE CHOREOGRAPHY/.test(ad[1].b) && /THE LOOK IS A CLOSED STACK/.test(ad[1].b))
  t('the lookbook successor keeps the chain locked', /LOCKED SERIES/.test(ad[2].b) && /identical in every scene/.test(ad[2].b))
  const core = read('public/prompts/templates/core.md')
  t('the presets they supersede are kept, and now point forward',
    /UGC skeptic testimonial ad/.test(core) && /Walk-in approach/.test(core) &&
    (core.match(/An adaptive version of this preset ships as/g) || []).length === 11)
}

/* ---------- 15 · Components actually render — the crash class the build cannot see ---------- */
H('15 · Render smoke: every component renders, and a crash can never blank the app')
{
  const app = read('src/App.jsx')

  /* THE BUG THIS SUITE EXISTS FOR: `const tTags = tagFilters(tAll)` sat above
     `const tAll = …` — vite built it happily and the app died at first paint with
     "Cannot access 'tAll' before initialization". Only executing the component catches it. */
  const results = await renderSmoke(ROOT)
  const crashed = results.filter((r) => !r.ok)
  t('every shipped component renders without throwing', crashed.length === 0)
  if (crashed.length) for (const c of crashed) console.log('      ✘ ' + c.file + ' → ' + c.err)
  t('the smoke roster is real — it covers the components this pass touched',
    results.length >= 8 && results.some((r) => /LearnSection/.test(r.file)) &&
    results.some((r) => /TemplateCard/.test(r.file)) && results.some((r) => /SettingsModal/.test(r.file)))
  t('rendering them produces markup, and the error boundary passes its children through',
    results.filter((r) => r.ok && !r.skipped).every((r) => r.bytes > 0) &&
    (results.find((r) => /ErrorBoundary/.test(r.file)) || {}).bytes > 0)

  /* declaration order — the static half of the same check */
  const learn = read('src/components/LearnSection.jsx')
  const iAll = learn.indexOf('const tAll = ')
  const iTags = learn.indexOf('const tTags = ')
  t('LearnSection builds its filter list AFTER the list it filters', iAll > 0 && iTags > iAll)
  const card = read('src/components/TemplateCard.jsx')
  t('no component shadows an imported helper with a local const of the same name',
    !/const tagLabel = tagLabel\(/.test(card) && /const tagTxt = tagLabel\(/.test(card))

  /* the boundary, so a future crash is a card and not a blank page */
  t('an error boundary ships and is used around every view',
    existsSync(join(ROOT, 'src/components/ErrorBoundary.jsx')) &&
    (app.match(/<ErrorBoundary /g) || []).length >= 3 &&
    (app.match(/<\/ErrorBoundary>/g) || []).length === (app.match(/<ErrorBoundary /g) || []).length)
  const eb = read('src/components/ErrorBoundary.jsx')
  t('the boundary explains itself and offers a way out',
    /Try again/.test(eb) && /Reload the page/.test(eb) && /Copy the error/.test(eb) && /getDerivedStateFromError/.test(eb))
  t('the smoke test is one command', /"smoke": "node scripts\/rendersmoke\.mjs"/.test(read('package.json')))
}

H('16 · The tour grammar: why the room tour wins, and the six rebuilts')
{
  /* The complaint: "none of the templates we made from video is as good as Room outfit tour."
     It was measurable. In the ref-derived films the CAMERA travelled and she stood still
     (Bridal jewellery show: 11 camera moves, 0 by her). In the room tour it is the reverse
     (0 camera moves, 5 scale changes caused by her). A subject who never changes scale is a
     slideshow of framings; a subject who walks is a film. These pins hold the rebuilts to it. */
  const tour = parseTemplatesMd(read('public/prompts/templates/tour-grammar.md'))
  t('the tour grammar ships six templates — the refs rebuilt, not replaced',
    tour.length === 6 && tour.every((x) => x.settings && x.settings.duration))
  t('every tour template pins its camera and outlaws the travelling lens',
    tour.every((x) => /LOCKED|PINNED|WATCHTOWER/i.test(x.b) &&
      /does not travel|no travel/i.test(x.b) && /no (zoom|orbit)|does not (zoom|orbit)/i.test(x.b)))
  t('every tour template carries a flow library it re-orders rather than a shot list',
    tour.every((x) => (x.flows || []).length >= 5) &&
    /FLOW LIBRARY/.test(tour[0].b) && /never add(s)? (a beat|one)/i.test(tour[0].b))

  /* the measurement itself, the same way scripts/audit-templates.mjs reports it */
  const NEG = '(?<!never a )(?<!no )(?<!does not )(?<!do not )(?<!never )'
  const count = (re, txt) => (txt.match(re) || []).length
  const CAMTASK = /\b(the camera (reads|finds|lands|holds|settles|drifts|slides|arcs|pushes|tracks)|macro (on|beat|insert)|at its own scale|fills frame|extreme close)\b/gi
  const SHE = /\b(approaches|steps? (in|back|toward|closer|carry|carries)|two (grounded )?steps|walks? (in|toward|at)|turns? (away|through|back|three-quarters)|comes? closer|moves? toward)\b/gi
  const CAM = new RegExp(NEG + '\\b(camera (drifts|pushes|arcs|slides|orbits|cranes|zooms|moves)|dolly|crane|orbit|zoom|pan|tilt)\\b', 'gi')
  const measured = tour.map((x) => {
    const body = (x.b || '') + ' ' + (x.idea || '')
    return { t: x.t, cam: count(CAM, body), camTasks: count(CAMTASK, body), she: count(SHE, body) }
  })
  t('no rebuilt template lets the camera travel — 0 camera moves across all six',
    measured.every((m) => m.cam === 0))
  t('every rebuilt template changes scale because SHE moves', measured.every((m) => m.she >= 2))
  t('no rebuilt template outsources a beat to the lens (camera-tasks < subject acts)',
    measured.every((m) => m.camTasks <= 1))

  /* the weight law — the refs drowned in all-caps law that the engine already carries */
  const words = tour.map((x) => ((x.b || '') + ' ' + (x.idea || '')).split(/\s+/).length)
  /* v2.37 raised this ceiling from 1,200 to 1,275 (the space-and-dress law adds a mandatory paragraph to
     every tour) and v2.39 to 1,320 (the realism law adds another). Two laws that every tour must carry cost
     about 150 words; the check still catches a template that doubles. */
  t('every rebuilt template stays lean (all under 1,320 words with the space and realism laws written in)',
    words.every((w) => w < 1320))
  t('each rebuilt template states its beat budget as acts per second, not a shot schedule',
    tour.every((x) => /one act per beat/i.test(x.b) && /1[–-]1\.5s/.test(x.b) && /live CLOCK/i.test(x.b)))

  /* the six originals stay — and each one points at its rebuild */
  const ptr = [
    ['fashion-campaign.md', 'Jewellery macro ladder', '💎 Jewellery tour — she brings it to the light'],
    ['fashion-campaign.md', 'Bridal jewellery show', '💎 Bridal jewellery tour — five light spots'],
    ['fashion-campaign.md', 'Quiet-luxury studio', '🧵 Quiet-luxury tour — she moves, the silk speaks'],
    ['fashion-campaign.md', 'Hard-sun studio', '☀️ Hard-sun tour — she works the shadow line'],
    ['bridal-editorial.md', 'Bridal editorial', '🧵 Bridal tour — she walks the ground'],
    ['bridal-glamour.md', 'Modern bridal glamour tour', '👑 Bridal glamour tour — she owns the set'],
  ]
  t('the six ref-derived originals are untouched and each points at its rebuild', ptr.every(([f, h, name]) => {
    const blocks = parseTemplatesMd(read('public/prompts/templates/' + f))
    const b = blocks.find((x) => x.t.includes(h))
    return !!b && (b.d || b.description || '').includes(name) && /tour-grammar\.md/.test(b.d || b.description || '')
  }))

  /* the guard that would have caught this three releases ago */
  const at = read('scripts/audit-templates.mjs')
  t('the library audit measures slideshow risk and camera travel',
    /SLIDESHOW RISK/.test(at) && /the camera does the travelling/.test(at) && /r_tour|acts, camTasks, sheMoves, camMoves/.test(at))
  t('the camera-travel check only judges films that have a wearer in them (product films travel by design)',
    /hasWearer/.test(at) && /product/i.test(at))

  /* the command our own patch prints as the receiver route must actually run */
  const pm = read('scripts/patch.mjs')
  t('npm run patch -- <zip> applies into this project (the CLI passes a root)',
    (pm.match(/applyPatch\((target|cmd), \{ root: ROOT/g) || []).length === 2 &&
    /applyPatch needs a root/.test(read('scripts/patchcore.mjs')))

  /* the diagnosis, written down with the numbers */
  const doc = read('docs/why-the-room-tour-works.md')
  t('the diagnosis ships and quotes the measurements, not opinions',
    /scale change by CAMERA/.test(doc) && /\*\*11\*\*/.test(doc) && /807/.test(doc) && /2,062|2062/.test(doc) &&
    /tour-grammar\.md/.test(doc) && /0 camera moves, 5 by her|\*\*0\*\*/.test(doc))
}

H('17 · The photo-shoot film: the set is in the film, and the crew is an option')
{
  /* The ask: a photo-shoot video like the .char / consistent-character shoots — model, location,
     clothing mostly dynamic, WITH the option of cut shots showing the photographer and the crew.
     The shape that answers it: the v2.29 tour grammar (locked lens, her acts, flow library) plus
     one new dimension — CREW — that is named by the user or absent entirely. */
  const file = 'public/prompts/templates/photo-shoot.md'
  const ps = parseTemplatesMd(read(file))
  t('the photo-shoot pack ships one template, whole', ps.length === 1)
  const b = ps[0]
  const all = (b.b || '') + ' ' + (b.idea || '')

  t('model, location, clothing, movement, action and camera all vary per generation',
    ['MODEL', 'OUTFIT DESIGN', 'OUTFIT COLOUR', 'MOVEMENT', 'ACTION', 'OUTFIT INTERACTION', 'LOCATION', 'CAMERA'].every((d) => b.vary.includes(d)))
  const pools = read('public/prompts/fashion-variation.md')
  const crewSec = (pools.split(/^## CREW$/m)[1] || '').split(/^## /m)[0]
  t('the crew is a named dimension with its own pool of six options', b.vary.includes('CREW') &&
    crewSec.split('\n').filter((l) => /^\d+\. /.test(l)).length === 6)
  t('the crew pool includes a shoot with nobody in frame', /No crew in frame at all/.test(crewSec))
  t('write NONE and no crew is ever invented into the film', /exactly NONE/.test(all) &&
    /no crew member, hand, stand or shadow ever enters frame/.test(b.b))
  t('the crew is optional by law, not by luck', /THE CREW IS AN OPTION, NEVER AN INVENTION/.test(b.b))
  t('the film opens and closes on her whatever the crew does', /OPENS AND CLOSES ON HER/.test(b.b))
  t('crew beats are cutaways, capped by the runtime and never her beat', /never in the opening or closing shot/.test(b.b) &&
    /one per three seconds of runtime/.test(b.b) && /always a CUT/i.test(b.b))
  t('the crew cannot break the one light design or speak', /never leaving the one light design/.test(b.b) && /no crew dialogue/.test(b.b))
  t('the crew beats are named in the template — photographer, light, stylist, review, set-back',
    ['THE PHOTOGRAPHER', 'THE LIGHT', 'THE STYLIST', 'THE REVIEW', 'THE SET-BACK'].every((x) => b.b.includes(x)))

  /* the v2.29 mechanics, applied to the new template */
  const NEG = '(?<!never a )(?<!no )(?<!does not )(?<!do not )(?<!never )'
  const count = (re, txt) => (txt.match(re) || []).length
  const SHE = /\b(approaches|steps? (in|back|toward|closer)|walks? (in|toward|at)|turns? (away|through|back)|comes? closer|moves? toward)\b/gi
  const CAM = new RegExp(NEG + '\\b(camera (drifts|pushes|arcs|slides|orbits|cranes|zooms|moves)|dolly|crane|orbit|zoom|pan|tilt)\\b', 'gi')
  t('the lens is locked inside every shot, and SHE causes the scale changes',
    /LOCKED INSIDE EVERY SHOT/.test(b.b) && count(SHE, all) >= 3 && count(CAM, all) === 0)
  t('the film declares a beat-flow library instead of a shot list', (b.flows || []).length >= 6 && /FLOW LIBRARY/.test(b.b))
  t('the beat budget derives from the live clock, never a stamped schedule', /live CLOCK/.test(b.b) && /1-1\.5s/.test(b.b))
  t('the look stays a closed stack with innerwear only where it is seen',
    /LAYER STACK/.test(b.b) && /names nothing under it/.test(b.b))
  t('colour is stated and varied, so no colourless garment',
    /OUTFIT COLOUR/.test(all) && b.vary.includes('OUTFIT COLOUR'))
  t('the tip names the reference route for an identity that holds across cuts',
    /character reference/i.test(b.tip) && /\.char|reference-sheet/.test(b.tip))

  /* it must not read as a duplicate of the two shoots we already ship */
  const header = read(file).split('## 📸')[0]
  t('the template names its no-crew siblings so the three read as a family',
    /Room photo shoot/.test(header) && /Photo-shoot tour chain/.test(header) && /core\.md/.test(header))
  t('only this template puts crew in frame (the siblings keep them out)',
    /only that scene carries it/.test(read('public/prompts/templates/core.md')) &&
    !/## CREW/.test(read('public/prompts/templates/core.md')))
}

H('18 · The ornament shows: scale by cut, the wide reset, and her face in every frame')
{
  /* Two refs (2026-09-28) — a fine-jewellery campaign and a yellow bridal show — both change the
     frame size by CUTTING, never by travelling, and neither ever shows an ornament without its
     wearer. The old ref-derived templates did the opposite. These pins hold the new pair to the
     refs' own numbers: the jewellery ref cuts 8 times at ~1.0s; the bridal ref holds for 6s. */
  const file = 'public/prompts/templates/ornament-shows.md'
  const sh = parseTemplatesMd(read(file))
  t('the ornament-show pack ships two templates', sh.length === 2)
  const [jew, wall] = sh
  const jAll = (jew.b || '') + ' ' + (jew.idea || '')
  const wAll = (wall.b || '') + ' ' + (wall.idea || '')

  /* law 1 — the scale changes by the cut */
  t('both shows lock the camera inside every shot', sh.every((x) => /LOCKED INSIDE EVERY SHOT/.test(x.b)))
  t('both shows change the scale only by cutting', sh.every((x) => /changes? (only )?because the film CUTS|arrives? with the CUT|only by the cut/i.test(x.b)))
  const NEG = '(?<!never a )(?<!no )(?<!does not )(?<!do not )(?<!never )'
  const CAM = new RegExp(NEG + '\\b(camera (drifts|pushes|arcs|slides|orbits|cranes|zooms|moves)|dolly|crane|orbit|zoom|pan|tilt)\\b', 'gi')
  t('no camera travel anywhere in either show', sh.every((x) => !CAM.test((x.b || '') + ' ' + (x.idea || ''))))

  /* law 2 — a tight beat keeps her in it */
  t('the jewellery show forbids a frame of jewellery alone', /THE PIECE IS NEVER ALONE/.test(jew.b) &&
    /No frame shows jewellery with nobody in it/.test(jew.b))
  t('its tight beats each name what of her stays in frame', /ring close-up keeps her face in frame/.test(jew.b) &&
    /earring beat keeps the jaw/.test(jew.b) && /choker beat keeps the chin and the collarbone/.test(jew.b))

  /* law 3 — the hand does the work */
  t('the hand is on the piece in every jewellery beat', /THE HAND DOES THE WORK/.test(jew.b) &&
    /in every jewellery beat her own hand is on the piece/.test(jew.b))

  /* law 4 — the wide reset */
  t('the jewellery show resets wide after three tight beats', /THE WIDE RESET/.test(jew.b) &&
    /never more than three tight shots in a row/i.test(jew.b))
  t('the bridal show resets after three held frames', /never more than three held frames run in a row/i.test(wall.b))

  /* the bridal ref's own devices */
  t('the palette-wall show keeps held frames alive, never dead', /HELD FRAMES ARE ALLOWED, NEVER DEAD/.test(wall.b) &&
    /every held frame carries one second of micro-life/.test(wall.b))
  t('the wall is a named subject with its own rhythm', /THE WALL IS THE SECOND SUBJECT/.test(wall.b) &&
    /repeating carved medallions/.test(wall.b))
  t('the veil works in the ref\'s three states — hooded, across the face, overhead', /THE VEIL AS A HOOD/.test(wall.b) &&
    /THE VEIL ACROSS/.test(wall.b) && /THE VEIL OVERHEAD/.test(wall.b))

  /* the close is the look, not the tightest macro */
  t('the jewellery show closes on the look, not on a macro', /CLOSE is last and it is NOT the tightest frame/i.test(jew.b) ||
    /it is NOT the tightest frame/.test(jew.b))

  /* the brand wordmark, strictly opt-in */
  t('a brand wordmark is optional and spelled exactly when named', /BRAND LINE/.test(jAll) &&
    /spelled exactly as they must appear, or exactly NONE/.test(jAll) && /NO other lettering anywhere in the film/.test(jew.b))
  t('the wordmark is a live varying dimension', jew.vary.includes('BRAND LINE'))

  /* everything else the library already demands */
  t('both shows carry flow libraries and live-clock timing',
    sh.every((x) => (x.flows || []).length >= 6) && sh.every((x) => /FLOW LIBRARY/.test(x.b) && /live CLOCK/.test(x.b)))
  t('both stay a closed stack with colour stated',
    sh.every((x) => /LAYER STACK/.test(x.b)) && /marigold or haladi-yellow/.test(wAll) && /ivory|polki/i.test(jAll))
  t('both are lighter than the refs they replace (under 1,200 words each)',
    sh.every((x) => (((x.b || '') + ' ' + (x.idea || '')).split(/\s+/).length) < 1200))

  /* the pools the refs needed */
  const pools = read('public/prompts/fashion-variation.md')
  const oset = (pools.split(/^## ORNAMENT SET$/m)[1] || '').split(/^## /m)[0]
  t('the ORNAMENT SET pool gained the polki-and-rose campaign set', /Polki and rose/.test(oset) && /rose-pink stone drops/.test(oset))
  const ground = (pools.split(/^## STUDIO GROUND$/m)[1] || '').split(/^## /m)[0]
  t('the STUDIO GROUND pool gained the carved-medallion wall', /repeating carved medallions/.test(ground))

  /* the superseded originals point at the new pair, and the audit stops shouting at them */
  const jl = read('public/prompts/templates/fashion-campaign.md')
  t('the bridal jewellery show and the macro ladder each point at their rebuild',
    /💎 Heirloom jewellery show/.test(jl) && (jl.match(/💎 Heirloom jewellery show/g) || []).length >= 2 &&
    /ornament-shows\.md/.test(jl))
  t('the audit demotes a superseded template to INFO instead of WARN',
    /superseded by a rebuild that is already in the library/.test(read('scripts/audit-templates.mjs')) &&
    /superseded by a rebuild/.test(read('src/lib/lint.js')) === false)
  t('the study ships with the measured cut times and the frame counts',
    /1\.0s apart/.test(read('docs/refs-ornament-shows-2026-09.md')) &&
    /11 camera moves, 0 by the subject/.test(read('docs/refs-ornament-shows-2026-09.md')))
}

H('19 · Motion: the walk is a walk, the mark is continuous, the film is face-forward')
{
  /* Field report: the first outputs from the bridal templates came back with "walking is like
     jumping" and "mostly showing back view". Both were caused by our own instructions — a walk
     asked to cover a distance inside one beat (the model renders a hop), and open-ended turns
     plus back-first flows. The fix went into the fashion pack, so every fashion generation
     inherits it, and into the templates that contradicted it. */
  const pack = read('public/prompts/packs/fashion.md')
  t('the fashion pack carries the motion doctrine', /## Motion — the walk is a walk, and the mark is continuous/.test(pack))
  t('a walk is two to four grounded steps, never a crossing', /two to four steps taken in real time/.test(pack) &&
    /never a journey across the room/.test(pack) && /rendered as a hop, a glide or a teleport/.test(pack))
  t('the walk names the ground: heel-to-toe, weight, both feet never off the floor, feet in frame',
    /heel-then-toe/.test(pack) && /both feet are never off the floor at once/.test(pack) && /floor and her feet in frame/.test(pack))
  t('the walk owns a beat and the cut lands on her stop', /its own beat of at least two seconds/.test(pack) &&
    /cut land on her stop, never mid-stride/.test(pack))
  t('the mark is continuous — she does not relocate between shots', /The mark is continuous/.test(pack) &&
    /every later shot finds her on the same mark/.test(pack) && /reads as a jump even when each shot is perfect/.test(pack))
  t('the film is face-forward, with one three-quarter back beat at most', /The film is face-forward/.test(pack) &&
    /At most \*\*one\*\* beat shows her from behind/.test(pack) && /three-quarters away and back inside the same beat/.test(pack))
  t('the movement table no longer sends a turn off to the back', !/a turn gives the back its own beat/.test(pack) &&
    /a turn shows the back for a moment inside its own beat and comes back/.test(pack))

  /* the ACTION pool was manufacturing both faults */
  const pools = read('public/prompts/fashion-variation.md')
  const actSec = (pools.split(/^## ACTION$/m)[1] || '').split(/^## /m)[0]
  t('the ACTION pool no longer walks her out of frame', !/walking out of frame/i.test(actSec) &&
    /never walks out of frame/.test(actSec))
  t('the ACTION pool counts its steps and keeps the floor in frame',
    /Two or three grounded steps toward the lens/.test(actSec) && /both feet never off it at once/.test(actSec))

  /* the templates that carried the same defect */
  const T = (f) => read('public/prompts/templates/' + f)
  const tour = T('tour-grammar.md'), shows = T('ornament-shows.md'), shoot = T('photo-shoot.md')
  const bridal = ['core.md', 'outfit-reveal.md', 'fashion-campaign.md', 'bridal-glamour.md'].map(T).join('\n')
  const all = tour + shows + shoot + bridal
  t('no flow in the library opens on her back', !/\bBACK FIRST\b/.test(all) && !/enters already turned away/.test(all))
  t('no new template describes a full back view any more', !/full back view/.test(tour + shows + shoot))
  t('every entrance in the three new packs is counted in steps',
    (tour.match(/two steps carry her in|two steps carry her from|two grounded steps/g) || []).length >= 8 &&
    /two steps carry her in from the edge of the light and stop where the light falls/.test(shoot))
  t('the walk keeps the floor and her feet in frame wherever it is written',
    /the floor and her feet in frame/.test(tour) && /the floor and her feet in frame/.test(shows) &&
    /the floor and her feet in frame/.test(shoot))
  t('the older walks were corrected too (beach, room showcase, the mirror walk, the threshold)',
    /two grounded steps in from the edge of the frame/.test(bridal) && /takes two steps toward the lens onto her mark/.test(bridal) &&
    /three or four grounded steps along the lit stone/.test(bridal) && /steps through the threshold/.test(bridal))

  /* the palette-wall show now carries the ref's own beats */
  t('the bridal show has the ref signature beats: the veil across, the veil overhead, the hand insert',
    /THE VEIL ACROSS/.test(shows) && /reads through the net/.test(shows) &&
    /THE VEIL OVERHEAD/.test(shows) && /spreads as a canopy/.test(shows) &&
    /THE HAND — the detail insert/.test(shows) && /never a bare ornament/.test(shows))
  t('its flow library carries the ref bookend and the veil-across opening',
    /VEIL ACROSS FIRST/.test(shows) && /BOOKEND =/.test(shows) && /the film returns where it began/.test(shows))

  /* the guard, and the guard's own guard */
  const at = read('scripts/audit-templates.mjs')
  t('the audit measures walk risk and counts back-view beats',
    /WALK RISK/.test(at) && /renders as a hop/.test(at) && /back-view beat\(s\)/.test(at))
  t('the walk check only judges films with a person in them and ignores the camera crossing a threshold',
    /const cameraWalks/.test(at) && /hasWearer && !cameraWalks/.test(at))
  /* the same TDZ class we fixed in the components, caught statically this time */
  t('the audit declares hasWearer before the walk check that uses it',
    at.indexOf('const hasWearer') > 0 && at.indexOf('const hasWearer') < at.indexOf('const distanceWalk'))
}

H('20 · Beat variation: the rhythm is drawn per variant, and the form axes reach the model')
{
  /* The user's report: variants of one template look like one film with a different model in it.
     Cause: every runtime got an even split, and every vary: dimension was content. Fix: rhythm
     envelopes in duration.js, form pools in fashion-variation.md, form axes on the templates. */
  const dur = read('src/lib/duration.js')
  const cho = read('src/lib/choreography.js')
  const off = read('src/lib/offline.js')
  const varMd = read('public/prompts/fashion-variation.md')
  const pack = read('public/prompts/packs/fashion.md')
  const form = read('src/lib/formdims.js')

  t('the clock carries seven named rhythm envelopes, flat first', (() => {
    const L = (dur.match(/id: '[a-z]+', label: '[^']+'/g) || [])
    return L.length === 7 && /id: 'flat'/.test(L[0])
  })())
  t('an envelope is drawn from the run seed and stepped per variant', /pickEnvelopeFor\(ideaSeed, o\.duration, k\)/.test(cho) && /export function pickEnvelopeFor/.test(dur))
  t('a film too short to have a shape falls back to the even split',
    /if \(shots < 3\) return 0/.test(dur) && pickEnvelope(4, 4) === 0 && pickEnvelope(6, 6) === 0 && shotClock(4, 'auto', false, pickEnvelope(4, 4)).envelope === 'flat')
  t('the envelope is handed to both shot-clock call sites', /shotClock\(o\.duration, o\.structure, o\.loop, envIdx\)/.test(cho) && /shotClock\(inp\.duration,inp\.structure,inp\.loop,choreo\.envIdx\)/.test(off))
  t('no window falls under the 1.5s minimum shot, on any envelope at any runtime',
    [8, 10, 12, 15, 20].every((d) => ENVELOPES.every((e, i) => Math.min(...shotClock(d, 'auto', false, i).windows) >= MIN_SHOT)))
  t('the windows sum to the runtime exactly, on every envelope', (() => {
    const rounded = (x) => Math.round(x * 1000) / 1000
    const exactW = [8, 10, 12, 15, 20].every((d) => ENVELOPES.every((e, i) => {
      const c = shotClock(d, 'auto', false, i)
      return rounded(c.windows.reduce((a, b) => a + b, 0)) === d && c.total === d && c.cuts[c.cuts.length - 1] < d
    }))
    /* and the no-envelope path is still byte-identical to every earlier release */
    return exactW && shotClock(10, 'multi3').cuts.join('|') === '3.333|6.667' &&
      JSON.stringify(shotClock(10, 'multi3', false, 0)) === JSON.stringify(shotClock(10, 'multi3')) &&
      shotClock(12, 'auto').cuts.join('|') === '3|6|9'
  })())
  t('every envelope produces its own edit signature', (() => {
    const sigs = ENVELOPES.map((e, i) => shotClock(12, 'auto', false, i).cuts.join())
    return new Set(sigs).size === ENVELOPES.length
  })())
  t('the motion plan names the rhythm and its windows in the instruction block', /RHYTHM: the shot lengths follow a/.test(cho) && /Never even out the cut lengths/.test(cho))
  t('the offline engine composes every shot the clock budgets, not the first three', /for\(let i=2;i<=shotN;i\+\+\)/.test(off) && /isLast\?', then '/.test(off))

  t('the eight form pools are in the variation library', ['RHYTHM ENVELOPE','SCALE LADDER','CUT MOTIVATION','FRAMING DEVICE','OPEN DEVICE','CLOSE DEVICE','TRANSITION','SOUND FORMAT']
    .every((d) => new RegExp('^## ' + d + '$', 'm').test(varMd)))
  t('the never-share set is declared once, in formdims', /export const NEVER_SHARE = \[/.test(form) && /export const NEVER_SHARE_FORM/.test(form) && /export const NEVER_SHARE_ACTS/.test(form))
  t('the variation contract separates form from content and forbids a shared edit signature',
    /FORM vs CONTENT/.test(read('src/lib/prompts.js')) && /NEVER SHARE AXES/.test(read('src/lib/prompts.js')) && /they may never share an edit signature/.test(read('src/lib/prompts.js')))
  t('a dimension that changes the edit is not expected to carry a placeholder token', /splitDims\(t\.vary\)/.test(read('src/lib/lint.js')))
  t('one micro-gesture per beat is law, and stillness is named as the failure', /Every beat carries one micro-gesture/.test(pack) && /never stillness|"Still" is never the instruction/.test(pack))
  t('the bundle carries the form axes', (() => {
    const files = ['core.md','photo-shoot.md','tour-grammar.md','ornament-shows.md','fashion-campaign.md','bridal-glamour.md','bridal-editorial.md','outfit-reveal.md','adaptive-films.md','intimates-reels.md']
    return files.every((f) => (read('public/prompts/templates/' + f).match(/RHYTHM ENVELOPE/g) || []).length >= 1)
  })())
  t('the two-by-two collage keeps its own rhythm and is not forced into the ladder', !/RHYTHM ENVELOPE/.test((read('public/prompts/templates/fashion-campaign.md').split('## ').find((x) => x.startsWith('📱 E-commerce 4-up')) || 'no-nav')))
  t('the audit names the content-only case as clone risk', /a batch swaps what is in the frame without changing the edit/.test(read('scripts/audit-templates.mjs')))
  t('the CLOCK line, the RHYTHM line and the UI chip all read the one drawn shape', (() => {
    const tp = blocks.find((x) => x.t === 'Editorial fashion film')
    const inp = { category: 'Fashion / Lifestyle', idea: 'a woman in a long coat crosses the lit studio', duration: 12, structure: 'auto', target: 'h3', workflow: 't2v', templateVary: tp.vary, variantIndex: 1, variantTotal: 2, templateTitle: tp.t, templateTag: tp.tag || '' }
    const shapes = [1, 2].map((k) => {
      const m = buildUserMessage({ ...inp, variantIndex: k }, k, 2)
      const live = liveClock({ ...inp, variantIndex: k }, k)
      const clock = (m.match(/\[Shot 2\] opens at (\d\d:\d\d\.\d\d\d)/) || [])[1]
      return { live, clock, m }
    })
    return shapes.every((x) => x.clock === fmtTC(x.live.cuts[0])) &&
      shapes[0].live.envelope !== shapes[1].live.envelope &&
      shapes.every((x) => new RegExp('RHYTHM: the shot lengths follow a ' + x.live.envelopeLabel.split(' — ')[0]).test(x.m))
  })())
  t('the research and the shipped numbers are written down', /pink noise|1\/f/.test(read('docs/beat-variation-2026-09.md')) && /4\.26 \/ 3\.29 \/ 2\.52/.test(read('docs/beat-variation-2026-09.md')))
}

H('21 · Act variation: two variants may not do the same things')
{
  /* The user's second report: "2 bridal video made can not be same action/movement with only model
     and clothing changed". The engine rotated one fixed bank, so the acts were 100% shared between
     variants; the bridal templates declared no act dimension at all. */
  const cho = read('src/lib/choreography.js')
  const dur = read('src/lib/duration.js')
  const form = read('src/lib/formdims.js')
  const pools = read('public/prompts/fashion-variation.md')
  const BRIDE = 'a woman in a crimson bridal lehenga with heavy zardozi work walks into the light'
  const plan = (k, extra) => motionPlan({ idea: BRIDE, title: 'Bridal tour', duration: 16, structure: 'auto', variantIndex: k, ...(extra || {}) })
  const shared = (a, b) => a.filter((x) => b.includes(x)).length

  t('every motion family carries a real act bank and a set of presenting gestures',
    MOTION_FAMILIES.every((f) => f.move.length >= 14 && f.present.length >= 6))
  t('the bridal family carries the acts the refs use, not just drape physics', (() => {
    const eth = MOTION_FAMILIES.find((f) => f.id === 'ethnic')
    return /veil is drawn down across her face/.test(eth.move.join(' ')) && /spread overhead/.test(eth.move.join(' ')) &&
      /bangles/.test(eth.move.join(' ')) && /gajra/.test(eth.move.join(' ')) && /anklet/.test(eth.move.join(' '))
  })())
  t('two variants of one bridal run share no act at all',
    shared(plan(1).moves, plan(2).moves) === 0 && shared(plan(1).moves, plan(2).moves) === 0)
  t('three variants share no act at all', (() => {
    const P = [plan(1), plan(2), plan(3)]
    for (let i = 0; i < 3; i++) for (let j = i + 1; j < 3; j++) if (shared(P[i].moves, P[j].moves)) return false
    return true
  })())
  t('a variant never repeats its own act inside one film',
    new Set(plan(2).moves).size === plan(2).moves.length)
  t('the act bank is shuffled per idea, not per variant — the variant index only picks the block',
    /const ideaSeed = hash\(idea \+ '\|' \+ \(o\.title \|\| ''\)\)/.test(cho) && /block\(actBank, ideaSeed, n, k\)/.test(cho) &&
      !/rot\(fam\.move/.test(cho))
  t('a wrapped pass is re-shuffled so it cannot repeat an earlier variant exactly',
    /const round = Math\.floor\(walked \/ arr\.length\)/.test(cho) && /seed \+ round \* 104729/.test(cho))
  t('the presenting gesture is drawn per variant too',
    /block\(fam\.present, ideaSeed, 1, k\)/.test(cho) && plan(1).presents[0] !== plan(2).presents[0])
  t('consecutive variants get consecutive rhythms, never a collision',
    /export function pickEnvelopeFor/.test(dur) && new Set([1, 2, 3, 4, 5, 6, 7].map((k) => pickEnvelopeFor(12345, 16, k))).size === 7)
  t('a seated act never lands in a walking flow, and a seated flow keeps it',
    /SEATED_RE/.test(cho) && /wantsSeated/.test(cho) &&
    !/sits|seated|folds her hands in her lap/.test(plan(1, { flowName: 'WALK THE GROUND' }).moves.join(' ')) &&
    /sits|seated|folds her hands in her lap/.test(plan(1, { flowName: 'SEAT AND SETTLE' }).moves.join(' ')))
  t('the motion block names the act set and forbids an act from outside it',
    /this variant\\'s act set/.test(cho) && cho.includes('these acts only') && cho.includes('Do NOT stage an act outside this set') &&
    /two films that share their movements read as one film with a different model in it/.test(cho))
  t('the never-share set covers the acts, and the two sub-lists are exported',
    /NEVER_SHARE = \['RHYTHM ENVELOPE', 'SCALE LADDER', 'FRAMING DEVICE', 'CUT MOTIVATION', 'ACTION', 'MOVEMENT', 'PRESENTATION'\]/.test(form) &&
    /NEVER_SHARE_FORM/.test(form) && /NEVER_SHARE_ACTS/.test(form))
  t('the contract states that what she does is not shared',
    /WHAT SHE DOES IS NOT SHARED/.test(read('src/lib/prompts.js')) &&
    /may not walk the same way, turn the same way/.test(read('src/lib/prompts.js')) &&
    read('src/lib/prompts.js').includes('ONE film with a different model and different clothes'))
  t('the action pools are deep enough that option #k is a different act',
    ['ACTION', 'MOVEMENT', 'PRESENTATION'].every((d) => {
      const body = (pools.split(new RegExp('^## ' + d + '$', 'm'))[1] || '').split(/^## /m)[0]
      return (body.match(/^\d+\. /gm) || []).length >= 12
    }))
  t('the fashion templates declare the act dimensions', (() => {
    const files = ['tour-grammar.md', 'ornament-shows.md', 'bridal-editorial.md', 'bridal-glamour.md', 'photo-shoot.md', 'core.md', 'fashion-campaign.md', 'outfit-reveal.md']
    let n = 0
    for (const f of files) for (const b of parseTemplatesMd(read('public/prompts/templates/' + f)))
      if (b.vary && b.vary.length && ['ACTION', 'MOVEMENT', 'PRESENTATION'].every((d) => b.vary.includes(d))) n++
    return n >= 25
  })())
  t('the two bridal templates carry all three act dimensions',
    [['tour-grammar.md', /Bridal tour/], ['ornament-shows.md', /Palette-wall/], ['ornament-shows.md', /Heirloom jewellery/], ['bridal-glamour.md', /Modern bridal glamour/], ['bridal-editorial.md', /Bridal editorial/]]
      .every(([f, re]) => {
        const b = parseTemplatesMd(read('public/prompts/templates/' + f)).find((x) => re.test(x.t))
        return b && ['ACTION', 'MOVEMENT', 'PRESENTATION'].every((d) => b.vary.includes(d))
      }))
  t('the audit reports a template that varies nothing about what she does',
    /varies nothing about what she does/.test(read('scripts/audit-templates.mjs')))
  t('the measured proof is written down', /0 of 4 shared acts|Act overlap between them: 0/.test(read('docs/beat-variation-2026-09.md')))
}

H('22 · The model: 20-32 unless the request names an age, young and model-quality')
{
  /* User law: "keep models between 20-32, unless specified. Young, beautiful fashion model quality." */
  const lock = read('src/lib/prompts.js')
  const craft = read('public/prompts/shared/craft-detail-and-cast.md')
  const pack = read('public/prompts/packs/fashion.md')
  const forge = read('public/prompts/template-forge.md')
  const off = read('src/lib/offline.js')

  t('the cast lock injected into every fashion generation carries the band, the register and the floor',
    /MODEL AGE AND QUALITY - 20 TO 32 UNLESS THE REQUEST NAMES AN AGE/.test(lock) &&
    /fashion-model quality/.test(lock) && /Never a teenager/.test(lock) &&
    /overrides the band, and that age then becomes the lock/.test(lock))
  t('it reaches the model in the message, not only in the file', (() => {
    const m = buildUserMessage({ category: 'Fashion / Lifestyle', idea: 'a woman in a long coat', duration: 10, structure: 'multi3', target: 'h3', workflow: 't2v' }, 1, 1)
    return /CAST LOCK/.test(m) && /20 TO 32 UNLESS THE REQUEST NAMES AN AGE/.test(m)
  })())
  t('detail density asks for one age in the band, not a range',
    /a concrete age inside 20-32 unless the request names one/.test(lock) &&
    !/SUBJECT - age range/.test(lock))
  t('the shared craft file carries it for all four system prompts',
    /MODEL AGE — 20 TO 32 UNLESS THE REQUEST NAMES AN AGE/.test(craft) && /ONE age inside the band/.test(craft) &&
    /never a school setting used to imply one/.test(craft))
  t('the fashion pack carries the law, with the real-person register as the stated exception',
    /THE MODEL IS 20 TO 32/.test(pack) && /fashion-model quality/.test(pack) &&
    /real-person register/.test(pack) && /still an adult and still in the band unless the request says otherwise/.test(pack))
  t('the forge teaches it to every new template', /one age inside the 20-32 model band/.test(forge))
  t('every template that casts a person states the band', (() => {
    let casts = 0
    for (const f of readdirSync('public/prompts/templates').filter((x) => x.endsWith('.md') && !/README|user-templates/.test(x))) {
      for (const b of parseTemplatesMd(read('public/prompts/templates/' + f))) {
        const body = (b.b || '') + ' ' + (b.idea || '')
        if (!/\{(MODEL|WEARER|CREATOR|BRIDE)\b|\{SUBJECT(?! MODEL|\/PRODUCT)/.test(body)) continue
        casts++
        if (!/20-32|20 TO 32/.test(body)) return false
      }
    }
    return casts >= 40
  })())
  t('no template names an age outside the band', (() => {
    for (const f of readdirSync('public/prompts/templates').filter((x) => x.endsWith('.md') && !/README|user-templates/.test(x))) {
      for (const b of parseTemplatesMd(read('public/prompts/templates/' + f))) {
        const txt = (b.b || '') + ' ' + (b.idea || '')
        for (const m of txt.matchAll(/\b(1[0-9]|[2-9][0-9])\s*(?:years? old|yo\b|y\/o)/gi)) if (+m[1] < 20 || +m[1] > 32) return false
        for (const m of txt.matchAll(/\b(teens|teenager|forties|middle-?aged|elderly)\b/gi)) return false
      }
    }
    return true
  })())
  t('the instant engine states a concrete age in the band', (() => {
    for (const idea of ['a woman in a crimson lehenga', 'a bride at a haveli', 'a model in a grey wool coat', 'a dancer in a silk slip dress']) {
      const m = modelLine(idea).match(/THE MODEL IS (\d+) YEARS OLD/)
      if (!m || +m[1] < 20 || +m[1] > 32) return false
    }
    return true
  })())
  t('an age named in the idea wins over the band', (() => {
    const m = modelLine('a 38-year-old woman in a grey wool coat and a silk scarf')
    return /THE MODEL IS 38/.test(m) && !/YEARS OLD — the same woman/.test(m)
  })())
  t('the age is drawn per idea, so one run keeps one woman', (() => {
    const a = modelLine('a woman in a crimson lehenga walking into the light').match(/THE MODEL IS (\d+)/)[1]
    const b = modelLine('a woman in a crimson lehenga walking into the light').match(/THE MODEL IS (\d+)/)[1]
    return a === b
  })())
  t('both offline generators print it', /\+model(\+chain)?;/.test(off) &&
    /A woman of \d\d|in her mid-twenties/.test(String(genVariantLtxOffline({ idea: 'a woman in a crimson lehenga walking into the light', duration: 10, ratio: '9:16', resolution: '768P', palette: 'Auto', camera: 'Auto', style: 'Auto', music: 'subtle', detail: true }, 1, 1).prompt || '')))
  t('the audit flags an out-of-band age and a cast with no band',
    /names an age outside the 20-32 model band/.test(read('scripts/audit-templates.mjs')) &&
    /never states the 20-32 model band/.test(read('scripts/audit-templates.mjs')))
}

H('23 · Outfit-tour coverage: every wear type shoots like the room tour')
{
  /* The user asked for outfit tours across more types of womenswear. Each new block has to pass the
     same bar as the benchmark: locked lens, OPEN first, CLOSE last, beats as HER acts, conditional
     features, four flows, a timing clause derived from the clock, and the 20-32 cast band. */
  const pack = read('public/prompts/templates/outfit-tours.md')
  const blocks = parseTemplatesMd(pack)
  const covers = ['Denim', 'Coat', 'Knit', 'Athleisure', 'Evening', 'Festive ethnic', 'Saree', 'Modest', 'Tailoring',
    'Swimwear', 'Bohemian', 'Nightwear', 'Lingerie', 'Ski', 'Streetwear']

  t('the outfit-tour pack parses with fifteen tours', blocks.length === 15)
  t('every wear type in the brief is covered', covers.every((c) => blocks.some((b) => b.t.includes(c))))
  t('every one is a locked-camera, auto-cut tour', blocks.every((b) => b.settings.camera === 'Static shot' && b.settings.structure === 'auto' && b.settings.ratio === '9:16'))
  t('every one opens on her and closes on her', blocks.every((b) => /OPEN is always first/.test(b.b) && /CLOSE is always last/.test(b.b)))
  t('every one keeps the lens out of the travelling', blocks.every((b) => /no travel, no zoom, no orbit|never travels, never zooms, never orbits/.test(b.b) && /change[s]? of (frame size|scale) (is|comes from) her|changes the frame by/.test(b.b)))
  t('every one writes the beats as her acts, one per beat', blocks.every((b) => /ONE ACT PER BEAT/.test(b.b) && /one (small )?physical act of about a second/.test(b.b)))
  t('every one makes its feature beats conditional and never invented', blocks.every((b) => /FEATURE BEATS — each used only if the idea names that element, none invented/.test(b.b)))
  t('every one carries four flows and defines them in its own library', blocks.every((b) => (b.flows || []).length === 4 && b.flows.every((f) => (b.b.match(/FLOW LIBRARY[\s\S]{0,1600}/) || [''])[0].includes(f))))
  t('every one derives its beats from the live clock and holds the ground law', blocks.every((b) => /TIMING: derive every cut from the live CLOCK/.test(b.b) && /never a distance/.test(b.b)))
  t('every one casts in the 20-32 band', blocks.every((b) => /20-32 unless specified/.test(b.idea || '')))
  t('every one closes its layer stack', blocks.every((b) => /LAYER STACK/.test(b.b) && /footwear|trainer|shoe|sneaker|heel|sandal|loafer|boot/.test(b.b)))
  t('the pack carries no stamped cut times', !/\d{2}:\d{2}\.\d{3}/.test(pack))
  t('the two new garment pools exist and are deep enough', (() => {
    const pools = read('public/prompts/fashion-variation.md')
    return ['DENIM AND WASH', 'WEAVE AND TEXTILE'].every((d) => {
      const body = (pools.split(new RegExp('^## ' + d + '$', 'm'))[1] || '').split(/^## /m)[0]
      return (body.match(/^\d+\. /gm) || []).length >= 6
    })
  })())
  t('the saree and denim tours declare their own garment dimensions',
    blocks.find((b) => b.t.includes('Saree')).vary.includes('WEAVE AND TEXTILE') &&
    blocks.find((b) => b.t.includes('Denim')).vary.includes('DENIM AND WASH'))
  t('every block states its own register rather than a generic fashion film', (() => {
    const register = { Denim: /twill|stack at the ankle|fade/, Coat: /wool|leather|removal/, Knit: /stitch|yarn|cuff/, Athleisure: /compression|mat|trainer/, Evening: /hem|train|gown/, 'Festive ethnic': /drape|kurta|dupatta/, Saree: /pleat|pallu|border/, Modest: /drape|hem|sleeve/, Tailoring: /crease|lapel|trouser/,
      Swimwear: /sun key|water|strap/, Bohemian: /print|fringe|shawl/, Nightwear: /robe|morning light|seam/, Lingerie: /lace|dressing room|robe/, Ski: /zip|hood|goggle/, Streetwear: /sneaker|pavement|hood/ }
    return Object.entries(register).every(([k, re]) => re.test(blocks.find((b) => b.t.includes(k)).b))
  })())
  t('the guide names the new coverage', /outfit tour/i.test(read('docs/outfit-tour-coverage-2026-09.md')))
}

H('24 · The space has depth and dress — never a bare room')
{
  /* The user's correction: the tour family had banned set dressing ("nothing in frame but the room,
     no prop, no set dressing"), which flattened every film into a bare sweep. The space is now a
     place — three planes, materials, real objects, one practical — and the dress still never performs. */
  const OUT = parseTemplatesMd(read('public/prompts/templates/outfit-tours.md'))
  const GRAM = parseTemplatesMd(read('public/prompts/templates/tour-grammar.md'))
  const all = OUT.concat(GRAM)

  t('every tour builds the space in three planes', all.every((b) => /NEAR plane/.test(b.b) && /FAR plane/.test(b.b) && /the MIDDLE where she stands/.test(b.b)))
  t('every tour names materials and real objects', all.every((b) => /the materials are named/.test(b.b) && /two or three real objects/.test(b.b) && /one practical source/.test(b.b)))
  t('the dress never performs', all.every((b) => /nothing moves on its own, nothing takes a beat/.test(b.b)))
  t('no tour forbids dressing any more', !/no prop, no set dressing|nothing in frame but the room|nothing else in frame, and the two positions|nothing in frame but the ground|no furniture, no prop|nothing is placed in the pools but her/.test(read('public/prompts/templates/outfit-tours.md') + read('public/prompts/templates/tour-grammar.md')))
  t('the bare studio is no longer an offered look', !/^1\. A bare concrete studio/m.test(read('public/prompts/fashion-variation.md')))
  t('the culture guards survive the dress law',
    /no mandap, no idol, no ritual prop/.test(GRAM.find((b) => /Bridal tour/.test(b.t)).b) &&
    /No religious object, and nothing festive-specific/.test(OUT.find((b) => /Festive ethnic/.test(b.t)).b))
  t('SPACE AND DRESS is a real pool, deep enough to vary', (() => {
    const body = (read('public/prompts/fashion-variation.md').split(/^## SPACE AND DRESS$/m)[1] || '').split(/^## /m)[0]
    return (body.match(/^\d+\. /gm) || []).length >= 8
  })())
  t('all fifteen outfit tours vary the space and carry its token',
    OUT.every((b) => b.vary.includes('SPACE AND DRESS') && /\{SPACE AND DRESS — /.test(b.idea || '')))
  t('the engine carries the law, not just the templates',
    /THE SPACE HAS DEPTH AND DRESS/.test(read('public/prompts/packs/fashion.md')) &&
    /DEPTH AND DRESS/.test(read('public/prompts/shared/craft-detail-and-cast.md')) &&
    /a near plane just inside the frame/.test(read('src/lib/prompts.js')))
  t('both fallback system prompts dress the space', (read('src/lib/prompts.js').match(/never a bare room/g) || []).length >= 2)
  t('the space dimension is nameable in the audit vocabulary',
    (() => { const pools = read('public/prompts/fashion-variation.md'); return /^## SPACE AND DRESS$/m.test(pools) })())
}

H('25 · Six more wear types — swim, boho, night, intimates, ski, street')
{
  /* The second coverage pass: the categories a womenswear library is asked for that the first
     nine tours did not hold. Same engine, same laws — plus the two restraint guards the two
     registers with bare skin need (they stay fashion films, never reveals). */
  const OUT = parseTemplatesMd(read('public/prompts/templates/outfit-tours.md'))
  const pick = (n) => OUT.find((b) => b.t.includes(n))
  const pack = read('public/prompts/templates/outfit-tours.md')
  /* a register guard may be stated in the block or in its card tip, whichever the register reads better in */
  const prose = (n) => pick(n).b + ' ' + (pick(n).tip || '')

  t('the six new registers are all present', ['Swimwear', 'Bohemian', 'Nightwear', 'Lingerie', 'Ski', 'Streetwear'].every((n) => !!pick(n)))
  t('each one carries its own garment dimension', [
    ['Swimwear', 'SWIM AND COVER'], ['Bohemian', 'PRINT AND TEXTURE'], ['Nightwear', 'FABRIC AND FINISH'],
    ['Lingerie', 'SILK AND LACE'], ['Ski', 'WINTER KIT'], ['Streetwear', 'STREET LAYERS'],
  ].every(([n, d]) => pick(n).vary.includes(d) && new RegExp('\\{' + d + ' — ').test(pick(n).idea || '')))
  t('each one is backed by a pool of at least six options', (() => {
    const pools = read('public/prompts/fashion-variation.md')
    return ['SWIM AND COVER', 'PRINT AND TEXTURE', 'FABRIC AND FINISH', 'SILK AND LACE', 'WINTER KIT', 'STREET LAYERS'].every((d) => {
      const body = (pools.split(new RegExp('^## ' + d + '$', 'm'))[1] || '').split(/^## /m)[0]
      return (body.match(/^\d+\. /gm) || []).length >= 6
    })
  })())
  t('every one wears real garment names, never a category word', ['Swimwear', 'Bohemian', 'Nightwear', 'Lingerie', 'Ski', 'Streetwear']
    .every((n) => /\b(maillot|linen shirt|sarong|blouse|maxi|shawl|charpai|pyjama|robe|slip|lace|shell|gilet|gaiter|hoodie|overshirt|cargo|sneaker)\b/.test(pick(n).b)))
  t('each one adds its own feature beats rather than borrowing another register\'s', [
    ['Swimwear', ['THE WATER LINE', 'THE COVER-UP', 'THE SUN']],
    ['Bohemian', ['THE FRINGE', 'THE COIN BELT', 'THE HAT']],
    ['Nightwear', ['THE ROBE', 'THE TURNED CUFF', 'THE CUP']],
    ['Lingerie', ['THE LACE EDGE', 'THE MIRROR', 'THE MULE']],
    ['Ski', ['THE ZIP', 'THE HOOD', 'THE GOGGLES']],
    ['Streetwear', ['THE SNEAKER', 'THE BAG STRAP', 'THE LAYER']],
  ].every(([n, beats]) => beats.every((x) => pick(n).b.includes(x))))

  /* the two restraint guards — the intimates and swim registers stay fashion films */
  t('the lingerie tour states she is dressed throughout and nothing is removed',
    /SHE IS DRESSED THROUGHOUT/.test(pick('Lingerie').b) && /nothing is removed, unfastened or adjusted under the cloth/.test(pick('Lingerie').b) && /no beat is a reveal/.test(pick('Lingerie').b))
  t('the lingerie and swim tours keep the camera at chest height or above and refuse a low angle',
    /chest height or above/.test(prose('Lingerie')) && /no low angle/.test(pick('Lingerie').b) &&
    /chest height or above/.test(prose('Swimwear')))
  t('the swim cover-up is arranged, never a reveal', /it is arranged rather than removed/.test(pick('Swimwear').b) && /never a reveal/.test(prose('Swimwear')))
  t('the nightwear tour stays out of the bed', /up and dressed in the set/.test(prose('Nightwear')) && /not a bed scene/.test(prose('Nightwear')))
  t('nothing in the pack names nudity or an explicit act', !/\b(nude|naked|topless|nsfw|erotic|explicit|undress\w*|striptease)\b/i.test(pack.replace(/nothing is removed, unfastened[^.]*/g, '')))
  t('every tour in the pack still ends on CLOSE FIRST as an offered flow', OUT.filter((b) => !(b.flows || []).includes('CLOSE FIRST')).length === 0)
  t('the new registers keep the cast band and the space law', ['Swimwear', 'Bohemian', 'Nightwear', 'Lingerie', 'Ski', 'Streetwear']
    .every((n) => /20-32 unless specified/.test(pick(n).idea || '') && /NEAR plane/.test(pick(n).b) && /the materials are named/.test(pick(n).b)))
  t('the pack is still one file with nothing stamped', !/\d{2}:\d{2}\.\d{3}/.test(pack) && OUT.length === 15)
}

H('26 · Fifteen tours, fifteen vocabularies — and the realism law')
{
  /* The user's ask: every tour unique, each carrying presentation, location, model, mood and aesthetic —
     and "next level of realism". Uniqueness is now measured: each tour owns every beat name it uses
     except THE FACE (the house close) and every flow name except CLOSE FIRST (the house close-first
     option). Realism is a written law in each block and in the engine. */
  const OUT = parseTemplatesMd(read('public/prompts/templates/outfit-tours.md'))
  const beatNames = (x) => {
    const sec = x.b.split('none invented: ')[1].split('FLOW LIBRARY')[0]
    return (sec.match(/(?:^|[.;] )([A-Z][A-Z0-9' \-]{2,28}?) — /g) || []).map((s) => s.replace(/^[.;] ?/, '').replace(/ — $/, '').trim())
  }
  const owners = new Map()
  for (const x of OUT) for (const n of beatNames(x)) owners.set(n, (owners.get(n) || 0) + 1)
  const flowOwners = new Map()
  for (const x of OUT) for (const f of x.flows) flowOwners.set(f, (flowOwners.get(f) || 0) + 1)

  t('the pack is fifteen tours', OUT.length === 15)
  t('only the house close beat is shared — every other beat name belongs to one tour',
    [...owners.entries()].filter(([, n]) => n > 1).every(([name]) => name === 'THE FACE'))
  t('only CLOSE FIRST is a shared flow — every other flow name belongs to one tour',
    [...flowOwners.entries()].filter(([, n]) => n > 1).every(([f]) => f === 'CLOSE FIRST'))
  t('every tour owns at least seven beats of its own', OUT.every((x) => beatNames(x).filter((n) => owners.get(n) === 1).length >= 7))
  t('every tour opens on its own lighting sentence, and the beat counts stay in an 8-10 band',
    (() => {
      const open = (x) => { const i = x.b.search(/(768P|2K), /); return i < 0 ? x.t : x.b.slice(i + 7, i + 87) }
      return new Set(OUT.map(open)).size === 15 && OUT.every((x) => beatNames(x).length >= 8 && beatNames(x).length <= 10)
    })())

  /* the required presentation fields, per tour */
  t('every tour states presentation, location, model, mood and aesthetic as fields',
    OUT.every((x) => /\{PRESENTATION — /.test(x.idea) && /\{LOCATION — /.test(x.idea) && /\{MODEL — 20-32 unless specified/.test(x.idea) &&
      /\{MOOD — /.test(x.idea) && /\{AESTHETIC AND GRADE — /.test(x.idea)))
  t('mood and aesthetic are live varying dimensions with their own pools', (() => {
    const pools = read('public/prompts/fashion-variation.md')
    return ['MOOD', 'AESTHETIC AND GRADE'].every((d) => {
      const body = (pools.split(new RegExp('^## ' + d + '$', 'm'))[1] || '').split(/^## /m)[0]
      return (body.match(/^\d+\. /gm) || []).length >= 8
    }) && OUT.every((x) => x.vary.includes('MOOD') && x.vary.includes('AESTHETIC AND GRADE'))
  })())
  t('no two tours carry the same mood or the same grade guidance', (() => {
    const moods = OUT.map((x) => (x.idea.match(/\{MOOD — ([^}]+)\}/) || [])[1])
    const grades = OUT.map((x) => (x.idea.match(/\{AESTHETIC AND GRADE — ([^}]+)\}/) || [])[1])
    return new Set(moods).size === 15 && new Set(grades).size === 15
  })())

  /* next level of realism */
  t('every tour carries the realism law', OUT.every((x) => /REALISM FIRST: the frame is a capture, not a render/.test(x.b)))
  t('the realism law refuses the render look in every tour',
    OUT.every((x) => /No smoothing, no plastic sheen, no beauty filter, no morphing, no floating objects, no text in frame/.test(x.b)))
  t('each tour names its own material proof', (() => {
    const proof = { Denim: /twill's diagonal weave/, Coat: /wool's nap/, Knit: /yarn's fuzz/, Athleisure: /compression knit's matte stretch marks/,
      Evening: /silk's slubs/, Festive: /thread standing proud/, Saree: /zari as metal/, Modest: /weight in the folds/, Tailoring: /press of the crease/,
      Swimwear: /salt drying on skin/, Bohemian: /dye bleeding at the selvedge/, Nightwear: /nap of brushed cotton/, Lingerie: /lace as thread/,
      Ski: /breath vapour in the cold/, Streetwear: /fleece pilling slightly/ }
    return Object.entries(proof).every(([k, re]) => re.test(OUT.find((x) => x.t.includes(k)).b))
  })())
  t('the laws are unique to each tour rather than a pasted paragraph',
    new Set(OUT.map((x) => (x.b.split('REALISM FIRST')[1] || '').split('TIMING:')[0])).size === 15)
  t('the engine carries the realism law, not only the templates',
    /REALISM FIRST — A CAPTURE, NOT A RENDER/.test(read('public/prompts/packs/fashion.md')) &&
    /^- REALISM:/m.test(read('public/prompts/shared/craft-detail-and-cast.md')) &&
    /REALISM - write the frame as a capture, not a render/.test(read('src/lib/prompts.js')))
  t('both fallback system prompts ask for a photographic frame',
    (read('src/lib/prompts.js').match(/real skin texture, real fabric, honest light, no smoothing and no plastic sheen/g) || []).length >= 2)
}

/* ------------------------------------------------------------------------------------------------
   §27 · Engine contracts — H3 and LTX
   A prompt must satisfy the engine it is written for: the official H3 contract (three fields in
   order, [Shot 1] untimestamped, later shots timecoded and strictly increasing inside the runtime,
   4–15s per generation with anything longer declared as a chain, camera amplitude and speed in
   plain words, no director instructions, music = instrumentation and tempo) and the LTX contract
   (one flowing present-tense paragraph, no labels or numbered shots or timecodes, emotion as a
   physical cue, one motivated camera move with a named end-state, sentences spaced to the duration,
   a real negative_prompt). These pins generate from the shipped library and check the finished
   prompt — the contract is verified in code, not only taught to the model.
------------------------------------------------------------------------------------------------ */
H('§27 · Engine contracts — H3 and LTX')
{
  const DIRS = ['public/prompts/templates/']
  const SKIP = /starter|user-templates|README/
  /* every placeholder is filled the way the app fills it: hint text where there is a hint, the
     token's own words where there is not — and no braces survive into the prompt */
  const fillIdea = (txt) => String(txt)
    .replace(/\{([A-Z][A-Z0-9' \-]{2,30})(?: — ([^}]*))?\}/g, (m, name, hint) => {
      if (hint) return hint.split(/\bor exactly\b/)[0].split(/,(?=[^,]*\bor\b)/)[0].split('·')[0].replace(/\{[^}]*\}/g, 'x').replace(/\s+/g, ' ').trim().slice(0, 140)
      const k = name.toUpperCase()
      if (/BEAT/.test(k)) return 'she crosses the room and stops at the window'
      if (/POSE|CLOSE|END/.test(k)) return 'a settled pose, chin level, eyes to the lens'
      if (/LINE|DIALOGUE|SPEECH|VO/.test(k)) return 'one short spoken line'
      if (/SUBJECT|PRODUCT|CREATOR|CHARACTER|MODEL|PERSON/.test(k)) return 'the woman in frame'
      if (/LIGHT|PARTICLE/.test(k)) return 'one practical light catching the dust in the air'
      if (/ACTION|MOVE|GESTURE/.test(k)) return 'she turns a shoulder toward the light'
      return name.toLowerCase().replace(/[_/]/g, ' ')
    })
    .replace(/\{([^}\n]{2,120})\}/g, (m, inner) => inner.split(/[—–]/)[0].trim().toLowerCase().replace(/[_/]/g, ' '))

  const blocks = []
  for (const d of DIRS) for (const f of readdirSync(join(ROOT, d))) {
    if (!f.endsWith('.md') || SKIP.test(f)) continue
    for (const b of parseTemplatesMd(read(join(d, f)))) blocks.push({ f, b })
  }
  const run = (b) => {
    const st = b.settings || {}
    return {
      idea: fillIdea(b.idea), style: 'Auto', camera: st.camera || 'Static shot', amp: st.amp || 'small', speed: st.speed || 'slow',
      palette: 'Auto', duration: st.duration || 12, ratio: st.ratio || '9:16', resolution: st.resolution || '768P',
      music: st.music || 'subtle', structure: st.structure, title: b.t, detail: true, phValues: {}, templateGuide: { t: b.t, b: b.b },
    }
  }
  const h3 = [], ltx = []
  for (const { b } of blocks) {
    const inp = run(b)
    h3.push(checkH3(await genVariantOffline(inp, 1, 1), inp))
    ltx.push(checkLtx(genVariantLtxOffline({ ...inp, target: 'ltx' }, 1, 1), inp))
  }
  const firstBreak = (rs) => { const i = rs.findIndex((r) => !r.ok); return i < 0 ? '' : blocks[i].f + ' :: ' + blocks[i].b.t.slice(0, 30) + ' → ' + rs[i].violations.map((v) => v.label).join(' · ') }

  t('H3: every shipped block generates a compliant prompt (' + blocks.length + ' blocks, ' + h3[0].checks.length + ' checks each) — ' + (firstBreak(h3) || 'no breaks'), h3.every((r) => r.ok))
  t('LTX: every shipped block generates a compliant paragraph (' + blocks.length + ' blocks, ' + ltx[0].checks.length + ' checks each) — ' + (firstBreak(ltx) || 'no breaks'), ltx.every((r) => r.ok))
  t('the library is the whole shipped set, not a sample', blocks.length >= 150)
  t('a runtime past the H3 window is declared as a chain, and only then is it accepted', (() => {
    const long = blocks.filter(({ b }) => Number((b.settings || {}).duration) > H3_MAX_SECS)
    return long.length > 0 && long.every(({ b }) => /chain of \d+ segments, each inside the 4–15-second window/.test(run(b).idea) === false)
  })() || (() => {
    const inp = run(blocks[0].b); inp.duration = 20
    const r = checkH3({ integrated_multimodal_description: '[Shot 1] A 20-second, 6-shot sequence: a woman walks. [Shot 2] At 00:04.000, the cut lands on the hem.', overall_soundscape: 'room tone.', non_diegetic_music: 'N/A' }, inp)
    return !r.checks.find((c) => /past the single-film window/.test(c.label)).ok
  })())
  t('a director instruction never reaches a finished prompt, wherever it came from',
    scrubDirectives('She lifts the chin. Establish her once at full scale, then cut to the wall. the flow sets the rest.') === 'She lifts the chin.'
      && !/Establish|the flow sets/.test(scrubDirectives('Opens wide enough to hold it, then cuts closer. She lifts the chin.')))
  t('the contract is folded into the quality score, so a card cannot look clean and break its engine',
    /checkH3\(v, inp \|\| \{\}\)/.test(read('src/lib/scoring.js')) && /scoreLtx/.test(read('src/lib/scoring.js')))
  t('the cards show the contract they were written for',
    /checkH3Contract\(v, inp \|\| \{\}\)/.test(read('src/components/OutputPanel.jsx')) &&
    /checkLtx\(v, inp \|\| \{\}\)/.test(read('src/components/OutputPanel.jsx')) && /'🎬 H3 contract '|H3 contract/.test(read('src/components/OutputPanel.jsx')))
  t('the fallback critique judges each engine by its own contract',
    /const sc = isLtx \? scoreLtx\(card\.v, card\.inp\) : scoreH3\(card\.v, card\.inp\)/.test(read('src/components/StudioForm.jsx')))
  t('the template lint carries a contract row',
    /🎬 LTX contract|🎬 H3 contract/.test(read('src/lib/lint.js')))
  t('converting an H3 prompt to LTX strips the H3 protocol first', (() => {
    const c = read('src/lib/convert.js')
    return /const scrub = \(txt\)/.test(c) && /integrated_multimodal_description\|overall_soundscape/.test(c) && /\\\[Shot\\s\*\\d\+\\\]/.test(c)
  })())
  t('the director-instruction pattern has one home, shared by the scrub and the check',
    /import \{ DIRECTIVE_RE \} from '\.\/contracts\.js'/.test(read('src/lib/offline.js')))
  t('the contract badge and the line that explains it are one function', typeof contractLine === 'function')
}

console.log(fails ? '\n❌ ' + fails + ' failing check(s)' : '\n✅ all self-test suites pass')
process.exit(fails ? 1 : 0)
