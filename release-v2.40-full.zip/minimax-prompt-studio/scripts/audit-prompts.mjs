/* Prompt-corpus auditor — run with:  npm run audit
   Checks the three layers (base prompts · craft packs · templates) for the things that
   actually rot in a modular prompt system: size, drift/duplication, routing gaps,
   coverage, and template shape. Prints a report and writes docs/prompt-audit.md. */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { parseTemplatesMd } from '../src/lib/templates.js'
import { scanTemplates, templateFolders } from './templatescan.mjs'
import { parsePackMd, resolvePacks, packText } from '../src/lib/packs.js'
import { lintTemplate } from '../src/lib/lint.js'
import { tokensIn, uniqueTokens } from '../src/lib/tokens.js'
import { resolveIncludes } from '../src/lib/sysfiles.js'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const P = (p) => path.join(root, p)
const read = (p) => fs.readFileSync(P(p), 'utf8')
const lines = []
const say = (s = '') => { lines.push(s); console.log(s) }
const H = (t) => { say(); say('## ' + t); say() }

/* ---------- load ---------- */
const BASE = ['system-prompt.md', 'system-prompt-mature.md', 'ltx-system-prompt.md', 'ltx-system-prompt-mature.md']
/* a system prompt may pull in other .md files (@include) — size what the model receives */
const sysRead = (p) => read('public/' + p)
const RESOLVED = {}
for (const f of BASE) {
  const res = await resolveIncludes(sysRead('prompts/' + f), 'prompts/' + f, sysRead)
  RESOLVED[f] = res
}
const packDir = P('public/prompts/packs')
const packFiles = fs.readdirSync(packDir).filter((f) => f.endsWith('.md') && !/^README/i.test(f) && !f.startsWith('_'))
const packs = packFiles.map((f) => parsePackMd(read('public/prompts/packs/' + f), f)).filter((p) => p.body)
/* Every drop-in file in the templates folder counts, not just core.md — a new template file
   is a template. */
const tplDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public/prompts/templates')
/* Subfolders count as templates too — the scan is recursive, so a file dropped into
   templates/medical/ is audited exactly like a root file. */
const tplScan = scanTemplates(tplDir)
const allTpl = tplScan.flatMap((f) => parseTemplatesMd(read('public/prompts/templates/' + f.rel)))
const tplFiles = tplScan.length
const tplFolders = templateFolders(tplScan)

/* ---------- 1. sizes ---------- */
H('1 · Layer sizes (what the model actually receives)')
say('| file | chars | ≈tokens |')
say('|---|---|---|')
let baseTot = 0
for (const f of BASE) { const n = read('public/prompts/' + f).length; baseTot += n; say(`| ${f} | ${n} | ${Math.round(n / 4)} |`) }
say(`| **base total** | **${baseTot}** | **${Math.round(baseTot / 4)}** |`)
say('')
say('| pack | chars (perform) | chars (camplay) |')
say('|---|---|---|')
let packTot = 0
for (const p of packs) { const a = packText(p, 'perform').length, b = packText(p, 'camplay').length; packTot += a; say(`| ${p.icon} ${p.id} | ${a} | ${b || '—'} |`) }
say(`| **pack corpus** | **${packTot}** | |`)
const biggest = [...packs].sort((a, b) => packText(b, 'perform').length - packText(a, 'perform').length)[0]
const sizes = packs.map((p) => packText(p, 'perform').length).sort((x, y) => x - y)
const median = sizes[Math.floor(sizes.length / 2)]
say('')
{
  /* A big pack is only a problem when it serves few templates (pure bloat).
     A big pack that serves a big share of the library is just the popular vertical. */
  const share = allTpl.length ? allTpl.filter((t) => biggest.tags.includes((t.tag || '').toLowerCase()) || biggest.categories.includes((((t.settings || {}).category) || '').toLowerCase())).length / allTpl.length : 0
  const ratio = packText(biggest, 'perform').length / median
  const warn = ratio > 3 && share < 0.15
  say(`Pack size balance: median ${median} · biggest ${packText(biggest, 'perform').length} (${biggest.id}) — ratio ${ratio.toFixed(1)}× · serves ${Math.round(share * 100)}% of templates ${warn ? '⚠ lopsided (consider splitting)' : '✓'}`)
}
say('')
const bmax = Math.max(...BASE.map((f) => RESOLVED[f].text.length))
say(`Worst case single call: base ${bmax} (incl. ${[...new Set(BASE.flatMap((f) => RESOLVED[f].deps))].length} dependency file(s)) + 2 packs (${packText(biggest, 'perform').length} max) ≈ ${Math.round((bmax + packText(biggest, 'perform').length * 2) / 4)} tokens of system prompt.`)

/* ---------- 2. drift / duplication ---------- */
H('2 · Drift check — rules repeated across files (should be ~0)')
const norm = (s) => s.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const files = [
  ...BASE.map((f) => ({ name: 'base:' + f, text: read('public/prompts/' + f) })),
  ...packs.map((p) => ({ name: 'pack:' + p.id, text: packText(p, 'perform') })),
]
const owned = new Map()
for (const f of files) {
  const seen = new Set()
  for (const raw of f.text.split(/(?<=[.;!?])\s+|\n+/)) {
    const s = norm(raw)
    if (s.split(' ').length < 9) continue
    if (seen.has(s)) continue
    seen.add(s)
    if (!owned.has(s)) owned.set(s, [])
    owned.get(s).push(f.name)
  }
}
const fam = (name) => {
  if (!name.startsWith('base:')) return 'pack'
  const f = name.slice(5)
  if (f.startsWith('ltx-')) return f.includes('mature') ? 'ltx-mature' : 'ltx-sfw'
  return f.includes('mature') ? 'h3-mature' : 'h3-sfw'
}
/* intentional mirrors: an H3 doc and its mature twin, an LTX doc and its mature twin,
   and H3↔LTX restatements of the same universal rule. Real drift = anything a PACK
   shares with another pack or with a base file. */
/* a repetition is only drift if a PACK is involved: packs must not restate the
   base prompt's universal rules, and must not copy each other. */
const intentional = (groups) => groups.every((g) => g !== 'pack')
const allDups = [...owned.entries()].filter(([, where]) => new Set(where).size > 1)
const dups = []
let mirror = 0
for (const [s, where] of allDups) {
  const w = [...new Set(where)]
  if (intentional(w.map(fam))) { mirror++; continue }
  dups.push({ s, where: w })
}
say(`Cross-file repeated sentences: **${allDups.length}** — of which **${mirror}** are intentional twins (SFW↔mature, H3↔LTX restatements).`)
say(`**Real drift (a pack sharing text with another pack or a base file): ${dups.length}**`)
for (const d of dups.slice(0, 12)) say(`- "${d.s.slice(0, 96)}${d.s.length > 96 ? '…' : ''}" → ${d.where.join(', ')}`)
if (dups.length > 12) say(`- … and ${dups.length - 12} more`)

/* ---------- 3. pack hygiene ---------- */
H('3 · Pack hygiene')
say('| pack | keywords | tags | categories | sections | mode blocks | verdict |')
say('|---|---|---|---|---|---|---|')
for (const p of packs) {
  const body = p.body
  const secs = (body.match(/^## /gm) || []).length
  const modeBlocks = (body.match(/\[\[MODE /g) || []).length
  const openM = (body.match(/\[\[MODE /g) || []).length, closeM = (body.match(/\[\[\/MODE\]\]/g) || []).length
  const warns = []
  if (!p.keywords.length) warns.push('no keywords (idea router blind)')
  if (!p.tags.length) warns.push('no tags')
  if (!/SCOPE GUARD/.test(body)) warns.push('no scope guard')
  if (modeBlocks && modeBlocks !== closeM) warns.push('unbalanced MODE markers')
  if (/\[\[MODE/.test(packText(p, 'zzz'))) warns.push('mode markers leak')
  say(`| ${p.icon} ${p.id} | ${p.keywords.length} | ${p.tags.length} | ${p.categories.length} | ${secs} | ${modeBlocks} | ${warns.length ? '⚠ ' + warns.join('; ') : '✓'} |`)
}

/* ---------- 4. routing gaps ---------- */
H('4 · Routing dry-run — every shipped template through the pack router')
const rows = []
for (const t of allTpl) {
  const r = resolvePacks(packs, { tag: t.tag || '', category: (t.settings && t.settings.category) || '', idea: t.idea || '', mode: 'perform' })
  rows.push({ t, picked: r.chosen.map((p) => p.id), ctx: t.tag })
}
const gap = rows.filter((r) => !r.picked.length)
say(`Templates that resolve to **base prompt only**: ${gap.length} / ${rows.length}`)
for (const g of gap) say(`- ${g.t.fmt === 'ltx' ? '⚡' : '🎬'} ${g.t.t} (tag: ${g.t.tag}) → base only`)
const twoP = rows.filter((r) => r.picked.length > 1)
say('')
say(`Templates that stack two packs: ${twoP.length}`)
for (const r of twoP.slice(0, 10)) say(`- ${r.t.t} → ${r.picked.join(' + ')}`)

/* ---------- 5. coverage ---------- */
H('5 · Coverage — which craft domain has no template yet')
const tagCount = {}
for (const t of allTpl) tagCount[t.tag] = (tagCount[t.tag] || 0) + 1
const catCount = {}
for (const t of allTpl) { const c = (t.settings && t.settings.category) || ''; catCount[c] = (catCount[c] || 0) + 1 }
say('| pack | templates selecting it (tag/category) | idea-keyword fallback | verdict |')
say('|---|---|---|---|')
for (const p of packs) {
  const byTag = allTpl.filter((t) => p.tags.includes((t.tag || '').toLowerCase())).length
  const byCat = allTpl.filter((t) => p.categories.includes(((t.settings && t.settings.category) || '').toLowerCase())).length
  const direct = Math.max(byTag, byCat)
  say(`| ${p.icon} ${p.id} | ${direct} (tag ${byTag}/cat ${byCat}) | ${p.keywords.length} words | ${direct === 0 ? '⚠ no template routes here' : direct < 2 ? 'thin' : '✓'} |`)
}
say('')
say('Template tags present that no pack claims: ' + [...new Set(allTpl.map((t) => t.tag))].filter((tg) => !['person', 'preset', 'multi', 'vertical', 'longvideo', 'mature'].includes(tg) && !packs.some((p) => p.tags.includes(tg))).join(', '))

/* ---------- 6. template shape ---------- */
H('6 · Template shape')
const dyn = allTpl.filter((t) => t.flows && t.flows.length)
const vry = allTpl.filter((t) => t.vary && t.vary.length)
say(`Templates: **${allTpl.length}** across ${tplFiles} file(s) · dynamic (declare flows): **${dyn.length}** · skipped on parse: **${parseTemplatesMd.skipped || 0}**`)
if (tplFolders.filter(Boolean).length) say(`Subfolders scanned: **${tplFolders.filter(Boolean).length}** — ${tplFolders.filter(Boolean).map((f) => '📁 ' + f).join(' · ')} (every file inside a subfolder is the owner's, never replaced by an update)`)
say(`Templates where everything varies (declare \`vary:\`): **${vry.length}** — dimensions per template: **${vry.length ? [...new Set(vry.map((x) => x.vary.length))].join('/') : '0'}**`)
const chn = allTpl.filter((t) => t.chain)
say(`Chain recipes (\`chain: N\` — one template that runs as N linked scenes): **${chn.length}**` + (chn.length ? ' — ' + chn.map((t) => `${t.t} → ${t.chain} scenes`).join(' · ') : ''))
{
  const fam = (t) => /fashion|lifestyle|beaut|styling|lookbook|ootd|ethnic|bridal|jewel|garment|apparel|model|hair|makeup|swim|athleisure|streetwear/i.test(((t.settings && t.settings.category) || '') + ' ' + (t.tag || '') + ' ' + t.t)
  const masculine = /\b(man|men|male|males|boy|boys|guy|guys|groom|grooms|gentleman|husband|fianc[eé]|sherwani|dude)\b/i
  const fashion = allTpl.filter(fam)
  const bad = fashion.filter((t) => masculine.test(('' + (t.prompt || '')).replace(/boyfriend\s+(jeans|blazer|shirt|coat|cardigan|sweater)/gi, ' ')))
  say(`Cast lock (fashion / beauty / ethnic = women only): **${fashion.length}** blocks checked · masculine casting refs: **${bad.length}**` + (bad.length ? ' → ' + bad.map((t) => t.t).join(', ') : ''))
}
/* single source of token syntax + one field per token NAME — see src/lib/tokens.js */
const tok = (t) => uniqueTokens([t.b || '', t.idea || '']).length
const overSoft = allTpl.filter((t) => tok(t) > 8).sort((a, b) => tok(b) - tok(a))
say('')
say(`Templates above the soft target of 8 placeholders: ${overSoft.length} (advisory — 12+ is where merging pays off)`)
for (const t of overSoft.slice(0, 8)) say(`- ${t.t} → ${tok(t)} placeholders`)
const linted = allTpl.map((t) => ({ t, L: lintTemplate(t, []) }))
/* the layer stack — a garment never appears alone (v2.13) */
{
  const layered = linted.filter((x) => x.L.checks.some((c) => /Layering completeness/.test(c.label)))
  const gap = layered.filter((x) => x.L.checks.some((c) => /Layering completeness/.test(c.label) && c.level === 'warn'))
  say('')
  say(`Layer stack (fashion looks described as a complete outfit): **${layered.length - gap.length} / ${layered.length}** blocks carry the closed stack`)
  for (const x of gap.slice(0, 8)) {
    const w = x.L.checks.find((c) => /Layering completeness/.test(c.label))
    say(`- ${x.t.t} → ${(w.hint || '').split('.')[0]}`)
  }
  if (gap.length > 8) say(`- … and ${gap.length - 8} more`)
}
/* the wearer is in frame — jewellery beats open on her (v2.14) */
{
  const innerWorn = linted.filter((x) => x.L.checks.some((c) => /Innerwear named though nothing is exposed/.test(c.label)))
  say(`Innerwear with nothing exposed to cover: **${innerWorn.length}** block(s)`)
  for (const x of innerWorn.slice(0, 6)) say(`- ${x.t.t} → name no base layer, the look reads closed`)
  const wearer = linted.filter((x) => x.L.checks.some((c) => /Wearer in frame/.test(c.label)))
  const ringWarn = wearer.filter((x) => x.L.checks.some((c) => /Wearer in frame/.test(c.label) && c.level === 'warn'))
  say('')
  say(`Wearer in frame (jewellery / ornament blocks): **${wearer.length - ringWarn.length} / ${wearer.length}** open on her and keep every insert anchored on her body`)
  for (const x of wearer) say(`- ${x.t.t} → ${x.L.checks.find((c) => /Wearer in frame/.test(c.label)).level === 'ok' ? 'ok' : 'WARN: ' + x.L.checks.find((c) => /Wearer in frame/.test(c.label)).hint.split('.')[0]}`)
  if (ringWarn.length) say(`⚠️ ${ringWarn.length} jewellery block(s) frame the piece without the wearer`)
}
/* beat derivation — how many blocks would render the same clip forever (v2.16) */
{
  const judged = linted.filter((x) => x.L.checks.some((c) => /Beat derivation/.test(c.label)))
  const fixedList = judged.filter((x) => x.L.checks.some((c) => /Beat derivation/.test(c.label) && c.level === 'warn'))
  say('')
  say(`Beat derivation (blocks judged): **${judged.length}** · fixed shot lists: **${fixedList.length}** · flow libraries: **${allTpl.filter((t) => t.flows && t.flows.length).length}**`)
  /* the shot count belongs to the runtime: a 12s look film must not be told it is three shots */
  const autoCuts = allTpl.filter((t) => t.settings && t.settings.structure === 'auto').length
  const pinnedThree = allTpl.filter((t) => t.settings && t.settings.structure === 'multi3' && (t.settings.duration || 0) >= 10).length
  say(`Shot counts: **${autoCuts}** block(s) let the runtime decide the cuts (auto) · **${pinnedThree}** fixed three-shot block(s) of 10s or longer`)
  for (const x of fixedList.slice(0, 8)) say(`- ${x.t.t} → ${(x.L.checks.find((c) => /Beat derivation/.test(c.label)).hint || '').split('.')[0]}`)
}
const noTiming = linted.filter((x) => x.L.checks.some((c) => c.level === 'warn' && /Pacing contract/.test(c.label)))
say('')
say(`Templates missing a pacing contract (TIMING / duration budget): ${noTiming.length}`)
for (const x of noTiming.slice(0, 12)) say(`- ${x.t.t}`)
const warnCounts = {}
for (const x of linted) for (const c of x.L.checks) if (c.level === 'warn') warnCounts[c.label] = (warnCounts[c.label] || 0) + 1
say('')
say('Linter warnings across the library: ' + (Object.entries(warnCounts).map(([k, v]) => `${k} ×${v}`).join(' · ') || 'none'))
const heavy = linted.filter((x) => x.L.tokens.length > 12)
say('')
say(`Templates above the soft placeholder target (12+ tokens): ${heavy.length} — advisory only, no template is ever blocked`)
for (const x of heavy.sort((p, q) => q.L.tokens.length - p.L.tokens.length).slice(0, 10)) say(`- ${x.t.t} → ${x.L.tokens.length} tokens, ${x.L.guided.length} guided (${Math.round((x.L.guided.length / x.L.tokens.length) * 100)}%)`)
const unguided = linted.filter((x) => x.L.tokens.length >= 4 && x.L.guided.length / x.L.tokens.length < 0.5)
say('')
say(`Templates where under half the tokens carry guidance: ${unguided.length} (the builder shows guidance as the field hint)`)

/* ---------- write ---------- */
fs.writeFileSync(P('docs/prompt-audit.md'), `# Prompt corpus audit\n\nGenerated by \`npm run audit\` — ${new Date().toISOString().slice(0, 10)}\n` + lines.join('\n') + '\n')
console.log('\n→ wrote docs/prompt-audit.md')
