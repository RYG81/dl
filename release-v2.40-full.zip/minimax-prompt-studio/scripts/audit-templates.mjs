#!/usr/bin/env node
/* 🔎 Template library audit — the layered truth about every template.
 *
 * A template is not the only thing that reaches the model. Three layers do:
 *   1 · the ENGINE (src/lib/prompts.js) injects READING BEAT, SHOT DESIGN, DETAIL DENSITY,
 *       TOKEN DISCIPLINE, the CAST LOCK, the motion plan and the variation contract;
 *   2 · the PACKS (public/prompts/packs/*.md) carry the domain craft — the closed-stack law,
 *       innerwear-where-seen, the colour bank and the register rules;
 *   3 · the TEMPLATE carries its own beats, camera grammar and timing.
 *
 * So "this template never mentions the closed stack" is NOT a defect — the layer above it
 * does, on every generation. This tool only reports what is actually wrong, and separates:
 *
 *   ERROR  something that misleads the UI or the model (misfiled tag, stamped cut times,
 *          a token over budget) — these get fixed.
 *   WARN   the template's own text contradicts a law the engine also carries.
 *   INFO   advisory only: a fixed shot count where Auto exists, no flows, a long stretch
 *          with no beat language — fine for a 6s preset, worth a look for a 20s film.
 *
 *   node scripts/audit-templates.mjs            → report
 *   node scripts/audit-templates.mjs --json     → machine-readable
 *   node scripts/audit-templates.mjs --strict   → exit 1 if any ERROR
 */
import fs from 'node:fs'
import path from 'node:path'
import { parseTemplatesMd } from '../src/lib/templates.js'
import { TAG_LABELS, groupOf } from '../src/lib/tags.js'

const ROOT = path.join(path.dirname(new URL(import.meta.url).pathname), '..')
const TPL = path.join(ROOT, 'public/prompts/templates')
const json = process.argv.includes('--json')
const strict = process.argv.includes('--strict')

const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)])
const FASHION_CAT = /fashion|lifestyle|beauty|ethnic|bridal|styling/i
/* camera language the engine's own contract forbids — only a contradiction if the template
   does not explicitly ask for a fast/style register of its own */
/* a ban is not a request: match the move only when it is NOT introduced by never/no/avoid/without */
const BANNED_MOVE = /(?<!never a )(?<!no )(?<!avoid )(?<!without )(?<!never )\b(whip pan|speed ramp|snap zoom|handheld jitter)\b/i
const SELF_AWARE = /\b(whip-follow|whip pan|speed ramp|handheld)\b[^.\n]{0,60}\b(is the point|deliberate|by design|style)\b/i

const rows = []
for (const f of walk(TPL).filter((x) => x.endsWith('.md') && !/README|user-templates/.test(x))) {
  const src = fs.readFileSync(f, 'utf8')
  for (const b of parseTemplatesMd(src)) {
    const s = b.settings || {}
    /* both the skeleton and the idea line reach the model — check the template as a whole */
    const body = (b.b || '') + '\n' + (b.idea || '')
    const err = [], warn = [], info = []

    /* ---- ERROR: metadata the UI cannot use ---- */
    if (b.tag && !TAG_LABELS[b.tag]) err.push('tag "' + b.tag + '" has no label in the picker')
    if (FASHION_CAT.test(s.category || '') && b.tag === 'person') err.push('category says Fashion/Lifestyle but the tag says person (shows under Person)')
    if (groupOf(b) === 'other') err.push('no usable tag or category — it lands in an unlabelled group')

    /* ---- ERROR: a skeleton that states when its own cuts happen ---- */
    const stamped = body.match(/\b\d{1,2}:\d{2}\.\d{3}\b/g)
    if (stamped) err.push('stamped cut time ' + stamped[0] + ' — the clock is derived per runtime')

    /* ---- ERROR: token budget ---- */
    const over = [...body.matchAll(/\{([^{}\n]{121,500})\}/g)]
    if (over.length) err.push(over.length + ' placeholder token(s) over the 120-char budget')

    /* ---- ERROR: no timing contract on a template whose cuts are derived ---- */
    const multi = String(s.structure) === 'auto' || /^multi/.test(String(s.structure) || '')
    if (multi && !/TIMING|clock/i.test(body)) err.push('cuts are derived but the template states no timing contract')

    /* ---- WARN: the template contradicts a law the engine already carries ---- */
    const banMatch = body.match(/(?:never|no|avoid|without)\s+(?:a\s+)?(whip pan|speed ramp|snap zoom|handheld jitter)/i)
    const useMatch = body.match(/(?:^|[.\n]\s*)(?:the camera |a )?(whip pan|speed ramp|snap zoom|handheld jitter)/i)
    if (useMatch && !SELF_AWARE.test(body) && !/\bnever\b[^.]{0,40}\b(whip pan|speed ramp|snap zoom|handheld jitter)/i.test(body)) warn.push('camera language the contract bans (' + useMatch[1] + ') without saying it is the point')
    if (!/colour|color/i.test(body) && FASHION_CAT.test(s.category || '') && b.vary && b.vary.length && b.vary.some((d) => /colour|palette/i.test(d)) === false && /\bwearing\b|\boutfit\b|\bgarment\b/i.test(body)) warn.push('describes a look and never mentions colour, and no colour dimension is varied')
    if (/\bis wearing\b[^.]{0,200}\b(and nothing else|only)\b/i.test(body)) warn.push('reads as an open stack (a look with one piece and no lower half)')

    /* ---- INFO: advisory ---- */
    if (/^multi/.test(String(s.structure) || '') && Number(s.duration) >= 10) info.push('fixed ' + s.structure + ' at ' + s.duration + 's — Auto derives the count from the runtime')
    if (!b.flows || !b.flows.length) info.push('no beat-flow library')
    if (b.fmt !== 'ltx' && Number(s.duration) >= 12 && !/beat/i.test(body)) info.push('a ' + s.duration + 's H3 film with no beat language')
    const tok = [...body.matchAll(/\{([^{}\n]{2,140})\}/g)].length
    if (tok > 20) info.push(tok + ' tokens (soft target is 12)')

    /* ---- the TOUR GRAMMAR checks — why the Room outfit tour beats the ref-derived films ----
       A film reads as a film when the SUBJECT travels through the framings; it reads as a
       slideshow when the camera travels across a still subject. Bans are not requests, so
       every pattern here ignores a move introduced by never/no/does not. */
    const NEG = '(?<!never a )(?<!no )(?<!does not )(?<!do not )(?<!never )'
    const acts = (body.match(/\b(walks?|steps?|enters|lifts?|lowers?|rests?|settles?|shifts?|meets?|drifts?|sweeps?|crosses|leans?|rises?|reaches?|adjusts?|draws?|glances?|blinks?|breathes?|smiles?|stands?|stops?|arrives?|swings?|touches?|pulls?|turns?)\b/gi) || []).length
    const camTasks = (body.match(/\b(the camera (reads|finds|lands|holds|settles|drifts|slides|arcs|pushes|tracks)|macro (on|beat|insert)|at its own scale|fills frame|extreme close|the frame (holds|rests) on)\b/gi) || []).length
    const sheMoves = (body.match(/\b(approaches|steps? (in|back|toward|closer|carry|carries)|two (grounded )?steps|walks? (in|toward|at)|turns? (away|through|back|three-quarters)|comes? closer|moves? toward)\b/gi) || []).length
    const camMoves = (body.match(new RegExp(NEG + '\\b(camera (drifts|pushes|arcs|slides|orbits|cranes|zooms|moves)|dolly|crane|orbit|zoom|pan|tilt)\\b', 'gi')) || []).length
    const locks = /LOCKED|watchtower|locked off|does not travel|never moves/i.test(body)

    /* ---- the MOTION faults a locked-camera film cannot survive (field report 2026-09-28):
       "walking is like jumping" came from asking her to cross a distance inside one beat, and
       "mostly showing back view" came from open-ended turns and back-first flows. */
    const hasWearer = /\b(she|her|model|wearer|bride|woman|creator|presenter)\b/i.test(body)
    const walkMove = /\b(walks? (in|across|straight|toward|at)\b[^.]{0,45}\b(depth|room|ground|floor|set|space|zone|wall)|crosses? (the|a|into)\b[^.]{0,45}\b(room|floor|depth|space|threshold|ground|set)\b)/i
    const cameraWalks = /camera (crosses|walks)/i.test(body)
    const distanceWalk = hasWearer && !cameraWalks && walkMove.test(body) &&
      !/two (grounded )?steps|two to four|steps? in from/i.test(body)
    if (distanceWalk) warn.push('WALK RISK — the entrance asks her to cross a distance; the model cannot animate that inside a beat, so the walk renders as a hop. Write it as two to four grounded steps onto a mark')
    const backBeats = (body.match(/full back view|turns? away through|enters already turned away/gi) || []).length
    if (backBeats > 0) info.push(backBeats + ' back-view beat(s) — the film is face-forward when there is at most one, it returns inside its own beat, and the first and last shots are toward the lens')
    if (!/two (grounded )?steps|two to four|she stands full length|locked inside every shot/i.test(body) && /\bwalks?\b/i.test(body)) info.push('a walk is described without telling the model how many steps, on what floor, or that her feet stay in frame')
    if (camTasks > acts) warn.push('SLIDESHOW RISK — ' + camTasks + ' beat(s) where the camera looks for a detail against ' + acts + ' where her body acts; let her present the detail instead')
    /* A product turntable, a 3D explainer and a material study travel by design — the check
       only judges films with a person in them. */
    /* A template that names its own rebuild in the description is a deliberate kept-favourite,
       not an unaddressed defect — its camera-travel note drops from WARN to INFO so the WARN
       list keeps meaning "nobody has looked at this yet". */
    const superseded = /rebuilt on the tour grammar|on the tour grammar|ships as|Cut as a jeweller's campaign|The macro ladder done|The held-frame register/i.test((b.d || '') + ' ' + (b.tip || ''))
    if (hasWearer && camMoves > sheMoves && camMoves > 2 && !locks) {
      const note = 'the camera does the travelling (' + camMoves + ' camera moves vs ' + sheMoves + ' by the subject) — scale changes are stronger when she moves'
      if (superseded) {
        info.push('superseded by a rebuild that is already in the library — ' + note)
      } else {
        warn.push(note)
      }
    }
    /* ---- the model band: 20 to 32 unless the request names an age (young, beautiful,
       fashion-model quality). Anything else in the corpus is a defect, not a preference. */
    const ageText = (s.idea || '') + ' ' + body
    const bandHit = /20\s*(?:-|\u2013|to)\s*32/.test(ageText)
    const badAge = []
    for (const m of ageText.matchAll(/\b(1[0-9]|[2-9][0-9])\s*(?:-|\u2013|to)\s*(1[0-9]|[2-9][0-9])\s*(?:years? old|yo\b|y\/o)/gi)) {
      const lo = +m[1], hi = +m[2]
      if (lo < 20 || hi > 32) badAge.push(m[0].trim())
    }
    for (const m of ageText.matchAll(/\b(1[0-9]|[2-9][0-9])\s*(?:years? old|yo\b|y\/o)/gi)) {
      const a = +m[1]
      if (a < 20 || a > 32) badAge.push(m[0].trim())
    }
    for (const m of ageText.matchAll(/\b(in her |aged )?(teens|teenager|early twenties|mid-?twenties|late twenties|early thirties|mid-?thirties|late thirties|forties|middle-?aged|elderly)\b/gi)) {
      const w = m[0].toLowerCase()
      if (/teen/.test(w) || /forties|middle-?aged|elderly/.test(w) || /late thirties/.test(w)) badAge.push(m[0].trim())
    }
    if (badAge.length) {
      warn.push('names an age outside the 20-32 model band (' + badAge.slice(0, 3).join(', ') + ') — the band is the default for every fashion cast; an age only leaves it when the request itself asks')
    }
    const hasPerson = /\{(MODEL|WEARER|CREATOR|BRIDE)\b|\{SUBJECT(?! MODEL|\/PRODUCT)/.test(body)
    const isStarter = /(^|\/)starter\//.test(String(f || ''))
    if (hasPerson && !isStarter && !bandHit && !/20 TO 32|20-32/.test(body)) {
      info.push('names a person but never states the 20-32 model band — the cast should carry it so the age is a lock, not a guess')
    }
    /* ---- clones: a run that only varies content produces one film with a different woman in it */
    const FORM_RE = /RHYTHM ENVELOPE|SCALE LADDER|CUT MOTIVATION|FRAMING DEVICE|OPEN DEVICE|CLOSE DEVICE|TRANSITION|SOUND FORMAT/
    const formAxes = (b.vary || []).filter((d) => FORM_RE.test(d))
    if ((b.vary || []).length && !formAxes.length) {
      info.push('varies ' + b.vary.length + ' content dimensions and no FORM axis — a batch swaps what is in the frame without changing the edit, which is how outputs end up looking like one film with a different model')
    } else if ((b.vary || []).length >= 8 && formAxes.length < 4) {
      info.push('only ' + formAxes.length + ' form axis(es) — the never-share set is RHYTHM ENVELOPE · SCALE LADDER · FRAMING DEVICE · CUT MOTIVATION')
    }
    /* the other half of the clone: a run that never varies what she DOES. New model, new clothes,
       identical actions — the film the user asked us to stop making. */
    const ACT_RE = /^(ACTION|MOVEMENT|PRESENTATION)$/
    if ((b.vary || []).length && hasWearer && !(b.vary || []).some((d) => ACT_RE.test(d))) {
      info.push('varies nothing about what she does — no ACTION, MOVEMENT or PRESENTATION dim, so every variant of a run performs the same acts')
    }
    if (Number(s.duration) >= 14 && tok > 12) info.push('a ' + s.duration + 's film with ' + tok + ' tokens — long runtimes reward fewer beats, not more')
    if (/[A-Z]{5,} [A-Z]{3,}[A-Z ]{4,}/.test(body) && (body.match(/\b[A-Z][A-Z][A-Z][A-Z][A-Z]+ [A-Z][A-Z]/g) || []).length > 18) info.push('heavy all-caps law density — the engine already carries several of those laws')

    rows.push({ file: path.basename(f), rel: path.relative(TPL, f), title: b.t, tag: b.tag, cat: s.category, dur: s.duration, st: s.structure, err, warn, info, acts, camTasks, sheMoves, camMoves })
  }
}

const nE = rows.filter((r) => r.err.length).length
const nW = rows.filter((r) => r.warn.length).length
const nI = rows.filter((r) => r.info.length).length

if (json) {
  console.log(JSON.stringify({ templates: rows.length, errors: nE, warns: nW, infos: nI, rows }, null, 1))
} else {
  console.log('templates audited: ' + rows.length)
  console.log('  ❌ ' + nE + ' with an ERROR (the UI or the model is being misled)')
  console.log('  ⚠️  ' + nW + ' with a WARN (the template contradicts a law the engine also carries)')
  console.log('  ℹ️  ' + nI + ' with an INFO (advisory only)')
  if (nE) {
    console.log('\nERRORS')
    for (const r of rows.filter((x) => x.err.length)) console.log('  ' + r.file.padEnd(20) + r.title.slice(0, 46).padEnd(48) + r.err.join('; '))
  }
  if (nW) {
    console.log('\nWARNINGS')
    for (const r of rows.filter((x) => x.warn.length)) console.log('  ' + r.file.padEnd(20) + r.title.slice(0, 46).padEnd(48) + r.warn.join('; '))
  }
  if (process.argv.includes('--info') && nI) {
    console.log('\nINFO')
    for (const r of rows.filter((x) => x.info.length)) console.log('  ' + r.file.padEnd(20) + r.title.slice(0, 46).padEnd(48) + r.info.join('; '))
  }
  console.log('\nThe engine already injects: READING BEAT · SHOT DESIGN · DETAIL DENSITY · TOKEN DISCIPLINE ·')
  console.log('CAST LOCK · the motion plan · the variation contract. The packs carry: the closed-stack law ·')
  console.log('innerwear-where-seen · the colour bank · the register rules. Only the gaps above are real.')
}
process.exit(strict && nE ? 1 : 0)
