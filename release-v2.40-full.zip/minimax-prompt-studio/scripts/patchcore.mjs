/* Patch core — the whole "an update can never eat your work" engine.
 *
 * The rule is one line: **your file is only replaced when it is byte-identical to the
 * version we shipped.** If you edited it, or it is a protected path, or we have never
 * seen it before, your copy stays exactly as it is and the incoming version is written
 * beside it as `<file>.new` with a line in PATCH-REPORT.md.
 *
 * Nothing in here imports anything from the app and nothing touches the network, so the
 * exact same code can be inlined into the standalone `apply.mjs` that ships inside every
 * patch archive (see scripts/apply-standalone.mjs + `npm run standalone`). The CLI lives
 * in scripts/patch.mjs; this file is engine only, so both users of it can never drift.
 */
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { readZip, writeZip } from './ziplib.mjs'

export const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex')

/* Paths the updater must never touch, even when they are unmodified. */
export const DEFAULT_PROTECTED = [
  'public/prompts/banks/**',
  'public/prompts/user/**',
  'public/prompts/mature-addendum.md',
  'public/prompts/*mature*.md',
  'public/prompts/templates/user-*.md',
  /* 📁 Subfolders of the template library are the owner's territory: updates ship files in
     the ROOT of that folder only, so a folder tree you build is never replaced or flattened.
     One star per folder level covers that — one level deep, and anything deeper — while a
     root file matches neither pattern, so the built-ins stay shippable. */
  'public/prompts/templates/*/*',
  'public/prompts/templates/*/*/**',
  'public/prompts/templates/**/user-*.md',
  'public/prompts/system-prompt-sample.md',
  '.env',
  '.env.*',
  'patch.config.json',
  'patches/**',
  '.patch-backup/**',
  'PATCH-REPORT.md',
  'PATCH-INBOX.md',
]

/* Paths that are excluded from every patch unless a release explicitly asks for them.
 * The mature prompts are the user's own work: a patch only carries them when there is new
 * MiniMax H3 prompting knowledge to fold in (`make --include-mature`). */
export const MATURE_EXCLUDES = [
  'public/prompts/*mature*.md',
  'public/prompts/mature-*.md',
]

/* glob → regex: ** crosses directories, * stays inside one */
export function globToRe(glob) {
  const esc = glob.replace(/[.+^${}()|[\]\\]/g, '\\$&')
  const rx = esc
    .replace(/\*\*\//g, '\u0000')      // double-star followed by a slash
    .replace(/\*\*/g, '\u0001')        // bare double-star
    .replace(/\*/g, '[^/]*')
    .replace(/\u0000/g, '(?:.*/)?')
    .replace(/\u0001/g, '.*')
  return new RegExp('^' + rx + '$')
}
export const isProtected = (p, list) => (list || DEFAULT_PROTECTED).some((g) => globToRe(g).test(p))

/** Decide what to do with every file in the patch. Pure — no disk access. */
export function planPatch({ incoming = [], base = {}, local = {}, protectedList = DEFAULT_PROTECTED } = {}) {
  const actions = []
  for (const f of incoming) {
    const p = f.path
    const incomingHash = f.hash
    const localHash = local[p] || null
    const baseHash = base[p] || null
    const prot = isProtected(p, protectedList)

    if (!localHash) {
      actions.push({ path: p, action: 'add', why: 'not present locally' })
      continue
    }
    if (localHash === incomingHash) {
      actions.push({ path: p, action: 'same', why: 'already this version' })
      continue
    }
    if (prot) {
      actions.push({ path: p, action: 'keep', why: 'protected path — yours is never replaced', sidecar: true })
      continue
    }
    if (baseHash && localHash === baseHash) {
      actions.push({ path: p, action: 'update', why: 'unmodified since we shipped it' })
      continue
    }
    actions.push({
      path: p,
      action: 'conflict',
      why: baseHash ? 'this copy is not the one we shipped from' : 'older or edited copy — we cannot prove it is unmodified',
      sidecar: true,
    })
  }
  return actions
}

/* A conflicted file is not an island: the rest of the patch was written around it. When another
   file in the patch imports it by name, a stale local copy can stop the app loading entirely
   ("does not provide an export named …") — the v2.15 report bug. Name those files and the fix. */
export function importersOf(paths, target, root) {
  if (!root) return []
  const strip = (s) => String(s).replace(/\.[a-z0-9]+$/i, '')
  const want = strip(target)
  const out = []
  for (const p of paths) {
    if (p === target || !/\.(js|jsx|mjs)$/i.test(p)) continue
    let src = ''
    try { src = fs.readFileSync(path.join(root, p), 'utf8') } catch (e) { continue }
    const dir = path.posix.dirname(p)
    for (const m of src.matchAll(/from\s+['"]([^'"]+)['"]/g)) {
      const spec = m[1]
      if (!spec.startsWith('.')) continue
      const resolved = path.posix.normalize(path.posix.join(dir, spec))
      if (strip(resolved) === want) { out.push(p); break }
    }
  }
  return out
}

export function patchReport({ version, actions = [], notes = [], standalone = null, root = null, cmd = null }) {
  const g = (a) => actions.filter((x) => x.action === a)
  const lines = []
  lines.push('# PATCH REPORT — ' + (version || 'unknown version'))
  lines.push('')
  lines.push('Applied ' + new Date().toISOString().replace('T', ' ').slice(0, 19) + ' · nothing was deleted')
  if (notes.length) {
    lines.push('')
    lines.push('**What this patch brings:**')
    for (const n of notes) lines.push('- ' + n)
  }
  lines.push('')
  lines.push('| action | files |')
  lines.push('|---|---|')
  for (const a of ['add', 'update', 'accepted', 'same', 'keep', 'conflict']) {
    const n = g(a).length
    if (n) lines.push('| ' + a + ' | ' + n + ' |')
  }
  if (g('accepted').length) {
    lines.push('')
    lines.push('## Replaced, after saving your old copy')
    for (const x of g('accepted')) lines.push('- `' + x.path + '` → your previous copy is in `.patch-backup/' + (version || 'previous') + '/' + x.path + '`')
  }
  if (g('conflict').length) {
    lines.push('')
    lines.push('## Needs your eye — your version is untouched, the new one is beside it')
    for (const x of g('conflict')) {
      lines.push('- `' + x.path + '` → new version at `' + x.path + '.new`  (' + x.why + ')')
      const deps = importersOf(actions.map((a) => a.path), x.path, root)
      if (deps.length) {
        lines.push('  - ⚠ ' + deps.length + ' other file' + (deps.length > 1 ? 's' : '') + ' in this patch import' +
          (deps.length > 1 ? '' : 's') + ' it: ' + deps.map((d) => '`' + d + '`').join(', ') +
          ' — a copy that is out of step with them can stop the app loading ("does not provide an export named …").' +
          ' Take the new version with the command below; your copy is saved to `.patch-backup/` first.')
      }
    }
  }
  if (g('keep').length) {
    lines.push('')
    lines.push('## Protected — never replaced')
    for (const x of g('keep')) lines.push('- `' + x.path + '`  (' + x.why + ')')
  }
  if (g('update').length) {
    lines.push('')
    lines.push('## Updated')
    for (const x of g('update')) lines.push('- `' + x.path + '`')
  }
  if (g('add').length) {
    lines.push('')
    lines.push('## Added')
    for (const x of g('add')) lines.push('- `' + x.path + '`')
  }
  lines.push('')
  if (g('conflict').length) {
    lines.push('Those `conflict` files are copies we could not prove are unmodified — most often they are simply an')
    lines.push('older version of the file. Yours were left alone. Two ways to finish:')
    lines.push('')
    lines.push('1. Open a `.new` file next to yours, copy over what you want, delete the `.new`.')
    lines.push('2. Take them all at once (your current copies are saved first, nothing is lost):')
    lines.push('')
    lines.push('   ```')
    lines.push('   ' + (cmd || ('node ' + (standalone || 'scripts/patch.mjs') + ' --accept-new' + (root ? ' --into ' + root : ''))))
    lines.push('   ```')
  } else {
    lines.push('Nothing needs your attention: every file of yours was either already current or untouched.')
  }
  lines.push('')
  return lines.join('\n') + '\n'
}

/* ---------------- disk ---------------- */

export function protectListFor(root) {
  const extra = (() => {
    try { return JSON.parse(fs.readFileSync(path.join(root, 'patch.config.json'), 'utf8')).protected || [] } catch (e) { return [] }
  })()
  return [...DEFAULT_PROTECTED, ...extra]
}

export function loadPatch(input) {
  const p = path.resolve(input)
  if (!fs.existsSync(p)) throw new Error('patch not found: ' + input)
  const stat = fs.statSync(p)
  if (stat.isDirectory()) {
    const man = JSON.parse(fs.readFileSync(path.join(p, 'manifest.json'), 'utf8'))
    const files = {}
    for (const rel of Object.keys(man.files || {})) {
      const abs = path.join(p, 'files', rel)
      if (fs.existsSync(abs)) files[rel] = fs.readFileSync(abs)
    }
    return { manifest: man, files }
  }
  const entries = readZip(fs.readFileSync(p))
  const manEntry = entries.find((e) => e.name === 'manifest.json')
  if (!manEntry) throw new Error('not a patch archive (no manifest.json)')
  const man = JSON.parse(manEntry.data.toString('utf8'))
  const files = {}
  for (const e of entries) {
    const m = /^files\/(.+)$/.exec(e.name)
    if (m) files[m[1]] = e.data
  }
  return { manifest: man, files }
}

export function hashTree(root, list) {
  const out = {}
  for (const rel of list) {
    const abs = path.join(root, rel)
    if (fs.existsSync(abs) && fs.statSync(abs).isFile()) out[rel] = sha(fs.readFileSync(abs))
  }
  return out
}

/** Apply a patch. Returns { actions, wrote, sidecars, accepted, backedUp, report }.
 *  acceptNew: take the incoming version of CONFLICT files too — your current copy is
 *  moved to .patch-backup/<version>/<path> first, so an overwrite is always reversible,
 *  and protected paths are still never touched. */
export async function applyPatch(input, { root, quiet = false, acceptNew = false, dryRun = false, cmd = null, onNote = null } = {}) {
  if (!root) throw new Error('applyPatch needs a root')
  const { manifest, files } = await loadPatch(input)
  const local = hashTree(root, Object.keys(files))
  const actions = planPatch({
    incoming: Object.entries(files).map(([p, buf]) => ({ path: p, hash: sha(buf) })),
    base: manifest.files || {},
    local,
    protectedList: protectListFor(root),
  })

  let wrote = 0, sidecars = 0, accepted = 0, backedUp = 0
  const version = manifest.version || 'patch'
  for (const a of actions) {
    const buf = files[a.path]
    const abs = path.join(root, a.path)
    if (a.action === 'add' || a.action === 'update') {
      if (!dryRun) {
        fs.mkdirSync(path.dirname(abs), { recursive: true })
        fs.writeFileSync(abs, buf)
      }
      wrote++
    } else if (a.sidecar && a.action === 'conflict' && acceptNew) {
      if (!dryRun) {
        const bak = path.join(root, '.patch-backup', version, a.path)
        if (fs.existsSync(abs)) {
          fs.mkdirSync(path.dirname(bak), { recursive: true })
          fs.copyFileSync(abs, bak)
          backedUp++
        }
        fs.mkdirSync(path.dirname(abs), { recursive: true })
        fs.writeFileSync(abs, buf)
        if (fs.existsSync(abs + '.new')) fs.rmSync(abs + '.new')
      }
      a.action = 'accepted'
      a.backup = '.patch-backup/' + version + '/' + a.path
      accepted++
    } else if (a.sidecar) {
      if (!dryRun) {
        fs.mkdirSync(path.dirname(abs), { recursive: true })
        fs.writeFileSync(abs + '.new', buf)
      }
      sidecars++
    }
  }

  const report = patchReport({
    version, actions, notes: manifest.notes || [], root, cmd,
    standalone: manifest.standalone || null,
  })
  if (!dryRun) {
    fs.writeFileSync(path.join(root, 'PATCH-REPORT.md'), report)
    fs.mkdirSync(path.join(root, 'patches'), { recursive: true })
    fs.writeFileSync(path.join(root, 'patches', 'applied.json'), JSON.stringify({
      version, at: new Date().toISOString(), wrote, sidecars, accepted, backedUp,
      conflicts: actions.filter((a) => a.action === 'conflict').map((a) => a.path),
      files: actions.map((a) => ({ path: a.path, action: a.action })),
    }, null, 2))
  }

  if (!quiet) {
    console.log(report)
    console.log('→ ' + wrote + ' file(s) written · ' + accepted + ' accepted from .new · ' + sidecars +
      ' new version(s) left as .new · ' + backedUp + ' copy/copies backed up · 0 deleted')
    if (sidecars) console.log('→ nothing of yours was replaced. See PATCH-REPORT.md')
  }
  if (onNote) onNote(report, actions)
  return { actions, wrote, sidecars, accepted, backedUp, report, manifest }
}
