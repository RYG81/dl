/* Minimal ZIP reader/writer — no dependencies.
   Supports the two methods every archiver emits for this use: stored (0) and deflate (8).
   Only used by the patch tooling (scripts/patch.mjs, scripts/make-patch.mjs). */
import zlib from 'node:zlib'

const CRC_TABLE = (() => {
  const t = new Int32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    t[n] = c
  }
  return t
})()

export function crc32(buf) {
  let c = -1
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8)
  return (c ^ -1) >>> 0
}

/** entries: [{ name, data: Buffer }] → Buffer (deflate, no zip64) */
export function writeZip(entries) {
  const chunks = []
  const central = []
  let offset = 0
  const now = new Date()
  const dosTime = ((now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() / 2)) & 0xffff
  const dosDate = (((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate()) & 0xffff

  for (const e of entries) {
    const name = Buffer.from(e.name, 'utf8')
    const raw = Buffer.isBuffer(e.data) ? e.data : Buffer.from(String(e.data), 'utf8')
    const deflated = zlib.deflateRawSync(raw, { level: 9 })
    const useStore = deflated.length >= raw.length
    const body = useStore ? raw : deflated
    const crc = crc32(raw)
    const local = Buffer.alloc(30)
    local.writeUInt32LE(0x04034b50, 0)
    local.writeUInt16LE(20, 4)          /* version needed */
    local.writeUInt16LE(0, 6)           /* flags */
    local.writeUInt16LE(useStore ? 0 : 8, 8)
    local.writeUInt16LE(dosTime, 10)
    local.writeUInt16LE(dosDate, 12)
    local.writeUInt32LE(crc, 14)
    local.writeUInt32LE(body.length, 18)
    local.writeUInt32LE(raw.length, 22)
    local.writeUInt16LE(name.length, 26)
    local.writeUInt16LE(0, 28)
    chunks.push(local, name, body)

    const cd = Buffer.alloc(46)
    cd.writeUInt32LE(0x02014b50, 0)
    cd.writeUInt16LE(20, 4)
    cd.writeUInt16LE(20, 6)
    cd.writeUInt16LE(0, 8)
    cd.writeUInt16LE(useStore ? 0 : 8, 10)
    cd.writeUInt16LE(dosTime, 12)
    cd.writeUInt16LE(dosDate, 14)
    cd.writeUInt32LE(crc, 16)
    cd.writeUInt32LE(body.length, 20)
    cd.writeUInt32LE(raw.length, 24)
    cd.writeUInt16LE(name.length, 28)
    cd.writeUInt16LE(0, 30)
    cd.writeUInt16LE(0, 32)
    cd.writeUInt16LE(0, 34)
    cd.writeUInt16LE(0, 36)
    cd.writeUInt32LE(0, 38)
    cd.writeUInt32LE(offset, 42)
    central.push(cd, name)
    offset += local.length + name.length + body.length
  }

  const cdBuf = Buffer.concat(central)
  const end = Buffer.alloc(22)
  end.writeUInt32LE(0x06054b50, 0)
  end.writeUInt16LE(0, 4)
  end.writeUInt16LE(0, 6)
  end.writeUInt16LE(entries.length, 8)
  end.writeUInt16LE(entries.length, 10)
  end.writeUInt32LE(cdBuf.length, 12)
  end.writeUInt32LE(offset, 16)
  end.writeUInt16LE(0, 20)
  return Buffer.concat([...chunks, cdBuf, end])
}

/** Buffer → [{ name, data: Buffer }] (stored + deflate) */
export function readZip(buf) {
  const buf2 = Buffer.isBuffer(buf) ? buf : Buffer.from(buf)
  /* find End Of Central Directory (scan back over an optional comment) */
  let eocd = -1
  for (let i = buf2.length - 22; i >= 0 && i >= buf2.length - 22 - 65535; i--) {
    if (buf2.readUInt32LE(i) === 0x06054b50) { eocd = i; break }
  }
  if (eocd < 0) throw new Error('not a zip file (no end-of-central-directory)')
  const count = buf2.readUInt16LE(eocd + 10)
  let ptr = buf2.readUInt32LE(eocd + 16)
  const out = []
  for (let i = 0; i < count; i++) {
    if (buf2.readUInt32LE(ptr) !== 0x02014b50) throw new Error('bad central directory at entry ' + i)
    const method = buf2.readUInt16LE(ptr + 10)
    const compSize = buf2.readUInt32LE(ptr + 20)
    const rawSize = buf2.readUInt32LE(ptr + 24)
    const nameLen = buf2.readUInt16LE(ptr + 28)
    const extraLen = buf2.readUInt16LE(ptr + 30)
    const commentLen = buf2.readUInt16LE(ptr + 32)
    const localOff = buf2.readUInt32LE(ptr + 42)
    const name = buf2.slice(ptr + 46, ptr + 46 + nameLen).toString('utf8')
    ptr += 46 + nameLen + extraLen + commentLen
    if (name.endsWith('/')) continue
    /* local header → data offset */
    if (buf2.readUInt32LE(localOff) !== 0x04034b50) throw new Error('bad local header for ' + name)
    const lNameLen = buf2.readUInt16LE(localOff + 26)
    const lExtraLen = buf2.readUInt16LE(localOff + 28)
    const dataStart = localOff + 30 + lNameLen + lExtraLen
    const comp = buf2.slice(dataStart, dataStart + compSize)
    let data
    if (method === 0) data = comp
    else if (method === 8) data = zlib.inflateRawSync(comp)
    else throw new Error('unsupported zip method ' + method + ' for ' + name)
    if (rawSize >= 0 && data.length !== rawSize) throw new Error('size mismatch for ' + name)
    out.push({ name, data })
  }
  return out
}
