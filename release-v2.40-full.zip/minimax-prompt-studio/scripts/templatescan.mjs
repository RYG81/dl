/* 📁 One scanner for the drop-in template folder — node-only.
 *
 * Subfolders are first-class: `public/prompts/templates/medical/moa.md` is scanned,
 * listed and loaded exactly like a root file. The scan is used by
 *   · vite.config.js      → the live `_index.json` + the built copy in dist/
 *   · scripts/audit-prompts.mjs → the library audit
 *   · scripts/selftest.mjs      → the hygiene sweeps
 * so all four can never disagree about what the folder contains.
 *
 * Skipped, at any depth: `_*` files/folders, README*, dotfiles.
 */
import fs from 'node:fs'
import path from 'node:path'
import { isUserTemplate } from '../src/lib/templatepaths.js'

export const MAX_DEPTH = 4   /* four folder levels under templates/ is plenty; deeper is ignored */

const skip = (name) => name.startsWith('_') || name.startsWith('.') || /^README/i.test(name)

/** Every template file under `dir`, as { rel, folder, name, abs }, sorted by rel. */
export function scanTemplates(dir, _rel = '', _depth = 0) {
  const out = []
  if (_depth > MAX_DEPTH || !fs.existsSync(dir)) return out
  let entries = []
  try { entries = fs.readdirSync(dir, { withFileTypes: true }) } catch (e) { return out }
  for (const e of entries) {
    if (skip(e.name)) continue
    const rel = _rel ? _rel + '/' + e.name : e.name
    const abs = path.join(dir, e.name)
    if (e.isDirectory()) out.push(...scanTemplates(abs, rel, _depth + 1))
    else if (e.name.endsWith('.md')) out.push({ rel, folder: _rel, name: e.name, abs })
  }
  return out.sort((a, b) => a.rel.localeCompare(b.rel))
}

/** The relative paths only — what `_index.json` carries. */
export const templateIndex = (dir) => scanTemplates(dir).map((f) => f.rel)

/** Folder names present, root first, then alphabetical. `''` means the root folder. */
export function templateFolders(files) {
  const set = new Set(files.map((f) => f.folder || ''))
  return [...set].sort((a, b) => (a === '' ? -1 : b === '' ? 1 : a.localeCompare(b)))
}

/* The user-vs-builtin rule lives with the app (src/lib/templatepaths.js) so the scanner,
   the loader and the picker can never disagree about it. */
export { isUserTemplate }
