import re
from typing import List, Tuple, Optional

try:
    import ollama
    OLLAMA_AVAILABLE = True
except ImportError:
    OLLAMA_AVAILABLE = False

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


def call_ollama(model: str, system_prompt: str, user_message: str,
                temperature: float = 0.7, seed: Optional[int] = None) -> str:
    """Call local Ollama using official package or HTTP fallback."""
    options = {
        "temperature": temperature,
        "num_ctx": 8192,
    }
    if seed is not None and seed > 0:
        options["seed"] = seed

    if OLLAMA_AVAILABLE:
        try:
            response = ollama.chat(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message}
                ],
                options=options
            )
            return response["message"]["content"]
        except Exception as e:
            print(f"[PhotosetGenerator] ollama package error: {e}")

    if REQUESTS_AVAILABLE:
        try:
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message}
                ],
                "stream": False,
                "options": options
            }
            resp = requests.post(
                "http://localhost:11434/api/chat",
                json=payload,
                timeout=300
            )
            resp.raise_for_status()
            return resp.json()["message"]["content"]
        except Exception as e:
            raise RuntimeError(
                f"Failed to reach Ollama at http://localhost:11434\n"
                f"Make sure Ollama is running and model '{model}' is available.\n"
                f"Error: {e}"
            )

    raise RuntimeError(
        "Neither 'ollama' nor 'requests' is installed.\n"
        "Run:  pip install ollama   or   pip install requests"
    )


def parse_llm_output(raw: str, expected_num: int) -> Tuple[List[str], str]:
    """Extract summary and clean prompts from LLM response."""
    summary = ""
    prompts = []

    summary_match = re.search(
        r"=== PHOTOSET SUMMARY ===\s*(.*?)\s*=== END SUMMARY ===",
        raw, re.DOTALL | re.IGNORECASE
    )
    if summary_match:
        summary = summary_match.group(1).strip()

    prompts_match = re.search(
        r"=== PROMPTS ===\s*(.*?)\s*=== END PROMPTS ===",
        raw, re.DOTALL | re.IGNORECASE
    )
    text_to_parse = prompts_match.group(1).strip() if prompts_match else raw

    lines = text_to_parse.splitlines()
    current_prompt = []

    for line in lines:
        line = line.strip()
        if not line:
            continue
        num_match = re.match(r"^(\d+)[\.\)\-\:]\s+(.*)", line)
        if num_match:
            if current_prompt:
                prompts.append(" ".join(current_prompt).strip())
            current_prompt = [num_match.group(2).strip()]
        else:
            if current_prompt:
                current_prompt.append(line)

    if current_prompt:
        prompts.append(" ".join(current_prompt).strip())

    # Fallback if numbered parsing failed
    if len(prompts) < max(1, expected_num // 2):
        chunks = [p.strip() for p in re.split(r"\n\s*\n", text_to_parse) if p.strip()]
        cleaned = []
        for p in chunks:
            cleaned.append(re.sub(r"^\d+[\.\)\-\:]\s*", "", p).strip())
        prompts = [p for p in cleaned if len(p) > 40]

    return prompts[:expected_num + 5], summary


DEFAULT_SYSTEM_PROMPT = """You are an expert prompt engineer specialized in creating high-end artistic nude / softcore glamour photoset prompts in the exact quality and style of MetArt, Eternal Desire, Femjoy, and Stunning.

Your task is to take a short creative brief from the user and expand it into a complete, coherent, progressive photoset.

### STRICT RULES YOU MUST FOLLOW:

1. **Model Consistency**
   - Invent one detailed, beautiful 18-28 year old woman description and keep it 100% identical in every single prompt.
   - Include: age, ethnicity/heritage feel, hair (length + style + color), eye color, body type, breast description (always natural), facial expression base (prefer joyful / warm / sensual smile).

2. **Location Consistency**
   - Invent one rich, specific location and keep the core environment identical across all prompts.
   - Describe key furniture, architecture, and atmosphere.

3. **Progressive Teasing Structure** (very important)
   Divide the photoset into clear stages of undressing. Never jump straight to full explicit nude.
   Typical good progression:
   - Early prompts: stylish clothing / dress / lingerie
   - Middle: partial undress, topless, thong only
   - Later: full artistic nude with elegant poses
   Always keep it refined and tasteful.

4. **Prompt Quality Requirements**
   Every single prompt MUST contain:
   - Full consistent model description
   - Exact current clothing / nudity state
   - Specific pose and body language
   - Clear interaction with the environment/furniture
   - Camera framing (full body, three-quarter, medium, close-up, low angle, etc.)
   - Lighting description
   - Atmosphere / mood
   - Ending quality boosters: photorealistic, ultra detailed skin texture, professional photography, [Style] style, sharp focus, natural skin pores, soft cinematic lighting, 8k, masterpiece

5. **Variety**
   - Strong variation in poses, angles, and framing
   - Keep the joyful / sensual / elegant tone consistent with the brief

6. **Output Format** (CRITICAL - follow exactly)
   First output a short structured summary in this exact format:

   === PHOTOSET SUMMARY ===
   Model: [full model description]
   Location: [full location description]
   Clothing Theme: [short name of the progression theme]
   Lighting: [main lighting style]
   Mood: [overall mood]
   Style: [MetArt / Eternal Desire / Femjoy / etc.]
   === END SUMMARY ===

   Then output the prompts like this:

   === PROMPTS ===
   1. [full prompt text]
   2. [full prompt text]
   3. [full prompt text]
   ...
   === END PROMPTS ===

Do not add any extra commentary, explanations, or markdown outside of the required sections.
Write rich, cinematic, natural-language prompts. Never use crude language."""


class SmartPhotosetGenerator:
    """
    Smart Photoset Prompt Generator
    --------------------------------
    Minimal user input (just a short creative brief).
    Local Ollama expands it into a full consistent MetArt / Eternal Desire style
    progressive photoset and generates high-quality prompts.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "creative_brief": ("STRING", {
                    "multiline": True,
                    "default": "Joyful slim brunette with green eyes on a sunny Mediterranean patio, playful and free",
                    "placeholder": "Describe the vibe in one line or a short paragraph..."
                }),
                "num_prompts": ("INT", {
                    "default": 10,
                    "min": 1,
                    "max": 50,
                    "step": 1
                }),
                "starting_number": ("INT", {
                    "default": 1,
                    "min": 1,
                    "max": 1000,
                    "step": 1
                }),
                "ollama_model": ("STRING", {
                    "default": "qwen2.5:14b",
                    "placeholder": "qwen2.5:14b / llama3.1:8b / mistral-nemo etc."
                }),
            },
            "optional": {
                "temperature": ("FLOAT", {
                    "default": 0.7,
                    "min": 0.1,
                    "max": 1.5,
                    "step": 0.05
                }),
                "seed": ("INT", {
                    "default": 0,
                    "min": 0,
                    "max": 0xffffffffffffffff
                }),
                "force_style": (["Auto", "MetArt", "Eternal Desire", "Femjoy", "Stunning", "Playboy Soft"],),
                "system_prompt_override": ("STRING", {
                    "multiline": True,
                    "default": "",
                    "placeholder": "Leave empty to use the built-in high-quality system prompt"
                }),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("prompts_list", "prompts_text", "photoset_summary", "raw_llm_output")
    FUNCTION = "generate"
    CATEGORY = "Photoset / Prompt Tools"
    DESCRIPTION = "Generate high-end progressive MetArt-style photoset prompts from a short creative brief using local Ollama."

    def generate(self, creative_brief: str, num_prompts: int, starting_number: int,
                 ollama_model: str, temperature: float = 0.7, seed: int = 0,
                 force_style: str = "Auto", system_prompt_override: str = ""):

        if not creative_brief.strip():
            raise ValueError("Creative Brief cannot be empty.")

        system_prompt = system_prompt_override.strip() if system_prompt_override.strip() else DEFAULT_SYSTEM_PROMPT

        style_instruction = ""
        if force_style and force_style != "Auto":
            style_instruction = f"\nForce the overall production style to be: {force_style}."

        user_message = f"""Creative Brief:
{creative_brief.strip()}
{style_instruction}

Please create a coherent progressive photoset and generate exactly {num_prompts} high-quality prompts.
Start numbering the prompts from {starting_number}.

Remember to follow the exact output format with === PHOTOSET SUMMARY === and === PROMPTS === sections."""

        raw_output = call_ollama(
            model=ollama_model,
            system_prompt=system_prompt,
            user_message=user_message,
            temperature=temperature,
            seed=seed if seed > 0 else None
        )

        prompts, summary = parse_llm_output(raw_output, num_prompts)

        prompts_list = "\n".join([f"{i + starting_number}. {p}" for i, p in enumerate(prompts)])
        prompts_text = "\n\n".join(prompts)
        photoset_summary = summary if summary else "Summary not extracted cleanly. See raw output."

        return (prompts_list, prompts_text, photoset_summary, raw_output)


class ContinuePhotoset:
    """
    Continue an existing photoset.
    Paste the previous PHOTOSET SUMMARY and it will generate the next batch
    while keeping perfect consistency.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "previous_summary": ("STRING", {
                    "multiline": True,
                    "default": "",
                    "placeholder": "Paste the full === PHOTOSET SUMMARY === block from the previous generation"
                }),
                "num_prompts": ("INT", {
                    "default": 10,
                    "min": 1,
                    "max": 50,
                    "step": 1
                }),
                "starting_number": ("INT", {
                    "default": 11,
                    "min": 1,
                    "max": 1000,
                    "step": 1
                }),
                "ollama_model": ("STRING", {
                    "default": "qwen2.5:14b",
                }),
            },
            "optional": {
                "temperature": ("FLOAT", {
                    "default": 0.7,
                    "min": 0.1,
                    "max": 1.5,
                    "step": 0.05
                }),
                "seed": ("INT", {
                    "default": 0,
                    "min": 0,
                    "max": 0xffffffffffffffff
                }),
                "extra_instructions": ("STRING", {
                    "multiline": True,
                    "default": "",
                    "placeholder": "Optional: any extra direction for this batch (e.g. more open poses, focus on back views...)"
                }),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("prompts_list", "prompts_text", "photoset_summary", "raw_llm_output")
    FUNCTION = "continue_set"
    CATEGORY = "Photoset / Prompt Tools"
    DESCRIPTION = "Continue a previous photoset using its summary. Keeps model, location and style 100% consistent."

    def continue_set(self, previous_summary: str, num_prompts: int, starting_number: int,
                     ollama_model: str, temperature: float = 0.7, seed: int = 0,
                     extra_instructions: str = ""):

        if not previous_summary.strip():
            raise ValueError("Previous Summary cannot be empty. Paste the PHOTOSET SUMMARY from the first generation.")

        system_prompt = DEFAULT_SYSTEM_PROMPT + """

You are now continuing an already defined photoset.
You MUST reuse the exact Model, Location, Clothing Theme, Lighting, Mood and Style from the provided summary.
Do not invent a new model or location.
Continue the progressive undressing naturally from the given starting number.
"""

        extra = f"\n\nAdditional instructions for this batch:\n{extra_instructions.strip()}" if extra_instructions.strip() else ""

        user_message = f"""Here is the existing photoset definition:

{previous_summary.strip()}

Generate the next {num_prompts} prompts for this same photoset.
Start numbering from {starting_number}.
Keep the model description, location, clothing progression logic, lighting and style exactly the same.
{extra}

Follow the exact output format with === PHOTOSET SUMMARY === (you can repeat the same summary) and === PROMPTS === sections."""

        raw_output = call_ollama(
            model=ollama_model,
            system_prompt=system_prompt,
            user_message=user_message,
            temperature=temperature,
            seed=seed if seed > 0 else None
        )

        prompts, summary = parse_llm_output(raw_output, num_prompts)

        # Prefer the original summary if the new one is weaker
        final_summary = summary if summary else previous_summary.strip()

        prompts_list = "\n".join([f"{i + starting_number}. {p}" for i, p in enumerate(prompts)])
        prompts_text = "\n\n".join(prompts)

        return (prompts_list, prompts_text, final_summary, raw_output)


# ComfyUI registration
NODE_CLASS_MAPPINGS = {
    "SmartPhotosetGenerator": SmartPhotosetGenerator,
    "ContinuePhotoset": ContinuePhotoset,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "SmartPhotosetGenerator": "Smart Photoset Prompt Generator (Ollama)",
    "ContinuePhotoset": "Continue Photoset (Ollama)",
}
