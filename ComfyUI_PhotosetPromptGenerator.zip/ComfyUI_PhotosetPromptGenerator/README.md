# Smart Photoset Prompt Generator for ComfyUI + Ollama

**Complete pack** for generating high-end progressive MetArt / Eternal Desire / Femjoy style photosets using local Ollama.

Any user can create full coherent 50–100 image artistic photosets with minimal effort.

---

## What's Included

### Nodes (4)

| Node | Purpose |
|------|---------|
| **Smart Photoset Prompt Generator (Ollama)** | Main node – create a new photoset from a short creative brief |
| **Continue Photoset (Ollama)** | Generate the next batch while keeping perfect consistency |
| **Photoset Preset Loader** | Instantly load high-quality ready-made briefs |
| **Example Summary Loader** | Load example summaries to test the Continue node |

### Data Files

- `presets.json` – 8 high-quality presets (Mediterranean Joy, Elegant Salon, Soft Romantic Bedroom, etc.)
- `examples.json` – Ready-to-use photoset summaries for testing

---

## Installation

1. Make sure **Ollama** is installed and running:
   ```bash
   ollama serve
   ollama pull qwen2.5:14b
   ```

2. Copy the entire folder into:
   ```
   ComfyUI/custom_nodes/ComfyUI_PhotosetPromptGenerator/
   ```

3. Install dependencies:
   ```bash
   pip install ollama requests
   ```

4. Restart ComfyUI.

---

## Quick Start (Recommended for new users)

1. Add **Photoset Preset Loader**
2. Choose a preset (e.g. "Mediterranean Joy (Gloria style)")
3. Connect its outputs to **Smart Photoset Prompt Generator**
4. Set number of prompts (10–20)
5. Queue Prompt

You now have a professional progressive photoset.

To continue the set:
- Copy the `photoset_summary` output
- Paste it into **Continue Photoset**
- Generate the next batch

---

## Recommended Ollama Models

| Model | Quality | Speed | VRAM | Notes |
|-------|---------|-------|------|-------|
| qwen2.5:14b | Excellent | Fast | ~10 GB | **Best choice** |
| llama3.1:8b | Very Good | Very Fast | ~6 GB | Great for lower VRAM |
| mistral-nemo | Excellent | Fast | ~8 GB | Strong alternative |
| qwen2.5:32b | Highest | Slower | ~20 GB | Maximum quality |

---

## Tips for Best Results

- Generate in batches of 10–20 prompts
- Always reuse the `photoset_summary` when continuing
- Temperature 0.65 – 0.8 works best
- Use the Preset Loader if you don’t want to write briefs yourself
- Force a style (MetArt / Eternal Desire / Femjoy) when you want a specific aesthetic

---

Enjoy creating beautiful, coherent MetArt-style photosets fully locally.
