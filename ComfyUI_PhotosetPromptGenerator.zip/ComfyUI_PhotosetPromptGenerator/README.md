# Smart Photoset Prompt Generator for ComfyUI + Ollama

Generate high-end progressive **MetArt / Eternal Desire / Femjoy** style photoset prompts from a short creative brief using your local Ollama models.

**Minimal input → Maximum quality.**

You only write a one-line (or short paragraph) idea.  
The LLM designs the model, location, clothing progression, lighting and mood, then writes rich consistent prompts.

---

## Features

- **SmartPhotosetGenerator** – Create a brand new photoset from a short brief
- **ContinuePhotoset** – Generate the next batch of the same photoset (keeps perfect consistency)
- Fully local & private (Ollama)
- Strong progressive teasing structure (clothed → lingerie → topless → artistic nude)
- High-quality cinematic prompts ready for Flux, SD3, Pony, etc.
- Seed + temperature control
- Optional force style (MetArt, Eternal Desire, Femjoy…)

---

## Installation

1. **Install Ollama** and pull a good model:
   ```bash
   ollama pull qwen2.5:14b
   # or
   ollama pull llama3.1:8b
   ollama pull mistral-nemo
   ```

2. Copy this entire folder into your ComfyUI custom nodes directory:
   ```
   ComfyUI/custom_nodes/ComfyUI_PhotosetPromptGenerator/
   ```

3. Install Python dependencies (inside the same Python environment ComfyUI uses):
   ```bash
   pip install -r requirements.txt
   ```
   or simply:
   ```bash
   pip install ollama requests
   ```

4. Restart ComfyUI.

---

## How to Use

### 1. Create a new photoset
- Add node: **Photoset / Prompt Tools → Smart Photoset Prompt Generator (Ollama)**
- Write a short **Creative Brief**, examples:

  ```
  Joyful slim brunette with green eyes on a sunny Mediterranean patio, playful and free
  ```

  ```
  Elegant long dark-haired woman in a soft-lit luxurious Parisian bedroom, romantic and sensual
  ```

  ```
  Athletic blonde in a modern minimalist loft with big windows, confident and glamorous
  ```

- Set number of prompts (10 is perfect for first batch)
- Choose your Ollama model
- Queue Prompt

### 2. Continue the same photoset
- Copy the **photoset_summary** output from the first node
- Add node: **Continue Photoset (Ollama)**
- Paste the summary into **previous_summary**
- Set the next starting number (e.g. 11)
- Generate the next batch

---

## Recommended Models

| Model              | Quality | Speed   | VRAM   | Recommendation      |
|--------------------|---------|---------|--------|---------------------|
| qwen2.5:14b        | Excellent | Fast  | ~10GB | **Best overall**    |
| llama3.1:8b        | Very Good | Very Fast | ~6GB | Great for lower VRAM |
| mistral-nemo       | Excellent | Fast  | ~8GB  | Strong alternative  |
| qwen2.5:32b        | Highest | Slower | ~20GB | Maximum quality     |

---

## Tips

- Temperature 0.65 – 0.8 works best
- Generate in batches of 10–20 for best consistency
- Always reuse the summary when continuing
- You can force a style with the dropdown if you want pure MetArt, Eternal Desire, etc.

---

Enjoy creating beautiful, coherent photosets locally.
