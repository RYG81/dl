from .nodes.model_loader import (
    NODE_CLASS_MAPPINGS as m1,
    NODE_DISPLAY_NAME_MAPPINGS as d1,
)
from .nodes.location_loader import (
    NODE_CLASS_MAPPINGS as m2,
    NODE_DISPLAY_NAME_MAPPINGS as d2,
)
from .nodes.outfit_loader import (
    NODE_CLASS_MAPPINGS as m3,
    NODE_DISPLAY_NAME_MAPPINGS as d3,
)
from .nodes.outfit_sequence import (
    NODE_CLASS_MAPPINGS as m4,
    NODE_DISPLAY_NAME_MAPPINGS as d4,
)
from .nodes.fashion_shoot_plan import (
    NODE_CLASS_MAPPINGS as m5,
    NODE_DISPLAY_NAME_MAPPINGS as d5,
)
from .nodes.plan_to_prompt import (
    NODE_CLASS_MAPPINGS as m6,
    NODE_DISPLAY_NAME_MAPPINGS as d6,
)
from .nodes.batch_index import (
    NODE_CLASS_MAPPINGS as m7,
    NODE_DISPLAY_NAME_MAPPINGS as d7,
)
from .nodes.manifest import (
    NODE_CLASS_MAPPINGS as m8,
    NODE_DISPLAY_NAME_MAPPINGS as d8,
)
from .nodes.plan_editor import (
    NODE_CLASS_MAPPINGS as m9,
    NODE_DISPLAY_NAME_MAPPINGS as d9,
)

NODE_CLASS_MAPPINGS = {}
NODE_DISPLAY_NAME_MAPPINGS = {}

for mapping, display in [
    (m1, d1), (m2, d2), (m3, d3), (m4, d4),
    (m5, d5), (m6, d6), (m7, d7), (m8, d8), (m9, d9),
]:
    NODE_CLASS_MAPPINGS.update(mapping)
    NODE_DISPLAY_NAME_MAPPINGS.update(display)

WEB_DIRECTORY = "web"

# Live-data API for the web widget (web/asb_fashion_widgets.js). Guarded so
# the package still imports cleanly outside a running ComfyUI server (e.g.
# for local testing of the node logic).
try:
    from aiohttp import web as _aiohttp_web
    from server import PromptServer as _PromptServer
    from .nodes.utils import list_models, list_locations, list_outfits
    import os as _os
    import json as _json

    _DATA_LISTERS = {
        "models": list_models,
        "locations": list_locations,
        "outfits": list_outfits,
    }

    @_PromptServer.instance.routes.get("/asb_fashion/data")
    async def _asb_fashion_data(request):
        from .nodes.utils import load_json, load_shared
        from .nodes.plan_editor import QUALITY_PRESETS

        data_type = request.rel_url.query.get("type", "")

        if data_type in _DATA_LISTERS:
            return _aiohttp_web.json_response({"items": _DATA_LISTERS[data_type]()})

        if data_type == "zones":
            location_name = request.rel_url.query.get("location", "")
            try:
                location = load_json("locations", location_name)
            except FileNotFoundError:
                return _aiohttp_web.json_response({"error": "unknown location"}, status=400)
            zones = [{"id": z["id"], "name": z["name"]} for z in location.get("zones", [])]
            return _aiohttp_web.json_response({"items": zones})

        if data_type == "patterns":
            patterns = load_shared("coverage_patterns.json")
            items = [{"id": p["id"], "name": p["name"], "shot_intent": p["shot_intent"]} for p in patterns]
            return _aiohttp_web.json_response({"items": items})

        if data_type == "poses":
            poses = load_shared("poses.json")
            items = [{"id": p["id"], "mood": p.get("mood", [])} for p in poses]
            return _aiohttp_web.json_response({"items": items})

        if data_type == "cameras":
            cameras = load_shared("cameras.json")
            items = [{"id": c["id"], "name": c["name"]} for c in cameras]
            return _aiohttp_web.json_response({"items": items})

        if data_type == "qualities":
            items = [{"id": k, "label": k} for k in QUALITY_PRESETS.keys()]
            return _aiohttp_web.json_response({"items": items})

        return _aiohttp_web.json_response({"error": f"unknown type '{data_type}'"}, status=400)

    # Powers the embedded Plan Editor panel (web/asb_plan_editor.js). Runs
    # the exact same engine (ASB_FashionShootPlan) and resolver
    # (ASB_PlanToPrompt) the actual nodes use — the preview is never a
    # separate/simplified implementation that could drift from real output.
    @_PromptServer.instance.routes.post("/asb_fashion/preview_plan")
    async def _asb_fashion_preview_plan(request):
        from .nodes.utils import load_json
        from .nodes.fashion_shoot_plan import ASB_FashionShootPlan
        from .nodes.plan_to_prompt import ASB_PlanToPrompt

        try:
            body = await request.json()
            model = load_json("models", body["model_name"])
            location = load_json("locations", body["location_name"])
            outfit_names = body.get("outfit_names") or []
            if not outfit_names:
                return _aiohttp_web.json_response(
                    {"error": "select at least one outfit"}, status=400
                )
            outfit_sequence = [load_json("outfits", n) for n in outfit_names]

            plan, plan_summary, shot_count = ASB_FashionShootPlan().build(
                model,
                location,
                outfit_sequence,
                int(body.get("shots_per_look", 24)),
                body.get("coverage_density", "standard"),
                bool(body.get("include_detail_shots", True)),
                int(body.get("seed", 0)),
            )

            resolver = ASB_PlanToPrompt()
            style = body.get(
                "style", "editorial fashion photography, clean composition, sharp focus"
            )
            negative = body.get(
                "negative", "blurry, deformed, extra limbs, watermark, low quality"
            )
            camera = body.get("camera", "(none)")

            shots = []
            for i in range(len(plan)):
                prompt, neg, sd, fname, idx, done = resolver.resolve(
                    plan, model, location, outfit_sequence, camera, style, negative, False, index=i
                )
                s = plan[i]
                shots.append({
                    "index": i,
                    "outfit_id": s.get("outfit_id"),
                    "outfit_name": s["outfit_name"],
                    "zone_id": s.get("zone_id"),
                    "zone_name": s["zone_name"],
                    "pattern_id": s.get("pattern_id"),
                    "pattern_name": s["pattern_name"],
                    "shot_intent": s["shot_intent"],
                    "pose_id": s["pose_id"],
                    "seed": sd,
                    "filename_hint": fname,
                    "prompt": prompt,
                })

            return _aiohttp_web.json_response(
                {"plan_summary": plan_summary, "shot_count": shot_count, "shots": shots}
            )
        except FileNotFoundError as exc:
            return _aiohttp_web.json_response({"error": f"data file not found: {exc}"}, status=400)
        except Exception as exc:  # noqa: BLE001 - surface any failure to the panel instead of a bare 500
            return _aiohttp_web.json_response({"error": str(exc)}, status=500)

    # Powers "+ Shot" in the panel — resolves ONE hand-picked zone/pattern/pose
    # combo through the real resolver, so a manually added shot's prompt text
    # is built by the same code path as every auto-generated shot.
    @_PromptServer.instance.routes.post("/asb_fashion/resolve_shot")
    async def _asb_fashion_resolve_shot(request):
        from .nodes.utils import load_json, load_shared
        from .nodes.plan_to_prompt import ASB_PlanToPrompt

        try:
            body = await request.json()
            model = load_json("models", body["model_name"])
            location = load_json("locations", body["location_name"])
            outfit = load_json("outfits", body["outfit_name"])

            patterns = load_shared("coverage_patterns.json")
            pattern = next((p for p in patterns if p["id"] == body["pattern_id"]), None)
            if pattern is None:
                return _aiohttp_web.json_response({"error": "unknown pattern_id"}, status=400)

            zone = next((z for z in location.get("zones", []) if z["id"] == body["zone_id"]), None)
            if zone is None:
                return _aiohttp_web.json_response({"error": "unknown zone_id"}, status=400)

            shot = {
                "index": 0,
                "model_id": model.get("id"),
                "outfit_id": outfit.get("id"),
                "outfit_name": outfit.get("name"),
                "zone_id": zone["id"],
                "zone_name": zone["name"],
                "pattern_id": pattern["id"],
                "pattern_name": pattern["name"],
                "framing_id": pattern["framing_id"],
                "shot_intent": pattern["shot_intent"],
                "pose_id": body.get("pose_id", ""),
                "detail_piece_id": body.get("piece_id"),
                "seed": int(body.get("seed", 0)),
                "filename_hint": f"manual_{pattern['id']}",
            }

            resolver = ASB_PlanToPrompt()
            style = body.get("style", "editorial fashion photography, clean composition, sharp focus")
            negative = body.get("negative", "blurry, deformed, extra limbs, watermark, low quality")
            camera = body.get("camera", "(none)")
            prompt, neg, sd, fname, idx, done = resolver.resolve(
                [shot], model, location, [outfit], camera, style, negative, False, index=0
            )
            return _aiohttp_web.json_response({
                "outfit_name": outfit.get("name"),
                "zone_name": zone["name"],
                "pattern_id": pattern["id"],
                "pattern_name": pattern["name"],
                "shot_intent": pattern["shot_intent"],
                "pose_id": shot["pose_id"],
                "prompt": prompt,
                "negative": neg,
                "seed": sd,
                "filename_hint": fname,
            })
        except KeyError as exc:
            return _aiohttp_web.json_response({"error": f"missing field: {exc}"}, status=400)
        except FileNotFoundError as exc:
            return _aiohttp_web.json_response({"error": f"data file not found: {exc}"}, status=400)
        except Exception as exc:  # noqa: BLE001
            return _aiohttp_web.json_response({"error": str(exc)}, status=500)

    # Minimal named-plan store for the panel's "Server" section — saves the
    # full panel config (not just the shot list) as JSON under
    # <pack>/saved_plans/, so a plan can be reloaded by name from any
    # workstation pointed at the same ComfyUI instance.
    import re as _re

    _SAVED_PLANS_DIR = _os.path.join(_os.path.dirname(__file__), "saved_plans")

    def _safe_plan_name(name):
        name = _re.sub(r"[^A-Za-z0-9_\-]", "_", (name or "").strip())[:80]
        return name or None

    @_PromptServer.instance.routes.get("/asb_fashion/plans")
    async def _asb_fashion_list_plans(request):
        if not _os.path.isdir(_SAVED_PLANS_DIR):
            return _aiohttp_web.json_response({"items": []})
        names = sorted(f[:-5] for f in _os.listdir(_SAVED_PLANS_DIR) if f.endswith(".json"))
        return _aiohttp_web.json_response({"items": names})

    @_PromptServer.instance.routes.post("/asb_fashion/plans")
    async def _asb_fashion_save_plan(request):
        try:
            body = await request.json()
            name = _safe_plan_name(body.get("name"))
            if not name:
                return _aiohttp_web.json_response({"error": "invalid plan name"}, status=400)
            _os.makedirs(_SAVED_PLANS_DIR, exist_ok=True)
            path = _os.path.join(_SAVED_PLANS_DIR, f"{name}.json")
            with open(path, "w", encoding="utf-8") as f:
                _json.dump(body.get("data", {}), f, indent=2)
            return _aiohttp_web.json_response({"saved": name})
        except Exception as exc:  # noqa: BLE001
            return _aiohttp_web.json_response({"error": str(exc)}, status=500)

    @_PromptServer.instance.routes.get(r"/asb_fashion/plans/{name}")
    async def _asb_fashion_load_plan(request):
        name = _safe_plan_name(request.match_info.get("name"))
        if not name:
            return _aiohttp_web.json_response({"error": "invalid plan name"}, status=400)
        path = _os.path.join(_SAVED_PLANS_DIR, f"{name}.json")
        if not _os.path.isfile(path):
            return _aiohttp_web.json_response({"error": "plan not found"}, status=404)
        with open(path, "r", encoding="utf-8") as f:
            return _aiohttp_web.json_response({"data": _json.load(f)})

    @_PromptServer.instance.routes.delete(r"/asb_fashion/plans/{name}")
    async def _asb_fashion_delete_plan(request):
        name = _safe_plan_name(request.match_info.get("name"))
        if not name:
            return _aiohttp_web.json_response({"error": "invalid plan name"}, status=400)
        path = _os.path.join(_SAVED_PLANS_DIR, f"{name}.json")
        if not _os.path.isfile(path):
            return _aiohttp_web.json_response({"error": "plan not found"}, status=404)
        _os.remove(path)
        return _aiohttp_web.json_response({"deleted": name})

except ImportError:
    pass

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS", "WEB_DIRECTORY"]
