from .nodes.model_loader import (
    NODE_CLASS_MAPPINGS as m1,
    NODE_DISPLAY_NAME_MAPPINGS as d1,
)
from .nodes.location_loader import (
    NODE_CLASS_MAPPINGS as m2,
    NODE_DISPLAY_NAME_MAPPINGS as d2,
)
from .nodes.outfit_loader import (
    NODE_CLASS_MAPPINGS as m3,
    NODE_DISPLAY_NAME_MAPPINGS as d3,
)
from .nodes.outfit_sequence import (
    NODE_CLASS_MAPPINGS as m4,
    NODE_DISPLAY_NAME_MAPPINGS as d4,
)
from .nodes.fashion_shoot_plan import (
    NODE_CLASS_MAPPINGS as m5,
    NODE_DISPLAY_NAME_MAPPINGS as d5,
)
from .nodes.plan_to_prompt import (
    NODE_CLASS_MAPPINGS as m6,
    NODE_DISPLAY_NAME_MAPPINGS as d6,
)
from .nodes.batch_index import (
    NODE_CLASS_MAPPINGS as m7,
    NODE_DISPLAY_NAME_MAPPINGS as d7,
)
from .nodes.manifest import (
    NODE_CLASS_MAPPINGS as m8,
    NODE_DISPLAY_NAME_MAPPINGS as d8,
)
from .nodes.plan_editor import (
    NODE_CLASS_MAPPINGS as m9,
    NODE_DISPLAY_NAME_MAPPINGS as d9,
)

NODE_CLASS_MAPPINGS = {}
NODE_DISPLAY_NAME_MAPPINGS = {}

for mapping, display in [
    (m1, d1), (m2, d2), (m3, d3), (m4, d4),
    (m5, d5), (m6, d6), (m7, d7), (m8, d8), (m9, d9),
]:
    NODE_CLASS_MAPPINGS.update(mapping)
    NODE_DISPLAY_NAME_MAPPINGS.update(display)

WEB_DIRECTORY = "web"

# Live-data API for the web widget (web/asb_fashion_widgets.js). Guarded so
# the package still imports cleanly outside a running ComfyUI server (e.g.
# for local testing of the node logic).
try:
    from aiohttp import web as _aiohttp_web
    from server import PromptServer as _PromptServer
    from .nodes.utils import list_models, list_locations, list_outfits

    _DATA_LISTERS = {
        "models": list_models,
        "locations": list_locations,
        "outfits": list_outfits,
    }

    @_PromptServer.instance.routes.get("/asb_fashion/data")
    async def _asb_fashion_data(request):
        data_type = request.rel_url.query.get("type", "")
        lister = _DATA_LISTERS.get(data_type)
        if lister is None:
            return _aiohttp_web.json_response(
                {"error": f"unknown type '{data_type}'"}, status=400
            )
        return _aiohttp_web.json_response({"items": lister()})

    # Powers the embedded Plan Editor panel (web/asb_plan_editor.js). Runs
    # the exact same engine (ASB_FashionShootPlan) and resolver
    # (ASB_PlanToPrompt) the actual nodes use — the preview is never a
    # separate/simplified implementation that could drift from real output.
    @_PromptServer.instance.routes.post("/asb_fashion/preview_plan")
    async def _asb_fashion_preview_plan(request):
        from .nodes.utils import load_json
        from .nodes.fashion_shoot_plan import ASB_FashionShootPlan
        from .nodes.plan_to_prompt import ASB_PlanToPrompt

        try:
            body = await request.json()
            model = load_json("models", body["model_name"])
            location = load_json("locations", body["location_name"])
            outfit_names = body.get("outfit_names") or []
            if not outfit_names:
                return _aiohttp_web.json_response(
                    {"error": "select at least one outfit"}, status=400
                )
            outfit_sequence = [load_json("outfits", n) for n in outfit_names]

            plan, plan_summary, shot_count = ASB_FashionShootPlan().build(
                model,
                location,
                outfit_sequence,
                int(body.get("shots_per_look", 24)),
                body.get("coverage_density", "standard"),
                bool(body.get("include_detail_shots", True)),
                int(body.get("seed", 0)),
            )

            resolver = ASB_PlanToPrompt()
            style = body.get(
                "style", "editorial fashion photography, clean composition, sharp focus"
            )
            negative = body.get(
                "negative", "blurry, deformed, extra limbs, watermark, low quality"
            )
            camera = body.get("camera", "(none)")

            shots = []
            for i in range(len(plan)):
                prompt, neg, sd, fname, idx, done = resolver.resolve(
                    plan, model, location, outfit_sequence, camera, style, negative, False, index=i
                )
                s = plan[i]
                shots.append({
                    "index": i,
                    "outfit_name": s["outfit_name"],
                    "zone_name": s["zone_name"],
                    "pattern_name": s["pattern_name"],
                    "shot_intent": s["shot_intent"],
                    "pose_id": s["pose_id"],
                    "seed": sd,
                    "filename_hint": fname,
                    "prompt": prompt,
                })

            return _aiohttp_web.json_response(
                {"plan_summary": plan_summary, "shot_count": shot_count, "shots": shots}
            )
        except FileNotFoundError as exc:
            return _aiohttp_web.json_response({"error": f"data file not found: {exc}"}, status=400)
        except Exception as exc:  # noqa: BLE001 - surface any failure to the panel instead of a bare 500
            return _aiohttp_web.json_response({"error": str(exc)}, status=500)

except ImportError:
    pass

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS", "WEB_DIRECTORY"]
