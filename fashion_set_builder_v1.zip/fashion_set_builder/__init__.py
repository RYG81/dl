from .nodes.model_loader import (
    NODE_CLASS_MAPPINGS as m1,
    NODE_DISPLAY_NAME_MAPPINGS as d1,
)
from .nodes.location_loader import (
    NODE_CLASS_MAPPINGS as m2,
    NODE_DISPLAY_NAME_MAPPINGS as d2,
)
from .nodes.outfit_loader import (
    NODE_CLASS_MAPPINGS as m3,
    NODE_DISPLAY_NAME_MAPPINGS as d3,
)
from .nodes.outfit_sequence import (
    NODE_CLASS_MAPPINGS as m4,
    NODE_DISPLAY_NAME_MAPPINGS as d4,
)
from .nodes.fashion_shoot_plan import (
    NODE_CLASS_MAPPINGS as m5,
    NODE_DISPLAY_NAME_MAPPINGS as d5,
)
from .nodes.plan_to_prompt import (
    NODE_CLASS_MAPPINGS as m6,
    NODE_DISPLAY_NAME_MAPPINGS as d6,
)
from .nodes.batch_index import (
    NODE_CLASS_MAPPINGS as m7,
    NODE_DISPLAY_NAME_MAPPINGS as d7,
)
from .nodes.manifest import (
    NODE_CLASS_MAPPINGS as m8,
    NODE_DISPLAY_NAME_MAPPINGS as d8,
)

NODE_CLASS_MAPPINGS = {}
NODE_DISPLAY_NAME_MAPPINGS = {}

for mapping, display in [
    (m1, d1), (m2, d2), (m3, d3), (m4, d4),
    (m5, d5), (m6, d6), (m7, d7), (m8, d8),
]:
    NODE_CLASS_MAPPINGS.update(mapping)
    NODE_DISPLAY_NAME_MAPPINGS.update(display)

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
