import { app } from "../../scripts/app.js";

// Maps node type -> data type queried from the /asb_fashion/data endpoint.
// Matched against the combo widget whose name ends in "_name".
const REFRESHABLE_NODES = {
  ASB_LoadModel: "models",
  ASB_LoadLocation: "locations",
  ASB_LoadOutfit: "outfits",
};

async function fetchList(dataType) {
  try {
    const res = await fetch(`/asb_fashion/data?type=${dataType}`);
    if (!res.ok) return null;
    const data = await res.json();
    return Array.isArray(data.items) ? data.items : null;
  } catch (err) {
    console.warn("ASB Fashion: failed to fetch live data list", err);
    return null;
  }
}

function applyList(widget, items) {
  if (!items || !items.length) return;
  widget.options.values = items;
  if (!items.includes(widget.value)) {
    widget.value = items[0];
  }
}

app.registerExtension({
  name: "ASBFashion.LiveDropdowns",

  async nodeCreated(node) {
    const dataType = REFRESHABLE_NODES[node.comfyClass];
    if (!dataType) return;

    const widget = node.widgets?.find((w) => w.name && w.name.endsWith("_name"));
    if (!widget) return;

    // Pull the current list from disk as soon as the node is placed, so
    // JSON files added after ComfyUI last started still show up.
    fetchList(dataType).then((items) => {
      applyList(widget, items);
      node.setDirtyCanvas(true, true);
    });

    // Manual refresh for files added mid-session, after the node already exists.
    node.addWidget("button", "\uD83D\uDD04 Refresh List", null, async () => {
      const items = await fetchList(dataType);
      if (items && items.length) {
        applyList(widget, items);
        node.setDirtyCanvas(true, true);
      } else {
        console.warn("ASB Fashion: refresh returned no items for", dataType);
      }
    });
  },
});
