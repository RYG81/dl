import { app } from "../../scripts/app.js";

// Node types this extension manages, and which of their widgets are
// live-refreshable combo boxes. Any widget named "<thing>_name" is matched
// to data type "<thing>s" (model_name -> models, location_name -> locations,
// outfit_name -> outfits). Widgets like "outfit_names" (plural, chip-managed
// by the Plan Editor panel) intentionally don't match this pattern.
const ASB_NODE_TYPES = new Set([
  "ASB_LoadModel",
  "ASB_LoadLocation",
  "ASB_LoadOutfit",
  "ASB_PlanEditor",
]);

// ASB_PlanEditor has its own "Refresh data" button inside the embedded
// panel (which also refreshes the outfit list, not just model/location) —
// adding this extension's generic button there too is redundant clutter.
// Still auto-refresh its model_name/location_name silently on creation.
const NODE_TYPES_WITH_OWN_REFRESH_BUTTON = new Set(["ASB_PlanEditor"]);

function dataTypeForWidget(widgetName) {
  const match = widgetName.match(/^(.+)_name$/);
  if (!match) return null;
  return match[1] + "s";
}

async function fetchList(dataType) {
  try {
    const res = await fetch(`/asb_fashion/data?type=${dataType}`);
    if (!res.ok) return null;
    const data = await res.json();
    return Array.isArray(data.items) ? data.items : null;
  } catch (err) {
    console.warn("ASB Fashion: failed to fetch live data list", err);
    return null;
  }
}

function applyList(widget, items) {
  if (!items || !items.length) return;
  widget.options.values = items;
  if (!items.includes(widget.value)) {
    widget.value = items[0];
  }
}

app.registerExtension({
  name: "ASBFashion.LiveDropdowns",

  async nodeCreated(node) {
    if (!ASB_NODE_TYPES.has(node.comfyClass)) return;

    const refreshableWidgets = (node.widgets || [])
      .map((w) => ({ widget: w, dataType: w.name ? dataTypeForWidget(w.name) : null }))
      .filter((entry) => entry.dataType);
    if (!refreshableWidgets.length) return;

    async function refreshAll() {
      const results = await Promise.all(
        refreshableWidgets.map((entry) => fetchList(entry.dataType))
      );
      refreshableWidgets.forEach((entry, i) => applyList(entry.widget, results[i]));
      node.setDirtyCanvas(true, true);
    }

    // Pull current lists from disk as soon as the node is placed, so JSON
    // files added after ComfyUI last started still show up.
    refreshAll();

    // Manual refresh for files added mid-session, after the node already
    // exists — skipped for node types that already have their own richer
    // refresh control (see NODE_TYPES_WITH_OWN_REFRESH_BUTTON above).
    if (!NODE_TYPES_WITH_OWN_REFRESH_BUTTON.has(node.comfyClass)) {
      node.addWidget("button", "\uD83D\uDD04 Refresh List", null, refreshAll);
    }
  },
});
