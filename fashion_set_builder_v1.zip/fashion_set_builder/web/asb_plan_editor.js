import { app } from "../../scripts/app.js";

const PAGE_SIZE = 10;

function el(tag, props = {}, children = []) {
  const e = document.createElement(tag);
  Object.assign(e, props);
  for (const c of children) e.appendChild(c);
  return e;
}

async function fetchOutfitList() {
  try {
    const res = await fetch("/asb_fashion/data?type=outfits");
    const data = await res.json();
    return Array.isArray(data.items) ? data.items : [];
  } catch (err) {
    console.warn("ASB Plan Editor: failed to fetch outfit list", err);
    return [];
  }
}

app.registerExtension({
  name: "ASBFashion.PlanEditor",

  async nodeCreated(node) {
    if (node.comfyClass !== "ASB_PlanEditor") return;

    const modelWidget = node.widgets.find((w) => w.name === "model_name");
    const locationWidget = node.widgets.find((w) => w.name === "location_name");
    const outfitNamesWidget = node.widgets.find((w) => w.name === "outfit_names");
    const shotsWidget = node.widgets.find((w) => w.name === "shots_per_look");
    const densityWidget = node.widgets.find((w) => w.name === "coverage_density");
    const detailWidget = node.widgets.find((w) => w.name === "include_detail_shots");
    const seedWidget = node.widgets.find((w) => w.name === "seed");
    if (!outfitNamesWidget) return;

    const outfitList = await fetchOutfitList();

    let selectedOutfits = outfitNamesWidget.value
      ? outfitNamesWidget.value.split(",").map((s) => s.trim()).filter(Boolean)
      : [];
    let previewShots = [];
    let page = 0;

    function syncHiddenWidget() {
      outfitNamesWidget.value = selectedOutfits.join(",");
    }

    // --- outfit chip builder ---
    const chipRow = el("div", {
      style: "display:flex; flex-wrap:wrap; gap:4px; margin-bottom:4px; min-height:20px;",
    });

    function renderChips() {
      chipRow.innerHTML = "";
      selectedOutfits.forEach((name, i) => {
        const chip = el("span", {
          textContent: name + "  \u2715",
          title: "Click to remove",
          style:
            "background:#2a2a2a; border:1px solid #555; border-radius:10px; " +
            "padding:2px 8px; cursor:pointer; font-size:10px;",
        });
        chip.onclick = () => {
          selectedOutfits.splice(i, 1);
          renderChips();
          syncHiddenWidget();
        };
        chipRow.appendChild(chip);
      });
    }
    renderChips();

    const addSelect = el("select", {
      style: "flex:1; background:#222; color:#ddd; border:1px solid #444; font-size:10px;",
    });
    outfitList.forEach((name) => addSelect.appendChild(el("option", { value: name, textContent: name })));
    const addBtn = el("button", { textContent: "+ Add Outfit", style: "cursor:pointer; font-size:10px;" });
    addBtn.onclick = () => {
      const val = addSelect.value;
      if (val && !selectedOutfits.includes(val)) {
        selectedOutfits.push(val);
        renderChips();
        syncHiddenWidget();
      }
    };
    const addRow = el("div", { style: "display:flex; gap:4px; margin-bottom:6px;" }, [addSelect, addBtn]);

    // --- preview table ---
    const summaryLine = el("div", { style: "margin:4px 0; color:#9cf; font-size:10px;" });
    const tableWrap = el("div", { style: "max-height:220px; overflow:auto; border:1px solid #333;" });
    const prevBtn = el("button", { textContent: "\u2039 Prev", style: "font-size:10px; cursor:pointer;" });
    const nextBtn = el("button", { textContent: "Next \u203a", style: "font-size:10px; cursor:pointer;" });
    const pageLabel = el("span", { textContent: "", style: "font-size:10px;" });
    const pagerRow = el(
      "div",
      { style: "display:flex; justify-content:space-between; align-items:center; margin-top:4px;" },
      [prevBtn, pageLabel, nextBtn]
    );

    function renderTable() {
      tableWrap.innerHTML = "";
      const start = page * PAGE_SIZE;
      const rows = previewShots.slice(start, start + PAGE_SIZE);
      const table = el("table", { style: "width:100%; border-collapse:collapse; font-size:10px;" });
      const headerRow = el("tr", {});
      ["#", "intent", "zone", "pose", "prompt"].forEach((h) =>
        headerRow.appendChild(
          el("th", {
            textContent: h,
            style: "text-align:left; border-bottom:1px solid #444; padding:2px; color:#aaa;",
          })
        )
      );
      table.appendChild(headerRow);
      rows.forEach((r) => {
        const tr = el("tr", {});
        const cellStyle = "padding:2px; border-bottom:1px solid #2a2a2a; color:#ccc;";
        tr.appendChild(el("td", { textContent: r.index, style: cellStyle }));
        tr.appendChild(el("td", { textContent: r.shot_intent, style: cellStyle }));
        tr.appendChild(el("td", { textContent: r.zone_name, style: cellStyle }));
        tr.appendChild(el("td", { textContent: r.pose_id, style: cellStyle }));
        tr.appendChild(
          el("td", {
            textContent: r.prompt.length > 70 ? r.prompt.slice(0, 70) + "\u2026" : r.prompt,
            title: r.prompt,
            style: cellStyle,
          })
        );
        table.appendChild(tr);
      });
      tableWrap.appendChild(table);
      const totalPages = Math.max(1, Math.ceil(previewShots.length / PAGE_SIZE));
      pageLabel.textContent = `page ${previewShots.length ? page + 1 : 0}/${totalPages}`;
      prevBtn.disabled = page <= 0;
      nextBtn.disabled = page >= totalPages - 1;
    }
    renderTable();

    prevBtn.onclick = () => {
      if (page > 0) {
        page--;
        renderTable();
      }
    };
    nextBtn.onclick = () => {
      const totalPages = Math.max(1, Math.ceil(previewShots.length / PAGE_SIZE));
      if (page < totalPages - 1) {
        page++;
        renderTable();
      }
    };

    const genBtn = el("button", {
      textContent: "\u25B6 Generate Preview",
      style:
        "width:100%; margin:4px 0; cursor:pointer; background:#2b7a4b; color:#fff; " +
        "border:none; padding:5px; font-size:11px; border-radius:3px;",
    });
    genBtn.onclick = async () => {
      if (!selectedOutfits.length) {
        summaryLine.textContent = "Add at least one outfit first.";
        return;
      }
      genBtn.textContent = "Generating\u2026";
      genBtn.disabled = true;
      try {
        const res = await fetch("/asb_fashion/preview_plan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model_name: modelWidget?.value,
            location_name: locationWidget?.value,
            outfit_names: selectedOutfits,
            shots_per_look: shotsWidget?.value,
            coverage_density: densityWidget?.value,
            include_detail_shots: detailWidget?.value,
            seed: seedWidget?.value,
          }),
        });
        const data = await res.json();
        if (data.error) {
          summaryLine.textContent = "Error: " + data.error;
          previewShots = [];
        } else {
          previewShots = data.shots || [];
          summaryLine.textContent = data.plan_summary || "";
          page = 0;
        }
      } catch (err) {
        summaryLine.textContent = "Request failed: " + err;
      }
      renderTable();
      genBtn.textContent = "\u25B6 Generate Preview";
      genBtn.disabled = false;
    };

    const copyBtn = el("button", {
      textContent: "Copy Plan JSON",
      style: "width:100%; margin-top:2px; cursor:pointer; font-size:10px;",
    });
    copyBtn.onclick = async () => {
      try {
        await navigator.clipboard.writeText(JSON.stringify(previewShots, null, 2));
        copyBtn.textContent = "Copied!";
        setTimeout(() => (copyBtn.textContent = "Copy Plan JSON"), 1200);
      } catch (err) {
        console.warn("ASB Plan Editor: clipboard write failed", err);
      }
    };

    const container = el("div", { style: "font-family: sans-serif; padding: 4px; width: 100%;" }, [
      addRow,
      chipRow,
      genBtn,
      summaryLine,
      tableWrap,
      pagerRow,
      copyBtn,
    ]);

    if (typeof node.addDOMWidget === "function") {
      node.addDOMWidget("asb_plan_editor_panel", "div", container, { serialize: false });
    } else {
      console.warn(
        "ASB Plan Editor: this ComfyUI version doesn't support addDOMWidget — " +
          "the preview panel can't render, but the node's regular widgets still work."
      );
    }
    node.setDirtyCanvas(true, true);
  },
});
