import { app } from "../../scripts/app.js";

const PAGE_SIZE = 10;
const DEFAULT_STYLE = "editorial fashion photography, clean composition, sharp focus, natural color grading";
const DEFAULT_NEGATIVE = "blurry, deformed, extra limbs, watermark, low quality, plastic skin, distorted fabric";

function el(tag, props = {}, children = []) {
  const e = document.createElement(tag);
  Object.assign(e, props);
  for (const c of children) e.appendChild(c);
  return e;
}

async function getJSON(url, opts) {
  const res = await fetch(url, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `request failed (${res.status})`);
  return data;
}

function widgetByName(node, name) {
  return node.widgets?.find((w) => w.name === name);
}

// Removes a widget's on-canvas footprint while keeping it fully functional
// and serializable -- tries every mechanism different ComfyUI/litegraph
// versions use to skip drawing/layout for a widget, since which one applies
// isn't knowable without the exact frontend version installed.
function hideWidget(widget) {
  if (!widget || widget._asbHidden) return;
  widget._asbHidden = true;
  widget.hidden = true;
  widget.computeSize = () => [0, -4];
  widget.draw = () => {};
  for (const prop of ["inputEl", "element", "textEl", "domElement"]) {
    if (widget[prop] && widget[prop].style) widget[prop].style.display = "none";
  }
}

function setWidgetValue(widget, value) {
  if (!widget) return;
  widget.value = value;
  if (widget.options && Array.isArray(widget.options.values) && !widget.options.values.includes(value)) {
    return; // stale value (e.g. from a loaded file) -- leave current selection alone
  }
}

app.registerExtension({
  name: "ASBFashion.PlanEditor",

  async nodeCreated(node) {
    if (node.comfyClass !== "ASB_PlanEditor") return;

    const w = {
      title: widgetByName(node, "title"),
      model: widgetByName(node, "model_name"),
      location: widgetByName(node, "location_name"),
      outfitNames: widgetByName(node, "outfit_names"),
      camera: widgetByName(node, "camera"),
      quality: widgetByName(node, "quality"),
      shots: widgetByName(node, "shots_per_look"),
      density: widgetByName(node, "coverage_density"),
      includeDetail: widgetByName(node, "include_detail_shots"),
      seed: widgetByName(node, "seed"),
      manualShotsJson: widgetByName(node, "manual_shots_json"),
      overridesJson: widgetByName(node, "shot_overrides_json"),
    };
    if (!w.outfitNames) return; // not the node we think it is

    hideWidget(w.manualShotsJson);
    hideWidget(w.overridesJson);

    let panelStyle = DEFAULT_STYLE;
    let selectedOutfits = w.outfitNames.value
      ? w.outfitNames.value.split(",").map((s) => s.trim()).filter(Boolean)
      : [];
    let manualShots = [];
    try {
      const parsed = JSON.parse(w.manualShotsJson?.value || "[]");
      if (Array.isArray(parsed)) manualShots = parsed;
    } catch (e) { /* start empty */ }
    let overrides = {};
    try {
      const parsed = JSON.parse(w.overridesJson?.value || "{}");
      if (parsed && typeof parsed === "object") overrides = parsed;
    } catch (e) { /* start empty */ }

    let previewShots = [];
    let locationZones = []; // {id,name} for the currently selected location
    let allPatterns = [];   // {id,name,shot_intent}
    let allPoses = [];      // {id,mood}
    let totalLocationsCount = 0;
    let page = 0;
    let outfitList = [];
    let expanded = true;
    let serverOpen = false;
    let outOpen = false;

    function syncOutfitWidget() {
      if (w.outfitNames) w.outfitNames.value = selectedOutfits.join(",");
    }
    function syncManualShotsWidget() {
      if (w.manualShotsJson) w.manualShotsJson.value = JSON.stringify(manualShots);
    }
    function syncOverridesWidget() {
      if (w.overridesJson) w.overridesJson.value = JSON.stringify(overrides);
    }

    // ---------------------------------------------------------------
    // shell / status / summary
    // ---------------------------------------------------------------
    const statusLine = el("div", { style: "font-size:10px; min-height:14px; margin:2px 0; color:#9cf;" });
    let flashTimer = null;
    function flash(msg, isErr) {
      statusLine.textContent = msg;
      statusLine.style.color = isErr ? "#f77" : "#9cf";
      if (flashTimer) clearTimeout(flashTimer);
      flashTimer = setTimeout(() => { statusLine.textContent = ""; }, 4000);
    }

    const countBadge = el("span", { style: "font-size:10px; color:#888;" });
    const toggleBtn = el("button", {
      textContent: "\u25BE Plan editor",
      style: "cursor:pointer; background:none; border:none; color:#ddd; font-size:11px; font-weight:bold;",
    });
    const headRow = el("div", { style: "display:flex; align-items:center; gap:6px; margin-bottom:2px;" }, [
      toggleBtn, el("span", { style: "flex:1" }), countBadge,
    ]);

    // Two summary lines, mirroring the original's blue headline + gray
    // breakdown row -- computed from the last preview run, not a bare count.
    const summaryLine1 = el("div", { style: "font-size:10px; color:#5b9dd9; margin-bottom:1px;" });
    const summaryLine2 = el("div", { style: "font-size:9px; color:#888; margin-bottom:4px;" });

    function allRows() {
      return previewShots.concat(
        manualShots.map((m, i) => ({ ...m, index: previewShots.length + i, _manual: true }))
      );
    }

    function updateSummary() {
      const rows = allRows();
      if (!rows.length) {
        summaryLine1.textContent = "";
        summaryLine2.textContent = "";
        countBadge.textContent = "0 shots";
        return;
      }
      const zonesUsed = new Set(rows.map((r) => r.zone_name)).size;
      const posesUsed = new Set(rows.map((r) => r.pose_id)).size;
      summaryLine1.textContent =
        `${rows.length} shots \u00b7 ${modelSelect.value} \u00b7 ${locationSelect.value} \u00b7 ` +
        `${selectedOutfits.join(", ") || "(no outfit)"} \u00b7 ${cameraSelect.value} \u00b7 ` +
        `${qualitySelect.value} \u00b7 seed ${w.seed?.value ?? 0} \u00b7 ${zonesUsed} zones \u00b7 ${posesUsed} poses`;

      const intentCounts = {};
      rows.forEach((r) => { intentCounts[r.shot_intent] = (intentCounts[r.shot_intent] || 0) + 1; });
      const breakdown = Object.entries(intentCounts).map(([k, v]) => `${k}:${v}`).join(" ");
      summaryLine2.textContent = `${totalLocationsCount} location(s) total \u00b7 ${breakdown}`;
      countBadge.textContent = `${rows.length} shot${rows.length === 1 ? "" : "s"}`;
    }

    const body = el("div", { style: "display:flex; flex-direction:column; gap:4px; width:100%; box-sizing:border-box; min-width:0;" });

    // ---------------------------------------------------------------
    // field grid: 3 columns, matching the original's density
    //   Row 1: Title | Seed | Camera
    //   Row 2: Model | Location | Quality
    //   Row 3: Style (full width)
    // ---------------------------------------------------------------
    function gridField(label, inputEl) {
      return el("div", { style: "display:flex; flex-direction:column; gap:1px; min-width:0;" }, [
        el("label", { textContent: label, style: "font-size:9px; color:#999; text-transform:uppercase;" }),
        inputEl,
      ]);
    }

    const smallInputStyle = "background:#222; color:#ddd; border:1px solid #444; font-size:10px; padding:2px 4px; width:100%; box-sizing:border-box;";

    const titleInput = el("input", { type: "text", value: w.title?.value ?? "", style: smallInputStyle });
    titleInput.oninput = () => { if (w.title) w.title.value = titleInput.value; };

    const seedInput = el("input", { type: "number", value: w.seed?.value ?? 0, style: smallInputStyle });
    seedInput.onchange = () => { if (w.seed) w.seed.value = parseInt(seedInput.value, 10) || 0; };

    const cameraSelect = el("select", { style: smallInputStyle });
    function fillCameraSelect() {
      const opts = (w.camera?.options?.values || ["(none)"]);
      cameraSelect.innerHTML = "";
      opts.forEach((id) => cameraSelect.appendChild(el("option", { value: id, textContent: id })));
      cameraSelect.value = w.camera?.value ?? opts[0];
    }
    fillCameraSelect();
    cameraSelect.onchange = () => { if (w.camera) w.camera.value = cameraSelect.value; updateSummary(); };

    const modelSelect = el("select", { style: smallInputStyle });
    function fillModelSelect() {
      const opts = w.model?.options?.values || [];
      modelSelect.innerHTML = "";
      opts.forEach((id) => modelSelect.appendChild(el("option", { value: id, textContent: id })));
      modelSelect.value = w.model?.value ?? opts[0];
    }
    fillModelSelect();
    modelSelect.onchange = () => { if (w.model) w.model.value = modelSelect.value; updateSummary(); };

    const locationSelect = el("select", { style: smallInputStyle });
    function fillLocationSelect() {
      const opts = w.location?.options?.values || [];
      locationSelect.innerHTML = "";
      opts.forEach((id) => locationSelect.appendChild(el("option", { value: id, textContent: id })));
      locationSelect.value = w.location?.value ?? opts[0];
    }
    fillLocationSelect();
    locationSelect.onchange = async () => {
      if (w.location) w.location.value = locationSelect.value;
      await refreshLocationZones();
      updateSummary();
    };

    const styleInput = el("input", { type: "text", value: panelStyle, style: smallInputStyle });
    styleInput.oninput = () => { panelStyle = styleInput.value; };

    const qualitySelect = el("select", { style: smallInputStyle });
    function fillQualitySelect() {
      const opts = w.quality?.options?.values || ["standard"];
      qualitySelect.innerHTML = "";
      opts.forEach((id) => qualitySelect.appendChild(el("option", { value: id, textContent: id })));
      qualitySelect.value = w.quality?.value ?? opts[0];
    }
    fillQualitySelect();
    qualitySelect.onchange = () => { if (w.quality) w.quality.value = qualitySelect.value; updateSummary(); };

    const grid = el("div", {
      style: "display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr) minmax(0,1fr); gap:4px 8px; width:100%; box-sizing:border-box;",
    }, [
      gridField("Title", titleInput),
      gridField("Seed", seedInput),
      gridField("Camera (all shots)", cameraSelect),
      gridField("Model", modelSelect),
      gridField("Location", locationSelect),
      gridField("Quality", qualitySelect),
    ]);
    const styleRow = el("div", { style: "width:100%; box-sizing:border-box;" }, [gridField("Style", styleInput)]);

    // ---------------------------------------------------------------
    // outfit chip builder
    // ---------------------------------------------------------------
    const chipRow = el("div", { style: "display:flex; flex-wrap:wrap; gap:4px; min-height:18px;" });
    function renderChips() {
      chipRow.innerHTML = "";
      selectedOutfits.forEach((name, i) => {
        const chip = el("span", {
          textContent: name + "  \u2715",
          title: "Click to remove",
          style: "background:#2a2a2a; border:1px solid #555; border-radius:10px; padding:2px 8px; cursor:pointer; font-size:10px;",
        });
        chip.onclick = () => { selectedOutfits.splice(i, 1); renderChips(); syncOutfitWidget(); updateSummary(); };
        chipRow.appendChild(chip);
      });
    }
    renderChips();

    const outfitAddSelect = el("select", { style: smallInputStyle + "flex:1;" });
    function fillOutfitAddSelect() {
      outfitAddSelect.innerHTML = "";
      outfitList.forEach((name) => outfitAddSelect.appendChild(el("option", { value: name, textContent: name })));
    }
    const outfitAddBtn = el("button", { textContent: "+ Add Outfit", style: "cursor:pointer; font-size:10px;" });
    outfitAddBtn.onclick = () => {
      const val = outfitAddSelect.value;
      if (val && !selectedOutfits.includes(val)) {
        selectedOutfits.push(val);
        renderChips();
        syncOutfitWidget();
        updateSummary();
      }
    };
    const outfitRow = el("div", { style: "display:flex; gap:4px;" }, [outfitAddSelect, outfitAddBtn]);

    // ---------------------------------------------------------------
    // shared data fetchers (used by both "+ Shot" and per-shot card edits)
    // ---------------------------------------------------------------
    async function refreshLocationZones() {
      try {
        const zones = await getJSON(`/asb_fashion/data?type=zones&location=${encodeURIComponent(locationSelect.value)}`);
        locationZones = zones.items || [];
      } catch (e) { console.warn("ASB Plan Editor: zone fetch failed", e); locationZones = []; }
    }
    async function ensurePatternsAndPoses() {
      if (!allPatterns.length) {
        try { allPatterns = (await getJSON("/asb_fashion/data?type=patterns")).items || []; }
        catch (e) { console.warn("ASB Plan Editor: pattern fetch failed", e); }
      }
      if (!allPoses.length) {
        try { allPoses = (await getJSON("/asb_fashion/data?type=poses")).items || []; }
        catch (e) { console.warn("ASB Plan Editor: pose fetch failed", e); }
      }
    }
    function fillSelectOptions(selectEl, items, valueKey, labelFn, currentValue) {
      selectEl.innerHTML = "";
      items.forEach((item) => {
        const value = item[valueKey];
        selectEl.appendChild(el("option", { value, textContent: labelFn(item) }));
      });
      if (currentValue !== undefined) selectEl.value = currentValue;
    }

    // ---------------------------------------------------------------
    // "+ Shot" mini form (adds a brand-new shot, appended)
    // ---------------------------------------------------------------
    const shotOutfitSelect = el("select", { style: smallInputStyle });
    const shotZoneSelect = el("select", { style: smallInputStyle });
    const shotPatternSelect = el("select", { style: smallInputStyle });
    const shotPoseSelect = el("select", { style: smallInputStyle });
    const shotAddBtn = el("button", { textContent: "Add", style: "cursor:pointer; font-size:10px;" });
    const shotForm = el("div", {
      style: "display:none; gap:4px; padding:4px; border:1px dashed #444; margin-top:2px; flex-wrap:wrap; align-items:flex-end;",
    });

    async function fillShotFormOptions() {
      shotOutfitSelect.innerHTML = "";
      selectedOutfits.forEach((name) => shotOutfitSelect.appendChild(el("option", { value: name, textContent: name })));
      await refreshLocationZones();
      await ensurePatternsAndPoses();
      fillSelectOptions(shotZoneSelect, locationZones, "id", (z) => z.name);
      fillSelectOptions(shotPatternSelect, allPatterns, "id", (p) => `${p.name} (${p.shot_intent})`);
      fillSelectOptions(shotPoseSelect, allPoses, "id", (p) => p.id);
    }

    shotAddBtn.onclick = async () => {
      if (!shotOutfitSelect.value) { flash("Add an outfit chip first", true); return; }
      shotAddBtn.disabled = true;
      try {
        const resolved = await getJSON("/asb_fashion/resolve_shot", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model_name: modelSelect.value,
            location_name: locationSelect.value,
            outfit_name: shotOutfitSelect.value,
            zone_id: shotZoneSelect.value,
            pattern_id: shotPatternSelect.value,
            pose_id: shotPoseSelect.value,
            camera: cameraSelect.value,
            style: panelStyle,
            negative: DEFAULT_NEGATIVE,
            seed: (w.seed?.value ?? 0) + manualShots.length,
          }),
        });
        manualShots.push(resolved);
        syncManualShotsWidget();
        flash(`\u2713 shot added (${manualShots.length} manual)`);
        renderShotList();
      } catch (e) {
        flash("\u26A0 " + e.message, true);
      }
      shotAddBtn.disabled = false;
    };
    shotForm.append(
      gridField("Outfit", shotOutfitSelect),
      gridField("Zone", shotZoneSelect),
      gridField("Pattern", shotPatternSelect),
      gridField("Pose", shotPoseSelect),
      shotAddBtn
    );

    // ---------------------------------------------------------------
    // toolbar
    // ---------------------------------------------------------------
    const addShotBtn = el("button", { textContent: "\uFF0B Shot", style: "cursor:pointer; font-size:10px;" });
    addShotBtn.onclick = async () => {
      const showing = shotForm.style.display !== "none";
      if (showing) { shotForm.style.display = "none"; return; }
      if (!selectedOutfits.length) { flash("Add an outfit chip first", true); return; }
      await fillShotFormOptions();
      shotForm.style.display = "flex";
    };

    const autoBtn = el("button", {
      style: "cursor:pointer; font-size:10px; background:#2b7a4b; color:#fff; border:none; padding:3px 8px; border-radius:3px;",
    });
    function updateAutoBtnLabel() { autoBtn.textContent = `\uD83E\uDDE9 Auto ${w.shots?.value ?? "?"} shots`; }
    updateAutoBtnLabel();
    autoBtn.onclick = () => runPreview({ shots_per_look: w.shots?.value, coverage_density: w.density?.value });

    const sampleBtn = el("button", { textContent: "Sample", style: "cursor:pointer; font-size:10px;" });
    sampleBtn.onclick = () => runPreview({ shots_per_look: 12, coverage_density: "light" }, true);

    const loadFromPlanBtn = el("button", { textContent: "\u27F3 Load from plan", style: "cursor:pointer; font-size:10px;" });
    loadFromPlanBtn.onclick = () => {
      selectedOutfits = w.outfitNames?.value ? w.outfitNames.value.split(",").map((s) => s.trim()).filter(Boolean) : [];
      try {
        const parsed = JSON.parse(w.manualShotsJson?.value || "[]");
        manualShots = Array.isArray(parsed) ? parsed : [];
      } catch (e) { manualShots = []; }
      try {
        const parsed = JSON.parse(w.overridesJson?.value || "{}");
        overrides = parsed && typeof parsed === "object" ? parsed : {};
      } catch (e) { overrides = {}; }
      titleInput.value = w.title?.value ?? "";
      seedInput.value = w.seed?.value ?? 0;
      fillCameraSelect(); fillModelSelect(); fillLocationSelect(); fillQualitySelect();
      renderChips();
      renderShotList();
      flash(`\u2713 reloaded from node (${manualShots.length} manual, ${Object.keys(overrides).length} edited)`);
    };

    function currentConfig() {
      return {
        title: w.title?.value ?? "",
        model_name: modelSelect.value,
        location_name: locationSelect.value,
        outfit_names: selectedOutfits,
        camera: cameraSelect.value,
        quality: qualitySelect.value,
        style: panelStyle,
        shots_per_look: w.shots?.value,
        coverage_density: w.density?.value,
        include_detail_shots: w.includeDetail?.value,
        seed: w.seed?.value,
        manual_shots: manualShots,
        shot_overrides: overrides,
      };
    }

    function applyConfig(cfg) {
      if (!cfg) return;
      if (w.title) w.title.value = cfg.title ?? w.title.value;
      setWidgetValue(w.model, cfg.model_name);
      setWidgetValue(w.location, cfg.location_name);
      setWidgetValue(w.camera, cfg.camera);
      setWidgetValue(w.quality, cfg.quality);
      if (w.shots && cfg.shots_per_look != null) w.shots.value = cfg.shots_per_look;
      if (w.density && cfg.coverage_density) w.density.value = cfg.coverage_density;
      if (w.includeDetail && cfg.include_detail_shots != null) w.includeDetail.value = cfg.include_detail_shots;
      if (w.seed && cfg.seed != null) w.seed.value = cfg.seed;
      panelStyle = cfg.style || DEFAULT_STYLE;
      selectedOutfits = Array.isArray(cfg.outfit_names) ? cfg.outfit_names.slice() : [];
      manualShots = Array.isArray(cfg.manual_shots) ? cfg.manual_shots.slice() : [];
      overrides = cfg.shot_overrides && typeof cfg.shot_overrides === "object" ? { ...cfg.shot_overrides } : {};
      syncOutfitWidget();
      syncManualShotsWidget();
      syncOverridesWidget();

      titleInput.value = w.title?.value ?? "";
      seedInput.value = w.seed?.value ?? 0;
      fillCameraSelect(); fillModelSelect(); fillLocationSelect(); fillQualitySelect();
      styleInput.value = panelStyle;
      renderChips();
      updateAutoBtnLabel();
      previewShots = []; // config changed -- old preview no longer trustworthy
      renderShotList();
    }

    const saveFileBtn = el("button", { textContent: "\uD83D\uDCBE Save file", style: "cursor:pointer; font-size:10px;" });
    saveFileBtn.onclick = () => {
      const cfg = currentConfig();
      const blob = new Blob([JSON.stringify(cfg, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = el("a", { href: url, download: `asb_fashion_plan_${(cfg.title || "plan").replace(/\s+/g, "_")}.json` });
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 3000);
      flash("\u2713 saved to file");
    };

    let fileInput = null;
    const loadFileBtn = el("button", { textContent: "\uD83D\uDCC2 Load file", style: "cursor:pointer; font-size:10px;" });
    loadFileBtn.onclick = () => {
      if (!fileInput) {
        fileInput = el("input", { type: "file", accept: ".json", style: "display:none;" });
        document.body.appendChild(fileInput);
        fileInput.onchange = () => {
          const f = fileInput.files && fileInput.files[0];
          if (!f) return;
          const reader = new FileReader();
          reader.onload = () => {
            try {
              const cfg = JSON.parse(String(reader.result || "{}"));
              applyConfig(cfg);
              flash(`\u2713 loaded ${f.name}`);
            } catch (e) {
              flash("\u26A0 could not parse " + f.name, true);
            }
            fileInput.value = "";
          };
          reader.readAsText(f);
        };
      }
      fileInput.click();
    };

    const refreshDataBtn = el("button", { textContent: "\u21BB Refresh data", style: "cursor:pointer; font-size:10px;" });
    refreshDataBtn.onclick = async () => {
      flash("\u21BB reloading data\u2026");
      try {
        const [models, locations, outfits] = await Promise.all([
          getJSON("/asb_fashion/data?type=models"),
          getJSON("/asb_fashion/data?type=locations"),
          getJSON("/asb_fashion/data?type=outfits"),
        ]);
        if (w.model) w.model.options.values = models.items;
        if (w.location) w.location.options.values = locations.items;
        outfitList = outfits.items || [];
        totalLocationsCount = (locations.items || []).length;
        fillModelSelect(); fillLocationSelect(); fillOutfitAddSelect();
        flash(`\u2713 data refreshed \u2014 ${models.items.length} models \u00b7 ${locations.items.length} locations \u00b7 ${outfitList.length} outfits`);
      } catch (e) {
        flash("\u26A0 refresh failed: " + e.message, true);
      }
    };

    const clearBtn = el("button", { textContent: "\uD83E\uDDF9 Clear", style: "cursor:pointer; font-size:10px;" });
    clearBtn.onclick = () => {
      selectedOutfits = [];
      manualShots = [];
      overrides = {};
      previewShots = [];
      syncOutfitWidget();
      syncManualShotsWidget();
      syncOverridesWidget();
      renderChips();
      renderShotList();
      flash("\u2713 cleared");
    };

    const applyBtn = el("button", {
      textContent: "\u2713 Apply to node",
      style: "cursor:pointer; font-size:10px; font-weight:bold; background:#3b6fd6; color:#fff; border:none; padding:3px 10px; border-radius:3px;",
    });
    applyBtn.onclick = () => {
      syncOutfitWidget();
      syncManualShotsWidget();
      syncOverridesWidget();
      node.setDirtyCanvas(true, true);
      flash(`\u2713 applied (${selectedOutfits.length} outfit(s), ${manualShots.length} manual, ${Object.keys(overrides).length} edited) \u2014 queue the node to run`);
      if (!outOpen) toggleOutBtn.click();
    };

    const toolbar = el("div", { style: "display:flex; flex-wrap:wrap; gap:4px; align-items:center; width:100%; box-sizing:border-box;" }, [
      addShotBtn, autoBtn, sampleBtn, loadFromPlanBtn, saveFileBtn, loadFileBtn,
      el("button", { textContent: "\u2601\uFE0F Server", style: "cursor:pointer; font-size:10px;" }),
      refreshDataBtn, clearBtn,
      el("span", { style: "flex:1" }),
      applyBtn,
    ]);
    const serverToggleBtn = toolbar.children[6];

    // ---------------------------------------------------------------
    // server panel
    // ---------------------------------------------------------------
    const serverNameInput = el("input", { type: "text", placeholder: "plan name", style: smallInputStyle + "flex:1;" });
    const serverSaveBtn = el("button", { textContent: "\u2601\uFE0F Save to server", style: "cursor:pointer; font-size:10px;" });
    const serverRefreshBtn = el("button", { textContent: "\u27F3", style: "cursor:pointer; font-size:10px;" });
    const serverList = el("div", { style: "font-size:10px; margin-top:4px;" });
    const serverPanel = el("div", { style: "display:none; padding:4px; border:1px solid #333; margin-top:2px;" }, [
      el("div", { style: "display:flex; gap:4px;" }, [serverNameInput, serverSaveBtn, serverRefreshBtn]),
      serverList,
    ]);

    async function refreshServerList() {
      serverList.textContent = "loading\u2026";
      try {
        const data = await getJSON("/asb_fashion/plans");
        const names = data.items || [];
        if (!names.length) { serverList.textContent = "no saved plans yet"; return; }
        serverList.innerHTML = "";
        names.forEach((name) => {
          const row = el("div", { style: "display:flex; gap:4px; align-items:center; padding:1px 0;" }, [
            el("span", { textContent: name, style: "flex:1;" }),
            el("button", { textContent: "Load", style: "cursor:pointer; font-size:9px;" }),
            el("button", { textContent: "\uD83D\uDDD1", style: "cursor:pointer; font-size:9px;" }),
          ]);
          row.children[1].onclick = async () => {
            try {
              const got = await getJSON(`/asb_fashion/plans/${encodeURIComponent(name)}`);
              applyConfig(got.data);
              flash(`\u2713 loaded ${name}`);
            } catch (e) { flash("\u26A0 " + e.message, true); }
          };
          row.children[2].onclick = async () => {
            try {
              await getJSON(`/asb_fashion/plans/${encodeURIComponent(name)}`, { method: "DELETE" });
              flash(`\uD83D\uDDD1 deleted ${name}`);
              refreshServerList();
            } catch (e) { flash("\u26A0 " + e.message, true); }
          };
          serverList.appendChild(row);
        });
      } catch (e) {
        serverList.textContent = "\u26A0 server unavailable: " + e.message;
      }
    }
    serverToggleBtn.onclick = () => {
      serverOpen = !serverOpen;
      serverPanel.style.display = serverOpen ? "block" : "none";
      if (serverOpen) refreshServerList();
    };
    serverSaveBtn.onclick = async () => {
      const name = serverNameInput.value.trim() || (w.title?.value || "plan").replace(/\s+/g, "_");
      try {
        const res = await getJSON("/asb_fashion/plans", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, data: currentConfig() }),
        });
        flash(`\u2713 saved to server: ${res.saved}`);
        refreshServerList();
      } catch (e) { flash("\u26A0 " + e.message, true); }
    };
    serverRefreshBtn.onclick = refreshServerList;

    // ---------------------------------------------------------------
    // shot browser -- editable per-shot cards (replaces the old flat table)
    // ---------------------------------------------------------------
    const listWrap = el("div", { style: "max-height:320px; overflow:auto; border:1px solid #333; width:100%; box-sizing:border-box;" });
    const prevBtn = el("button", { textContent: "\u2039 Prev", style: "font-size:10px; cursor:pointer;" });
    const nextBtn = el("button", { textContent: "Next \u203a", style: "font-size:10px; cursor:pointer;" });
    const firstBtn = el("button", { textContent: "\u00ab", style: "font-size:10px; cursor:pointer;" });
    const lastBtn = el("button", { textContent: "\u00bb", style: "font-size:10px; cursor:pointer;" });
    const pageLabel = el("span", { textContent: "", style: "font-size:10px;" });
    const pageJumpInput = el("input", { type: "number", style: smallInputStyle + "width:44px;" });
    const pagerRow = el("div", { style: "display:flex; justify-content:space-between; align-items:center; gap:4px; flex-wrap:wrap;" }, [
      firstBtn, prevBtn, pageLabel, nextBtn, lastBtn, pageJumpInput,
    ]);

    function totalPages() {
      return Math.max(1, Math.ceil(allRows().length / PAGE_SIZE));
    }

    async function editShotField(row, field, value) {
      // Re-resolve this exact shot with one field changed, then record it
      // as an override (auto shot) or update it in place (manual shot).
      const outfitName = row.outfit_name;
      const zoneId = field === "zone_id" ? value : row.zone_id;
      const patternId = field === "pattern_id" ? value : row.pattern_id;
      const poseId = field === "pose_id" ? value : row.pose_id;
      try {
        const resolved = await getJSON("/asb_fashion/resolve_shot", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model_name: modelSelect.value,
            location_name: locationSelect.value,
            outfit_name: findOutfitFilenameByDisplayName(outfitName) || selectedOutfits[0],
            zone_id: zoneId,
            pattern_id: patternId,
            pose_id: poseId,
            camera: cameraSelect.value,
            style: panelStyle,
            negative: DEFAULT_NEGATIVE,
            seed: row.seed,
          }),
        });
        if (row._manual) {
          const manualIdx = row.index - previewShots.length;
          manualShots[manualIdx] = resolved;
          syncManualShotsWidget();
        } else {
          overrides[String(row.index)] = { ...resolved, zone_id: zoneId, pattern_id: patternId };
          syncOverridesWidget();
        }
        flash(`\u2713 shot ${row.index} updated`);
        renderShotList();
      } catch (e) {
        flash("\u26A0 " + e.message, true);
      }
    }

    // outfit filenames vs display names can differ -- resolve_shot needs the
    // filename (id used in data/outfits/*.json), the card shows the display name
    function findOutfitFilenameByDisplayName(displayName) {
      // selectedOutfits already holds filenames; if a filename matches this
      // shot's outfit_name loosely, prefer the first selected outfit as a
      // reasonable default since a card's exact source outfit filename isn't
      // returned by preview_plan (only its display name is).
      return selectedOutfits.find((n) => n === displayName) || null;
    }

    function removeAutoShot(index) {
      overrides[String(index)] = { removed: true };
      syncOverridesWidget();
      renderShotList();
      flash(`\u2713 shot ${index} marked removed \u2014 will be excluded on next node run`);
    }
    function removeManualShot(index) {
      const manualIdx = index - previewShots.length;
      manualShots.splice(manualIdx, 1);
      syncManualShotsWidget();
      renderShotList();
    }
    function moveManualShot(index, dir) {
      const manualIdx = index - previewShots.length;
      const swapWith = manualIdx + dir;
      if (swapWith < 0 || swapWith >= manualShots.length) return;
      [manualShots[manualIdx], manualShots[swapWith]] = [manualShots[swapWith], manualShots[manualIdx]];
      syncManualShotsWidget();
      renderShotList();
    }

    function shotCard(row) {
      const isRemoved = !row._manual && overrides[String(row.index)]?.removed;
      const isEdited = !row._manual && overrides[String(row.index)] && !overrides[String(row.index)].removed;
      const tagText = row._manual ? "manual" : isEdited ? "edited" : isRemoved ? "removed" : "auto";
      const card = el("div", {
        style: `border:1px solid #333; border-radius:3px; padding:6px; margin-bottom:4px; ` +
          `background:${row._manual ? "#1d2a1d" : isEdited ? "#2a2a1d" : isRemoved ? "#2a1d1d" : "#1a1a1a"}; ` +
          `${isRemoved ? "opacity:0.5;" : ""}`,
      });

      const badge = el("span", {
        textContent: `${row.index}`,
        style: "background:#3b6fd6; color:#fff; border-radius:8px; padding:1px 7px; font-size:9px; margin-right:6px;",
      });
      const tag = el("span", { textContent: tagText, style: "font-size:9px; color:#888; margin-right:8px;" });
      const controls = el("span", { style: "float:right; display:flex; gap:4px;" });
      if (row._manual) {
        const upBtn = el("button", { textContent: "\u2191", style: "font-size:9px; cursor:pointer;" });
        const downBtn = el("button", { textContent: "\u2193", style: "font-size:9px; cursor:pointer;" });
        const rmBtn = el("button", { textContent: "\u2715", style: "font-size:9px; cursor:pointer;" });
        upBtn.onclick = () => moveManualShot(row.index, -1);
        downBtn.onclick = () => moveManualShot(row.index, 1);
        rmBtn.onclick = () => removeManualShot(row.index);
        controls.append(upBtn, downBtn, rmBtn);
      } else if (isRemoved) {
        const undoBtn = el("button", { textContent: "\u21B6 restore", style: "font-size:9px; cursor:pointer;" });
        undoBtn.onclick = () => {
          delete overrides[String(row.index)];
          syncOverridesWidget();
          renderShotList();
        };
        controls.append(undoBtn);
      } else {
        const rmBtn = el("button", { textContent: "\u2715", style: "font-size:9px; cursor:pointer;" });
        rmBtn.onclick = () => removeAutoShot(row.index);
        controls.append(rmBtn);
      }
      const header = el("div", { style: "margin-bottom:4px;" }, [badge, tag, controls]);

      const zoneSel = el("select", { style: smallInputStyle });
      fillSelectOptions(zoneSel, locationZones.length ? locationZones : [{ id: row.zone_id, name: row.zone_name }], "id", (z) => z.name, row.zone_id);
      zoneSel.onchange = () => editShotField(row, "zone_id", zoneSel.value);

      const patternSel = el("select", { style: smallInputStyle });
      fillSelectOptions(patternSel, allPatterns.length ? allPatterns : [{ id: row.pattern_id, name: row.pattern_name, shot_intent: row.shot_intent }], "id", (p) => `${p.name} (${p.shot_intent})`, row.pattern_id);
      patternSel.onchange = () => editShotField(row, "pattern_id", patternSel.value);

      const poseSel = el("select", { style: smallInputStyle });
      fillSelectOptions(poseSel, allPoses.length ? allPoses : [{ id: row.pose_id }], "id", (p) => p.id, row.pose_id);
      poseSel.onchange = () => editShotField(row, "pose_id", poseSel.value);

      const fieldsRow = el("div", {
        style: "display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr) minmax(0,1fr); gap:4px; margin-bottom:4px;",
      }, [gridField("Zone", zoneSel), gridField("Pattern", patternSel), gridField("Pose", poseSel)]);

      const promptLine = el("div", {
        textContent: `prompt: ${row.prompt || ""}`,
        style: "font-size:9px; color:#aaa; line-height:1.3;",
      });

      card.append(header, fieldsRow, promptLine);
      return card;
    }

    function renderShotList() {
      updateSummary();
      const rows = allRows();
      listWrap.innerHTML = "";
      const start = page * PAGE_SIZE;
      rows.slice(start, start + PAGE_SIZE).forEach((row) => listWrap.appendChild(shotCard(row)));
      const tp = totalPages();
      pageLabel.textContent = `shots ${rows.length ? start + 1 : 0}-${Math.min(start + PAGE_SIZE, rows.length)}/${rows.length} \u00b7 page ${rows.length ? page + 1 : 0}/${tp}`;
      pageJumpInput.value = page + 1;
      prevBtn.disabled = page <= 0;
      nextBtn.disabled = page >= tp - 1;
      firstBtn.disabled = page <= 0;
      lastBtn.disabled = page >= tp - 1;
    }
    renderShotList();

    prevBtn.onclick = () => { if (page > 0) { page--; renderShotList(); } };
    nextBtn.onclick = () => { if (page < totalPages() - 1) { page++; renderShotList(); } };
    firstBtn.onclick = () => { page = 0; renderShotList(); };
    lastBtn.onclick = () => { page = totalPages() - 1; renderShotList(); };
    pageJumpInput.onchange = () => {
      const n = parseInt(pageJumpInput.value, 10);
      if (Number.isFinite(n)) {
        page = Math.min(Math.max(n - 1, 0), totalPages() - 1);
        renderShotList();
      }
    };

    async function runPreview(overridesArg, isSample) {
      if (!selectedOutfits.length) { flash("Add at least one outfit first.", true); return; }
      autoBtn.disabled = true;
      const original = autoBtn.textContent;
      autoBtn.textContent = "Generating\u2026";
      try {
        const data = await getJSON("/asb_fashion/preview_plan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model_name: modelSelect.value,
            location_name: locationSelect.value,
            outfit_names: selectedOutfits,
            shots_per_look: overridesArg.shots_per_look,
            coverage_density: overridesArg.coverage_density,
            include_detail_shots: w.includeDetail?.value,
            seed: w.seed?.value,
            camera: cameraSelect.value,
            style: panelStyle,
          }),
        });
        previewShots = data.shots || [];
        overrides = {}; // a fresh preview invalidates by-index overrides from the last one
        syncOverridesWidget();
        page = 0;
        await refreshLocationZones();
        await ensurePatternsAndPoses();
        flash(isSample ? `\u2713 sample: ${data.plan_summary}` : `\u2713 ${data.plan_summary}`);
      } catch (e) {
        flash("\u26A0 " + e.message, true);
        previewShots = [];
      }
      renderShotList();
      autoBtn.textContent = original;
      updateAutoBtnLabel();
      autoBtn.disabled = false;
    }

    // ---------------------------------------------------------------
    // output preview (raw JSON) + copy
    // ---------------------------------------------------------------
    const outBody = el("pre", {
      style: "display:none; max-height:150px; overflow:auto; font-size:9px; background:#111; padding:4px; margin:0;",
    });
    const toggleOutBtn = el("button", { textContent: "\u25B8 Output preview", style: "cursor:pointer; font-size:10px; background:none; border:none; color:#ddd;" });
    const copyBtn = el("button", { textContent: "\uD83D\uDCCB Copy plan_json", style: "cursor:pointer; font-size:10px;" });
    const outRow = el("div", { style: "display:flex; gap:6px; align-items:center;" }, [toggleOutBtn, copyBtn]);
    toggleOutBtn.onclick = () => {
      outOpen = !outOpen;
      outBody.style.display = outOpen ? "block" : "none";
      toggleOutBtn.textContent = outOpen ? "\u25BE Output preview" : "\u25B8 Output preview";
      if (outOpen) outBody.textContent = JSON.stringify(allRows(), null, 2);
    };
    copyBtn.onclick = async () => {
      try {
        await navigator.clipboard.writeText(JSON.stringify(allRows(), null, 2));
        flash("\u2713 plan_json copied");
      } catch (e) { flash("\u26A0 copy failed", true); }
    };

    // ---------------------------------------------------------------
    // assemble
    // ---------------------------------------------------------------
    body.append(
      summaryLine1, summaryLine2, statusLine, grid, styleRow, outfitRow, chipRow,
      shotForm, toolbar, serverPanel, listWrap, pagerRow, outRow, outBody
    );
    toggleBtn.onclick = () => {
      expanded = !expanded;
      body.style.display = expanded ? "flex" : "none";
      toggleBtn.textContent = expanded ? "\u25BE Plan editor" : "\u25B8 Plan editor";
      node.setDirtyCanvas(true, true);
    };

    const container = el("div", {
      style: "font-family: sans-serif; padding: 4px; width: 100%; max-width: 100%; " +
        "box-sizing: border-box; overflow-x: hidden; min-width: 0;",
    }, [headRow, body]);

    try {
      const outfits = await getJSON("/asb_fashion/data?type=outfits");
      outfitList = outfits.items || [];
      fillOutfitAddSelect();
    } catch (e) { console.warn("ASB Plan Editor: outfit list fetch failed", e); }
    try {
      const locations = await getJSON("/asb_fashion/data?type=locations");
      totalLocationsCount = (locations.items || []).length;
    } catch (e) { /* stat only, non-fatal */ }
    await refreshLocationZones();
    await ensurePatternsAndPoses();
    updateSummary();

    const MIN_WIDTH = 480;
    if (Array.isArray(node.size) && node.size[0] < MIN_WIDTH) {
      node.size[0] = MIN_WIDTH;
    }

    if (typeof node.addDOMWidget === "function") {
      node.addDOMWidget("asb_plan_editor_panel", "div", container, { serialize: false });
    } else {
      console.warn("ASB Plan Editor: this ComfyUI version doesn't support addDOMWidget.");
    }
    node.setDirtyCanvas(true, true);
  },
});
