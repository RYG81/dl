import { app } from "../../scripts/app.js";

const PAGE_SIZE = 10;
const DEFAULT_STYLE = "editorial fashion photography, clean composition, sharp focus, natural color grading";
const DEFAULT_NEGATIVE = "blurry, deformed, extra limbs, watermark, low quality, plastic skin, distorted fabric";

function el(tag, props = {}, children = []) {
  const e = document.createElement(tag);
  Object.assign(e, props);
  for (const c of children) e.appendChild(c);
  return e;
}

async function getJSON(url, opts) {
  const res = await fetch(url, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `request failed (${res.status})`);
  return data;
}

function widgetByName(node, name) {
  return node.widgets?.find((w) => w.name === name);
}

// Removes a widget's on-canvas footprint while keeping it fully functional
// and serializable (value still saves/loads with the workflow) — the
// standard technique custom ComfyUI nodes use to hide a widget that's
// managed entirely by a DOM panel instead of shown natively.
function hideWidget(widget) {
  if (!widget || widget._asbHidden) return;
  widget._asbHidden = true;
  widget.computeSize = () => [0, -4];
  widget.draw = () => {};
  if (widget.inputEl) widget.inputEl.style.display = "none";
}

function setWidgetValue(widget, value) {
  if (!widget) return;
  widget.value = value;
  if (widget.options && Array.isArray(widget.options.values) && !widget.options.values.includes(value)) {
    // value isn't one of this combo's current options (e.g. a stale name
    // from a loaded file) -- leave the widget's own value as-is rather
    // than forcing an invalid selection.
    return;
  }
}

app.registerExtension({
  name: "ASBFashion.PlanEditor",

  async nodeCreated(node) {
    if (node.comfyClass !== "ASB_PlanEditor") return;

    const w = {
      title: widgetByName(node, "title"),
      model: widgetByName(node, "model_name"),
      location: widgetByName(node, "location_name"),
      outfitNames: widgetByName(node, "outfit_names"),
      camera: widgetByName(node, "camera"),
      quality: widgetByName(node, "quality"),
      shots: widgetByName(node, "shots_per_look"),
      density: widgetByName(node, "coverage_density"),
      includeDetail: widgetByName(node, "include_detail_shots"),
      seed: widgetByName(node, "seed"),
      manualShotsJson: widgetByName(node, "manual_shots_json"),
    };
    if (!w.outfitNames) return; // not the node we think it is

    // The panel fully manages manual_shots_json (reading/writing it as
    // shots are added/removed via "+ Shot") — its native multiline
    // textarea would otherwise sit on the node showing a bare "[ ]"
    // wasting space, so hide it while keeping it functional/serializable.
    hideWidget(w.manualShotsJson);

    let panelStyle = DEFAULT_STYLE;
    let selectedOutfits = w.outfitNames.value
      ? w.outfitNames.value.split(",").map((s) => s.trim()).filter(Boolean)
      : [];
    let manualShots = [];
    try {
      const parsed = JSON.parse(w.manualShotsJson?.value || "[]");
      if (Array.isArray(parsed)) manualShots = parsed;
    } catch (e) { /* start empty */ }

    let previewShots = [];
    let page = 0;
    let outfitList = [];
    let expanded = true;
    let serverOpen = false;
    let outOpen = false;

    function syncOutfitWidget() {
      if (w.outfitNames) w.outfitNames.value = selectedOutfits.join(",");
    }
    function syncManualShotsWidget() {
      if (w.manualShotsJson) w.manualShotsJson.value = JSON.stringify(manualShots);
    }

    // ---------------------------------------------------------------
    // shell / status
    // ---------------------------------------------------------------
    const statusLine = el("div", { style: "font-size:10px; min-height:14px; margin:2px 0; color:#9cf;" });
    let flashTimer = null;
    function flash(msg, isErr) {
      statusLine.textContent = msg;
      statusLine.style.color = isErr ? "#f77" : "#9cf";
      if (flashTimer) clearTimeout(flashTimer);
      flashTimer = setTimeout(() => { statusLine.textContent = ""; }, 4000);
    }

    const countBadge = el("span", { style: "font-size:10px; color:#888;" });

    const toggleBtn = el("button", {
      textContent: "\u25BE Plan editor",
      style: "cursor:pointer; background:none; border:none; color:#ddd; font-size:11px; font-weight:bold;",
    });
    const headRow = el("div", { style: "display:flex; align-items:center; gap:6px; margin-bottom:4px;" }, [
      toggleBtn,
      el("span", { style: "flex:1" }),
      countBadge,
    ]);

    const body = el("div", { style: "display:flex; flex-direction:column; gap:4px; width:100%; box-sizing:border-box; min-width:0;" });

    // ---------------------------------------------------------------
    // field grid: Title / Seed / Camera / Model / Location / Style / Quality
    // ---------------------------------------------------------------
    function gridField(label, inputEl) {
      return el("div", { style: "display:flex; flex-direction:column; gap:1px; min-width:0;" }, [
        el("label", { textContent: label, style: "font-size:9px; color:#999; text-transform:uppercase;" }),
        inputEl,
      ]);
    }

    const smallInputStyle = "background:#222; color:#ddd; border:1px solid #444; font-size:10px; padding:2px 4px; width:100%; box-sizing:border-box;";

    const titleInput = el("input", { type: "text", value: w.title?.value ?? "", style: smallInputStyle });
    titleInput.oninput = () => { if (w.title) w.title.value = titleInput.value; };

    const seedInput = el("input", { type: "number", value: w.seed?.value ?? 0, style: smallInputStyle });
    seedInput.onchange = () => { if (w.seed) w.seed.value = parseInt(seedInput.value, 10) || 0; };

    const cameraSelect = el("select", { style: smallInputStyle });
    function fillCameraSelect() {
      const opts = (w.camera?.options?.values || ["(none)"]);
      cameraSelect.innerHTML = "";
      opts.forEach((id) => cameraSelect.appendChild(el("option", { value: id, textContent: id })));
      cameraSelect.value = w.camera?.value ?? opts[0];
    }
    fillCameraSelect();
    cameraSelect.onchange = () => { if (w.camera) w.camera.value = cameraSelect.value; };

    const modelSelect = el("select", { style: smallInputStyle });
    function fillModelSelect() {
      const opts = w.model?.options?.values || [];
      modelSelect.innerHTML = "";
      opts.forEach((id) => modelSelect.appendChild(el("option", { value: id, textContent: id })));
      modelSelect.value = w.model?.value ?? opts[0];
    }
    fillModelSelect();
    modelSelect.onchange = () => { if (w.model) w.model.value = modelSelect.value; };

    const locationSelect = el("select", { style: smallInputStyle });
    function fillLocationSelect() {
      const opts = w.location?.options?.values || [];
      locationSelect.innerHTML = "";
      opts.forEach((id) => locationSelect.appendChild(el("option", { value: id, textContent: id })));
      locationSelect.value = w.location?.value ?? opts[0];
    }
    fillLocationSelect();
    locationSelect.onchange = () => { if (w.location) w.location.value = locationSelect.value; };

    const styleInput = el("input", { type: "text", value: panelStyle, style: smallInputStyle });
    styleInput.oninput = () => { panelStyle = styleInput.value; };

    const qualitySelect = el("select", { style: smallInputStyle });
    function fillQualitySelect() {
      const opts = w.quality?.options?.values || ["standard"];
      qualitySelect.innerHTML = "";
      opts.forEach((id) => qualitySelect.appendChild(el("option", { value: id, textContent: id })));
      qualitySelect.value = w.quality?.value ?? opts[0];
    }
    fillQualitySelect();
    qualitySelect.onchange = () => { if (w.quality) w.quality.value = qualitySelect.value; };

    const grid = el("div", {
      style: "display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr); gap:4px 8px; width:100%; box-sizing:border-box;",
    }, [
      gridField("Title", titleInput),
      gridField("Seed", seedInput),
      gridField("Camera (all shots)", cameraSelect),
      gridField("Model", modelSelect),
      gridField("Location", locationSelect),
      gridField("Style", styleInput),
      gridField("Quality", qualitySelect),
    ]);

    // ---------------------------------------------------------------
    // outfit chip builder
    // ---------------------------------------------------------------
    const chipRow = el("div", { style: "display:flex; flex-wrap:wrap; gap:4px; min-height:18px;" });
    function renderChips() {
      chipRow.innerHTML = "";
      selectedOutfits.forEach((name, i) => {
        const chip = el("span", {
          textContent: name + "  \u2715",
          title: "Click to remove",
          style: "background:#2a2a2a; border:1px solid #555; border-radius:10px; padding:2px 8px; cursor:pointer; font-size:10px;",
        });
        chip.onclick = () => { selectedOutfits.splice(i, 1); renderChips(); syncOutfitWidget(); };
        chipRow.appendChild(chip);
      });
    }
    renderChips();

    const outfitAddSelect = el("select", { style: smallInputStyle + "flex:1;" });
    function fillOutfitAddSelect() {
      outfitAddSelect.innerHTML = "";
      outfitList.forEach((name) => outfitAddSelect.appendChild(el("option", { value: name, textContent: name })));
    }
    const outfitAddBtn = el("button", { textContent: "+ Add Outfit", style: "cursor:pointer; font-size:10px;" });
    outfitAddBtn.onclick = () => {
      const val = outfitAddSelect.value;
      if (val && !selectedOutfits.includes(val)) {
        selectedOutfits.push(val);
        renderChips();
        syncOutfitWidget();
      }
    };
    const outfitRow = el("div", { style: "display:flex; gap:4px;" }, [outfitAddSelect, outfitAddBtn]);

    // ---------------------------------------------------------------
    // "+ Shot" mini form
    // ---------------------------------------------------------------
    const shotOutfitSelect = el("select", { style: smallInputStyle });
    const shotZoneSelect = el("select", { style: smallInputStyle });
    const shotPatternSelect = el("select", { style: smallInputStyle });
    const shotPoseSelect = el("select", { style: smallInputStyle });
    const shotAddBtn = el("button", { textContent: "Add", style: "cursor:pointer; font-size:10px;" });
    const shotForm = el("div", {
      style: "display:none; gap:4px; padding:4px; border:1px dashed #444; margin-top:2px; flex-wrap:wrap; align-items:flex-end;",
    });

    async function fillShotFormOptions() {
      shotOutfitSelect.innerHTML = "";
      selectedOutfits.forEach((name) => shotOutfitSelect.appendChild(el("option", { value: name, textContent: name })));

      try {
        const zones = await getJSON(`/asb_fashion/data?type=zones&location=${encodeURIComponent(locationSelect.value)}`);
        shotZoneSelect.innerHTML = "";
        (zones.items || []).forEach((z) => shotZoneSelect.appendChild(el("option", { value: z.id, textContent: z.name })));
      } catch (e) { console.warn("ASB Plan Editor: zone fetch failed", e); }

      try {
        const patterns = await getJSON("/asb_fashion/data?type=patterns");
        shotPatternSelect.innerHTML = "";
        (patterns.items || []).forEach((p) =>
          shotPatternSelect.appendChild(el("option", { value: p.id, textContent: `${p.name} (${p.shot_intent})` }))
        );
      } catch (e) { console.warn("ASB Plan Editor: pattern fetch failed", e); }

      try {
        const poses = await getJSON("/asb_fashion/data?type=poses");
        shotPoseSelect.innerHTML = "";
        (poses.items || []).forEach((p) => shotPoseSelect.appendChild(el("option", { value: p.id, textContent: p.id })));
      } catch (e) { console.warn("ASB Plan Editor: pose fetch failed", e); }
    }

    shotAddBtn.onclick = async () => {
      if (!shotOutfitSelect.value) { flash("Add an outfit chip first", true); return; }
      shotAddBtn.disabled = true;
      try {
        const resolved = await getJSON("/asb_fashion/resolve_shot", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model_name: modelSelect.value,
            location_name: locationSelect.value,
            outfit_name: shotOutfitSelect.value,
            zone_id: shotZoneSelect.value,
            pattern_id: shotPatternSelect.value,
            pose_id: shotPoseSelect.value,
            camera: cameraSelect.value,
            style: panelStyle,
            negative: DEFAULT_NEGATIVE,
            seed: (w.seed?.value ?? 0) + manualShots.length,
          }),
        });
        manualShots.push(resolved);
        syncManualShotsWidget();
        flash(`\u2713 shot added (${manualShots.length} manual)`);
        renderTable();
      } catch (e) {
        flash("\u26A0 " + e.message, true);
      }
      shotAddBtn.disabled = false;
    };
    shotForm.append(
      gridField("Outfit", shotOutfitSelect),
      gridField("Zone", shotZoneSelect),
      gridField("Pattern", shotPatternSelect),
      gridField("Pose", shotPoseSelect),
      shotAddBtn
    );

    // ---------------------------------------------------------------
    // toolbar
    // ---------------------------------------------------------------
    const addShotBtn = el("button", { textContent: "\uFF0B Shot", style: "cursor:pointer; font-size:10px;" });
    addShotBtn.onclick = async () => {
      const showing = shotForm.style.display !== "none";
      if (showing) { shotForm.style.display = "none"; return; }
      if (!selectedOutfits.length) { flash("Add an outfit chip first", true); return; }
      await fillShotFormOptions();
      shotForm.style.display = "flex";
    };

    const autoBtn = el("button", {
      style: "cursor:pointer; font-size:10px; background:#2b7a4b; color:#fff; border:none; padding:3px 8px; border-radius:3px;",
    });
    function updateAutoBtnLabel() { autoBtn.textContent = `\uD83E\uDDE9 Auto ${w.shots?.value ?? "?"} shots`; }
    updateAutoBtnLabel();
    autoBtn.onclick = () => runPreview({
      shots_per_look: w.shots?.value, coverage_density: w.density?.value,
    });

    const sampleBtn = el("button", { textContent: "Sample", style: "cursor:pointer; font-size:10px;" });
    sampleBtn.onclick = () => runPreview({ shots_per_look: 12, coverage_density: "light" }, true);

    const loadFromPlanBtn = el("button", { textContent: "\u27F3 Load from plan", style: "cursor:pointer; font-size:10px;" });
    loadFromPlanBtn.onclick = () => {
      // Re-read current widget truth back into panel state (useful after
      // programmatic changes, e.g. a workflow load).
      selectedOutfits = w.outfitNames?.value ? w.outfitNames.value.split(",").map((s) => s.trim()).filter(Boolean) : [];
      try {
        const parsed = JSON.parse(w.manualShotsJson?.value || "[]");
        manualShots = Array.isArray(parsed) ? parsed : [];
      } catch (e) { manualShots = []; }
      titleInput.value = w.title?.value ?? "";
      seedInput.value = w.seed?.value ?? 0;
      fillCameraSelect(); fillModelSelect(); fillLocationSelect(); fillQualitySelect();
      renderChips();
      renderTable();
      flash(`\u2713 reloaded from node (${manualShots.length} manual shots)`);
    };

    function currentConfig() {
      return {
        title: w.title?.value ?? "",
        model_name: modelSelect.value,
        location_name: locationSelect.value,
        outfit_names: selectedOutfits,
        camera: cameraSelect.value,
        quality: qualitySelect.value,
        style: panelStyle,
        shots_per_look: w.shots?.value,
        coverage_density: w.density?.value,
        include_detail_shots: w.includeDetail?.value,
        seed: w.seed?.value,
        manual_shots: manualShots,
      };
    }

    function applyConfig(cfg) {
      if (!cfg) return;
      if (w.title) w.title.value = cfg.title ?? w.title.value;
      setWidgetValue(w.model, cfg.model_name);
      setWidgetValue(w.location, cfg.location_name);
      setWidgetValue(w.camera, cfg.camera);
      setWidgetValue(w.quality, cfg.quality);
      if (w.shots && cfg.shots_per_look != null) w.shots.value = cfg.shots_per_look;
      if (w.density && cfg.coverage_density) w.density.value = cfg.coverage_density;
      if (w.includeDetail && cfg.include_detail_shots != null) w.includeDetail.value = cfg.include_detail_shots;
      if (w.seed && cfg.seed != null) w.seed.value = cfg.seed;
      panelStyle = cfg.style || DEFAULT_STYLE;
      selectedOutfits = Array.isArray(cfg.outfit_names) ? cfg.outfit_names.slice() : [];
      manualShots = Array.isArray(cfg.manual_shots) ? cfg.manual_shots.slice() : [];
      syncOutfitWidget();
      syncManualShotsWidget();

      titleInput.value = w.title?.value ?? "";
      seedInput.value = w.seed?.value ?? 0;
      fillCameraSelect(); fillModelSelect(); fillLocationSelect(); fillQualitySelect();
      styleInput.value = panelStyle;
      renderChips();
      updateAutoBtnLabel();
      renderTable();
    }

    const saveFileBtn = el("button", { textContent: "\uD83D\uDCBE Save file", style: "cursor:pointer; font-size:10px;" });
    saveFileBtn.onclick = () => {
      const cfg = currentConfig();
      const blob = new Blob([JSON.stringify(cfg, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = el("a", { href: url, download: `asb_fashion_plan_${(cfg.title || "plan").replace(/\s+/g, "_")}.json` });
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 3000);
      flash("\u2713 saved to file");
    };

    let fileInput = null;
    const loadFileBtn = el("button", { textContent: "\uD83D\uDCC2 Load file", style: "cursor:pointer; font-size:10px;" });
    loadFileBtn.onclick = () => {
      if (!fileInput) {
        fileInput = el("input", { type: "file", accept: ".json", style: "display:none;" });
        document.body.appendChild(fileInput);
        fileInput.onchange = () => {
          const f = fileInput.files && fileInput.files[0];
          if (!f) return;
          const reader = new FileReader();
          reader.onload = () => {
            try {
              const cfg = JSON.parse(String(reader.result || "{}"));
              applyConfig(cfg);
              flash(`\u2713 loaded ${f.name}`);
            } catch (e) {
              flash("\u26A0 could not parse " + f.name, true);
            }
            fileInput.value = "";
          };
          reader.readAsText(f);
        };
      }
      fileInput.click();
    };

    const refreshDataBtn = el("button", { textContent: "\u21BB Refresh data", style: "cursor:pointer; font-size:10px;" });
    refreshDataBtn.onclick = async () => {
      flash("\u21BB reloading data\u2026");
      try {
        const [models, locations, outfits] = await Promise.all([
          getJSON("/asb_fashion/data?type=models"),
          getJSON("/asb_fashion/data?type=locations"),
          getJSON("/asb_fashion/data?type=outfits"),
        ]);
        if (w.model) w.model.options.values = models.items;
        if (w.location) w.location.options.values = locations.items;
        outfitList = outfits.items || [];
        fillModelSelect(); fillLocationSelect(); fillOutfitAddSelect();
        flash(`\u2713 data refreshed \u2014 ${models.items.length} models \u00b7 ${locations.items.length} locations \u00b7 ${outfitList.length} outfits`);
      } catch (e) {
        flash("\u26A0 refresh failed: " + e.message, true);
      }
    };

    const clearBtn = el("button", { textContent: "\uD83E\uDDF9 Clear", style: "cursor:pointer; font-size:10px;" });
    clearBtn.onclick = () => {
      selectedOutfits = [];
      manualShots = [];
      previewShots = [];
      syncOutfitWidget();
      syncManualShotsWidget();
      renderChips();
      renderTable();
      flash("\u2713 cleared");
    };

    const applyBtn = el("button", {
      textContent: "\u2713 Apply to node",
      style: "cursor:pointer; font-size:10px; font-weight:bold; background:#3b6fd6; color:#fff; border:none; padding:3px 10px; border-radius:3px;",
    });
    applyBtn.onclick = () => {
      syncOutfitWidget();
      syncManualShotsWidget();
      node.setDirtyCanvas(true, true);
      flash(`\u2713 applied (${selectedOutfits.length} outfit(s), ${manualShots.length} manual shot(s)) \u2014 queue the node to run`);
      if (!outOpen) toggleOutBtn.click();
    };

    const toolbar = el("div", { style: "display:flex; flex-wrap:wrap; gap:4px; align-items:center; width:100%; box-sizing:border-box;" }, [
      addShotBtn, autoBtn, sampleBtn, loadFromPlanBtn, saveFileBtn, loadFileBtn,
      el("button", { textContent: "\u2601\uFE0F Server", style: "cursor:pointer; font-size:10px;" }),
      refreshDataBtn, clearBtn,
      el("span", { style: "flex:1" }),
      applyBtn,
    ]);
    const serverToggleBtn = toolbar.children[6];

    // ---------------------------------------------------------------
    // server panel (save/list/load/delete named plans)
    // ---------------------------------------------------------------
    const serverNameInput = el("input", { type: "text", placeholder: "plan name", style: smallInputStyle + "flex:1;" });
    const serverSaveBtn = el("button", { textContent: "\u2601\uFE0F Save to server", style: "cursor:pointer; font-size:10px;" });
    const serverRefreshBtn = el("button", { textContent: "\u27F3", style: "cursor:pointer; font-size:10px;" });
    const serverList = el("div", { style: "font-size:10px; margin-top:4px;" });
    const serverPanel = el("div", { style: "display:none; padding:4px; border:1px solid #333; margin-top:2px;" }, [
      el("div", { style: "display:flex; gap:4px;" }, [serverNameInput, serverSaveBtn, serverRefreshBtn]),
      serverList,
    ]);

    async function refreshServerList() {
      serverList.textContent = "loading\u2026";
      try {
        const data = await getJSON("/asb_fashion/plans");
        const names = data.items || [];
        if (!names.length) { serverList.textContent = "no saved plans yet"; return; }
        serverList.innerHTML = "";
        names.forEach((name) => {
          const row = el("div", { style: "display:flex; gap:4px; align-items:center; padding:1px 0;" }, [
            el("span", { textContent: name, style: "flex:1;" }),
            el("button", { textContent: "Load", style: "cursor:pointer; font-size:9px;" }),
            el("button", { textContent: "\uD83D\uDDD1", style: "cursor:pointer; font-size:9px;" }),
          ]);
          row.children[1].onclick = async () => {
            try {
              const got = await getJSON(`/asb_fashion/plans/${encodeURIComponent(name)}`);
              applyConfig(got.data);
              flash(`\u2713 loaded ${name}`);
            } catch (e) { flash("\u26A0 " + e.message, true); }
          };
          row.children[2].onclick = async () => {
            try {
              await getJSON(`/asb_fashion/plans/${encodeURIComponent(name)}`, { method: "DELETE" });
              flash(`\uD83D\uDDD1 deleted ${name}`);
              refreshServerList();
            } catch (e) { flash("\u26A0 " + e.message, true); }
          };
          serverList.appendChild(row);
        });
      } catch (e) {
        serverList.textContent = "\u26A0 server unavailable: " + e.message;
      }
    }
    serverToggleBtn.onclick = () => {
      serverOpen = !serverOpen;
      serverPanel.style.display = serverOpen ? "block" : "none";
      if (serverOpen) refreshServerList();
    };
    serverSaveBtn.onclick = async () => {
      const name = serverNameInput.value.trim() || (w.title?.value || "plan").replace(/\s+/g, "_");
      try {
        const res = await getJSON("/asb_fashion/plans", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, data: currentConfig() }),
        });
        flash(`\u2713 saved to server: ${res.saved}`);
        refreshServerList();
      } catch (e) { flash("\u26A0 " + e.message, true); }
    };
    serverRefreshBtn.onclick = refreshServerList;

    // ---------------------------------------------------------------
    // shot browser table + pagination
    // ---------------------------------------------------------------
    const tableWrap = el("div", { style: "max-height:220px; overflow:auto; border:1px solid #333; width:100%; box-sizing:border-box;" });
    const prevBtn = el("button", { textContent: "\u2039 Prev", style: "font-size:10px; cursor:pointer;" });
    const nextBtn = el("button", { textContent: "Next \u203a", style: "font-size:10px; cursor:pointer;" });
    const pageLabel = el("span", { textContent: "", style: "font-size:10px;" });
    const pagerRow = el("div", { style: "display:flex; justify-content:space-between; align-items:center;" }, [prevBtn, pageLabel, nextBtn]);

    function allRows() {
      return previewShots.concat(
        manualShots.map((m, i) => ({ ...m, index: previewShots.length + i, _manual: true }))
      );
    }

    function renderTable() {
      const rows = allRows();
      countBadge.textContent = `${rows.length} shot${rows.length === 1 ? "" : "s"}`;
      tableWrap.innerHTML = "";
      const start = page * PAGE_SIZE;
      const pageRows = rows.slice(start, start + PAGE_SIZE);
      const table = el("table", { style: "width:100%; border-collapse:collapse; font-size:10px;" });
      const headerRow = el("tr", {});
      ["#", "intent", "zone", "pose", "prompt", ""].forEach((h) =>
        headerRow.appendChild(el("th", { textContent: h, style: "text-align:left; border-bottom:1px solid #444; padding:2px; color:#aaa;" }))
      );
      table.appendChild(headerRow);
      pageRows.forEach((r) => {
        const cellStyle = "padding:2px; border-bottom:1px solid #2a2a2a; color:#ccc;";
        const tr = el("tr", { style: r._manual ? "background:#1d2a1d;" : "" });
        tr.appendChild(el("td", { textContent: r.index, style: cellStyle }));
        tr.appendChild(el("td", { textContent: r.shot_intent + (r._manual ? " \u270E" : ""), style: cellStyle }));
        tr.appendChild(el("td", { textContent: r.zone_name, style: cellStyle }));
        tr.appendChild(el("td", { textContent: r.pose_id, style: cellStyle }));
        tr.appendChild(el("td", {
          textContent: r.prompt && r.prompt.length > 60 ? r.prompt.slice(0, 60) + "\u2026" : r.prompt,
          title: r.prompt, style: cellStyle,
        }));
        const removeCell = el("td", { style: cellStyle });
        if (r._manual) {
          const rmBtn = el("button", { textContent: "\u2715", style: "cursor:pointer; font-size:9px;" });
          rmBtn.onclick = () => {
            const manualIdx = r.index - previewShots.length;
            manualShots.splice(manualIdx, 1);
            syncManualShotsWidget();
            renderTable();
          };
          removeCell.appendChild(rmBtn);
        }
        tr.appendChild(removeCell);
        table.appendChild(tr);
      });
      tableWrap.appendChild(table);
      const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
      pageLabel.textContent = `shots ${rows.length ? start + 1 : 0}-${Math.min(start + PAGE_SIZE, rows.length)}/${rows.length} \u00b7 page ${rows.length ? page + 1 : 0}/${totalPages}`;
      prevBtn.disabled = page <= 0;
      nextBtn.disabled = page >= totalPages - 1;
    }
    renderTable();
    prevBtn.onclick = () => { if (page > 0) { page--; renderTable(); } };
    nextBtn.onclick = () => {
      const totalPages = Math.max(1, Math.ceil(allRows().length / PAGE_SIZE));
      if (page < totalPages - 1) { page++; renderTable(); }
    };

    async function runPreview(overrides, isSample) {
      if (!selectedOutfits.length) { flash("Add at least one outfit first.", true); return; }
      autoBtn.disabled = true;
      const original = autoBtn.textContent;
      autoBtn.textContent = "Generating\u2026";
      try {
        const data = await getJSON("/asb_fashion/preview_plan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model_name: modelSelect.value,
            location_name: locationSelect.value,
            outfit_names: selectedOutfits,
            shots_per_look: overrides.shots_per_look,
            coverage_density: overrides.coverage_density,
            include_detail_shots: w.includeDetail?.value,
            seed: w.seed?.value,
            camera: cameraSelect.value,
            style: panelStyle,
          }),
        });
        previewShots = data.shots || [];
        page = 0;
        flash(isSample ? `\u2713 sample: ${data.plan_summary}` : `\u2713 ${data.plan_summary}`);
      } catch (e) {
        flash("\u26A0 " + e.message, true);
        previewShots = [];
      }
      renderTable();
      autoBtn.textContent = isSample ? original : original;
      updateAutoBtnLabel();
      autoBtn.disabled = false;
    }

    // ---------------------------------------------------------------
    // output preview (raw JSON) + copy
    // ---------------------------------------------------------------
    const outBody = el("pre", {
      style: "display:none; max-height:150px; overflow:auto; font-size:9px; background:#111; padding:4px; margin:0;",
    });
    const toggleOutBtn = el("button", { textContent: "\u25B8 Output preview", style: "cursor:pointer; font-size:10px; background:none; border:none; color:#ddd;" });
    const copyBtn = el("button", { textContent: "\uD83D\uDCCB Copy plan_json", style: "cursor:pointer; font-size:10px;" });
    const outRow = el("div", { style: "display:flex; gap:6px; align-items:center;" }, [toggleOutBtn, copyBtn]);
    toggleOutBtn.onclick = () => {
      outOpen = !outOpen;
      outBody.style.display = outOpen ? "block" : "none";
      toggleOutBtn.textContent = outOpen ? "\u25BE Output preview" : "\u25B8 Output preview";
      if (outOpen) outBody.textContent = JSON.stringify(allRows(), null, 2);
    };
    copyBtn.onclick = async () => {
      try {
        await navigator.clipboard.writeText(JSON.stringify(allRows(), null, 2));
        flash("\u2713 plan_json copied");
      } catch (e) { flash("\u26A0 copy failed", true); }
    };

    // ---------------------------------------------------------------
    // assemble
    // ---------------------------------------------------------------
    body.append(statusLine, grid, outfitRow, chipRow, shotForm, toolbar, serverPanel, tableWrap, pagerRow, outRow, outBody);
    toggleBtn.onclick = () => {
      expanded = !expanded;
      body.style.display = expanded ? "flex" : "none";
      toggleBtn.textContent = expanded ? "\u25BE Plan editor" : "\u25B8 Plan editor";
      node.setDirtyCanvas(true, true);
    };

    const container = el("div", {
      style: "font-family: sans-serif; padding: 4px; width: 100%; max-width: 100%; " +
        "box-sizing: border-box; overflow-x: hidden; min-width: 0;",
    }, [headRow, body]);

    // fetch outfit list once for the "+ Add Outfit" select
    try {
      const outfits = await getJSON("/asb_fashion/data?type=outfits");
      outfitList = outfits.items || [];
      fillOutfitAddSelect();
    } catch (e) { console.warn("ASB Plan Editor: outfit list fetch failed", e); }

    // This panel's field grid + toolbar need real room (7-field grid, ~9
    // toolbar buttons) -- ComfyUI's default new-node width is too narrow
    // for it and the DOM widget content would otherwise overflow the
    // node's drawn box rather than wrap. Widen the node once on creation,
    // but only if the user hasn't already resized it wider than this.
    const MIN_WIDTH = 420;
    if (Array.isArray(node.size) && node.size[0] < MIN_WIDTH) {
      node.size[0] = MIN_WIDTH;
    }

    if (typeof node.addDOMWidget === "function") {
      node.addDOMWidget("asb_plan_editor_panel", "div", container, { serialize: false });
    } else {
      console.warn("ASB Plan Editor: this ComfyUI version doesn't support addDOMWidget.");
    }
    node.setDirtyCanvas(true, true);
  },
});
