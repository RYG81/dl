# Fashion Set Builder for ComfyUI (v1)

Data-driven node pack for generating full fashion photography coverage —
any model, any location, any wardrobe — as a deterministic, reproducible
shot plan.

## Install
1. Copy this folder into `ComfyUI/custom_nodes/`
2. Restart ComfyUI
3. Find nodes under **ArtisticSetBuilder/Fashion**

## Node graph (typical)
```
ASB Load Model ─────────────┐
ASB Load Location ──────────┤
ASB Load Outfit ──► ASB Add Outfit To Sequence ──► (chain more outfits) ──┐
                                                                            │
                                                    ASB Fashion Shoot Plan ─┤
                                                                            │
                                                    ASB Plan → Prompt ◄─────┘
                                                        │
                                          prompt / negative / seed → your sampler
                                                        │
                                                  ASB Manifest (optional log)
```

- **ASB Load Model / Location / Outfit** — pick from `data/models`,
  `data/locations`, `data/outfits` (dropdowns are populated from whatever
  JSON files exist in those folders — add your own, no code changes needed)
- **ASB Add Outfit To Sequence** — chain as many of these as looks in the
  shoot; wire `previous_sequence` from the last one to build up the list
- **ASB Fashion Shoot Plan** — the core engine. Expands model × location ×
  outfit sequence into a full shot list: one hero shot per look, a spread
  of coverage patterns (editorial, movement, candid, environmental...)
  cycled across the location's zones, and one detail shot per
  `detail_worthy` garment/accessory piece
- **ASB Plan → Prompt** — resolves one shot (by index, or auto-advancing
  with `use_internal_counter`) into final prompt/negative/seed/filename text
- **ASB Batch Index** — external counter if you'd rather drive the index
  yourself than use the internal counter
- **ASB Manifest** — appends each rendered shot to a CSV log
- **ASB Plan Editor (all-in-one)** — optional alternative to the loader +
  sequence chain above. Model/location dropdowns plus an embedded panel
  for building the outfit sequence and previewing the real shot plan
  before wiring outputs downstream. See "Plan Editor panel" below.

## Data layout
```
data/
  models/*.json        identity + styling, no anatomical fields
  locations/*.json      a location + its zones (spots within it)
  outfits/*.json         a full look + its individual pieces
  cameras.json            camera body/lens prompt phrases
  framing.json            shot-size prompt phrases
  coverage_patterns.json  the editorial shot-type vocabulary
  poses.json              pose bank tagged by mood
```

Add a new model/location/outfit by dropping a new JSON file in the matching
folder — it shows up in the dropdown next ComfyUI (re)loads the pack.

### Outfit piece schema
```json
{
  "item_id": "P1",
  "name": "camel wool coat",
  "type": "outerwear",
  "prompt": "structured camel wool oversized coat, sharp lapels",
  "detail_worthy": true
}
```
`detail_worthy: true` means the plan engine will reserve one close-up shot
for that piece. Set it `false` for basics that don't need their own beat
(plain tee, base trousers, etc).

## One photoset = one model + one outfit + one location, 100+ shots
`shots_per_look` supports up to 500. Zone/pattern/pose are drawn from
independent shuffle-bags (not cycled in lockstep) with a signature-dedupe
pass, so a single look at one location produces zero duplicate prompts —
verified at 50/100/150/200 shots on one model+outfit+location. The
dedupe key is `framing_id`, not `pattern_id`: several coverage patterns
resolve to the same framing phrase, and pattern *name* never reaches the
final prompt text, so two differently-named patterns with the same
framing_id are the same prompt and are deduped as such.

Detail shots now scale with volume too — budgeted at ~20% of the look's
shot count (or one per detail-worthy piece, whichever is larger), cycling
through pieces with independently drawn zone/pose per repeat so a second
close-up of the same garment reads as a different angle, not a copy.

## Live dropdown widgets
`web/asb_fashion_widgets.js` (auto-loaded via `WEB_DIRECTORY` in
`__init__.py`) refreshes the model/location/outfit dropdowns from disk:
- On node creation, it fetches the current list from `GET /asb_fashion/data?type=models|locations|outfits`
- A **🔄 Refresh List** button is added to each loader node for re-fetching mid-session
- The Python route lives in `__init__.py`, reads the same `data/` folders
  the nodes already use, and is import-guarded so the package still loads
  fine outside a running ComfyUI server (e.g. for local testing)

Net effect: drop a new JSON file into `data/models/`, `data/locations/`,
or `data/outfits/` and it shows up in the dropdown without restarting
ComfyUI — either immediately on the next node you add, or via the refresh
button on ones already on the canvas.

## Plan Editor panel
`ASB_PlanEditor` is a self-contained authoring node with an embedded
DOM panel (`web/asb_plan_editor.js`) that mirrors the original ASB pack's
field layout and toolbar, rebuilt against this pack's schema — no
undress-state machinery, no explicit-content fields:

**Field grid:** Title, Seed, Camera (all shots), Model, Location, Style,
Quality — Model/Location/Camera/Quality/Seed/Title are bound directly to
the node's real widgets (no separate shadow state to fall out of sync);
Style is panel-only and feeds preview/`+ Shot` calls.

**Outfit chips:** add/remove outfits; syncs the node's `outfit_names`
widget live.

**Toolbar:**
- **+ Shot** — opens a Zone/Pattern/Pose picker, resolves it through
  `POST /asb_fashion/resolve_shot` (the real resolver, not a JS mock),
  and appends the result as a manual shot. Manual shots are stored in
  the node's `manual_shots_json` widget and actually affect the node's
  output at execution time — `ASB_PlanToPrompt` short-circuits on a
  `resolved_prompt_override` key instead of doing normal lookups for
  these, so a hand-picked shot survives the real pipeline, not just the
  preview.
- **Auto N shots** — runs the full engine via `/asb_fashion/preview_plan`
  at the current `shots_per_look`.
- **Sample** — a quick 12-shot/light-density peek without changing your
  actual settings.
- **Load from plan** — re-reads the node's current widget values back
  into the panel (useful after a workflow load).
- **Save file / Load file** — downloads/uploads the full panel config
  (title, model, location, outfits, camera, quality, style, density,
  seed, manual shots) as a `.json` file via the browser.
- **Server** — save/list/load/delete named plans via
  `/asb_fashion/plans`, stored under `saved_plans/` in the pack
  directory.
- **Refresh data** — re-fetches model/location/outfit lists from disk.
- **Clear** — resets outfit chips and manual shots.
- **Apply to node** — finalizes the outfit/manual-shot widgets and opens
  the output preview.

**Shot browser:** paginated table (10/page) showing intent, zone, pose,
and prompt preview for both auto-generated and manual shots (manual rows
are tinted and removable). **Output preview** toggle shows the raw
`plan_json`; **Copy plan_json** copies it to the clipboard.

The node still has real `ASB_MODEL` / `ASB_LOCATION` / `ASB_OUTFIT_SEQ` /
`ASB_PLAN` outputs (plus `camera` and `quality_style_suffix` passthrough
outputs for wiring into `ASB_PlanToPrompt`), so it can feed the rest of
the graph directly — you don't need the separate loader/sequence chain
if you use this node instead. If `outfit_names` is empty when the graph
actually runs, it falls back to the first available outfit rather than
erroring.

**Tested:** all Python routes (`data` for every type including
`zones`/`patterns`/`poses`/`cameras`/`qualities`, `preview_plan`,
`resolve_shot`, and full `plans` CRUD including path-traversal name
sanitization) verified against a real aiohttp test server. The JS panel
was tested by mocking ComfyUI's DOM/fetch APIs and driving the actual
widget code: outfit chip add/remove, Auto-shots preview, Apply-to-node,
the full `+ Shot` picker→resolve→append flow, Save file, Copy plan_json,
and Clear all verified against real (not simulated) handler logic.

## Text → Database system prompt
`system_prompts/TEXT_TO_DATABASE.md` is an LLM system prompt for
generating new `models/`, `locations/`, `outfits/` JSON from a short
text brief — the fashion-pack equivalent of the original ASB's
database-generation prompts, rewritten from scratch for this schema.
It differs from the original in three concrete ways: no real people, no
sexual/fetish content, and piece descriptions cover fabric/cut only,
never anatomy. Verified against the real pipeline — a sample
model/location/outfit set generated to this spec loaded through
`ASB_PlanEditor` and produced correct resolved prompts with no schema
mismatches.

## Intent-matched pose selection
Poses are drawn from a per-`shot_intent` mood-filtered shuffle-bag, not the
whole pose bank. Each intent (`hero`, `editorial`, `movement`,
`establishing`, `candid`, `portrait`, `detail`) maps to an accepted mood set
in `INTENT_POSE_MOODS`; static-anchored intents (`hero`, `detail`,
`portrait`, `establishing`) additionally exclude any pose tagged
`dynamic`/`movement`, even if it shares another accepted mood — a mood tag
like "editorial" alone wasn't enough to keep a walking pose out of a static
hero shot. Verified: 0 pose/intent rule violations at 50/100/150 shots on a
single model+outfit+location, on top of the existing 0-duplicate-prompt
guarantee.

## Known v1 limitations (next up)
  folders grow past a handful of files each.
