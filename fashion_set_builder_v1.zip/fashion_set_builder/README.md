# Fashion Set Builder for ComfyUI (v1)

Data-driven node pack for generating full fashion photography coverage —
any model, any location, any wardrobe — as a deterministic, reproducible
shot plan.

## Install
1. Copy this folder into `ComfyUI/custom_nodes/`
2. Restart ComfyUI
3. Find nodes under **ArtisticSetBuilder/Fashion**

## Node graph (typical)
```
ASB Load Model ─────────────┐
ASB Load Location ──────────┤
ASB Load Outfit ──► ASB Add Outfit To Sequence ──► (chain more outfits) ──┐
                                                                            │
                                                    ASB Fashion Shoot Plan ─┤
                                                                            │
                                                    ASB Plan → Prompt ◄─────┘
                                                        │
                                          prompt / negative / seed → your sampler
                                                        │
                                                  ASB Manifest (optional log)
```

- **ASB Load Model / Location / Outfit** — pick from `data/models`,
  `data/locations`, `data/outfits` (dropdowns are populated from whatever
  JSON files exist in those folders — add your own, no code changes needed)
- **ASB Add Outfit To Sequence** — chain as many of these as looks in the
  shoot; wire `previous_sequence` from the last one to build up the list
- **ASB Fashion Shoot Plan** — the core engine. Expands model × location ×
  outfit sequence into a full shot list: one hero shot per look, a spread
  of coverage patterns (editorial, movement, candid, environmental...)
  cycled across the location's zones, and one detail shot per
  `detail_worthy` garment/accessory piece
- **ASB Plan → Prompt** — resolves one shot (by index, or auto-advancing
  with `use_internal_counter`) into final prompt/negative/seed/filename text
- **ASB Batch Index** — external counter if you'd rather drive the index
  yourself than use the internal counter
- **ASB Manifest** — appends each rendered shot to a CSV log

## Data layout
```
data/
  models/*.json        identity + styling, no anatomical fields
  locations/*.json      a location + its zones (spots within it)
  outfits/*.json         a full look + its individual pieces
  cameras.json            camera body/lens prompt phrases
  framing.json            shot-size prompt phrases
  coverage_patterns.json  the editorial shot-type vocabulary
  poses.json              pose bank tagged by mood
```

Add a new model/location/outfit by dropping a new JSON file in the matching
folder — it shows up in the dropdown next ComfyUI (re)loads the pack.

### Outfit piece schema
```json
{
  "item_id": "P1",
  "name": "camel wool coat",
  "type": "outerwear",
  "prompt": "structured camel wool oversized coat, sharp lapels",
  "detail_worthy": true
}
```
`detail_worthy: true` means the plan engine will reserve one close-up shot
for that piece. Set it `false` for basics that don't need their own beat
(plain tee, base trousers, etc).

## One photoset = one model + one outfit + one location, 100+ shots
`shots_per_look` supports up to 500. Zone/pattern/pose are drawn from
independent shuffle-bags (not cycled in lockstep) with a signature-dedupe
pass, so a single look at one location produces zero duplicate prompts —
verified at 50/100/150/200 shots on one model+outfit+location. The
dedupe key is `framing_id`, not `pattern_id`: several coverage patterns
resolve to the same framing phrase, and pattern *name* never reaches the
final prompt text, so two differently-named patterns with the same
framing_id are the same prompt and are deduped as such.

Detail shots now scale with volume too — budgeted at ~20% of the look's
shot count (or one per detail-worthy piece, whichever is larger), cycling
through pieces with independently drawn zone/pose per repeat so a second
close-up of the same garment reads as a different angle, not a copy.

## Known v1 limitations (next up)
- **Pose selection isn't intent-matched** — poses are drawn independently
  of `shot_intent`, so a calm "seated, relaxed" pose can land on a
  close-up detail shot, or a mid-motion pose on a static hero shot. Needs
  mood/intent tagging cross-referenced against `shot_intent` before
  drawing from the pose bag.
- **No live dropdown widgets** — model/location/outfit lists are captured
  at ComfyUI startup, not refreshed live from disk. The ASB zip's approach
  (a small `web/` JS extension + a `/asb/data` endpoint) is worth porting
  over so adding data files doesn't require a restart.
- **No validator/data-report scripts yet** — worth adding once the data
  folders grow past a handful of files each.
