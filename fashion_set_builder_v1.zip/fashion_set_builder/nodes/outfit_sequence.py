class ASB_OutfitSequence:
    """
    Chain nodes together to build an ordered list of looks for the shoot.
    Wire `previous_sequence` from an upstream ASB_OutfitSequence node to
    append; leave it unconnected to start a new sequence.
    """

    CATEGORY = "ArtisticSetBuilder/Fashion"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {"outfit": ("ASB_OUTFIT",)},
            "optional": {"previous_sequence": ("ASB_OUTFIT_SEQ",)},
        }

    RETURN_TYPES = ("ASB_OUTFIT_SEQ", "STRING")
    RETURN_NAMES = ("outfit_sequence", "sequence_summary")
    FUNCTION = "add"

    def add(self, outfit, previous_sequence=None):
        seq = list(previous_sequence) if previous_sequence else []
        seq.append(outfit)
        names = ", ".join(o.get("name", "?") for o in seq)
        summary = f"{len(seq)} look(s): {names}"
        return (seq, summary)


NODE_CLASS_MAPPINGS = {"ASB_OutfitSequence": ASB_OutfitSequence}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_OutfitSequence": "ASB Add Outfit To Sequence"}
