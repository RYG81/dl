from .utils import load_shared


def _camera_ids():
    try:
        return [c["id"] for c in load_shared("cameras.json")]
    except FileNotFoundError:
        return []


class ASB_PlanToPrompt:
    """
    Serves one shot from the plan as resolved prompt text. With
    use_internal_counter ON it advances automatically each queue run;
    otherwise wire an external `index` (e.g. from ASB Batch Index).
    """

    CATEGORY = "ArtisticSetBuilder/Fashion"
    _counters = {}

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "plan": ("ASB_PLAN",),
                "model": ("ASB_MODEL",),
                "location": ("ASB_LOCATION",),
                "outfit_sequence": ("ASB_OUTFIT_SEQ",),
                "camera": (["(none)"] + _camera_ids(),),
                "style": (
                    "STRING",
                    {
                        "default": "editorial fashion photography, clean composition, sharp focus, natural color grading",
                        "multiline": True,
                    },
                ),
                "negative": (
                    "STRING",
                    {
                        "default": "blurry, deformed, extra limbs, watermark, low quality, plastic skin, distorted fabric",
                        "multiline": True,
                    },
                ),
                "use_internal_counter": ("BOOLEAN", {"default": True}),
            },
            "optional": {"index": ("INT", {"default": 0, "min": 0, "max": 100000})},
        }

    RETURN_TYPES = ("STRING", "STRING", "INT", "STRING", "INT", "BOOLEAN")
    RETURN_NAMES = ("prompt", "negative_prompt", "seed", "filename_hint", "index", "done")
    FUNCTION = "resolve"

    def resolve(
        self,
        plan,
        model,
        location,
        outfit_sequence,
        camera,
        style,
        negative,
        use_internal_counter,
        index=0,
    ):
        if use_internal_counter:
            key = id(plan)
            index = self._counters.get(key, 0)
            self._counters[key] = index + 1

        if index >= len(plan):
            return ("", negative, 0, "", index, True)

        shot = plan[index]

        # Manual shots added via the Plan Editor panel's "+ Shot" control
        # (or loaded from a saved file) carry their own already-resolved
        # text — skip the normal id-based lookups entirely for these.
        override = shot.get("resolved_prompt_override")
        if override:
            return (
                override.get("prompt", ""),
                override.get("negative") or negative,
                override.get("seed", shot.get("seed", 0)),
                override.get("filename_hint", shot.get("filename_hint", "")),
                index,
                False,
            )

        outfit = next((o for o in outfit_sequence if o.get("id") == shot["outfit_id"]), None)
        zone = next((z for z in location.get("zones", []) if z.get("id") == shot["zone_id"]), {})
        framing = next(
            (f for f in load_shared("framing.json") if f["id"] == shot["framing_id"]), {}
        )
        poses = load_shared("poses.json")
        pose = next((p for p in poses if p["id"] == shot.get("pose_id")), {})
        cameras = load_shared("cameras.json")
        cam = next((c for c in cameras if c["id"] == camera), None)

        parts = [model.get("prompt_description", model.get("name", ""))]

        if outfit:
            if shot["shot_intent"] == "detail" and shot.get("detail_piece_id"):
                piece = next(
                    (p for p in outfit.get("pieces", []) if p["item_id"] == shot["detail_piece_id"]),
                    None,
                )
                if piece:
                    parts.append(piece.get("prompt", piece.get("name", "")))
            else:
                piece_prompts = [p.get("prompt", "") for p in outfit.get("pieces", [])]
                parts.append(outfit.get("base_prompt") or ", ".join(filter(None, piece_prompts)))

        parts.append(zone.get("prompt", zone.get("name", "")))
        parts.append(pose.get("prompt", ""))
        parts.append(framing.get("prompt", ""))
        if cam:
            parts.append(cam.get("prompt", ""))
        parts.append(style)

        prompt = ", ".join(p for p in parts if p)
        return (prompt, negative, shot["seed"], shot["filename_hint"], index, False)


NODE_CLASS_MAPPINGS = {"ASB_PlanToPrompt": ASB_PlanToPrompt}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_PlanToPrompt": "ASB Plan \u2192 Prompt"}
