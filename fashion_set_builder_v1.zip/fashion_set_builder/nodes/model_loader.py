from .utils import list_models, load_json


class ASB_LoadModel:
    CATEGORY = "ArtisticSetBuilder/Fashion"

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"model_name": (list_models(),)}}

    RETURN_TYPES = ("ASB_MODEL", "STRING")
    RETURN_NAMES = ("model", "model_summary")
    FUNCTION = "load"

    def load(self, model_name):
        data = load_json("models", model_name)
        summary = f"{data.get('name', model_name)} — {data.get('age', '?')}, {data.get('build', '')}".strip()
        return (data, summary)


NODE_CLASS_MAPPINGS = {"ASB_LoadModel": ASB_LoadModel}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_LoadModel": "ASB Load Model"}
