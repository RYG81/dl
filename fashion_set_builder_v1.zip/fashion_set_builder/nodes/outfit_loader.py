from .utils import list_outfits, load_json


class ASB_LoadOutfit:
    CATEGORY = "ArtisticSetBuilder/Fashion"

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"outfit_name": (list_outfits(),)}}

    RETURN_TYPES = ("ASB_OUTFIT", "STRING")
    RETURN_NAMES = ("outfit", "outfit_summary")
    FUNCTION = "load"

    def load(self, outfit_name):
        data = load_json("outfits", outfit_name)
        pieces = data.get("pieces", [])
        summary = f"{data.get('name', outfit_name)} — {len(pieces)} piece(s)"
        return (data, summary)


NODE_CLASS_MAPPINGS = {"ASB_LoadOutfit": ASB_LoadOutfit}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_LoadOutfit": "ASB Load Outfit"}
