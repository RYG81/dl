import json
import os

PACK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(PACK_DIR, "data")


def _list_json(subdir):
    d = os.path.join(DATA_DIR, subdir)
    if not os.path.isdir(d):
        return []
    names = sorted(f[:-5] for f in os.listdir(d) if f.endswith(".json"))
    return names


def load_json(subdir, name):
    path = os.path.join(DATA_DIR, subdir, f"{name}.json")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_shared(filename):
    path = os.path.join(DATA_DIR, filename)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def list_models():
    return _list_json("models") or ["(no models found)"]


def list_locations():
    return _list_json("locations") or ["(no locations found)"]


def list_outfits():
    return _list_json("outfits") or ["(no outfits found)"]
