from .utils import list_locations, load_json


class ASB_LoadLocation:
    CATEGORY = "ArtisticSetBuilder/Fashion"

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"location_name": (list_locations(),)}}

    RETURN_TYPES = ("ASB_LOCATION", "STRING")
    RETURN_NAMES = ("location", "location_summary")
    FUNCTION = "load"

    def load(self, location_name):
        data = load_json("locations", location_name)
        zones = data.get("zones", [])
        summary = f"{data.get('name', location_name)} — {len(zones)} zone(s)"
        return (data, summary)


NODE_CLASS_MAPPINGS = {"ASB_LoadLocation": ASB_LoadLocation}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_LoadLocation": "ASB Load Location"}
