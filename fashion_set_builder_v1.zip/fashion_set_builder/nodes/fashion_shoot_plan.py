import random

from .utils import load_shared

DETAIL_WORTHY_DEFAULT = True
DETAIL_SHOT_RATIO = 0.2  # target fraction of budget spent on detail shots
MAX_SIGNATURE_RETRIES = 50


class ShuffleBag:
    """Draws items without replacement; reshuffles a fresh copy once the bag
    empties. Guarantees no item repeats until every other item has been
    used at least once — avoids the clumping you get from plain random.choice
    or from cycling in lockstep with another sequence."""

    def __init__(self, items, rng):
        self.items = list(items)
        self.rng = rng
        self.pool = []

    def draw(self):
        if not self.pool:
            self.pool = list(self.items)
            self.rng.shuffle(self.pool)
        return self.pool.pop()


class ASB_FashionShootPlan:
    """
    Expands model x location x outfit sequence into a deterministic,
    reproducible shot list. Every look gets: one hero shot, a spread of
    non-detail coverage patterns drawn independently across zone/pattern/pose
    (shuffle-bagged, with a signature dedupe pass so no two shots in the same
    look land on an identical zone+pattern+pose combo), and (if enabled) a
    budgeted share of detail shots cycling through detail-worthy pieces.
    """

    CATEGORY = "ArtisticSetBuilder/Fashion"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("ASB_MODEL",),
                "location": ("ASB_LOCATION",),
                "outfit_sequence": ("ASB_OUTFIT_SEQ",),
                "shots_per_look": ("INT", {"default": 24, "min": 1, "max": 500}),
                "coverage_density": (["light", "standard", "dense"],),
                "include_detail_shots": ("BOOLEAN", {"default": True}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xFFFFFFFF}),
            }
        }

    RETURN_TYPES = ("ASB_PLAN", "STRING", "INT")
    RETURN_NAMES = ("plan", "plan_summary", "shot_count")
    FUNCTION = "build"

    def build(
        self,
        model,
        location,
        outfit_sequence,
        shots_per_look,
        coverage_density,
        include_detail_shots,
        seed,
    ):
        patterns = load_shared("coverage_patterns.json")
        poses = load_shared("poses.json")
        zones = location.get("zones") or [{"id": "Z0", "name": "default", "prompt": ""}]
        rng = random.Random(seed)

        hero_pattern = next((p for p in patterns if p["shot_intent"] == "hero"), patterns[0])
        detail_pattern = next(
            (p for p in patterns if p["shot_intent"] == "detail"),
            {"id": "detail_garment", "name": "Garment Detail", "framing_id": "close_up", "shot_intent": "detail"},
        )
        non_detail_patterns = [p for p in patterns if p["shot_intent"] != "detail"]
        if not poses:
            poses = [{"id": "neutral", "prompt": ""}]

        shots = []
        shot_index = 0

        for outfit in outfit_sequence:
            pieces = outfit.get("pieces", [])
            detail_pieces = [p for p in pieces if p.get("detail_worthy", DETAIL_WORTHY_DEFAULT)]

            budget = max(shots_per_look - 1, 0)  # -1 reserves the forced opening hero shot
            if include_detail_shots and detail_pieces:
                n_detail = max(len(detail_pieces), round(budget * DETAIL_SHOT_RATIO))
                n_detail = min(n_detail, budget)
            else:
                n_detail = 0
            n_coverage = max(budget - n_detail, 0)

            zone_bag = ShuffleBag(zones, rng)
            pattern_bag = ShuffleBag(non_detail_patterns, rng)
            pose_bag = ShuffleBag(poses, rng)
            used_signatures = set()

            # Forced opening hero shot for the look
            zone = zone_bag.draw()
            pose = pose_bag.draw()
            used_signatures.add((zone["id"], hero_pattern["framing_id"], pose["id"], None))
            shots.append(
                self._make_shot(model, outfit, zone, hero_pattern, pose, shot_index, seed, None)
            )
            shot_index += 1

            # Remaining coverage shots — independently drawn zone/pattern/pose,
            # retried on exact signature collision so no shot repeats verbatim.
            for _ in range(n_coverage):
                zone, pattern, pose = self._draw_unique(
                    zone_bag, pattern_bag, pose_bag, used_signatures
                )
                shots.append(
                    self._make_shot(model, outfit, zone, pattern, pose, shot_index, seed, None)
                )
                shot_index += 1

            # Detail shots — cycle through detail-worthy pieces, each with its
            # own independently drawn zone/pose so repeats of the same piece
            # still read as a different angle.
            if n_detail:
                piece_cycle = [detail_pieces[i % len(detail_pieces)] for i in range(n_detail)]
                for piece in piece_cycle:
                    zone, _, pose = self._draw_unique(
                        zone_bag, ShuffleBag([detail_pattern], rng), pose_bag, used_signatures,
                        fixed_pattern=detail_pattern, piece_id=piece["item_id"],
                    )
                    shots.append(
                        self._make_shot(
                            model, outfit, zone, detail_pattern, pose, shot_index, seed, piece
                        )
                    )
                    shot_index += 1

        summary = (
            f"{len(shots)} shots across {len(outfit_sequence)} look(s) "
            f"at {location.get('name', '?')} (density: {coverage_density})"
        )
        return (shots, summary, len(shots))

    @staticmethod
    def _draw_unique(zone_bag, pattern_bag, pose_bag, used_signatures, fixed_pattern=None, piece_id=None):
        # Signature keys on framing_id, not pattern_id — pattern *name* never
        # reaches the final prompt text, only its resolved framing phrase does,
        # so two differently-named patterns sharing a framing_id are the same
        # prompt and must be deduped as such.
        for _ in range(MAX_SIGNATURE_RETRIES):
            zone = zone_bag.draw()
            pattern = fixed_pattern or pattern_bag.draw()
            pose = pose_bag.draw()
            sig = (zone["id"], pattern["framing_id"], pose["id"], piece_id)
            if sig not in used_signatures:
                used_signatures.add(sig)
                return zone, pattern, pose
        # Combinatorial space exhausted (only happens at very high shot counts
        # relative to data volume) — accept the collision rather than loop forever.
        used_signatures.add(sig)
        return zone, pattern, pose

    @staticmethod
    def _make_shot(model, outfit, zone, pattern, pose, shot_index, base_seed, detail_piece):
        name_bits = [
            model.get("name", "model"),
            outfit.get("name", "look"),
            detail_piece["name"] if detail_piece else pattern["id"],
            f"{shot_index:03d}",
        ]
        filename_hint = "_".join(b.replace(" ", "-") for b in name_bits)
        return {
            "index": shot_index,
            "model_id": model.get("id"),
            "outfit_id": outfit.get("id"),
            "outfit_name": outfit.get("name"),
            "zone_id": zone.get("id"),
            "zone_name": zone.get("name"),
            "pattern_id": pattern["id"],
            "pattern_name": pattern["name"],
            "framing_id": pattern["framing_id"],
            "shot_intent": pattern["shot_intent"],
            "pose_id": pose.get("id"),
            "detail_piece_id": detail_piece["item_id"] if detail_piece else None,
            "seed": base_seed + shot_index,
            "filename_hint": filename_hint,
        }


NODE_CLASS_MAPPINGS = {"ASB_FashionShootPlan": ASB_FashionShootPlan}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_FashionShootPlan": "ASB Fashion Shoot Plan"}
