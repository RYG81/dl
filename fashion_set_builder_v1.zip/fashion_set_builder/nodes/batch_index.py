class ASB_BatchIndex:
    CATEGORY = "ArtisticSetBuilder/Fashion"
    _counter = 0

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"reset": ("BOOLEAN", {"default": False})}}

    RETURN_TYPES = ("INT",)
    RETURN_NAMES = ("index",)
    FUNCTION = "next_index"

    def next_index(self, reset):
        if reset:
            ASB_BatchIndex._counter = 0
        idx = ASB_BatchIndex._counter
        ASB_BatchIndex._counter += 1
        return (idx,)


NODE_CLASS_MAPPINGS = {"ASB_BatchIndex": ASB_BatchIndex}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_BatchIndex": "ASB Batch Index"}
