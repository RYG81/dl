import csv
import os
import time


class ASB_Manifest:
    CATEGORY = "ArtisticSetBuilder/Fashion"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "filename_hint": ("STRING", {"forceInput": True}),
                "prompt": ("STRING", {"forceInput": True}),
                "seed": ("INT", {"forceInput": True}),
                "output_path": ("STRING", {"default": "output/fashion_set_manifest.csv"}),
            }
        }

    RETURN_TYPES = ()
    FUNCTION = "log"
    OUTPUT_NODE = True

    def log(self, filename_hint, prompt, seed, output_path):
        out_dir = os.path.dirname(output_path)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        write_header = not os.path.exists(output_path)
        with open(output_path, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if write_header:
                w.writerow(["timestamp", "filename_hint", "seed", "prompt"])
            w.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), filename_hint, seed, prompt])
        return {}


NODE_CLASS_MAPPINGS = {"ASB_Manifest": ASB_Manifest}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_Manifest": "ASB Manifest"}
