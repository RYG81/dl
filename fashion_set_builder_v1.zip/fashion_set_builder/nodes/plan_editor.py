from .utils import list_models, list_locations, list_outfits, load_json


class ASB_PlanEditor:
    """
    All-in-one authoring node. Pick a model, a location, and build an
    outfit sequence directly on this node (no separate loader/sequence
    chain needed) — the embedded Plan Editor panel (see
    web/asb_plan_editor.js) lets you add/remove outfits as chips and
    preview the resulting shot plan before wiring it downstream.

    `outfit_names` is a comma-separated list of outfit filenames (without
    .json) and is normally managed by the panel, not typed by hand.
    """

    CATEGORY = "ArtisticSetBuilder/Fashion"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model_name": (list_models(),),
                "location_name": (list_locations(),),
                "outfit_names": ("STRING", {"default": "", "multiline": False}),
                "shots_per_look": ("INT", {"default": 24, "min": 1, "max": 500}),
                "coverage_density": (["light", "standard", "dense"],),
                "include_detail_shots": ("BOOLEAN", {"default": True}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xFFFFFFFF}),
            }
        }

    RETURN_TYPES = ("ASB_MODEL", "ASB_LOCATION", "ASB_OUTFIT_SEQ", "ASB_PLAN", "STRING", "INT")
    RETURN_NAMES = ("model", "location", "outfit_sequence", "plan", "plan_summary", "shot_count")
    FUNCTION = "build"

    def build(
        self,
        model_name,
        location_name,
        outfit_names,
        shots_per_look,
        coverage_density,
        include_detail_shots,
        seed,
    ):
        # Local import avoids a circular import at module load time
        # (fashion_shoot_plan doesn't depend on this module, but keeping
        # the import scoped here keeps package init order irrelevant).
        from .fashion_shoot_plan import ASB_FashionShootPlan

        model = load_json("models", model_name)
        location = load_json("locations", location_name)

        available = set(list_outfits())
        names = [n.strip() for n in outfit_names.split(",") if n.strip()]
        names = [n for n in names if n in available]
        if not names:
            # Nothing selected in the panel yet (or node run standalone) —
            # fall back to the first available outfit so the node still
            # produces a valid plan instead of erroring.
            fallback = list_outfits()
            if not fallback:
                raise ValueError("No outfit JSON files found in data/outfits/")
            names = fallback[:1]

        outfit_sequence = [load_json("outfits", n) for n in names]

        plan, plan_summary, shot_count = ASB_FashionShootPlan().build(
            model,
            location,
            outfit_sequence,
            shots_per_look,
            coverage_density,
            include_detail_shots,
            seed,
        )
        return (model, location, outfit_sequence, plan, plan_summary, shot_count)


NODE_CLASS_MAPPINGS = {"ASB_PlanEditor": ASB_PlanEditor}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_PlanEditor": "ASB Plan Editor (all-in-one)"}
