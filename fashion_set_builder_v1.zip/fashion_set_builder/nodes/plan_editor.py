import json

from .utils import list_models, list_locations, list_outfits, load_json, load_shared

QUALITY_PRESETS = {
    "draft": "draft quality, quick render",
    "standard": "standard quality, clean render",
    "high": "high quality, detailed render, sharp focus",
    "ultra": "ultra high quality, hyperdetailed, professional retouch, 8k",
}


def _camera_ids():
    try:
        return [c["id"] for c in load_shared("cameras.json")]
    except FileNotFoundError:
        return []


class ASB_PlanEditor:
    """
    All-in-one authoring node. Pick a model, a location, and build an
    outfit sequence directly on this node (no separate loader/sequence
    chain needed) -- the embedded Plan Editor panel (see
    web/asb_plan_editor.js) lets you add/remove outfits as chips, preview
    the resulting shot plan, hand-add individual shots, and save/load
    full configs as files, before wiring the outputs downstream.

    `outfit_names` (comma-separated outfit filenames without .json) and
    `manual_shots_json` (a JSON array of already-resolved shot dicts added
    via the panel's "+ Shot" control) are managed by the panel, not
    normally typed by hand.
    """

    CATEGORY = "ArtisticSetBuilder/Fashion"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "title": ("STRING", {"default": "My Shoot"}),
                "model_name": (list_models(),),
                "location_name": (list_locations(),),
                "outfit_names": ("STRING", {"default": "", "multiline": False}),
                "camera": (["(none)"] + _camera_ids(),),
                "quality": (list(QUALITY_PRESETS.keys()),),
                "shots_per_look": ("INT", {"default": 24, "min": 1, "max": 500}),
                "coverage_density": (["light", "standard", "dense"],),
                "include_detail_shots": ("BOOLEAN", {"default": True}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xFFFFFFFF}),
            },
            "optional": {
                "manual_shots_json": ("STRING", {"default": "[]", "multiline": True}),
                "shot_overrides_json": ("STRING", {"default": "{}", "multiline": True}),
            },
        }

    RETURN_TYPES = (
        "ASB_MODEL", "ASB_LOCATION", "ASB_OUTFIT_SEQ", "ASB_PLAN",
        "STRING", "INT", "STRING", "STRING",
    )
    RETURN_NAMES = (
        "model", "location", "outfit_sequence", "plan",
        "plan_summary", "shot_count", "camera", "quality_style_suffix",
    )
    FUNCTION = "build"

    def build(
        self,
        title,
        model_name,
        location_name,
        outfit_names,
        camera,
        quality,
        shots_per_look,
        coverage_density,
        include_detail_shots,
        seed,
        manual_shots_json="[]",
        shot_overrides_json="{}",
    ):
        from .fashion_shoot_plan import ASB_FashionShootPlan

        model = load_json("models", model_name)
        location = load_json("locations", location_name)

        available = set(list_outfits())
        names = [n.strip() for n in outfit_names.split(",") if n.strip()]
        names = [n for n in names if n in available]
        if not names:
            fallback = list_outfits()
            if not fallback:
                raise ValueError("No outfit JSON files found in data/outfits/")
            names = fallback[:1]

        outfit_sequence = [load_json("outfits", n) for n in names]

        plan, plan_summary, _ = ASB_FashionShootPlan().build(
            model,
            location,
            outfit_sequence,
            shots_per_look,
            coverage_density,
            include_detail_shots,
            seed,
        )

        manual_shots = self._parse_manual_shots(manual_shots_json)
        if manual_shots:
            start = len(plan)
            for offset, m in enumerate(manual_shots):
                plan.append(self._manual_to_shot(m, start + offset))

        overrides = self._parse_overrides(shot_overrides_json)
        edited_count = sum(1 for o in overrides.values() if not o.get("removed"))
        removed_count = sum(1 for o in overrides.values() if o.get("removed"))
        if overrides:
            plan = self._apply_overrides(plan, overrides)

        # Edits/removals can leave gaps -- keep indices contiguous so
        # ASB_PlanToPrompt's index-driven loop still walks the whole plan.
        for i, shot in enumerate(plan):
            shot["index"] = i
        shot_count = len(plan)

        base_summary = plan_summary.split(" (density")[0]
        extras = []
        if manual_shots:
            extras.append(f"+{len(manual_shots)} manual")
        if edited_count:
            extras.append(f"{edited_count} edited")
        if removed_count:
            extras.append(f"-{removed_count} removed")
        extra_str = f" {' '.join(extras)}" if extras else ""
        plan_summary = f"{base_summary}{extra_str} (density: {coverage_density})"

        quality_suffix = QUALITY_PRESETS.get(quality, "")
        return (model, location, outfit_sequence, plan, plan_summary, shot_count, camera, quality_suffix)

    @staticmethod
    def _parse_manual_shots(manual_shots_json):
        try:
            data = json.loads(manual_shots_json or "[]")
            return data if isinstance(data, list) else []
        except (json.JSONDecodeError, TypeError):
            return []

    @staticmethod
    def _parse_overrides(shot_overrides_json):
        try:
            data = json.loads(shot_overrides_json or "{}")
            return data if isinstance(data, dict) else {}
        except (json.JSONDecodeError, TypeError):
            return {}

    @staticmethod
    def _apply_overrides(plan, overrides):
        # Edits from the panel's per-shot card controls (zone/pose/pattern
        # changed in place) and removals both arrive here keyed by the
        # shot's index at preview time. Indices from a stale preview
        # (plan regenerated with a different seed/density since) are
        # silently skipped rather than corrupting an unrelated shot.
        remove_indices = set()
        for key, override in overrides.items():
            try:
                idx = int(key)
            except (TypeError, ValueError):
                continue
            if idx < 0 or idx >= len(plan):
                continue
            if override.get("removed"):
                remove_indices.add(idx)
                continue
            shot = plan[idx]
            shot["zone_name"] = override.get("zone_name", shot.get("zone_name"))
            shot["pattern_name"] = override.get("pattern_name", shot.get("pattern_name"))
            shot["shot_intent"] = override.get("shot_intent", shot.get("shot_intent"))
            shot["pose_id"] = override.get("pose_id", shot.get("pose_id"))
            shot["resolved_prompt_override"] = {
                "prompt": override.get("prompt", ""),
                "negative": override.get("negative", ""),
                "seed": override.get("seed", shot.get("seed", 0)),
                "filename_hint": override.get("filename_hint", shot.get("filename_hint", "")),
            }
        if remove_indices:
            plan = [s for i, s in enumerate(plan) if i not in remove_indices]
        return plan

    @staticmethod
    def _manual_to_shot(manual, index):
        return {
            "index": index,
            "model_id": None,
            "outfit_id": None,
            "outfit_name": manual.get("outfit_name", "manual"),
            "zone_id": None,
            "zone_name": manual.get("zone_name", ""),
            "pattern_id": manual.get("pattern_id", "manual"),
            "pattern_name": manual.get("pattern_name", "Manual Shot"),
            "framing_id": None,
            "shot_intent": manual.get("shot_intent", "manual"),
            "pose_id": manual.get("pose_id", ""),
            "detail_piece_id": None,
            "seed": manual.get("seed", 0),
            "filename_hint": manual.get("filename_hint", f"manual_{index:03d}"),
            "resolved_prompt_override": {
                "prompt": manual.get("prompt", ""),
                "negative": manual.get("negative", ""),
                "seed": manual.get("seed", 0),
                "filename_hint": manual.get("filename_hint", f"manual_{index:03d}"),
            },
        }


NODE_CLASS_MAPPINGS = {"ASB_PlanEditor": ASB_PlanEditor}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_PlanEditor": "ASB Plan Editor (all-in-one)"}
