import json

from .utils import list_models, list_locations, list_outfits, load_json, load_shared

QUALITY_PRESETS = {
    "draft": "draft quality, quick render",
    "standard": "standard quality, clean render",
    "high": "high quality, detailed render, sharp focus",
    "ultra": "ultra high quality, hyperdetailed, professional retouch, 8k",
}


def _camera_ids():
    try:
        return [c["id"] for c in load_shared("cameras.json")]
    except FileNotFoundError:
        return []


class ASB_PlanEditor:
    """
    All-in-one authoring node. Pick a model, a location, and build an
    outfit sequence directly on this node (no separate loader/sequence
    chain needed) -- the embedded Plan Editor panel (see
    web/asb_plan_editor.js) lets you add/remove outfits as chips, preview
    the resulting shot plan, hand-add individual shots, and save/load
    full configs as files, before wiring the outputs downstream.

    `outfit_names` (comma-separated outfit filenames without .json) and
    `manual_shots_json` (a JSON array of already-resolved shot dicts added
    via the panel's "+ Shot" control) are managed by the panel, not
    normally typed by hand.
    """

    CATEGORY = "ArtisticSetBuilder/Fashion"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "title": ("STRING", {"default": "My Shoot"}),
                "model_name": (list_models(),),
                "location_name": (list_locations(),),
                "outfit_names": ("STRING", {"default": "", "multiline": False}),
                "camera": (["(none)"] + _camera_ids(),),
                "quality": (list(QUALITY_PRESETS.keys()),),
                "shots_per_look": ("INT", {"default": 24, "min": 1, "max": 500}),
                "coverage_density": (["light", "standard", "dense"],),
                "include_detail_shots": ("BOOLEAN", {"default": True}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xFFFFFFFF}),
            },
            "optional": {
                "manual_shots_json": ("STRING", {"default": "[]", "multiline": True}),
            },
        }

    RETURN_TYPES = (
        "ASB_MODEL", "ASB_LOCATION", "ASB_OUTFIT_SEQ", "ASB_PLAN",
        "STRING", "INT", "STRING", "STRING",
    )
    RETURN_NAMES = (
        "model", "location", "outfit_sequence", "plan",
        "plan_summary", "shot_count", "camera", "quality_style_suffix",
    )
    FUNCTION = "build"

    def build(
        self,
        title,
        model_name,
        location_name,
        outfit_names,
        camera,
        quality,
        shots_per_look,
        coverage_density,
        include_detail_shots,
        seed,
        manual_shots_json="[]",
    ):
        from .fashion_shoot_plan import ASB_FashionShootPlan

        model = load_json("models", model_name)
        location = load_json("locations", location_name)

        available = set(list_outfits())
        names = [n.strip() for n in outfit_names.split(",") if n.strip()]
        names = [n for n in names if n in available]
        if not names:
            fallback = list_outfits()
            if not fallback:
                raise ValueError("No outfit JSON files found in data/outfits/")
            names = fallback[:1]

        outfit_sequence = [load_json("outfits", n) for n in names]

        plan, plan_summary, shot_count = ASB_FashionShootPlan().build(
            model,
            location,
            outfit_sequence,
            shots_per_look,
            coverage_density,
            include_detail_shots,
            seed,
        )

        manual_shots = self._parse_manual_shots(manual_shots_json)
        if manual_shots:
            start = len(plan)
            for offset, m in enumerate(manual_shots):
                plan.append(self._manual_to_shot(m, start + offset))
            base_summary = plan_summary.split(" (density")[0]
            plan_summary = f"{base_summary} + {len(manual_shots)} manual (density: {coverage_density})"
            shot_count = len(plan)

        quality_suffix = QUALITY_PRESETS.get(quality, "")
        return (model, location, outfit_sequence, plan, plan_summary, shot_count, camera, quality_suffix)

    @staticmethod
    def _parse_manual_shots(manual_shots_json):
        try:
            data = json.loads(manual_shots_json or "[]")
            return data if isinstance(data, list) else []
        except (json.JSONDecodeError, TypeError):
            return []

    @staticmethod
    def _manual_to_shot(manual, index):
        return {
            "index": index,
            "model_id": None,
            "outfit_id": None,
            "outfit_name": manual.get("outfit_name", "manual"),
            "zone_id": None,
            "zone_name": manual.get("zone_name", ""),
            "pattern_id": manual.get("pattern_id", "manual"),
            "pattern_name": manual.get("pattern_name", "Manual Shot"),
            "framing_id": None,
            "shot_intent": manual.get("shot_intent", "manual"),
            "pose_id": manual.get("pose_id", ""),
            "detail_piece_id": None,
            "seed": manual.get("seed", 0),
            "filename_hint": manual.get("filename_hint", f"manual_{index:03d}"),
            "resolved_prompt_override": {
                "prompt": manual.get("prompt", ""),
                "negative": manual.get("negative", ""),
                "seed": manual.get("seed", 0),
                "filename_hint": manual.get("filename_hint", f"manual_{index:03d}"),
            },
        }


NODE_CLASS_MAPPINGS = {"ASB_PlanEditor": ASB_PlanEditor}
NODE_DISPLAY_NAME_MAPPINGS = {"ASB_PlanEditor": "ASB Plan Editor (all-in-one)"}
