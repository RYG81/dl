# Passionate kissing — prompt seeds (from studio/LoRA-style refs)

Trigger family: `They kiss passionately.` / deep passionate kiss

## Structure (MiniMax H3)

```
integrated_multimodal_description: [Shot 1] Live-action, cinematic. [light + place].
[Who] stand/sit/lie close. They kiss passionately, [hold / press / hands on ...].
Camera: medium close-up at eye level, locked | slow subtle push-in.
overall_soundscape: Quiet room tone, soft breathing, light fabric movement, quiet kissing. No spoken dialogue.
non_diegetic_music: N/A
```

## Rules learned from refs

1. **One continuous shot** is enough for pure kissing (7–9s). Multi-shot only if reveal (blankets thrown) or orbit is intentional.
2. **No spoken dialogue** by default — breath and kiss carry audio.
3. **Camera:** medium close-up, eye level, **locked** or **slow push-in** — not frantic cuts.
4. **Hands** may roam waist, hips, chest, back — state it simply.
5. **Clothing state** explicit: lingerie, naked, panties only, etc.
6. Works **MF / FF / MM** — same structure, change subjects.
7. Soundscape is concrete: room tone, breath, fabric, kiss — not "romantic atmosphere."

## LTX continuous form

```
A medium close-up holds [place] under [light]. [Cast] stand/sit close and kiss passionately,
bodies pressed together, hands on waist and back. Soft room tone, quiet breathing, fabric,
and the sound of the kiss. The camera stays locked at eye level (or eases in slowly). No score. No spoken dialogue.
```
