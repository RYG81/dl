# Sequence-first planning

1. Write the **full sexual spine** of the scene (what happens in order).
2. Oral is optional and **peer-choice**: blowjob **or** cunnilingus **or** both at different points — not automatic BJ.
3. Each oral beat picks a **layout**, not a single stock pose.
4. Split into clips only where continuous coverage cannot hold (costume state, room change, major position change).
5. Activity keys are labels inside the spine, not the reason to cut.

Example spines:
- Cunnilingus (him between her thighs) → missionary
- Blowjob (prone on bed) → she climbs up → cowgirl
- Kiss down → cunnilingus → him moves up and enters → doggy
- 69-adjacent oral exchange → cowgirl
