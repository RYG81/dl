# AVS — Example sequence line for EVERY activity
# Format: activity:variant_index:intensity
# Copy lines into AVS Sequence Decider. Pick variant 1..N from list_catalog.

## SOFTCORE

### body_worship — Body Worship
- cast: `couple` | variants: **3**
- sequence: `body_worship:1:low`
- variant 1: he kisses and licks down her body from neck to belly, skipping her pussy to make her wait
- detail frame: close on mouth on skin and her reactions
- triggers: nipple lick

### ff_foreplay — FF Foreplay
- cast: `girls_only` | variants: **3**
- sequence: `ff_foreplay:1:low`
- variant 1: they undress each other, kissing down necks and breasts, fingers teasing without full penetration yet
- detail frame: detail on fingers at pussy or mouths on breasts

### ff_kissing — FF Kissing
- cast: `girls_only` | variants: **2**
- sequence: `ff_kissing:1:low`
- variant 1: two women kiss deeply, hands in hair and on hips, bodies flush
- detail frame: close on lips and tongues

### foreplay — Foreplay
- cast: `couple` | variants: **7**
- sequence: `foreplay:1:low`
- variant 1: they press together fully nude, mouths hungry, hands mapping skin without rushing penetration
- detail frame: close cut on hands on skin, mouths kissing, or fingers at the edge of her pussy without entry
- triggers: having sex

### kissing — Kissing
- cast: `couple` | variants: **4**
- sequence: `kissing:1:low`
- variant 1: deep open-mouth kissing, tongues visible, hands in hair
- detail frame: close on lips, tongue, jaw, eyes half-closed

### nipple_play — Nipple Play
- cast: `couple,solo_female` | variants: **5**
- sequence: `nipple_play:1:low`
- variant 1: he focuses on her breasts, mouth and fingers on her nipples while she arches
- detail frame: close on nipples, tongue or fingers, and her reaction face
- triggers: nipple lick, nipple suck

### solo_body_showcase — Solo Body Showcase
- cast: `solo_female` | variants: **3**
- sequence: `solo_body_showcase:1:low`
- variant 1: she walks toward camera and turns, presenting front, side, and back in slow glamour pacing
- detail frame: detail passes over breasts, waist, hips, then face

### solo_glamour_pose — Solo Glamour Pose
- cast: `solo_female` | variants: **4**
- sequence: `solo_glamour_pose:1:low`
- variant 1: she holds elegant nude poses, shifting weight, arching slightly, always finding the lens
- detail frame: detail on face, breasts, or hip line with shallow depth of field

### solo_lingerie_tease — Solo Lingerie Tease
- cast: `solo_female` | variants: **3**
- sequence: `solo_lingerie_tease:1:low`
- variant 1: in lace lingerie she adjusts straps, lets one shoulder fall, never fully rushed to nude
- detail frame: close on lace against skin, cleavage, or hip cutout

### solo_tease_strip — Solo Tease Strip
- cast: `solo_female` | variants: **4**
- sequence: `solo_tease_strip:1:low`
- variant 1: she slowly peels off her lingerie piece by piece, eyes on the camera, confident and unhurried
- detail frame: close on hands at fabric, skin reveal, face looking into lens

## ORAL

### 69 — 69
- cast: `couple` | variants: **3**
- sequence: `69:1:medium`
- variant 1: 69 with her on top, mouth on his cock while he licks her pussy
- detail frame: alternating close cuts on each mouth at work
- triggers: cunn1l1ngu5, bl0wj0b, performing cunnilingus, performing fellatio

### blowjob — Blowjob
- cast: `couple` | variants: **8**
- sequence: `blowjob:1:medium`
- variant 1: she kneels between his legs and takes his cock into her mouth, lips sealed, one hand stroking the base
- detail frame: close insert on lips stretched around the shaft, tongue, hand on the base
- triggers: bl0wj0b, performing fellatio, sensualBJ, handj0b

### creampie_cleanup — Creampie Cleanup
- cast: `couple` | variants: **2**
- sequence: `creampie_cleanup:1:medium`
- variant 1: after the creampie he licks her pussy clean, slow careful tongue
- detail frame: close on tongue cleaning
- triggers: cunn1l1ngu5, performing cunnilingus

### cunnilingus — Cunnilingus
- cast: `couple` | variants: **6**
- sequence: `cunnilingus:1:medium`
- variant 1: he is between her open thighs licking her pussy, tongue on her clit, her hands in his hair
- detail frame: close on tongue on clit and labia, her hands in his hair
- triggers: cunn1l1ngu5, performing cunnilingus

### deepthroat — Deepthroat
- cast: `couple` | variants: **4**
- sequence: `deepthroat:1:medium`
- variant 1: she takes his cock deep until her lips meet the base, throat working, steady hold before easing back
- detail frame: close on her lips at the base, throat working, eyes watering
- triggers: bl0wj0b, performing fellatio, blowjob, deepthroat

### ff_cunnilingus — FF Cunnilingus
- cast: `girls_only` | variants: **4**
- sequence: `ff_cunnilingus:1:medium`
- variant 1: one woman lies back while the other licks her pussy, focused on her clit, hands holding her thighs open
- detail frame: close on tongue on clit and labia
- triggers: cunn1l1ngu5, performing cunnilingus

### ff_strapon_oral — FF Oral on Strap-on
- cast: `girls_only` | variants: **2**
- sequence: `ff_strapon_oral:1:medium`
- variant 1: she kneels and sucks the strap-on while her partner wears the harness, eye contact up
- detail frame: close on lips around the toy

### rimming — Rimming
- cast: `couple` | variants: **3**
- sequence: `rimming:1:medium`
- variant 1: he spreads her cheeks and licks her ass while she is on all fours
- detail frame: close on tongue
- triggers: performing cunnilingus

### spit_roast_hint — Spit Roast Setup
- cast: `couple` | variants: **2**
- sequence: `spit_roast_hint:1:medium`
- variant 1: she is on all fours sucking his cock, ass raised, body ready for doggy transition
- detail frame: detail alternating mouth and raised ass
- triggers: bl0wj0b, d0gg1e, performing fellatio

## MANUAL

### ball_play — Ball Play
- cast: `couple` | variants: **2**
- sequence: `ball_play:1:medium`
- variant 1: she licks and sucks his balls while stroking his shaft with her hand
- detail frame: close on tongue or careful fingers
- triggers: bl0wj0b, performing fellatio

### ff_scissors — FF Scissoring
- cast: `girls_only` | variants: **2**
- sequence: `ff_scissors:1:medium`
- variant 1: they scissor, legs interleaved, grinding wet pussies together with steady pressure
- detail frame: close on pussies pressed together

### ff_tribbing — FF Tribbing / Grind
- cast: `girls_only` | variants: **2**
- sequence: `ff_tribbing:1:medium`
- variant 1: one woman on top grinding her pussy against the other's, circular hips, both fully nude
- detail frame: detail of wet friction

### fingering_partner — Partner Fingering
- cast: `couple` | variants: **4**
- sequence: `fingering_partner:1:medium`
- variant 1: he fingers her with two fingers, thumb on her clit, her hips lifting into his hand
- detail frame: close on fingers in her pussy, wetness, clit contact
- triggers: masturbating using finger, thrusting in and out of her pussy

### handjob — Handjob
- cast: `couple` | variants: **4**
- sequence: `handjob:1:medium`
- variant 1: she strokes his cock with a firm wet fist, thumb over the head on each upstroke
- detail frame: close on her fingers stroking the shaft and head
- triggers: handj0b, oneHanded, twoHanded, performing a handjob with her right hand

### intercrural — Thigh Sex
- cast: `couple` | variants: **2**
- sequence: `intercrural:1:medium`
- variant 1: his cock slides between her tightly closed thighs, wet with lube or arousal, thrusting
- detail frame: close on shaft sliding between thighs
- triggers: pussy job, rubbing pussy on penis, having sex

### titfuck — Titfuck
- cast: `couple` | variants: **3**
- sequence: `titfuck:1:medium`
- variant 1: his cock slides between her pressed breasts, she adds tongue to the head on each upstroke
- detail frame: close on shaft sliding between pressed breasts, head emerging toward her mouth
- triggers: titfuck, paizuri

## VAGINAL

### against_wall — Against Wall
- cast: `couple` | variants: **3**
- sequence: `against_wall:1:high`
- variant 1: standing against the wall, one of her legs hooked around him, he thrusts up
- detail frame: side insert of cock in pussy
- triggers: having sex, standing sex

### amazon — Amazon
- cast: `couple` | variants: **2**
- sequence: `amazon:1:high`
- variant 1: amazon: she sits on him with his legs pressed up, she controls depth and angle
- detail frame: insert of penetration from her dominant position
- triggers: c0wg1rl, having sex

### bent_over — Bent Over
- cast: `couple` | variants: **3**
- sequence: `bent_over:1:high`
- variant 1: she bends at the waist, hands on her knees or the bed, he takes her from behind
- detail frame: rear insert of penetration
- triggers: d0gg1e, sfbehind, having sex from behind

### bridge — Bridge
- cast: `couple` | variants: **2**
- sequence: `bridge:1:high`
- variant 1: she holds a bridge on the bed, he kneels and enters her from the front
- detail frame: detail of penetration into arched hips
- triggers: having sex

### butterfly — Butterfly
- cast: `couple` | variants: **2**
- sequence: `butterfly:1:high`
- variant 1: butterfly: she on her back at the bed edge, hips at the edge, he stands and thrusts into her
- detail frame: detail of penetration at the bed edge
- triggers: m15510n4ry, having sex in the missionary position

### chair_sex — Chair Sex
- cast: `couple` | variants: **3**
- sequence: `chair_sex:1:high`
- variant 1: she straddles him on a chair facing him, grinding and rising on his cock
- detail frame: detail of connection
- triggers: c0wg1rl, having sex

### cowgirl — Cowgirl
- cast: `couple` | variants: **6**
- sequence: `cowgirl:1:high`
- variant 1: she straddles him facing forward and rides his cock with controlled hip rolls, hands on his chest
- detail frame: low or side insert showing his cock disappearing into her as she rises and drops
- triggers: c0wg1rl, riding cowgirl grinding, grinding motion, having sex in the cowgirl position

### doggy — Doggy
- cast: `couple` | variants: **9**
- sequence: `doggy:1:high`
- variant 1: she is on all fours as he takes her from behind, hands on her hips, each thrust rippling through her ass
- detail frame: rear three-quarter insert showing cock entering her pussy, ass ripple, his hands on her hips
- triggers: d0gg1e, they are having doggy style sex, having sex in the doggystyle position, sfbehind

### full_nelson — Full Nelson
- cast: `couple` | variants: **2**
- sequence: `full_nelson:1:high`
- variant 1: full nelson: he stands behind her, arms under her knees locking her open, thrusting up into her
- detail frame: detail of penetration from behind under locked arms
- triggers: having sex

### knee_chest — Knee to Chest
- cast: `couple` | variants: **2**
- sequence: `knee_chest:1:high`
- variant 1: her knees pulled to her chest, he kneels and drives into her with a steep angle
- detail frame: detail of deep entry
- triggers: m15510n4ry, having sex in the missionary position

### lap_dance_sex — Lap Sex
- cast: `couple` | variants: **3**
- sequence: `lap_dance_sex:1:high`
- variant 1: she sits in his lap facing him and sinks onto his cock, small grinding motions
- detail frame: close on connection while she grinds in his lap
- triggers: c0wg1rl, having sex

### lotus — Lotus
- cast: `couple` | variants: **3**
- sequence: `lotus:1:high`
- variant 1: seated face-to-face, her legs wrapped around his waist, rocking with his cock inside her
- detail frame: close between them showing connection and small rocking motion
- triggers: having sex, having sex in the missionary position

### matthews — Matthews / Legs Up
- cast: `couple` | variants: **3**
- sequence: `matthews:1:high`
- variant 1: her legs pushed up toward her chest, he kneels and drives down into her
- detail frame: detail of steep entry
- triggers: m15510n4ry, having sex in the missionary position

### missionary — Missionary
- cast: `couple` | variants: **9**
- sequence: `missionary:1:high`
- variant 1: he is between her open thighs in missionary, cock driving into her pussy with deep rhythmic strokes, her knees drawn up
- detail frame: angled insert from the side or slightly above showing cock sliding in and out of her pussy, his lower body and her open 
- triggers: m15510n4ry, having sex in the missionary position, thrusting in and out of her pussy, having missionary sex

### piledriver — Piledriver
- cast: `couple` | variants: **2**
- sequence: `piledriver:1:high`
- variant 1: piledriver: her hips elevated, legs toward her head, he drives down into her pussy from above
- detail frame: close on deep penetration from above
- triggers: m15510n4ry, having sex

### pronebone — Pronebone
- cast: `couple` | variants: **3**
- sequence: `pronebone:1:high`
- variant 1: she lies flat face-down, he covers her and thrusts into her pussy from behind
- detail frame: rear-side insert of penetration with her ass under him
- triggers: d0gg1e, sfbehind, prone, having sex from behind

### reverse_cowgirl — Reverse Cowgirl
- cast: `couple` | variants: **4**
- sequence: `reverse_cowgirl:1:high`
- variant 1: she straddles him facing away and rides, ass on display, steady bounce
- detail frame: rear insert of penetration and ass motion as she lifts and sinks
- triggers: r3v3rs3_c0wg1rl, c0wg1rl, having sex in the reverse cowgirl position

### scissors — Scissors
- cast: `couple` | variants: **2**
- sequence: `scissors:1:high`
- variant 1: scissors: both on their sides, legs interleaved, grinding and shallow thrusting
- detail frame: close on genital contact
- triggers: having sex

### sideways — Sideways
- cast: `couple` | variants: **2**
- sequence: `sideways:1:high`
- variant 1: sideways sex facing each other, one leg over his hip, slow thrusts
- detail frame: close on penetration between scissored thighs
- triggers: having sex

### spooning — Spooning
- cast: `couple` | variants: **3**
- sequence: `spooning:1:high`
- variant 1: they lie on their sides spooned, he enters her from behind with slow deep strokes
- detail frame: side insert along the bodies showing penetration from behind while spooned
- triggers: having sex, having sex from behind

### standing — Standing
- cast: `couple` | variants: **4**
- sequence: `standing:1:high`
- variant 1: standing sex against the wall, one of her legs lifted, he thrusts up into her
- detail frame: side insert of cock in pussy, his hands under her thigh or at her hip
- triggers: having sex, standing sex

### table_top — Table Top
- cast: `couple` | variants: **2**
- sequence: `table_top:1:high`
- variant 1: she sits on the edge of a table, he stands between her open legs and thrusts into her
- detail frame: side insert of penetration
- triggers: having sex, m15510n4ry

## ANAL

### anal_cowgirl — Anal Cowgirl
- cast: `couple` | variants: **2**
- sequence: `anal_cowgirl:1:high`
- variant 1: she lowers herself onto his cock in anal cowgirl, controlling depth, slow rolls
- detail frame: detail of anal connection as she rides
- triggers: c0wg1rl, having sex in the cowgirl position

### anal_doggy — Anal Doggy
- cast: `couple` | variants: **3**
- sequence: `anal_doggy:1:high`
- variant 1: anal doggy: she on all fours, he enters her ass slowly then builds a controlled rhythm
- detail frame: close rear angle on anal entry, careful depth, his hands steadying her hips
- triggers: d0gg1e, they are having doggy style sex, sfbehind, anal sex

### anal_missionary — Anal Missionary
- cast: `couple` | variants: **2**
- sequence: `anal_missionary:1:high`
- variant 1: anal missionary: he between her legs, careful entry into her ass, slow build
- detail frame: detail of careful anal entry
- triggers: m15510n4ry, having sex

## STRAPON

### ff_threesome_strapon — FF Threesome Strap-on
- cast: `girls_only` | variants: **2**
- sequence: `ff_threesome_strapon:1:high`
- variant 1: one woman on all fours is fucked with a strap-on while a third kisses her or holds her open
- detail frame: detail on strap-on entry with third's hands or mouth involved

### strapon_bent_over — Strap-on Bent Over
- cast: `girls_only` | variants: **2**
- sequence: `strapon_bent_over:1:high`
- variant 1: she bends at the waist, hands on knees or the bed, partner takes her from behind with the strap-on
- detail frame: rear insert of strap-on penetration

### strapon_cowgirl — Strap-on Cowgirl
- cast: `girls_only` | variants: **3**
- sequence: `strapon_cowgirl:1:high`
- variant 1: she straddles her partner and rides the strap-on with controlled hip rolls, hands on the giver's chest
- detail frame: low or side insert of the toy disappearing as she rises and drops
- triggers: c0wg1rl, strap-on

### strapon_doggy — Strap-on Doggy
- cast: `girls_only` | variants: **4**
- sequence: `strapon_doggy:1:high`
- variant 1: she is on all fours as her partner fucks her from behind with a strap-on, hands on her hips, steady deep thrusts
- detail frame: rear three-quarter insert showing strap-on dildo entering her pussy, hands on hips
- triggers: d0gg1e, strap-on, they are having doggy style sex

### strapon_domme — Strap-on Domme Control
- cast: `girls_only` | variants: **3**
- sequence: `strapon_domme:1:high`
- variant 1: dominant partner holds her hair lightly and fucks her with the strap-on from behind, controlled pace
- detail frame: detail on strap-on entry while submissive is held

### strapon_missionary — Strap-on Missionary
- cast: `girls_only` | variants: **3**
- sequence: `strapon_missionary:1:high`
- variant 1: she lies on her back, legs open, as her partner between her thighs drives a strap-on into her pussy
- detail frame: angled insert of strap-on dildo thrusting into her pussy
- triggers: m15510n4ry, strap-on

### strapon_standing — Strap-on Standing
- cast: `girls_only` | variants: **2**
- sequence: `strapon_standing:1:high`
- variant 1: standing against the wall, one leg lifted, partner thrusts the strap-on up into her
- detail frame: side insert of toy and hips

## FINISH

### creampie_cowgirl — Creampie Cowgirl
- cast: `couple` | variants: **1**
- sequence: `creampie_cowgirl:1:peak`
- variant 1: cowgirl climax — she stays down on him as he finishes inside, holds, small after-grinds
- detail frame: close on him finishing inside while she is on top
- triggers: c0wg1rl, riding cowgirl grinding

### creampie_doggy — Creampie Doggy
- cast: `couple` | variants: **2**
- sequence: `creampie_doggy:1:peak`
- variant 1: doggy climax — he finishes inside her from behind, holds on her hips, then slow pull shows the fill
- detail frame: close on finish inside then slow pull showing fill
- triggers: d0gg1e, they are having doggy style sex

### creampie_missionary — Creampie Missionary
- cast: `couple` | variants: **3**
- sequence: `creampie_missionary:1:peak`
- variant 1: missionary climax — he finishes deep inside her, holds, then a slow withdrawal shows the creampie at her entrance
- detail frame: close on cock buried as he finishes, then slow pull showing fill at the entrance
- triggers: m15510n4ry, having sex in the missionary position, cr34mp13

### creampie_standing — Creampie Standing
- cast: `couple` | variants: **1**
- sequence: `creampie_standing:1:peak`
- variant 1: standing climax — he finishes inside her against the wall, holds her up through it
- detail frame: detail of finish inside while standing
- triggers: having sex, standing sex

### cum_in_mouth — Cum In Mouth
- cast: `couple` | variants: **2**
- sequence: `cum_in_mouth:1:peak`
- variant 1: he finishes in her mouth as she kneels, lips sealed, she holds then swallows or shows
- detail frame: close on release into her mouth
- triggers: f4c3cr34m, cum in mouth, mouthfull

### cum_on_body — Cum On Body
- cast: `couple` | variants: **3**
- sequence: `cum_on_body:1:peak`
- variant 1: he finishes across her breasts and stomach as she lies back
- detail frame: close on thick release on skin
- triggers: cumshot, cum on body

### facial — Facial
- cast: `couple` | variants: **3**
- sequence: `facial:1:peak`
- variant 1: he finishes on her face as she kneels, eyes up, mouth soft
- detail frame: close on release across her face or lips
- triggers: f4c3cr34m, facial

## SOLO_FEMALE

### solo_female_anal_toy — Solo Female Anal Toy
- cast: `solo_female` | variants: **2**
- sequence: `solo_female_anal_toy:1:high`
- variant 1: she works a small toy into her ass slowly while rubbing her clit
- detail frame: close on toy at her ass
- triggers: masturbating with a dildo

### solo_female_breast — Solo Female Breast Play
- cast: `solo_female` | variants: **2**
- sequence: `solo_female_breast:1:high`
- variant 1: she cups and squeezes her own breasts, pinching nipples, thighs shifting
- detail frame: close on nipples and fingers
- triggers: nipple lick, nipple suck

### solo_female_clit — Solo Female Clit
- cast: `solo_female` | variants: **4**
- sequence: `solo_female_clit:1:high`
- variant 1: fingertips rub her clit in tight focused circles, thighs trembling
- detail frame: close on fingertips on her clit
- triggers: masturbating using finger, masturbating with the fingers of her right hand

### solo_female_dildo_ride — Solo Female Dildo Ride
- cast: `solo_female` | variants: **2**
- sequence: `solo_female_dildo_ride:1:high`
- variant 1: she lowers onto a suction toy on the floor or chair and rides with full weight
- detail frame: close on toy disappearing into her
- triggers: masturbating with a dildo, c0wg1rl

### solo_female_fingering — Solo Female Fingering
- cast: `solo_female` | variants: **6**
- sequence: `solo_female_fingering:1:high`
- variant 1: two fingers slide deep into her wet pussy while her thumb circles her clit, free hand on her breast
- detail frame: close on fingers in her pussy, wetness, clit contact
- triggers: masturbating using finger, masturbating with the fingers of her right hand, thrusting in and out of her pussy

### solo_female_finish — Solo Female Finish
- cast: `solo_female` | variants: **3**
- sequence: `solo_female_finish:1:high`
- variant 1: orgasm breaks — hips bucking, core clamping, thighs shaking, toes curling
- detail frame: close on face and working hand through the peak
- triggers: masturbating using finger

### solo_female_grinding — Solo Female Grinding
- cast: `solo_female` | variants: **3**
- sequence: `solo_female_grinding:1:high`
- variant 1: she straddles the edge of the bed and grinds her full weight down, continuous contact
- detail frame: close on pussy and clit in continuous pressure contact
- triggers: grinding motion, masturbating using finger

### solo_female_mirror — Solo Female Mirror
- cast: `solo_female` | variants: **2**
- sequence: `solo_female_mirror:1:high`
- variant 1: she watches herself in the mirror while fingering her pussy, free hand on a breast
- detail frame: close on her hand between her legs and face in the mirror
- triggers: masturbating using finger

### solo_female_shower — Solo Female Shower
- cast: `solo_female` | variants: **2**
- sequence: `solo_female_shower:1:high`
- variant 1: in the shower, water running, she fingers herself against the wall
- detail frame: close on fingers or toy under water
- triggers: masturbating using finger, LTXNUDES

### solo_female_toy — Solo Female Toy
- cast: `solo_female` | variants: **4**
- sequence: `solo_female_toy:1:high`
- variant 1: she guides a toy into her pussy and works a firm rhythm, free hand on her clit
- detail frame: close on toy entering her pussy and her grip
- triggers: masturbating with a dildo, thrusting in and out of her pussy

## SOLO_MALE

### solo_male_edge — Solo Male Edge
- cast: `solo_male` | variants: **3**
- sequence: `solo_male_edge:1:high`
- variant 1: tight slow strokes bring him to the edge — he pauses, abs flexed — then resumes
- detail frame: close on tight grip at the edge, then resume
- triggers: cock stroking

### solo_male_finish — Solo Male Finish
- cast: `solo_male` | variants: **3**
- sequence: `solo_male_finish:1:high`
- variant 1: fast strokes through climax, hips jerking, thick white release on his stomach
- detail frame: close on release on stomach or hand
- triggers: cock stroking, cumshot

### solo_male_lube — Solo Male Lube Stroke
- cast: `solo_male` | variants: **2**
- sequence: `solo_male_lube:1:high`
- variant 1: wet lube stroke, long gliding pulls, thumb over the head
- detail frame: close on shiny shaft and fist
- triggers: cock stroking

### solo_male_stroke — Solo Male Stroke
- cast: `solo_male` | variants: **5**
- sequence: `solo_male_stroke:1:high`
- variant 1: his fist strokes the shaft in a steady rhythm, thumb over the head on each upstroke, free hand on his balls
- detail frame: close on fist on shaft, head, precum
- triggers: cock stroking, performing a handjob with his right hand on his own penis

### solo_male_toy — Solo Male Toy
- cast: `solo_male` | variants: **2**
- sequence: `solo_male_toy:1:high`
- variant 1: he uses a fleshlight or sleeve with both hands, steady strokes
- detail frame: close on toy on or around his cock
- triggers: cock stroking
