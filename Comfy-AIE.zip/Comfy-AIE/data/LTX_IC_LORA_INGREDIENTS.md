# LTX IC-LoRA Ingredients + AVS_RefSheet

Model: https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Ingredients

## Purpose
Lock **characters, props, location** across LTX clips via one composite **reference sheet**.

## AVS flow (one extra node only)

```
Cast → RefSheet → panel image prompts
                      ↓
              (your image gen × N)
                      ↓
              collage to one grid image
                      ↓
         LTX Ingredients workflow (sheet as ref)
                      +
         ingredients_prompt_prefix + AVS_Render (ltx) action
```

## Outputs

| Output | Use |
|--------|-----|
| `reference_sheet_description` | Human-readable panel inventory |
| `panel_prompts_json` / `panel_prompts_text` | One prompt per still to generate |
| `grid_layout` | Suggested cols/rows and order |
| `ingredients_prompt_prefix` | Starts with `Reference sheet: … Generated video: ` |
| `video_action_stub` | Optional action seed; prefer full AVS_Render LTX text after prefix |

## ComfyUI side
1. Put Ingredients LoRA in `models/loras`
2. Use official **IC-LoRA reference sheet** workflow (ref path required — plain LoRA loader is not enough)
3. Strength ~1.0–1.4; trained bucket ~768×448 often strongest
4. Larger panels for main performers = better identity lock

## Tips
- Same sheet for every beat in a multi-clip scene
- Nude + clothed turnarounds when costume changes mid-story
- Props that must persist (glass dildo, robe) get their own panels
