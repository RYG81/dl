# LTX-2.3 / 2.5 prompt format (official + AVS)

Source: https://docs.ltx.io/open-source-model/usage-guides/prompting-guide

## Single-shot
One flowing **present-tense** paragraph, ~4–8 sentences:
shot scale → scene/light → characters → action → camera → audio.
Dialogue in quotation marks.

## Multi-shot (prefer 2–4)
Still one chronological paragraph. At every cut:
1. Name transition: "A hard cut transitions to…"
2. Re-establish scale / angle / who is in frame
3. Re-identify subjects with visual anchors
4. State audio continuity across the cut

**Do not** use `[Shot 1]` labels (that is MiniMax-H3 style).

## Adult AVS additions
- Explicit anatomy: cock / pussy / shaft
- BJ: hand on shaft + wet rhythm
- Optional LoRA trigger mid-action; `LTXNUDES, FLW` seal when using LTX NSFW packs
