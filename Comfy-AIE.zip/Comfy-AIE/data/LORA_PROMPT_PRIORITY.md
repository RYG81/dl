# LoRA tags, token priority, and why pose/anatomy succeed or fail

Goal: make AVS prompts **LoRA-compatible and model-priority-aware** so pose and genitals lock the way community LoRA demos do — then expand the sex-activity list on that foundation.

---

## 1. What LoRA makers actually decide

A sex-act LoRA is not “all sex.” It is a **narrow concept** bound to a **trigger**.

| Decision | Meaning |
|----------|---------|
| **Trigger** | Rare token (`bl0w_j0b`, `slptp`, `PENISLORA`, `moawxx`) — empty slot in the base model |
| **Concept** | One act / geometry / texture cluster (deepthroat + hand on shaft, missionary insert, face-sit, etc.) |
| **Captions** | Same *order* every clip; only what should stay **flexible** is described; identity of the concept is *not* over-described if it should stick to the trigger |
| **Inference rule** | User must put **trigger first** (or early), then **same action language used in training** |

If training captions always said:

```text
bl0w_j0b. She is giving a deepthroat blowjob. One hand grips the shaft. Lips stretched around his erect cock.
```

then at inference you need **that language family**, not:

```text
romantic intimacy, beautiful woman, passionate oral, connection, the join...
```

The LoRA never saw your poetry. It saw **trigger + concrete act geometry**.

---

## 2. Caption logic (training side) — why tags exist

### Trigger
- Unique, low prior in the base model.
- Always present in every training caption.
- At use time: **first or very early** in the prompt.

### What gets tagged / described
Trainers tag what they want **controllable later**:
- layout / pose
- camera angle
- clothing state
- visible genital geometry
- secondary hands
- wetness / saliva

They **omit or under-tag** what should fuse into the trigger (so the concept “is” the trigger).

### NSFW anatomy failure fix (from real retrains)
Abstract words fail; **action + named parts** work:

| Bad (collapse) | Good (locks anatomy) |
|----------------|----------------------|
| fingers near her | finger penetration, spreading her pussy |
| the join | his cock in her pussy |
| oral | lips stretched around his erect cock, hand on the shaft |
| him | his veiny cock / her pussy lips |

Training and inference both reward **nouns that name the contact surface**.

### Concept LoRA caption order (typical)

```text
[TRIGGER], [shot/angle], [who], [exact act with named genitals], [hand/secondary], [wet/fluid], [body reaction], [setting light] optional
```

Missionary LoRA trainers often say captions go:

1. subject  
2. **action**  
3. second subject  
4. pose peculiarities  
5. traits  
6. crop  
7. lighting  

Action is **early**, not buried under adjectives.

---

## 3. Token / attention priority (why order matters)

Models do not treat every word equally.

**Practical priority for sex video prompts:**

```text
1. TRIGGER (if any LoRA)
2. Medium / reality (live-action, cinematic) — optional but early for H3
3. CORE ACT + NAMED ANATOMY (who does what to which body part)
4. Layout / pose geometry (prone, edge of bed, legs open, from behind)
5. Secondary motion (hand on shaft, breast bounce, hip roll)
6. Camera (only if needed; continuous preferred)
7. Environment / light (short)
8. Sound (H3/LTX fields)
9. Sparse dialogue (woven on a physical beat)
```

### What kills pose/anatomy
- Long cast essays **before** the act  
- Abstract intimacy language **before** cock/pussy contact  
- “Him / it / the join / entrance” instead of named parts  
- Trigger buried at the end or missing  
- Conflicting acts in one breath without sequence clarity  

### What successful LoRA prompts do
Examples from public act LoRAs:

- `Live action PENISLORA. The woman is giving a deepthroat blow job to the man's erect penis. The penis is visible from the front.`
- `slptp, sloppy and messy deepthroat blowjob, ...`
- `bl0w_j0b` + one clear oral geometry sentence  
- Missionary: *thrusts his penis in and out of her vagina* — not “makes love”

**Pattern:** trigger → **explicit act sentence with genital nouns** → support detail.

---

## 4. Why community demos work and generic AVS prose fails

| Community LoRA demo | Weak generic prompt |
|---------------------|---------------------|
| Trigger first | No trigger / wrong trigger |
| 1 clear geometry | Many poetic clauses |
| `erect cock`, `pussy`, `shaft`, `lips` | `him`, `connection`, `intimacy` |
| Hand role stated | Hands ignored → model invents |
| Short, repeated training lexicon | Novel synonyms every time |
| One act focus | Act + mood + biography + camera essay mixed |

The base model + LoRA are matching **training distribution**.  
Your prompt must **look like the caption language**, not like a film review.

---

## 5. AVS writing contract (future-ready)

### When a LoRA is active
```text
[TRIGGER] [optional strength handled in Comfy]
[one sentence: subject + verb + named genital contact + layout]
[1–2 secondaries: hand, bounce, wet]
[short place/light]
[audio fields if H3/LTX]
[optional one dialogue line on a thrust/bob]
```

### When no LoRA
Same structure **without** trigger — still lead with **act + anatomy**, not mood.

### Never lead with
- age-gap essay  
- “studio cinematic masterpiece” pile  
- emotion labels without body  

Put cast **once**, short; **act geometry is the spine**.

---

## 6. Mapping to our three models

| Model | Priority tip |
|-------|----------------|
| **MiniMax H3** | Trigger (if LoRA) inside Shot 1 early; act + anatomy in prose; moans in `overall_soundscape`; dialogue rare `<d>` |
| **LTX** | Continuous present tense; trigger early; named hard cut only if needed; same anatomy nouns |
| **WAN** | Short dense act sentence first; avoid diluting with style adjectives |

---

## 7. Expanding the sex-activity list (method)

For each studio act you want to support:

1. **Name the concept** (one geometry family).  
2. Find or note **LoRA trigger + caption lexicon** if one exists.  
3. Write **3–6 layout variants** (not one pose).  
4. Force **required visible** strings: e.g. `his cock in her pussy`, `lips around his cock`, `tongue on her clit`.  
5. List **secondaries** that appear in real coverage.  
6. Only then add dialogue hooks / studio tags.

Do **not** expand activities as mood words. Expand as **contact geometries**.

### Starter taxonomy (studio coverage)

Oral: blowjob layouts, cunnilingus layouts, 69  
Hand: handjob, fingering  
Breast: titfuck  
Penetration: missionary, doggy, cowgirl, reverse cowgirl, spoon, standing doggy, butterfly, anal variants  
Toy: dildo ride, strapon (giver/receiver)  
Transition: undress, grind / dry hump, guide-in  

Each row = layouts + required anatomy phrase + optional trigger list.

---

## 8. One-line checklist before generate

- [ ] Trigger first (if LoRA)?  
- [ ] Act sentence has **cock/pussy/clit/lips/shaft** as needed?  
- [ ] Layout stated (prone / edge / from behind / on top)?  
- [ ] Hand/secondary stated if critical?  
- [ ] Cast not burying the act?  
- [ ] Continuous shot unless cut is earned?  
- [ ] Dialogue sparse and on a physical beat?  

If anatomy still fails: strengthen the **act sentence**, do not add more adjectives.
"""
)
print("wrote LORA_PROMPT_PRIORITY.md")
# also append short pointer in ltx system
ltx = Path("/home/workdir/artifacts/Comfy-AIE/avs_config/prompts/ltx_system.txt")
t = ltx.read_text()
if "Token priority" not in t:
    t = t.rstrip() + """

## Token priority (LoRA + base)
1) Trigger (if any) 2) Core act + named anatomy 3) Layout 4) Secondaries 5) Camera/env 6) Sound 7) Sparse dialogue.
See data/LORA_PROMPT_PRIORITY.md. Never bury cock/pussy contact under mood language.
"""
    ltx.write_text(t)
print("ltx pointer")
PY
cd /home/workdir/artifacts && rm -f Comfy-AIE.zip && zip -r Comfy-AIE.zip Comfy-AIE \
  -x "Comfy-AIE/.git/*" -x "Comfy-AIE/**/__pycache__/*" -x "Comfy-AIE/**/*.pyc" -q \
  && ls -lh Comfy-AIE.zip
