# kermitfrog1202 study (from your collected prompts)

## Pattern
```
{trigger}. A {N}-second 2:3 cinematic shot.
integrated_multimodal_description: [Shot 1] Live-action, cinematic. {env+cast+action}.
Camera: {angle}.
overall_soundscape: {wet, breath, room}.
non_diegetic_music: N/A
```

## Triggers mapped into AVS
- bl0w_j0b → blowjob, deepthroat
- titty_drop → solo_tease_strip, solo_female_breast
- dildo phrase → solo_female_toy
- pillow phrase → solo_female_grinding
- strapon phrase → strapon_*
- cameltoe, sagging breasts → catalogued in lora_triggers_ref.json

## BJ must-haves
hand on shaft + wet oral rhythm + explicit cock language
