# Dialogue, expression & moans style (AVS)

Goal: **sound human**, not like a forced porn script. Prefer breath and body over words.

Research basis: authentic sex-audio studies (vocalization rises at peak; speech is rare), adult directors preferring organic set sound, erotic audio direction (dead air, pace match, imperfect breath), phonetic analyses of porn (non-lexical moans dominate; stereotyped lines are sparse).

---

## Hierarchy (use in this order)

1. **Silence / quiet room tone** — allowed; do not fill every second  
2. **Breath** — inhale through teeth, soft exhale, nasal stuffiness when aroused is realistic  
3. **Non-verbal voice** — soft `mm`, `ahh`, short gasps, broken syllables timed to thrusts  
4. **One intentional verbal line** when sensation/role needs it (can be a full short sentence)  
5. **Never** monologue or spam the same stock line every second

---

## Intelligent dialogue (not banned — used with intent)

Words **can** add realism when they are **specific to the body, relationship, and moment**.
Empty stock spam every clip is the problem — not explicit language itself.

| Weak (avoid as default spam) | Strong (use when it fits) |
|------------------------------|---------------------------|
| “Oh yes” every 2 seconds | One line tied to sensation or role |
| “Fuck me harder daddy” on every beat | Age-gap / role line only in that story |
| Endless “yes yes yes” loops | Broken, breathy fragment mid-thrust |
| Same line for every activity | Line names the act or feeling *now* |

**Proven style (user-tested realism):**  
specific body feedback + relationship term when the story supports it.

Examples that work when paced with the action:
- “Ohh uncle… you’re so deep, I can feel you inside me.”
- “Stay — right there.”
- “I can feel every inch.”
- “Don’t pull out.”
- Soft: “Slow… yes, like that.”

Rules for strong lines:
1. **At most one solid spoken line per short clip** (plus non-verbal moans).
2. Line should reference **sensation, depth, pace, or role** — not empty cheerleading.
3. Delivery always described: breathy, strained, almost whispered, broken by a moan.
4. Match register: studio = quieter, fewer words; raw/hard = still sparse but can be filthier.
5. Relationship terms (uncle, sir, etc.) **only** when cast/story is age-gap or roleplay — never random.

---

## Expressions (face + body — prefer these over dialogue)

Describe **physical cues**, not feelings:

| Intensity | Face | Body voice |
|-----------|------|------------|
| Low / tease | Soft open mouth, eyes half-lidded, small swallow | Quiet breath, almost no voice |
| Medium | Furrowed brow, lips parting, focus on partner or closed eyes | Soft `mm`, short gasps on impact |
| High | Eyes squeeze, mouth wider, jaw slack | Longer moans, broken pitch, louder on deeper strokes |
| Peak | Unfocused eyes, tremor, held breath then release | Short non-words, irregular rhythm, then quieter after |

Male default: lower volume — sharp inhales, low `mm`, occasional grunt on deep thrusts; not silent, not theatrical.

---

## Moans (how to write them in prompts)

Put **sound behavior in the soundscape / action prose**, not as fake subtitle text.

**Good**
- soft breathy moans rising and falling with each thrust  
- quiet nasal breathing, a short gasp when he sinks deeper  
- her voice stays low; only broken sounds on the downstroke  
- his breathing roughens; a low grunt on the deepest stroke  
- at the edge her moans turn shorter and higher, then catch  

**Optional intensity tags** (when using moan LoRAs like `moawxx`):
- soft sensual female moan + gentle writhing  
- deeper throaty pleasure sound + hips trembling  
- high thin cry only at peak, then breath  

**Bad**
- she says “ah ah ah ah ah” as dialogue  
- continuous loud porn-scream for the whole 8s  

---

## Weave into action prose (preferred for LTX)

Do **not** park dialogue in a separate block at the end. Attach each line to a physical moment:

```
…each powerful thrust drives deeper; her ass jiggles as she arches and breaks:
“Uncle you’re so fucking deep… I can feel it in my stomach.”
His mouth is at her neck; he answers low:
“Your pussy is so tight.”
She pushes back: “Go deeper inside me.”
Wet squelch and silk rustle fill the gaps between words.
```

That pattern (user-tested) beats both silence-only *and* spam “oh yes” loops.

## Dialogue rules (when words are used)

1. **Max one spoken line per short clip** unless the beat is talk-heavy (door invite, domme command).  
2. Prefer **short** (3–8 words) *or* one **specific full sentence** when it names depth/role/sensation.  
   - Short: “Stay still.” / “Like that.” / “Don’t stop.”  
   - Specific: “Ohh… you’re so deep, I can feel you inside me.”  
3. Match **pace** to the act: slow scene → soft, spaced words; hard pace → fragmented, breath between words.  
4. Delivery always described: *quiet*, *breathy*, *almost whispered*, *strained*, *low*.  
5. Studio / SexArt register: quieter, fewer words. Raw / hard register: still sparse, just less polite.  
6. Setup beats (door, robe) can use normal soft speech; sex beats should drop to breath + rare words.

### Register examples

**Studio intimate (preferred default)**  
- Almost no dialogue  
- Soundscape: linen, wet contact, shared breathing  
- One optional line: she whispers, “Slow.”  

**Active sex**  
- Moans timed to motion  
- Optional: “There—” / “Deeper—” (broken, not full sentence)  

**Peak**  
- Non-verbal only, or one fragment: “I’m—” then breath  

**Domme / strapon presentational**  
- One clear line is OK (command style), then return to breath + wet sound  

---

## Model-specific writing

### MiniMax-H3
- Prefer **no** `<d>` line on pure sex beats  
- If used: short + voice quality outside the tag  
  `The woman with a quiet breathy voice (S1) says: <d>[English] Slow.</d>`  
- Put continuous moans in **overall_soundscape**, not as spoken dialogue (spoken dialogue can get TTS’d)

### LTX
- Dialogue in quotation marks only when needed: she whispers, “Stay.”  
- At cuts: “her soft moans continue across the cut”  

### WAN
- Weave: *a soft moan escapes on each thrust* — not a script block  

---

## Soundscape template (natural)

```
overall_soundscape: quiet room tone; wet contact and skin; fabric/linen;
soft irregular breathing; occasional short breathy moan timed to motion;
no constant talking; no background score (or N/A).
```

Escalate only with intensity:
- low → mostly breath  
- high → moans longer, still uneven  
- peak → denser voiced sounds, then drop  

---

## AVS implementation notes

- Dialogue hooks in activity DB should be **optional short fragments**, not mandatory full sentences.  
- Render/Ollama: default `dialogue_mode = sparse` — often empty string for sex contracts.  
- Do not auto-spam the same stock cheer every clip; pick lines that fit body + relationship + intensity.

---

## Explicit anatomy (prompt body)

Always name genitals and contact surfaces.

| Bad | Good |
|-----|------|
| stretched around him | stretched around his veiny cock |
| takes him | takes his cock into her pussy / mouth |
| the join / the connection | his cock sliding in her pussy |
| between her legs | against her pussy lips |

## Hard cuts

Default: continuous shot inside one activity.
Hard cut only when the activity/position changes or continuous coverage cannot show the required detail.
