# MiniMax-H3 prompt format (AVS)

## Multi-cut (partnered default)

```
integrated_multimodal_description: [Shot 1] ... [Shot 2] At 00:SS.mmm, the camera cuts to ... [Shot 3] At 00:SS.mmm, the camera cuts to ...

overall_soundscape: ...

non_diegetic_music: ...
```

## Single-shot + LoRA trigger (concept / BJ / pillow / titty drop)

```
bl0w_j0b. A 8-second 2:3 cinematic shot.
integrated_multimodal_description: [Shot 1] Live-action, cinematic. {env}. {cast}. {action with cock/pussy}. Camera: close side-angle.
overall_soundscape: Soft wet sounds, breathing, room tone.
non_diegetic_music: N/A
```

## Rules
- Trigger first when present
- Explicit anatomy only
- BJ: hand on shaft + wet oral rhythm
- Cast once in Shot 1
- Music often N/A for intimate LoRA demos
