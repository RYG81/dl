"""Pick a studio style bible (SexArt, Vixen, OnlyFans, etc.)."""

import json
from ..avs_core.studio import load_studios


class AVS_Studio:
    @classmethod
    def INPUT_TYPES(cls):
        studios = load_studios()
        keys = list(studios.keys()) or ["sexart"]
        return {
            "required": {
                "studio": (keys, {"default": keys[0]}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("studio_id", "studio_json", "style_brief")
    FUNCTION = "select"
    CATEGORY = "AVS"

    def select(self, studio: str):
        catalog = load_studios()
        data = catalog.get(studio, {})
        brief = (
            f"{data.get('display_name', studio)}\n"
            f"{data.get('description', '')}\n"
            f"Light: {data.get('lighting', '')}\n"
            f"Camera: {data.get('camera', '')}\n"
            f"Pacing: {data.get('pacing', '')}\n"
            f"Language: {data.get('language', '')}"
        )
        return (
            studio,
            json.dumps(data, indent=2, ensure_ascii=False),
            brief,
        )


NODE_CLASS_MAPPINGS = {"AVS_Studio": AVS_Studio}
NODE_DISPLAY_NAME_MAPPINGS = {"AVS_Studio": "AVS Studio"}
