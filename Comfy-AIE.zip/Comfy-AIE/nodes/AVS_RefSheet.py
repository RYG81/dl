"""
AVS Reference Sheet — for LTX-2.3 IC-LoRA Ingredients continuity.

Builds:
  1) reference_sheet_description  — panel inventory text for Ingredients
  2) panel_prompts_json           — one image prompt per grid cell (generate stills, then collage)
  3) grid_layout                  — suggested rows/cols + labels
  4) ingredients_prompt_prefix    — "Reference sheet: ..." block to prepend to LTX video prompt
  5) video_action_stub            — short "Generated video:" action seed (pair with AVS_Render ltx)

No extra planner nodes. Wire: Cast (+ optional Sequence/Plan scene) → RefSheet →
  (panel prompts → your image gen → grid) + (prefix + Render LTX → Ingredients workflow).
"""

from __future__ import annotations

import json
from datetime import datetime

from ..avs_core.utils import parse_json_safe
from ..avs_core.studio import locked_desc


def _person_blurb(p: dict) -> str:
    if not isinstance(p, dict):
        return "adult performer"
    name = p.get("name") or "Performer"
    gender = (p.get("gender") or "").lower()
    age = p.get("age") or p.get("age_range") or ""
    hair = p.get("hair") or p.get("hair_description") or ""
    skin = p.get("skin") or p.get("skin_tone") or ""
    build = p.get("build") or p.get("body") or ""
    height = p.get("height") or ""
    bits = [str(name)]
    if gender:
        bits.append(gender)
    if age:
        bits.append(f"age {age}")
    if hair:
        bits.append(str(hair))
    if skin:
        bits.append(str(skin))
    if build:
        bits.append(str(build))
    if height:
        bits.append(str(height))
    # anatomy hints if present
    if gender in ("female", "woman", "f"):
        br = p.get("breasts") or p.get("breast_desc")
        if br:
            bits.append(f"breasts: {br}" if not isinstance(br, dict) else f"breasts: {br}")
        elif isinstance(p.get("breasts"), dict):
            b = p["breasts"]
            bits.append(
                "breasts: "
                + ", ".join(f"{k} {v}" for k, v in b.items() if v)
            )
    if gender in ("male", "man", "m"):
        ck = p.get("cock") or p.get("penis")
        if isinstance(ck, dict):
            bits.append(
                "cock: "
                + ", ".join(f"{k} {v}" for k, v in ck.items() if v)
            )
        elif ck:
            bits.append(f"cock: {ck}")
    return ", ".join(bits)


def _clothing_line(p: dict, override: str) -> str:
    if override and override.strip():
        return override.strip()
    if not isinstance(p, dict):
        return "as described"
    return (
        p.get("clothing")
        or p.get("outfit")
        or "nude or scene clothing as specified"
    )


class AVS_RefSheet:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "environment": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": (
                            "Her bedroom; soft practical lamps; adult posters on one wall; "
                            "cupboard with a nude photo and a glass dildo; bed with linen; doorway visible"
                        ),
                    },
                ),
            },
            "optional": {
                "participants_json": ("STRING", {"multiline": True, "default": ""}),
                "scene_json": ("STRING", {"multiline": True, "default": ""}),
                "props": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "glass dildo; red rose robe; open button shirt; boxers",
                    },
                ),
                "clothing_states": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                        "tooltip": "Optional per-person clothing, one line each or semicolon-separated",
                    },
                ),
                "include_nude_turnaround": ("BOOLEAN", {"default": True}),
                "include_prop_panels": ("BOOLEAN", {"default": True}),
                "include_location_panel": ("BOOLEAN", {"default": True}),
                "style_note": (
                    "STRING",
                    {
                        "default": "photorealistic live-action reference, neutral studio light, clear detail, no text overlays",
                    },
                ),
                "action_hint": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                        "tooltip": "Optional seed for Generated video: half (else leave to AVS_Render)",
                    },
                ),
            },
        }

    RETURN_TYPES = (
        "STRING",  # reference_sheet_description
        "STRING",  # panel_prompts_json
        "STRING",  # grid_layout
        "STRING",  # ingredients_prompt_prefix
        "STRING",  # video_action_stub
        "STRING",  # panel_prompts_text (human readable)
        "INT",     # panel_count
        "STRING",  # log
    )
    RETURN_NAMES = (
        "reference_sheet_description",
        "panel_prompts_json",
        "grid_layout",
        "ingredients_prompt_prefix",
        "video_action_stub",
        "panel_prompts_text",
        "panel_count",
        "log",
    )
    FUNCTION = "build"
    CATEGORY = "AVS"

    def build(
        self,
        environment,
        participants_json="",
        scene_json="",
        props="",
        clothing_states="",
        include_nude_turnaround=True,
        include_prop_panels=True,
        include_location_panel=True,
        style_note="photorealistic live-action reference, neutral studio light, clear detail, no text overlays",
        action_hint="",
    ):
        log = [f"[{datetime.now().isoformat()}] AVS_RefSheet"]
        scene = parse_json_safe(scene_json, {}) if scene_json.strip() else {}
        people = parse_json_safe(participants_json, [])
        if not people and isinstance(scene, dict):
            people = scene.get("participants") or []
        if isinstance(people, dict):
            people = [people]
        if not isinstance(people, list):
            people = []

        env = (environment or scene.get("environment") or "intimate indoor space").strip()
        prop_list = [p.strip() for p in props.replace("\n", ";").split(";") if p.strip()]
        cloth_lines = [
            c.strip()
            for c in clothing_states.replace("\n", ";").split(";")
            if c.strip()
        ]

        panels = []
        desc_blocks = []

        # Character panels
        for i, person in enumerate(people):
            if not isinstance(person, dict):
                continue
            blurb = _person_blurb(person)
            cloth = cloth_lines[i] if i < len(cloth_lines) else _clothing_line(person, "")
            label = f"Character {i+1}"
            name = person.get("name") or label

            # clothed / scene-state turnaround
            panels.append(
                {
                    "id": f"char_{i+1}_scene",
                    "label": f"{name} (scene clothing)",
                    "role": "character",
                    "image_prompt": (
                        f"{style_note}. Reference turnaround sheet panel of {blurb}. "
                        f"Clothing: {cloth}. "
                        f"Show clear front three-quarter view, neutral pose, plain backdrop, "
                        f"full body visible, sharp identity detail for video consistency. "
                        f"No other people, no text, no watermark."
                    ),
                }
            )
            desc_blocks.append(
                f"**{name} (scene):** {blurb}. Wearing: {cloth}. "
                f"Front and three-quarter views for identity lock."
            )

            if include_nude_turnaround:
                gender = (person.get("gender") or "").lower()
                nude_extra = (
                    "fully nude, natural anatomy clearly visible"
                    if gender in ("female", "woman", "f", "male", "man", "m")
                    else "fully nude"
                )
                panels.append(
                    {
                        "id": f"char_{i+1}_nude",
                        "label": f"{name} (nude turnaround)",
                        "role": "character",
                        "image_prompt": (
                            f"{style_note}. Reference turnaround panel of {blurb}, {nude_extra}. "
                            f"Front and slight side angle, neutral standing pose, plain backdrop, "
                            f"full body, consistent face and body proportions. No text, no watermark."
                        ),
                    }
                )
                desc_blocks.append(
                    f"**{name} (nude turnaround):** {blurb}, fully nude, "
                    f"front and side angles for body consistency."
                )

        # Location
        if include_location_panel:
            panels.append(
                {
                    "id": "location",
                    "label": "Location",
                    "role": "setting",
                    "image_prompt": (
                        f"{style_note}. Wide establishing reference of the location only: {env}. "
                        f"Empty of people, clear spatial layout, readable props in place, "
                        f"consistent lighting. No text, no watermark."
                    ),
                }
            )
            desc_blocks.append(f"**Setting:** {env}. Empty of people; layout and key furniture clear.")

        # Props
        if include_prop_panels and prop_list:
            for j, prop in enumerate(prop_list[:6]):
                panels.append(
                    {
                        "id": f"prop_{j+1}",
                        "label": prop,
                        "role": "prop",
                        "image_prompt": (
                            f"{style_note}. Product-style reference of: {prop}. "
                            f"Multiple clear angles on a neutral surface, sharp detail, "
                            f"no hands unless needed to show scale. No text labels, no watermark."
                        ),
                    }
                )
            desc_blocks.append(
                "**Props:** " + "; ".join(prop_list[:6]) + ". Shown from clear angles."
            )

        if not panels:
            # fallback empty cast
            panels.append(
                {
                    "id": "location",
                    "label": "Location",
                    "role": "setting",
                    "image_prompt": (
                        f"{style_note}. Wide reference of: {env}. No people. No text."
                    ),
                }
            )
            desc_blocks.append(f"**Setting:** {env}.")

        # Grid layout suggestion
        n = len(panels)
        if n <= 2:
            cols, rows = n, 1
        elif n <= 4:
            cols, rows = 2, 2
        elif n <= 6:
            cols, rows = 3, 2
        else:
            cols, rows = 3, (n + 2) // 3
        layout = {
            "panel_count": n,
            "suggested_cols": cols,
            "suggested_rows": rows,
            "order": [p["id"] for p in panels],
            "labels": [p["label"] for p in panels],
            "note": (
                "Generate each panel_prompts image separately, then collage left-to-right, "
                "top-to-bottom into one reference sheet. Larger panels for main characters."
            ),
        }

        sheet_desc = (
            "### Reference Sheet Description\n"
            + "\n".join(desc_blocks)
            + "\n\nPanels are arranged for IC-LoRA Ingredients identity lock: "
            "characters (clothed and nude turnarounds as included), location, and key props."
        )

        prefix = (
            "Reference sheet: "
            + " | ".join(desc_blocks)
            + "\n\nGenerated video: "
        )

        if action_hint.strip():
            video_stub = "Generated video: " + action_hint.strip()
        else:
            locked = locked_desc(people) if people else ""
            video_stub = (
                "Generated video: A wide shot frames "
                f"{env}. "
                + (f"{locked} " if locked else "")
                + "Use the same performers and props as the reference sheet. "
                "Present-tense action continues here (or paste AVS_Render LTX prompt after the prefix)."
            )

        panel_text = "\n\n".join(
            f"### {i+1}. {p['label']} [{p['id']}]\n{p['image_prompt']}"
            for i, p in enumerate(panels)
        )

        log.append(f"panels={n} people={len(people)} props={len(prop_list)}")
        log.append(f"grid~{cols}x{rows}")

        return (
            sheet_desc,
            json.dumps({"panels": panels}, indent=2, ensure_ascii=False),
            json.dumps(layout, indent=2, ensure_ascii=False),
            prefix,
            video_stub,
            panel_text,
            n,
            "\n".join(log),
        )


NODE_CLASS_MAPPINGS = {"AVS_RefSheet": AVS_RefSheet}
NODE_DISPLAY_NAME_MAPPINGS = {
    "AVS_RefSheet": "AVS Reference Sheet (LTX Ingredients)",
}
