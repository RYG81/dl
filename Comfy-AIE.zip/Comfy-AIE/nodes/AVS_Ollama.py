"""
AVS Ollama — full prompt generation via local LLM (parallel to template Render).

Uses the same inputs as AVS Render + the activity database blocks
(variant text, framing, secondaries, intensity) so the model receives
structured requirements, not a blank rewrite.

System prompts: avs_config/prompts/{wan22,ltx,minimax_h3,solo}_system.txt
"""

import json
import re
from datetime import datetime

from ..avs_core.utils import parse_json_safe, nonempty
from ..avs_core.studio import load_system_prompt, load_activities_db


class AVS_Ollama:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "target_model": (["wan22", "ltx", "minimax_h3"], {"default": "wan22"}),
                "scene_json": ("STRING", {"multiline": True, "default": "{}"}),
                "shot_contracts_json": ("STRING", {"multiline": True, "default": "{}"}),
                "ollama_model": ("STRING", {"default": "llama3.1:8b"}),
            },
            "optional": {
                "locked_desc": ("STRING", {"multiline": True, "default": ""}),
                "mode": (["independent", "continuation"], {"default": "independent"}),
                "minimax_register": (["studio_cinematic", "raw_candid_phone"], {"default": "studio_cinematic"}),
                "clip_duration": ("FLOAT", {"default": 6.0, "min": 3.0, "max": 12.0, "step": 0.5}),
                "temperature": ("FLOAT", {"default": 0.65, "min": 0.0, "max": 1.2, "step": 0.05}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffffffff}),
                "api_base_url": ("STRING", {"default": "http://localhost:11434"}),
                "system_prompt_override": ("STRING", {"multiline": True, "default": ""}),
                "keep_alive": ("STRING", {"default": "5m"}),
                "unload_after": ("BOOLEAN", {"default": True}),
                "prompt_text": ("STRING", {"multiline": True, "default": ""}),
                "extra_instructions": ("STRING", {"multiline": True, "default": ""}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING", "INT", "STRING")
    RETURN_NAMES = (
        "prompts_array_json",
        "prompts_text",
        "first_prompt",
        "negative_prompt",
        "shot_count",
        "log",
    )
    FUNCTION = "run"
    CATEGORY = "AVS"

    NEG = {
        "wan22": (
            "blurry, floating limbs, missing genitals, duplicated anatomy, awkward joints, "
            "ghosting, generative errors, deformed, extra limbs, text, watermark"
        ),
        "ltx": "blurry, low quality, deformed, extra limbs, bad anatomy, text, watermark, cartoon, anime",
        "minimax_h3": "blurry, deformed, extra limbs, bad anatomy, text, watermark, low quality, subtitles, logos",
    }

    PROMPT_FILES = {
        "wan22": "wan22_system.txt",
        "ltx": "ltx_system.txt",
        "minimax_h3": "minimax_h3_system.txt",
    }

    def run(
        self,
        target_model,
        scene_json,
        shot_contracts_json,
        ollama_model,
        locked_desc="",
        mode="independent",
        minimax_register="studio_cinematic",
        clip_duration=6.0,
        temperature=0.65,
        seed=0,
        api_base_url="http://localhost:11434",
        system_prompt_override="",
        keep_alive="5m",
        unload_after=True,
        prompt_text="",
        extra_instructions="",
    ):
        log = [f"[{datetime.now().isoformat()}] Ollama generate -> {target_model} via {ollama_model}"]

        wrap = parse_json_safe(shot_contracts_json, {}) or {}
        contracts = wrap.get("shot_contracts") if isinstance(wrap, dict) else wrap
        if not isinstance(contracts, list):
            contracts = []

        if nonempty(prompt_text) and not contracts:
            out, msg = self._rewrite_one(
                prompt_text, target_model, ollama_model, system_prompt_override,
                extra_instructions, temperature, seed, api_base_url, keep_alive, log,
            )
            neg = self.NEG.get(target_model, "")
            return (
                json.dumps([out], indent=2, ensure_ascii=False),
                out, out, neg, 1, "\n".join(log),
            )

        if not contracts:
            msg = "No shot contracts - connect AVS Sequence or Scene."
            log.append(msg)
            return ("[]", msg, msg, self.NEG.get(target_model, ""), 0, "\n".join(log))

        try:
            import requests
        except Exception:
            msg = "requests not installed - cannot call Ollama"
            log.append(msg)
            return ("[]", msg, msg, self.NEG.get(target_model, ""), 0, "\n".join(log))

        scene = parse_json_safe(scene_json, {}) or {}
        style = scene.get("style") or {}
        environment = scene.get("environment") or "intimate room"
        cast_mode = scene.get("cast_mode") or "couple"
        studio_name = scene.get("studio_name") or scene.get("studio_id") or ""
        cast = self._cast(locked_desc, scene)
        act_db = load_activities_db()

        system = system_prompt_override.strip() if nonempty(system_prompt_override) else load_system_prompt(
            self.PROMPT_FILES.get(target_model, "wan22_system.txt")
        )
        if cast_mode.startswith("solo"):
            solo = load_system_prompt("solo_system.txt")
            if solo:
                system = solo + "\n\nAlso obey the target model format rules in the user message.\n"
                log.append("solo system attached")
        if not system:
            system = "Write explicit adult video prompts. Output only the finished prompt text."
        if target_model == "minimax_h3":
            system = (
                system.rstrip()
                + "\n\nREMINDER: Output ONLY the three official fields "
                "(integrated_multimodal_description, overall_soundscape, non_diegetic_music). "
                "Cast once in Shot 1. Cut coverage wide→body→detail. Dense physical secondaries. "
                "No meta labels. No repeated cast tags."
            )

        prompts = []
        prev = ""
        for i, c in enumerate(contracts):
            if not isinstance(c, dict):
                c = {}
            env_i = c.get("environment") or environment
            if target_model == "minimax_h3":
                # Slot-fill JSON then assemble official 3-field format (stable with small LLMs)
                text = self._generate_minimax_structured(
                    requests, api_base_url, ollama_model, system,
                    cast, env_i, style, studio_name, c, act_db,
                    minimax_register, clip_duration,
                    temperature, (seed + i if seed else 0), keep_alive, log,
                )
            else:
                user = self._user_message(
                    target_model=target_model,
                    studio_name=studio_name,
                    style=style,
                    environment=env_i,
                    cast=cast,
                    cast_mode=cast_mode,
                    contract=c,
                    act_db=act_db,
                    shot_index=i,
                    total=len(contracts),
                    continuation=(mode == "continuation" and i > 0),
                    previous=prev if mode == "continuation" and i > 0 else "",
                    minimax_register=minimax_register,
                    clip_duration=clip_duration,
                    extra_instructions=extra_instructions,
                )
                raw = self._chat(
                    requests, api_base_url, ollama_model, system, user,
                    temperature, seed + i if seed else 0, keep_alive, log,
                )
                text = self._clean(raw, target_model)
                if not text.strip():
                    text = self._fallback_template(c, cast, environment, target_model)
                    log.append(f"Shot {i+1}: empty LLM -> template fallback")
            prompts.append(text)
            if mode == "continuation":
                prev = text
            log.append(f"Shot {i+1}: {c.get('activity')} ({len(text.split())}w)")

        if unload_after:
            try:
                requests.post(
                    f"{api_base_url.rstrip('/')}/api/generate",
                    json={"model": ollama_model, "keep_alive": 0},
                    timeout=8,
                )
            except Exception:
                pass

        neg = self.NEG.get(target_model, "")
        if style.get("negative_bias"):
            neg = f"{neg}, {style['negative_bias']}"

        joined = "\n\n---\n\n".join(f"[Shot {i+1}]\n{p}" for i, p in enumerate(prompts))
        return (
            json.dumps(prompts, indent=2, ensure_ascii=False),
            joined,
            prompts[0] if prompts else "",
            neg,
            len(prompts),
            "\n".join(log),
        )

    def _activity_block(self, contract, act_db):
        key = (contract.get("activity_key") or contract.get("activity") or "").lower().replace(" ", "_")
        entry = act_db.get(key)
        if not entry:
            for k, v in act_db.items():
                if k in key or key in k:
                    entry = v
                    key = k
                    break
        lines = [
            f"Activity key: {key}",
            f"Label: {contract.get('activity') or (entry or {}).get('label', key)}",
        ]
        if entry:
            lines.append(f"Sex type: {entry.get('sex_type', '')}")
            variants = entry.get("variants") or []
            vi = contract.get("variant_index")
            if contract.get("variant_text"):
                lines.append(f"USER-SELECTED VARIANT TEXT (use this action):\n{contract['variant_text']}")
            elif vi and variants:
                try:
                    idx = max(0, min(int(vi) - 1, len(variants) - 1))
                    lines.append(f"USER-SELECTED VARIANT #{vi}:\n{variants[idx]}")
                except Exception:
                    lines.append(
                        "Variant options:\n"
                        + "\n".join(f"  {i+1}. {v}" for i, v in enumerate(variants[:6]))
                    )
            elif variants:
                lines.append(
                    "Variant options (pick one coherent with intensity):\n"
                    + "\n".join(f"  {i+1}. {v}" for i, v in enumerate(variants[:6]))
                )
            fr = contract.get("framing") if isinstance(contract.get("framing"), dict) else (entry.get("framing") or {})
            if fr:
                lines.append("FRAMING COVERAGE (use cut shots, not continuous dollies):")
                lines.append(f"  Wide: {fr.get('wide', '')}")
                lines.append(f"  Body: {fr.get('body', '')}")
                lines.append(f"  Detail: {fr.get('detail', '')}")
            secs = contract.get("required_secondary_motions") or entry.get("secondaries") or []
            if secs:
                lines.append(
                    "SECONDARIES TO WEAVE (as/while/with every - do not list): "
                    + ", ".join(secs)
                )
            loras = entry.get("lora_triggers") or []
            if loras:
                lines.append("LORA TRIGGERS (use when matching model): " + ", ".join(loras))
            hooks = entry.get("dialogue_hooks") or []
            if hooks:
                lines.append("DIALOGUE HOOKS (optional, natural): " + " | ".join(hooks))
        else:
            if contract.get("variant_text"):
                lines.append(f"Action: {contract['variant_text']}")
            if contract.get("required_secondary_motions"):
                lines.append("Secondaries: " + ", ".join(contract["required_secondary_motions"]))
        lines.append(f"Intensity: {contract.get('intensity', 'medium')}")
        if contract.get("hint"):
            lines.append(f"Hint: {contract['hint']}")
        return "\n".join(lines)

    def _user_message(
        self,
        target_model,
        studio_name,
        style,
        environment,
        cast,
        cast_mode,
        contract,
        act_db,
        shot_index,
        total,
        continuation,
        previous,
        minimax_register,
        clip_duration,
        extra_instructions,
    ):
        if target_model == "wan22":
            fmt = (
                "FORMAT: **BOLD TITLE** on first line, then exact line k3nk4llin0n3, "
                "then ONE flowing paragraph 80-110 words. "
                "Secondary actions woven with as/while/with every. "
                "Coverage = cut shots (wide -> body -> detail), not continuous camera moves. "
                "End with quality seal. No moan text as on-screen words."
            )
        elif target_model == "ltx":
            fmt = (
                "FORMAT: single present-tense paragraph. "
                "Order: cut coverage -> setting/light -> cast -> position -> LoRA trigger at act start "
                "(d0gg1e, bl0wj0b, m15510n4ry, c0wg1rl, cunn1l1ngu5 when matching) -> "
                "physics -> short dialogue allowed -> layered audio -> "
                "quality phrases ending with LTXNUDES, FLW."
            )
        else:
            t1 = clip_duration * 0.34
            t2 = clip_duration * 0.67
            ts1 = f"00:{int(t1):02d}.{int((t1 % 1) * 1000):03d}"
            ts2 = f"00:{int(t2):02d}.{int((t2 % 1) * 1000):03d}"
            fmt = (
                f"FORMAT — MiniMax-H3 T2VA official skeleton ONLY (no LoRA required):\n"
                f"integrated_multimodal_description: [Shot 1] ... [Shot 2] At {ts1}, the camera cuts to ... "
                f"[Shot 3] At {ts2}, the camera cuts to ...\n\n"
                f"overall_soundscape: ...\n\n"
                f"non_diegetic_music: ...\n\n"
                f"Register: {minimax_register}. Clip duration: {clip_duration:.0f}s.\n"
                "HARD RULES:\n"
                "- [Shot 1] has NO timestamp. Later shots use At 00:SS.mmm, the camera cuts to ...\n"
                "- Cast described ONCE in Shot 1 flowing prose. Never re-list age/hair/cup in later shots.\n"
                "- Full nudity from frame 1.\n"
                "- Cut coverage: wide establish -> medium body action -> tight anatomy detail.\n"
                "- Dense secondaries every shot (breasts jiggle, lips stretch, toes curl, fingers dig, wet shine).\n"
                "- Dialogue form exact: The woman (S1) says: <d>[English] line.</d>\n"
                "- No meta labels (age-gap, vacuum of intimacy, cinematic pass).\n"
                "- No Action:/Secondary: tag lists. Weave into sentences.\n"
                "- No continuous dolly/orbit language.\n"
                "- overall_soundscape = ambience + physical sounds + non-verbal only.\n"
                "- non_diegetic_music = score or N/A if raw_candid_phone.\n"
                "- Output ONLY the three fields. No preamble."
            )

        parts = [
            f"Target model: {target_model}",
            fmt,
            f"Studio style: {studio_name}",
            f"Lighting: {style.get('lighting', '')}",
            f"Language tone: {style.get('language', '')}",
            f"Environment: {environment}",
            f"Cast mode: {cast_mode}",
            "",
            "=== LOCKED CAST (use these visual details) ===",
            cast,
            "",
            f"=== SHOT {shot_index + 1}/{total} ACTIVITY REQUIREMENTS (from database) ===",
            self._activity_block(contract, act_db),
        ]
        if cast_mode.startswith("solo"):
            parts.append("SOLO: exactly one performer. No partner.")
        if continuation and previous:
            parts += [
                "",
                "=== PREVIOUS PROMPT (continuity) ===",
                previous[:900],
                "Same performers and location; new activity only.",
            ]
        if nonempty(extra_instructions):
            parts += ["", "=== EXTRA INSTRUCTIONS ===", extra_instructions]
        parts += ["", "Output ONLY the finished prompt text. No preamble."]
        return "\n".join(parts)

    def _cast(self, locked_desc, scene):
        people = scene.get("participants") or []
        if people and isinstance(people, list) and isinstance(people[0], dict):
            bits = []
            for p in people:
                name = p.get("name", "Performer")
                age = p.get("age", "")
                gender = p.get("gender", "")
                phys = p.get("physical_description") or {}
                sexf = p.get("sexual_features") or {}
                line = f"{name}, {gender}, age {age}"
                for k in ("hair_color", "skin_tone", "build", "height"):
                    if phys.get(k):
                        line += f", {phys[k]}"
                if str(gender).lower() in ("female", "woman", "f"):
                    br = sexf.get("breasts") or {}
                    if isinstance(br, dict) and any(br.values()):
                        line += f"; {br.get('size','')} {br.get('shape','')} breasts"
                    vu = sexf.get("vulva") or {}
                    if isinstance(vu, dict) and vu.get("description"):
                        line += f"; {vu.get('description')} pussy"
                    line += "; fully nude"
                else:
                    pe = sexf.get("penis") or {}
                    if isinstance(pe, dict) and any(pe.values()):
                        line += f"; fully nude, {pe.get('length','')} {pe.get('girth','')} cock"
                    else:
                        line += "; fully nude"
                bits.append(line)
            return " | ".join(bits)
        if nonempty(locked_desc):
            lines = [
                ln.strip().lstrip("-")
                for ln in locked_desc.splitlines()
                if ln.strip() and not ln.upper().startswith("LOCKED")
            ]
            return " ".join(lines)[:500]
        return "Adult performers, fully nude."

    def _chat(self, requests, base, model, system, user, temperature, seed, keep_alive, log):
        opts = {"temperature": temperature}
        if seed:
            opts["seed"] = seed
        try:
            r = requests.post(
                f"{base.rstrip('/')}/api/chat",
                json={
                    "model": model,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                    "stream": False,
                    "options": opts,
                    "keep_alive": keep_alive,
                },
                timeout=180,
            )
            r.raise_for_status()
            data = r.json()
            return data.get("message", {}).get("content", "") or data.get("response", "")
        except Exception as e:
            log.append(f"Ollama error: {e}")
            return ""

    def _clean(self, raw, target_model):
        text = (raw or "").strip()
        text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.I)
        text = re.sub(r"```.*?```", "", text, flags=re.DOTALL)
        for m in ("Here's the prompt:", "Prompt:", "Final prompt:", "Here is the prompt:"):
            if m.lower() in text.lower():
                text = text[text.lower().find(m.lower()) + len(m) :].strip()
        text = text.strip().strip('"')
        if target_model == "ltx":
            for t in ("LTXNUDES", "FLW"):
                if t not in text:
                    text = text.rstrip() + f" {t}"
        if target_model == "wan22" and "hyper-realistic" not in text.lower():
            text = text.rstrip(".") + (
                ". hyper-realistic amateur footage, sharp skin texture and sweat details, "
                "natural grain, cinematic depth of field, high fidelity clarity, "
                "consistent lighting and shadows, no blur, no artifacts, stable high-quality motion."
            )
        if target_model == "minimax_h3":
            # ensure three fields exist; if model forgot wrappers, wrap best-effort
            low = text.lower()
            if "integrated_multimodal_description" not in low:
                text = "integrated_multimodal_description: " + text
            if "overall_soundscape" not in low:
                text = text.rstrip() + (
                    "\n\noverall_soundscape: Clean intimate mics — breath, wet contact, skin, "
                    "linen rustle, soft vocal reactions timed to motion."
                )
            if "non_diegetic_music" not in low:
                text = text.rstrip() + (
                    "\n\nnon_diegetic_music: Low warm ambient bed under the clip, soft lift mid-way, "
                    "gentle resolve at the end."
                )
            # strip common meta failures
            for bad in (
                "age-gap dynamic",
                "vacuum of intimacy",
                "creating a vacuum",
                "cinematic pass",
                "Studio cinematic pass",
            ):
                text = text.replace(bad, "")
        return text.strip()

    def _fallback_template(self, contract, cast, environment, target_model):
        act = contract.get("variant_text") or contract.get("activity") or "intimate action"
        return f"{cast} In {environment}. {act}. Intensity {contract.get('intensity', 'medium')}."

    def _rewrite_one(
        self, prompt_text, target_model, ollama_model, system_override,
        extra, temperature, seed, api_base_url, keep_alive, log,
    ):
        try:
            import requests
        except Exception:
            return prompt_text, "requests missing - pass-through"
        system = (
            system_override.strip()
            if nonempty(system_override)
            else load_system_prompt(self.PROMPT_FILES.get(target_model, "wan22_system.txt"))
            or "Rewrite the adult video prompt. Keep explicit. No repetition. Output only the prompt."
        )
        extra_mm = (
            "Rewrite to official MiniMax-H3 T2VA skeleton: "
            "integrated_multimodal_description with [Shot 1] (no timestamp), "
            "[Shot 2] At 00:SS.mmm the camera cuts to..., [Shot 3] At 00:SS.mmm the camera cuts to...; "
            "then overall_soundscape; then non_diegetic_music. "
            "Cast once in Shot 1 only. Dense physical secondaries. No meta. No repeated tags."
            if target_model == "minimax_h3"
            else (extra or "Rewrite cleaner. Keep explicit. Match the activity. No repetition.")
        )
        user = (
            f"Target: {target_model}\n"
            f"{extra_mm}\n\n"
            f"SOURCE:\n{prompt_text}\n\nOutput ONLY the improved prompt."
        )
        raw = self._chat(
            requests, api_base_url, ollama_model, system, user, temperature, seed, keep_alive, log
        )
        text = self._clean(raw, target_model)
        return (text or prompt_text), "rewrite path"

    # ── MiniMax structured path (reliable with small local models) ──

    def _mm_ts(self, seconds):
        s = max(0.0, float(seconds))
        whole = int(s)
        ms = int(round((s - whole) * 1000))
        if ms >= 1000:
            whole += 1
            ms = 0
        return f"00:{whole:02d}.{ms:03d}"

    def _mm_slots_prompt(self, cast, environment, act, fr, intensity, secs, hooks, register, duration, style, studio_name):
        """Ask LLM only for content slots — we own the skeleton."""
        sec_list = ", ".join(secs[:6]) if secs else "breasts move on impact, toes curl, fingers dig, wet shine"
        hook_list = " | ".join(hooks[:4]) if hooks else "Deeper… yes. | Don't stop. | Right there."
        light = (style or {}).get("lighting") or "practical lamps, soft cinematic key"
        return f"""You fill content slots for an explicit adult MiniMax-H3 video clip.
Output ONLY valid JSON. No markdown. No commentary. No extra keys.

Rules for slot text:
- Full explicit anatomical words: cock, pussy, clit, breasts, nipples, shaft, labia, tongue, hips.
- NEVER write bare measurements alone. Always pair size with the body part:
  GOOD: "his 5.5-inch thick cock slides into her pussy"
  BAD:  "5.5 inch length" / "5.5 inches creating tension"
- NEVER use soft euphemisms for genitals or penetration:
  BAD:  entrance, opening, womanhood, manhood, member, flower, folds (alone)
  GOOD: pussy, cock, shaft, clit, labia — e.g. "guides his cock into her pussy"
- Dense physical motion: jiggle, stretch, dig, curl, tremble, wet, thrust, grind.
- No meta labels (age-gap, vacuum of intimacy, cinematic pass, overall_intensity).
- No HTML tags. No <p> <s> <m>.
- Cast is ALREADY locked — do not re-describe age/hair/height in the slots.

LOCKED CAST (reference only, do not repeat as tags):
{cast}

ENVIRONMENT: {environment}
LIGHTING: {light}
STUDIO: {studio_name or "studio"}
REGISTER: {register}
DURATION: {duration:.0f}s
INTENSITY: {intensity}
MAIN ACTION (use this): {act}
FRAMING:
  wide: {fr.get("wide", "wide of the room and both bodies")}
  body: {fr.get("body", "medium full-body of the action")}
  detail: {fr.get("detail", "close insert on the point of contact")}
SECONDARIES TO USE: {sec_list}
DIALOGUE OPTIONS: {hook_list}

Return exactly this JSON shape:
{{
  "shot1_setup": "one sentence: opening posture and first contact using the main action (no cast re-list)",
  "shot1_physics": "one short clause of secondary physics for shot 1",
  "shot2_action": "two sentences: continuing the main action with clear body motion and secondaries",
  "shot2_dialogue": "one short English line only, no tags (e.g. Deeper... yes.)",
  "shot3_detail": "two sentences: extreme close contact anatomy, wetness, stretch, peak physical hold for intensity={intensity}",
  "soundscape": "one sentence: room tone + physical sex sounds + breath (no dialogue, no music)",
  "music": "one sentence score description OR the single token N/A if register is raw_candid_phone"
}}
"""

    def _mm_assemble(self, slots, cast, environment, fr, register, duration, style, act):
        """Own the official 3-field skeleton. LLM only filled slots."""
        light = (style or {}).get("lighting") or "practical lamps, soft cinematic key, controlled contrast"
        t1 = duration * 0.34
        t2 = duration * 0.67

        if register == "raw_candid_phone":
            style_open = (
                "Live-action, candid phone capture, grainy handheld with slight shake, "
                "edge softness, imperfect room light, voyeuristic closeness"
            )
        else:
            style_open = (
                f"Live-action, cinematic, practical film texture, shallow depth of field, "
                f"volumetric atmosphere, natural motion blur, controlled grain. Lighting: {light}"
            )

        s1_setup = (slots.get("shot1_setup") or act or "they begin intimate contact").strip()
        s1_phys = (slots.get("shot1_physics") or "skin meets skin, breath shortens").strip()
        s2_act = (slots.get("shot2_action") or act).strip()
        dlg_line = (slots.get("shot2_dialogue") or "Don't stop.").strip().strip('"')
        dlg_line = re.sub(r"</?d>", "", dlg_line, flags=re.I).strip()
        dlg_line = re.sub(r"^\[English\]\s*", "", dlg_line).strip()
        s3 = (slots.get("shot3_detail") or "tight detail on the point of contact, wetness and stretch visible").strip()
        sound = (slots.get("soundscape") or "room tone, wet contact, breath, linen rustle").strip()
        music = (slots.get("music") or "N/A").strip()
        if register == "raw_candid_phone":
            music = "N/A"

        def fix_measure(text):
            text = re.sub(
                r"\b(\d+(?:\.\d+)?)\s*-?\s*inch(?:es)?\s+length\b",
                r"his \1-inch thick cock",
                text,
                flags=re.I,
            )
            text = re.sub(
                r"\b(\d+(?:\.\d+)?)\s*-?\s*inch(?:es)?\s+creating\b",
                r"his \1-inch thick cock creating",
                text,
                flags=re.I,
            )
            text = re.sub(
                r"\b(his|her)\s+(\d+(?:\.\d+)?)\s*-?\s*inch(?:es)?\b(?!\s+(?:thick\s+)?(?:cock|penis|shaft|dildo|toy|strap))",
                r"\1 \2-inch thick cock",
                text,
                flags=re.I,
            )
            # Explicit anatomy — kill soft euphemisms
            replacements = [
                (r"\bher entrance\b", "her pussy"),
                (r"\bthe entrance\b", "her pussy"),
                (r"\bher opening\b", "her pussy"),
                (r"\bthe opening\b", "her pussy"),
                (r"\bher womanhood\b", "her pussy"),
                (r"\bhis manhood\b", "his cock"),
                (r"\bhis member\b", "his cock"),
                (r"\bhis length\b", "his cock"),
                (r"\bguides (?:his cock |it )?to her pussy\b", "guides his cock into her pussy"),
                (r"\bat her pussy\b(?! lips)", "into her pussy"),  # soft — only when awkward
            ]
            for pat, rep in replacements:
                text = re.sub(pat, rep, text, flags=re.I)
            # prefer "into her pussy" over "to her pussy" for penetration verbs
            text = re.sub(
                r"\b(guides|presses|pushes|slides|drives|puts|thrusts)\s+(his\s+(?:\d+(?:\.\d+)?-?inch\s+(?:thick\s+)?)?cock)\s+to\s+her\s+pussy\b",
                r"\1 \2 into her pussy",
                text,
                flags=re.I,
            )
            return text

        s1_setup, s1_phys, s2_act, s3 = map(fix_measure, (s1_setup, s1_phys, s2_act, s3))

        shot1 = (
            f"[Shot 1] {style_open}. "
            f"A wide shot frames {environment}. "
            f"{cast} Full nudity from frame 1. "
            f"{(fr.get('wide') or 'wide of the room and both bodies').rstrip('.')}. "
            f"{s1_setup} {s1_phys}"
        )
        shot2 = (
            f"[Shot 2] At {self._mm_ts(t1)}, the camera cuts to a medium full-body frame. "
            f"{(fr.get('body') or 'medium full-body of the action').rstrip('.')}. "
            f"{s2_act} "
            f"The woman (S1) says: <d>[English] {dlg_line}</d>"
        )
        shot3 = (
            f"[Shot 3] At {self._mm_ts(t2)}, the camera cuts to a tight detail insert. "
            f"{(fr.get('detail') or 'close insert on the point of contact').rstrip('.')}. "
            f"{s3} "
            f"Coverage is cut-based (wide to body to detail). No text, logos, or watermarks."
        )

        return (
            f"integrated_multimodal_description: {shot1} {shot2} {shot3}\n\n"
            f"overall_soundscape: {sound}\n\n"
            f"non_diegetic_music: {music}"
        )

    def _mm_parse_slots(self, raw):
        text = (raw or "").strip()
        text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.I)
        text = re.sub(r"```(?:json)?", "", text)
        text = text.replace("```", "").strip()
        m = re.search(r"\{[\s\S]*\}", text)
        if not m:
            return {}
        try:
            data = json.loads(m.group(0))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _mm_fallback_slots(self, act, intensity, secs, hooks):
        s = list(secs or []) + [
            "breasts move on impact",
            "toes curl",
            "fingers dig into skin",
            "wet shine on contact",
            "hips lift",
        ]
        hook = (hooks or ["Don't stop."])[0]
        peak = {
            "low": "the contact stays slow and deliberate through the final second",
            "medium": "the rhythm holds with clear physical reaction through the final second",
            "high": "impact, stretch, and breath peak through the final second",
            "peak": "body trembling, wet contact, breath breaking through the final second",
        }.get((intensity or "medium").lower(), "the physical state holds through the final second")
        return {
            "shot1_setup": act or "they press together in intimate contact",
            "shot1_physics": f"{s[0]}, {s[1]}",
            "shot2_action": f"The action continues: {act}. {s[2]}, {s[3]}.",
            "shot2_dialogue": hook,
            "shot3_detail": f"Tight detail on the point of contact, wetness and stretch visible. {s[4]}. {peak}.",
            "soundscape": "room tone, wet contact, skin, linen rustle, breath timed to motion",
            "music": "low warm ambient bed under the clip, soft lift mid-way, gentle resolve at the end",
        }

    def _generate_minimax_structured(
        self, requests, api_base, ollama_model, system, cast, environment, style,
        studio_name, contract, act_db, register, duration, temperature, seed, keep_alive, log,
    ):
        key = (contract.get("activity_key") or contract.get("activity") or "").lower().replace(" ", "_")
        entry = act_db.get(key) or {}
        if not entry:
            for k, v in act_db.items():
                if k in key or key in k:
                    entry = v
                    break
        variants = entry.get("variants") or []
        act = contract.get("variant_text")
        if not act and contract.get("variant_index") and variants:
            try:
                vi = max(0, min(int(contract["variant_index"]) - 1, len(variants) - 1))
                act = variants[vi]
            except Exception:
                act = variants[0] if variants else None
        if not act:
            act = variants[0] if variants else (contract.get("activity") or "intimate explicit contact")
        fr = contract.get("framing") if isinstance(contract.get("framing"), dict) else (entry.get("framing") or {})
        if not isinstance(fr, dict):
            fr = {}
        secs = list(contract.get("required_secondary_motions") or entry.get("secondaries") or [])
        hooks = list(entry.get("dialogue_hooks") or [])
        intensity = contract.get("intensity") or "medium"

        user = self._mm_slots_prompt(
            cast, environment, act, fr, intensity, secs, hooks, register, duration, style, studio_name
        )
        slot_system = (
            "You are a precise adult video content writer. "
            "Output ONLY a single JSON object with the requested keys. "
            "Use explicit anatomical language. Pair every measurement with the body part name "
            "(cock, shaft, pussy). No meta labels. No markdown."
        )
        raw = self._chat(
            requests, api_base, ollama_model, slot_system, user, temperature, seed, keep_alive, log
        )
        slots = self._mm_parse_slots(raw)
        if len(slots) < 4:
            log.append("MiniMax slots incomplete — using DB fallback slots")
            slots = self._mm_fallback_slots(act, intensity, secs, hooks)
        else:
            fb = self._mm_fallback_slots(act, intensity, secs, hooks)
            for k, v in fb.items():
                if not slots.get(k):
                    slots[k] = v
            log.append("MiniMax slots filled by Ollama, assembled by AVS")
        return self._mm_assemble(slots, cast, environment, fr, register, duration, style, act)




NODE_CLASS_MAPPINGS = {"AVS_Ollama": AVS_Ollama}
NODE_DISPLAY_NAME_MAPPINGS = {
    "AVS_Ollama": "AVS Ollama (full generate / optional rewrite)"
}
