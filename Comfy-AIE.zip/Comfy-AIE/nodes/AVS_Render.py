"""
AVS Render — template prompts following WAN / LTX / MiniMax system-prompt rules.
No Ollama. Optional polish is AVS_Ollama.
"""

import json
import re
import random
from datetime import datetime

from ..avs_core.utils import parse_json_safe, nonempty
from ..avs_core.studio import load_activities_db


class AVS_Render:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "target_model": (["wan22", "ltx", "minimax_h3"], {"default": "wan22"}),
                "scene_json": ("STRING", {"multiline": True, "default": "{}"}),
                "shot_contracts_json": ("STRING", {"multiline": True, "default": "{}"}),
            },
            "optional": {
                "locked_desc": ("STRING", {"multiline": True, "default": ""}),
                "mode": (["independent", "continuation"], {"default": "independent"}),
                "minimax_register": (["studio_cinematic", "raw_candid_phone"], {"default": "studio_cinematic"}),
                "clip_duration": ("FLOAT", {"default": 6.0, "min": 3.0, "max": 12.0, "step": 0.5}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffffffff}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING", "INT", "STRING")
    RETURN_NAMES = (
        "prompts_array_json",
        "prompts_text",
        "first_prompt",
        "negative_prompt",
        "shot_count",
        "log",
    )
    FUNCTION = "render"
    CATEGORY = "AVS"

    NEG = {
        "wan22": (
            "blurry, floating limbs, missing genitals, duplicated anatomy, awkward joints, "
            "ghosting, generative errors, deformed, extra limbs, text, watermark"
        ),
        "ltx": "blurry, low quality, deformed, extra limbs, bad anatomy, text, watermark, cartoon, anime",
        "minimax_h3": "blurry, deformed, extra limbs, bad anatomy, text, watermark, low quality, subtitles, logos",
    }

    WAN_CAMERAS = [
        "slow dolly push-in",
        "slow pan left to right",
        "slow tilt up",
        "slow circular orbit around",
        "slow tracking follow",
    ]
    WAN_SEAL = (
        "hyper-realistic amateur footage, sharp skin texture and sweat details, natural grain, "
        "cinematic depth of field, high fidelity clarity, consistent lighting and shadows, "
        "no blur, no artifacts, stable high-quality motion."
    )

    LTX_LORA = {
        "doggy": "d0gg1e",
        "doggy style": "d0gg1e",
        "blowjob": "bl0wj0b",
        "oral": "bl0wj0b",
        "missionary": "m15510n4ry",
        "cowgirl": "c0wg1rl",
        "reverse cowgirl": "c0wg1rl",
        "lotus": "having sex",
        "cunnilingus": "cunn1l1ngu5",
        "solo_male_stroke": "cock stroking",
        "solo_male_edge": "cock stroking",
        "solo_male_finish": "cock stroking",
    }
    LTX_SEAL = (
        "hyperrealistic skin texture with ultra detailed pores and imperfections, glistening sweat droplets, "
        "natural heavy breast physics with realistic jiggle and bounce, realistic ass ripple and impact jiggle, "
        "deep penetration stretch with visible labia grip, intense pleasure face with eyes rolling back and "
        "furrowed brow ecstasy, fluid temporal consistency, LTXNUDES, FLW"
    )

    ACT = {
        "foreplay": {
            "couple": (
                "they press together fully nude, mouths hungry, hands mapping skin — "
                "her palms on his chest while his fingers trace her hip and the outer lips of her pussy without entering yet"
            ),
            "solo_female": (
                "she reclines fully nude, both hands sliding over her skin, "
                "cupping her breasts then drifting down to part her thighs"
            ),
            "solo_male": (
                "he sits fully nude, one hand wrapping the shaft of his cock in a slow exploratory stroke"
            ),
        },
        "blowjob": {
            "couple": (
                "she kneels between his legs and takes his cock into her mouth — "
                "lips stretched around the shaft, tongue working the underside, one hand stroking the base "
                "while his fingers rest in her hair without forcing"
            ),
            "solo_female": "she wets her fingers with her mouth before guiding them between her legs",
            "solo_male": "close on his fist stroking the shaft, thumb sweeping the head each upstroke",
        },
        "missionary": {
            "couple": (
                "he settles between her open thighs in missionary, cock sinking into her pussy — "
                "labia gripping the shaft, her knees drawn up, his weight on his forearms as he drives steady strokes"
            ),
            "solo_female": "on her back thighs wide, two fingers pumping her pussy while her thumb works her clit",
            "solo_male": "on his back, both hands stroking, hips lifting into his fist",
        },
        "doggy": {
            "couple": (
                "she is on all fours as he takes her from behind — "
                "hands locked on her hips, cock driving into her pussy, each thrust sending a ripple through her ass"
            ),
            "solo_female": "chest down ass up, reaching back to fuck herself with fingers or a toy",
            "solo_male": "kneeling upright, hard strokes, free hand under his balls",
        },
        "cowgirl": {
            "couple": (
                "she straddles him facing forward and sinks onto his cock — "
                "riding with controlled rolls of her hips, hands on his chest, breasts moving with every drop"
            ),
            "solo_female": "she straddles a pillow and grinds her full weight down onto her clit and pussy",
            "solo_male": "seated upright stroking with both hands, abs flexed",
        },
        "reverse cowgirl": {
            "couple": (
                "she straddles him facing away, ass toward his chest, sliding down onto his cock and riding with a steady bounce"
            ),
            "solo_female": "straddling a toy facing away from camera, grinding down",
            "solo_male": "seated, angled to camera, long strokes",
        },
        "lotus": {
            "couple": (
                "seated face-to-face in lotus, her legs wrapped around his waist, "
                "bodies flush as they rock with his cock buried inside her"
            ),
            "solo_female": "seated upright, legs open, both hands busy between her thighs",
            "solo_male": "seated, slow deliberate strokes, jaw tight",
        },
        "standing": {
            "couple": (
                "standing sex — her back to the wall or bent for entry, "
                "his hands at her hips as he thrusts up into her"
            ),
            "solo_female": "standing with one foot raised, fingers working her pussy",
            "solo_male": "standing against the wall, full-length strokes",
        },
        "solo_female_fingering": {
            "solo_female": (
                "two fingers slide deep into her wet pussy while her thumb circles her clit — "
                "free hand on her breast, hips lifting into her own hand"
            ),
        },
        "solo_female_clit": {
            "solo_female": "fingertips rub her clit in tight focused circles, thighs trembling, free hand on her breast",
        },
        "solo_female_toy": {
            "solo_female": (
                "she guides a toy into her pussy and works a firm rhythm, free hand on her clit, "
                "breasts shifting with each thrust of her arm"
            ),
        },
        "solo_female_finish": {
            "solo_female": (
                "orgasm breaks — hips bucking, core clamping around her fingers, thighs shaking, toes curling"
            ),
        },
        "solo_male_stroke": {
            "solo_male": (
                "his fist strokes the shaft in a steady rhythm, thumb over the head on each upstroke, "
                "free hand cupping his balls"
            ),
        },
        "solo_male_edge": {
            "solo_male": "tight slow strokes bring him to the edge — he pauses, abs flexed, jaw locked — then resumes",
        },
        "solo_male_finish": {
            "solo_male": "fast strokes through climax, hips jerking, thick white release landing on his stomach",
        },
    }

    SEC_F = [
        "her breasts jiggle with the rhythm",
        "her toes curl against the sheets",
        "her free hand fists the linen",
        "her thighs tremble on each pass",
        "her head tips back",
        "sweat shines on her collarbone",
    ]
    SEC_M = [
        "his abs flex with every thrust",
        "his jaw tightens",
        "his fingers dig into her hip",
        "his thighs brace",
        "sweat runs down his chest",
        "his grip tightens then eases",
    ]
    SEC_SOLO_F = [
        "her breasts shift with each breath",
        "her toes curl",
        "her free hand grips the sheet",
        "her thighs tremble",
        "her belly tenses",
        "her head tips back",
    ]
    SEC_SOLO_M = [
        "his abs flex",
        "his jaw clenches",
        "his toes curl",
        "his free hand tightens on his balls",
        "his hips lift into his fist",
        "sweat beads on his chest",
    ]

    def render(
        self,
        target_model,
        scene_json,
        shot_contracts_json,
        locked_desc="",
        mode="independent",
        minimax_register="studio_cinematic",
        clip_duration=6.0,
        seed=0,
    ):
        log = [f"[{datetime.now().isoformat()}] template={target_model}"]
        rng = random.Random(seed) if seed else random.Random(42)

        scene = parse_json_safe(scene_json, {}) or {}
        wrap = parse_json_safe(shot_contracts_json, {}) or {}
        contracts = wrap.get("shot_contracts") if isinstance(wrap, dict) else wrap
        if not isinstance(contracts, list) or not contracts:
            msg = "No shot contracts — connect AVS Scene."
            return ("[]", msg, msg, self.NEG[target_model], 0, msg)

        style = scene.get("style") or {}
        environment = scene.get("environment") or "intimate room"
        cast_mode = scene.get("cast_mode") or "couple"
        cast = self._cast(locked_desc, scene)

        prompts = []
        for i, c in enumerate(contracts):
            if not isinstance(c, dict):
                c = {}
            cont = mode == "continuation" and i > 0
            if target_model == "wan22":
                text = self._wan(c, cast, cast_mode, environment, style, cont, rng)
            elif target_model == "ltx":
                text = self._ltx(c, cast, cast_mode, environment, style, cont, rng)
            else:
                text = self._minimax(
                    c, cast, cast_mode, environment, style, minimax_register, cont, rng, clip_duration
                )
            if not text.strip():
                text = f"{cast} {environment}. {c.get('activity', 'action')}."
            prompts.append(text)
            log.append(f"Shot {i+1}: {c.get('activity')} ({len(text.split())}w)")

        neg = self.NEG[target_model]
        if style.get("negative_bias"):
            neg = f"{neg}, {style['negative_bias']}"

        joined = "\n\n———\n\n".join(f"[Shot {i+1}]\n{p}" for i, p in enumerate(prompts))
        return (
            json.dumps(prompts, indent=2, ensure_ascii=False),
            joined,
            prompts[0],
            neg,
            len(prompts),
            "\n".join(log),
        )

    # ----- cast -----

    def _cast(self, locked_desc, scene):
        people = scene.get("participants") or []
        if people and isinstance(people, list) and isinstance(people[0], dict):
            return " ".join(self._person_prose(p) for p in people if isinstance(p, dict))
        if nonempty(locked_desc):
            lines = []
            for line in locked_desc.splitlines():
                line = line.strip().lstrip("-").strip()
                if not line or line.upper().startswith("LOCKED"):
                    continue
                line = (
                    line.replace("breasts: size ", "")
                    .replace("vulva: description ", "pussy ")
                    .replace("cock: length ", "cock ")
                    .replace(", shape ", ", ")
                )
                lines.append(line)
            text = " ".join(lines) if lines else locked_desc.strip()
            return text[:420].rsplit(" ", 1)[0] + "." if len(text) > 420 else text
        return "Adult performers, fully nude."

    def _person_prose(self, p: dict) -> str:
        name = p.get("name") or "Performer"
        gender = (p.get("gender") or "").lower()
        age = p.get("age")
        phys = p.get("physical_description") or {}
        sexf = p.get("sexual_features") or {}
        bits = [name]
        if age:
            bits.append(f"age {age}")
        for k in ("hair_color", "skin_tone", "build", "height"):
            if phys.get(k):
                bits.append(str(phys[k]))
        core = ", ".join(str(b) for b in bits)
        detail = []
        if gender in ("female", "woman", "f"):
            br = sexf.get("breasts") or {}
            if isinstance(br, dict) and any(br.values()):
                detail.append(
                    f"{br.get('size', '')} {br.get('shape', '')} breasts, {br.get('nipples', '')} nipples".strip()
                )
            vu = sexf.get("vulva") or {}
            if isinstance(vu, dict) and any(vu.values()):
                detail.append(
                    f"{vu.get('description', '')} pussy"
                    + (f", {vu.get('clitoris')} clit" if vu.get("clitoris") else "")
                )
            detail.append("fully nude")
        else:
            pe = sexf.get("penis") or {}
            if isinstance(pe, dict) and any(pe.values()):
                detail.append(
                    f"fully nude, {pe.get('length', '')} {pe.get('girth', '')} cock, "
                    f"{pe.get('head', '')} head".replace("  ", " ").strip()
                )
            else:
                detail.append("fully nude")
        return f"{core}; {'; '.join(d for d in detail if d)}.".replace(" ;", ";")

    # ----- shared -----

    def _mode_key(self, cast_mode):
        if str(cast_mode).startswith("solo_female"):
            return "solo_female"
        if str(cast_mode).startswith("solo_male"):
            return "solo_male"
        return "couple"


    def _activity_entry(self, contract):
        db = getattr(self, "_act_db", None)
        if db is None:
            self._act_db = load_activities_db()
            db = self._act_db
        raw = (contract.get("activity_key") or contract.get("activity") or "foreplay").lower().strip()
        raw = raw.replace(" ", "_")
        # direct
        if raw in db:
            return raw, db[raw]
        # fuzzy
        for k, v in db.items():
            if k in raw or raw in k or (v.get("label") or "").lower() in raw:
                return k, v
        # label match without underscore
        for k, v in db.items():
            if (v.get("label") or "").lower() == raw.replace("_", " "):
                return k, v
        return "foreplay", db.get("foreplay") or {}

    def _act(self, contract, cast_mode):
        key, entry = self._activity_entry(contract)
        variants = entry.get("variants") or []
        mk = self._mode_key(cast_mode)
        if cast_mode == "girls_only":
            mk = "couple"  # two performers, no male lines by default
        # filter variants that mention solo-inappropriate if needed — use all for now
        if not variants:
            return f"explicit {entry.get('label', key)} action"
        return variants[0]  # default; callers should use _variant for seed pick

    def _variant(self, contract, cast_mode, rng):
        # User-picked text on the contract wins (from AVS Sequence)
        if contract.get("variant_text"):
            return str(contract["variant_text"])
        key, entry = self._activity_entry(contract)
        variants = list(entry.get("variants") or [])
        if not variants:
            return f"explicit {entry.get('label', key)} action"
        # User-picked 1-based index
        if contract.get("variant_index"):
            try:
                vi = int(contract["variant_index"]) - 1
                vi = max(0, min(vi, len(variants) - 1))
                return variants[vi]
            except Exception:
                pass
        # fallback first variant (NOT random — deterministic default)
        return variants[0]

    def _framing(self, contract):
        fr = contract.get("framing") if isinstance(contract.get("framing"), dict) else {}
        if not fr:
            key, entry = self._activity_entry(contract)
            fr = entry.get("framing") or {}
        return {
            "wide": fr.get("wide") or "wide shot of the full room and both bodies",
            "body": fr.get("body") or "medium full-body framing of the action",
            "detail": fr.get("detail") or "close insert on the point of contact",
        }

    def _secs_db(self, contract, cast_mode, rng, n=3):
        key, entry = self._activity_entry(contract)
        custom = list(entry.get("secondaries") or [])
        # merge with generic pools
        mk = self._mode_key(cast_mode)
        if mk == "solo_female":
            pool = custom + list(self.SEC_SOLO_F)
        elif mk == "solo_male":
            pool = custom + list(self.SEC_SOLO_M)
        else:
            pool = custom + list(self.SEC_F) + list(self.SEC_M)
        # unique preserve order
        seen = set()
        uniq = []
        for s in pool:
            if s and s not in seen:
                seen.add(s)
                uniq.append(s)
        rng.shuffle(uniq)
        return uniq[:n]

    def _weave(self, secs):

        if not secs:
            return ""
        if len(secs) == 1:
            return f"as {secs[0]}"
        if len(secs) == 2:
            return f"as {secs[0]}, while {secs[1]}"
        return f"as {secs[0]}, while {secs[1]}, with every motion {secs[2]}"


    def _required_visible(self, contract):
        req = (contract.get("required_visible") or "").strip()
        if req:
            return req
        key, entry = self._activity_entry(contract)
        return (entry.get("required_visible") or "").strip()

    def _lexicon(self, contract):
        lex = contract.get("lexicon")
        if isinstance(lex, list) and lex:
            return [str(x) for x in lex if x]
        key, entry = self._activity_entry(contract)
        lex = entry.get("lexicon") or []
        return [str(x) for x in lex if x]

    def _act_core(self, contract, cast_mode, rng):
        """Layout variant + required_visible + lexicon contact when LoRA/trigger active."""
        act = self._variant(contract, cast_mode, rng)
        req = self._required_visible(contract)
        act_l = act.lower()

        # Enforce required_visible anatomy if missing
        if req:
            req_l = req.lower()
            tokens = [
                t for t in (
                    "cock", "pussy", "clit", "asshole", "mouth", "lips", "tongue",
                    "strapon", "dildo", "breasts", "cum", "fingers",
                )
                if t in req_l
            ]
            if not (tokens and any(t in act_l for t in tokens)):
                act = f"{act.rstrip('.')} — visible: {req}."
                act_l = act.lower()

        # When trigger/LoRA present, inject 1–2 missing lexicon phrases (training-like words)
        lead = (contract.get("lora_phrase") or "") or ""
        trigs = contract.get("lora_triggers") or []
        has_trigger = bool(lead) or (isinstance(trigs, list) and len(trigs) > 0)
        if has_trigger:
            lex = self._lexicon(contract)
            missing = []
            for phrase in lex:
                # consider present if main content words overlap heavily
                pl = phrase.lower()
                # simple containment or key noun overlap
                if pl in act_l:
                    continue
                words = [w for w in re.findall(r"[a-z]+", pl) if len(w) > 3]
                if words and sum(1 for w in words if w in act_l) >= max(1, len(words) - 1):
                    continue
                missing.append(phrase)
                if len(missing) >= 2:
                    break
            if missing:
                act = f"{act.rstrip('.')} {', '.join(missing)}."

        return act

    def _secs_prefer_contract(self, contract, cast_mode, rng, n=3):
        """Prefer secondaries from contract/DB; fill from pools only if short."""
        secs = list(contract.get("secondaries") or contract.get("required_secondary_motions") or [])
        if len(secs) >= n:
            return secs[:n]
        extra = self._secs_db(contract, cast_mode, rng, n=n)
        out = []
        seen = set()
        for s in secs + extra:
            if s and s not in seen:
                seen.add(s)
                out.append(s)
            if len(out) >= n:
                break
        return out

    def _trigger_lead(self, contract):
        """LoRA trigger first when present."""
        phrase = (contract.get("lora_phrase") or "").strip()
        if phrase:
            return phrase
        trigs = contract.get("lora_triggers") or []
        if isinstance(trigs, list) and trigs:
            return str(trigs[0])
        return self._ltx_trigger(contract)

    def _ltx_trigger(self, contract):
        key, entry = self._activity_entry(contract)
        loras = entry.get("lora_triggers") or []
        if loras:
            # primary token + one natural phrase if present
            primary = loras[0]
            if len(loras) > 1 and not loras[1].startswith(primary[:3]):
                return f"{primary}, {loras[1]}"
            return primary
        raw = (contract.get("activity_key") or contract.get("activity") or "").lower()
        for k, v in self.LTX_LORA.items():
            if k in raw:
                return v
        return "having sex"


    def _dialogue(self, contract, cast_mode, rng):
        """Sparse but intelligent dialogue. Specific sensation/role lines OK; no spam."""
        intensity = (contract.get("intensity") or "medium").lower()
        act = (contract.get("activity_key") or contract.get("activity") or "").lower()
        people = contract.get("participants_involved") or []
        # Infer age-gap / role from scene locked_desc or environment hints in contract
        blob = " ".join(
            str(x)
            for x in (
                contract.get("variant_text"),
                contract.get("hint"),
                contract.get("story_beat"),
                act,
            )
            if x
        ).lower()
        age_gap = any(
            w in blob
            for w in ("uncle", "older", "silver", "age", "72", "65", "grandpa", "sir")
        )

        talk_ok = any(
            x in act
            for x in (
                "foreplay",
                "tease",
                "lingerie",
                "domme",
                "strapon_domme",
                "body_worship",
                "missionary",
                "cowgirl",
                "doggy",
                "blowjob",
                "deepthroat",
                "handjob",
            )
        )

        # Often stay non-verbal
        if intensity in ("low",) and rng.random() < 0.55:
            return ""
        if intensity in ("medium", "high", "peak") and rng.random() < 0.40:
            return ""

        soft = [
            'She whispers, "Slow."',
            'She breathes, "There."',
            'She murmurs, "Like that."',
            'Quiet: "Stay."',
        ]
        sensation = [
            'She strains, "I can feel you."',
            'Breathy: "You\'re so deep."',
            'She whispers, "I can feel you inside me."',
            'Soft: "Right there."',
            'She gasps, "Don\'t stop."',
        ]
        age_gap_lines = [
            'She breathes, "Ohh uncle... you\'re so deep, I can feel you inside me."',
            'Whispered: "Uncle... stay inside."',
            'Soft and broken: "You\'re so deep..."',
        ]
        edge = [
            'She strains, "I\'m close..."',
            'Broken: "I\'m..."',
            "Her voice catches on a short sound.",
        ]
        setup = [
            'She says softly, "Come in."',
            'She smiles, "Sit."',
            'Quiet: "Look at me."',
        ]
        oral = [
            "Only wet sounds and her muffled breath around him.",
            'She pulls off just enough to breathe, "Like that."',
        ]

        if "foreplay" in act or "tease" in act or "lingerie" in act:
            pool = setup + soft
        elif any(x in act for x in ("blowjob", "deepthroat")):
            pool = oral + soft
        elif age_gap and intensity in ("medium", "high", "peak"):
            pool = age_gap_lines + sensation + soft
        elif intensity in ("high", "peak"):
            pool = sensation + edge + soft
        else:
            pool = soft + sensation

        # Prefer specific lines more often at high intensity
        if intensity in ("high", "peak") and age_gap and rng.random() < 0.55:
            return rng.choice(age_gap_lines)
        if intensity in ("high", "peak") and rng.random() < 0.5:
            return rng.choice(sensation)

        return rng.choice(pool)


    def _music(self, register, intensity, duration_s=6.0):
        if register == "raw_candid_phone":
            return "non_diegetic_music: N/A"
        if intensity in ("peak", "high"):
            return (
                f"non_diegetic_music: Low warm bass pulse under the opening, soft percussive lift at mid-clip, "
                f"fuller swell into the final second, resolving toward the hold at {duration_s:.1f}s."
            )
        return (
            f"non_diegetic_music: Sparse intimate ambient bed, soft pad and barely-there pulse, "
            f"gentle accent near mid-clip, near-quiet under the final hold at {duration_s:.1f}s."
        )

    # ----- model builders -----


    def _wan(self, contract, cast, cast_mode, environment, style, continuation, rng):
        activity = contract.get("activity") or "act"
        title = f"**{str(activity).replace('_', ' ').title()} — Close Heat**"
        act = self._act_core(contract, cast_mode, rng)
        secs = self._secs_prefer_contract(contract, cast_mode, rng, 3)
        weave = self._weave(secs)
        fr = self._framing(contract)
        loc = environment.split(";")[0].strip() if environment else "dim bedroom"
        cont = "Continuing with exact same performers: " if continuation else ""
        # Coverage language: cuts, not continuous moves
        coverage = (
            f"Coverage cuts from a {fr['wide']}, then a {fr['body']}, "
            f"then a {fr['detail']}."
        )
        body = (
            f"{cont}{cast} "
            f"In {loc} — {environment}. Full nudity from the first frame. "
            f"{act}, {weave}. "
            f"{coverage} "
            f"{self.WAN_SEAL}"
        )
        words = body.split()
        if len(words) > 115:
            body = " ".join(words[:112]) + "."
        return f"{title}\nk3nk4llin0n3\n{body}"

    def _ltx(self, contract, cast, cast_mode, environment, style, continuation, rng):
        """
        Official LTX guide: one chronological present-tense paragraph.
        Multi-shot uses named transitions in prose (hard cut / view cuts to),
        not [Shot N] labels. Prefer 2-4 shots: wide → body → detail.
        """
        light = style.get("lighting") or "warm practical lamps with soft cinematic falloff and controlled shadow play"
        act = self._act_core(contract, cast_mode, rng)
        trigger = self._trigger_lead(contract)
        secs = self._secs_prefer_contract(contract, cast_mode, rng, 3)
        intensity = contract.get("intensity") or "medium"
        fluid = contract.get("fluid_state") or "skin already slick with sweat and arousal"
        dialogue = self._dialogue(contract, cast_mode, rng)
        fr = self._framing(contract)
        phrase = self._trigger_lead(contract)
        if phrase in ("having sex", ""):
            phrase = ""
        cont = (
            "The same performers remain in the same room; continuity of bodies and space is unbroken. "
            if continuation else ""
        )

        # Optional phrase trigger (pillow / strapon / etc.) early
        lead = f"{phrase} " if phrase else ""

        # Primary act trigger when action starts (after cast, before thrusting detail)
        trig_mid = f"{trigger} — " if trigger else ""

        # Dialogue woven into the action beat (user pattern), not a trailing script dump
        dlg = (dialogue or "").strip()
        dlg = re.sub(
            r"The woman \(S1\) says:\s*<d>(.*?)</d>",
            r"\1",
            dlg,
            flags=re.I | re.S,
        ).strip()
        dlg = re.sub(
            r"^(She whispers,|She breathes,|She murmurs,|She says softly,|She smiles,|She strains,|She gasps,|Breathy:|Whispered:|Quiet:|Broken:|Soft and broken:|Soft:)\s*",
            "",
            dlg,
            flags=re.I,
        ).strip().strip('"').strip("'")

        mid_voice = ""
        if dlg:
            mid_voice = (
                f' She arches into the motion, voice breaking: "{dlg}"'
            )
            if intensity in ("high", "peak") and rng.random() < 0.4:
                mid_voice += ' He answers low against her skin, "So tight."'
        elif intensity in ("high", "peak") and rng.random() < 0.3:
            mid_voice = " She gasps, \"You're so deep... I can feel you inside me.\""

        # Continuous coverage by default. Hard cuts only if contract asks
        # (position change / impossible continuous coverage).
        use_cuts = bool(
            contract.get("use_hard_cuts")
            or contract.get("force_cuts")
            or (contract.get("coverage") or "").lower() in ("cut", "cuts", "multi_cut")
        )
        detail = fr.get("detail") or (
            "his cock sliding in and out of her pussy"
            if "oral" not in (contract.get("activity_key") or contract.get("activity") or "").lower()
            and "blow" not in (contract.get("activity_key") or contract.get("activity") or "").lower()
            else "her lips stretched around his veiny cock"
        )
        # Prefer explicit anatomy phrasing in detail
        detail = detail.replace("the join of their bodies", "his cock in her pussy")
        detail = detail.replace("tight on the join", "tight on his cock in her pussy")

        if use_cuts:
            body = (
                f"A wide shot frames {environment}, lighting {light}. "
                f"{cast} "
                f"The frame holds the full space as bodies settle into position. "
                f"Soft room tone and quiet fabric movement fill the air. "
                f"A hard cut transitions to a medium full-body shot: {trig_mid}{act}, "
                f"as {secs[0]}, while {secs[1]}, with every motion {secs[2]}."
                f"{mid_voice} "
                f"Wet contact and heavy breathing continue across the cut. "
                f"Another hard cut jumps to a close detail — {detail}; "
                f"rhythm builds from deliberate to {intensity}. {fluid}. "
            )
        else:
            # Continuous take (default): one flowing present-tense passage
            body = (
                f"An intimate medium shot holds {environment}, lighting {light}. "
                f"{cast} "
                f"{trig_mid}{act}, "
                f"as {secs[0]}, while {secs[1]}, with every motion {secs[2]}."
                f"{mid_voice} "
                f"The camera stays with them, easing closer on {detail}; "
                f"rhythm builds from deliberate to {intensity}. {fluid}. "
                f"Wet contact, skin, and heavy breath fill the room. "
            )

        return (
            f"{cont}{lead}{body}"
            f"Only wet friction, skin, breath, and linen remain between any spoken words; no score. "
            f"{self.LTX_SEAL}"
        )

    def _mm_ts(self, seconds):
        """Official H3 timestamp: 00:SS.mmm"""
        s = max(0.0, float(seconds))
        whole = int(s)
        ms = int(round((s - whole) * 1000))
        if ms >= 1000:
            whole += 1
            ms = 0
        return f"00:{whole:02d}.{ms:03d}"

    def _minimax(
        self, contract, cast, cast_mode, environment, style, register, continuation, rng, duration=6.0
    ):
        """
        Official MiniMax-H3 T2VA skeleton (no LoRA required):

          integrated_multimodal_description: [Shot 1] ... (no timestamp)
          [Shot 2] At 00:SS.mmm, the camera cuts to ...
          [Shot 3] At 00:SS.mmm, the camera cuts to ...

          overall_soundscape: ...

          non_diegetic_music: ...

        Rules applied from user MMH3 system prompt:
        - Full nudity from frame 1
        - Cast described once in flowing prose (Shot 1 only)
        - Dense micro-physical secondaries (breasts, stretch, toes, fingers)
        - Cut coverage wide → body → detail (not continuous moves)
        - Dialogue: The woman (S1) says: <d>[English] line</d>
        """
        intensity = (contract.get("intensity") or "medium").lower()
        act = self._act_core(contract, cast_mode, rng)
        secs = self._secs_db(contract, cast_mode, rng, 5)
        dialogue = self._dialogue(contract, cast_mode, rng)
        light = style.get("lighting") or "practical lamps, soft cinematic key, controlled contrast"
        fr = self._framing(contract)
        # cut budget: ~one cut per 2–3s inside total duration
        t1 = duration * 0.34
        t2 = duration * 0.67
        cont = (
            "Same performers, same room, same lighting palette as the previous clip. "
            if continuation else ""
        )

        # pick 4 distinct secondaries, force physical language
        s0 = secs[0] if len(secs) > 0 else "her breath shortens"
        s1 = secs[1] if len(secs) > 1 else "fingers dig into skin"
        s2 = secs[2] if len(secs) > 2 else "toes curl"
        s3 = secs[3] if len(secs) > 3 else "wet shine on contact"
        s4 = secs[4] if len(secs) > 4 else "muscle tension under skin"

        if register == "raw_candid_phone":
            style_open = (
                "Live-action, candid phone capture, grainy handheld with slight shake, "
                "edge softness, imperfect room light, voyeuristic closeness"
            )
            sound = (
                "overall_soundscape: Rough phone-mic room tone, wet impact synced to motion, "
                "unpolished breath, short vocal reactions, fabric rustle."
            )
            music = "non_diegetic_music: N/A"
        else:
            style_open = (
                f"Live-action, cinematic, practical film texture, shallow depth of field, "
                f"volumetric atmosphere, natural motion blur, controlled grain. Lighting: {light}"
            )
            sound = (
                "overall_soundscape: Clean intimate mics — breath, wet contact, skin, linen rustle, "
                "soft vocal reactions timed to motion; denser contact in the second half."
            )
            music = self._music(register, intensity, duration)

        # --- Shot 1: wide establish, cast once, first contact ---
        shot1 = (
            f"[Shot 1] {style_open}. "
            f"A wide shot frames {environment}. {cont}"
            f"{cast} "
            f"Full nudity from frame 1. "
            f"{fr['wide'].rstrip('.')}. "
            f"Opening posture and first contact for: {act}. "
            f"{s0.capitalize()}, {s1}."
        )

        # --- Shot 2: body action + dialogue ---
        shot2 = (
            f"[Shot 2] At {self._mm_ts(t1)}, the camera cuts to a medium full-body frame. "
            f"{fr['body'].rstrip('.')}. "
            f"The action continues: {act}. "
            f"Secondary motion is continuous and physical — {s2}, {s3}. "
            f"{dialogue}"
        )

        # --- Shot 3: detail anatomy insert, peak hold ---
        peak_phrase = {
            "low": "the contact stays slow and deliberate through the final second",
            "medium": "the rhythm holds steady with clear physical reaction through the final second",
            "high": "the intensity rises — impact, stretch, and breath peak through the final second",
            "peak": "the peak holds — body trembling, wet contact, breath breaking through the final second",
        }.get(intensity, "the physical state holds through the final second")

        shot3 = (
            f"[Shot 3] At {self._mm_ts(t2)}, the camera cuts to a tight detail insert. "
            f"{fr['detail'].rstrip('.')}. "
            f"Micro-detail on contact, wetness, and stretch. {s4.capitalize()}. "
            f"{peak_phrase}. "
            f"Coverage is cut-based (wide to body to detail); no continuous dolly or orbit. "
            f"No text, logos, or watermarks."
        )

        return (
            f"integrated_multimodal_description: {shot1} {shot2} {shot3}\n\n"
            f"{sound}\n\n"
            f"{music}"
        )




NODE_CLASS_MAPPINGS = {"AVS_Render": AVS_Render}
NODE_DISPLAY_NAME_MAPPINGS = {"AVS_Render": "AVS Render (template prompts)"}
