"""Pick one prompt string from Render outputs for ShowText / video nodes."""

import json
from ..avs_core.utils import parse_json_safe


class AVS_PickPrompt:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompts_array_json": ("STRING", {"multiline": True, "default": "[]"}),
                "shot_index": ("INT", {"default": 1, "min": 1, "max": 50}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "INT")
    RETURN_NAMES = ("prompt_text", "all_text", "count")
    FUNCTION = "pick"
    CATEGORY = "AVS"

    def pick(self, prompts_array_json, shot_index):
        data = parse_json_safe(prompts_array_json, [])
        if not isinstance(data, list):
            data = []
        # also accept list of dicts with "prompt"
        texts = []
        for item in data:
            if isinstance(item, str):
                texts.append(item)
            elif isinstance(item, dict) and item.get("prompt"):
                texts.append(str(item["prompt"]))
            else:
                texts.append(str(item))
        if not texts:
            empty = "(no prompts — run AVS Render first)"
            return (empty, empty, 0)
        idx = max(0, min(shot_index - 1, len(texts) - 1))
        chosen = texts[idx] if texts[idx].strip() else f"(empty shot {shot_index})"
        all_text = "\n\n———\n\n".join(f"[Shot {i+1}]\n{t}" for i, t in enumerate(texts))
        return (chosen, all_text, len(texts))


NODE_CLASS_MAPPINGS = {"AVS_PickPrompt": AVS_PickPrompt}
NODE_DISPLAY_NAME_MAPPINGS = {"AVS_PickPrompt": "AVS Pick Prompt"}
