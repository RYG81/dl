"""Compose a scene from studio + cast + archetype. No LLM."""

import json
from datetime import datetime
from ..avs_core.studio import (
    load_studios,
    load_archetypes,
    load_activity_presets,
    locked_desc,
)
from ..avs_core.utils import parse_json_safe


class AVS_Scene:
    @classmethod
    def INPUT_TYPES(cls):
        arches = load_archetypes()
        keys = list(arches.keys()) or ["couple_sensual"]
        return {
            "required": {
                "studio_id": ("STRING", {"default": "sexart"}),
                "participants_json": ("STRING", {"multiline": True}),
                "archetype": (keys, {"default": keys[0]}),
                "environment": ("STRING", {
                    "multiline": True,
                    "default": "Sunlit bedroom; soft linen; warm afternoon light",
                }),
                "num_shots": ("INT", {"default": 0, "min": 0, "max": 12}),
            },
            "optional": {
                "studio_json": ("STRING", {"multiline": True, "default": ""}),
                "custom_beat_ids": ("STRING", {
                    "default": "",
                    "multiline": False,
                }),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "INT", "STRING")
    RETURN_NAMES = (
        "scene_json",
        "shot_contracts_json",
        "locked_desc",
        "shot_count",
        "scene_log",
    )
    FUNCTION = "compose"
    CATEGORY = "AVS"

    def compose(
        self,
        studio_id,
        participants_json,
        archetype,
        environment,
        num_shots,
        studio_json="",
        custom_beat_ids="",
    ):
        log = []
        studios = load_studios()
        studio = parse_json_safe(studio_json, {}) if studio_json.strip() else studios.get(studio_id, {})
        if not studio:
            studio = studios.get(studio_id, {})

        arches = load_archetypes()
        arch = arches.get(archetype, {})
        beats = list(arch.get("beats") or [])
        if custom_beat_ids.strip():
            want = [b.strip() for b in custom_beat_ids.split(",") if b.strip()]
            filtered = [b for b in beats if b.get("id") in want]
            if filtered:
                beats = filtered

        if num_shots and num_shots > 0:
            beats = beats[:num_shots]
            while len(beats) < num_shots and beats:
                beats.append(beats[-1])

        people = parse_json_safe(participants_json, [])
        if isinstance(people, dict):
            people = [people]
        if not isinstance(people, list):
            people = []

        names = [p.get("name") for p in people if isinstance(p, dict) and p.get("name")]
        if not names:
            names = ["Performer"]

        presets = load_activity_presets()
        contracts = []
        for i, beat in enumerate(beats):
            act_key = beat.get("activity", "foreplay")
            ap = presets.get(act_key, {})
            contracts.append({
                "shot_number": i + 1,
                "beat_id": beat.get("id", f"beat_{i}"),
                "activity": ap.get("label", act_key),
                "activity_key": act_key,
                "position": ap.get("position", ""),
                "intensity": beat.get("intensity", "medium"),
                "hint": beat.get("hint", ""),
                "participants_involved": names,
                "required_organs": ap.get("required_organs", []),
                "required_secondary_motions": ap.get("secondary_actions", []),
                "required_camera_beats": ap.get("camera_beats", []),
                "facing_relative": ap.get("facing_relative", ""),
                "anchors_supports": ap.get("anchors_supports", ""),
                "grips_contact": ap.get("grips_contact", ""),
                "fluid_state": ap.get("fluid_state", ""),
                "environment": environment,
                "sex_type_context": ap.get("sex_type", arch.get("cast", "")),
                "word_count": 120,
                "studio_id": studio_id,
            })

        scene = {
            "studio_id": studio_id,
            "studio_name": studio.get("display_name", studio_id),
            "archetype": archetype,
            "archetype_label": arch.get("label", archetype),
            "cast_mode": arch.get("cast", "couple"),
            "environment": environment,
            "participants": people,
            "beats": beats,
            "style": {
                "lighting": studio.get("lighting", ""),
                "camera": studio.get("camera", ""),
                "pacing": studio.get("pacing", ""),
                "language": studio.get("language", ""),
                "audio_mood": studio.get("audio_mood", ""),
                "negative_bias": studio.get("negative_bias", ""),
                "model_hints": studio.get("model_hints", {}),
            },
            "created": datetime.now().isoformat(),
        }

        log.append(f"Studio: {scene['studio_name']}")
        log.append(f"Archetype: {scene['archetype_label']} ({len(contracts)} shots)")
        log.append(f"Cast: {', '.join(names)}")

        return (
            json.dumps(scene, indent=2, ensure_ascii=False),
            json.dumps({"shot_contracts": contracts}, indent=2, ensure_ascii=False),
            locked_desc(people),
            len(contracts),
            "\n".join(log),
        )


NODE_CLASS_MAPPINGS = {"AVS_Scene": AVS_Scene}
NODE_DISPLAY_NAME_MAPPINGS = {"AVS_Scene": "AVS Scene"}
