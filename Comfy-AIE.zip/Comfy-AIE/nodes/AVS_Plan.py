"""
AVS Plan Sequence — turn a natural-language story into a full shot sequence.

No manual activity:variant:intensity lines required.
Uses Ollama when available; falls back to a rule-based story planner.

Outputs the same scene_json + shot_contracts_json shape as AVS Sequence,
so you can wire Plan → Render / Ollama directly.
"""

from __future__ import annotations

import json
import re
from datetime import datetime

from ..avs_core.utils import parse_json_safe, nonempty
from ..avs_core.studio import load_activities_db, load_studios, locked_desc


# Keyword → default activity for offline planner
_RULES = [
    # order matters: more specific patterns first
    (r"\b(door|doorbell|invite|doorway|opens the door)\b", "foreplay", "low",
     "at the doorway: she smiles and invites him in"),
    (r"\b(looks around|posters?|cupboard|room tour|inspects the room|nude photo)\b", "body_worship", "low",
     "he looks around the room — adult posters, nude photo on the cupboard, glass dildo"),
    (r"\b(glass dildo|dildo|toy).{0,60}(lick|suck|mouth)\b", "solo_female_toy", "medium",
     "she slowly licks the glass dildo, moving it in and out of her mouth while he watches"),
    (r"\b(through (the )?boxers|inside his boxers|harder inside|rubs?.{0,30}boxers)\b", "handjob", "medium",
     "she kneels and rubs his hard cock through his boxers"),
    (r"\b(pulls? (down|off|his ).{0,20}boxers|removes? (his )?boxers|pulls his boxer)\b", "handjob", "medium",
     "she slowly pulls his boxers down and smiles"),
    (r"\b(deepthroat|deep throat)\b", "deepthroat", "high",
     "she licks his cock then takes him deepthroat"),
    (r"\b(blowjob|blow job|sucks? (his )?cock|licking his cock)\b", "blowjob", "high",
     "she licks and sucks his cock"),
    (r"\b(handjob|strokes? (his )?cock|rubs? (his )?cock)\b", "handjob", "medium", None),
    (r"\b(guides? (his )?cock (in|into) (her )?pussy|rubs? (her|his) pussy (over|on) (his )?cock)\b", "cowgirl", "high",
     "she rubs her pussy over his cock then guides his cock into her pussy"),
    (r"\b(cowgirl|rides? him|straddles?).{0,40}(facing|face to face|kiss)\b", "cowgirl", "high",
     "she rides him cowgirl facing him, his hands on her waist, kissing mouth to mouth"),
    (r"\b(reverse cowgirl)\b", "reverse_cowgirl", "high", None),
    (r"\b(cowgirl|rides? him|straddles?|removes? her robe).{0,30}(ride|robe)\b", "cowgirl", "high",
     "she straddles him and slowly removes her robe, throwing it on the floor"),
    (r"\b(cowgirl|rides? him|straddles?)\b", "cowgirl", "high", None),
    (r"\b(doggy|from behind|doggystyle)\b", "doggy", "high", None),
    (r"\b(missionary)\b", "missionary", "high", None),
    (r"\b(creampie|cum inside|finishes inside)\b", "creampie_missionary", "peak", None),
    (r"\b(facial|cum on (her )?face)\b", "facial", "peak", None),
    (r"\b(robe|exposing her breast)\b", "solo_lingerie_tease", "low",
     "she stands in a loose red robe tied open, breasts exposed"),
    (r"\b(kneels?|on (the )?bed edge|holds his hand)\b", "foreplay", "medium", None),
    (r"\b(kiss|make out|foreplay|sits? (him|her) on (the )?bed|lying on his back|pushes? (him )?back)\b", "foreplay", "low", None),
]


class AVS_Plan:
    @classmethod
    def INPUT_TYPES(cls):
        studios = list(load_studios().keys()) or ["sexart"]
        return {
            "required": {
                "story": ("STRING", {
                    "multiline": True,
                    "default": (
                        "Old man in boxers and open shirt at the door. Young woman invites him in, "
                        "leads him to her bedroom, seats him on the bed and leaves. He looks around: "
                        "adult posters, nude photo on the cupboard, used glass dildo. She returns in a "
                        "loose red rose robe exposing her breasts. She dims the light, licks the glass "
                        "dildo while he watches, kneels and rubs his cock through the boxers, pulls them "
                        "down, gives him a deepthroat blowjob, pushes him onto his back, removes her robe, "
                        "rubs her pussy on his cock, guides him into her pussy, and rides cowgirl facing "
                        "him while kissing his mouth and licking his chest."
                    ),
                }),
                "studio_id": (studios, {"default": studios[0]}),
            },
            "optional": {
                "participants_json": ("STRING", {"multiline": True, "default": ""}),
                "environment_hint": ("STRING", {
                    "multiline": True,
                    "default": "",
                }),
                "max_shots": ("INT", {"default": 14, "min": 3, "max": 24}),
                "use_ollama": ("BOOLEAN", {"default": True}),
                "ollama_model": ("STRING", {"default": "llama3.1:8b"}),
                "api_base_url": ("STRING", {"default": "http://localhost:11434"}),
                "temperature": ("FLOAT", {"default": 0.4, "min": 0.0, "max": 1.0, "step": 0.05}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xFFFFFFFFFFFFFFFF}),
                "scene_name": ("STRING", {"default": "Story Plan"}),
                "studio_json": ("STRING", {"multiline": True, "default": ""}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING", "STRING", "INT", "STRING")
    RETURN_NAMES = (
        "scene_json",
        "shot_contracts_json",
        "sequence_text",
        "sequence_summary",
        "environment",
        "shot_count",
        "log",
    )
    FUNCTION = "plan"
    CATEGORY = "AVS"

    def plan(
        self,
        story,
        studio_id,
        participants_json="",
        environment_hint="",
        max_shots=14,
        use_ollama=True,
        ollama_model="llama3.1:8b",
        api_base_url="http://localhost:11434",
        temperature=0.4,
        seed=0,
        scene_name="Story Plan",
        studio_json="",
    ):
        log = [f"[{datetime.now().isoformat()}] AVS Plan Sequence"]
        db = load_activities_db()
        studio = parse_json_safe(studio_json, {}) if studio_json.strip() else {}
        if not studio:
            studio = load_studios().get(studio_id, {}) or {}

        people = parse_json_safe(participants_json, [])
        if isinstance(people, dict):
            people = [people]
        if not isinstance(people, list):
            people = []
        names = [p.get("name") for p in people if isinstance(p, dict) and p.get("name")]
        if not names:
            names = ["Performer"]
        cast_mode = self._cast_mode(people)

        beats = []
        environment = (environment_hint or "").strip()
        source = "rules"

        if use_ollama:
            try:
                beats, environment, src_log = self._plan_ollama(
                    story, db, max_shots, environment_hint,
                    ollama_model, api_base_url, temperature, seed, cast_mode,
                )
                log.append(src_log)
                if beats:
                    source = "ollama"
            except Exception as e:
                log.append(f"Ollama plan failed: {e}")

        if not beats:
            beats, environment = self._plan_rules(story, db, max_shots, environment_hint)
            source = "rules"
            log.append(f"Rule planner produced {len(beats)} beats")

        if not environment:
            environment = self._default_environment(story)

        contracts = []
        seq_lines = []
        summary = []
        for i, beat in enumerate(beats[:max_shots]):
            act_key = self._resolve_key(beat.get("activity") or "foreplay", db)
            entry = db.get(act_key) or {}
            variants = entry.get("variants") or []
            vi = int(beat.get("variant_index") or 1)
            vi = max(1, min(vi, max(1, len(variants))))
            chosen = (beat.get("variant_text") or "").strip()
            if not chosen and variants:
                chosen = variants[vi - 1]
            if not chosen:
                chosen = entry.get("label") or act_key
            intensity = (beat.get("intensity") or "medium").lower()
            if intensity not in ("low", "medium", "high", "peak"):
                intensity = "medium"
            fr = entry.get("framing") or {}
            secs = entry.get("secondaries") or []

            contracts.append({
                "shot_number": i + 1,
                "activity": entry.get("label", act_key),
                "activity_key": act_key,
                "variant_index": vi,
                "variant_text": chosen,
                "position": act_key,
                "intensity": intensity,
                "hint": chosen[:160],
                "participants_involved": names,
                "required_secondary_motions": secs,
                "framing": fr,
                "environment": environment,
                "sex_type_context": entry.get("sex_type", ""),
                "word_count": 120,
                "studio_id": studio_id,
                "story_beat": (beat.get("story_beat") or "")[:200],
            })
            seq_lines.append(f"{act_key}:{vi}:{intensity}")
            summary.append(
                f"{i+1}. {act_key} v{vi} [{intensity}] — {chosen[:80]}"
                + ("…" if len(chosen) > 80 else "")
            )
            log.append(f"{i+1}. {act_key}:{vi}:{intensity} ({source})")

        scene = {
            "studio_id": studio_id,
            "studio_name": studio.get("display_name", studio_id),
            "archetype": "story_plan",
            "archetype_label": scene_name,
            "cast_mode": cast_mode,
            "environment": environment,
            "participants": people,
            "style": {
                "lighting": studio.get("lighting", ""),
                "camera": studio.get("camera", ""),
                "pacing": studio.get("pacing", ""),
                "language": studio.get("language", ""),
                "audio_mood": studio.get("audio_mood", ""),
                "negative_bias": studio.get("negative_bias", ""),
                "model_hints": studio.get("model_hints", {}),
            },
            "sequence_source": f"AVS_Plan/{source}",
            "story": story[:2000],
            "locked_desc": locked_desc(people) if people else "",
            "created": datetime.now().isoformat(),
        }

        return (
            json.dumps(scene, indent=2, ensure_ascii=False),
            json.dumps({"shot_contracts": contracts}, indent=2, ensure_ascii=False),
            "\n".join(seq_lines),
            "\n".join(summary) if summary else "(no shots)",
            environment,
            len(contracts),
            "\n".join(log),
        )

    # ── Ollama planner ──

    def _plan_ollama(
        self, story, db, max_shots, environment_hint,
        model, api_base, temperature, seed, cast_mode,
    ):
        import requests

        keys = sorted(db.keys())
        # compact catalog for the model
        catalog_lines = []
        for k in keys:
            e = db[k]
            n = len(e.get("variants") or [])
            catalog_lines.append(f"- {k} ({e.get('sex_type','')}, {n} variants): {e.get('label', k)}")
        catalog = "\n".join(catalog_lines)

        system = (
            "You are an adult video sequence planner for a local node pack. "
            "Map a story into ordered shot beats using ONLY the provided activity keys. "
            "Output ONLY valid JSON. No markdown. No commentary."
        )
        user = f"""Story:
{story}

Cast mode: {cast_mode}
Max shots: {max_shots}
Environment hint (optional): {environment_hint or "(derive from story)"}

Allowed activity keys (use these exact keys only):
{catalog}

Rules:
- Cover the story in order from setup → tease → sex → peak if present.
- Setup beats (door, look around, invite) use softcore keys: foreplay, body_worship, solo_lingerie_tease.
- Sex beats use explicit keys: blowjob, deepthroat, handjob, cowgirl, missionary, doggy, etc.
- intensity: low | medium | high | peak
- variant_index: 1-based integer
- variant_text: one explicit sentence for THIS beat (use cock/pussy not entrance/member). Clothing state must be clear until nude.
- Prefer 8–{max_shots} beats. Do not invent activity keys outside the list.

Return JSON:
{{
  "environment": "one continuous location description for all shots",
  "beats": [
    {{
      "activity": "exact_key_from_list",
      "variant_index": 1,
      "intensity": "low",
      "variant_text": "explicit action sentence for this beat",
      "story_beat": "short label"
    }}
  ]
}}
"""
        opts = {"temperature": temperature}
        if seed:
            opts["seed"] = seed
        r = requests.post(
            f"{api_base.rstrip('/')}/api/chat",
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "stream": False,
                "options": opts,
                "keep_alive": "5m",
            },
            timeout=180,
        )
        r.raise_for_status()
        raw = (r.json().get("message") or {}).get("content") or ""
        data = self._parse_json(raw)
        beats = data.get("beats") if isinstance(data, dict) else None
        if not isinstance(beats, list) or not beats:
            raise ValueError("no beats in Ollama JSON")
        env = (data.get("environment") or environment_hint or "").strip()
        # sanitize keys
        clean = []
        for b in beats:
            if not isinstance(b, dict):
                continue
            k = self._resolve_key(str(b.get("activity") or ""), db)
            if not k:
                continue
            clean.append({
                "activity": k,
                "variant_index": int(b.get("variant_index") or 1),
                "intensity": b.get("intensity") or "medium",
                "variant_text": (b.get("variant_text") or "").strip(),
                "story_beat": (b.get("story_beat") or "").strip(),
            })
        if not clean:
            raise ValueError("no valid activity keys")
        return clean, env, f"Ollama plan OK ({len(clean)} beats, model={model})"

    # ── Rule planner (no LLM) ──

    def _plan_rules(self, story, db, max_shots, environment_hint):
        text = story or ""
        # split on scene markers or sentences
        parts = re.split(
            r"(?:scene\s*\d+\s*[-–:]|cut to|then she|then he|\n+)",
            text,
            flags=re.I,
        )
        parts = [p.strip() for p in parts if p and len(p.strip()) > 8]
        if len(parts) < 2:
            # sentence split
            parts = re.split(r"(?<=[.!?])\s+", text)
            parts = [p.strip() for p in parts if len(p.strip()) > 12]

        beats = []
        used_spans = set()
        for part in parts:
            low = part.lower()
            matched = False
            for pat, act, intensity, forced_text in _RULES:
                if re.search(pat, low, flags=re.I):
                    # avoid duplicate consecutive same activity unless text differs a lot
                    if beats and beats[-1]["activity"] == act and beats[-1]["variant_text"][:40] == (forced_text or part)[:40]:
                        continue
                    key = self._resolve_key(act, db)
                    if not key:
                        continue
                    entry = db.get(key) or {}
                    variants = entry.get("variants") or []
                    vtext = forced_text or self._explicitize(part)
                    # if we have variants, still prefer story-specific text
                    beats.append({
                        "activity": key,
                        "variant_index": 1,
                        "intensity": intensity,
                        "variant_text": vtext[:300],
                        "story_beat": part[:80],
                    })
                    matched = True
                    break
            if not matched and len(part) > 20:
                # generic soft beat
                key = "foreplay" if "foreplay" in db else (sorted(db.keys())[0] if db else "foreplay")
                beats.append({
                    "activity": key,
                    "variant_index": 1,
                    "intensity": "medium",
                    "variant_text": self._explicitize(part)[:300],
                    "story_beat": part[:80],
                })
            if len(beats) >= max_shots:
                break

        if not beats:
            beats = [{
                "activity": "foreplay",
                "variant_index": 1,
                "intensity": "low",
                "variant_text": self._explicitize(story)[:300],
                "story_beat": "story",
            }]

        env = (environment_hint or "").strip() or self._default_environment(story)
        return beats[:max_shots], env

    def _default_environment(self, story):
        low = (story or "").lower()
        bits = []
        if "bedroom" in low or "bed" in low:
            bits.append("her bedroom with a bed and soft practical lighting")
        if "poster" in low:
            bits.append("adult movie posters on one wall")
        if "cupboard" in low or "dildo" in low or "photo" in low:
            bits.append("a cupboard with a nude photo and a glass dildo on top")
        if "door" in low:
            bits.append("doorway visible at the start")
        if not bits:
            bits.append("intimate bedroom; soft practical lamps; continuous location")
        return "; ".join(bits)

    def _explicitize(self, text):
        t = text.strip()
        t = re.sub(r"\bher entrance\b", "her pussy", t, flags=re.I)
        t = re.sub(r"\bhis manhood\b", "his cock", t, flags=re.I)
        t = re.sub(r"\bhis member\b", "his cock", t, flags=re.I)
        # fix common typo from user stories
        t = re.sub(r"\brubs? his pussy\b", "rubs her pussy", t, flags=re.I)
        t = re.sub(r"\b(her hand on )her cock\b", r"\1his cock", t, flags=re.I)
        t = re.sub(r"\brubs her hand on her cock\b", "rubs his cock", t, flags=re.I)
        return t

    def _resolve_key(self, raw, db):
        if not raw:
            return None
        k = raw.lower().strip().replace(" ", "_")
        if k in db:
            return k
        for key in db:
            if key in k or k in key:
                return key
            label = (db[key].get("label") or "").lower()
            if label and label == raw.lower().strip():
                return key
        return None

    def _cast_mode(self, people):
        if len(people) <= 1:
            g = (people[0].get("gender") or "").lower() if people else ""
            return "solo_male" if g in ("male", "man", "m") else "solo_female"
        genders = [(p.get("gender") or "").lower() for p in people if isinstance(p, dict)]
        females = sum(1 for g in genders if g in ("female", "woman", "f", "girl"))
        males = sum(1 for g in genders if g in ("male", "man", "m", "boy"))
        if females >= 2 and males == 0:
            return "girls_only"
        if males >= 2 and females == 0:
            return "boys_only"
        return "couple"

    def _parse_json(self, raw):
        text = (raw or "").strip()
        text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.I)
        text = re.sub(r"```(?:json)?", "", text).replace("```", "").strip()
        m = re.search(r"\{[\s\S]*\}", text)
        if not m:
            return {}
        try:
            return json.loads(m.group(0))
        except Exception:
            return {}


NODE_CLASS_MAPPINGS = {"AVS_Plan": AVS_Plan}
NODE_DISPLAY_NAME_MAPPINGS = {"AVS_Plan": "AVS Plan Sequence (story → shots)"}
