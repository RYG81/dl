"""
AVS Sequence Decider — user-defined shot sequence OR studio template.

Sequence format (one beat per line):
  activity
  activity:variant_index
  activity:variant_index:intensity

Or pick sequence_template to load a full spine, then edit.

Contracts pass to AVS_Render:
  variant_text, variant_index, required_visible, lora_triggers, secondaries, framing
"""

from __future__ import annotations

import json
from datetime import datetime

from ..avs_core.utils import parse_json_safe
from ..avs_core.studio import load_activities_db, load_studios, locked_desc


def _activity_keys():
    db = load_activities_db()
    return sorted(db.keys()) if db else ["foreplay"]


def _template_ids():
    from pathlib import Path
    p = Path(__file__).resolve().parents[1] / "data" / "sex_activities_db.json"
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
        t = raw.get("sequence_templates") or {}
        return ["(none)"] + sorted(t.keys())
    except Exception:
        return ["(none)"]


class AVS_Sequence:
    @classmethod
    def INPUT_TYPES(cls):
        keys = _activity_keys()
        studios = list(load_studios().keys()) or ["sexart"]
        templates = _template_ids()
        return {
            "required": {
                "sequence": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": (
                            "foreplay:1:low\n"
                            "blowjob:1:medium\n"
                            "missionary:1:high\n"
                            "doggy:1:high\n"
                            "creampie_missionary:1:peak"
                        ),
                    },
                ),
                "environment": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "Sunlit bedroom; soft linen; warm afternoon light",
                    },
                ),
                "studio_id": (studios, {"default": studios[0]}),
            },
            "optional": {
                "participants_json": ("STRING", {"multiline": True, "default": ""}),
                "scene_name": ("STRING", {"default": "Sequence"}),
                "studio_json": ("STRING", {"multiline": True, "default": ""}),
                "sequence_template": (templates, {"default": "(none)"}),
                "list_catalog": ("BOOLEAN", {"default": False}),
                "append_activity": (["(none)"] + keys, {"default": "(none)"}),
                "append_variant": ("INT", {"default": 1, "min": 1, "max": 40}),
                "append_intensity": (["low", "medium", "high", "peak"], {"default": "medium"}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING", "INT", "STRING")
    RETURN_NAMES = (
        "scene_json",
        "shot_contracts_json",
        "sequence_summary",
        "activity_catalog",
        "shot_count",
        "log",
    )
    FUNCTION = "decide"
    CATEGORY = "AVS"

    def decide(
        self,
        sequence,
        environment,
        studio_id,
        participants_json="",
        scene_name="Sequence",
        studio_json="",
        sequence_template="(none)",
        list_catalog=False,
        append_activity="(none)",
        append_variant=1,
        append_intensity="medium",
    ):
        db = load_activities_db()
        full = self._full_db()
        catalog = self._catalog(db)

        if list_catalog:
            return (
                "{}",
                '{"shot_contracts":[]}',
                "(catalog only)",
                catalog,
                0,
                "list_catalog=True — no contracts built",
            )

        seq_text = sequence.strip()
        log = [f"[{datetime.now().isoformat()}] Sequence Decider"]

        # Template loads spine (user can still edit sequence field next run)
        if sequence_template and sequence_template != "(none)":
            tmpl = (full.get("sequence_templates") or {}).get(sequence_template) or {}
            beats = tmpl.get("beats") or []
            if beats:
                seq_text = "\n".join(beats)
                log.append(f"template={sequence_template} ({tmpl.get('label', '')})")
                if tmpl.get("environment_default") and (
                    not environment
                    or environment.startswith("Sunlit bedroom")
                ):
                    environment = tmpl["environment_default"]

        if append_activity and append_activity != "(none)":
            line = f"{append_activity}:{append_variant}:{append_intensity}"
            seq_text = (seq_text + "\n" + line).strip() if seq_text else line

        lines = self._parse_lines(seq_text)
        if not lines:
            return (
                "{}",
                '{"shot_contracts":[]}',
                "empty sequence",
                catalog,
                0,
                "No beats — write sequence, pick template, or use append_activity",
            )

        studio = parse_json_safe(studio_json, {}) if studio_json.strip() else {}
        if not studio:
            studio = load_studios().get(studio_id, {})

        people = parse_json_safe(participants_json, [])
        if isinstance(people, dict):
            people = [people]
        if not isinstance(people, list):
            people = []
        names = [p.get("name") for p in people if isinstance(p, dict) and p.get("name")]
        if not names:
            names = ["Performer"]

        if len(people) <= 1:
            g = (people[0].get("gender") or "").lower() if people else ""
            cast_mode = "solo_male" if g in ("male", "man", "m") else "solo_female"
        else:
            genders = [(p.get("gender") or "").lower() for p in people if isinstance(p, dict)]
            females = sum(1 for g in genders if g in ("female", "woman", "f", "girl"))
            males = sum(1 for g in genders if g in ("male", "man", "m", "boy"))
            if females >= 2 and males == 0:
                cast_mode = "girls_only"
            elif males >= 2 and females == 0:
                cast_mode = "boys_only"
            else:
                cast_mode = "couple"

        contracts = []
        summary_lines = []

        for line in lines:
            parsed = self._parse_beat(line, db)
            if not parsed:
                log.append(f"SKIP unknown: {line}")
                continue
            act_key, variant_idx, intensity, entry, chosen = parsed
            fr = entry.get("framing") or {}
            secs = entry.get("secondaries") or entry.get("secondary_actions") or []
            nvar = len(entry.get("variants") or [])
            req = entry.get("required_visible") or ""
            loras = entry.get("lora_triggers") or []

            contracts.append(
                {
                    "shot_number": len(contracts) + 1,
                    "activity": entry.get("label", act_key),
                    "activity_key": act_key,
                    "variant_index": variant_idx,
                    "variant_text": chosen,
                    "position": act_key,
                    "intensity": intensity,
                    "hint": chosen[:120],
                    "participants_involved": names,
                    "required_visible": req,
                    "required_secondary_motions": secs,
                    "secondaries": secs,
                    "lora_triggers": loras,
                    "lora_phrase": loras[0] if loras else "",
                    "lexicon": entry.get("lexicon") or [],
                    "caption_example": entry.get("caption_example") or "",
                    "framing": fr,
                    "environment": environment,
                    "sex_type_context": entry.get("sex_type", ""),
                    "word_count": 120,
                    "studio_id": studio_id,
                }
            )
            req_flag = " ✓req" if req else ""
            summary_lines.append(
                f"{len(contracts)}. {act_key}  v{variant_idx}/{nvar}  [{intensity}]{req_flag}  "
                + (chosen[:65] + "…" if len(chosen) > 65 else chosen)
            )
            log.append(
                f"{len(contracts)}. {act_key} v{variant_idx}/{nvar} [{intensity}] "
                f"loras={len(loras)} req={bool(req)}"
            )

        scene = {
            "studio_id": studio_id,
            "studio_name": studio.get("display_name", studio_id),
            "archetype": sequence_template if sequence_template != "(none)" else "user_sequence",
            "archetype_label": scene_name,
            "cast_mode": cast_mode,
            "environment": environment,
            "participants": people,
            "style": {
                "lighting": studio.get("lighting", ""),
                "camera": studio.get("camera", ""),
                "pacing": studio.get("pacing", ""),
                "language": studio.get("language", ""),
                "audio_mood": studio.get("audio_mood", ""),
                "negative_bias": studio.get("negative_bias", ""),
                "model_hints": studio.get("model_hints", {}),
            },
            "sequence_source": "AVS_Sequence",
            "sequence_template": sequence_template,
            "created": datetime.now().isoformat(),
        }
        scene["locked_desc"] = locked_desc(people) if people else ""

        return (
            json.dumps(scene, indent=2, ensure_ascii=False),
            json.dumps({"shot_contracts": contracts}, indent=2, ensure_ascii=False),
            "\n".join(summary_lines) if summary_lines else "(no shots)",
            catalog,
            len(contracts),
            "\n".join(log),
        )

    def _full_db(self):
        from pathlib import Path
        p = Path(__file__).resolve().parents[1] / "data" / "sex_activities_db.json"
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _catalog(self, db):
        full = self._full_db()
        templates = full.get("sequence_templates") or {}
        lines = [
            f"=== Sequence templates ({len(templates)}) ===",
            "",
        ]
        for tid, t in sorted(templates.items()):
            lines.append(f"*{tid}* — {t.get('label', tid)}")
            lines.append(f"  {t.get('description', '')}")
            lines.append("  " + " → ".join(b.split(":")[0] for b in t.get("beats") or []))
            lines.append("")
        lines.append(f"=== Activity catalog ({len(db)} activities) ===")
        lines.append("")
        for k in sorted(db.keys()):
            entry = db[k]
            variants = entry.get("variants") or []
            req = entry.get("required_visible") or ""
            lines.append(f"{k}  — {entry.get('label', k)}  ({len(variants)} layouts)")
            if req:
                lines.append(f"    required: {req}")
            for i, v in enumerate(variants, 1):
                short = v if len(v) <= 100 else v[:97] + "…"
                lines.append(f"    {i}. {short}")
            lines.append("")
        lines.append("Format: activity:variant_index:intensity")
        lines.append("Pick sequence_template OR write your own spine.")
        return "\n".join(lines)

    def _parse_lines(self, text):
        raw = text.replace(";", "\n")
        return [
            ln.strip()
            for ln in raw.splitlines()
            if ln.strip() and not ln.strip().startswith("#")
        ]

    def _parse_beat(self, line, db):
        parts = [p.strip() for p in line.split(":")]
        act_key = parts[0].lower().replace(" ", "_")
        variant_idx = 1
        intensity = "medium"
        if len(parts) >= 2 and parts[1].isdigit():
            variant_idx = max(1, int(parts[1]))
        if len(parts) >= 3 and parts[2]:
            intensity = parts[2].lower()
        elif len(parts) == 2 and parts[1] and not parts[1].isdigit():
            intensity = parts[1].lower()
        entry = db.get(act_key)
        if not entry:
            for k, v in db.items():
                if k in act_key or act_key in k or (v.get("label") or "").lower() == parts[0].lower():
                    act_key, entry = k, v
                    break
        if not entry:
            return None
        variants = entry.get("variants") or ["explicit action"]
        vi = min(variant_idx, len(variants))
        chosen = variants[vi - 1]
        return act_key, vi, intensity, entry, chosen


NODE_CLASS_MAPPINGS = {"AVS_Sequence": AVS_Sequence}
NODE_DISPLAY_NAME_MAPPINGS = {"AVS_Sequence": "AVS Sequence Decider"}
