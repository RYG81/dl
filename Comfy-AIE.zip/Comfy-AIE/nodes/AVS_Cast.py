"""Load cast from performer database. No LLM."""

import json
import random
from ..avs_core.studio import load_performers, locked_desc


class AVS_Cast:
    @classmethod
    def INPUT_TYPES(cls):
        db = load_performers()
        f_names = ["(random)"] + [p["name"] for p in db.get("females_young", []) if p.get("name")]
        m_all = (
            db.get("males_young", [])
            + db.get("males_middle", [])
            + db.get("males_older", [])
        )
        m_names = ["(random)"] + sorted({p["name"] for p in m_all if p.get("name")})
        return {
            "required": {
                "mode": (["couple", "solo_female", "solo_male"], {"default": "couple"}),
                "female_pick": (f_names, {"default": f_names[0]}),
                "male_pool": (
                    ["males_young", "males_middle", "males_older", "any_male"],
                    {"default": "males_young"},
                ),
                "male_pick": (m_names, {"default": m_names[0]}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffffffff}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("participants_json", "locked_desc", "cast_summary")
    FUNCTION = "build"
    CATEGORY = "AVS"

    def build(self, mode, female_pick, male_pool, male_pick, seed):
        db = load_performers()
        rng = random.Random(seed) if seed else random.Random()

        def pick_female():
            pool = list(db.get("females_young") or [])
            if not pool:
                return {"name": "Ava", "gender": "Female", "age": 24, "clothing_condition": "nude"}
            if female_pick != "(random)":
                for p in pool:
                    if p.get("name") == female_pick:
                        return p
            return rng.choice(pool)

        def pick_male():
            if male_pool == "males_young":
                pool = list(db.get("males_young") or [])
            elif male_pool == "males_middle":
                pool = list(db.get("males_middle") or [])
            elif male_pool == "males_older":
                pool = list(db.get("males_older") or [])
            else:
                pool = (
                    list(db.get("males_young") or [])
                    + list(db.get("males_middle") or [])
                    + list(db.get("males_older") or [])
                )
            if not pool:
                return {"name": "Jordan", "gender": "Male", "age": 28, "clothing_condition": "nude"}
            if male_pick != "(random)":
                for p in pool:
                    if p.get("name") == male_pick:
                        return p
            return rng.choice(pool)

        if mode == "solo_female":
            people = [pick_female()]
        elif mode == "solo_male":
            people = [pick_male()]
        else:
            people = [pick_female(), pick_male()]

        summary = " + ".join(
            f"{p.get('name')} ({p.get('gender')}, {p.get('age')})" for p in people
        )
        return (
            json.dumps(people, indent=2, ensure_ascii=False),
            locked_desc(people),
            summary,
        )


NODE_CLASS_MAPPINGS = {"AVS_Cast": AVS_Cast}
NODE_DISPLAY_NAME_MAPPINGS = {"AVS_Cast": "AVS Cast"}
