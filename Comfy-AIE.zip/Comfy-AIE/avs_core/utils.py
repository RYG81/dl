import json

def parse_json_safe(s, fallback):
    try:
        return json.loads(s) if s and s.strip() else fallback
    except Exception:
        return fallback

def split_list(s):
    if not s:
        return []
    return [x.strip() for x in s.split(";") if x.strip()]

def int_safe(x, default=0):
    try:
        return int(x)
    except Exception:
        return default

def nonempty(s):
    return bool(s and str(s).strip())
