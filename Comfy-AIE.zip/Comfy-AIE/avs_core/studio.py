"""Studio catalog + archetype helpers."""

import json
from pathlib import Path


def _root() -> Path:
    return Path(__file__).resolve().parent.parent


def load_studios() -> dict:
    p = _root() / "avs_config" / "studios" / "catalog.json"
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def load_archetypes() -> dict:
    p = _root() / "avs_config" / "studios" / "scene_archetypes.json"
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def load_performers() -> dict:
    p = _root() / "data" / "performers.json"
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def load_activity_presets() -> dict:
    p = _root() / "avs_config" / "presets" / "activity_presets.json"
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def load_system_prompt(name: str) -> str:
    p = _root() / "avs_config" / "prompts" / name
    try:
        return p.read_text(encoding="utf-8")
    except Exception:
        return ""


def load_solo_phrases() -> dict:
    """Studio Sensual vs Raw Hard phrase banks for solo prompts."""
    p = _root() / "avs_config" / "presets" / "solo_style_phrases.json"
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def locked_desc(people: list) -> str:
    if not people:
        return "LOCKED PERFORMERS: adult performers, fully nude."
    lines = []
    for p in people:
        if not isinstance(p, dict):
            continue
        name = p.get("name", "Performer")
        gender = p.get("gender", "")
        age = p.get("age", "")
        phys = p.get("physical_description") or {}
        sexf = p.get("sexual_features") or {}
        bits = [str(name)]
        if gender:
            bits.append(str(gender).lower())
        if age:
            bits.append(f"age {age}")
        for k in ("hair_color", "skin_tone", "build", "height"):
            if phys.get(k):
                bits.append(str(phys[k]))
        extra = []
        g = str(gender).lower()
        if g in ("female", "woman", "f"):
            br = sexf.get("breasts") or {}
            if isinstance(br, dict) and any(br.values()):
                extra.append("breasts: " + ", ".join(f"{k} {v}" for k, v in br.items() if v))
            vu = sexf.get("vulva") or {}
            if isinstance(vu, dict) and any(vu.values()):
                extra.append("vulva: " + ", ".join(f"{k} {v}" for k, v in vu.items() if v))
        else:
            pe = sexf.get("penis") or {}
            if isinstance(pe, dict) and any(pe.values()):
                extra.append("cock: " + ", ".join(f"{k} {v}" for k, v in pe.items() if v))
        line = ", ".join(bits) + ". Fully nude."
        if extra:
            line += " " + "; ".join(extra) + "."
        lines.append(line)
    return (
        "LOCKED PERFORMER DESCRIPTIONS (use exactly these visual details):\n"
        + "\n".join(f"- {L}" for L in lines)
    )


def load_activities_db() -> dict:
    p = _root() / "data" / "sex_activities_db.json"
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data.get("activities") or {}
    except Exception:
        return {}
