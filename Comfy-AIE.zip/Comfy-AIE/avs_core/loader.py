import json
from pathlib import Path

def load_json(rel_path: str, default):
    try:
        base = Path(__file__).resolve().parent.parent / "avs_config"
        fp = base / rel_path
        if not fp.exists():
            return default
        return json.loads(fp.read_text(encoding="utf-8"))
    except Exception:
        return default

def load_preset(group: str, key: str, default):
    data = load_json(f"presets/{group}.json", {})
    return data.get(key, default)
