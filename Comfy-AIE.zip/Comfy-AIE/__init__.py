from .nodes.AVS_Studio import AVS_Studio
from .nodes.AVS_Cast import AVS_Cast
from .nodes.AVS_Scene import AVS_Scene
from .nodes.AVS_Render import AVS_Render
from .nodes.AVS_PickPrompt import AVS_PickPrompt
from .nodes.AVS_Ollama import AVS_Ollama
from .nodes.AVS_Sequence import AVS_Sequence
from .nodes.AVS_Plan import AVS_Plan
from .nodes.AVS_RefSheet import AVS_RefSheet

NODE_CLASS_MAPPINGS = {
    "AVS_Studio": AVS_Studio,
    "AVS_Cast": AVS_Cast,
    "AVS_Scene": AVS_Scene,
    "AVS_Render": AVS_Render,
    "AVS_PickPrompt": AVS_PickPrompt,
    "AVS_Ollama": AVS_Ollama,
    "AVS_Sequence": AVS_Sequence,
    "AVS_Plan": AVS_Plan,
    "AVS_RefSheet": AVS_RefSheet,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AVS_Studio": "AVS Studio",
    "AVS_Cast": "AVS Cast",
    "AVS_Scene": "AVS Scene",
    "AVS_Render": "AVS Render (template prompts)",
    "AVS_PickPrompt": "AVS Pick Prompt",
    "AVS_Ollama": "AVS Ollama (full generate / optional rewrite)",
    "AVS_Sequence": "AVS Sequence Decider",
    "AVS_Plan": "AVS Plan Sequence (story → shots)",
    "AVS_RefSheet": "AVS Reference Sheet (LTX Ingredients)",
}

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
