# Comfy-AIE

Database-first adult video prompt system for ComfyUI.

## Sequence decision = one node

**AVS Sequence Decider** is the only place you define the shot list.

```
Studio → Cast → Sequence Decider → Render  (or Ollama) → Pick Prompt
```

### How to decide the sequence

Write one beat per line:

```
foreplay:1:low
blowjob:2:medium
missionary:1:high
doggy:3:peak
creampie_missionary:1:peak
```

| Field | Meaning |
|-------|---------|
| `activity` | key from the activity DB |
| `:2` | **variant index (1-based)** — you pick the phrasing |
| `:high` | intensity: low / medium / high / peak |

Optional dropdowns **append_activity / append_variant / append_intensity** add one more beat after the text box.

Set **list_catalog = True** once → `activity_catalog` lists all **63 activities / 173+ variants** with numbers.

### Outputs

| Output | Use |
|--------|-----|
| scene_json | → Render / Ollama |
| shot_contracts_json | → Render / Ollama |
| sequence_summary | human-readable plan |
| activity_catalog | full DB list |
| shot_count | number of beats |

### Prompt generation

- **AVS Render** — template (no LLM)
- **AVS Ollama** — full generate with same activity DB requirements + your system prompts


## LoRA stacking (studio quality)

See `data/lora_triggers_ref.json`:

- **loras** — catalog with links + default weights
- **stacks** — recommended multi-LoRA recipes per activity
- **stacking_rules** — how to layer foundation / specialist / anatomy / finish

Example **blowjob** stack (WAN 2.2):

| LoRA | Weight | Role |
|------|--------|------|
| Sensual BJ | 0.90 | primary motion |
| Handjob combo | 0.70 | hand on shaft |
| Penis (Taz) | 0.50 | anatomy |
| DR34ML4Y (optional) | 0.40 | bl0wj0b anchor |

Prompt prefix: `sensualBJ, bl0wj0b, handj0b, performing fellatio, …`

Rules of thumb: one primary specialist; anatomy ≤0.6; finish LoRAs often as a second clip.
