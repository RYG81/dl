# Motion Studio → Unity: test prototype 0.1

**Editable scene objects, not video. Target: Unity 6 (6000.0+).**

This first importer targets the three supplied lesson concepts. Every visual element becomes a named uGUI object with a RectTransform, editable text or procedural UI geometry, and its own Timeline clip. The JSON is stored on its MotionNode component. Narration and real CC0 sound cues become WAV assets, AudioSources and native audio tracks.

## Install (use a new test Unity project)

1. Create/open a **Unity 6** project (2D built-in or Universal 2D).
2. Unzip this delivery **outside** your Unity project's Assets folder. Keep it there while testing.
3. Unity → **Window → Package Manager → + → Install package from disk** (wording can be “Add package from disk”). Select `Packages/com.arena.motion-studio/package.json` from this delivery.
4. Let Unity resolve uGUI, Timeline and Newtonsoft JSON. Internet is required for dependencies not already cached. This extension never downloads model binaries or source media.
5. Import TMP Essential Resources if prompted (Window → TextMeshPro → Import TMP Essential Resources). Alternatively supply your own TMP Font Asset in the importer.
6. Open **Tools → Motion Studio → Import scene JSON**.
7. Browse to `Examples/concept-smart-fan.json`. Click **Validate**, then **Create scene + Timeline**.
8. Select the generated root object. Open **Window → Sequencing → Timeline**. Scrub its timeline, or enter Play Mode for narration and motion. Use the **Game view**, 16:9, for the Canvas output.
9. Repeat for the other two JSON files. Each import saves a separate scene under `Assets/MotionStudioImports/`; open each generated `Lesson.unity` to revisit it.

The importer prompts to save your current scene first. It creates a **fresh uniquely named output folder** every time; it never merges into a manually modified scene.

## Three projects to test

| JSON | Duration | Inspect |
|---|---:|---|
| concept-smart-fan | 29 s | Fan card; unknown method; three possible mechanisms; final hold at 21–29 s |
| concept-sort-justify-revise | 29 s | Four destinations; timer moves into Fixed settings; other seven cards hidden; hold at 21–29 s |
| concept-ai-attendance | 28 s | Device silhouette; Input / Decision method / Output; hold at 20–28 s |

All supplied narration and recorded SFX are embedded in these JSONs. Source receipts and CC0 licence accompany the package. Voice is AI-generated using the voice selected for the original lesson, not a named-person recording.

## What is editable?

- Text content/style: on the generated TextMeshProUGUI components.
- Drawings: MotionGraphic components (rect, rounded card, ellipse, line).
- Motion/keyframes: `MotionNode.elementJson` on the object's component. The numbers are in the same design-pixel coordinate space as the web editor. Scrub after editing to evaluate them.
- Audio: native Timeline clips and AudioSources.
- Timing: source JSON start/end and keys. Each visual clip spans the whole scene so backwards seeking evaluates the element from absolute time.

**Important:** keyed transforms, sizes and opacity are reapplied while scrubbing. Edit their JSON keys, not the RectTransform, for lasting motion changes. Colours/text edits on components persist until you regenerate. Moving/trimming the custom visual clips changes their local evaluation time: keep them at timeline zero for source parity. Native Unity AnimationClip baking and a visual keyframe editor are **not implemented** in this prototype.

## Compatibility / honest limits

Supported for these examples: text, rect, ellipse, line; x/y/w/h/scale/rotation/opacity/strokeWidth tracks; supported easing functions; embedded WAV audio with static gain. Stable z ordering, centre coordinates and clockwise rotation are converted to Unity UI space. Rounded shapes use procedural meshes, not textures.

Not yet supported: arbitrary images, rings, polylines, gradients, blur, text reveal, particles, charts, meshes/3D, animated audio gain, or round-trip export to JSON. Validation rejects unsupported types/properties instead of producing fake substitutes. This validator is for the supported prototype subset, not a complete version-1 schema validator.

Font fidelity is approximate: one selected TMP font is used for all font families; bold uses TMP styling; advanced letter spacing/line-height matching is not implemented. The bundled scenes use explicit line breaks; verify your font's arrow/question-mark glyphs and wrapping. Timeline audio preview during backwards seeking depends on Unity's audio preview behaviour; use Play Mode for the full audio test. No fonts are redistributed.

**No Unity Editor was available in the build environment.** The package and example-data checks were run, but Unity compilation, package resolution, Canvas visual parity, audio playback and Timeline editor behaviour remain to be verified on your machine. This is a test prototype, not a validated production plugin. If Unity reports a Console error, send its complete text and your Unity version.

## Expected output

```
Assets/MotionStudioImports/<unique lesson>/
  Lesson.unity
  Lesson.playable
  Audio/*.wav
  Source/scene.json
```

No MP4, rendered image sequence, model download or external audio request is made by the importer. Only the local WAVs are extracted from the JSON you select.
