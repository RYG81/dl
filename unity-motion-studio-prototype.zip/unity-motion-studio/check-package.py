"""Data and C# syntax checks only. Does NOT replace compiling inside Unity.
Optional parser dependencies: pip install tree-sitter tree-sitter-c-sharp
"""
import json,pathlib,base64,wave,io,hashlib
root=pathlib.Path(__file__).parent
checks=[]
for p in (root/'Examples').glob('*.json'):
 s=json.loads(p.read_text());assert s['version']==1;assert s['meta']['duration'] in [28,29]
 ids=set();voices=0
 for e in s['elements']:
  assert e['id'] not in ids;ids.add(e['id']);assert e['type'] in ['text','rect','ellipse','line','audio']
  for prop,keys in e.get('anim',{}).items():
   assert prop in ['x','y','w','h','scale','rotate','opacity','strokeWidth'];assert keys==sorted(keys,key=lambda k:k['t'])
  if e['type']=='audio':
   assert e['kind']=='file';data=base64.b64decode(e['src'].split(',',1)[1]);w=wave.open(io.BytesIO(data));assert w.getsampwidth()==2
   if 'narration' in e.get('name',''):voices+=1
 assert voices==1
 checks.append(p.name+': supported primitives/tracks, unique IDs, embedded PCM16 audio, one narration')
for p in (root/'Packages').rglob('*.json'):json.loads(p.read_text())
for p in (root/'Packages').rglob('*.asmdef'):json.loads(p.read_text())
try:
 from tree_sitter import Language,Parser
 import tree_sitter_c_sharp
 parser=Parser(Language(tree_sitter_c_sharp.language()))
 for p in (root/'Packages').rglob('*.cs'):
  tree=parser.parse(p.read_bytes());assert not tree.root_node.has_error,p
  checks.append(p.name+': C# syntax parses (not Unity compilation)')
except ImportError:checks.append('C# syntax parser skipped: install optional tree-sitter dependencies')
report={'status':'prototype; Unity execution untested','checks':checks}
(root/'CHECKS.json').write_text(json.dumps(report,indent=2))
print('\n'.join(checks))
