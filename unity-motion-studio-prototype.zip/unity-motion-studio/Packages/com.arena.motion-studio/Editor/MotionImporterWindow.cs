using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Timeline;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
namespace Arena.MotionStudio.Editor {
 public sealed class MotionImporterWindow:EditorWindow {
  string source="",output="Assets/MotionStudioImports",report="Choose one scene JSON. Each import creates a new scene and Timeline.";
  TMP_FontAsset font;
  [MenuItem("Tools/Motion Studio/Import scene JSON")]
  static void Open()=>GetWindow<MotionImporterWindow>("Motion Studio");
  void OnGUI(){
   GUILayout.Label("JSON → Editable Unity scene",EditorStyles.boldLabel);
   EditorGUILayout.HelpBox("Prototype for Unity 6. Native uGUI objects + per-element Timeline tracks. No rendered video.",MessageType.Info);
   EditorGUILayout.BeginHorizontal();source=EditorGUILayout.TextField("Scene JSON",source);if(GUILayout.Button("Browse",GUILayout.Width(70)))source=EditorUtility.OpenFilePanel("Motion Studio scene","","json");EditorGUILayout.EndHorizontal();
   output=EditorGUILayout.TextField("Output under Assets",output);font=(TMP_FontAsset)EditorGUILayout.ObjectField("Text font",font,typeof(TMP_FontAsset),false);
   if(GUILayout.Button("Validate")){try{var s=Read();Validate(s);report="Valid supported scene: "+MotionJson.S(s["meta"],"title")+"\nCreates a fresh scene, Timeline, source copy and embedded WAV assets. Fonts may change line widths.";}catch(Exception ex){report=ex.Message;}}
   if(GUILayout.Button("Create scene + Timeline")){try{Import();}catch(Exception ex){report=ex.ToString();Debug.LogException(ex);}}
   EditorGUILayout.HelpBox(report,MessageType.None);
  }
  JObject Read()=>JObject.Parse(File.ReadAllText(source));
  static readonly HashSet<string> Types=new HashSet<string>{"text","rect","ellipse","line","audio"};
  static readonly HashSet<string> Props=new HashSet<string>{"x","y","w","h","scale","rotate","opacity","strokeWidth"};
  static readonly HashSet<string> Eases=new HashSet<string>{"linear","smooth","inCubic","outCubic","inOutCubic","inExpo","outExpo","outBack","outElastic","step"};
  public static void Validate(JObject s){
   if((int?)s["version"]!=1||!(s["elements"] is JArray)||s["meta"]==null)throw new Exception("Expected Motion Studio version 1 scene JSON.");
   if(MotionJson.N(s["meta"],"duration")<=0||MotionJson.N(s["meta"],"width")<=0||MotionJson.N(s["meta"],"height")<=0)throw new Exception("Invalid scene dimensions/duration.");
   if(MotionJson.N(s["theme"],"grain")!=0||MotionJson.N(s["theme"],"vignette")!=0||s["theme"]?["bgTo"]?.Type==JTokenType.String)throw new Exception("Gradient backgrounds, grain and vignette are not supported in this prototype.");
   var ids=new HashSet<string>();
   foreach(var e in (JArray)s["elements"]){
    string id=MotionJson.S(e,"id"),type=MotionJson.S(e,"type");if(id==""||!ids.Add(id))throw new Exception("Missing or duplicate element ID: "+id);
    if(!Types.Contains(type))throw new Exception(id+": unsupported type "+type);
    if(MotionJson.N(e,"blur")!=0||e["gradient"] is JArray||e["dash"] is JArray)throw new Exception(id+": blur, gradients and dashed geometry are not supported.");
    if(type=="text"&&MotionJson.S(e,"revealMode","none")!="none")throw new Exception(id+": text reveal is not supported yet.");
    if(e["anim"] is JObject anim)foreach(var p in anim.Properties()){
     if(!Props.Contains(p.Name))throw new Exception(id+": unsupported animated property "+p.Name);
     float last=-float.MaxValue;foreach(var k in (JArray)p.Value){float t=MotionJson.N(k,"t");if(t<last||!Eases.Contains(MotionJson.S(k,"ease","linear")))throw new Exception(id+": unsorted keys or unsupported ease.");last=t;}
    }
    if(type=="audio"){
     if(MotionJson.S(e,"kind")!="file"||!MotionJson.S(e,"src").StartsWith("data:audio/wav;base64,"))throw new Exception(id+": audio requires embedded WAV. Remote downloads and synthesized tones are not substituted.");
     byte[] wav=Convert.FromBase64String(MotionJson.S(e,"src").Substring("data:audio/wav;base64,".Length));
     if(wav.Length<44||System.Text.Encoding.ASCII.GetString(wav,0,4)!="RIFF")throw new Exception(id+": invalid WAV.");
    }
   }
  }
  void Import(){
   var s=Read();Validate(s);
   var f=font!=null?font:TMP_Settings.defaultFontAsset;
   if(f==null)throw new Exception("Choose a TMP Font Asset, or import Window → TextMeshPro → Import TMP Essential Resources first.");
   if(!output.StartsWith("Assets/",StringComparison.Ordinal)||output.Contains(".."))throw new Exception("Output must be a folder under Assets/ without '..'.");
   if(!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())return;
   string title=MotionJson.S(s["meta"],"title","Lesson"),slug=string.Concat(title.Select(c=>char.IsLetterOrDigit(c)?c:'_'));
   string dir=AssetDatabase.GenerateUniqueAssetPath(output.TrimEnd('/')+"/"+slug);Directory.CreateDirectory(dir+"/Audio");Directory.CreateDirectory(dir+"/Source");
   File.WriteAllText(dir+"/Source/scene.json",s.ToString());AssetDatabase.Refresh();
   var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
   var root=new GameObject(title);var director=root.AddComponent<PlayableDirector>();director.playOnAwake=true;director.extrapolationMode=DirectorWrapMode.Hold;
   var timeline=ScriptableObject.CreateInstance<TimelineAsset>();AssetDatabase.CreateAsset(timeline,dir+"/Lesson.playable");timeline.durationMode=TimelineAsset.DurationMode.FixedLength;timeline.fixedDuration=MotionJson.N(s["meta"],"duration");timeline.editorSettings.fps=MotionJson.N(s["meta"],"fps",30);director.playableAsset=timeline;
   var cameraGO=new GameObject("Lesson Camera",typeof(Camera),typeof(AudioListener));cameraGO.transform.SetParent(root.transform,false);cameraGO.transform.position=new Vector3(0,0,-10);cameraGO.GetComponent<Camera>().orthographic=true;cameraGO.GetComponent<Camera>().clearFlags=CameraClearFlags.SolidColor;cameraGO.GetComponent<Camera>().backgroundColor=Color.black;
   var canvasGO=new GameObject("Lesson Canvas",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler));canvasGO.transform.SetParent(root.transform,false);canvasGO.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;
   var scaler=canvasGO.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;var dimensions=new Vector2(MotionJson.N(s["meta"],"width"),MotionJson.N(s["meta"],"height"));scaler.referenceResolution=dimensions;scaler.screenMatchMode=CanvasScaler.ScreenMatchMode.Expand;
   var bg=new GameObject("Background",typeof(RectTransform),typeof(Image));bg.transform.SetParent(canvasGO.transform,false);var br=bg.GetComponent<RectTransform>();br.anchorMin=Vector2.zero;br.anchorMax=Vector2.one;br.offsetMin=br.offsetMax=Vector2.zero;bg.GetComponent<Image>().color=MotionJson.ColorOf(MotionJson.S(s["theme"],"bg"),Color.black);bg.GetComponent<Image>().raycastTarget=false;
   foreach(var raw in ((JArray)s["elements"]).OrderBy(e=>MotionJson.N(e,"z"))){
    var e=(JObject)raw.DeepClone();string type=MotionJson.S(e,"type"),id=MotionJson.S(e,"id");
    if(type=="audio"){
     if(e["hidden"]?.Value<bool>()==true)continue;
     var bytes=Convert.FromBase64String(MotionJson.S(e,"src").Substring("data:audio/wav;base64,".Length));string wavPath=dir+"/Audio/"+id+".wav";File.WriteAllBytes(wavPath,bytes);AssetDatabase.ImportAsset(wavPath,ImportAssetOptions.ForceSynchronousImport);var audio=AssetDatabase.LoadAssetAtPath<AudioClip>(wavPath);if(audio==null)throw new Exception("Unity could not decode "+wavPath);
     var audioGO=new GameObject(MotionJson.S(e,"name",id));audioGO.transform.SetParent(root.transform,false);var a=audioGO.AddComponent<AudioSource>();a.playOnAwake=false;a.spatialBlend=0;a.volume=Mathf.Clamp01(MotionJson.N(e,"gain",1)*MotionJson.N(e,"volume",1));
     var at=timeline.CreateTrack<AudioTrack>(null,id);director.SetGenericBinding(at,a);var clip=at.CreateClip(audio);clip.start=MotionJson.N(e,"start");clip.duration=Math.Min(audio.length,Math.Max(.001,MotionJson.N(e,"end",(float)timeline.fixedDuration)-clip.start));clip.displayName=audioGO.name;continue;
    }
    var go=new GameObject(MotionJson.S(e,"name",id),typeof(RectTransform),typeof(CanvasGroup));go.transform.SetParent(canvasGO.transform,false);var rt=go.GetComponent<RectTransform>();rt.anchorMin=rt.anchorMax=rt.pivot=new Vector2(.5f,.5f);
    if(type=="text"){
     var text=go.AddComponent<TextMeshProUGUI>();text.font=f;text.text=MotionJson.S(e,"text");text.fontSize=MotionJson.N(e,"size",36);text.fontStyle=MotionJson.N(e,"weight",400)>=600?FontStyles.Bold:FontStyles.Normal;text.color=MotionJson.ColorOf(MotionJson.S(e,"color"),Color.white);text.raycastTarget=false;text.enableWordWrapping=false;text.overflowMode=TextOverflowModes.Overflow;
     text.alignment=TextAlignmentOptions.Center;rt.sizeDelta=new Vector2(Mathf.Max(100,text.preferredWidth+8),Mathf.Max(text.fontSize*1.5f,text.preferredHeight+8));
    }else{
     var g=go.AddComponent<MotionGraphic>();g.shape=type;g.color=MotionJson.ColorOf(MotionJson.S(e,"color"),Color.clear);g.outline=MotionJson.ColorOf(MotionJson.S(e,"stroke"),Color.clear);g.raycastTarget=false;
    }
    var node=go.AddComponent<MotionNode>();node.baseSize=rt.sizeDelta;node.elementJson=e.ToString();node.designSize=dimensions;node.sceneDuration=(float)timeline.fixedDuration;node.Evaluate(0);
    var track=timeline.CreateTrack<MotionTrack>(null,id);var tc=track.CreateClip<MotionClip>();tc.start=0;tc.duration=timeline.fixedDuration;tc.displayName=go.name;var mc=(MotionClip)tc.asset;mc.target=new ExposedReference<MotionNode>{exposedName=new PropertyName(id)};director.SetReferenceValue(mc.target.exposedName,node);
   }
   AssetDatabase.SaveAssets();EditorSceneManager.SaveScene(scene,dir+"/Lesson.unity");director.RebuildGraph();director.time=0;director.Evaluate();Selection.activeGameObject=root;
   report="Created "+dir+"/Lesson.unity\nSelect the director and open Window → Sequencing → Timeline. Scrub or press Play in Timeline. No source JSON is modified.";
  }
 }
}
