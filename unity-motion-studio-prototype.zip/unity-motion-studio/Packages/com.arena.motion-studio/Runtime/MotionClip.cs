using System;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Timeline;
namespace Arena.MotionStudio {
 [Serializable]public sealed class MotionClip:PlayableAsset,ITimelineClipAsset {
  public ExposedReference<MotionNode> target;
  public ClipCaps clipCaps=>ClipCaps.None;
  public override Playable CreatePlayable(PlayableGraph graph,GameObject owner){var p=ScriptPlayable<MotionBehaviour>.Create(graph);p.GetBehaviour().target=target.Resolve(graph.GetResolver());return p;}
 }
}
