using System;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Timeline;
namespace Arena.MotionStudio {
 public sealed class MotionBehaviour:PlayableBehaviour {
  public MotionNode target;
  public override void ProcessFrame(Playable p,FrameData info,object playerData){if(target!=null)target.Evaluate((float)p.GetTime());}
 }
}
