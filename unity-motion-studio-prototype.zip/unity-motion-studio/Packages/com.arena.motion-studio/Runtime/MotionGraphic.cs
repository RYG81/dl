using UnityEngine;
using UnityEngine.UI;
namespace Arena.MotionStudio {
 // Native editable uGUI geometry. No baked PNGs or video plates.
 public sealed class MotionGraphic:MaskableGraphic {
  public string shape="rect";public float radius=0;public Color outline=Color.clear;public float strokeWidth=0;
  protected override void OnPopulateMesh(VertexHelper vh){
   vh.Clear();var r=rectTransform.rect;
   if(shape=="line"){
    // JSON line anchors at its start, unlike all other centre-anchored shapes.
    Quad(vh,new Vector2(0,-strokeWidth/2),new Vector2(r.width,strokeWidth/2),color);return;
   }
   int count=shape=="ellipse"?80:radius>0?40:4;
   var outer=new Vector2[count];var inner=new Vector2[count];
   float inset=Mathf.Min(strokeWidth,Mathf.Min(r.width,r.height)/2);
   for(int i=0;i<count;i++){
    outer[i]=Point(i,count,r,Mathf.Min(radius,Mathf.Min(r.width,r.height)/2));
    var ir=new Rect(r.x+inset,r.y+inset,Mathf.Max(0,r.width-2*inset),Mathf.Max(0,r.height-2*inset));
    inner[i]=Point(i,count,ir,Mathf.Max(0,radius-inset));
   }
   vh.AddVert(r.center,color,Vector2.zero);
   for(int i=0;i<count;i++)vh.AddVert(outer[i],color,Vector2.zero);
   for(int i=0;i<count;i++)vh.AddTriangle(0,i+1,(i+1)%count+1);
   if(outline.a>0&&inset>0){int offset=vh.currentVertCount;for(int i=0;i<count;i++){vh.AddVert(outer[i],outline,Vector2.zero);vh.AddVert(inner[i],outline,Vector2.zero);}for(int i=0;i<count;i++){int a=offset+2*i,b=offset+2*((i+1)%count);vh.AddTriangle(a,b,a+1);vh.AddTriangle(b,b+1,a+1);}}
  }
  Vector2 Point(int i,int count,Rect r,float rad){
   if(shape=="ellipse"){float a=2*Mathf.PI*i/count;return r.center+new Vector2(Mathf.Cos(a)*r.width/2,Mathf.Sin(a)*r.height/2);}
   if(count==4)return new Vector2(i==0||i==3?r.xMin:r.xMax,i<2?r.yMin:r.yMax);
   int q=i/10;float angle=(q*90+(i%10)*90f/9)*Mathf.Deg2Rad;
   var center=r.center+new Vector2(q==0||q==3?r.width/2-rad:-r.width/2+rad,q<2?r.height/2-rad:-r.height/2+rad);
   return center+new Vector2(Mathf.Cos(angle),Mathf.Sin(angle))*rad;
  }
  static void Quad(VertexHelper v,Vector2 min,Vector2 max,Color c){v.AddVert(new Vector2(min.x,min.y),c,Vector2.zero);v.AddVert(new Vector2(max.x,min.y),c,Vector2.zero);v.AddVert(new Vector2(max.x,max.y),c,Vector2.zero);v.AddVert(new Vector2(min.x,max.y),c,Vector2.zero);v.AddTriangle(0,1,2);v.AddTriangle(0,2,3);}
 }
}
