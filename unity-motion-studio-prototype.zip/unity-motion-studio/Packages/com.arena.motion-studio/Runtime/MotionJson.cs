using System;
using Newtonsoft.Json.Linq;
using UnityEngine;
namespace Arena.MotionStudio {
 public static class MotionJson {
  public static float N(JToken o,string k,float fallback=0) => o?[k]?.Type==JTokenType.Null || o?[k]==null ? fallback : o[k].Value<float>();
  public static string S(JToken o,string k,string fallback="") => o?[k]?.Type==JTokenType.Null || o?[k]==null ? fallback : o[k].Value<string>();
  public static Color ColorOf(string s,Color fallback) => ColorUtility.TryParseHtmlString(s,out var c)?c:fallback;
  public static float Value(JToken e,string p,float t,float fallback) {
   var keys=e?["anim"]?[p] as JArray;
   if(keys==null||keys.Count==0)return N(e,p,fallback);
   if(t<=N(keys[0],"t"))return N(keys[0],"v");
   for(int i=0;i<keys.Count-1;i++){
    float a=N(keys[i],"t"),b=N(keys[i+1],"t");
    if(t<=b){float u=Mathf.Clamp01((t-a)/Mathf.Max(.000001f,b-a));return Mathf.LerpUnclamped(N(keys[i],"v"),N(keys[i+1],"v"),Ease(u,S(keys[i],"ease","linear")));}
   }
   return N(keys[keys.Count-1],"v");
  }
  public static float Ease(float u,string e){
   switch(e){
    case "step":return u>=1?1:0;
    case "smooth":return u*u*(3-2*u);
    case "inCubic":return u*u*u;
    case "outCubic":return 1-Mathf.Pow(1-u,3);
    case "inOutCubic":return u<.5f?4*u*u*u:1-Mathf.Pow(-2*u+2,3)/2;
    case "inExpo":return u<=0?0:Mathf.Pow(2,10*u-10);
    case "outExpo":return u>=1?1:1-Mathf.Pow(2,-10*u);
    case "outBack":{float x=u-1;return 1+2.70158f*x*x*x+1.70158f*x*x;}
    case "outElastic":return u<=0?0:u>=1?1:Mathf.Pow(2,-10*u)*Mathf.Sin((u*10-.75f)*(2*Mathf.PI/3))+1;
    default:return u;
   }
  }
 }
}
