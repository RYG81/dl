using System;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Timeline;
namespace Arena.MotionStudio {
 [TrackClipType(typeof(MotionClip)),TrackColor(.38f,.9f,.88f)]
 public sealed class MotionTrack:TrackAsset {}
}
