using Newtonsoft.Json.Linq;
using TMPro;
using UnityEngine;
namespace Arena.MotionStudio {
 [ExecuteAlways,DisallowMultipleComponent]
 public sealed class MotionNode:MonoBehaviour {
  [TextArea(3,12)] public string elementJson;
  public Vector2 designSize=new Vector2(1920,1080);
  public float sceneDuration=29;
  public Vector2 baseSize=new Vector2(100,100);
  string parsed;JObject element;RectTransform rect;CanvasGroup group;TMP_Text text;MotionGraphic graphic;
  public void Evaluate(float t){
   if(parsed!=elementJson||element==null){element=JObject.Parse(elementJson);parsed=elementJson;}
   if(rect==null)rect=GetComponent<RectTransform>();if(group==null)group=GetComponent<CanvasGroup>();
   if(text==null)text=GetComponent<TMP_Text>();if(graphic==null)graphic=GetComponent<MotionGraphic>();
   float V(string p,float f=0)=>MotionJson.Value(element,p,t,f);
   bool visible=t>=MotionJson.N(element,"start")&&t<MotionJson.N(element,"end",sceneDuration)&&!(element["hidden"]?.Value<bool>()??false);
   group.alpha=visible?Mathf.Clamp01(V("opacity",1)):0;
   rect.anchoredPosition=new Vector2(V("x",designSize.x/2)-designSize.x/2,designSize.y/2-V("y",designSize.y/2));
   rect.sizeDelta=new Vector2(Mathf.Max(.01f,V("w",baseSize.x)),Mathf.Max(.01f,V("h",baseSize.y)));
   if(text!=null){string align=MotionJson.S(element,"align","center");if(align=="left")rect.anchoredPosition+=Vector2.right*rect.sizeDelta.x/2;else if(align=="right")rect.anchoredPosition-=Vector2.right*rect.sizeDelta.x/2;}
   rect.localScale=Vector3.one*V("scale",1);rect.localRotation=Quaternion.Euler(0,0,-V("rotate"));
   if(graphic!=null){graphic.radius=V("radius");graphic.strokeWidth=V("strokeWidth",1);graphic.SetVerticesDirty();}
  }
 }
}
